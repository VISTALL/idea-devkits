package com.intellij.persistence.database;

import org.jetbrains.annotations.Nullable;

/**
 * @author Gregory.Shrago
 */
public interface DatabaseReferenceConstraintInfo {
  DatabaseReferenceConstraintInfo[] EMPTY_ARRAY = new DatabaseReferenceConstraintInfo[0];

  String getName();

  DatabaseColumnInfo getSourceColumn();

  @Nullable
  DatabaseColumnInfo getTargetColumn();

  DatabaseTableLongInfo getSourceTable();

  @Nullable
  DatabaseTableLongInfo getTargetTable();
}
