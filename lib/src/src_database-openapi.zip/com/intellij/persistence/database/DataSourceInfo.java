package com.intellij.persistence.database;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author Gregory.Shrago
 */
public interface DataSourceInfo {

  String getName();

  String getUniqueId();

  @Nullable
  String getDatabaseProductName();

  @Nullable
  String getDatabaseProductVersion();

  @NotNull
  DatabaseTableLongInfo[] getMyTables();


}
