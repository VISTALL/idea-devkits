package com.intellij.persistence.database.psi;

import com.intellij.persistence.database.PsiDatabaseTableLongInfo;
import com.intellij.persistence.database.TableType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author Gregory.Shrago
 */
public interface DbTableElement extends DbElement, PsiDatabaseTableLongInfo {
  DbTableElement[] EMPTY_ARRAY = new DbTableElement[0];

  DbSchemaElement getDbParent();

  @NotNull
  TableType getTableType();

  @NotNull
  DbColumnElement[] getColumns();

  @Nullable
  DbColumnElement findColumn(final String name);
}
