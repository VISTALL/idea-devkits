package com.intellij.persistence.database.psi;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import com.intellij.persistence.database.DataSourceInfo;
import com.intellij.persistence.database.DatabaseConnectionInfo;

/**
 * @author Gregory.Shrago
 */
public interface DbDataSourceElement extends DbElement, DataSourceInfo{
  DbDataSourceElement[] EMPTY_ARRAY = new DbDataSourceElement[0];

  @Nullable
  DatabaseConnectionInfo getConnectionInfo();

  @NotNull
  DbTableElement[] getMyTables();

  @NotNull
  DbCatalogElement[] getCatalogs();

  @NotNull
  DbSchemaElement[] getSchemas();

  @Nullable
  DbTableElement findTable(final String table, final String schema, final String catalog);

  void clearCaches();

}
