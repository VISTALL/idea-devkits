package com.intellij.persistence.database.psi;

import com.intellij.openapi.actionSystem.Presentation;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * @author Gregory.Shrago
 */
public interface DbPsiManager {
  List<DbDataSourceElement> getDataSources();

  void removeDataSource(final DbDataSourceElement element);

  void editDataSource(final DbDataSourceElement element);

  @Nullable
  DbDataSourceElement addDataSource(@Nullable final DbDataSourceElement template);

  void tuneCreateDataSourceAction(final Presentation presentation);
}
