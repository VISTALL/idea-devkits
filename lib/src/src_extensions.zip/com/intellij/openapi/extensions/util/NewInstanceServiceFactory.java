/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.openapi.extensions.util;

import com.intellij.openapi.extensions.AreaInstance;
import com.intellij.openapi.extensions.ServiceFactory;

import java.lang.reflect.Constructor;

public class NewInstanceServiceFactory implements ServiceFactory {
  private String myClassName;

  public NewInstanceServiceFactory() {
  }

  public NewInstanceServiceFactory(String className) {
    myClassName = className;
  }

  public String getClassName() {
    return myClassName;
  }

  public void setClassName(String className) {
    myClassName = className;
  }

  public Object create(AreaInstance areaInstance) {
    try {
      Class aClass = Class.forName(myClassName);
      Constructor constructor = null;
      try {
        Constructor[] constructors = aClass.getConstructors();
        for (int i = 0; i < constructors.length; i++) {
          Constructor aConstructor = constructors[i];
          if (aConstructor.getParameterTypes().length == 1 && aConstructor.getParameterTypes()[0].isAssignableFrom(areaInstance.getClass())) {
            constructor = aConstructor;
            break;
          }
        }
      } catch (Exception e) {
      }

      if (constructor != null) {
        return constructor.newInstance(new Object[]{areaInstance});
      } else {
        return aClass.newInstance();
      }
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  public String toString() {
    return "NewInstanceServiceFactory[" + myClassName + "]";
  }
}
