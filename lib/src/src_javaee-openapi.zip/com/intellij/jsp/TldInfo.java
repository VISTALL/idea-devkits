/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsp;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * @author mike
 */
public class TldInfo implements Serializable {
  private String myUri;
  private Map<String, TagInfo> myTagName2Info = new HashMap<String, TagInfo>();
  private Map<String, TagInfo> myTagClass2Info = new HashMap<String, TagInfo>();
  private final String myTldFileUrl;
  private final long myTldFileTimestamp;

  TldInfo(String tldFileUrl, long tldFileTimestamp) {
    myTldFileUrl = tldFileUrl;
    myTldFileTimestamp = tldFileTimestamp;
  }


  public void setUri(final String uri) {
    myUri = uri;
  }

  public String getUri() {
    return myUri;
  }

  void addTagInfo(TagInfo tagInfo) {
    myTagName2Info.put(tagInfo.getTagName(), tagInfo);
    myTagClass2Info.put(tagInfo.getClassName(), tagInfo);
    tagInfo.setTldInfo(this);
  }

  public Collection<TagInfo> getTagInfos() {
    return Collections.unmodifiableCollection(myTagName2Info.values());
  }

  public TagInfo getTagInfo(String tagName) {
    return myTagName2Info.get(tagName);
  }


  public String getTldFileUrl() {
    return myTldFileUrl;
  }

  public long getTldFileTimestamp() {
    return myTldFileTimestamp;
  }

  public TagInfo findTagInfoByTagClass(final String tagClass) {
    return myTagClass2Info.get(tagClass);
  }
}
