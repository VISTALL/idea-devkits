/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsp;

import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.net.URL;
import java.util.*;

/**
 * @author mike
 */
public class ModuleTldInfo implements Serializable {
  private final Map<String, TldInfo> myUriMap = new HashMap<String, TldInfo>();
  private final Map<String, TldInfo> myFileMap = new HashMap<String, TldInfo>();
  private int myClassPathHashCode = 0;


  ModuleTldInfo(@NotNull final List<URL> classPath) {
    myClassPathHashCode = classPath.hashCode();
  }


  public ModuleTldInfo() {
  }

  void addTldInfo(TldInfo tldInfo) {
    myUriMap.put(tldInfo.getUri(), tldInfo);
    myFileMap.put(tldInfo.getTldFileUrl(), tldInfo);
  }

  public TldInfo getInfoByUri(String uri) {
    return myUriMap.get(uri);
  }

  public TldInfo getInfoByFileUrl(String fileUrl) {
    return myFileMap.get(fileUrl);
  }

  public Collection<TldInfo> getTldInfos() {
    return Collections.unmodifiableCollection(myFileMap.values());
  }


  public int getClassPathHashCode() {
    return myClassPathHashCode;
  }
}
