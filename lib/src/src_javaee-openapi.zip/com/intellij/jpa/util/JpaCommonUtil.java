/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jpa.util;

import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.OrderEntry;
import com.intellij.openapi.roots.OrderRootType;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.vfs.VfsUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiFile;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.search.ProjectScope;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: Gregory.Shrago
 * Date: 10.03.2006
 * Time: 15:10:25
 * To change this template use File | Settings | File Templates.
 */
public class JpaCommonUtil {
  private JpaCommonUtil() {
  }

  public static GlobalSearchScope getORMClassesSearchScope(@NotNull final Project project, final Module module,
                                                           @NotNull final PsiFile psiFile) {
    final ProjectRootManager instance = ProjectRootManager.getInstance(project);
    final VirtualFile virtualFile = psiFile.getVirtualFile();
    if (virtualFile == null || !(instance.getFileIndex().isInLibraryClasses(virtualFile) && virtualFile.getFileSystem().isReadOnly())) {
      return module == null? GlobalSearchScope.allScope(project) : GlobalSearchScope.moduleWithDependenciesAndLibrariesScope(module);
    }
    final ArrayList<VirtualFile> files = new ArrayList<VirtualFile>();
    for (OrderEntry entry : instance.getFileIndex().getOrderEntriesForFile(virtualFile)) {
      if (module == null || entry.getOwnerModule().equals(module)) {
        files.addAll(Arrays.asList(entry.getFiles(OrderRootType.CLASSES)));
      }
    }
    final GlobalSearchScope base = module == null? ProjectScope.getAllScope(project) : module.getModuleWithLibrariesScope();
    return new GlobalSearchScope() {
      public boolean contains(VirtualFile file) {
        for (VirtualFile file1 : files) {
          if (VfsUtil.isAncestor(file1, file, true)) {
            return true;
          }
        }
        return false;
      }

      public int compare(VirtualFile file1, VirtualFile file2) {
        return base.compare(file1, file2);
      }

      public boolean isSearchInModuleContent(@NotNull Module aModule) {
        return false;
      }

      public boolean isSearchInLibraries() {
        return true;
      }
    };
  }
}
