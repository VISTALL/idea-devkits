package com.intellij.jpa;

import com.intellij.javaee.model.xml.persistence.PersistenceUnit;
import com.intellij.openapi.extensions.ExtensionPointName;
import com.intellij.persistence.database.DatabaseConnectionInfo;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

/**
 * @author Gregory.Shrago
 */
public interface JpaImplementationProvider {
  ExtensionPointName<JpaImplementationProvider> EP_NAME = ExtensionPointName.create("com.intellij.javaee.jpa.jpaImplementationProvider");

  boolean isConfiguredForUnit(final PersistenceUnit unit);

  @NotNull
  String getProviderName();

  @Nullable
  Icon getProviderIcon();

  @NonNls
  String getProviderClassName();

  void setConnectionProperties(final PersistenceUnit unit, final DatabaseConnectionInfo connectionInfo);

  void setDefaultProperties(final PersistenceUnit unit);

}
