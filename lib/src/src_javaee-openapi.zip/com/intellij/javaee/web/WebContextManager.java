package com.intellij.javaee.web;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiFileSystemItem;
import com.intellij.psi.PsiFile;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

import java.util.Map;

/**
 * @author Dmitry Avdeev
 */
public abstract class WebContextManager {
  
  public static WebContextManager getInstance(Project project) {
    return ServiceManager.getService(project, WebContextManager.class);
  }

  @Nullable
  public abstract PsiFileSystemItem getContextFolder(@NotNull PsiFile file);

  public abstract void setContextFolder(@NotNull PsiFileSystemItem target, @NotNull PsiFileSystemItem contextFolder);

  public abstract Map<VirtualFile, String> getMappings();

  public abstract void setMappings(Map<VirtualFile, String> mappings);
}
