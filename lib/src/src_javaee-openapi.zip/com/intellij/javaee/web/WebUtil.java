/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.web;

import com.intellij.javaee.facet.JavaeeFacetUtil;
import com.intellij.javaee.model.common.JavaeeModelElement;
import com.intellij.javaee.model.xml.web.*;
import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.lang.jsp.JspxFileViewProvider;
import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.paths.PathReference;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ProjectFileIndex;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.util.TextRange;
import com.intellij.openapi.vfs.VfsUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiFileSystemItem;
import com.intellij.psi.jsp.JspFile;
import com.intellij.psi.jsp.WebDirectoryElement;
import com.intellij.util.xml.DomUtil;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.Consumer;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * @author mike
 */
public abstract class WebUtil {
  @NonNls public static final String WEB_FRAMEWORK_GROUP_ID = "web";

  public static WebUtil getWebUtil() {
    return ServiceManager.getService(WebUtil.class);
  }

  @Nullable
  public static WebFacet getWebFacet(@NotNull JavaeeModelElement element) {
    return JavaeeFacetUtil.getInstance().getJavaeeFacet(element, WebFacet.ID);
  }

  @Nullable
  public static WebFacet getWebFacet(@NotNull PsiElement element) {
    return JavaeeFacetUtil.getInstance().getJavaeeFacet(element, WebFacet.ID);
  }

  @Nullable
  public static WebFacet getWebFacet(VirtualFile file, Project project) {
    return JavaeeFacetUtil.getInstance().getJavaeeFacet(file, WebFacet.ID, project);
  }


  @Nullable
  public static WebRoot findParentWebRoot(final VirtualFile selectedFile, final List<WebRoot> webRoots) {
    if (selectedFile == null) return null;
    for (WebRoot webRoot : webRoots) {
      final VirtualFile file = webRoot.getFile();
      if (file == null) continue;
      if (VfsUtil.isAncestor(file, selectedFile, false)) {
        return webRoot;
      }
    }
    return null;
  }

  public static boolean isInsideWebRoots(VirtualFile file, List<WebRoot> webRoots) {
    for (WebRoot webRoot : webRoots) {
      VirtualFile resDir = webRoot.getFile();
      if (resDir == null || !resDir.isValid()) continue;
      if (VfsUtil.isAncestor(resDir, file, false)) return true;
    }
    return false;
  }

  public static boolean isInsideWebRoots(VirtualFile file, Project project) {
    return findFacetByFileUnderWebRoot(file, project) != null;
  }

  public static boolean isWebRoot(@NotNull VirtualFile file, Project project) {
    final ProjectFileIndex projectFileIndex = ProjectRootManager.getInstance(project).getFileIndex();
    Module module = projectFileIndex.getModuleForFile(file);
    if (module == null) return false;
    final Collection<WebFacet> webFacets = WebFacet.getInstances(module);
    for (WebFacet webFacet : webFacets) {
      List<WebRoot> webRoots = webFacet.getWebRoots(false);
      for (WebRoot webRoot : webRoots) {
        if (file.equals(webRoot.getFile())) {
          return true;
        }
      }
    }
    return false;
  }

  @Nullable
  public static Servlet findServlet(@NotNull WebFacet webFacet, final String name) {
    final WebApp root = webFacet.getRoot();
    return root == null ? null : DomUtil.findByName(root.getServlets(), name);
  }

  @Nullable
  public static Filter findFilter(@NotNull WebFacet webFacet, final String name) {
    final WebApp root = webFacet.getRoot();
    return root == null ? null : DomUtil.findByName(root.getFilters(), name);
  }

  @NotNull
  public static TextRange trimRange(@NotNull String url, TextRange range) {
    for (int i = 0; i < url.length(); i++) {
      switch (url.charAt(i)) {
        case '?':
        case '#':
          final int startOffset = range.getStartOffset();
          return new TextRange(startOffset, startOffset + i);
      }
    }
    return range;
  }


  @NotNull
  public static String trimURL(@NotNull String url) {
    return PathReference.trimPath(url);
  }


  public static int indexOfDynamicJSP(String text) {
    final int len = text.length();
    for (int i = 0; i < len; i++) {
      switch (text.charAt(i)) {
        case '$':
          if (i + 1 < len && text.charAt(i + 1) == '{') {
            return i;
          }
          break;
        case '<':
          if (i + 1 < len && text.charAt(i + 1) == '%') {
            return i;
          }
          break;
      }
    }
    return -1;

  }

  public static int getLastPosOfURL(@NotNull String url) {
    for (int i = 0; i < url.length(); i++) {
      switch (url.charAt(i)) {
        case '?':
        case '#':
          return i;
      }
    }
    return -1;
  }

  @Nullable
  public abstract JspFile getJspFile(Servlet servlet);

  public abstract WebDirectoryElement createWebDirectoryElement(WebFacet webFacet, @NotNull String path, boolean isDirectory);

  @Nullable
  public static String getRelativePath(WebDirectoryElement src, WebDirectoryElement dst) {
    final WebDirectoryElement commonAncestor = getCommonAncestor(src, dst);

    if (commonAncestor != null) {
      StringBuffer buffer = new StringBuffer();
      if (src != commonAncestor) {
        while (src.getParent() != commonAncestor) {
          buffer.append("..").append('/');
          src = src.getParentDirectory();
          assert src != null;
        }
      }
      buffer.append(getRelativePathFromAncestor(dst, commonAncestor));
      return buffer.toString();
    }

    return null;
  }

  public static String getRelativePathFromAncestor(WebDirectoryElement file, WebDirectoryElement ancestor) {

    int length = 0;
    WebDirectoryElement parent = file;

    while (true) {
      if (parent == null) return null;
      if (parent.equals(ancestor)) break;
      if (length > 0) {
        length++;
      }
      length += parent.getName().length();
      parent = parent.getParentDirectory();
    }

    char[] chars = new char[length];
    int index = chars.length;
    parent = file;

    while (true) {
      if (parent.equals(ancestor)) break;
      if (index < length) {
        chars[--index] = '/';
      }
      String name = parent.getName();
      for (int i = name.length() - 1; i >= 0; i--) {
        chars[--index] = name.charAt(i);
      }
      parent = parent.getParentDirectory();
    }
    return new String(chars);
  }

  public static WebDirectoryElement getCommonAncestor(WebDirectoryElement file1, WebDirectoryElement file2) {
      WebDirectoryElement[] path1 = getPathComponents(file1);
      WebDirectoryElement[] path2 = getPathComponents(file2);

      WebDirectoryElement[] minLengthPath;
      WebDirectoryElement[] maxLengthPath;
      if (path1.length < path2.length) {
        minLengthPath = path1;
        maxLengthPath = path2;
      }
      else {
        minLengthPath = path2;
        maxLengthPath = path1;
      }

      int lastEqualIdx = -1;
      for (int i = 0; i < minLengthPath.length; i++) {
        if (minLengthPath[i].equals(maxLengthPath[i])) {
          lastEqualIdx = i;
        }
        else {
          break;
        }
      }
      return lastEqualIdx != -1 ? minLengthPath[lastEqualIdx] : null;
    }

    /**
     * Gets an array of files representing paths from root to the passed file.
     *
     * @param file the file
     * @return virtual files which represents paths from root to the passed file
     */
    private static WebDirectoryElement [] getPathComponents(WebDirectoryElement file) {
      ArrayList<WebDirectoryElement> componentsList = new ArrayList<WebDirectoryElement>();
      while (file != null) {
        componentsList.add(file);
        file = file.getParentDirectory();
      }

      int size = componentsList.size();
      WebDirectoryElement[] components = new WebDirectoryElement[size];

      for (int i = 0; i < size; i++) {
        components[i] = componentsList.get(size - i - 1);
      }
      return components;
    }

  @Nullable
  public abstract WebDirectoryElement findWebDirectoryByFile(@NotNull final VirtualFile file, @NotNull final WebFacet webFacet);

  @Nullable
  public static WebDirectoryElement findWebDirectoryByFile(@NotNull final VirtualFile file, Project project) {
    final WebFacet webFacet = getWebFacet(file, project);
    return webFacet == null ? null : getWebUtil().findWebDirectoryByFile(file, webFacet);
  }

  @Nullable
  public static WebDirectoryElement findWebDirectoryByFile(@NotNull final PsiFileSystemItem file) {
    VirtualFile virtualFile = file.getVirtualFile();
    final WebFacet webFacet = getWebFacet(file);
    if (webFacet != null && virtualFile != null) {
      return getWebUtil().findWebDirectoryByFile(virtualFile, webFacet);
    }
    return null;
  }

  @Nullable
  public abstract WebDirectoryElement getParentWebDirectory(@NotNull PsiFile file);

  @Nullable
  public abstract WebDirectoryElement getContainingWebDirectory(JspxFileViewProvider viewProvider);

  @Nullable
  public abstract String getWebPath(PsiFile file);

  @Nullable
  public abstract WebDirectoryElement findWebDirectoryElement(@NonNls String path, @NotNull WebFacet facet);


  @NotNull
  public static List<PathReference> getPreludes(JspFile file) {
    WebFacet webFacet = WebUtil.getWebFacet(file);
    if (webFacet == null) return Collections.emptyList();

    String path = WebUtil.getWebUtil().getWebPath(file);
    if (path == null) return Collections.emptyList();

    List<PathReference> result = new ArrayList<PathReference>();
    final WebApp root = webFacet.getRoot();

    if (root != null) {
      final List<JspConfig> configs = root.getJspConfigs();
      for (JspConfig config : configs) {
        final List<JspPropertyGroup> groups = config.getJspPropertyGroups();
        for (JspPropertyGroup group : groups) {
          collectMatchingPaths(group.getIncludePreludes(), group.getUrlPatterns(), path, result);
        }
      }
    }

    return result;
  }

  public static List<PathReference> getCodas(JspFile file) {
    WebFacet webFacet = WebUtil.getWebFacet(file);
    if (webFacet == null) return Collections.emptyList();

    String path = WebUtil.getWebUtil().getWebPath(file);
    if (path == null) return Collections.emptyList();

    List<PathReference> result = new ArrayList<PathReference>();
    final WebApp root = webFacet.getRoot();

    if (root != null) {
      final List<JspConfig> configs = root.getJspConfigs();
      for (JspConfig config : configs) {
        final List<JspPropertyGroup> groups = config.getJspPropertyGroups();
        for (JspPropertyGroup group : groups) {
          collectMatchingPaths(group.getIncludeCodas(), group.getUrlPatterns(), path, result);
        }
      }
    }

    return result;
  }

  private static void collectMatchingPaths(final List<GenericDomValue<PathReference>> paths,
                                           final List<GenericDomValue<String>> patterns,
                                           final String path,
                                           final List<PathReference> result) {
    if (!paths.isEmpty() && !patterns.isEmpty()) {
      for (GenericDomValue<String> patternValue : patterns) {
        final String pattern = patternValue.getValue();
        if (pathMatchesUrlPattern(path, pattern)) {
          for (GenericDomValue<PathReference> webPath : paths) {
            final PathReference value = webPath.getValue();
            if (value != null) {
              result.add(value);
            }
          }
        }
      }
    }
  }

  public static boolean pathMatchesUrlPattern(@NotNull String path, @NotNull String pattern) {
    if (pattern.endsWith("/*")) {
      return path.startsWith(pattern.substring(0, pattern.length() - 1));
    }

    if (pattern.startsWith("*.")) {
      return path.endsWith(pattern.substring(1));
    }

    return path.equals(pattern);
  }

  @Nullable
  public static WebFacet findFacetByFileUnderWebRoot(@NotNull VirtualFile file, @NotNull Project project) {
    final Module module = ModuleUtil.findModuleForFile(file, project);
    if (module == null) return null;

    final Collection<WebFacet> facets = WebFacet.getInstances(module);
    for (WebFacet facet : facets) {
      if (isInsideWebRoots(file, facet.getWebRoots(false))) {
        return facet;
      }
    }
    return null;
  }

  public abstract Collection<PsiFileSystemItem> getContextsByPath(final String path, final @NotNull Module module);

  public abstract void visitAllFacets(final @NotNull Module module, final Consumer<WebFacet> visitor);
}
