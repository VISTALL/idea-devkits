/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.model.common.persistence;

import com.intellij.javaee.model.common.JavaeeCommonConstants;
import org.jetbrains.annotations.NonNls;

/**
 * Created by IntelliJ IDEA.
 * User: Gregory.Shrago
 * Date: 03.02.2006
 * Time: 22:18:10
 * To change this template use File | Settings | File Templates.
 */
public interface JavaeePersistenceConstants extends JpaAnnotationConstants, JavaeeCommonConstants {
  @NonNls String ORM_XML_ROOT_TAG = "entity-mappings";
  @NonNls String PERSISTENCE_XML_ROOT_TAG = "persistence";
  @NonNls String ORM_XML_NS = "http://java.sun.com/xml/ns/persistence/orm";
  @NonNls String PERSISTENCE_XML_NS = "http://java.sun.com/xml/ns/persistence";

  @NonNls String PERSISTENCE_XML_1_0 = "persistence.xml";
  @NonNls String ORM_XML_1_0 = "orm_1_0.xml";

  @NonNls String DATASOURCE_PROPERTY_NAME = "com.intellij.javaee.persistence.datasource";
  @NonNls String PERSISTENCE_PROVIDER_CLASS = "javax.persistence.spi.PersistenceProvider";

  String JAVA_SQL_BLOB = "java.sql.Blob";
  String JAVA_SQL_CLOB = "java.sql.Clob";
}
