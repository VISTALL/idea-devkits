/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.model.common.persistence.mapping;

import com.intellij.javaee.model.common.persistence.JavaeePersistenceConstants;
import org.jetbrains.annotations.NonNls;

public enum EntityListenerMethodType {
  PRE_PERSIST("PrePersist"),
  PRE_UPDATE("PreUpdate"),
  PRE_REMOVE("PreRemove"),
  POST_LOAD("PostLoad"),
  POST_REMOVE("PostRemove"),
  POST_UPDATE("PostUpdate"),
  POST_PERSIST("PostPersist"),
  ;

  private String typeName;

  EntityListenerMethodType(@NonNls final String typeName) {
   this.typeName = typeName;
 }

  public String getTypeName() { return typeName; }

  @NonNls
  public String getMethodAnnotation() {
    switch (this) {
      case PRE_PERSIST: return JavaeePersistenceConstants.PRE_PERSIST_ANNO;
      case PRE_REMOVE: return JavaeePersistenceConstants.PRE_REMOVE_ANNO;
      case PRE_UPDATE: return JavaeePersistenceConstants.PRE_UPDATE_ANNO;
      case POST_LOAD: return JavaeePersistenceConstants.POST_LOAD_ANNO;
      case POST_PERSIST: return JavaeePersistenceConstants.POST_PERSIST_ANNO;
      case POST_REMOVE: return JavaeePersistenceConstants.POST_REMOVE_ANNO;
      case POST_UPDATE: return JavaeePersistenceConstants.POST_UPDATE_ANNO;
    }
    assert false;
    return null;
  }
}
