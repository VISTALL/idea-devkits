/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.model.common.persistence.mapping;

import com.intellij.util.xml.NamedEnum;
import com.intellij.util.xml.GenericValue;
import org.jetbrains.annotations.NonNls;

import java.util.Collection;

/**
 * @author Gregory.Shrago
 */
public enum CascadeTypeMode implements NamedEnum {
  ALL("all"),
  PERSIST("persist"),
  MERGE("merge"),
  REMOVE("remove"),
  REFRESH("refresh");

  private final String value;

  private CascadeTypeMode(@NonNls String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  public String getDisplayName() {
    return getValue();
  }

  public GenericValue<Boolean> getCascadeTypeModeValue(final CascadeType cascadeType) {
    switch (this) {
      case ALL: return cascadeType.getCascadeAll();
      case MERGE: return cascadeType.getCascadeMerge();
      case PERSIST: return cascadeType.getCascadePersist();
      case REFRESH: return cascadeType.getCascadeRefresh();
      case REMOVE: return cascadeType.getCascadeRemove();
      default:throw new AssertionError();
    }
  }

  public static <T extends Collection<CascadeTypeMode>> T addCascadeTypes(final CascadeType cascadeType, final T result) {
    for (CascadeTypeMode mode : values()) {
      if (Boolean.TRUE.equals(mode.getCascadeTypeModeValue(cascadeType).getValue())) result.add(mode);
    }
    return result;
  }

}
