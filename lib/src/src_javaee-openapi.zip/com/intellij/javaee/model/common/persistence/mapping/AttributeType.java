/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.model.common.persistence.mapping;

import com.intellij.javaee.model.common.persistence.JavaeePersistenceConstants;
import com.intellij.jpa.JpaMessages;
import com.intellij.persistence.model.PersistentAttribute;
import com.intellij.persistence.model.PersistentEmbeddedAttribute;
import com.intellij.persistence.model.PersistentRelationshipAttribute;
import com.intellij.persistence.model.RelationshipType;
import com.intellij.persistence.util.JavaContainerType;
import com.intellij.psi.JavaPsiFacade;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiManager;
import com.intellij.psi.PsiType;
import com.intellij.psi.search.ProjectScope;
import com.intellij.util.IncorrectOperationException;
import com.intellij.util.JavaeeIcons;
import com.intellij.util.ReflectionCache;
import com.intellij.util.xml.ModelMergerUtil;
import gnu.trove.THashMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AttributeType {

  private static final List<AttributeType> ourInstances = new ArrayList<AttributeType>();
  private static final Map<String, AttributeType> ourAnnotations = new THashMap<String, AttributeType>();

  public static final AttributeType ID = new AttributeType(JavaeePersistenceConstants.ID_ANNO, Id.class, Id.class, JpaMessages.message("type.persistence.attr.id"));
  public static final AttributeType EMBEDDED_ID = new AttributeType(JavaeePersistenceConstants.EMBEDDED_ID_ANNO, EmbeddedId.class, EmbeddedId.class, JpaMessages.message("type.persistence.attr.embedded.id"));
  public static final AttributeType VERSION = new AttributeType(JavaeePersistenceConstants.VERSION_ANNO, Version.class, Version.class, JpaMessages.message("type.persistence.attr.version"));
  public static final AttributeType BASIC = new AttributeType(JavaeePersistenceConstants.BASIC_ANNO, Basic.class, Basic.class, JpaMessages.message("type.persistence.attr.basic"));
  public static final AttributeType EMBEDDED = new AttributeType(JavaeePersistenceConstants.EMBEDDED_ANNO, Embedded.class, Embedded.class, JpaMessages.message("type.persistence.attr.embedded"));
  public static final AttributeType ONE_TO_ONE = new AttributeType(JavaeePersistenceConstants.ONE_TO_ONE_ANNO, OneToOne.class, OneToOne.class, JpaMessages.message("type.persistence.attr.one.to.one"));
  public static final AttributeType ONE_TO_MANY = new AttributeType(JavaeePersistenceConstants.ONE_TO_MANY_ANNO, OneToMany.class, OneToMany.class, JpaMessages.message("type.persistence.attr.one.to.many"));
  public static final AttributeType MANY_TO_ONE = new AttributeType(JavaeePersistenceConstants.MANY_TO_ONE_ANNO, ManyToOne.class, ManyToOne.class, JpaMessages.message("type.persistence.attr.many.to.one"));
  public static final AttributeType MANY_TO_MANY = new AttributeType(JavaeePersistenceConstants.MANY_TO_MANY_ANNO, ManyToMany.class, ManyToMany.class, JpaMessages.message("type.persistence.attr.many.to.many"));
  public static final AttributeType TRANSIENT = new AttributeType(JavaeePersistenceConstants.TRANSIENT_ANNO, Transient.class, Transient.class, JpaMessages.message("type.persistence.attr.transient"));

  private final String myAttributeAnnotation;
  private final Class myAttributeClass;
  private final Class myAttributeAnnoClass;
  private final String myTypeName;

  public static Iterable<AttributeType> values() {
    return ourInstances;
  }

  public static Set<String> getAttributeAnnotations() {
    return ourAnnotations.keySet();
  }

  @Nullable
  public static AttributeType getAnnotationAttributeType(final AttributeType type) {
    final String annotation = type.getAttributeAnnotation();
    return annotation == null ? null : ourAnnotations.get(annotation);
  }

  protected AttributeType(final String anno, final Class attributeClass, final Class annoClass, final String typeName) {
    assert attributeClass != null : "null attribute class";
    myAttributeAnnotation = anno;
    myAttributeClass = attributeClass;
    myAttributeAnnoClass = annoClass;
    myTypeName = typeName;
    if (anno != null) {
      assert anno.length() > 0 : "empty annotation name";
      final AttributeType prevType = ourAnnotations.get(anno);
      final AttributeType baseType;
      final AttributeType newType;
      if (prevType == null || prevType.getAttributeClass() != attributeClass &&
                              ReflectionCache.isAssignable(attributeClass, prevType.getAttributeClass())) {
        ourAnnotations.put(anno, this);
        baseType = this;
        newType = prevType;
      }
      else {
        baseType = prevType;
        newType = this;
      }
      assert newType == null || newType.getAttributeAnnoClass() == null || ReflectionCache.isAssignable(baseType.getAttributeAnnoClass(), newType.getAttributeAnnoClass()) : "incompatible types: " + baseType + " and " + newType;
    }
    ourInstances.add(this);
  }

  public String getTypeName() {
    return myTypeName;
  }

  public Class getAttributeClass() {
    return myAttributeClass;
  }

  public Class getAttributeAnnoClass() {
    return myAttributeAnnoClass;
  }

  public String getAttributeAnnotation() {
    return myAttributeAnnotation;
  }

  @NotNull
  public AttributeType getOppositeType() {
    if (this == MANY_TO_MANY) {
      return MANY_TO_MANY;
    }
    else if (this == MANY_TO_ONE) {
      return ONE_TO_MANY;
    }
    else if (this == ONE_TO_MANY) {
      return MANY_TO_ONE;
    }
    else if (this == ONE_TO_ONE) {
      return ONE_TO_ONE;
    }
    else {
      throw new AssertionError(this);
    }
  }

  @Nullable
  public RelationshipType getRelationshipType() {
    if (this == MANY_TO_MANY) {
      return RelationshipType.MANY_TO_MANY;
    }
    else if (this == MANY_TO_ONE) {
      return RelationshipType.MANY_TO_ONE;
    }
    else if (this == ONE_TO_MANY) {
      return RelationshipType.ONE_TO_MANY;
    }
    else if (this == ONE_TO_ONE) {
      return RelationshipType.ONE_TO_ONE;
    }
    else {
      return null;
    }
  }

  @NotNull
  public static AttributeType getAttributeType(@NotNull final PersistentAttribute attribute) {
    for (PersistentAttribute impl : ModelMergerUtil.getImplementations(attribute)) {
      for (AttributeType type : values()) {
        if (type.accepts(impl)) return type;
      }
    }
    throw new AssertionError(attribute);
  }

  protected boolean accepts(final PersistentAttribute attribute) {
    return ReflectionCache.isInstance(attribute, getAttributeClass());
  }

  @NotNull
  public static AttributeType getAttributeType(@NotNull final RelationshipType relationshipType) {
    switch (relationshipType) {
      case MANY_TO_MANY: return AttributeType.MANY_TO_MANY;
      case MANY_TO_ONE: return AttributeType.MANY_TO_ONE;
      case ONE_TO_MANY: return AttributeType.ONE_TO_MANY;
      case ONE_TO_ONE: return AttributeType.ONE_TO_ONE;
      default: throw new AssertionError(relationshipType);
    }
  }

  public boolean isIdAttribute() {
    return this == EMBEDDED_ID || this == ID;
  }

  public boolean isContainer() {
    return this == MANY_TO_MANY || this == ONE_TO_MANY;
  }


  public boolean isEmbedded() {
    return this == EMBEDDED || this == EMBEDDED_ID;
  }

  public boolean canBeEmbedded() {
    return this == ID;
  }

  public boolean isBasic() {
    return this == BASIC;
  }


  public Icon getIcon() {
    final boolean id = isIdAttribute();
    if (getRelationshipType() != null) {
      return id ? JavaeeIcons.ID_RELATIONSHIP_ICON : JavaeeIcons.RELATIONSHIP_ICON;
    }
    return id ? JavaeeIcons.ID_ATTRIBUTE_ICON : JavaeeIcons.ATTRIBUTE_ICON;

  }

  public String toString() {
    return "["+getTypeName()+"]";
  }

  public PsiType getDefaultPsiType(final PersistentAttribute attribute) {
    final PsiType psiType = getDefaultElementPsiType(attribute);
    if (isContainer()) {
      try {
        return JavaContainerType.COLLECTION.createCollectionType(attribute.getIdentifyingPsiElement(), psiType, null);
      }
      catch (IncorrectOperationException e) {
        throw new AssertionError(e);
      }
    }
    else return psiType;
  }

  public PsiType getDefaultElementPsiType(final PersistentAttribute attribute) {
    final PsiManager psiManager = attribute.getPsiManager();
    PsiType psiType = null;
    if (this == TRANSIENT) {
      // default
    }
    else if (attribute instanceof PersistentEmbeddedAttribute) {
      final PsiClass aClass = ((PersistentEmbeddedAttribute)attribute).getTargetEmbeddableClass().getValue();
      psiType = aClass == null ? PsiType.getJavaLangObject(psiManager, ProjectScope.getAllScope(psiManager.getProject())) : JavaPsiFacade
        .getInstance(psiManager.getProject()).getElementFactory().createType(aClass);
    }
    else if (attribute instanceof PersistentRelationshipAttribute) {
      final PersistentRelationshipAttribute relationAttributeBase = (PersistentRelationshipAttribute)attribute;
      final PsiClass aClass = relationAttributeBase.getTargetEntityClass().getValue();
      if (aClass != null) {
        psiType = JavaPsiFacade.getInstance(psiManager.getProject()).getElementFactory().createType(aClass);
      }
    }
    if (psiType == null) {
      psiType = PsiType.getJavaLangObject(psiManager, ProjectScope.getAllScope(psiManager.getProject()));
    }
    return psiType;
  }
}
