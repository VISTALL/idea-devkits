/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.model.common.persistence.mapping;

/**
 * @author Gregory.Shrago
 */
public class AttributeVisitorAdapter implements AttributeVisitor {

  public boolean visitAttributeBase(AttributeBase attributeBase) {
    return true;
  }

  public boolean visitAttributeWithColumn(AttributeWithColumn attribute) {
    return visitAttributeBase(attribute);
  }

  public boolean visitRelationAttribute(RelationAttributeBase relationAttributeBase) {
    return visitAttributeBase(relationAttributeBase);
  }

  public boolean visitId(Id id) {
    return visitAttributeWithColumn(id);
  }

  public boolean visitEmbeddedId(EmbeddedId embeddedId) {
    return visitAttributeBase(embeddedId);
  }

  public boolean visitBasic(Basic basic) {
    return visitAttributeWithColumn(basic);
  }

  public boolean visitEmbedded(Embedded embedded) {
    return visitAttributeBase(embedded);
  }

  public boolean visitVersion(Version version) {
    return visitAttributeWithColumn(version);
  }

  public boolean visitManyToOne(ManyToOne manyToOne) {
    return visitRelationAttribute(manyToOne);
  }

  public boolean visitOneToMany(OneToMany oneToMany) {
    return visitRelationAttribute(oneToMany);
  }

  public boolean visitOneToOne(OneToOne oneToOne) {
    return visitRelationAttribute(oneToOne);
  }

  public boolean visitManyToMany(ManyToMany manyToMany) {
    return visitRelationAttribute(manyToMany);
  }

  public boolean visitOtherAttribute(final AttributeBase attribute, final AttributeType type) {
    return visitAttributeBase(attribute);
  }

  public boolean visitTransient(Transient aTransient) {
    return visitAttributeBase(aTransient);
  }

}
