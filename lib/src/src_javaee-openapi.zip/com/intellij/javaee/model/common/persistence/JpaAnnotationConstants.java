/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.model.common.persistence;

import org.jetbrains.annotations.NonNls;

public interface JpaAnnotationConstants {
  @NonNls String VALUE_PARAM = "value";
  @NonNls String NAME_PARAM = "name";
  String EMBEDDABLE_ANNO = "javax.persistence.Embeddable";
  String ENTITY_ANNO = "javax.persistence.Entity";
  String ENTITY_MANAGER_CLASS = "javax.persistence.EntityManager";
  String QUERY_CLASS = "javax.persistence.Query";
  String MAPPED_SUPERCLASS_ANNO = "javax.persistence.MappedSuperclass";
  String POST_LOAD_ANNO = "javax.persistence.PostLoad";
  String POST_PERSIST_ANNO = "javax.persistence.PostPersist";
  String POST_REMOVE_ANNO = "javax.persistence.PostRemove";
  String POST_UPDATE_ANNO = "javax.persistence.PostUpdate";
  String PRE_PERSIST_ANNO = "javax.persistence.PrePersist";
  String PRE_REMOVE_ANNO = "javax.persistence.PreRemove";
  String PRE_UPDATE_ANNO = "javax.persistence.PreUpdate";
  String EMBEDDED_ID_ANNO = "javax.persistence.EmbeddedId";
  String COLUMN_ANNO = "javax.persistence.Column";
  String ATTRIBUTE_OVERRIDE_ANNO = "javax.persistence.AttributeOverride";
  String ATTRIBUTE_OVERRIDES_ANNO = "javax.persistence.AttributeOverrides";
  String ASSOCIATION_OVERRIDE_ANNO = "javax.persistence.AssociationOverride";
  String ASSOCIATION_OVERRIDES_ANNO = "javax.persistence.AssociationOverrides";
  @NonNls String ASSOCIATION_OVERRIDE_JOIN_COLUMNS_PARAM = "joinColumns";
  @NonNls String COLUMN_PARAM = "column";
  @NonNls String COLUMN_UNIQUE_PARAM = "unique";
  @NonNls String NULLABLE_PARAM = "nullable";
  @NonNls String INSERTABLE_PARAM = "insertable";
  @NonNls String UPDATABLE_PARAM = "updatable";
  @NonNls String COLUMN_DEFINITION_PARAM = "columnDefinition";
  @NonNls String TABLE_PARAM = "table";
  @NonNls String LENGTH_PARAM = "length";
  @NonNls String PRECISION_PARAM = "precision";
  @NonNls String SCALE_PARAM = "scale";
  String GENERATION_TYPE_PREFIX = "javax.persistence.GenerationType" + ".";
  @NonNls String ID_STRATEGY_PARAM = "strategy";
  String ID_ANNO = "javax.persistence.Id";
  String ID_CLASS_ANNO = "javax.persistence.IdClass";
  @NonNls String ID_GENERATOR_PARAM = "generator";
  String BASIC_ANNO = "javax.persistence.Basic";
  String TEMPORAL_TYPE_PREFIX = "javax.persistence.TemporalType" + ".";
  String EMBEDDED_ANNO = "javax.persistence.Embedded";
  String LOB_ANNO = "javax.persistence.Lob";
  @NonNls String MAPPING_FETCH_PARAM = "fetch";
  @NonNls String MAPPING_OPTIONAL_PARAM = "optional";
  String FETCH_TYPE_PREFIX = "javax.persistence.FetchType" + ".";
  String VERSION_ANNO = "javax.persistence.Version";
  String TRANSIENT_ANNO = "javax.persistence.Transient";
  String ENUMERATED_ANNO = "javax.persistence.Enumerated";
  String ENUM_TYPE_PREFIX = "javax.persistence.EnumType" + ".";
  String MAP_KEY_ANNO = "javax.persistence.MapKey";
  String ORDER_BY_ANNO = "javax.persistence.OrderBy";
  String TEMPORAL_ANNO = "javax.persistence.Temporal";
  String MANY_TO_ONE_ANNO = "javax.persistence.ManyToOne";
  String MANY_TO_MANY_ANNO = "javax.persistence.ManyToMany";
  String ONE_TO_ONE_ANNO = "javax.persistence.OneToOne";
  String ONE_TO_MANY_ANNO = "javax.persistence.OneToMany";
  String CASCADE_TYPE_PREFIX = "javax.persistence.CascadeType" + ".";
  @NonNls String MAPPING_CASCADE_PARAM = "cascade";
  @NonNls String MAPPING_TARGET_ENTITY_PARAM = "targetEntity";
  @NonNls String MAPPING_MAPPED_BY_PARAM = "mappedBy";
  String JOIN_COLUMNS_ANNO = "javax.persistence.JoinColumns";
  String JOIN_TABLE_ANNO = "javax.persistence.JoinTable";
  @NonNls String CATALOG_PARAM = "catalog";
  @NonNls String SCHEMA_PARAM = "schema";
  @NonNls String TABLE_JOIN_COLUMNS_PARAM = "joinColumns";
  @NonNls String TABLE_INVERSE_JOIN_COLUMNS_PARAM = "inverseJoinColumns";
  @NonNls String UNIQUE_CONSTRAINTS_PARAM = "uniqueConstraints";
  String UNIQUE_CONSTRAINT_ANNO = "javax.persistence.UniqueConstraint";
  @NonNls String TABLE_PK_JOIN_COLUMNS_PARAM = "pkJoinColumns";
  @NonNls String REFERENCED_COLUMN_NAME = "referencedColumnName";
  String PRIMARY_KEY_JOIN_COLUMN_ANNO = "javax.persistence.PrimaryKeyJoinColumn";
  @NonNls String COLUMN_NAMES_PARAM = "columnNames";
  String EXCLUDE_DEFAULT_LISTENERS_ANNO = "javax.persistence.ExcludeDefaultListeners";
  String EXCLUDE_SUPERCLASS_LISTENERS_ANNO = "javax.persistence.ExcludeSuperclassListeners";
  String ENTITY_LISTENERS_ANNO = "javax.persistence.EntityListeners";
  String JOIN_COLUMN_ANNO = "javax.persistence.JoinColumn";
  String SECONDARY_TABLE_ANNO = "javax.persistence.SecondaryTable";
  String TABLE_ANNO = "javax.persistence.Table";
  String SECONDARY_TABLES_ANNO = "javax.persistence.SecondaryTables";
  String PRIMARY_KEY_JOIN_COLUMNS_ANNO = "javax.persistence.PrimaryKeyJoinColumns";
  String INHERITANCE_ANNO = "javax.persistence.Inheritance";
  @NonNls String INHERITANCE_STRATEGY_PARAM = "strategy";
  @NonNls String INHERITANCE_TYPE_PREFIX = "javax.persistence.InheritanceType.";
  String DISCRIMINATOR_VALUE_ANNO = "javax.persistence.DiscriminatorValue";
  String DISCRIMINATOR_COLUMN_ANNO = "javax.persistence.DiscriminatorColumn";
  @NonNls String DISCRIMINATOR_TYPE_PARAM = "discriminatorType";
  String DISCRIMINATOR_TYPE_PREFIX = "javax.persistence.DiscriminatorType" + ".";
  String SEQUENCE_GENERATOR_ANNO = "javax.persistence.SequenceGenerator";
  @NonNls String SEQUENCE_NAME_PARAM = "sequenceName";
  @NonNls String INITIAL_VALUE_PARAM = "initialValue";
  @NonNls String ALLOCATION_SIZE_PARAM = "allocationSize";
  String TABLE_GENERATOR_ANNO = "javax.persistence.TableGenerator";
  @NonNls String PK_COLUMN_NAME_PARAM = "pkColumnName";
  @NonNls String VALUE_COLUMN_NAME_PARAM = "valueColumnName";
  @NonNls String PK_COLUMN_VALUE_PARAM = "pkColumnValue";
  String GENERATED_VALUE_ANNO = "javax.persistence.GeneratedValue";
  String NAMED_QUERIES_ANNO = "javax.persistence.NamedQueries";
  String QUERY_HINT_ANNO = "javax.persistence.QueryHint";
  String NAMED_QUERY_ANNO = "javax.persistence.NamedQuery";
  @NonNls String QUERY_PARAM = "query";
  @NonNls String QUERY_HINTS_PARAM = "hints";
  String NAMED_NATIVE_QUERY_ANNO = "javax.persistence.NamedNativeQuery";
  String NAMED_NATIVE_QUERIES_ANNO = "javax.persistence.NamedNativeQueries";
  @NonNls String QUERY_RESULT_CLASS_PARAM = "resultClass";
  @NonNls String QUERY_RESULT_SET_MAPPING_PARAM = "resultSetMapping";
  String FIELD_RESULT_ANNO = "javax.persistence.FieldResult";
  String ENTITY_RESULT_ANNO = "javax.persistence.EntityResult";
  String SQL_RESULT_SET_MAPPING_ANNO = "javax.persistence.SqlResultSetMapping";
  String SQL_RESULT_SET_MAPPINGS_ANNO = "javax.persistence.SqlResultSetMappings";
  @NonNls String COLUMNS_PARAM = "columns";
  @NonNls String ENTITIES_PARAM = "entities";
  @NonNls String RESULT_DISCRIMINATOR_COLUMN_PARAM = "discriminatorColumn";
  @NonNls String RESULT_FIELDS_PARAM = "fields";
  @NonNls String RESULT_ENTITY_CLASS_PARAM = "entityClass";
}
