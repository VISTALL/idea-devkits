/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.model.common.ejb;

import com.intellij.util.xml.NamedEnum;
import com.intellij.javaee.model.common.JavaeeCommonConstants;
import org.jetbrains.annotations.NonNls;

import java.util.Arrays;
import java.util.List;

/**
 * @author peter
 */
public enum EjbDescriptorVersion implements NamedEnum {
  //todo[peter,greg] maybe 1.0 should be added?
  EJB_VERSION_1_X("1.x", JavaeeCommonConstants.EJB_JAR_1_0_DTD, JavaeeCommonConstants.EJB_JAR_1_1_DTD, JavaeeCommonConstants.EJB_1_0_PUBLIC_ID, JavaeeCommonConstants.EJB_1_1_PUBLIC_ID),
  EJB_VERSION_2_0("2.0", JavaeeCommonConstants.EJB_JAR_2_0_DTD, JavaeeCommonConstants.EJB_2_0_PUBLIC_ID),
  EJB_VERSION_2_1("2.1", JavaeeCommonConstants.J2EE_NAMESPACE),
  EJB_VERSION_3_0("3.0", JavaeeCommonConstants.JAVAEE_NAMESPACE);

  private final String myName;
  private final String[] myAllowedNamespaces;

  EjbDescriptorVersion(@NonNls final String name, @NonNls String... allowedNamespaces) {
    myName = name;
    myAllowedNamespaces = allowedNamespaces;
 }

  public final String getValue() {
    return myName;
  }

  public List<String> getAllowedNamespaces() {
    return Arrays.asList(myAllowedNamespaces);
  }

  public static EjbDescriptorVersion getEjbDescriptorVersion(String value) {
    for (EjbDescriptorVersion version : EjbDescriptorVersion.values()) {
      if (version.getValue().equals(value)) {
        return version;
      }
    }
    assert false: value;
    return null;
  }
}
