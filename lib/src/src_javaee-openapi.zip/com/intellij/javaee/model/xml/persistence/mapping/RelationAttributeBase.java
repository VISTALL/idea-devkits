/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.converters.AttributeConverter;
import com.intellij.javaee.model.xml.converters.ClassConverter;
import com.intellij.persistence.model.PersistentAttribute;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.Convert;
import com.intellij.util.xml.GenericAttributeValue;
import com.intellij.util.xml.GenericDomValue;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: greg
 * Date: 23.12.2005
 * Time: 17:20:04
 */
public interface RelationAttributeBase extends AttributeBase, com.intellij.javaee.model.common.persistence.mapping.RelationAttributeBase {

  @Convert(ClassConverter.class)
  GenericAttributeValue<PsiClass> getTargetEntityClass();

  GenericAttributeValue<FetchType> getFetch();

  CascadeType getCascade();

  JoinTable getJoinTable();


  interface AnyToOneBase extends RelationAttributeBase, com.intellij.javaee.model.common.persistence.mapping.RelationAttributeBase.AnyToOneBase {

    GenericAttributeValue<Boolean> getOptional();

  }

  interface NonManyToOneBase extends RelationAttributeBase, com.intellij.javaee.model.common.persistence.mapping.RelationAttributeBase.NonManyToOneBase {

    @Convert(AttributeConverter.class)
    GenericAttributeValue<PersistentAttribute> getMappedBy();

  }

  interface NonManyToManyBase extends RelationAttributeBase, com.intellij.javaee.model.common.persistence.mapping.RelationAttributeBase.NonManyToManyBase {

    List<JoinColumn> getJoinColumns();

    JoinColumn addJoinColumn();

  }

  interface AnyToManyBase extends NonManyToOneBase, com.intellij.javaee.model.common.persistence.mapping.RelationAttributeBase.AnyToManyBase {

    GenericDomValue<String> getOrderBy();

    MapKey getMapKey();

  }

}
