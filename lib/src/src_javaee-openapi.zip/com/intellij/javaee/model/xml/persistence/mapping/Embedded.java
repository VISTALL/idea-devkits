/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.CommonDomModelElement;

import java.util.List;

/**
 * http://java.sun.com/xml/ns/persistence/orm:embedded interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:embedded documentation</h3>
 * @Target({METHOD, FIELD}) @Retention(RUNTIME)
 *         public @interface Embedded {}
 * </pre>
 */
public interface Embedded extends AttributeBase, CommonDomModelElement, com.intellij.javaee.model.common.persistence.mapping.Embedded {

	/**
	 * Returns the value of the name child.
	 * @return the value of the name child.
	 */
//	@NotNull
//	GenericAttributeValue<String> getName();


	/**
	 * Returns the list of attribute-override children.
	 * @return the list of attribute-override children.
	 */
	List<AttributeOverride> getAttributeOverrides();
	/**
	 * Adds new child to the list of attribute-override children.
	 * @return created child
	 */
	AttributeOverride addAttributeOverride();


}
