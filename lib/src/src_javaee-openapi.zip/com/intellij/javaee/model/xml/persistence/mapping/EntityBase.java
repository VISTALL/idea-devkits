/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.psi.PsiClass;
import com.intellij.util.xml.GenericAttributeValue;
import com.intellij.util.xml.GenericDomValue;

/**
 * Created by IntelliJ IDEA.
 * User: Gregory.Shrago
 * Date: 02.02.2006
 * Time: 21:51:22
 * To change this template use File | Settings | File Templates.
 */
public interface EntityBase extends PersistentObjectBase, EntityListenerMethodContainer, com.intellij.javaee.model.common.persistence.mapping.EntityBase {

  GenericAttributeValue<PsiClass> getClazz();

  GenericAttributeValue<AccessType> getAccess();

  IdClass getIdClass();

  GenericDomValue<Boolean> getExcludeDefaultListeners();

  GenericDomValue<Boolean> getExcludeSuperclassListeners();

  EntityListeners getEntityListeners();

  PrePersist getPrePersist();

  PostPersist getPostPersist();

  PreRemove getPreRemove();

  PostRemove getPostRemove();

  PreUpdate getPreUpdate();

  PostUpdate getPostUpdate();

  PostLoad getPostLoad();

  Attributes getAttributes();

}
