/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.util.xml.GenericAttributeValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://java.sun.com/xml/ns/persistence/orm:sql-result-set-mapping interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:sql-result-set-mapping documentation</h3>
 * @Target({TYPE}) @Retention(RUNTIME)
 *         public @interface SqlResultSetMapping {
 *           String name();
 *           EntityResult[] entities() default {};
 *           ColumnResult[] columns() default {};
 *         }
 * </pre>
 */
public interface SqlResultSetMapping extends CommonDomModelElement {

	/**
	 * Returns the value of the name child.
	 * @return the value of the name child.
	 */
	@NotNull
	GenericAttributeValue<String> getName();


	/**
	 * Returns the list of entity-result children.
	 * @return the list of entity-result children.
	 */
	List<EntityResult> getEntityResults();
	/**
	 * Adds new child to the list of entity-result children.
	 * @return created child
	 */
	EntityResult addEntityResult();


	/**
	 * Returns the list of column-result children.
	 * @return the list of column-result children.
	 */
	List<ColumnResult> getColumnResults();
	/**
	 * Adds new child to the list of column-result children.
	 * @return created child
	 */
	ColumnResult addColumnResult();


}
