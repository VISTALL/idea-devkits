/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.SubTag;

/**
 * http://java.sun.com/xml/ns/persistence/orm:persistence-unit-metadata interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:persistence-unit-metadata documentation</h3>
 * Metadata that applies to the persistence unit and not just to 
 *         the mapping file in which it is contained. 
 *         If the xml-mapping-metadata-complete element is specified then 
 *         the complete set of mapping metadata for the persistence unit 
 *         is contained in the XML mapping files for the persistence unit.
 * </pre>
 */
public interface PersistenceUnitMetadata extends CommonDomModelElement {

	/**
	 * Returns the value of the xml-mapping-metadata-complete child.
	 * @return the value of the xml-mapping-metadata-complete child.
	 */
	@SubTag (value = "xml-mapping-metadata-complete", indicator = true)
	GenericDomValue<Boolean> getXmlMappingMetadataComplete();


	/**
	 * Returns the value of the persistence-unit-defaults child.
	 * @return the value of the persistence-unit-defaults child.
	 */
	PersistenceUnitDefaults getPersistenceUnitDefaults();


}
