/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.javaee.model.JavaeePersistenceORMResolveConverters;
import com.intellij.util.xml.GenericAttributeValue;
import com.intellij.util.xml.Convert;
import com.intellij.util.xml.Attribute;

import java.util.List;

/**
 * http://java.sun.com/xml/ns/persistence/orm:table interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:table documentation</h3>
 * @Target({TYPE}) @Retention(RUNTIME)
 *         public @interface Table {
 *           String name() default "";
 *           String catalog() default "";
 *           String schema() default "";
 *           UniqueConstraint[] uniqueConstraints() default {};
 *         }
 * </pre>
 */
public interface Table extends CommonDomModelElement, com.intellij.javaee.model.common.persistence.mapping.Table {

	/**
	 * Returns the value of the name child.
	 * @return the value of the name child.
	 */
        @Attribute("name")
        @Convert(JavaeePersistenceORMResolveConverters.TableResolver.class)
        GenericAttributeValue<String> getTableName();


	/**
	 * Returns the value of the catalog child.
	 * @return the value of the catalog child.
	 */
        @Convert(JavaeePersistenceORMResolveConverters.CatalogResolver.class)
        GenericAttributeValue<String> getCatalog();


	/**
	 * Returns the value of the schema child.
	 * @return the value of the schema child.
	 */
        @Convert(JavaeePersistenceORMResolveConverters.SchemaResolver.class)
        GenericAttributeValue<String> getSchema();


	/**
	 * Returns the list of unique-constraint children.
	 * @return the list of unique-constraint children.
	 */
	List<UniqueConstraint> getUniqueConstraints();
	/**
	 * Adds new child to the list of unique-constraint children.
	 * @return created child
	 */
	UniqueConstraint addUniqueConstraint();


}
