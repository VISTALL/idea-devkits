/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.*;
import com.intellij.persistence.model.TableInfoProvider;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://java.sun.com/xml/ns/persistence/orm:entity interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:entity documentation</h3>
 * Defines the settings and mappings for an entity. Is allowed to be
 *         sparsely populated and used in conjunction with the annotations.
 *         Alternatively, the metadata-complete attribute can be used to 
 *         indicate that no annotations on the entity class (and its fields
 *         or properties) are to be processed. If this is the case then 
 *         the defaulting rules for the entity and its subelements will 
 *         be recursively applied.
 *         @Target(TYPE) @Retention(RUNTIME)
 *           public @interface Entity {
 *           String name() default "";
 *         }
 * </pre>
 */
public interface Entity extends EntityBase, CommonDomModelElement, com.intellij.javaee.model.common.persistence.mapping.Entity, TableInfoProvider {

	/**
	 * Returns the value of the name child.
	 * @return the value of the name child.
	 */
        @NameValue
        @Convert(EntityNameConverter.class)
        GenericAttributeValue<String> getName();


	/**
	 * Returns the value of the class child.
	 * @return the value of the class child.
	 */
	@com.intellij.util.xml.Attribute ("class")
	@NotNull
	GenericAttributeValue<PsiClass> getClazz();


	/**
	 * Returns the value of the access child.
	 * @return the value of the access child.
	 */
	GenericAttributeValue<AccessType> getAccess();


	/**
	 * Returns the value of the metadata-complete child.
	 * @return the value of the metadata-complete child.
	 */
	GenericAttributeValue<Boolean> getMetadataComplete();


	/**
	 * Returns the value of the description child.
	 * @return the value of the description child.
	 */
	GenericDomValue<String> getDescription();


	/**
	 * Returns the value of the table child.
	 * @return the value of the table child.
	 */
	Table getTable();


	/**
	 * Returns the list of secondary-table children.
	 * @return the list of secondary-table children.
	 */
	List<SecondaryTable> getSecondaryTables();
	/**
	 * Adds new child to the list of secondary-table children.
	 * @return created child
	 */
	SecondaryTable addSecondaryTable();


	/**
	 * Returns the list of primary-key-join-column children.
	 * @return the list of primary-key-join-column children.
	 */
	List<PrimaryKeyJoinColumn> getPrimaryKeyJoinColumns();
	/**
	 * Adds new child to the list of primary-key-join-column children.
	 * @return created child
	 */
	PrimaryKeyJoinColumn addPrimaryKeyJoinColumn();


	/**
	 * Returns the value of the id-class child.
	 * @return the value of the id-class child.
	 */
	IdClass getIdClass();


	/**
	 * Returns the value of the inheritance child.
	 * @return the value of the inheritance child.
	 */
	Inheritance getInheritance();


	/**
	 * Returns the value of the discriminator-value child.
	 * @return the value of the discriminator-value child.
	 */
	GenericDomValue<String> getDiscriminatorValue();


	/**
	 * Returns the value of the discriminator-column child.
	 * @return the value of the discriminator-column child.
	 */
	DiscriminatorColumn getDiscriminatorColumn();


	/**
	 * Returns the value of the sequence-generator child.
	 * @return the value of the sequence-generator child.
	 */
	SequenceGenerator getSequenceGenerator();


	/**
	 * Returns the value of the table-generator child.
	 * @return the value of the table-generator child.
	 */
	TableGenerator getTableGenerator();


	/**
	 * Returns the list of named-query children.
	 * @return the list of named-query children.
	 */
	List<NamedQuery> getNamedQueries();
	/**
	 * Adds new child to the list of named-query children.
	 * @return created child
	 */
	NamedQuery addNamedQuery();


	/**
	 * Returns the list of named-native-query children.
	 * @return the list of named-native-query children.
	 */
	List<NamedNativeQuery> getNamedNativeQueries();
	/**
	 * Adds new child to the list of named-native-query children.
	 * @return created child
	 */
	NamedNativeQuery addNamedNativeQuery();


	/**
	 * Returns the list of sql-result-set-mapping children.
	 * @return the list of sql-result-set-mapping children.
	 */
	List<SqlResultSetMapping> getSqlResultSetMappings();
	/**
	 * Adds new child to the list of sql-result-set-mapping children.
	 * @return created child
	 */
	SqlResultSetMapping addSqlResultSetMapping();


	/**
	 * Returns the value of the exclude-default-listeners child.
	 * @return the value of the exclude-default-listeners child.
	 */
	@SubTag (value = "exclude-default-listeners", indicator = true)
	GenericDomValue<Boolean> getExcludeDefaultListeners();


	/**
	 * Returns the value of the exclude-superclass-listeners child.
	 * @return the value of the exclude-superclass-listeners child.
	 */
	@SubTag (value = "exclude-superclass-listeners", indicator = true)
	GenericDomValue<Boolean> getExcludeSuperclassListeners();


	/**
	 * Returns the value of the entity-listeners child.
	 * @return the value of the entity-listeners child.
	 */
	EntityListeners getEntityListeners();


	/**
	 * Returns the value of the pre-persist child.
	 * @return the value of the pre-persist child.
	 */
	PrePersist getPrePersist();


	/**
	 * Returns the value of the post-persist child.
	 * @return the value of the post-persist child.
	 */
	PostPersist getPostPersist();


	/**
	 * Returns the value of the pre-remove child.
	 * @return the value of the pre-remove child.
	 */
	PreRemove getPreRemove();


	/**
	 * Returns the value of the post-remove child.
	 * @return the value of the post-remove child.
	 */
	PostRemove getPostRemove();


	/**
	 * Returns the value of the pre-update child.
	 * @return the value of the pre-update child.
	 */
	PreUpdate getPreUpdate();


	/**
	 * Returns the value of the post-update child.
	 * @return the value of the post-update child.
	 */
	PostUpdate getPostUpdate();


	/**
	 * Returns the value of the post-load child.
	 * @return the value of the post-load child.
	 */
	PostLoad getPostLoad();


	/**
	 * Returns the list of attribute-override children.
	 * @return the list of attribute-override children.
	 */
	List<AttributeOverride> getAttributeOverrides();
	/**
	 * Adds new child to the list of attribute-override children.
	 * @return created child
	 */
	AttributeOverride addAttributeOverride();


	/**
	 * Returns the list of association-override children.
	 * @return the list of association-override children.
	 */
	List<AssociationOverride> getAssociationOverrides();
	/**
	 * Adds new child to the list of association-override children.
	 * @return created child
	 */
	AssociationOverride addAssociationOverride();


	/**
	 * Returns the value of the attributes child.
	 * @return the value of the attributes child.
	 */
	Attributes getAttributes();


}
