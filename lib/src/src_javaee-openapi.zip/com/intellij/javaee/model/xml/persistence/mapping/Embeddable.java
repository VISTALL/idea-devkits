/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.GenericAttributeValue;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.Required;

/**
 * http://java.sun.com/xml/ns/persistence/orm:embeddable interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:embeddable documentation</h3>
 * Defines the settings and mappings for embeddable objects. Is 
 *         allowed to be sparsely populated and used in conjunction with 
 *         the annotations. Alternatively, the metadata-complete attribute 
 *         can be used to indicate that no annotations are to be processed 
 *         in the class. If this is the case then the defaulting rules will 
 *         be recursively applied.
 *         @Target({TYPE}) @Retention(RUNTIME)
 *         public @interface Embeddable {}
 * </pre>
 */
public interface Embeddable extends PersistentObjectBase, CommonDomModelElement, com.intellij.javaee.model.common.persistence.mapping.Embeddable {

	/**
	 * Returns the value of the class child.
	 * @return the value of the class child.
	 */
	@com.intellij.util.xml.Attribute ("class")
	@Required
        GenericAttributeValue<PsiClass> getClazz();


	/**
	 * Returns the value of the access child.
	 * @return the value of the access child.
	 */
	GenericAttributeValue<AccessType> getAccess();


	/**
	 * Returns the value of the metadata-complete child.
	 * @return the value of the metadata-complete child.
	 */
	GenericAttributeValue<Boolean> getMetadataComplete();


	/**
	 * Returns the value of the description child.
	 * @return the value of the description child.
	 */
	GenericDomValue<String> getDescription();


	/**
	 * Returns the value of the attributes child.
	 * @return the value of the attributes child.
	 */
	EmbeddableAttributes getAttributes();


}
