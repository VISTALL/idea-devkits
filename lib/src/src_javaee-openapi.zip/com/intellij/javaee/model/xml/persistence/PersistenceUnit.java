/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Mon Mar 20 14:21:22 MSK 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence

package com.intellij.javaee.model.xml.persistence;

import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.javaee.model.xml.converters.PersistentUnitFileConverter;
import com.intellij.javaee.model.xml.converters.PersistentUnitJarFileConverter;
import com.intellij.javaee.model.common.persistence.JavaeePersistenceConstants;
import com.intellij.persistence.model.PersistencePackage;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiFile;
import com.intellij.util.xml.*;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://java.sun.com/xml/ns/persistence:persistence-unitElemType interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence:persistence-unitElemType documentation</h3>
 * Configuration of a persistence unit.
 * </pre>
 */
public interface PersistenceUnit extends CommonDomModelElement, PersistencePackage {

        PersistenceUnit[] EMPTY_ARRAY = new PersistenceUnit[0];

        /**
	 * Returns the value of the name child.
	 * <pre>
	 * <h3>Attribute null:name documentation</h3>
	 * Name used in code to reference this persistence unit.
	 * </pre>
	 * @return the value of the name child.
	 */
	@NotNull
        @NameValue
        GenericAttributeValue<String> getName();


	/**
	 * Returns the value of the transaction-type child.
	 * <pre>
	 * <h3>Attribute null:transaction-type documentation</h3>
	 * Type of transactions used by EntityManagers from this 
	 *                   persistence unit.
	 * </pre>
	 * @return the value of the transaction-type child.
	 */
	GenericAttributeValue<PersistenceUnitTransactionType> getTransactionType();


	/**
	 * Returns the value of the description child.
	 * <pre>
	 * <h3>Element http://java.sun.com/xml/ns/persistence:description documentation</h3>
	 * Textual description of this persistence unit.
	 * </pre>
	 * @return the value of the description child.
	 */
	GenericDomValue<String> getDescription();


	/**
	 * Returns the value of the provider child.
	 * <pre>
	 * <h3>Element http://java.sun.com/xml/ns/persistence:provider documentation</h3>
	 * Provider class that supplies EntityManagers for this 
	 *                     persistence unit.
	 * </pre>
	 * @return the value of the provider child.
	 */
        @ExtendClass(JavaeePersistenceConstants.PERSISTENCE_PROVIDER_CLASS)
        GenericDomValue<PsiClass> getProvider();


	/**
	 * Returns the value of the jta-data-source child.
	 * <pre>
	 * <h3>Element http://java.sun.com/xml/ns/persistence:jta-data-source documentation</h3>
	 * The container-specific name of the JTA datasource to use.
	 * </pre>
	 * @return the value of the jta-data-source child.
	 */
	GenericDomValue<String> getJtaDataSource();


	/**
	 * Returns the value of the non-jta-data-source child.
	 * <pre>
	 * <h3>Element http://java.sun.com/xml/ns/persistence:non-jta-data-source documentation</h3>
	 * The container-specific name of a non-JTA datasource to use.
	 * </pre>
	 * @return the value of the non-jta-data-source child.
	 */
	GenericDomValue<String> getNonJtaDataSource();


	/**
	 * Returns the list of mapping-file children.
	 * <pre>
	 * <h3>Element http://java.sun.com/xml/ns/persistence:mapping-file documentation</h3>
	 * File containing mapping information. Loaded as a resource 
	 *                     by the persistence provider.
	 * </pre>
	 * @return the list of mapping-file children.
	 */
        @Convert(PersistentUnitFileConverter.class)
        List<GenericDomValue<PsiFile>> getMappingFiles();
	/**
	 * Adds new child to the list of mapping-file children.
	 * @return created child
	 */
	GenericDomValue<PsiFile> addMappingFile();


	/**
	 * Returns the list of jar-file children.
	 * <pre>
	 * <h3>Element http://java.sun.com/xml/ns/persistence:jar-file documentation</h3>
	 * Jar file that should be scanned for entities. 
	 *                     Not applicable to Java SE persistence units.
	 * </pre>
	 * @return the list of jar-file children.
	 */
        @Convert(PersistentUnitJarFileConverter.class)
        List<GenericDomValue<PsiFile>> getJarFiles();
	/**
	 * Adds new child to the list of jar-file children.
	 * @return created child
	 */
	GenericDomValue<PsiFile> addJarFile();


	/**
	 * Returns the list of class children.
	 * <pre>
	 * <h3>Element http://java.sun.com/xml/ns/persistence:class documentation</h3>
	 * Class to scan for annotations.  It should be annotated 
	 *                     with either @Entity, @Embeddable or @MappedSuperclass.
	 * </pre>
	 * @return the list of class children.
	 */
	List<GenericDomValue<PsiClass>> getClasses();
	/**
	 * Adds new child to the list of class children.
	 * @return created child
	 */
	GenericDomValue<PsiClass> addClass();


	/**
	 * Returns the value of the exclude-unlisted-classes child.
	 * <pre>
	 * <h3>Element http://java.sun.com/xml/ns/persistence:exclude-unlisted-classes documentation</h3>
	 * When set to true then only listed classes and jars will 
	 *                     be scanned for persistent classes, otherwise the enclosing 
	 *                     jar or directory will also be scanned. Not applicable to 
	 *                     Java SE persistence units.
	 * </pre>
	 * @return the value of the exclude-unlisted-classes child.
	 */
	GenericDomValue<Boolean> getExcludeUnlistedClasses();


	/**
	 * Returns the value of the properties child.
	 * <pre>
	 * <h3>Element http://java.sun.com/xml/ns/persistence:properties documentation</h3>
	 * A list of vendor-specific properties.
	 * </pre>
	 * @return the value of the properties child.
	 */
	Properties getProperties();


}
