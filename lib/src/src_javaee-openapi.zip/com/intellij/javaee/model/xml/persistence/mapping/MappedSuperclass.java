/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.GenericAttributeValue;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.SubTag;
import org.jetbrains.annotations.NotNull;

/**
 * http://java.sun.com/xml/ns/persistence/orm:mapped-superclass interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:mapped-superclass documentation</h3>
 * Defines the settings and mappings for a mapped superclass. Is 
 *         allowed to be sparsely populated and used in conjunction with 
 *         the annotations. Alternatively, the metadata-complete attribute 
 *         can be used to indicate that no annotations are to be processed 
 *         If this is the case then the defaulting rules will be recursively 
 *         applied.
 *         @Target(TYPE) @Retention(RUNTIME)
 *         public @interface MappedSuperclass{}
 * </pre>
 */
public interface MappedSuperclass extends EntityBase, CommonDomModelElement, com.intellij.javaee.model.common.persistence.mapping.MappedSuperclass {

	/**
	 * Returns the value of the class child.
	 * @return the value of the class child.
	 */
	@com.intellij.util.xml.Attribute ("class")
	@NotNull
	GenericAttributeValue<PsiClass> getClazz();


	/**
	 * Returns the value of the access child.
	 * @return the value of the access child.
	 */
	GenericAttributeValue<AccessType> getAccess();


	/**
	 * Returns the value of the metadata-complete child.
	 * @return the value of the metadata-complete child.
	 */
	GenericAttributeValue<Boolean> getMetadataComplete();


	/**
	 * Returns the value of the description child.
	 * @return the value of the description child.
	 */
	GenericDomValue<String> getDescription();


	/**
	 * Returns the value of the id-class child.
	 * @return the value of the id-class child.
	 */
	IdClass getIdClass();


	/**
	 * Returns the value of the exclude-default-listeners child.
	 * @return the value of the exclude-default-listeners child.
	 */
	@SubTag (value = "exclude-default-listeners", indicator = true)
	GenericDomValue<Boolean> getExcludeDefaultListeners();


	/**
	 * Returns the value of the exclude-superclass-listeners child.
	 * @return the value of the exclude-superclass-listeners child.
	 */
	@SubTag (value = "exclude-superclass-listeners", indicator = true)
	GenericDomValue<Boolean> getExcludeSuperclassListeners();


	/**
	 * Returns the value of the entity-listeners child.
	 * @return the value of the entity-listeners child.
	 */
	EntityListeners getEntityListeners();


	/**
	 * Returns the value of the pre-persist child.
	 * @return the value of the pre-persist child.
	 */
	PrePersist getPrePersist();


	/**
	 * Returns the value of the post-persist child.
	 * @return the value of the post-persist child.
	 */
	PostPersist getPostPersist();


	/**
	 * Returns the value of the pre-remove child.
	 * @return the value of the pre-remove child.
	 */
	PreRemove getPreRemove();


	/**
	 * Returns the value of the post-remove child.
	 * @return the value of the post-remove child.
	 */
	PostRemove getPostRemove();


	/**
	 * Returns the value of the pre-update child.
	 * @return the value of the pre-update child.
	 */
	PreUpdate getPreUpdate();


	/**
	 * Returns the value of the post-update child.
	 * @return the value of the post-update child.
	 */
	PostUpdate getPostUpdate();


	/**
	 * Returns the value of the post-load child.
	 * @return the value of the post-load child.
	 */
	PostLoad getPostLoad();


	/**
	 * Returns the value of the attributes child.
	 * @return the value of the attributes child.
	 */
	Attributes getAttributes();


}
