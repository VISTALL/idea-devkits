/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.javaee.model.JavaeePersistenceORMResolveConverters;
import com.intellij.util.xml.GenericAttributeValue;
import com.intellij.util.xml.Convert;
import com.intellij.util.xml.Attribute;
import com.intellij.persistence.model.TableInfoProvider;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://java.sun.com/xml/ns/persistence/orm:table-generator interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:table-generator documentation</h3>
 * @Target({TYPE, METHOD, FIELD}) @Retention(RUNTIME)
 *         public @interface TableGenerator {
 *           String name();
 *           String table() default "";
 *           String catalog() default "";
 *           String schema() default "";
 *           String pkColumnName() default "";
 *           String valueColumnName() default "";
 *           String pkColumnValue() default "";
 *           int initialValue() default 0;
 *           int allocationSize() default 50;
 *           UniqueConstraint[] uniqueConstraints() default {};
 *         }
 * </pre>
 */
public interface TableGenerator extends CommonDomModelElement, TableInfoProvider {

	/**
	 * Returns the value of the name child.
	 * @return the value of the name child.
	 */
	@NotNull
	GenericAttributeValue<String> getName();


	/**
	 * Returns the value of the table child.
	 * @return the value of the table child.
	 */
        @Attribute("table")
        @Convert(JavaeePersistenceORMResolveConverters.TableResolver.class)
        GenericAttributeValue<String> getTableName();


	/**
	 * Returns the value of the catalog child.
	 * @return the value of the catalog child.
	 */
        @Convert(JavaeePersistenceORMResolveConverters.CatalogResolver.class)
        GenericAttributeValue<String> getCatalog();


	/**
	 * Returns the value of the schema child.
	 * @return the value of the schema child.
	 */
        @Convert(JavaeePersistenceORMResolveConverters.SchemaResolver.class)
        GenericAttributeValue<String> getSchema();


	/**
	 * Returns the value of the pk-column-name child.
	 * @return the value of the pk-column-name child.
	 */
        @Convert(JavaeePersistenceORMResolveConverters.ColumnResolver.class)
        GenericAttributeValue<String> getPkColumnName();


	/**
	 * Returns the value of the value-column-name child.
	 * @return the value of the value-column-name child.
	 */
        @Convert(JavaeePersistenceORMResolveConverters.ColumnResolver.class)
        GenericAttributeValue<String> getValueColumnName();


	/**
	 * Returns the value of the pk-column-value child.
	 * @return the value of the pk-column-value child.
	 */
	GenericAttributeValue<String> getPkColumnValue();


	/**
	 * Returns the value of the initial-value child.
	 * @return the value of the initial-value child.
	 */
	GenericAttributeValue<Integer> getInitialValue();


	/**
	 * Returns the value of the allocation-size child.
	 * @return the value of the allocation-size child.
	 */
	GenericAttributeValue<Integer> getAllocationSize();


	/**
	 * Returns the list of unique-constraint children.
	 * @return the list of unique-constraint children.
	 */
	List<UniqueConstraint> getUniqueConstraints();
	/**
	 * Adds new child to the list of unique-constraint children.
	 * @return created child
	 */
	UniqueConstraint addUniqueConstraint();


}
