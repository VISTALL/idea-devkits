/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.javaee.model.JavaeePersistenceORMResolveConverters;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.SubTag;
import com.intellij.util.xml.Convert;

/**
 * http://java.sun.com/xml/ns/persistence/orm:persistence-unit-defaults interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:persistence-unit-defaults documentation</h3>
 * These defaults are applied to the persistence unit as a whole 
 *         unless they are overridden by local annotation or XML 
 *         element settings. 
 *         
 *         schema - Used as the schema for all tables or secondary tables
 *             that apply to the persistence unit
 *         catalog - Used as the catalog for all tables or secondary tables
 *             that apply to the persistence unit
 *         access - Used as the access type for all managed classes in
 *             the persistence unit
 *         cascade-persist - Adds cascade-persist to the set of cascade options
 *             in entity relationships of the persistence unit
 *         entity-listeners - List of default entity listeners to be invoked 
 *             on each entity in the persistence unit.
 * </pre>
 */
public interface PersistenceUnitDefaults extends CommonDomModelElement {

	/**
	 * Returns the value of the schema child.
	 * @return the value of the schema child.
	 */
        @Convert(JavaeePersistenceORMResolveConverters.SchemaResolver.class)
        GenericDomValue<String> getSchema();


	/**
	 * Returns the value of the catalog child.
	 * @return the value of the catalog child.
	 */
        @Convert(JavaeePersistenceORMResolveConverters.CatalogResolver.class)
        GenericDomValue<String> getCatalog();


	/**
	 * Returns the value of the access child.
	 * @return the value of the access child.
	 */
	GenericDomValue<AccessType> getAccess();


	/**
	 * Returns the value of the cascade-persist child.
	 * @return the value of the cascade-persist child.
	 */
	@SubTag (value = "cascade-persist", indicator = true)
	GenericDomValue<Boolean> getCascadePersist();


	/**
	 * Returns the value of the entity-listeners child.
	 * @return the value of the entity-listeners child.
	 */
	EntityListeners getEntityListeners();


}
