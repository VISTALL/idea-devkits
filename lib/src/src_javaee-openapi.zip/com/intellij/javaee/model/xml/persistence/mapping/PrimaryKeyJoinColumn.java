/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.JavaeePersistenceORMResolveConverters;
import com.intellij.javaee.model.common.persistence.mapping.JoinColumnBase;
import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.util.xml.Convert;
import com.intellij.util.xml.GenericAttributeValue;

/**
 * http://java.sun.com/xml/ns/persistence/orm:primary-key-join-column interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:primary-key-join-column documentation</h3>
 * @Target({TYPE, METHOD, FIELD}) @Retention(RUNTIME)
 *         public @interface PrimaryKeyJoinColumn {
 *           String name() default "";
 *           String referencedColumnName() default "";
 *           String columnDefinition() default "";
 *         }
 * </pre>
 */
public interface PrimaryKeyJoinColumn extends CommonDomModelElement, JoinColumnBase {

	/**
	 * Returns the value of the name child.
	 * @return the value of the name child.
	 */
        @Convert(JavaeePersistenceORMResolveConverters.ColumnResolver.class)
        GenericAttributeValue<String> getName();


	/**
	 * Returns the value of the referenced-column-name child.
	 * @return the value of the referenced-column-name child.
	 */
        @Convert(JavaeePersistenceORMResolveConverters.ColumnResolver.class)
        GenericAttributeValue<String> getReferencedColumnName();


	/**
	 * Returns the value of the column-definition child.
	 * @return the value of the column-definition child.
	 */
	GenericAttributeValue<String> getColumnDefinition();


}
