/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.util.xml.GenericAttributeValue;

/**
 * http://java.sun.com/xml/ns/persistence/orm:column interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:column documentation</h3>
 * @Target({METHOD, FIELD}) @Retention(RUNTIME)
 *         public @interface Column {
 *           String name() default "";
 *           boolean unique() default false;
 *           boolean nullable() default true;
 *           boolean insertable() default true;
 *           boolean updatable() default true;
 *           String columnDefinition() default "";
 *           String table() default "";
 *           int length() default 255;
 *           int precision() default 0; // decimal precision
 *           int scale() default 0; // decimal scale
 *         }
 * </pre>
 */
public interface Column extends CommonDomModelElement, ColumnBase {

	/**
	 * Returns the value of the name child.
	 * @return the value of the name child.
	 */
	GenericAttributeValue<String> getName();


	/**
	 * Returns the value of the unique child.
	 * @return the value of the unique child.
	 */
	GenericAttributeValue<Boolean> getUnique();


	/**
	 * Returns the value of the nullable child.
	 * @return the value of the nullable child.
	 */
	GenericAttributeValue<Boolean> getNullable();


	/**
	 * Returns the value of the insertable child.
	 * @return the value of the insertable child.
	 */
	GenericAttributeValue<Boolean> getInsertable();


	/**
	 * Returns the value of the updatable child.
	 * @return the value of the updatable child.
	 */
	GenericAttributeValue<Boolean> getUpdatable();


	/**
	 * Returns the value of the column-definition child.
	 * @return the value of the column-definition child.
	 */
	GenericAttributeValue<String> getColumnDefinition();


	/**
	 * Returns the value of the table child.
	 * @return the value of the table child.
	 */
	GenericAttributeValue<String> getTable();


	/**
	 * Returns the value of the length child.
	 * @return the value of the length child.
	 */
	GenericAttributeValue<Integer> getLength();


	/**
	 * Returns the value of the precision child.
	 * @return the value of the precision child.
	 */
	GenericAttributeValue<Integer> getPrecision();


	/**
	 * Returns the value of the scale child.
	 * @return the value of the scale child.
	 */
	GenericAttributeValue<Integer> getScale();


}
