/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Fri May 19 21:02:44 MSD 2006
// DTD/Schema  :    http://java.sun.com/xml/ns/persistence/orm

package com.intellij.javaee.model.xml.persistence.mapping;

import com.intellij.javaee.model.xml.CommonDomModelElement;
import com.intellij.persistence.model.PersistentAttribute;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.Attribute;
import com.intellij.util.xml.GenericAttributeValue;
import com.intellij.util.xml.GenericDomValue;

import java.util.List;

/**
 * http://java.sun.com/xml/ns/persistence/orm:one-to-many interface.
 * <pre>
 * <h3>Type http://java.sun.com/xml/ns/persistence/orm:one-to-many documentation</h3>
 * @Target({METHOD, FIELD}) @Retention(RUNTIME)
 *         public @interface OneToMany {
 *           Class targetEntity() default void.class;
 *           CascadeType[] cascade() default {};
 *           FetchType fetch() default LAZY;
 *           String mappedBy() default "";
 *         }
 * </pre>
 */
public interface OneToMany extends RelationAttributeBase.AnyToManyBase, CommonDomModelElement, RelationAttributeBase.NonManyToManyBase, com.intellij.javaee.model.common.persistence.mapping.OneToMany {

	/**
	 * Returns the value of the name child.
	 * @return the value of the name child.
	 */
//	@NotNull
//	GenericAttributeValue<String> getName();


	/**
	 * Returns the value of the target-entity child.
	 * @return the value of the target-entity child.
	 */
        @Attribute("target-entity")
        GenericAttributeValue<PsiClass> getTargetEntityClass();


  /**
	 * Returns the value of the fetch child.
	 * @return the value of the fetch child.
	 */
	GenericAttributeValue<FetchType> getFetch();


	/**
	 * Returns the value of the mapped-by child.
	 * @return the value of the mapped-by child.
	 */
	GenericAttributeValue<PersistentAttribute> getMappedBy();


	/**
	 * Returns the value of the order-by child.
	 * @return the value of the order-by child.
	 */
	GenericDomValue<String> getOrderBy();


	/**
	 * Returns the value of the map-key child.
	 * @return the value of the map-key child.
	 */
	MapKey getMapKey();


	/**
	 * Returns the value of the cascade child.
	 * @return the value of the cascade child.
	 */
	CascadeType getCascade();


	/**
	 * Returns the value of the join-table child.
	 * @return the value of the join-table child.
	 */
	JoinTable getJoinTable();


	/**
	 * Returns the list of join-column children.
	 * @return the list of join-column children.
	 */
	List<JoinColumn> getJoinColumns();
	/**
	 * Adds new child to the list of join-column children.
	 * @return created child
	 */
	JoinColumn addJoinColumn();


}
