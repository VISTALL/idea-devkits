/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.model.annotations;

import com.intellij.javaee.model.common.JavaeeCommonConstants;
import org.jetbrains.annotations.NonNls;

/**
 * Created by IntelliJ IDEA.
 * User: greg
 * Date: 09.12.2005
 * Time: 20:00:16
 */
public interface JavaeeAnnotationConstants extends JavaeeCommonConstants {

  String WEB_SERVICE_ANNO = "javax.jws.WebService";
  @NonNls String WEB_SERVICE_ENDPOINT_INTERFACE_PARAMETER = "endpointInterface";
  String WEB_METHOD_ANNO = "javax.jws.WebMethod";
  String PERSISTENCE_UNIT_ANNO = "javax.persistence.PersistenceUnit";
  String PERSISTENCE_CONTEXT_ANNO = "javax.persistence.PersistenceContext";
  @NonNls String UNIT_NAME_PARAMETER = "unitName";
  String DECLARE_ROLES_ANNO = "javax.annotation.security.DeclareRoles";
  String DENY_ALL_ANNO = "javax.annotation.security.DenyAll";
  String PERMIT_ALL_ANNO = "javax.annotation.security.PermitAll";
  String ROLES_ALLOWED_ANNO = "javax.annotation.security.RolesAllowed";
  String RUN_AS_ANNO = "javax.annotation.security.RunAs";
  String POST_CONSTRUCT_ANNO = "javax.annotation.PostConstruct";
  String PRE_DESTROY_ANNO = "javax.annotation.PreDestroy";
  @NonNls String REFERENCE_MAPPED_NAME_PARAMETER = "mappedName";
  @NonNls String REFERENCE_NAME_PARAMETER = "name";
  @NonNls String REFERENCE_TYPE_PARAMETER = "type";
  String RESOURCE_ANNO = "javax.annotation.Resource";
  @NonNls String RESOURCE_SHAREABLE_PARAMETER = "shareable";
  @NonNls String RESOURCE_DESCRIPTION_PARAMETER = "description";
  @NonNls String RESOURCE_AUTHENTICATION_PARAMETER = "authenticationType";
  String WEB_SERVICE_REF_ANNO = "javax.xml.ws.WebServiceRef";
  String WEB_SERVICE_REFS_ANNO = "javax.xml.ws.WebServiceRefs";
  @NonNls String WEB_SERVICE_REF_WSDL_LOCATION_PARAMETER = "wsdlLocation";
  String EJB_ANNO = "javax.ejb.EJB";
  @NonNls String EJB_BEAN_NAME_PARAMETER = "beanName";
  @NonNls String EJB_BEAN_INTERFACE_PARAMETER = "beanInterface";
  String RESOURCES_ANNO = "javax.annotation.Resources";
  String EJBS_ANNO = "javax.ejb.EJBs";
  String AUTHENTICATION_TYPE_PREFIX = "javax.annotation.Resource.AuthenticationType"+".";
  String APPLICATION_EXCEPTION_ANNO = "javax.ejb.ApplicationException";
  @NonNls String APPLICATION_EXCEPTION_ROLLBACK_PARAMETER = "rollback";
  String STATELESS_ANNO = "javax.ejb.Stateless";
  String STATEFUL_ANNO = "javax.ejb.Stateful";
  String MESSAGE_DRIVEN_ANNO = "javax.ejb.MessageDriven";
  @NonNls String MESSAGE_LISTENER_PARAMETER = "messageListenerInterface";
  @NonNls String ACTIVATION_CONFIG_PARAMETER = "activationConfig";
  String ACTIVATION_CONFIG_PROPERTY_ANNO = "javax.ejb.ActivationConfigProperty";
  @NonNls String ACTIVATION_CONFIG_PROPERTY_NAME_PARAMETER = "propertyName";
  @NonNls String ACTIVATION_CONFIG_PROPERTY_VALUE_PARAMETER = "propertyValue";
  String POST_ACTIVATE_ANNO = "javax.ejb.PostActivate";
  String PRE_PASSIVATE_ANNO = "javax.ejb.PrePassivate";
  String AROUND_INVOKE_ANNO = "javax.interceptor.AroundInvoke";
  String EXCLUDE_DEFAULT_INTERCEPTORS_ANNO = "javax.interceptor.ExcludeDefaultInterceptors";
  String EXCLUDE_CLASS_INTERCEPTORS_ANNO = "javax.interceptor.ExcludeClassInterceptors";
  String INTERCEPTORS_ANNO = "javax.interceptor.Interceptors";
  String TRANSACTION_MANAGEMENT_ANNO = "javax.ejb.TransactionManagement";
  String TRANSACTION_MANAGEMENT_TYPE_PREFIX = "javax.ejb.TransactionManagementType"+".";
  String TRANSACTION_ATTRIBUTE_ANNO = "javax.ejb.TransactionAttribute";
  String TRANSACTION_TYPE_PREFIX = "javax.ejb.TransactionAttributeType"+".";
  String REMOVE_ANNO = "javax.ejb.Remove";
  @NonNls String RETAIN_IF_EXCEPTION_PARAMETER = "retainIfException";
  String INIT_ANNO = "javax.ejb.Init";
  String TIMEOUT_ANNO = "javax.ejb.Timeout";
  String LOCAL_ANNO = "javax.ejb.Local";
  String REMOTE_ANNO = "javax.ejb.Remote";
  String REMOTE_HOME_ANNO = "javax.ejb.RemoteHome";
  String LOCAL_HOME_ANNO = "javax.ejb.LocalHome";
  @NonNls String VALUE_PARAMETER = "value";
  @NonNls String NAME_PARAMETER = "name";
}
