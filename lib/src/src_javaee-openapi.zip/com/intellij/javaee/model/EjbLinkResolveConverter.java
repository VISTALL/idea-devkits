/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.model;

import com.intellij.javaee.application.facet.JavaeeApplicationFacet;
import com.intellij.javaee.ejb.EjbModuleUtil;
import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.facet.JavaeeFacetUtil;
import com.intellij.javaee.model.common.ejb.EjbCommonModelUtil;
import com.intellij.javaee.model.common.ejb.EnterpriseBean;
import com.intellij.javaee.model.xml.application.JavaeeApplication;
import com.intellij.javaee.model.xml.application.JavaeeModule;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.util.xml.ConvertContext;
import com.intellij.util.xml.ElementPresentationManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.Collection;

/**
 * @author peter
 */
public class EjbLinkResolveConverter extends JavaeeResolvingConverter<EnterpriseBean> {

  public EnterpriseBean fromString(final String s, final ConvertContext context) {
    return resolveEnterpriseBean(s, JavaeeFacetUtil.getInstance().getJavaeeFacet(context));
  }

  @Nullable
  public static EnterpriseBean resolveEnterpriseBean(final String s, @Nullable final JavaeeFacet contextFacet) {
    if (s == null || contextFacet == null) return null;
    final int index = s.indexOf('#');
    final Project project = contextFacet.getModule().getProject();
    if (index < 0) {
      EjbFacet facet = contextFacet instanceof EjbFacet ? (EjbFacet)contextFacet : null;
      final EnterpriseBean ejb = ElementPresentationManager.findByName(EjbCommonModelUtil.getAllEjbs(project, contextFacet.getModule(), facet), s);
      if (ejb != null) return ejb;
      return ElementPresentationManager.findByName(EjbCommonModelUtil.getAllEjbs(project), s);
    }

    final JavaeeApplication application = getApplicationModel(project);
    if (application != null) {
      final String relative = s.substring(0, index);
      for (final EjbFacet ejbFacet : JavaeeFacetUtil.getInstance().getJavaeeFacets(EjbFacet.ID, project)) {
        if (relative.equals(getRelativePath(application, contextFacet, ejbFacet))) {
          return ElementPresentationManager.findByName(EjbCommonModelUtil.getAllEjbs(project, null, ejbFacet), s.substring(index + 1));
        }
      }
    }

    return null;
  }

  @Nullable
  private static String getRelativePath(JavaeeApplication application, JavaeeFacet contextFacet, EjbFacet ejbFacet) {
    if (application == null) return null;
    final String contextPrefix = getUri(application, contextFacet);
    final String ejbPrefix = getUri(application, ejbFacet);
    if (contextPrefix == null || ejbPrefix == null) return null;
    final String relativePath = getRelativePath(contextPrefix, ejbPrefix);
    return relativePath == null ? null : "../" + relativePath;
  }

  @Nullable
  private static String getRelativePath(String context, String ejb) {
    final String relativePath = FileUtil.getRelativePath(new File("../" + context), new File("../" + ejb));
    return relativePath == null ? null : relativePath.replace('\\', '/');
  }

  @Nullable
  private static String getUri(JavaeeApplication application, JavaeeFacet facet) {
    final JavaeeModule moduleLink = application.findModuleLink(facet);
    if (moduleLink == null) return null;
    final String value = moduleLink.getWeb().getWebUri().getValue();
    if (value != null) {
      return value;
    }
    return moduleLink.getEjb().getValue();
  }

  @Nullable
  private static JavaeeApplication getApplicationModel(Project project) {
    final Collection<JavaeeApplicationFacet> facets = JavaeeFacetUtil.getInstance().getJavaeeFacets(JavaeeApplicationFacet.ID, project);
    if (!facets.isEmpty()) {
      return facets.iterator().next().getRoot();
    }
    return null;
  }

  public String toString(final EnterpriseBean t, final ConvertContext context) {
    if (t == null) return null;

    final EjbFacet ejbFacet = EjbModuleUtil.getEjbFacet(t);
    final JavaeeFacet contextFacet = JavaeeFacetUtil.getInstance().getJavaeeFacet(context);
    final String ejbName = t.getEjbName().getValue();
    final JavaeeApplication application = getApplicationModel(context.getPsiManager().getProject());
    if (ejbFacet == contextFacet) {
      return ejbName;
    }
    final String relativePath = getRelativePath(application, contextFacet, ejbFacet);
    return relativePath == null ? ejbName : relativePath + "#" + ejbName;
  }

  @NotNull
  public Collection<? extends EnterpriseBean> getVariants(final ConvertContext context) {
    return EjbCommonModelUtil.getAllEjbs(context.getModule().getProject());
  }
}
