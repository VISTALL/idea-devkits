/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.deployment;

import com.intellij.facet.pointers.FacetPointer;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.run.configuration.ServerModel;
import com.intellij.openapi.compiler.make.BuildConfiguration;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.*;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public abstract class DeploymentModel implements JDOMExternalizable, Cloneable {
  @NonNls private static final String DEPLOYMENT_METHOD_NAME = "DEPLOYMENT_METHOD";
  @NonNls private static final String DEPLOYMENT_SOURCE_NAME = "DEPLOYMENT_SOURCE_NAME";

  private DeploymentMethod myDeploymentMethod = null;
  private DeploymentSource myDeploymentSource = DeploymentSource.FROM_EXPLODED;
  private CommonModel myParentConfiguration;
  private DeploymentMethod[] myAvailableMethods;
  private FacetPointer<JavaeeFacet> myFacetPointer;
  public boolean DEPLOY = true;

  protected DeploymentModel(@NotNull CommonModel parentConfiguration, @NotNull FacetPointer<JavaeeFacet> facetPointer) {
    myParentConfiguration = parentConfiguration;
    myAvailableMethods = getAvailableMethods();
    myFacetPointer = facetPointer;
  }

  public DeploymentMethod[] getAvailableMethods() {
    DeploymentProvider deploymentProvider = myParentConfiguration.getServerModel().getDeploymentProvider();
    if (deploymentProvider == null) return new DeploymentMethod[0];
    DeploymentMethod[] availableMethods = deploymentProvider.getAvailableMethods();
    if (availableMethods == null) return new DeploymentMethod[0];
    List<DeploymentMethod> result = new ArrayList<DeploymentMethod>();
    for (final DeploymentMethod deploymentMethod : availableMethods) {
      if (isApplicable(deploymentMethod)) {
        result.add(deploymentMethod);
      }
    }
    return result.toArray(new DeploymentMethod[result.size()]);
  }

  private boolean isApplicable(DeploymentMethod deploymentMethod) {
    if (getCommonModel().isLocal()){
      return deploymentMethod.isApplicableForLocal();
    } else {
      return deploymentMethod.isApplicableForRemote();
    }
  }

  @Nullable
  public JavaeeFacet getFacet() {
    return myFacetPointer.getFacet();
  }

  public FacetPointer<JavaeeFacet> getFacetPointer() {
    return myFacetPointer;
  }

  public void readExternal(Element element) throws InvalidDataException {
    DefaultJDOMExternalizer.readExternal(this, element);
    String methodName = element.getAttributeValue(DEPLOYMENT_METHOD_NAME);
    if (methodName != null) {
      setDeploymentMethod(findMethodByName(methodName));
    }
    setDeploymentSource(DeploymentSource.findByName(element.getAttributeValue(DEPLOYMENT_SOURCE_NAME)));
  }

  private DeploymentMethod findMethodByName(String deplMethodName) {
    DeploymentMethod found = null;
    for (DeploymentMethod availableMethod : myAvailableMethods) {
      if (Comparing.equal(availableMethod.getName(), deplMethodName)) {
        found = availableMethod;
      }
    }
    return found;
  }

  public boolean shouldRedeployOnDeploymentSourceContentChange() {
    return false;
  }

  public boolean isValid() {
    return myFacetPointer.getFacet() != null;
  }

  public void writeExternal(Element element) throws WriteExternalException {
    DefaultJDOMExternalizer.writeExternal(this, element);
    if (getDeploymentMethod() != null) {
      element.setAttribute(DEPLOYMENT_METHOD_NAME, getDeploymentMethod().getName());
    }

    if (getSpecifiedDeploymentSource() != null){
      element.setAttribute(DEPLOYMENT_SOURCE_NAME, getSpecifiedDeploymentSource().getName());
    }

  }

  public DeploymentMethod getDeploymentMethod() {
    if (myDeploymentMethod == null){
      DeploymentMethod[] availableMethods = myAvailableMethods;
      if (availableMethods != null && availableMethods.length > 0){
        myDeploymentMethod = availableMethods[0];
      }
    }
    return myDeploymentMethod;
  }

  public void setDeploymentMethod(DeploymentMethod deploymentMethod) {
    myDeploymentMethod = deploymentMethod;
  }

  public CommonModel getCommonModel() {
    return myParentConfiguration;
  }

  public ServerModel getServerModel() {
    return myParentConfiguration.getServerModel();
  }

  public DeploymentModel createCopy(CommonModel parent) {
    try {
      DeploymentModel clone = (DeploymentModel)clone();
      clone.myParentConfiguration = parent;
      return clone;
    }
    catch (CloneNotSupportedException e) {
      throw new InternalError(e.getLocalizedMessage());
    }
  }

  public void setDeploymentSource(DeploymentSource deploymentSource) {
    myDeploymentSource = deploymentSource;
  }

  public @Nullable DeploymentSource getDeploymentSource() {
    final DeploymentSource source = getSpecifiedDeploymentSource();
    final JavaeeFacet facet = myFacetPointer.getFacet();
    if (source != null && facet != null) {
      final Module module = facet.getModule();
      if (module.isDisposed()) {
        return null;
      }
      final BuildConfiguration buildConfiguration = facet.getBuildConfiguration().getBuildProperties();
      if (source == DeploymentSource.FROM_JAR && !buildConfiguration.isJarEnabled()) {
        return null;
      }
      if (source == DeploymentSource.FROM_EXPLODED && !buildConfiguration.isExplodedEnabled()) {
        return null;
      }
    }
    return source;
  }

  public boolean isDeploymentSourceSupported(DeploymentSource deploymentSource) {
    return deploymentSource == DeploymentSource.FROM_JAR || myParentConfiguration.isLocal();
  }

  public @Nullable DeploymentSource getSpecifiedDeploymentSource() {
    if (isDeploymentSourceSupported(myDeploymentSource)) {
      return myDeploymentSource;
    }
    return null;
  }
}
