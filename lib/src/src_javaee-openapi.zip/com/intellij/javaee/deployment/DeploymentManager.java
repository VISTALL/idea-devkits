/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.deployment;

import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.Nullable;

import java.io.File;

/**
 * author: lesya
 */
public abstract class DeploymentManager {
  public static DeploymentManager getInstance(Project project) {
    return ServiceManager.getService(project, DeploymentManager.class);
  }


  public abstract void setDeploymentStatus(JavaeeFacet facet, DeploymentStatus status,
                                           CommonModel instanceConfiguration, J2EEServerInstance serverInstance);

  public abstract DeploymentStatus getDeploymentStatus(JavaeeFacet facet, CommonModel instanceConfiguration);


  public abstract void deployAllModules(J2EEServerInstance instance,
                                        CommonModel runConfiguration,
                                        boolean makeBeforeDeploy, Runnable callback);

  public abstract File getDeploymentSource(DeploymentModel model);

  public abstract void updateAllDeploymentStatus(J2EEServerInstance instance, CommonModel runConfiguration);

  public abstract boolean isModuleDeployedOrIncludedInDeployed(DeploymentModel model);

  public abstract @Nullable DeploymentModel getModelForDeployedModuleContainingModule(DeploymentModel model);
}
