/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.deployment;

import com.intellij.openapi.util.Comparing;
import org.jetbrains.annotations.NonNls;

public class DeploymentSource {
  private final String myName;
  public static final DeploymentSource FROM_JAR = new DeploymentSource("jar");
  public static final DeploymentSource FROM_EXPLODED = new DeploymentSource("exploded");

  public DeploymentSource(@NonNls String name) {
    myName = name;
  }

  public String getName() {
    return myName;
  }

  public String toString() {
    return getName();
  }

  public static DeploymentSource findByName(String name) {
    if (Comparing.equal(name, FROM_JAR.getName())) return FROM_JAR;
    if (Comparing.equal(name, FROM_EXPLODED.getName())) return FROM_EXPLODED;
    return null;
  }
}