package com.intellij.javaee.appServerIntegrations;

import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author nik
 */
public abstract class ApplicationServerUrlMapping implements AppServerDeployedFileUrlProvider {

  @Nullable
  public VirtualFile findSourceFile(@NotNull J2EEServerInstance serverInstance, @NotNull CommonModel model,
                                    @NotNull String url) {
    return null;
  }

  @Nullable 
  public String getUrlForDeployedFile(final J2EEServerInstance serverInstance,
                                      final DeploymentModel deploymentModel, final String relativePath) {
    return null;
  }
}
