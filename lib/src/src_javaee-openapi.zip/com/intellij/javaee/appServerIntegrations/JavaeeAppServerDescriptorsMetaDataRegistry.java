package com.intellij.javaee.appServerIntegrations;

import com.intellij.openapi.extensions.Extensions;
import com.intellij.util.descriptors.ConfigFileMetaData;
import com.intellij.javaee.facet.DescriptorMetaDataProvider;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.facet.FacetTypeId;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;

/**
 * @author nik
 */
/**
 * @deprecated register {@link com.intellij.javaee.facet.DescriptorMetaDataProvider} extension instead
 */
public abstract class JavaeeAppServerDescriptorsMetaDataRegistry implements AppServerDescriptorsMetaDataRegistry {
  public void registerMetaData(final AppServerIntegration integration, final ConfigFileMetaData metaData) {
    Extensions.getRootArea().getExtensionPoint(DescriptorMetaDataProvider.EXTENSION_POINT).registerExtension(new DescriptorMetaDataProvider() {
      public void registerDescriptors(@NotNull final MetaDataRegistry registry) {
        registry.register(getFacetTypeId(), integration, metaData);
      }
    });
  }

  protected abstract FacetTypeId<? extends JavaeeFacet> getFacetTypeId();

  public void registerMetaData(@NotNull final ConfigFileMetaData... metaData) {
    for (ConfigFileMetaData data : metaData) {
      registerMetaData(null, data);
    }
  }

  @NotNull
  public ConfigFileMetaData[] getMetaData() {
    throw new UnsupportedOperationException("'getMetaData' not implemented in " + getClass().getName());
  }

  public ConfigFileMetaData findMetaData(@NonNls @NotNull final String id) {
    throw new UnsupportedOperationException("'findMetaData' not implemented in " + getClass().getName());
  }

  @NotNull
  public Collection<ConfigFileMetaData> getMetaData(final AppServerIntegration integration) {
    throw new UnsupportedOperationException("'getMetaData' not implemented in " + getClass().getName());
  }
}
