/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.appServerIntegrations;

import com.intellij.facet.FacetTypeId;
import com.intellij.ide.fileTemplates.FileTemplateGroupDescriptor;
import com.intellij.ide.fileTemplates.FileTemplateGroupDescriptorFactory;
import com.intellij.javaee.dataSource.DataSourceProvider;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.facet.JavaeeFacetUtil;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.extensions.ExtensionPointName;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

/**
 * Application server integration component
 * Specific app server integrations should implement it
 */
public abstract class AppServerIntegration implements ApplicationComponent, FileTemplateGroupDescriptorFactory {
  public static final ExtensionPointName<AppServerIntegration> EXTENSION_POINT = ExtensionPointName.create("com.intellij.javaee.appServerIntegration");

  public abstract String getPresentableName();


  public void initComponent() {
  }


  public void disposeComponent() {
  }

  @Nullable 
  public DataSourceProvider getDataSourceProvider() {
    return null;
  }

  @Nullable
  public ApplicationServerHelper getApplicationServerHelper() {
    return null;
  }

  @Nullable
  public AppServerSpecificValidator getAppServerSpecificValidator(@NotNull JavaeeFacet facet, @NotNull ApplicationServer server) {
    return null;
  }

  @NotNull
  public AppServerDeployedFileUrlProvider getDeployedFileUrlProvider() {
    return AppServerDeployedFileUrlProvider.DEFAULT;
  }

  @NotNull
  public Collection<FacetTypeId<? extends JavaeeFacet>> getSupportedFacetTypes() {
    return JavaeeFacetUtil.getInstance().getAllJavaeeFacetTypes();
  }

  /**
   * @deprecated register a separate {@link com.intellij.ide.fileTemplates.FileTemplateGroupDescriptorFactory} instance as an extension point instead
   */
  @Nullable
  public FileTemplateGroupDescriptor getFileTemplatesDescriptor() {
    return null;
  }

}