/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.ui;

import com.intellij.javaee.J2EEBundle;
import com.intellij.javaee.JamMessages;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.help.HelpManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.util.xml.ui.CommittablePanel;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public abstract class TableWithCRUDButtons extends DisposableComponent implements CommittablePanel {
  protected JButton myEditButton;
  private JButton myRemoveButton;
  protected JTable myTable;
  private JPanel myPanel;
  protected JButton myNewButton;
  private JScrollPane myScrollPane;
  protected final Project myProject;
  private JButton myHelpButton;
  private JPanel myAdditionalButtonsPanel;

  protected TableWithCRUDButtons(Project project, boolean showNewButton, boolean showEditButton) {
    myProject = project;
    int minHeight = (int)((showNewButton ? myNewButton.getPreferredSize().getHeight() + 5 : 0) +
                          (showEditButton ? myEditButton.getPreferredSize().getHeight() + 5 : 0) +
                          myRemoveButton.getPreferredSize().getHeight() + 5);
    myPanel.setMinimumSize(new Dimension(myPanel.getWidth(), minHeight));

    myNewButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        doNew();
      }
    });
    myNewButton.setVisible(showNewButton);

    myRemoveButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (isRemoveOk()) {
          doRemove();
        }
      }
    });

    myEditButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        doEdit();
      }
    });
    myEditButton.setVisible(showEditButton);

    myHelpButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        HelpManager.getInstance().invokeHelp(getHelpID());
      }
    });

    myTable.addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
          doEdit();
        }
      }
    });
    myTable.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    myTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        selectionChanged();
      }
    });
    ApplicationManager.getApplication().invokeLater(new Runnable() {
      public void run() {
        selectionChanged();
      }
    });

    myAdditionalButtonsPanel.setLayout(new GridLayout(1, 0));
    myAdditionalButtonsPanel.setVisible(false);

    //TODO change to JScrollPane2 when GUI Designer allow
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        Component component = myScrollPane.getViewport().getView();
        if (component != null) {
          myScrollPane.getViewport().setBackground(component.getBackground());
        }
      }
    });
  }

  protected boolean isRemoveOk() {
    final Object o = getSelectedValue();
    String name = /*o instanceof NamedObject ? ((NamedObject)o).getName() : */String.valueOf(o);
    return Messages.showYesNoDialog(myProject, JamMessages.message("confirmation.text.delete.element", name), J2EEBundle.message("action.name.delete"), null) == 0;
  }

  public void commit() {
  }

  public final void reset() {
    refreshModel();
  }

  protected abstract void refreshModelImpl();

  protected void refreshModel(){
    Object selectedValue = getSelectedValue();
    refreshModelImpl();
    setSelection(selectedValue);
  }

  protected void setSelection(Object selectedValue) {
    if (selectedValue != null){
      int index = indexOf(selectedValue);
      if (index >= 0){
        myTable.getSelectionModel().setSelectionInterval(index, index);
      }
    }
  }

  private int indexOf(Object selectedValue) {
    TableModel model = myTable.getModel();
    for (int i = 0; i < model.getRowCount(); i++){
      if (model.getValueAt(i, 0) == selectedValue){
        return i;
      }
    }
    return -1;
  }

  protected void addNewButton(String caption, ActionListener actionListener){
    myAdditionalButtonsPanel.setVisible(true);
    JButton button = new JButton(caption);
    myAdditionalButtonsPanel.add(button);
    button.addActionListener(actionListener);
    myPanel.revalidate();
    myPanel.repaint();
  }

  private void selectionChanged() {
    final int selectedRows = myTable.getSelectedRowCount();
    myEditButton.setEnabled(selectedRows == 1);
    myRemoveButton.setEnabled(selectedRows != 0);
  }

  protected abstract void doEdit();

  protected abstract void doRemove();

  protected abstract void doNew();

  protected Object getSelectedValue() {
    final int selectedRow = myTable.getSelectedRow();
    if (selectedRow == -1) return null;
    return myTable.getModel().getValueAt(selectedRow, 0);
  }

  public JComponent getComponent() {
    return myPanel;
  }

  protected abstract String getHelpID();
}