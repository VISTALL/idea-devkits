/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.serverInstances;

import com.intellij.execution.process.ProcessHandler;
import com.intellij.javaee.appServerIntegrations.AppServerIntegration;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.facet.JavaeeFacetUtil;
import com.intellij.javaee.module.JavaeeFacetLink;
import com.intellij.openapi.deployment.PackagingMethod;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.run.configuration.ServerModel;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.application.ReadAction;
import com.intellij.openapi.application.Result;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NonNls;

import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

public class DefaultServerInstance implements J2EEServerInstance {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.serverInstances.DefaultServerInstance");
  private List<J2EEServerStateListener> myListeners = new ArrayList<J2EEServerStateListener>();
  private CommonModel myCommonModel;
  private final String myHost;
  private final int myPort;
  private ProcessHandler myProcessHandler;
  @NonNls protected static final String LOCALHOST = "localhost";

  public DefaultServerInstance(CommonModel runConfiguration) {
    myCommonModel = runConfiguration;
    myHost = myCommonModel.getHost();
    myPort = myCommonModel.getPort();
  }

  protected String getHost() {
    return myHost;
  }

  public String getName() {
    return myCommonModel.getName();
  }

  public AppServerIntegration getIntegration() {
    return myCommonModel.getIntegration();
  }

  public CommonModel getCommonModel() {
    return myCommonModel;
  }

  public ServerModel getServerModel() {
    return myCommonModel.getServerModel();
  }

  public void start(ProcessHandler processHandler) {
    myProcessHandler = processHandler;
  }

  public boolean isStopped() {
    return myProcessHandler != null && myProcessHandler.isProcessTerminated();
  }

  public boolean isStarting() {
    return myProcessHandler == null;
  }

  public boolean isStartupScriptTerminatesAfterServerStartup() {
    return false;
  }

  public boolean isConnected() {
    Project project = myCommonModel.getProject();
    if (!project.isDisposed() && RunAppServerInstanceManager.getInstance(project).debuggerIsConnected(myProcessHandler)) {
      return true;
    }

    if(LOCALHOST.equals(myHost) || myCommonModel.isLocal()) {
      try {
        ServerSocket serverSocket = new ServerSocket(myPort);
        serverSocket.close();
      } catch (BindException e) {
        return true;
      } catch (IOException e) {
      }
    }

    try {
      Socket socket = new Socket(myHost, myPort);
      socket.setSoTimeout(30000);
      try {
        socket.close();
      }
      catch (IOException e) {
      }
      return true;
    }
    catch (SocketTimeoutException ex) {
      return true;
    }
    catch (Exception e) {
      return false;
    }


  }

  public void shutdown() {
  }

  public boolean connect() throws Exception {
    return true;
  }

  public void registerServerError(Throwable e1) {
    LOG.error(e1);
  }

  public void addServerListener(J2EEServerStateListener j2EEServerStateListener) {
    myListeners.add(j2EEServerStateListener);
  }

  public void removeServerListener(J2EEServerStateListener j2EEServerStateListener) {
    myListeners.remove(j2EEServerStateListener);
  }

  public void fireServerListeners(final J2EEServerEvent event) {
    J2EEServerStateListener[] listenersArray = myListeners.toArray(new J2EEServerStateListener[myListeners.size()]);
    for (int i = 0; i < listenersArray.length; i++) {
      listenersArray[i].serverStateChanged(event);
    }
  }

  protected ProcessHandler getProcessHandler() {
    return myProcessHandler;
  }

  public static JavaeeFacet[] getScopeFacets(final CommonModel commonModel) {
    return ApplicationManager.getApplication().runReadAction(new Computable<JavaeeFacet[]>() {
      public JavaeeFacet[] compute() {
        final List<JavaeeFacet> facetsToDeploy = new ArrayList<JavaeeFacet>();
        for (JavaeeFacet facet : JavaeeFacetUtil.getInstance().getAllJavaeeFacets(commonModel.getProject())) {
          final DeploymentModel deploymentModel = commonModel.getDeploymentModel(facet);
          if (deploymentModel != null && !deploymentModel.DEPLOY) {
            continue;
          }
          facetsToDeploy.add(facet);
        }
        return facetsToDeploy.toArray(new JavaeeFacet[facetsToDeploy.size()]);
      }
    });
  }

  public static JavaeeFacet[] getScopeFacetsWithIncluded(final CommonModel commonModel) {
    final Set<JavaeeFacet> facets = new HashSet<JavaeeFacet>();
    new ReadAction() {
      protected void run(final Result result) {
        final JavaeeFacet[] scopeFacets = getScopeFacets(commonModel);
        for (JavaeeFacet facet : scopeFacets) {
          addIncludedFacets(facet, facets);
        }
      }
    }.execute();
    return facets.toArray(new JavaeeFacet[facets.size()]);
  }

  private static void addIncludedFacets(final JavaeeFacet facet, final Set<JavaeeFacet> facets) {
    if (facets.contains(facet)) return;
    facets.add(facet);

    for (JavaeeFacetLink facetLink : facet.getPackagingConfiguration().getFacetLinks()) {
      if (facetLink.getPackagingMethod() == PackagingMethod.INCLUDE_MODULE_IN_BUILD) {
        addIncludedFacets(facetLink.getFacet(), facets);
      }
    }
  }

}
