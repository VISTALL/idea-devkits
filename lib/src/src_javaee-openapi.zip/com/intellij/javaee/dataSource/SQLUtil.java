/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.dataSource;

import com.intellij.openapi.util.text.StringUtil;
import com.intellij.persistence.database.DatabaseColumnInfo;
import com.intellij.psi.CommonClassNames;
import com.intellij.psi.util.PsiTypesUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: nick
 * Date: 09.01.2003
 * Time: 16:17:35
 * To change this template use Options | File Templates.
 */
public class SQLUtil {

  @NonNls private static final String CHAR_ARR = "char[]";
  @NonNls private static final String BYTE_ARR = "byte[]";

  private static final String BOOLEAN = CommonClassNames.JAVA_LANG_BOOLEAN;
  private static final String BYTE = CommonClassNames.JAVA_LANG_BYTE;
  private static final String SHORT = CommonClassNames.JAVA_LANG_SHORT;
  private static final String INTEGER = CommonClassNames.JAVA_LANG_INTEGER;
  private static final String LONG = CommonClassNames.JAVA_LANG_LONG;
  private static final String BIGINT = "java.math.BigInteger";
  private static final String FLOAT = CommonClassNames.JAVA_LANG_FLOAT;
  private static final String DOUBLE = CommonClassNames.JAVA_LANG_DOUBLE;
  private static final String STRING = CommonClassNames.JAVA_LANG_STRING;
  private static final String BLOB = "java.sql.Blob";
  private static final String SQL_DATE = "java.sql.Date";
  private static final String SQL_TIME = "java.sql.Time";
  private static final String SQL_TIMESTAMP = "java.sql.Timestamp";
  private static final String CLOB = "java.sql.Clob";
  private static final String SQL_ARRAY = "java.sql.Array";
  private static final String SQL_REF = "java.sql.Ref";
  private static final String OBJECT = CommonClassNames.JAVA_LANG_OBJECT;
  private static final String SQL_STRUCT = "java.sql.Struct";
  private static final String SERIALIZABLE = CommonClassNames.JAVA_IO_SERIALIZABLE;
  private static final String MAP = CommonClassNames.JAVA_UTIL_MAP;

  /**
   * Has a side effect - strings are converted into lower case.
   * @param rs
   * @param columnName
   * @return
   * @throws SQLException
   */
  public static <T> List<T> resultSetToList(ResultSet rs, String columnName) throws SQLException {
    List<T> retVal = new ArrayList<T>();
    while (rs.next()) {
      Object o = rs.getObject(columnName);
      if (o instanceof String) {
        o = ((String) o).toLowerCase();
      }
      retVal.add((T)o);
    }
    return retVal;
  }

  /**
   *
   * @param jdbcType
   * @return
   */
  public static boolean hasScaleAndPrecision(int jdbcType) {
    switch(jdbcType) {
      case Types.DECIMAL:
      case Types.NUMERIC:
      case Types.FLOAT:
      case Types.REAL:
      case Types.DOUBLE:
        return true;
      default: return false;
    }
  }

  public static boolean hasLength(int jdbcType) {
    switch(jdbcType) {
      case Types.CHAR:
      case Types.VARCHAR:
      case Types.LONGVARCHAR:
      case Types.DATE:
      case Types.TIME:
      case Types.TIMESTAMP:
        return true;
      default:return false;
    }
  }

  public static String getJdbcTypeName(final DatabaseColumnInfo tableFieldData) {
    final String sqlType = tableFieldData.getSqlType();
    final int jdbcType = tableFieldData.getJdbcType();
    final String typeName = StringUtil.isNotEmpty(sqlType)? sqlType : getJdbcTypeName(jdbcType);
    if (hasLength(jdbcType) && tableFieldData.getLength()>=0) {
      return typeName+"("+tableFieldData.getLength()+")";
    }
    else if (hasScaleAndPrecision(jdbcType) && tableFieldData.getLength() >= 0 && tableFieldData.getPrecision() >= 0) {
      return typeName + "(" + tableFieldData.getLength() + ", " + tableFieldData.getPrecision() +")";
    }
    return typeName;
  }

  /**
   * Returns JDBC type name string, i.e. "LONGVARCHAR" for Types.LONGVARCHAR.
   * @param jdbcType one of java.sql.Types.* constants
   * @return type name
   */
  @NotNull
  public static String getJdbcTypeName(final int jdbcType) {
    @NonNls final String result;
    switch (jdbcType) {
      case Types.BIT:
        result = "BIT";
        break;
      case Types.TINYINT:
        result = "TINYINT";
        break;
      case Types.SMALLINT:
        result = "SMALLINT";
        break;
      case Types.INTEGER:
        result = "INTEGER";
        break;
      case Types.BIGINT:
        result = "BIGINT";
        break;
      case Types.FLOAT:
        result = "FLOAT";
        break;
      case Types.REAL:
        result = "REAL";
        break;
      case Types.DOUBLE:
        result = "DOUBLE";
        break;
      case Types.NUMERIC:
        result = "NUMERIC";
        break;
      case Types.DECIMAL:
        result = "DECIMAL";
        break;
      case Types.CHAR:
        result = "CHAR";
        break;
      case Types.VARCHAR:
        result = "VARCHAR";
        break;
      case Types.LONGVARCHAR:
        result = "LONGVARCHAR";
        break;
      case Types.DATE:
        result = "DATE";
        break;
      case Types.TIME:
        result = "TIME";
        break;
      case Types.TIMESTAMP:
        result = "TIMESTAMP";
        break;
      case Types.BINARY:
        result = "BINARY";
        break;
      case Types.VARBINARY:
        result = "VARBINARY";
        break;
      case Types.LONGVARBINARY:
        result = "LONGVARBINARY";
        break;
      case Types.NULL:
        result = "NULL";
        break;
      case Types.OTHER:
        result = "OTHER";
        break;
      case Types.JAVA_OBJECT:
        result = "JAVA_OBJECT";
        break;
      case Types.DISTINCT:
        result = "DISTINCT";
        break;
      case Types.STRUCT:
        result = "STRUCT";
        break;
      case Types.ARRAY:
        result = "ARRAY";
        break;
      case Types.BLOB:
        result = "BLOB";
        break;
      case Types.CLOB:
        result = "CLOB";
        break;
      case Types.REF:
        result = "REF";
        break;
      case Types.DATALINK:
        result = "DATALINK";
        break;
      case Types.BOOLEAN:
        result = "BOOLEAN";
        break;
      default:
        result = "UNKNOWN";
    }
    return result;
  }

  /**
   * Returns possible java types for a column of the given JDBC type.
   * @param jdbcType column JDBC type
   * @param preferUnboxed
   * @return possible java type names
   */
  @NotNull
  public static String[] getJavaTypeVariants(final int jdbcType, final boolean preferUnboxed) {
    final String[] result;
    switch (jdbcType) {
      case Types.BOOLEAN:      
      case Types.BIT:
        result = new String[] {BOOLEAN, BYTE, SHORT, INTEGER, LONG, BIGINT, //or
          FLOAT, DOUBLE, STRING};
        break;
      case Types.TINYINT:
        result = new String[]{BYTE, SHORT, INTEGER, LONG, BIGINT,  //or
          BOOLEAN, FLOAT, DOUBLE, STRING};
        break;
      case Types.SMALLINT:
        result = new String[]{SHORT, INTEGER, LONG, BIGINT,  //or
          BOOLEAN, BYTE, FLOAT, DOUBLE, STRING};
        break;
      case Types.INTEGER:
        result = new String[]{INTEGER, LONG, BIGINT,  //or
          BOOLEAN, BYTE, SHORT, FLOAT, DOUBLE, STRING};
        break;
      case Types.BIGINT:
        result = new String[]{LONG, BIGINT,  //or
          BOOLEAN, BYTE, SHORT, INTEGER, FLOAT, DOUBLE, STRING};
        break;
      case Types.REAL:
        result = new String[]{FLOAT, DOUBLE,  //or
          BOOLEAN, BYTE, SHORT, INTEGER, LONG, BIGINT, STRING};
        break;
      case Types.FLOAT:
      case Types.DOUBLE:
        result = new String[]{DOUBLE, FLOAT,  //or
          BOOLEAN, BYTE, SHORT, INTEGER, LONG, BIGINT, STRING};
        break;
      case Types.NUMERIC:
      case Types.DECIMAL:
        result = new String[]{BIGINT,  //or
          BOOLEAN, BYTE, SHORT, INTEGER, LONG, FLOAT, DOUBLE, STRING};
        break;
      case Types.CHAR:
      case Types.VARCHAR:
      case Types.LONGVARCHAR:
        result = new String[]{STRING, CHAR_ARR, BYTE_ARR, // or
          SQL_DATE, SQL_TIME, SQL_TIMESTAMP};
        break;
      case Types.DATE:
        result = new String[] {SQL_DATE, STRING};
        break;
      case Types.TIME:
        result = new String[]{SQL_TIME, STRING};
        break;
      case Types.TIMESTAMP:
        result = new String[]{SQL_TIMESTAMP, STRING};
        break;
      case Types.BINARY:
      case Types.VARBINARY:
      case Types.LONGVARBINARY:
        result = new String[]{BYTE_ARR, STRING};
        break;
      case Types.DATALINK:
      case Types.NULL:
      case Types.OTHER:
      case Types.DISTINCT:
      case Types.JAVA_OBJECT:
        result = new String[]{OBJECT, SERIALIZABLE};
        break;
      case Types.STRUCT:
        result = new String[]{SQL_STRUCT, MAP, OBJECT};
        break;
      case Types.ARRAY:
        result = new String[] {SQL_ARRAY, OBJECT};
        break;
      case Types.BLOB:
        result = new String[] {BLOB, BYTE_ARR};
        break;
      case Types.CLOB:
        result = new String[]{CLOB, CHAR_ARR};
        break;
      case Types.REF:
        result = new String[] {SQL_REF, OBJECT, SERIALIZABLE};
        break;
      default:
        result = new String[]{OBJECT, SERIALIZABLE};
    }
    return preferUnboxed? unboxJavaTypes(result) : result;
  }

  /**
   * Unboxes java types if possible in the given array
   * @param types array of java types
   * @return types
   */
  public static String[] unboxJavaTypes(final String[] types) {
    for (int i = 0; i < types.length; i++) {
      types[i] = PsiTypesUtil.unboxIfPossible(types[i]);
    }
    return types;
  }

  /**
   * Returns the unboxed type name or parameter.
   * @param type boxed java type name
   * @return unboxed type name if available; same value otherwise
   * * @deprecated use {@link com.intellij.psi.util.PsiTypesUtil#unboxIfPossible(String)}
   */
  @Nullable
  public static String unboxIfPossible(final String type) {
    return PsiTypesUtil.unboxIfPossible(type);
  }

  /**
   * Returns the boxed type name or parameter.
   * @param type primitive java type name
   * @return boxed type name if available; same value otherwise
   * @deprecated use {@link com.intellij.psi.util.PsiTypesUtil#boxIfPossible(String)}
   */
  @Nullable
  public static String boxIfPossible(final String type) {
    return PsiTypesUtil.boxIfPossible(type);
  }
}
