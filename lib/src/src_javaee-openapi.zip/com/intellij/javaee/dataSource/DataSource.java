/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.dataSource;

import com.intellij.javaee.J2EEBundle;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.openapi.progress.EmptyProgressIndicator;
import com.intellij.openapi.progress.ProcessCanceledException;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.util.*;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.util.containers.ContainerUtil;
import gnu.trove.THashSet;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * @author cdr
 */

public abstract class DataSource implements JDOMExternalizable {
  @NonNls private static final String RS_TABLE_NAME = "TABLE_NAME";
  @NonNls private static final String RS_TABLE_SCHEMA = "TABLE_SCHEM";
  @NonNls private static final String RS_TABLE_CATALOG = "TABLE_CAT";
  @NonNls private static final String RS_TABLE_TYPE = "TABLE_TYPE";
  public String NAME;
  @Deprecated
  public String PROJECT;
  protected List<DatabaseTableData> myTables = new ArrayList<DatabaseTableData>();
  protected List<String> mySchemas = new ArrayList<String>();

  @NonNls private static final String TABLE_ELEMENT = "TABLE_DATA";

  public void readExternal(Element element) throws InvalidDataException {
    myTables.clear();
    mySchemas.clear();
    DefaultJDOMExternalizer.readExternal(this, element);
    for (final Element tableElement : (List<Element>)element.getChildren(TABLE_ELEMENT)) {
      DatabaseTableData databaseTableData = new DatabaseTableData(null, this);
      databaseTableData.readExternal(tableElement);
      myTables.add(databaseTableData);
    }
    resolveSchemas(myTables, mySchemas);
    for (DatabaseTableData table : myTables) {
      table.resolveReferences();
    }
  }

  public void writeExternal(Element element) throws WriteExternalException {
    DefaultJDOMExternalizer.writeExternal(this, element);
    for (DatabaseTableData databaseTableData : myTables) {
      Element tableElement = new Element(TABLE_ELEMENT);
      element.addContent(tableElement);
      databaseTableData.writeExternal(tableElement);
    }
  }

  public String getName() {
    return NAME;
  }

  @Nullable
  protected abstract Connection getConnection(J2EEServerInstance serverInstance) throws Exception;
  @Nullable
  protected abstract String getSchemaName();

  @Nullable
  protected String getTablePattern() {
    return null;
  }

  public abstract void init();

  public List<DatabaseTableData> getTables() {
    return myTables;
  }

  public List<String> getSchemas() {
    return mySchemas;
  }

  @Deprecated
  @Nullable
  public DatabaseTableData findTableByName(final String name) {
    final List<DatabaseTableData> tables = getTables();
    for (DatabaseTableData tableData : tables) {
      if (Comparing.strEqual(name, tableData.getName(), false)) return tableData;
    }
    return null;
  }

  @Nullable
  public DatabaseTableData findTableByName(final String name, final String schema, final String catalog) {
    final List<DatabaseTableData> tables = getTables();
    for (DatabaseTableData tableData : tables) {
      if (Comparing.strEqual(name, tableData.getName(), false)
        && (schema == null || Comparing.strEqual(schema, tableData.getSchema(), false))
        && (catalog == null || Comparing.strEqual(catalog, tableData.getCatalog(), false))) {
        return tableData;
      }
    }
    return null;
  }

  @Nullable
  public <T> T performJdbcOperation(final J2EEServerInstance serverInstance,
                                        final Ref<String> errorMessage,
                                        final JdbcOperation<T> operation) {
    final ProgressManager progressManager = ProgressManager.getInstance();

    ProgressIndicator indicator = progressManager.getProgressIndicator();
    if (indicator == null) indicator = new EmptyProgressIndicator();
    Connection connection = null;
    try {
      indicator.setIndeterminate(true);
      indicator.setText(J2EEBundle.message("message.datasource.progress.connecting.to.database"));
      connection = getConnection(serverInstance);
    }
    catch (SQLException e) {
      errorMessage.set(J2EEBundle.message("message.text.cant.establish.connection.because.of.error", throwableToString(e)));
    }
    catch (ClassNotFoundException e) {
      errorMessage.set(J2EEBundle.message("message.driver.class.not.found.text", e.getMessage()));
    }
    catch (ProcessCanceledException e) {
      throw e;
    }
    catch (UnsatisfiedLinkError e) {
      // IDEADEV-6598
      errorMessage.set(J2EEBundle.message("message.text.native.library.cannot.be.loaded", throwableToString(e)));
    }
    catch (Throwable e) {
      errorMessage.set(throwableToString(e));
    }
    try {
      if (connection != null) {
        return operation.perform(connection, indicator);
      }
      else if (errorMessage.get() == null) {
        errorMessage.set(J2EEBundle.message("wrong.driver.specified"));
      }
    }
    catch (ProcessCanceledException e) {
      throw e;
    }
    catch (Exception e) {
      errorMessage.set(J2EEBundle.message("message.text.jdbc.operation.failed", throwableToString(e)));
    }
    catch (Throwable e) {
      errorMessage.set(throwableToString(e));
    }
    finally {
      if (connection != null) {
        releaseConnection(connection);
      }
    }
    return null;
  }

  protected void releaseConnection(final Connection connection) {
    try {
      connection.close();
    }
    catch (SQLException e) {
      // ignore
    }
  }

  @Nullable
  public String refreshMetaData(J2EEServerInstance serverInstance, final boolean loadTables, final boolean loadTableDetails) {
    final Ref<String> errorMessage = new Ref<String>();
    final String result = performJdbcOperation(serverInstance, errorMessage,
                                    new JdbcOperation<String>() {
      public String perform(@NotNull Connection connection, @NotNull ProgressIndicator indicator) throws Exception {
        DatabaseMetaData metaData = connection.getMetaData();
        if (loadTables) {
          final StringBuilder errors = new StringBuilder();
          final ArrayList<DatabaseTableData> tables = new ArrayList<DatabaseTableData>();
          final ArrayList<String> schemas = new ArrayList<String>();

          indicator.setText(J2EEBundle.message("message.datasource.progress.loading.table.list"));

          boolean tablesFound = false;
          final boolean schemaSupported = !StringUtil.isEmpty(metaData.getSchemaTerm());
          final Pattern pattern;
          if (StringUtil.isEmpty(getTablePattern())) {
            pattern = null;
          }
          else {
            try {
              pattern = Pattern.compile(getTablePattern());
            }
            catch (PatternSyntaxException e) {
              return e.getLocalizedMessage();
            }
          }
          final String schemaPattern = getSchemaName();
          final String catalog = connection.getCatalog();

          if (!schemaSupported || StringUtil.isEmpty(schemaPattern)) {
            tablesFound = loadTables(DataSource.this, tables, metaData, catalog, schemaPattern, pattern, indicator);
          }
          else {
            for (final StringTokenizer st = new StringTokenizer(schemaPattern); st.hasMoreTokens();) {
              final String schema = st.nextToken();
              tablesFound = loadTables(DataSource.this, tables, metaData, catalog, schema, pattern, indicator) || tablesFound;
            }
          }
          myTables = tables;
          mySchemas = schemas;

          resolveSchemas(myTables, mySchemas);
          if (loadTableDetails) {
            int errorCounter = 0;
            boolean errorsTruncated = false;
            int totalCount = 2 * myTables.size();
            int count = 0;
            indicator.setIndeterminate(false);
            indicator.setText(J2EEBundle.message("message.datasource.progress.loading.table.structure"));
            for (DatabaseTableData tableData : myTables) {
              indicator.checkCanceled();
              count++;
              indicator.setText2(J2EEBundle.message("message.datasource.progress.current.table.0", tableData.getName()));
              indicator.setFraction(count / (double)totalCount);
              try {
                refreshTableMetaData(tableData, metaData, tableData.getName(), schemaPattern);
              }
              catch (Exception e) {
                final boolean wrapper = e instanceof SQLWrapperException;
                if (!wrapper || ((SQLWrapperException)e).isFatal()) {
                  errorCounter ++;
                }
                if (errors.length() < 10240) {
                  errors.append(J2EEBundle.message("message.text.error.refreshing.table.item",
                                                   tableData.getName(), throwableToString(wrapper ? e.getCause(): e)));
                }
                else if (!errorsTruncated) {
                  errorsTruncated = true;
                  errors.append("\n\n...");
                }
              }
            }
            if (errors.length() > 0) {
              final int total = myTables.size();
              errors.insert(0, J2EEBundle.message("message.text.error.refreshing.table.header", String.valueOf(total - errorCounter), String.valueOf(total)));
            }
            indicator.setText(J2EEBundle.message("message.datasource.progress.resolving.table.relationships"));
            for (DatabaseTableData tableData : myTables) {
              indicator.checkCanceled();
              count++;
              indicator.setText2(J2EEBundle.message("message.datasource.progress.current.table.0", tableData.getName()));
              indicator.setFraction(count / (double)totalCount);
              tableData.resolveReferences();
            }
          }
          if (errors.length() > 0) {
            return errors.toString();
          }
          if (!tablesFound) {
            return J2EEBundle.message("message.text.no.tables.were");
          }
        }
        return null;
      }
    });
    return errorMessage.isNull()? result : errorMessage.get();
  }

  private static boolean loadTables(final DataSource dataSource, final List<DatabaseTableData> tables, final DatabaseMetaData metaData,
                                    final String catalog, final String schema, final Pattern tablePattern, final ProgressIndicator indicator) throws SQLException {
    boolean tablesFound = false;
    final ResultSet rs = metaData.getTables(catalog, schema, "%", DatabaseTableData.TABLE_TYPES);
    while (rs.next()) {
      indicator.checkCanceled();
      final String tableName = rs.getString(RS_TABLE_NAME);
      final String tableSchema = rs.getString(RS_TABLE_SCHEMA);
      final String tableCatalog = rs.getString(RS_TABLE_CATALOG);
      final String tableType = rs.getString(RS_TABLE_TYPE);
      if (tableName != null) {
        if (tablePattern != null) {
          if (!tablePattern.matcher(tableName).matches()) {
            continue;
          }
        }
        DatabaseTableData tableData = new DatabaseTableData(tableName, tableSchema, tableCatalog, tableType, dataSource);
        tables.add(tableData);
        tablesFound = true;
      }
    }
    rs.close();
    return tablesFound;
  }

  private static void resolveSchemas(final List<DatabaseTableData> tables, final List<String> schemas) {
    final THashSet<String> schemasSet = new THashSet<String>();
    for (DatabaseTableData table : tables) {
      ContainerUtil.addIfNotNull(table.getSchema(), schemasSet);
    }
    schemas.addAll(schemasSet);
  }

  protected void refreshTableMetaData(final DatabaseTableData tableData,
                                    final DatabaseMetaData metaData,
                                    final String tableName,
                                    final String schemaNamePattern) throws SQLException {
    tableData.refreshMetaData(metaData, tableName, schemaNamePattern);
  }

  @Nullable
  public String[] getSchemaNames(J2EEServerInstance serverInstance, final Ref<String> errorMessage) {
    return performJdbcOperation(serverInstance, errorMessage, new JdbcOperation<String[]>() {
      @Nullable
      public String[] perform(@NotNull Connection connection, @NotNull ProgressIndicator indicator) throws Exception {
        indicator.setText(J2EEBundle.message("message.datasource.progress.loading.schemas"));
        final HashSet<String> set = new HashSet<String>();
        final ResultSet schemas = connection.getMetaData().getSchemas();
        while (schemas.next()) {
          final String s = schemas.getString(RS_TABLE_SCHEMA);
          if (s != null) {
            set.add(s);
          }
        }
        return set.toArray(new String[set.size()]);
      }
    });
  }

  public void setName(String name) {
    NAME = name;
  }

  public abstract String getSourceName();

  protected void importTables(List<DatabaseTableData> tables) {
    for (DatabaseTableData table : tables) {
      table.setDataSource(this);
    }
    myTables.clear();
    myTables.addAll(tables);
  }

  private static String throwableToString(Throwable throwable) {
    return StringUtil.getThrowableText(throwable, "com.intellij.");
  }
}
