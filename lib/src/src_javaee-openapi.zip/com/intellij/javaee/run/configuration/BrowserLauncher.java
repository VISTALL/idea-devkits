package com.intellij.javaee.run.configuration;

import com.intellij.openapi.extensions.ExtensionPointName;
import com.intellij.openapi.extensions.Extensions;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author nik
 */
public abstract class BrowserLauncher {
  public static final ExtensionPointName<BrowserLauncher> EXTENSION_POINT = ExtensionPointName.create("com.intellij.javaee.browserLauncher");
  private final String myId;

  protected BrowserLauncher(final @NotNull @NonNls String id) {
    myId = id;
  }

  public final String getId() {
    return myId;
  }

  public abstract String getDisplayName();

  public abstract void launchBrowser(@NotNull @NonNls String url, @NotNull CommonModel runConfiguration, @NotNull ProcessHandler processHandler,
                                     @NotNull J2EEServerInstance serverInstance);

  public static BrowserLauncher[] getExtensions() {
    return Extensions.getExtensions(EXTENSION_POINT);
  }

  @NotNull
  public static BrowserLauncher findById(@Nullable @NonNls String id) {
    BrowserLauncher[] launchers = getExtensions();
    for (BrowserLauncher launcher : launchers) {
      if (launcher.getId().equals(id)) {
        return launcher;
      }
    }
    return launchers[0];
  }
}
