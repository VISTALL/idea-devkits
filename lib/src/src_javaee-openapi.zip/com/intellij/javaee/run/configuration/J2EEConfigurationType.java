/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.run.configuration;

import com.intellij.execution.configurations.ConfigurationFactory;
import com.intellij.execution.configurations.ConfigurationType;
import com.intellij.execution.configurations.RunConfiguration;
import com.intellij.openapi.project.Project;
import com.intellij.javaee.J2EEBundle;

public abstract class J2EEConfigurationType implements ConfigurationType {
  private final ConfigurationFactory myRemoteFactory;
  private final ConfigurationFactory myLocalFactory;

  protected J2EEConfigurationType() {


    myRemoteFactory = new MyConfigurationFactory(false, J2EEBundle.message("run.configuration.remote"));
    myLocalFactory = new MyConfigurationFactory(true, J2EEBundle.message("run.configuration.local"));

  }

  protected abstract RunConfiguration createJ2EEConfigurationTemplate(ConfigurationFactory factory,
                                                                      Project project,
                                                                      boolean isLocal);

  public void initComponent() {
  }

  public void disposeComponent() {
  }

  public ConfigurationFactory[] getConfigurationFactories() {
    return new ConfigurationFactory[]{myLocalFactory, myRemoteFactory};
  }

  private class MyConfigurationFactory extends ConfigurationFactory {
    private final boolean myIsLocal;
    private final String myName;

    public MyConfigurationFactory(boolean isLocal, String name) {
      super(J2EEConfigurationType.this);
      myIsLocal = isLocal;
      myName = name;
    }

    public RunConfiguration createConfiguration(String name, RunConfiguration template) {
      RunConfiguration configuration = super.createConfiguration(name, template);
      ((CommonModel)configuration).initialize();
      return configuration;
    }

    public RunConfiguration createTemplateConfiguration(Project project) {
      return createJ2EEConfigurationTemplate(this, project, myIsLocal);
    }

    public String getName() {
      return myName;
    }
  }
}
