package com.intellij.javaee.run.localRun;

import com.intellij.execution.configurations.RunnerSettings;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.javaee.run.configuration.CommonModel;
import org.jetbrains.annotations.Nullable;

/**
 * @author nik
 */
public abstract class ScriptHelper {

  @Nullable 
  public abstract ExecutableObject getDefaultScript(CommonModel commonModel);

  public void checkRunnerSettings(RunnerSettings runnerSettings) throws RuntimeConfigurationException {
  }

  public void initRunnerSettings(RunnerSettings runnerSettings) {
  }
}
