/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.run.localRun;

import com.intellij.execution.configurations.GeneralCommandLine;
import com.intellij.openapi.util.SystemInfo;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.io.IOException;

public class ScriptUtil {
  private ScriptUtil() {

  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  public static void appendEnvVariableDeclaration(String name, String value, StringBuffer buffer) {
    if (SystemInfo.isWindows) {
      buffer.append("SET ");
    }
    buffer.append(name);
    buffer.append("=");
    buffer.append(value);
    buffer.append("\n");

    if (SystemInfo.isUnix) {
      buffer.append("export ");
      buffer.append(name);
      buffer.append("\n");
    }
  }

  public static void appendEnvVariableReference(String name, StringBuffer buffer) {
    if (SystemInfo.isWindows) {
      buffer.append("%");
      buffer.append(name);
      buffer.append("%");
    }
    else {
      buffer.append("${");
      buffer.append(name);
      buffer.append("}");
    }
  }

  public static File createScriptFile(final File directory, final String fileName) throws IOException {
    File result = new File(directory, fileName + "." + getScriptExtension());
    result.createNewFile();
    makeExecutable(result);
    return result;
  }

  public static void makeExecutable(final File result) throws IOException {
    if (SystemInfo.isUnix) {
      @NonNls final String[] cmdarray = new String[]{
        "chmod",
        "u+x",
        result.getAbsolutePath()
      };
      Process process = Runtime.getRuntime().exec(cmdarray);
      try {
        process.waitFor();
      }
      catch (InterruptedException e) {
      }
    }
  }

  public static @NonNls String getScriptExtension() {
    if (SystemInfo.isWindows) {
      return "cmd";
    }
    else {
      return "sh";
    }
  }

  public static GeneralCommandLine createCommandLine(final String[] parameters) {
    GeneralCommandLine commandLine = new GeneralCommandLine();
    if (SystemInfo.isOS2) {
      commandLine.setExePath("cmd");
      commandLine.addParameter("/c");
    }
    else if (SystemInfo.isWindows) {
      if (!SystemInfo.isWindows9x) {
        commandLine.setExePath("cmd");
      }
      else {
        commandLine.setExePath("command.com");
      }
      commandLine.addParameter("/c");

      /*if exe-path and at least one of parameters contain spaces the whole command must be quoted,
         e.g. instead of
            cmd /c "C:\Program Files\jdk1.5\bin\java" "-Dproperty=a b c" myclass
         must be used
            cmd /c ""C:\Program Files\jdk1.5\bin\java" "-Dproperty=a b c" myclass"
      */
      boolean quoteWholeCommand = false;
      for (int i = 1; i < parameters.length; i++) {
        quoteWholeCommand |= parameters[i].contains(" ");
      }
      quoteWholeCommand &= parameters.length > 0 && parameters[0].contains(" ");

      if (quoteWholeCommand) {
        StringBuilder builder = new StringBuilder();
        builder.append('"');
        for (int i = 0; i < parameters.length; i++) {
          if (i > 0) {
            builder.append(' ');
          }
          builder.append(GeneralCommandLine.quote(parameters[i]));
        }
        builder.append('"');

        commandLine.addParameter(builder.toString());
        return commandLine;
      }
    }

    int firstParamIdx = 0;
    if (SystemInfo.isUnix) {

      commandLine.setExePath(parameters[0]);
      firstParamIdx = 1;
    }

    for (int i = firstParamIdx; i < parameters.length; i++) {
      commandLine.addParameter(parameters[i]);
    }

    return commandLine;
  }
}