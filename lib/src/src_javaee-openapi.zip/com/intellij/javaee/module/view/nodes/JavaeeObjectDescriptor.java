/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.module.view.nodes;

import com.intellij.ide.DeleteProvider;
import com.intellij.ide.util.treeView.NodeDescriptor;
import com.intellij.jam.view.DefaultUserResponse;
import com.intellij.jam.view.JamDeleteProvider;
import com.intellij.javaee.CommonModelManager;
import com.intellij.javaee.model.annotations.JamElement;
import com.intellij.javaee.model.common.CommonModelElement;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.fileEditor.OpenFileDescriptor;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.pom.Navigatable;
import com.intellij.psi.PsiFile;
import com.intellij.psi.xml.XmlFile;
import com.intellij.ui.SimpleTextAttributes;
import com.intellij.util.ReflectionCache;
import com.intellij.util.xml.DomElement;
import org.jetbrains.annotations.Nullable;

public abstract class JavaeeObjectDescriptor <P extends CommonModelElement> extends JavaeeNodeDescriptor<P> {

  protected JavaeeObjectDescriptor(P element, NodeDescriptor parentDescriptor, Object parameters) {
    super(parentDescriptor.getProject(), parentDescriptor, parameters, element);
  }

  protected JavaeeObjectDescriptor(P element, Project project, Object parameters) {
    super(project, null, parameters, element);
  }

  public DeleteProvider getDeleteProvider() {
    final DefaultUserResponse response = new DefaultUserResponse(myProject);
    return new JamDeleteProvider(getElement(), response);
  }

  public P updateElement() {
    P element = getElement();
    if (!element.isValid()) return null;
    return getElement();
  }

  public String getNewTooltip() {
    return null;
  }

  public boolean isValid() {
    return getElement().isValid();
  }

  protected void doUpdate() {
    super.doUpdate();
    final String textExt = getNewNodeTextExt();
    if (StringUtil.isNotEmpty(textExt)) {
      addColoredFragment(" (" + textExt + ")", SimpleTextAttributes.GRAY_ITALIC_ATTRIBUTES);
    }
  }

  @Nullable
  protected String getNewNodeTextExt() {
    return null;
  }

  public Object getData(final String dataId) {
    if (DataConstants.NAVIGATABLE.equals(dataId)) {
      final Object navigatable = getNavigatable();
      if (navigatable != null) {
        return navigatable;
      }
    }
    if (DataConstants.PSI_ELEMENT.equals(dataId)) {
      final P element = getElement();
      return element.isValid() ? element.getIdentifyingPsiElement() : null;
    }
    if (DataConstants.MODULE.equals(dataId)) {
      return getParentElementOfType(Module.class);
    }
    return super.getData(dataId);
  }

  @Nullable
  public <T> T getParentElementOfType(final Class<T> elementClass) {
    for (NodeDescriptor cur = this; cur != null; cur = cur.getParentDescriptor()) {
      final Object element = cur.getElement();
      if (element != null && ReflectionCache.isAssignable(elementClass, element.getClass())) {
        return (T)element;
      }
    }
    return null;
  }

  @Nullable
  protected Navigatable getNavigatable() {

    final DomElement domElement = CommonModelManager.getInstance().getDomElement(getElement());
    if (domElement != null && domElement.getXmlTag() != null) {
      final XmlFile file = domElement.getRoot().getFile();
      final VirtualFile virtualFile = file.getVirtualFile();
      if (virtualFile != null && virtualFile.isValid()) {
        return new OpenFileDescriptor(file.getManager().getProject(), virtualFile, domElement.getXmlTag().getTextRange().getStartOffset());
      }
    }
    final JamElement annoElement = CommonModelManager.getInstance().getJamElement(getElement());
    if (annoElement != null && annoElement.getIdentifyingAnnotation() != null) {
      final PsiFile file = annoElement.getIdentifyingAnnotation().getContainingFile();
      final VirtualFile virtualFile = file.getVirtualFile();
      if (virtualFile != null && virtualFile.isValid()) {
        return new OpenFileDescriptor(file.getManager().getProject(), virtualFile, annoElement.getIdentifyingAnnotation().getTextRange().getStartOffset());
      }
    }
    return null;
  }
}
