/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.module;

import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.openapi.deployment.ContainerElement;
import com.intellij.openapi.deployment.LibraryLink;
import com.intellij.openapi.deployment.PackagingConfiguration;
import com.intellij.openapi.deployment.PackagingMethod;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.roots.libraries.Library;
import com.intellij.openapi.roots.ui.configuration.FacetsProvider;
import com.intellij.openapi.roots.ui.configuration.ModulesProvider;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author nik
 */
public interface JavaeePackagingConfiguration extends PackagingConfiguration {

  JavaeeFacetLink[] getFacetLinks();

  JavaeeFacet[] getContainingFacets();

  @Nullable
  JavaeeFacetLink findFacetLink(@NotNull JavaeeFacet facet);

  ContainerElement[] getElements(ModulesProvider provider, final FacetsProvider facetsProvider,
                                 final boolean includeResolved, final boolean includeUnresolved, final boolean includeNonPackaged);


  void addLibraryLink(Library library);
  void addLibraryLink(Library library, PackagingMethod packagingMethod, @NonNls String relativeOutputPath);
  void addModuleLink(Module module, PackagingMethod packagingMethod, @NonNls String relativeOutputPath);
  JavaeeFacetLink addFacetLink(JavaeeFacet facet, @NonNls String relativeOutputPath);

  void removeAllElements();
  void removeLibraryLink(@NotNull LibraryLink link);
  void removeModuleLink(@NotNull Module module);
  void removeFacetLink(@NotNull JavaeeFacet facet);
  void removeFacetLink(@NotNull JavaeeFacetLink link);

}