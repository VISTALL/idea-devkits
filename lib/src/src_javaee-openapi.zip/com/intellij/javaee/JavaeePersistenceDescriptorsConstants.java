/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee;

import com.intellij.javaee.model.common.persistence.JavaeePersistenceConstants;
import com.intellij.jpa.JpaMessages;
import com.intellij.util.descriptors.ConfigFileVersion;
import com.intellij.util.descriptors.ConfigFileMetaData;

/**
 * @author Gregory.Shrago
 */
public interface JavaeePersistenceDescriptorsConstants {
  String PERSISTENCE_VERSION_1_0 = "1.0";

  String ORM_VERSION_1_0 = "1.0";


  ConfigFileVersion[] PERSISTENCE_XML_VERSIONS = {
    new ConfigFileVersion(PERSISTENCE_VERSION_1_0, JavaeePersistenceConstants.PERSISTENCE_XML_1_0)
  };
  ConfigFileMetaData PERSISTENCE_XML_META_DATA =
    new ConfigFileMetaData(JpaMessages.message("deployment.descriptor.title.persistence.xml"), "persistence.xml", "META-INF",
                           PERSISTENCE_XML_VERSIONS, null, false, true, true);


  ConfigFileVersion[] ORM_XML_VERSIONS = {
    new ConfigFileVersion(ORM_VERSION_1_0, JavaeePersistenceConstants.ORM_XML_1_0)
  };
  ConfigFileMetaData ORM_XML_META_DATA =
    new ConfigFileMetaData(JpaMessages.message("deployment.descriptor.title.orm.xml"), "orm.xml", "META-INF", ORM_XML_VERSIONS, null, true,
                           true, true);

}
