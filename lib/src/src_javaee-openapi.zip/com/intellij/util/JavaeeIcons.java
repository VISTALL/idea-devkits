/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.util;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

/**
 * @author peter
 */
public class JavaeeIcons {

  public static final Icon SESSION_BEAN = IconLoader.getIcon("/javaee/sessionBean.png");
  public static final Icon SESSION_BEAN_BIG = IconLoader.getIcon("/javaee/sessionBeanBig.png");
  public static final Icon ENTITY_BEAN = IconLoader.getIcon("/javaee/entityBean.png");
  public static final Icon ENTITY_BEAN_BIG = IconLoader.getIcon("/javaee/entityBeanBig.png");
  public static final Icon MESSAGE_BEAN = IconLoader.getIcon("/javaee/messageBean.png");
  public static final Icon MESSAGE_BEAN_BIG = IconLoader.getIcon("/javaee/messageBeanBig.png");

  public static final Icon EJB_ICON = Icons.EJB_ICON;

  public static final Icon EJB_CLASS_ICON = Icons.EJB_CLASS_ICON;
  public static final Icon EJB_HOME_INTERFACE_ICON = Icons.EJB_HOME_INTERFACE_ICON;
  public static final Icon EJB_LOCAL_HOME_INTERFACE_ICON = Icons.EJB_LOCAL_HOME_INTERFACE_ICON;
  public static final Icon EJB_LOCAL_INTERFACE_ICON = Icons.EJB_LOCAL_INTERFACE_ICON;
  public static final Icon EJB_REMOTE_INTERFACE_ICON = Icons.EJB_REMOTE_INTERFACE_ICON;

  public static final Icon EJB_INTERCEPTOR_CLASS_ICON = IconLoader.getIcon("/javaee/interceptorClass.png");
  public static final Icon EJB_INTERCEPTOR_METHOD_ICON = IconLoader.getIcon("/javaee/interceptorMethod.png");

  public static final Icon EJB_CREATE_METHOD_ICON = Icons.EJB_CREATE_METHOD_ICON;
  public static final Icon EJB_FINDER_METHOD_ICON = Icons.EJB_FINDER_METHOD_ICON;
  public static final Icon EJB_BUSINESS_METHOD_ICON = Icons.EJB_BUSINESS_METHOD_ICON;
  public static final Icon EJB_CMP_FIELD_ICON = Icons.EJB_CMP_FIELD_ICON;
  public static final Icon EJB_FIELD_PK = Icons.EJB_FIELD_PK;
  public static final Icon EJB_CMR_FIELD_ICON = Icons.EJB_CMR_FIELD_ICON;
  public static final Icon EJB_PRIMARY_KEY_CLASS = Icons.EJB_PRIMARY_KEY_CLASS;
  public static final Icon EJB_REFERENCE = Icons.EJB_REFERENCE;

  public static final Icon JPA_ICON = IconLoader.getIcon("/actions/addJpaSupport.png");

  public static final Icon RELATIONSHIP_ICON = IconLoader.getIcon("/javaee/persistenceRelationship.png");
  public static final Icon ID_RELATIONSHIP_ICON = IconLoader.getIcon("/javaee/persistenceIdRelationship.png");
  public static final Icon ATTRIBUTE_ICON = IconLoader.getIcon("/javaee/persistenceAttribute.png");
  public static final Icon ID_ATTRIBUTE_ICON = IconLoader.getIcon("/javaee/persistenceId.png");
  public static final Icon ENTITY_ICON = IconLoader.getIcon("/javaee/persistenceEntity.png");
  public static final Icon MAPPED_SUPERCLASS_ICON = IconLoader.getIcon("/javaee/persistenceMappedSuperclass.png");
  public static final Icon EMBEDDABLE_ICON = IconLoader.getIcon("/javaee/persistenceEmbeddable.png");
  public static final Icon ENTITY_LISTENER_ICON = IconLoader.getIcon("/javaee/persistenceEntityListener.png");
  public static final Icon PERSISTENCE_UNIT_ICON = IconLoader.getIcon("/javaee/persistenceUnit.png");

  public static final Icon DATASOURCE_ICON = Icons.DATASOURCE_ICON;
  public static final Icon DATASOURCE_DISABLED_ICON = Icons.DATASOURCE_DISABLED_ICON;
  public static final Icon DATASOURCE_TABLE_ICON = Icons.DATASOURCE_TABLE_ICON;
  public static final Icon DATASOURCE_VIEW_ICON = Icons.DATASOURCE_VIEW_ICON;
  public static final Icon DATASOURCE_SEQUENCE_ICON = Icons.DATASOURCE_SEQUENCE_ICON;
  public static final Icon DATASOURCE_COLUMN_ICON = Icons.DATASOURCE_COLUMN_ICON;
  public static final Icon DATASOURCE_FK_COLUMN_ICON = Icons.DATASOURCE_FK_COLUMN_ICON;
  public static final Icon DATASOURCE_PK_COLUMN_ICON = Icons.DATASOURCE_PK_COLUMN_ICON;

  public static final Icon DATASOURCE_REMOTE_INSTANCE = Icons.DATASOURCE_REMOTE_INSTANCE;

  public static final Icon JAVA_MODULE_GROUP = IconLoader.getIcon("/javaee/javaModuleGroup.png");

  public static final Icon EJB_JAR = IconLoader.getIcon("/javaee/ejb-jar_xml.png");
  public static final Icon EJB_MODULE_GROUP = IconLoader.getIcon("/javaee/ejbModuleGroup.png");
  public static final Icon EJB_MODULE_BIG = IconLoader.getIcon("/javaee/ejbModuleBig.png");
  public static final Icon EJB_MODULE_SMALL = IconLoader.getIcon("/javaee/ejbModule.png");

  public static final Icon APPLICATION_XML = IconLoader.getIcon("/javaee/application_xml.png");
  public static final Icon APP_MODULE_GROUP = IconLoader.getIcon("/javaee/JavaeeAppModuleGroup.png");
  public static final Icon APP_MODULE_BIG = IconLoader.getIcon("/javaee/JavaeeAppModuleBig.png");
  public static final Icon APP_MODULE_SMALL = IconLoader.getIcon("/javaee/JavaeeAppModule.png");

  public static final Icon WEB_XML = IconLoader.getIcon("/javaee/web_xml.png");
  public static final Icon WEB_MODULE_GROUP = IconLoader.getIcon("/javaee/webModuleGroup.png");
  public static final Icon WEB_MODULE_BIG = IconLoader.getIcon("/javaee/webModuleBig.png");
  public static final Icon WEB_MODULE_SMALL = IconLoader.getIcon("/javaee/webModule.png");


  public static final Icon WEB_FOLDER_OPEN = Icons.WEB_FOLDER_OPEN;
  public static final Icon WEB_FOLDER_CLOSED = Icons.WEB_FOLDER_CLOSED;

  public static final Icon EJBQL_METHOD_GUTTER_ICON = IconLoader.getIcon("/gutter/implementedMethod.png");
  public static final Icon PROPERTIES_ICON = IconLoader.getIcon("/actions/properties.png");
  public static final Icon SYNCHRONIZE_ICON = IconLoader.getIcon("/actions/sync.png");
  public static final Icon SELECT_ALL_ICON = IconLoader.getIcon("/actions/selectall.png");
  public static final Icon UNSELECT_ALL_ICON = IconLoader.getIcon("/actions/unselectall.png");
  
  public static final Icon DB_SCHEMA_IMPORT_BIG = IconLoader.getIcon("/javaee/dbSchemaImportBig.png");
}
