/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.util.projectImport;

import com.intellij.javaee.appServerIntegrations.ApplicationServerHelper;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.extensions.ExtensionPointName;
import org.jetbrains.annotations.Nullable;

/**
 * User: anna
 * Date: May 23, 2005
 */
public abstract class JBuilderJavaeeProjectImportHelper {
  public static final ExtensionPointName<JBuilderJavaeeProjectImportHelper> EXTENSION_POINT = ExtensionPointName.create("com.intellij.javaee.jbuilderImportHelper");

  /**
   * to process application servers available via plugins
   * @param homepath directory with server instance
   * @param version version of server instance
   * @return null if specified home and directory don't correspond to a valid server instance
   *         a pair of ApplicationServerHelper and the AppServerIntegration.getPresentableName() for a given server instance
   */
  @Nullable
  public abstract Pair<? extends ApplicationServerHelper, String> getAppServerHelperWithIntegrationName(String homepath, String version);


}
