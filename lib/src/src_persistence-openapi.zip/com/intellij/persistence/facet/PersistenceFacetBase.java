/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.persistence.facet;

import com.intellij.facet.Facet;
import com.intellij.facet.FacetType;
import com.intellij.lang.Language;
import com.intellij.openapi.module.Module;
import com.intellij.persistence.model.PersistenceMappings;
import com.intellij.persistence.model.PersistencePackage;
import com.intellij.persistence.model.validators.ModelValidator;
import com.intellij.util.descriptors.ConfigFile;
import com.intellij.util.descriptors.ConfigFileContainer;
import com.intellij.util.descriptors.ConfigFileMetaData;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;

/**
 * @author Gregory.Shrago
 */
public abstract class PersistenceFacetBase<C extends PersistenceFacetConfiguration, Unit extends PersistencePackage> extends Facet<C> {
                 
  public PersistenceFacetBase(@NotNull final FacetType facetType, @NotNull final Module module, final String name, @NotNull final C configuration,
                              Facet underlyingFacet) {
    super(facetType, module, name, configuration, underlyingFacet);
  }

  public abstract ConfigFile[] getDescriptors();

  public abstract ConfigFileContainer getDescriptorsContainer();

  @NotNull
  public abstract List<Unit> getPersistenceUnits();

  @Nullable
  public abstract PersistenceMappings getAnnotationEntityMappings();

  @NotNull
  public abstract PersistenceMappings getEntityMappings(@NotNull final Unit unit);

  @NotNull
  public abstract List<? extends PersistenceMappings> getDefaultEntityMappings(@NotNull final Unit unit);

  @NotNull
  public abstract Class<? extends PersistencePackage> getPersistenceUnitClass();

  @NotNull
  public abstract Map<ConfigFileMetaData,Class<? extends PersistenceMappings>> getSupportedDomMappingFormats();

  public abstract String getDataSourceId(@NotNull final Unit unit);

  public abstract void setDataSourceId(@NotNull final Unit unit, final String dataSourceId);

  @Nullable
  public abstract Language getQlLanguage();

  @NotNull
  public abstract ModelValidator getModelValidator(@Nullable final Unit unit);

  @NotNull
  public abstract Class[] getInspectionToolClasses();

  @NotNull
  public abstract PersistencePackageDefaults getPersistenceUnitDefaults(@NotNull final Unit unit);

}
