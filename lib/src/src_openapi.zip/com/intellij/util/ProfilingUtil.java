/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.util;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.util.io.FileUtil;
import com.yourkit.api.Controller;
import com.yourkit.api.ProfilingModes;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ProfilingUtil {
  private static final Logger LOG = Logger.getInstance("#com.intellij.util.ProfilingUtil");

  private static final Controller ourController = initController();
  private static boolean ourCPUProfilingInProgress;

  private ProfilingUtil() {
  }

  @Nullable
  private static Controller initController() {
    try {
      return new Controller();
    }
    catch (Exception ex) {
      LOG.info("Profiling agent is not enabled. Add -agentlib:yjpagent to idea.vmoptions if necessary to profile IDEA.");
      return null;
    }
  }

  public static boolean hasValidController() {
    return ourController != null;
  }

  public static void operationStarted(@NonNls String name) {
    try {
      if (profilingEnabled(name) && hasValidController()) {
        startCPUProfiling();
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static void startCPUProfiling() {
    startCPUProfiling(tracingEnabled());
  }

  public static void startCPUProfiling(final boolean withCounts) {
    try {
      if (hasValidController() && !ourCPUProfilingInProgress) {
        ourCPUProfilingInProgress = true;
        ourController.startCPUProfiling(withCounts ? ProfilingModes.CPU_TRACING : ProfilingModes.CPU_SAMPLING, null);
      }
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  public static void stopCPUProfiling() {
    try {
      if (hasValidController()) {
        if (ourCPUProfilingInProgress) {
          ourController.stopCPUProfiling();
          ourCPUProfilingInProgress = false;
        }
        else {
          System.err.println("Nested profiling request ignored");
        }
      }
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  public static String captureCPUSnapshot() {
    try {
      if (hasValidController()) {
        if (ourCPUProfilingInProgress) {
          ourCPUProfilingInProgress = false;
          final String result = ourController.captureSnapshot(ProfilingModes.SNAPSHOT_WITHOUT_HEAP);
          ourController.stopCPUProfiling();
          return result;
        }
        else {
          System.err.println("Nested profiling request ignored");
        }
      }

      return null;
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  public static void operationFinished(@NonNls String name) {
    try {
      if (profilingEnabled(name) && hasValidController()) {
        captureCPUSnapshot();
        captureMemorySnapshot(name);
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }


  public static void captureMemorySnapshot(String name) {
    LOG.info("captureMemorySnapshot(\"" + name + "\") called");
    if (captureMemorySnapshot() && profilingEnabled(name)) {
      LOG.info("Taking memory snapshot");
      forceCaptureMemorySnapshot();
      try {
        ourController.stopAllocationRecording();
      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  public static String forceCaptureMemorySnapshot() {
    if (hasValidController()) {
      try {
        return ourController.captureMemorySnapshot();
      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }
    return null;
  }

  public static void startRecordAllocations() {
    if (hasValidController()) {
      try {
        ourController.startAllocationRecording(ProfilingModes.ALLOCATION_RECORDING_ALL);
      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  public static void stopRecordAllocations() {
    if (hasValidController()) {
      try {
        ourController.stopAllocationRecording();
      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  public static String createDumpFileName(String buildNumber) {
    StringBuffer result = new StringBuffer(30);
    result.append(buildNumber).append('_');
    result.append(SystemProperties.getUserName()).append('_');
    result.append(new SimpleDateFormat("dd.MM.yyyy_HH.mm.ss").format(new Date()));
    return result.toString();
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  private static boolean captureMemorySnapshot() {
    String p = System.getProperty("profile.memory");
    return p != null && p.equals("true");
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  private static boolean tracingEnabled() {
    String p = System.getProperty("profile.trace");
    return p != null && p.equals("true");
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  private static boolean profilingEnabled(String name) {
    String p = System.getProperty("profile." + name);
    return p != null && p.equals("true");
  }

  public static void compressAndRemoveDataFile(@NonNls String dumpFilePath, final String outputFileName, @NonNls String ext) {
    String path = SystemProperties.getUserHome();
    path += File.separator;

    File dumpFile = new File(dumpFilePath);
    if (!dumpFile.exists()) return;

    InputStream is = null;
    ZipOutputStream zip = null;

    try {
      is = new FileInputStream(dumpFile);
      //noinspection HardCodedStringLiteral
      zip = new ZipOutputStream(new FileOutputStream(path + outputFileName + ".zip"));
      zip.putNextEntry(new ZipEntry(outputFileName + ext));
      FileUtil.copy(is, zip);
      zip.closeEntry();
    }
    catch (IOException ex) {
      ex.printStackTrace();
    }
    finally {
      try {
        if (is != null) is.close();
      }
      catch (IOException ex) {
      }

      try {
        if (zip != null) zip.close();
      }
      catch (IOException ex) {
      }

      FileUtil.delete(dumpFile);
    }
  }
}
