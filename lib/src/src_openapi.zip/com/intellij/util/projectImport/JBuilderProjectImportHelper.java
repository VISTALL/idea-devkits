/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.util.projectImport;

import com.intellij.openapi.module.ModifiableModuleModel;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleWithNameAlreadyExists;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.project.impl.importProject.jbuilder.JBuilderProjectSettings;
import com.intellij.openapi.projectRoots.Sdk;
import com.intellij.openapi.projectRoots.SdkAdditionalData;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.extensions.ExtensionPointName;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;

/**
 * User: anna
 * Date: May 23, 2005
 */
public abstract class JBuilderProjectImportHelper {
  public static final ExtensionPointName<JBuilderProjectImportHelper> EXTENSION_POINT = ExtensionPointName.create("com.intellij.jbuilderImportHelper");

  //to process sdk types available via plugins
  @Nullable public SdkAdditionalData additionalJDKDataProcessing(Sdk jdk, File jdkFile){
    return null;
  }

  //to process module types available via plugins
  @Nullable public Module additionalModuleTypeProcessing(Element moduleElement,
                                                         ModifiableModuleModel moduleModel,
                                                         final Module dependOn,
                                                         final JBuilderProjectSettings projectSettings)
                                                                                throws InvalidDataException, ConfigurationException, IOException, ModuleWithNameAlreadyExists, JDOMException {
    return null;
  }

  public void initComponent() {
  }

  public void disposeComponent() {
  }
}
