/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.localVcs.fileView;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.localVcs.LocalVcs;
import com.intellij.openapi.localVcs.LvcsObject;
import com.intellij.openapi.localVcs.LocalVcsBundle;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.vcs.FileStatus;
import com.intellij.openapi.vcs.fileView.FileViewAdditionalColumn;
import com.intellij.openapi.vcs.fileView.FileViewEnvironment;
import com.intellij.openapi.vcs.fileView.VcsFile;
import com.intellij.openapi.vfs.VirtualFile;

import java.util.ArrayList;
import java.util.Collection;

public class LvcsFileViewEnvironment implements FileViewEnvironment{
  private final Project myProject;

  public LvcsFileViewEnvironment(Project project) {
    myProject = project;
  }

  public FileViewAdditionalColumn[] getAdditionalColumns() {
    return new FileViewAdditionalColumn[]{
      new FileViewAdditionalColumn() {
        public String getText() {
          return LocalVcsBundle.message("column.name.file.view.file.date");
        }

        public Comparable getValue(VcsFile file) {
          return ((LvcsVcsObject)file).getDate();
        }
      }
    };
  }

  public String getHelpId() {
    return null;
  }

  public VcsFile[] createOn(VirtualFile[] files, ProgressIndicator progress) {
    Collection<VcsFile> result = new ArrayList<VcsFile>();
    LocalVcs localVcs = LocalVcs.getInstance(myProject);
    for (int i = 0; i < files.length; i++) {
      final VirtualFile file = files[i];
      String filePath = ApplicationManager.getApplication().runReadAction(new Computable<String>() {
              public String compute() {
                return file.getPath();
              }
            });
      LvcsObject lvcsObject = file.isDirectory() ? localVcs.findDirectory(filePath, true)
        : (LvcsObject)localVcs.findFile(filePath, true);
      if (lvcsObject != null) result.add(LvcsVcsObject.createOn(lvcsObject, myProject));
    }
    return result.toArray(new VcsFile[result.size()]);
  }

  public void onRefreshFinished() {

  }

  public void onRefreshStarted() {

  }

  public FileStatus[] getAdditionalStatuses() {
    return new FileStatus[0];
  }
}
