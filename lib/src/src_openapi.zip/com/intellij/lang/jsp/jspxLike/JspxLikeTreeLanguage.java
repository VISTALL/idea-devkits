package com.intellij.lang.jsp.jspxLike;

import com.intellij.lang.Language;
import com.intellij.lang.ParserDefinition;
import org.jetbrains.annotations.Nullable;

public class JspxLikeTreeLanguage extends Language {
  public JspxLikeTreeLanguage() {
    super("JSPX like");
  }

  @Nullable
  public ParserDefinition getParserDefinition() {
    return JspxLikeTreeParserDefinition.getInstance();
  }
}
