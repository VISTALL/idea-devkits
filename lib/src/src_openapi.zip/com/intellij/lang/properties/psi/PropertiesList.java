/*
 * @author max
 */
package com.intellij.lang.properties.psi;

import com.intellij.psi.StubBasedPsiElement;

public interface PropertiesList extends StubBasedPsiElement<PropertiesListStub> {
}