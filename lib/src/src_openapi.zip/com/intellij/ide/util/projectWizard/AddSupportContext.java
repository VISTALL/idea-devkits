/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.intellij.ide.util.projectWizard;

import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.*;
import com.intellij.openapi.roots.libraries.Library;
import com.intellij.openapi.roots.libraries.LibraryTable;
import com.intellij.openapi.roots.libraries.LibraryTablesRegistrar;
import com.intellij.openapi.roots.libraries.LibraryUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiFile;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;

/**
 * @author Dmitry Avdeev
 */
public abstract class AddSupportContext {

  protected boolean myAddSupport;

  protected final boolean myInsideAddModuleWizard;
  @NotNull
  protected VirtualFile[] myJars = VirtualFile.EMPTY_ARRAY;
  @Nullable
  protected Library myLibrary;
  @Nullable
  protected final Project myProject;
  @NonNls
  private final String myLibraryName;

  public AddSupportContext(@NonNls String libraryName, @Nullable Project project, boolean insideAddModuleWizard) {
    myInsideAddModuleWizard = insideAddModuleWizard;
    myProject = project;
    myLibraryName = libraryName;
    myAddSupport = !insideAddModuleWizard;
  }

  /**
   * The method should be always invoked in context of WriteAction
   * @param module the
   * @param rootModel root model
   * @see #installSupportInAction(com.intellij.openapi.module.Module, com.intellij.openapi.roots.ModifiableRootModel)
   */
  public abstract void installSupport(final Module module, final ModifiableRootModel rootModel);

  public void installSupportInAction(final Module module, final ModifiableRootModel rootModel) {
    new WriteCommandAction.Simple(module.getProject(), getPotentiallyModifiedFiles(module)) {

      protected void run() throws Throwable {
        installSupport(module, rootModel);
      }
    }.execute();
  }

  protected PsiFile[] getPotentiallyModifiedFiles(Module module) {
    return PsiFile.EMPTY_ARRAY;
  }

  public void setAddSupport(final boolean addSupport) {
    myAddSupport = addSupport;
  }

  public boolean isAddSupport() {
    return myAddSupport;
  }

  public boolean isInsideAddModuleWizard() {
    return myInsideAddModuleWizard;
  }

  @NotNull
  public LibraryInfo[] getRequiredLibraries() {
    return LibraryInfo.EMPTY_ARRAY;
  }

  @Nullable
  public Library getLibrary() {
    return myLibrary;
  }

  public void setLibrary(final @Nullable Library library) {
    myLibrary = library;
  }

  public void setJars(final VirtualFile[] jars) {
    myJars = jars;
  }

  @NotNull
  public VirtualFile[] getJars() {
    return myJars;
  }

  @Nullable
  public Project getProject() {
    return myProject;
  }

  public String getLibraryName() {
    return myLibraryName;
  }

  protected Library getExistentOrCreateNewLibrary(final Project project) {
    Library library;
    if (myLibrary != null) {
      library = myLibrary;
    } else {
      final LibraryTable libraryTable = LibraryTablesRegistrar.getInstance().getLibraryTable(project);
      library = LibraryUtil.createLibrary(libraryTable, getLibraryName());
    }
    final Library.ModifiableModel libraryModel = library.getModifiableModel();
    for (VirtualFile virtualFile : myJars) {
      libraryModel.addRoot(virtualFile, OrderRootType.CLASSES);
    }
    libraryModel.commit();
    return library;
  }

  /**
   * Adds {@link #myLibrary} to the given module.
   * This method is intended to be used in a custom {@link #installSupport(com.intellij.openapi.module.Module, com.intellij.openapi.roots.ModifiableRootModel)}
   * implementation.
   *
   * @param module module to add the entry
   * @param rootModel null if not in NewModuleWizard
   * @return created or existing library
   * @throws IOException io problem
   * @throws com.intellij.openapi.options.ConfigurationException configuration problem
   */
  public Library addLibrary(Module module, @Nullable ModifiableRootModel rootModel) throws IOException, ConfigurationException {
    final Project project = module.getProject();

    final Library library = getExistentOrCreateNewLibrary(project);
    ModifiableRootModel modifiableModel = rootModel;
    if (modifiableModel == null || !modifiableModel.isWritable()) {
      final ModuleRootManager rootManager = ModuleRootManager.getInstance(module);
      boolean found = false;
      for (OrderEntry entry: rootManager.getOrderEntries()) {
        if (entry instanceof LibraryOrderEntry && ((LibraryOrderEntry)entry).getLibrary() == library) {
          found = true;
        }
      }
      if (!found) {
        modifiableModel = rootManager.getModifiableModel();
        modifiableModel.addLibraryEntry(library);
        modifiableModel.commit();
      }
    } else {
      if (modifiableModel.findLibraryOrderEntry(library) == null) {
        modifiableModel.addLibraryEntry(library);
      }
    }
    return library;
  }
}
