/*
 * Copyright (c) 2000-2004 by JetBrains s.r.o. All Rights Reserved.
 * Use is subject to license terms.
 */
package com.intellij.coverage;

/**
 * @author Eugene Zhuravlev
 *         Date: Jul 7, 2006
 */
public interface CoverageFileProvider {
  
  String getCoverageDataFilePath();

  /**
   * @return true if the coverage file exists, false otherwise
   */
  boolean ensureFileExists();
}
