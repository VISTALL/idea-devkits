package com.intellij.openapi.util;

public abstract class Pass<T> {

  public abstract void pass(T t);

}