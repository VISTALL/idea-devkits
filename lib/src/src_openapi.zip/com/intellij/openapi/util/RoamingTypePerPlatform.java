package com.intellij.openapi.util;

public interface RoamingTypePerPlatform {
}
