package com.intellij.openapi.util;

public interface Getter<A> {
  
  A get();

}
