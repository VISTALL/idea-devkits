/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.jsf;

import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.jsf.model.FacesConfig;
import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.jsp.JspFile;
import com.intellij.psi.xml.XmlDocument;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.util.Set;

/**
 * @author peter
 */
public abstract class FacesManager {
  @NonNls public static final String FACES_CONFIG_FILENAME = "faces-config.xml";

  @NonNls public static final String FACES_CONFIG_DEFAULT_DIRECTORY = "WEB-INF";
  @NonNls public static final String FACES_CONFIG_RESOURCES_PATH = "META-INF/faces-config.xml";
  @NonNls public static final String FACES_CONFIG_DEFAULT_PATH = FACES_CONFIG_DEFAULT_DIRECTORY + "/" + FACES_CONFIG_FILENAME;
  @NonNls public static final String DTD_URI_1_1 = "http://java.sun.com/dtd/web-facesconfig_1_1.dtd";
  @NonNls public static final String DTD_URI_1_0 = "http://java.sun.com/dtd/web-facesconfig_1_0.dtd";

  @NonNls public static final String JSF_CONTEXT_PARAM = "javax.faces.CONFIG_FILES";
  @NonNls public static final String FACES_CONFIG_ROOT_TAGNAME = "faces-config";

  @NonNls public static final String JSF_CORE_TAGLIB_URI = "http://java.sun.com/jsf/core";
  @NonNls public static final String JSF_HTML_TAGLIB_URI = "http://java.sun.com/jsf/html";

  public static FacesManager getFacesManager() {
    return ServiceManager.getService(FacesManager.class);
  }

  @Deprecated
  public static FacesManager getFacesManager(Project project) {
    return getFacesManager();
  }

  @NotNull
  public abstract Set<XmlFile> getFacesConfigXmls(@NotNull WebFacet webFacet);

  public abstract boolean isFacesConfig(Project project, VirtualFile file);

  public abstract boolean isFacesPage(final JspFile jspFile);

  public abstract boolean isFacesEnabledFacet(WebFacet webFacet);

  @Nullable
  public abstract FacesConfig getFacesConfig(XmlFile xmlFile);

  public abstract boolean isFacesConfigResource(final VirtualFile file);

  @Nullable
  public abstract FacesConfig getFacesConfig(Project project, VirtualFile file);

  @Nullable
  public abstract FacesConfig getFacesConfig(WebFacet webFacet, VirtualFile file);

  public abstract FacesConfig getMergedFacesConfig(WebFacet webFacet);

  public abstract String getFacesConfigTemplateText(FacesVersion version) throws IOException;

  public abstract boolean isFacesComponentTag(XmlTag tag);

  @Nullable
  public abstract VirtualFile getDocRootElement(Module module);

  public static boolean isFacesDtd(final XmlFile xmlFile) {
    try {
      final String dtdUri = xmlFile.getDocument().getProlog().getDoctype().getDtdUri();

      return dtdUri != null && (dtdUri.equals(DTD_URI_1_0) || dtdUri.equals(DTD_URI_1_1));
    }
    catch (Exception e) {
      return false;
    }
  }

  public static boolean hasValidFacesConfigRoot(final XmlFile xmlFile) {
    final XmlDocument document = xmlFile.getDocument();
    if (document == null) {
      return false;
    }
    final XmlTag rootTag = document.getRootTag();
    return rootTag != null && FACES_CONFIG_ROOT_TAGNAME.equals(rootTag.getName());
  }
}
