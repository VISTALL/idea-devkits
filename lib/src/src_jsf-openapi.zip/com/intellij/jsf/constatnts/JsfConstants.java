package com.intellij.jsf.constatnts;

import org.jetbrains.annotations.NonNls;

/**
 * User: Sergey.Vasiliev
 */
public interface JsfConstants {
  @NonNls String FACES_CONFIG_FILENAME = "faces-config.xml";
  @NonNls String FACES_CONFIG_ROOT_TAGNAME = "faces-config";
  @NonNls String JSF_CONTEXT_PARAM = "javax.faces.CONFIG_FILES";

  // pathes
  @NonNls String FACES_CONFIG_DEFAULT_DIRECTORY = "WEB-INF";
  @NonNls String FACES_CONFIG_RESOURCES_PATH = "META-INF/faces-config.xml";
  @NonNls String FACES_CONFIG_DEFAULT_PATH = FACES_CONFIG_DEFAULT_DIRECTORY + "/" + FACES_CONFIG_FILENAME;

  //dtd
  @NonNls String DTD_URI_1_1 = "http://java.sun.com/dtd/web-facesconfig_1_1.dtd";
  @NonNls String DTD_URI_1_0 = "http://java.sun.com/dtd/web-facesconfig_1_0.dtd";

  //taglibs
  @NonNls String JSF_CORE_TAGLIB_URI = "http://java.sun.com/jsf/core";
  @NonNls String JSF_HTML_TAGLIB_URI = "http://java.sun.com/jsf/html";

  @NonNls String JSF_DATA_MODEL_CLASSNAME = "javax.faces.model.DataModel";

}
