/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.component;

import com.intellij.psi.PsiType;
import com.intellij.util.xml.*;

/**
 * The "property" element represents a JavaBean property of the Java class represented by our parent element.
 * Property names must be unique within the scope of the Java class that is represented by the parent element, and must correspond to property names
 * that will be recognized when performing introspection against that class via java.beans.Introspector.
 */
public interface Property extends FacesProperty {
  /**
   * The "property-name" element represents the JavaBeans property name under which the corresponding value may be stored.
   */
  @NameValue
  @Required
  GenericDomValue<String> getPropertyName();

/**
 * The "property-class" element represents the Java type of the value associated with this property name.
 * If not specified, it can be inferred from existing classes; however, this element should be specified
 * if the configuration file is going to be the source for generating the corresponding classes.
 */
  @Required
  @Convert(JvmPsiTypeConverter.class)
  GenericDomValue<PsiType> getPropertyClass();
}
