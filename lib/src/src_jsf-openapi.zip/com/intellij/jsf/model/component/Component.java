/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.component;

import com.intellij.jsf.model.FacesPresentationElement;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.NameValue;
import com.intellij.util.xml.Required;
import com.intellij.util.xml.ExtendClass;

/**
 * The "component" element represents a concrete javax.faces.component.Component
 * implementation class that should be registered under the specified type identifier,
 * along with its associated properties and attributes.
 * Component types must be unique within the entire web application.
 *
 * Nested "attribute" elements identify generic attributes that are recognized by the implementation logic of this component.
 * Nested "property" elements identify JavaBeans properties of the component class that may be exposed for manipulation via tools.
 */
public interface Component extends FacetsOwner, AttributesOwner, PropertiesOwner, FacesPresentationElement {
  /**
   *  The "component-type" element represents the name under which the corresponding Component class should be registered
   */
  @NameValue
  @Required
  GenericDomValue<String> getComponentType();

  /**
   *  The "component-class" represents the fully qualified class name of a concrete Component implementation class.
   */
  @Required
  @ExtendClass("javax.faces.component.UIComponent")
  GenericDomValue<PsiClass> getComponentClass();

  /**
   *  Extension element for component. May contain implementation specific content.
   */
  GenericDomValue<String> getComponentExtention();
}
