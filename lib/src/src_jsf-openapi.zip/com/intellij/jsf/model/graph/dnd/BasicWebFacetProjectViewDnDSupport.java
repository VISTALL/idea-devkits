package com.intellij.jsf.model.graph.dnd;

import com.intellij.javaee.web.WebUtil;
import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.openapi.graph.base.Node;
import com.intellij.openapi.graph.builder.GraphBuilder;
import com.intellij.openapi.graph.builder.dnd.ProjectViewDnDSupport;
import com.intellij.psi.PsiFile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * User: Sergey.Vasiliev
 */
public abstract class BasicWebFacetProjectViewDnDSupport <N,E>  implements ProjectViewDnDSupport<N, PsiFile> {

  private GraphBuilder<N,E> myBuilder;
  private WebFacet myFacetScope;

  public BasicWebFacetProjectViewDnDSupport(GraphBuilder<N,E> builder, @NotNull final WebFacet facetScope) {
    myBuilder = builder;
    myFacetScope = facetScope;
  }

  public boolean acceptDraggedElements(@NotNull final List<PsiFile> draggedFiles) {
    for (PsiFile draggedFile : draggedFiles) {
      if (!acceptDraggedFile(draggedFile)) return false;
    }
    return true;
  }

  @NotNull
  public List<N> dropElements(@NotNull final List<PsiFile> list) {
    List<N> nodeObjects = new ArrayList<N>();
    for (PsiFile file : list) {
      final String webPath = WebUtil.getWebUtil().getWebPath(file);
      if (webPath != null) {
        final N nodeObject = createNodeObject(webPath);
        if (nodeObject != null) nodeObjects.add(nodeObject);
      }
    }
    return nodeObjects;
  }

  protected boolean acceptDraggedFile(final PsiFile psiFile) {
    return myFacetScope.equals(WebUtil.getWebFacet(psiFile)) &&
           WebUtil.isInsideWebRoots(psiFile.getVirtualFile(), psiFile.getProject()) &&
           !isExistNode(psiFile);
  }

   protected boolean isExistNode(final PsiFile psiFile) {
    final String webPath = WebUtil.getWebUtil().getWebPath(psiFile);
    if (webPath != null) {
      for (Node node : myBuilder.getGraph().getNodeArray()) {
        final N nodeObject = myBuilder.getNodeObject(node);
        if (nodeObject != null && areNodesEquals(webPath, nodeObject)) return true;
      }
    }
    return false;
  }

  @Nullable
  protected abstract N createNodeObject(@NotNull final  String webPath);

  protected abstract boolean areNodesEquals(@NotNull final String webPath, @NotNull final N nodeObject);
}
