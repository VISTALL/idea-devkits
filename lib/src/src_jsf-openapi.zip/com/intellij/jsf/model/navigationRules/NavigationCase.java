/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.navigationRules;

import com.intellij.openapi.paths.PathReference;
import com.intellij.jsf.model.FacesPresentationElement;
import com.intellij.jsf.converters.FacesPathReferenceConverter;
import com.intellij.util.xml.*;

/**
 * The "navigation-case" element describes a particular combination of conditions
 * that must match for this case to be executed, and the view id of the component tree
 * that should be selected next.
 */
public interface NavigationCase extends FacesPresentationElement {
  /**
   * The "from-action" element contains an action reference expression that must have been executed
   * (by the default javax.faces.event.ActionListener for handling application level events) in order to select this navigation rule.
   * If not specified, this rule will be relevant no matter which action reference was executed (or if no action reference was executed).
   */
  GenericDomValue<String> getFromAction();

  /**
   * The "from-outcome" element contains a logical outcome string returned by the execution of an application
   * action method selected via an "actionRef" property (or a literal value specified by an "action" property)of a UICommand component.
   * If specified, this rule will be relevant only if the outcome value matches this element's value.
   * If not specified, this rule will be relevant no matter what the outcome value was.
   */
  GenericDomValue<String> getFromOutcome();

  /**
   * The "to-view" element contains the view identifier of the next view that should be displayed
   * if this navigation rule is matched.
   * It must be of type "ViewId".
   */
  @Convert(FacesPathReferenceConverter.class)
  @NameValue(unique = false)
  @Required
  GenericDomValue<PathReference> getToViewId();

  /**
   * The "redirect" element indicates that navigation to the specified "to-view-id" should be accomplished
   * by performing an HTTP redirect rather than the usual ViewHandler mechanisms.
   */
  @SubTag(indicator = true)
  GenericDomValue<Boolean> isRedirect();
}
