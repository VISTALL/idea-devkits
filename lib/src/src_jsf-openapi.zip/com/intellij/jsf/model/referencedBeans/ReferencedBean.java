/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.referencedBeans;

import com.intellij.jsf.model.FacesPresentationElement;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.NameValue;
import com.intellij.util.xml.Required;

/**
 * The "referenced-bean" element represents at design time the promise that a Java object
 * of the specified type will exist at runtime in some scope, under the specified key.
 * This can be used by design time tools to construct user interface dialogs based on the properties of the specified class.
 * The presence or absence of a referenced bean element has no impact on the JavaServer Faces
 * runtime environment inside a web application.
 */
public interface ReferencedBean extends FacesPresentationElement {
  /**
   * The "referenced-bean-name" element represents the attribute name
   * under which the corresponding referenced bean may be assumed to be stored,
   * in one of the scopes defined by the Scope type.
   */
  @NameValue
  @Required(identifier = true)
  GenericDomValue<String> getReferencedBeanName();

  /**
   * The "referenced-bean-class" element represents the fully qualified class name of the Java class (either abstract or concrete)
   * or Java interface implemented by the corresponding referenced bean.
   */
  @Required
  GenericDomValue<PsiClass> getReferencedBeanClass();
}
