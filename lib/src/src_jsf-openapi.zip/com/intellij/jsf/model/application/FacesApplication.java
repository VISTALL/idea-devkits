/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.application;

import com.intellij.jsf.model.FacesModelElement;
import com.intellij.jsf.model.renderKits.RenderKit;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.ExtendClass;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.Resolve;

/*
 *    The "application" provides a mechanism to define the various
 *    per-application-singleton implementation classes for a particular web application
 *    that is utilizing JavaServer Faces.
 *    For nested elements that are not specified,
 *    the JSF implementation must provide a suitable default.
 */

public interface FacesApplication extends FacesModelElement {
  /**
   * The base name of a resource bundle representing the message resources for this application. See the JavaDocs for the "java.util.ResourceBundle" class for more information on the syntax of resource bundle names.
   */
  GenericDomValue<String> getMessageBundle();

  /**
   * The "default-render-kit-id" element allows the application to define
   *  a renderkit to be used other than the standard one.
   */
  @Resolve(soft=true)
  GenericDomValue<RenderKit> getDefaultRenderKitId();

  /**
   * The "locale-config" allows the app developer to declare
   * the supported locales for this application.
   */
  LocaleConfig getLocaleConfig();

  /**
   * The "action-listener" element contains the fully qualified class name of the concrete
   * ActionListener implementation class that will be called during the Invoke Application phase
   * of the request processing lifecycle.
   */
  @ExtendClass(value = "javax.faces.event.ActionListener", canBeDecorator = true)
  GenericDomValue<PsiClass> getActionListener();

  /**
   * The "navigation-handler" contains the fully qualified class name of the concrete
   * javax.faces.application.NavigationHandler implementation class that will be called
   * during the Invoke Application phase of the request processing lifecycle,
   * if the default ActionListener (provided by the JSF implementation) is used.
   */
  @ExtendClass(value= "javax.faces.application.NavigationHandler", canBeDecorator = true)
  GenericDomValue<PsiClass> getNavigationHandler();

  /**
   * The "view-handler" contains the fully qualified class name of the concrete
   * javax.faces.application.ViewHandler implementation class that will be called
   * during the Restore View and Render Response phases of the request processing lifecycle.
   * The faces implementation must provide a default implementation of this class
   */
  @ExtendClass(value = "javax.faces.application.ViewHandler", canBeDecorator = true)
  GenericDomValue<PsiClass> getViewHandler();

  /**
   * The "property-resolver" element contains the fully qualified class name of
   * the concrete javax.faces.el.PropertyResolver implementation class
   * that will be used during the processing of value reference expressions.
   */
  @ExtendClass(value="javax.faces.el.PropertyResolver", canBeDecorator = true)
  GenericDomValue<PsiClass> getPropertyResolver();

  /**
   * The "variable-resolver" contains the fully qualified class name of
   * the concrete javax.faces.el.VariableResolver implementation class
   * that will be used during the processing of value reference expressions.
   */
  @ExtendClass(value = "javax.faces.el.VariableResolver", canBeDecorator = true)
  GenericDomValue<PsiClass> getVariableResolver();

  /**
   * The "state-manager" element contains the fully qualified class name
   *  of the concrete StateManager implementation class that will be called
   *  during the Restore View and Render Response phases of the request
   *  processing lifecycle.
   */
  @ExtendClass(value = "javax.faces.application.StateManager", canBeDecorator = true)
  GenericDomValue<PsiClass> getStateManager();


}
