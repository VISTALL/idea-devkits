/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.managedBeans.propertyValue;

import com.intellij.jsf.model.FacesModelElement;
import com.intellij.psi.PsiType;
import com.intellij.util.xml.*;

import java.util.List;

/**
 * The "list-entries" element represents a set of initialization elements for a managed property that is a java.util.List or an array. In the former case, the "value-class" element can optionally be used to declare the Java type to which each value should be converted before adding it to the Collection
 */
public interface ListEntries extends FacesModelElement {
  /**
   *  The "value-class" element defines the Java type to which each "value" element's value will be converted to, prior to adding it to the "list-entries" list for a managed property that is a java.util.List
   */
  @Convert(JvmPsiTypeConverter.class)
  GenericDomValue<PsiType> getValueClass();

  @SubTagList("value")
  List<Value> getNonNullValues();

  @SubTagList("null-value")
  List<NullValue> getNullValues();

  @SubTagsList({"null-value", "value"})
  List<ListItem> getValues();

  @SubTagsList(value={"null-value", "value"}, tagName = "value")
  Value addElement();

  @SubTagsList(value={"null-value", "value"}, tagName = "null-value")
  NullValue addNullElement();

  @SubTagsList(value={"null-value", "value"}, tagName = "value")
  Value addElement(int index);

  @SubTagsList(value={"null-value", "value"}, tagName = "null-value")
  NullValue addNullElement(int index);
}
