/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.managedBeans;

import com.intellij.jsf.model.FacesPresentationElement;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.NameValue;
import com.intellij.util.xml.Required;
import com.intellij.util.xml.ExtendClass;

/**
 * The "managed-bean" element represents a JavaBean, of a particular class,
 * that will be dynamically instantiated at runtime (by the default VariableResolver implementation)
 * if it is referenced as the first element of a value reference expression, and no corresponding bean can be identified in any scope.
 * In addition to the creation of the managed bean, and the optional storing of it into the specified scope, the nested managed-property elements
 * can be used to initialize the contents of settable JavaBeans properties of the created instance.
 */
public interface ManagedBean extends FacesPresentationElement {
  /**
   * The "managed-bean-name" element represents the attribute name
   * under which a managed bean will be searched for, as well as stored
   * (unless the "managed-bean-scope" value is "none").
   */
  @NameValue
  @Required
  GenericDomValue<String> getManagedBeanName();

  /**
   * The "managed-bean-class" element represents the fully qualified class name of the Java class
   * that will be used to instantiate a new instance if creation of the specified managed bean is requested.
   * It must be of type ClassName. The specified class must conform to standard JavaBeans conventions.
   * In particular, it must have a public zero-arguments constructor, and zero or more public property setters.
   */
  @ExtendClass
  @Required
  GenericDomValue<PsiClass> getManagedBeanClass();

  /**
   * The "managed-bean-scope" element represents the scope into which a newly created instance of the specified managed bean will be stored
   * (unless the value is "none"). It must be of type ScopeOrNone.
   */
  @Required
  GenericDomValue<BeanScope> getManagedBeanScope();
}
