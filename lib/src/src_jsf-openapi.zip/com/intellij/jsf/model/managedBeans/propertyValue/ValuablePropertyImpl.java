/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.managedBeans.propertyValue;

import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.application.Result;
import com.intellij.jsf.model.managedBeans.Valuable;

/**
 * User: Sergey.Vasiliev
 * Date: Jan 26, 2006
 */
abstract public class ValuablePropertyImpl implements Valuable {

  public String getStringValue() {
    if(getNullValue().getXmlTag() != null) return "null value";
    if(getValue().getXmlTag() != null) return getValue().getStringValue();

    return null;
  }

  public boolean isNullValue() {
    return getNullValue().getXmlTag() != null;
  }

  public void setNullValue() {
    new WriteCommandAction(getManager().getProject()) {
      protected void run(final Result result) throws Throwable {
        getValue().undefine();
        getNullValue().setValue("");
      }
    }.execute();
  }

  public void setValue(final String value) {
    new WriteCommandAction(getManager().getProject()) {
      protected void run(final Result result) throws Throwable {
          getNullValue().undefine();
          getValue().setValue(value);
      }
    }.execute();
  }
}
