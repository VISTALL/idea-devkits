package com.intellij.jsf.model;

import com.intellij.util.xml.model.DomModel;
import org.jetbrains.annotations.NotNull;

/**
 * User: Sergey.Vasiliev
 */
public interface FacesDomModel extends DomModel<FacesConfig> {
  @NotNull
  FacesConfig getFacesConfig();
}
