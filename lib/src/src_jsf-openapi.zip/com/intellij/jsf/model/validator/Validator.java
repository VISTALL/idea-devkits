/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.validator;

import com.intellij.jsf.model.FacesPresentationElement;
import com.intellij.jsf.model.component.AttributesOwner;
import com.intellij.jsf.model.component.PropertiesOwner;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.NameValue;
import com.intellij.util.xml.Required;
import com.intellij.util.xml.ExtendClass;

/**
 * The "validator" element represents a concrete javax.faces.validator.Validator implementation class
 * that should be registered under the specified validator identifier. Validator identifiers must be unique
 * within the entire web application.
 * Nested "attribute" elements identify generic attributes that may be configured on the corresponding Component
 * in order to affect the operation of the Validator.
 * Nested "property" elements identify JavaBeans properties of the Validator implementation class
 * that may be configured to affect the operation of the Validator.
 */
public interface Validator extends AttributesOwner, PropertiesOwner, FacesPresentationElement {
  /**
   * The "validator-id" element represents the identifier under which the corresponding Validator class should be registered.
   */
  @NameValue
  @Required
  GenericDomValue<String> getValidatorId();

  /**
   * The "validator-class" element represents the fully qualified class name of a concrete Validator implementation class.
   */
  @Required
  @ExtendClass("javax.faces.validator.Validator")
  GenericDomValue<PsiClass> getValidatorClass();
}
