/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.factory;

import com.intellij.jsf.model.FacesModelElement;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.ExtendClass;

/**
 * The "factory" provides a mechanism to define the various Factories
 * that comprise parts of the implementation of JavaServer Faces.
 * For nested elements that are not specified, the JSF implementation must provide a suitable default.
 */
public interface Factory extends FacesModelElement {
  /**
   * The "application-factory" element contains the fully qualified class name of
   * the concrete javax.faces.application.ApplicationFactory implementation class that will be called
   * when FactoryFinder.getFactory(APPLICATION_FACTORY) is called.
   */
  @ExtendClass(value ="javax.faces.application.ApplicationFactory", canBeDecorator = true)
  GenericDomValue<PsiClass> getApplicationFactory();

  /**
   * The "faces-context-factory" contains the fully qualified class name of the concrete
   * javax.faces.context.FacesContextFactory implementation class that will be called
   * when FactoryFinder.getFactory(FACES_CONTEXT_FACTORY) is called.
   */
  @ExtendClass(value = "javax.faces.context.FacesContextFactory", canBeDecorator = true)
  GenericDomValue<PsiClass> getFacesContextFactory();

  /**
   * The "lifecycle-factory" contains the fully qualified class name of the concrete
   * javax.faces.lifecycle.LifecycleFactory implementation class that will be called when
   * FactoryFinder.getFactory(LIFECYCLE_FACTORY) is called.
   */
  @ExtendClass(value = "javax.faces.lifecycle.LifecycleFactory", canBeDecorator = true)
  GenericDomValue<PsiClass> getLifecycleFactory();

  /**
   * The "render-kit-factory" contains the fully qualified class name of the concrete
   * javax.faces.render.RenderKitFactory implementation class that will be called when
   * FactoryFinder.getFactory(RENDER_KIT_FACTORY) is called.
   */
  @ExtendClass(value = "javax.faces.render.RenderKitFactory", canBeDecorator = true)
  GenericDomValue<PsiClass> getRenderKitFactory();
}
