/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.renderKits;

import com.intellij.jsf.model.FacesModelElement;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.GenericDomValue;

/**
 * The "supported-component-class" element identifies a component class that is supported by
 * the surrounding renderer, and the renderer attribute names that are relevant for this component class.
 * If no "attribute-name" subelements are listed, names from all of the "attribute" declarations
 * for the surrounding renderer shall be assumed.
 */
public interface SupportedComponentClass extends FacesModelElement {
  /**
   * The "component-class" element represents the fully qualified class name of a concrete Component implementation class.
   */
  GenericDomValue<PsiClass> getComponentClass();

  /**
   * The "attribute-name" element represents the name under which the corresponding value will be stored, in the generic attributes of the Component we are related to.
   */
  GenericDomValue<String> getAttributeName();
}
