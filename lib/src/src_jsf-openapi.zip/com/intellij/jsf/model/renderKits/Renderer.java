/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.renderKits;

import com.intellij.jsf.model.FacesPresentationElement;
import com.intellij.jsf.model.component.AttributesOwner;
import com.intellij.jsf.model.component.FacetsOwner;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.NameValue;
import com.intellij.util.xml.Required;
import com.intellij.util.xml.ExtendClass;

/**
 * The "renderer" element represents a concrete javax.faces.render.Renderer implementation class
 * that should be registered under the specified type identifier, in the RenderKit associated with the parent render-kit element.
 * Renderer types must be unique within the RenderKit associated with the parent "render-kit" element.
 * Nested "attribute" elements identify generic component attributes that are recognized by this renderer.
 * Nested "supported-component-type" and "supported-component-class" elements identify supported component classes,
 * by their type identifiers or the implementation class name, respectively, that are supported by this Renderer.
 */
public interface Renderer extends FacetsOwner, AttributesOwner, FacesPresentationElement {
  /**
   * The component-family element represents the component family for which the Renderer represented by the parent renderer element will be used.
   */
  @Required
  GenericDomValue<String> getComponentFamily();

  /**
   * The "renderer-type" element represents an identifier for the Renderer represented by the parent "renderer" element.
   */
  @NameValue(unique = false)
  @Required
  GenericDomValue<String> getRendererType();

  /**
   * The "renderer-class" element represents the fully qualified class name of a
   * concrete javax.faces.render.Renderer  implementation class.
   */
  @Required
  @ExtendClass("javax.faces.render.Renderer")
  GenericDomValue<PsiClass> getRendererClass();

  /**
   * The "supported-component-type" element identifies a component type that is supported by the surrounding renderer,
   * and the renderer attribute names that are relevant for this component type.
   * If no "attribute-name" subelements are listed, names from all of the "attribute" declarations for
   * the surrounding renderer shall be assumed.
   */
  SupportedComponentType getSupportedComponentType();

  /**
 * The "supported-component-class" element identifies a component class that is supported by
 * the surrounding renderer, and the renderer attribute names that are relevant for this component class.
 * If no "attribute-name" subelements are listed, names from all of the "attribute" declarations
 * for the surrounding renderer shall be assumed.
 */
  SupportedComponentClass getSupportedComponentClass();

  /**
   *  "renderer-extension". Extension element for renderer. May contain implementation specific content.
   */
  GenericDomValue<String> getRendererExtension();
}
