/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.jsf.model.renderKits;

import com.intellij.jsf.model.FacesPresentationElement;
import com.intellij.psi.PsiClass;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.NameValue;
import com.intellij.util.xml.Required;
import com.intellij.util.xml.ExtendClass;

import java.util.List;

/**
 * The "render-kit" element represents a concrete RenderKit implementation that should be registered
 * under the specified render-kit-id. If no render-kit-id is specified, the identifier of the default RenderKit
 * (RenderKitFactory.DEFAULT_RENDER_KIT) is assumed.
 */
public interface RenderKit extends FacesPresentationElement {
  /**
   * The "render-kit-id" element represents an identifier for the RenderKit represented by the parent "render-kit" element.
   */
  @NameValue
  @Required(value = false, identifier = false, nonEmpty = true)
  GenericDomValue<String> getRenderKitId();

  /**
   * The "render-kit-class" element represents the fully qualified class name of a concrete
   * javax.faces.render.RenderKit implementation class.
   */
  @ExtendClass("javax.faces.render.RenderKit")
  @Required(value = false, identifier = false, nonEmpty = true)
  GenericDomValue<PsiClass> getRenderKitClass();

  /**
   * The "renderer" element represents a concrete javax.faces.render.Renderer implementation class
   * that should be registered under the specified type identifier, in the RenderKit associated with the parent render-kit element.
   * Renderer types must be unique within the RenderKit associated with the parent "render-kit" element.
   * Nested "attribute" elements identify generic component attributes that are recognized by this renderer.
   * Nested "supported-component-type" and "supported-component-class" elements identify supported component classes,
   * by their type identifiers or the implementation class name, respectively, that are supported by this Renderer.
   */
  List<Renderer> getRenderers();
}
