package com.intellij.jsf.model;

import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.project.Project;
import com.intellij.psi.xml.XmlFile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * User: Sergey.Vasiliev
 */
public abstract class FacesDomModelManager {
  public static FacesDomModelManager getInstance(Project project) {
    return ServiceManager.getService(project, FacesDomModelManager.class);
  }

  public abstract boolean isFacesConfig(@NotNull final XmlFile file);

  @Nullable
  public abstract FacesDomModel getFacesDomModel(@NotNull final XmlFile file, @NotNull WebFacet webFacet);

  @NotNull
  public abstract List<FacesDomModel> getAllModels(@NotNull WebFacet webFacet);

  @Nullable
  public abstract FacesDomModel getCombinedModel(@NotNull WebFacet webFacet);
}
