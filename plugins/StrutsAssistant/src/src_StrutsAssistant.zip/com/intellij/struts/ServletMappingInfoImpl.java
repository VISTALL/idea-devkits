/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts;

import com.intellij.javaee.model.xml.web.ServletMapping;
import com.intellij.javaee.web.WebUtil;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiReference;
import com.intellij.psi.PsiReferenceBase;
import com.intellij.psi.impl.source.resolve.reference.impl.providers.XmlValueProvider;
import com.intellij.psi.xml.XmlElement;
import com.intellij.psi.xml.XmlTag;
import org.jetbrains.annotations.Nullable;

/**
 * @author Dmitry Avdeev
 */
public class ServletMappingInfoImpl implements ServletMappingInfo {

  @Nullable
  private final String myUrlPattern;

  private final Type mappingType;

  private final String mappingSubstring;

  @Nullable
  private final ServletMapping myServletMapping;

  @Nullable
  public String getUrlPattern() {
    return myUrlPattern;
  }

  @Nullable
  public ServletMapping getServletMapping() {
    return myServletMapping;
  }

  enum Type {
    EXTENSION,
    PATH,
    NONE
  }

  public ServletMappingInfoImpl(ServletMapping servletMapping) {

    myServletMapping = servletMapping;

    if (servletMapping != null && servletMapping.getUrlPatterns().size() > 0) {
      myUrlPattern = servletMapping.getUrlPatterns().get(0).getValue();
    }
    else {
      myUrlPattern = null;
    }

    if (myUrlPattern == null) {
      mappingType = Type.NONE;
      mappingSubstring = null;
    }
    else if (myUrlPattern.startsWith("*.")) {
      mappingType = Type.EXTENSION;
      mappingSubstring = myUrlPattern.substring(1);
    }
    else if (myUrlPattern.endsWith("/*")) {
      mappingType = Type.PATH;
      mappingSubstring = myUrlPattern.substring(0, myUrlPattern.length() - 2);
    }
    else {
      mappingType = Type.NONE;
      mappingSubstring = null;
    }
  }

  @Nullable
  public String stripMapping(String actionUrl) {
    switch (mappingType) {
      case EXTENSION:
        int pos = actionUrl.indexOf(mappingSubstring);
        if (pos != -1 && pos == actionUrl.length() - mappingSubstring.length()) {
          return actionUrl.substring(0, pos);
        }
      case PATH:
        pos = actionUrl.indexOf(mappingSubstring);
        if (pos == 0) {
          return actionUrl.substring(mappingSubstring.length());
        }
      case NONE:
        break;
    }
    return actionUrl;
  }

  @Nullable
  public String createUrl(String actionPath) {
    switch (mappingType) {
      case EXTENSION:
        return actionPath + mappingSubstring;
      case PATH:
        return mappingSubstring + actionPath;
      case NONE:
        break;
    }
    return null;
  }

  /**
   *
   * @param actionUrl
   * @return null if no mapping provided
   */
  @Nullable
  public TextRange getActionRange(String actionUrl) {
    actionUrl = WebUtil.trimURL(actionUrl);
    switch (mappingType) {
      case EXTENSION:
        int pos = actionUrl.indexOf(mappingSubstring);
        if (pos != -1 && pos == actionUrl.length() - mappingSubstring.length()) {
          return new TextRange(0, pos);
        }
      case PATH:
        pos = actionUrl.indexOf(mappingSubstring);
        if (pos == 0) {
          return new TextRange(mappingSubstring.length(), actionUrl.length());
        }
      case NONE:
        break;
    }
    return null;
  }

  @Nullable
  public TextRange getMappingRange(String actionUrl) {
    actionUrl = WebUtil.trimURL(actionUrl);
    switch (mappingType) {
      case EXTENSION:
        int pos = actionUrl.indexOf(mappingSubstring);
        if (pos != -1 && pos == actionUrl.length() - mappingSubstring.length()) {
          return new TextRange(pos + 1, actionUrl.length());
        }
      case PATH:
        pos = actionUrl.indexOf(mappingSubstring);
        if (pos == 0) {
          return new TextRange(0, mappingSubstring.length());
        }
      case NONE:
        break;
    }
    return null;
  }

  @Nullable
  public PsiReference getMappingReference(XmlElement element, String actionUrl, final boolean soft) {
    TextRange range = getMappingRange(actionUrl);
    if (range == null) {
      return null;
    }
    range = range.shiftRight(XmlValueProvider.getRange(element).getStartOffset());
    return new PsiReferenceBase(element, range, soft) {

      @Nullable
      public PsiElement resolve() {
        assert myServletMapping != null;
        final XmlTag tag = myServletMapping.getXmlTag();
        assert tag != null;
        return tag.findFirstSubTag("url-pattern");
      }

      public Object[] getVariants() {
        return EMPTY_ARRAY;
      }
    };
  }
}
