/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.actions;

import com.intellij.javaee.JavaeeDeploymentDescriptor;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.javaee.web.WebUtil;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleType;
import com.intellij.openapi.project.Project;
import com.intellij.struts.StrutsManager;
import com.intellij.struts.core.IdeaUtils;
import com.intellij.struts.util.PsiClassUtil;
import com.intellij.struts.wizards.StrutsSupportModel;
import com.intellij.struts.wizards.support.StrutsAddSupportContext;
import com.intellij.struts.wizards.support.StrutsAddSupportWizard;
import com.intellij.struts.wizards.support.StrutsVersion;
import org.jetbrains.annotations.NotNull;

/**
 * Date: 06.04.2005 Time: 13:21:53
 *
 * @author Dmitry Avdeev
 */
public class AddStrutsSupportAction extends AnAction {

  protected static final Logger logger = Logger.getInstance("#com.intellij.struts.actions.AddStrutsSupportAction");

  public void update(AnActionEvent event) {

    Presentation presentation = event.getPresentation();
      Module module = (Module)event.getDataContext().getData(DataConstants.MODULE);
      if (module != null && module.getModuleType().equals(ModuleType.WEB)) {
        if (IdeaUtils.isModuleNode(event)) {
          presentation.setEnabled(true);
          presentation.setVisible(true);
          if (StrutsManager.getInstance().getAllStrutsModels(module).size() > 0) {
            presentation.setText("Edit Struts Features...");
            presentation.setDescription("Edit Struts features for the module");
          }
          else {
            presentation.setText("Add Struts Support...");
            presentation.setDescription("Add Struts support for the module");
          }
          return;
        }
      }
    presentation.setEnabled(false);
    presentation.setVisible(false);
  }

  /**
   * @param module WebModule
   */
  public static StrutsSupportModel checkStrutsSupport(@NotNull Module module) {
    StrutsSupportModel support = new StrutsSupportModel();
    WebModuleProperties webProps = WebUtil.getWebModuleProperties(module);
    if (webProps == null) {
      return support;
    }
    JavaeeModuleProperties props = JavaeeModuleProperties.getInstance(module);
    JavaeeDeploymentDescriptor desc = props.getMainDeploymentDescriptor();
    if (desc == null) {
      return support;
    }
    support.webAppVersion = desc.getVersion();

    support.tiles = StrutsManager.getInstance().getAllTilesModels(module).size() > 0;

    support.validation = StrutsManager.getInstance().getAllValidationModels(module).size() > 0;

    support.taglibs = webProps.getTaglibUriToResourceMap();

    Project project = module.getProject();
    support.strutsLib = PsiClassUtil.findClassInProjectScope("org.apache.struts.action.Action", project) != null;
    support.struts13 = PsiClassUtil.findClassInProjectScope("org.apache.struts.chain.ComposableRequestProcessor", project) != null;
    support.jstl = PsiClassUtil.findClassInProjectScope("javax.servlet.jsp.jstl.core.ConditionalTagSupport", project) != null;
    support.strutsel = PsiClassUtil.findClassInProjectScope("org.apache.strutsel.taglib.html.ELBaseTag", project) != null;
    support.strutsTaglib = PsiClassUtil.findClassInProjectScope("org.apache.struts.taglib.html.BaseTag", project) != null;
    support.extras = PsiClassUtil.findClassInProjectScope("org.apache.struts.plugins.ModuleConfigVerifier", project) != null;
    support.scripting = PsiClassUtil.findClassInProjectScope("org.apache.struts.scripting.ScriptAction", project) != null;
    support.strutsFaces = PsiClassUtil.findClassInProjectScope("org.apache.struts.faces.application.FacesRequestProcessor", project) != null;

    return support;
  }

  public void actionPerformed(AnActionEvent event) {

    try {
      Module module = (Module)event.getDataContext().getData(DataConstants.MODULE);
      if (module != null && module.getModuleType().equals(ModuleType.WEB)) {
        perform(module);
      }
    }
    catch (Exception e) {
      logger.error("Cannot perform action: " + e.getMessage(), e);
    }
  }

  public static void perform(final Module module) {

    StrutsSupportModel model = checkStrutsSupport(module);
    final StrutsAddSupportContext context = new StrutsAddSupportContext(false, module.getProject());
    if (model.strutsLib) {
      context.setVersion(model.struts13 ? StrutsVersion.Struts1_3_5 : StrutsVersion.Struts1_2_9);
    }
    context.setTilesSupport(model.tiles);
    context.setValidatorSupport(model.validation);
    context.setStrutsELSupport(model.strutsel);
    context.setStrutsTaglibSupport(model.strutsTaglib);
    context.setStrutsFacesSupport(model.strutsFaces);
    context.setScriptingSupport(model.scripting);
    context.setExtrasSupport(model.extras);

    new StrutsAddSupportWizard(context, module).show();
  }

}
