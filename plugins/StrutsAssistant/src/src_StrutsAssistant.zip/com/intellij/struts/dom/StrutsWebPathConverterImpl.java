/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.dom;

import com.intellij.javaee.web.*;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.util.TextRange;
import com.intellij.openapi.module.Module;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiReference;
import com.intellij.psi.PsiReferenceBase;
import com.intellij.psi.impl.source.resolve.reference.impl.providers.FileReferenceSet;
import com.intellij.psi.xml.XmlAttribute;
import com.intellij.struts.StrutsManager;
import com.intellij.struts.StrutsModel;
import com.intellij.struts.TilesModel;
import com.intellij.struts.StrutsConstants;
import com.intellij.struts.inplace.reference.path.ActionWebPathsProvider;
import com.intellij.struts.dom.tiles.Definition;
import com.intellij.util.Function;
import com.intellij.util.xml.*;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.Icon;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

/**
 * Adds tiles definitions as valid paths
 *
 * @author Dmitry Avdeev
 */
public class StrutsWebPathConverterImpl extends StrutsWebPathConverter {

  private final static Icon TILE_ICON = IconLoader.getIcon("/com/intellij/struts/icons/tiles/Tile.png");

  @NonNls
  private static final String INPUT_ATTRIBUTE = "input";

  private final WebPathsProvider myTilesPathsProvider = new WebPathsProvider() {

    @Nullable
    public WebPath getPath(@NotNull String path, @NotNull WebModuleProperties properties, @NotNull final PsiFile context) {
      TilesModel model = StrutsManager.getInstance().getTiles(context);
      if (model != null) {
        Definition definition = model.findDefinition(path);
        if (definition != null) {
          return new WebPathImpl(path, this, TILE_ICON);
        }
      }
      return null;
    }

    public boolean createReferences(@NotNull PsiElement psiElement, @NotNull final List<PsiReference> references, final boolean soft) {
      final TilesModel model = StrutsManager.getInstance().getTiles(psiElement);
      if (model != null) {
        PsiReferenceBase<PsiElement> reference = new PsiReferenceBase<PsiElement>(psiElement, soft) {
           @Nullable
           public PsiElement resolve() {
             String url = getValue();
             url = WebUtil.trimURL(url);
             Definition definition = model.findDefinition(url);
             if (definition != null) {
               return definition.getXmlTag();
             }
             else {
               return null;
             }
           }

           public Object[] getVariants() {
             List<Definition> definitions = model.getDefinitions();
             return ElementPresentationManager.getInstance().createVariants(definitions);
           }
         };
        final String url = reference.getValue();
        int pos = WebUtil.getLastPosOfURL(url);
        if (pos != -1) {
          final TextRange range = reference.getRangeInElement();
          reference.setRangeInElement(new TextRange(range.getStartOffset(), pos + range.getStartOffset()));
        }
        references.add(reference);
      }
      return false;
    }
  };

  private final WebPathsProvider myForwardsPathsProvider = new WebPathsProvider() {

    public boolean createReferences(@NotNull final PsiElement psiElement, final @NotNull List<PsiReference> references, final boolean soft) {
      final StrutsModel model = StrutsManager.getInstance().getStrutsModel(psiElement);
      if (model != null) {
        PsiReferenceBase<PsiElement> reference = new PsiReferenceBase<PsiElement>(psiElement, soft) {

          public PsiElement resolve() {
            String url = getValue();
            url = WebUtil.trimURL(url);
            Forward forward = null;
            final DomElement element = DomManager.getDomManager(psiElement.getProject()).getDomElement(((XmlAttribute)getElement().getParent()).getParent());
            if (element instanceof Action) {
              forward = DomUtil.findByName(((Action)element).getForwards(), url);
            }
            if (forward == null) {
              forward = model.findForward(url);
            }
            return forward == null ? null : forward.getXmlTag();
          }

          public Object[] getVariants() {
            final List<Forward> forwards = new ArrayList<Forward>(model.getForwards());
            final DomElement element = DomManager.getDomManager(psiElement.getProject()).getDomElement(((XmlAttribute)getElement().getParent()).getParent());
            if (element instanceof Action) {
              forwards.addAll(((Action)element).getForwards());
            }
            return ElementPresentationManager.getInstance().createVariants(forwards);
          }
        };
        references.add(reference);
      }
      return false;
    }

    @Nullable
    public WebPath getPath(@NotNull String path, @NotNull WebModuleProperties properties, @NotNull final PsiFile context) {
      return new WebPathImpl(path, this, StrutsConstants.FORWARD_ICON);
    }
  };

  private final WebPathsProvider myStrutsPagesPathsProvider = new WebPathsProvider() {

    public boolean createReferences(final @NotNull PsiElement psiElement, final @NotNull List<PsiReference> references, final boolean soft) {
      final FileReferenceSet set = FileReferenceSet.createSet(psiElement, soft, true);
      if (set == null) {
        return true;
      }
      set.addCustomization(
        FileReferenceSet.DEFAULT_PATH_EVALUATOR_OPTION,
        new Function<PsiFile, PsiElement>() {
          @Nullable
          public PsiElement fun(final PsiFile file) {
            final StrutsModel model = StrutsManager.getInstance().getStrutsModel(file);
            return model == null ? null : model.getModuleRoot();
          }
        });
      Collections.addAll(references, set.getAllReferences());
      return false;
    }

    @Nullable
    public WebPath getPath(@NotNull String path, @NotNull WebModuleProperties properties, @NotNull final PsiFile context) {
      return null;
    }
  };

  private final WebPathsProvider myActionWebPathsProvider = new ActionWebPathsProvider();

  private final WebPathsProvider[] myProviders = new WebPathsProvider[] {
    myStrutsPagesPathsProvider,
    myTilesPathsProvider,
    myActionWebPathsProvider,
    WebPathsManager.getInstance().getServletWebPathsProvider()
  };

  public WebPath fromString(@Nullable final String s, final ConvertContext context) {
    final Module module = context.getModule();
    if (module == null || s == null) {
      return null;
    }
    if (isInputForward(context.getXmlElement())) {
      final WebModuleProperties moduleProperties = WebUtil.getWebModuleProperties(module);
      if (moduleProperties != null) {
        return myForwardsPathsProvider.getPath(s, moduleProperties, context.getFile());
      }
    }
    return WebPathsManager.getInstance().getCustomPath(s, module, context.getFile(), myProviders);
  }

  @NotNull
  public PsiReference[] createReferences(@NotNull final PsiElement psiElement, final boolean soft) {
    final PsiElement parent = psiElement.getParent();
    if (isInputForward(parent)) {
      return WebPathsManager.getReferencesFromProvider(myForwardsPathsProvider, psiElement, soft);
    }
    return WebPathsManager.getInstance().createCustomReferences(psiElement,
                                                                soft,
                                                                myProviders);
  }

  private static boolean isInputForward(PsiElement psiElement) {
    if (psiElement instanceof XmlAttribute && ((XmlAttribute)psiElement).getName().equals(INPUT_ATTRIBUTE)) {
      final StrutsModel model = StrutsManager.getInstance().getStrutsModel(psiElement);
      if (model != null) {
        final Controller controller = model.getMergedModel().getController();
        final Boolean value = controller.getInputForward().getValue();
        if (value == null) {
          final SetProperty property = DomUtil.findByName(controller.getSetProperties(), "inputForward");
          if (property != null) {
            final String s = property.getValue().getValue();
            return Boolean.parseBoolean(s);
          }
        } else {
          return value.booleanValue();
        }
      }
    }
    return false;
  }
}
