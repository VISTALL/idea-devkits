/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.web;

import com.intellij.struts.util.FormatUtil;

/**
 * Date: 15.09.2005 Time: 11:28:09
 *
 * @author Dmitry Avdeev
 */
public class TaglibJspDecl {

  private final String uri;
  private final String prefix;

  public TaglibJspDecl(String urilong) {

    this.uri = urilong;

    if ("http://java.sun.com/jstl/core".equals(uri)) {
      prefix = "c";
      return;
    }
    String uri = FormatUtil.getUriName(urilong);

    if (uri.endsWith("-rt")) {
      uri = uri.substring(0, uri.length() - 3);
    }
    else if (uri.endsWith("-el")) {
      uri = uri.substring(0, uri.length() - 3);
    }

    int pos = uri.lastIndexOf('-');
    if (pos == -1) {
      pos = uri.lastIndexOf('/');
      if (pos == -1) {
        prefix = uri;
      }
      else {
        prefix = uri.substring(pos + 1);
      }
    }
    else {
      prefix = uri.substring(pos + 1);
    }
  }

  public String getUri() {
    return uri;
  }

  public String getPrefix() {
    return prefix;
  }
}
