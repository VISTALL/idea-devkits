/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts;

import com.intellij.javaee.model.xml.web.Servlet;
import com.intellij.javaee.web.WebUtil;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.psi.PsiClass;
import com.intellij.psi.impl.source.jsp.JspManager;
import com.intellij.psi.jsp.WebDirectoryElement;
import com.intellij.psi.xml.XmlFile;
import com.intellij.struts.core.PsiBeanProperty;
import com.intellij.struts.core.PsiBeanPropertyCache;
import com.intellij.struts.core.PsiBeanPropertyImpl;
import com.intellij.struts.dom.*;
import com.intellij.struts.util.PsiClassUtil;
import com.intellij.util.xml.DomUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author Dmitry Avdeev
 */
public class StrutsModelImpl extends DomModelImpl<StrutsConfig> implements StrutsModel {

  private Servlet myActionServlet;
  private final WebModuleProperties myWebModuleProperties;
  private ServletMappingInfo myMappingInfo;

  public StrutsModelImpl(@NotNull Set<XmlFile> configFiles,
                         @NotNull StrutsConfig mergedModel,
                         @NotNull Servlet actionServlet,
                         @NotNull ServletMappingInfo mappingInfo,
                         @NotNull String modulePrefix,
                         @NotNull WebModuleProperties webModuleProperties) {

    super(configFiles, mergedModel, modulePrefix);
    myMappingInfo = mappingInfo;
    myActionServlet = actionServlet;
    myWebModuleProperties = webModuleProperties;
  }

  @NotNull
  public String getModulePrefix() {
    return getName();
  }

  @Nullable
  public WebDirectoryElement getModuleRoot() {
    return JspManager.getInstance(myWebModuleProperties.getModule().getProject()).findWebDirectoryElementByPath(getModulePrefix(), myWebModuleProperties);
  }

  @NotNull
  public WebModuleProperties getWebModuleProperties() {
    return myWebModuleProperties;
  }

  @NotNull
  public ServletMappingInfo getServletMappingInfo() {
    return myMappingInfo;
  }

  @NotNull
  public List<Action> getActions() {
    return getMergedModel().getActionMappings().getActions();
  }

  @Nullable
  public Action findAction(@NotNull String actionPath) {
    return DomUtil.findByName(getActions(), actionPath);
  }

  @Nullable
  public Action resolveActionURL(String actionURL) {
    String actionPath = getActionName(actionURL);
    return actionPath == null ? null : findAction(actionPath);
  }

  @Nullable
  public String getActionName(String url) {
    final String trimmedUrl = WebUtil.trimURL(url);
    return myMappingInfo.stripMapping(trimmedUrl);
  }

  @NotNull
  public String[] getActionPaths() {
    return DomUtil.getElementNames(getActions());
  }

  @NotNull
  public List<FormBean> getFormBeans() {
    return getMergedModel().getFormBeans().getFormBeans();
  }

  @Nullable
  public FormBean findFormBean(String formBeanName) {
    return DomUtil.findByName(getFormBeans(), formBeanName);
  }

  @NotNull
  public List<Forward> getForwards() {
    return getMergedModel().getGlobalForwards().getForwards();
  }

  @Nullable
  public Forward findForward(String forwardName) {
    return DomUtil.findByName(getForwards(), forwardName);
  }

  public boolean isInputForward() {
    return false;
  }

  @NotNull
  public Servlet getActionServlet() {
    return myActionServlet;
  }

  @NotNull
  public PsiBeanProperty[] getFormProperties(@NotNull FormBean form) {
    PsiClass type = form.getType().getValue();
    if (type != null) {
        if (PsiClassUtil.isSuper(type, "org.apache.struts.action.DynaActionForm")) {
          // analyze form here
          List<FormProperty> tags = form.getFormProperties();
          ArrayList<PsiBeanProperty> props = new ArrayList<PsiBeanProperty>();
          for (FormProperty tag : tags) {
            PsiBeanProperty prop = PsiBeanPropertyImpl.create(tag);
            if (prop != null) {
              props.add(prop);
            }
          }
          return props.toArray(new PsiBeanProperty[props.size()]);
        }
        else {
          return PsiBeanPropertyCache.getInstance(type.getProject()).getBeanProperties(type);
        }
    }
    return PsiBeanProperty.EMPTY_ARRAY;
  }
}
