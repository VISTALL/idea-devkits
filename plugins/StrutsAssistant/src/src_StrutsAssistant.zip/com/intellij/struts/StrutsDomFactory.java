/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts;

import com.intellij.javaee.model.xml.ParamValue;
import com.intellij.javaee.model.xml.web.Servlet;
import com.intellij.javaee.model.xml.web.ServletMapping;
import com.intellij.javaee.model.xml.web.WebApp;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiManager;
import com.intellij.psi.impl.source.jsp.JspManager;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.util.InheritanceUtil;
import com.intellij.psi.xml.XmlFile;
import com.intellij.struts.dom.StrutsConfig;
import com.intellij.util.xml.ModelMerger;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * @author Dmitry Avdeev
 */
public class StrutsDomFactory extends WebDomFactory<StrutsConfig, StrutsModel> {

  @NonNls private static final String ACTION_SERVLET = "org.apache.struts.action.ActionServlet";
  @NonNls private static final String CONFIG = "config";
  @NonNls private static final String CONFIG_PREFIX = "config/";

  public StrutsDomFactory(ModelMerger modelMerger, Project project) {
    super(StrutsConfig.class, modelMerger, project, "Struts");
    
  }

  protected Object[] computeDependencies(final @Nullable StrutsModel model, @Nullable WebModuleProperties moduleProperties,
                                         @NotNull final Project project) {
    moduleProperties = model == null ? moduleProperties : model.getWebModuleProperties();
    final ProjectRootManager manager = ProjectRootManager.getInstance(project);
    return new Object[] { moduleProperties, manager };
  }

  /**
   *
   * @param psiElement
   * @return corresponding StrutsModel, or null if not exist
   */
  @Nullable
  public StrutsModel getModel(@NotNull final PsiElement psiElement) {
    final PsiFile psiFile = psiElement.getContainingFile();
    if (psiFile instanceof XmlFile) {
      return getModelByConfigFile((XmlFile)psiFile);
    }
    return null;
  }

  @Nullable
  protected List<StrutsModel> computeModels(@Nullable WebModuleProperties moduleProperties) {

    if (moduleProperties == null) {
      return null;
    }
    WebApp webApp = moduleProperties.getRoot();
    if (webApp == null) {
      return null;
    }

    Servlet actionServlet = findActionServlet(webApp);
    if (actionServlet == null) {
      return Collections.emptyList();
    }
    ServletMapping strutsMapping = null;
    for (ServletMapping mapping: webApp.getServletMappings()) {
      if (mapping.getServletName().getValue() == actionServlet) {
        strutsMapping = mapping;
        break;
      }
    }
    ServletMappingInfo mappingInfo = new ServletMappingInfoImpl(strutsMapping);

    List<ParamValue> parameters = actionServlet.getInitParams();
    final JspManager jspManager = JspManager.getInstance(moduleProperties.getModule().getProject());
    final List<StrutsModel> strutsModels = new ArrayList<StrutsModel>();
    params: for (ParamValue parameter : parameters) {
      String parameterName = parameter.getParamName().getValue();
      if (parameterName == null) {
        continue;
      }

      String modulePath = null;
      if (parameterName.startsWith(CONFIG_PREFIX)) {
        modulePath = parameterName.substring(CONFIG_PREFIX.length() - 1);
      } else if (CONFIG.equals(parameterName)) {
        modulePath = "/";
      }

      if (modulePath != null) {
        // check path uniquness
        for (StrutsModel model: strutsModels) {
          if (model.getModulePrefix().equals(modulePath)) {
            continue params;  
          }
        }
        String configList = parameter.getParamValue().getValue();
        if (configList == null) {
          continue;
        }
        Set<XmlFile> configFiles = new LinkedHashSet<XmlFile>();
        String[] paths = configList.split(",");
        for (String path : paths) {
          PsiElement file = jspManager.findFileByPath(path.trim(), moduleProperties);
          if (file instanceof XmlFile) {
            configFiles.add((XmlFile)file);
          }
        }
        final StrutsConfig mergedModel = createMergedModel(configFiles);

        StrutsModel model = new StrutsModelImpl(configFiles, mergedModel, actionServlet, mappingInfo, modulePath, moduleProperties);
        strutsModels.add(model);
      }
    }
    return strutsModels;
  }

  protected StrutsModel createCombinedModel(final Set<XmlFile> configFiles, final StrutsConfig mergedModel, final StrutsModel firstModel) {
    return new StrutsModelImpl(configFiles, mergedModel, firstModel.getActionServlet(), firstModel.getServletMappingInfo(), "/", firstModel.getWebModuleProperties());
  }

  @Nullable
  public static Servlet findActionServlet(@NotNull WebApp webApp) {

    PsiClass actionServletClass = null;
    List<Servlet> servlets = webApp.getServlets();
    for (Servlet servlet : servlets) {
      PsiClass servletPsiClass = servlet.getServletClass().getValue();
      if (servletPsiClass != null) {
        if (actionServletClass == null) {
          final GlobalSearchScope scope = servlet.getResolveScope();
          actionServletClass = PsiManager.getInstance(servletPsiClass.getProject()).findClass(ACTION_SERVLET, scope);
          if (actionServletClass == null) {
            return null;
          }
        }
        if (InheritanceUtil.isInheritorOrSelf(servletPsiClass, actionServletClass, true)) {
          return servlet;
        }
      }
    }

    return null;
  }
}
