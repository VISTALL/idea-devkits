/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.tree;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.IconLoader;
import com.intellij.struts.StrutsProjectComponent;
import com.intellij.struts.ValidationModel;
import com.intellij.struts.dom.validator.*;
import com.intellij.util.Function;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.DomFileDescription;
import com.intellij.util.xml.ElementPresentationManager;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Dmitry Avdeev
 */
public class ValidatorDomTree extends StrutsTreeBase<FormValidation, ValidationModel> {

  private final static Map<Class, Boolean> hiders = new HashMap<Class, Boolean>();

  private final static List<Class> consolidated = Arrays.asList(
    new Class[]{Validator.class, Global.class, Constant.class, Formset.class, Form.class, Field.class, Msg.class, Arg.class, Var.class}

  );

  static {
    ValidatorDomTree.hiders.put(DomElement.class, true);
    ValidatorDomTree.hiders.put(GenericDomValue.class, false);

    ElementPresentationManager
      .registerIcon(FormValidation.class, IconLoader.getIcon("/com/intellij/struts/icons/validator/ValidatorConfig.png"));

    ElementPresentationManager.registerIcon(Global.class, IconLoader.getIcon("/com/intellij/struts/icons/validator/Global.png"));
    ElementPresentationManager.registerIcon(Validator.class, IconLoader.getIcon("/com/intellij/struts/icons/validator/Validator.png"));
    ElementPresentationManager.registerIcon(Constant.class, IconLoader.getIcon("/com/intellij/struts/icons/validator/Constant.png"));

    ElementPresentationManager.registerIcon(Formset.class, IconLoader.getIcon("/com/intellij/struts/icons/validator/Formset.png"));
    ElementPresentationManager.registerIcon(Form.class, IconLoader.getIcon("/com/intellij/struts/icons/validator/Form.png"));
    ElementPresentationManager.registerIcon(Field.class, IconLoader.getIcon("/com/intellij/struts/icons/FormProperty.png"));

    ElementPresentationManager.registerIcon(Msg.class, IconLoader.getIcon("/com/intellij/struts/icons/validator/Msg.png"));
    ElementPresentationManager.registerIcon(Arg.class, IconLoader.getIcon("/com/intellij/struts/icons/validator/Arg.png"));
    ElementPresentationManager.registerIcon(Var.class, IconLoader.getIcon("/com/intellij/struts/icons/validator/Var.png"));

    initNamers();
  }

  public static void initNamers() {
    ElementPresentationManager.registerNameProvider(new Function<Object, String>() {
      @Nullable
      public String fun(final Object s) {
        if (s instanceof Formset) {
          String lang = ((Formset)s).getLanguage().getValue();
          String country = ((Formset)s).getCountry().getValue();
          String variant = ((Formset)s).getVariant().getValue();
          String name = lang == null ? null : lang;
          if (country != null) {
            name = name == null ? country : name + "_" + country;
          }
          if (variant != null) {
            name = name == null ? variant : name + "_" + variant;
          }
          return name;
        }
        return null;
      }
    });

    ElementPresentationManager.registerNameProvider(new Function<Object, String>() {

      @Nullable
      public String fun(final Object s) {
        if (s instanceof Arg) {
          final String name = ((Arg)s).getName().getStringValue();
          if (name == null) {
            return null;
          }
          final String position = ((Arg)s).getPosition().getStringValue();
          return position == null ? name : name + position;
        }
        return null;
      }
    });
  }

  public ValidatorDomTree(final Project project, DomFileDescription fileDescription) {
    super(project, fileDescription, StrutsProjectComponent.getInstance(project).myValidatorFactory, hiders, consolidated, null);
  }

}
