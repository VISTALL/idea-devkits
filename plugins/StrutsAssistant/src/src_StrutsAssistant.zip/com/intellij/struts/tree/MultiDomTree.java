/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.tree;

import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiManager;
import com.intellij.psi.xml.XmlFile;
import com.intellij.struts.DomModel;
import com.intellij.struts.WebDomFactory;
import com.intellij.ui.treeStructure.SimpleTreeStructure;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.DomFileDescription;
import com.intellij.util.xml.DomManager;
import com.intellij.util.xml.tree.DomModelTreeView;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.List;
import java.util.Map;

/**
 * @author Dmitry Avdeev
 */
public class MultiDomTree<T extends DomElement, M extends DomModel<T>> extends DomModelTreeView {
  private final DomFileDescription myDescription;

  public MultiDomTree(final Project project,
                      DomFileDescription description,
                      final WebDomFactory<T, M> factory,
                      final Map<Class, Boolean> hiders,
                      final List<Class> consolidated,
                      final List<Class> folders) {

    this(project, description, new MultiDomTreeStructure<T, M>(project, factory, hiders, consolidated, folders));
  }

  public MultiDomTree(final Project project,
                      DomFileDescription description,
                      final SimpleTreeStructure treeStructure) {

    super(null, DomManager.getDomManager(project), treeStructure);
    myDescription = description;
  }

  protected boolean isRightFile(final VirtualFile file) {
    final PsiFile psiFile = PsiManager.getInstance(getProject()).findFile(file);
    return psiFile instanceof XmlFile && myDescription.isMyFile((XmlFile)psiFile, ModuleUtil.findModuleForPsiElement(psiFile));
  }

  protected boolean isRootVisible() {
    return false;
  }

  public void init() {
    if (getTree().getRowCount() < 2) {
      getTree().setRootVisible(true);
    }
    if (((DefaultMutableTreeNode)(getTree().getModel().getRoot())).getUserObject() == null) {
      getBuilder().initRoot();
    }
    else {
      getBuilder().queueUpdate();
    }
    getTree().expandRow(0);
    getTree().setRootVisible(false);
  }
}


