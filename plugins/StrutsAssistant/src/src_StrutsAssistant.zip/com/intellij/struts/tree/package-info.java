/**
 * Tree browser for configuration files.
 */
package com.intellij.struts.tree;