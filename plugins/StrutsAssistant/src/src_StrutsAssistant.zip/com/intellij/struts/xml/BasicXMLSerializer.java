/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.xml;

import com.intellij.struts.util.BeanSpector;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Date: 05.11.2004 Time: 13:17:05
 *
 * @author Dmitry Avdeev
 */
public class BasicXMLSerializer {

  protected PrintStream out;

  protected Map propertiesMap = new HashMap();

  public void setOut(PrintStream out) {
    this.out = out;
  }

  public void mapSerialized(Class clazz, String[] properties) {
    propertiesMap.put(clazz, properties);
  }

  protected void serializeBean(Object bean, int level) {

    startElement(BeanSpector.getClassName(bean.getClass()), level);
    // serialize properties
    BeanSpector inspector = BeanSpector.getBeanSpector(bean.getClass());
    String[] properties = (String[])propertiesMap.get(bean.getClass());
    if (properties == null) {
      for (final Object o : inspector.getProperties().values()) {
        serializeProperty((BeanSpector.Property)o, bean);
      }
    }
    else {
      for (String property : properties) {
        serializeProperty(inspector.getProperty(property), bean);
      }
    }
    endElement();
  }

  protected void serializeProperty(BeanSpector.Property property, Object bean) {
    if (property.getGetter() != null) {
      Object value;
      try {
        value = property.get(bean);
      }
      catch (Exception e) {
        throw new RuntimeException(e);
      }
      if (value != null) {
        printAttribute(property.getName(), value.toString());
      }
    }
  }

  protected void startElement(String tag, int level) {
    out.print('<' + tag);
  }

  protected void endElement() {
    out.print("/>\n");
  }

  protected void printAttribute(Map map, String name) {
    Object value = map.get(name);
    if (value != null) {
      out.print(" " + name + "=\"" + value + '"');
    }
  }

  protected void printAttribute(String name, int value) {
    out.print(" " + name + "=\"" + value + '"');
  }

  protected void printAttribute(String name, boolean value) {
    out.print(" " + name + "=\"" + value + '"');
  }

  protected void printAttribute(String name, double value) {
    out.print(" " + name + "=\"" + value + '"');
  }

  protected void printAttribute(String name, String value) {
    if (value != null) {
      out.print(" " + name + "=\"" + value + '"');
    }
  }
}
