/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.config;

import com.intellij.openapi.options.ConfigurationException;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Dmitry Avdeev
 */
public class StrutsConfigPane {

  protected List<ConfigurableElement> myElements = new ArrayList<ConfigurableElement>();

  private JTabbedPane myTabbedPane;
  private JPanel myMainPanel;
  private JCheckBox myStrutsValidationCheckBox;
  private JCheckBox myTilesValidationCheckBox;
  private JCheckBox myValidatorValidationCheckBox;
  private JCheckBox myReportErrorsAsWarningsCheckBox;

  public StrutsConfigPane(StrutsProjectSettings mySettings) {
    myElements.add(new BooleanConfigurableElement(myStrutsValidationCheckBox, mySettings, "myStrutsValidationEnabled"));
    myElements.add(new BooleanConfigurableElement(myTilesValidationCheckBox, mySettings, "myTilesValidationEnabled"));
    myElements.add(new BooleanConfigurableElement(myValidatorValidationCheckBox, mySettings, "myValidatorValidationEnabled"));
    myElements.add(new BooleanConfigurableElement(myReportErrorsAsWarningsCheckBox, mySettings, "myReportErrorsAsWarnings"));
  }

  public JComponent createComponent() {
    return myMainPanel;
  }

  public boolean isModified() {
    for (ConfigurableElement element : myElements) {
      if (element.isModified()) {
        return true;
      }
    }
    return false;
  }

  public void apply() throws ConfigurationException {
    for (ConfigurableElement element : myElements) {
      element.apply();
    }
  }

  public void reset() {
    for (ConfigurableElement element : myElements) {
      element.reset();
    }
  }
}
