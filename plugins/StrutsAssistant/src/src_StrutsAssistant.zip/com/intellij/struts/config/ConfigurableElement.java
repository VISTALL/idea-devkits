package com.intellij.struts.config;

import com.intellij.openapi.options.ConfigurationException;

/**
 * @author Dmitry Avdeev
 */
public interface ConfigurableElement {
  boolean isModified();

  void apply() throws ConfigurationException;

  void reset();
}
