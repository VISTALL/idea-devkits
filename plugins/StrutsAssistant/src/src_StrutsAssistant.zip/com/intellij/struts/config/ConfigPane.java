/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.config;

import com.intellij.openapi.fileEditor.FileEditor;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.project.ProjectManager;
import com.intellij.struts.api.AppManager;
import com.intellij.struts.ui.*;
import com.intellij.struts.ui.edit.BrowseFileField;
import com.intellij.struts.util.CompareUtil;
import com.intellij.ui.DocumentAdapter;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Date: 07.04.2005 Time: 11:34:37
 *
 * @author Dmitry Avdeev
 */
public class ConfigPane {

  protected final static Logger logger = Logger.getLogger(ConfigPane.class);

  private final BrowseFileField strutsPath;

  private boolean modified;

  private EmptyBorder border = new EmptyBorder(10, 10, 10, 10);

  private JCheckBox completion;
  private JCheckBox dot = new JCheckBox("After dot (for classnames)");
  private JCheckBox slash = new JCheckBox("After slash (for paths)");
  private JCheckBox comma = new JCheckBox("After comma (for lists)");
//    private JCheckBox empty = new JCheckBox("For empty attributes");
  private JTextField delay = new JTextField(6);

  private JCheckBox chain = new JCheckBox("After package choosing (for classnames)");
  private JCheckBox chainPath = new JCheckBox("After directory choosing (for paths)");
  private JTextField chainDelay = new JTextField(6);

  private final JSlider scrollIncrement = new JSlider(0, 100);
  private final Project project;


  public ConfigPane(Project project) {
    this.project = project;
    strutsPath = new BrowseFileField(true);
  }

  public JComponent createComponenet() {

    JPanel settingsPanel = new JPanel(new BorderLayout());
    JTabbedPane tabbed = new JTabbedPane();

    tabbed.add(this.createProjectPane(), "Struts Project");

    JComponent completion = this.createCompletionPanel();
    tabbed.add("Code Completion", completion);


    tabbed.add(this.createDiagramPanel(), "Diagram");
/*
        JPanel resources = new JPanel(new GridBagLayout());
        resources.setBorder(border);
        tabbed.add("Resources", resources);

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new Insets(5, 5, 5, 5);

        c.gridwidth = 300;
        c.anchor = GridBagConstraints.SOUTH;
        resources.add(new JLabel("Struts installation path:", SwingConstants.RIGHT), c);

        c.gridwidth = -1;
        JComponent pp = strutsPath.getComponent();
        pp.setPreferredSize(new Dimension(300, pp.getPreferredSize().height));
        resources.add(pp, c);

        c.weightx = 1.0;
        resources.add(new JLabel(), c);

        c.gridy = 1;
        c.fill = GridBagConstraints.VERTICAL;
        c.weighty = 1.0;
        resources.add(Box.createVerticalGlue(), c);
*/
/*
    JPanel aboutPanel = new JPanel(new GridBagLayout());
    aboutPanel.setBorder(border);
    tabbed.add("About", aboutPanel);

    GridBagConstraints c = new GridBagConstraints();
    c.fill = GridBagConstraints.HORIZONTAL;
    c.anchor = GridBagConstraints.EAST;
    c.insets = new Insets(5, 5, 5, 5);

    aboutPanel.add(new JLabel("Struts Assistant home page:", SwingConstants.RIGHT), c);
    c.anchor = GridBagConstraints.WEST;
    c.weightx = 1.0;
    aboutPanel.add(new SmartLink("http://www.intellij.org/twiki/bin/view/Main/StrutsAssistant"), c);
//		c.anchor = GridBagConstraints.NORTH;
    //       aboutPanel.add(Box.createHorizontalGlue(), c);

    c.anchor = GridBagConstraints.EAST;
    c.gridy = 1;
    c.weightx = -1.0;

    aboutPanel.add(new JLabel("Mail:", SwingConstants.RIGHT), c);
    c.anchor = GridBagConstraints.WEST;
//		c.weightx = 1.0;
    aboutPanel.add(new SmartLink("anima2ls@yahoo.com", "mailto:anima2ls@yahoo.com"), c);

    c.gridy = 2;
    c.fill = GridBagConstraints.VERTICAL;
    c.weighty = 1.0;
    aboutPanel.add(Box.createVerticalGlue(), c);
    */


    settingsPanel.add(tabbed, BorderLayout.CENTER);
    JPanel copyright = new JPanel(new BorderLayout());
    copyright.setBorder(new EmptyBorder(3, 3, 3, 3));
//        copyright.add(new JLabel("Struts Assistant 1.12 \u00a9 2004-2006 AnimA Tools"), BorderLayout.EAST);

    settingsPanel.add(copyright, BorderLayout.SOUTH);


    strutsPath.addChangeListener(changeListener);


    return settingsPanel;
  }


  private class MyChangeListener extends DocumentAdapter implements ActionListener, ChangeListener {

    public void actionPerformed() {
      modified = true;
      UIUtil.enableBox(completionBox, completion.isSelected());
      UIUtil.enableBox(chainBox, completion.isSelected());
    }

    public void stateChanged(ChangeEvent e) {
      actionPerformed();
    }

    /**
     * Invoked when an action occurs.
     */
    public void actionPerformed(ActionEvent e) {
      actionPerformed();
    }

    protected void textChanged(DocumentEvent e) {
      actionPerformed();
    }
  }

  private MyChangeListener changeListener = new MyChangeListener();
/*
    protected JComponent createFeaturesPanel() {

        GridLayoutBuilder builder = new GridLayoutBuilder();
        builder.addComponent(completion);
        builder.finish();
        builder.getPanel().setBorder(border);
        return builder.getPanel();
    }
*/

  protected JComponent completionBox;
  protected JComponent chainBox;

  protected JComponent createCompletionPanel() {

    completion = new JCheckBox("Enable Completion support");
    completion.addActionListener(changeListener);

    dot.addActionListener(changeListener);
    slash.addActionListener(changeListener);
    chain.addActionListener(changeListener);
    comma.addActionListener(changeListener);

    delay.getDocument().addDocumentListener(changeListener);
    chainDelay.getDocument().addDocumentListener(changeListener);


    GridLayoutBuilder builder = new GridLayoutBuilder();
    builder.addComponent(dot);
    builder.addComponent(slash);
    builder.addComponent(comma);
    builder.addShortLine(new JLabel("Delay (ms):"), delay);
//        builder.finish();
    builder.getPanel().setBorder(new TitledBorder(new EtchedBorder(), " Autopopup in XML and JSP "));
    completionBox = builder.getPanel();


    Box panel = new Box(BoxLayout.Y_AXIS);
    Box box = new Box(BoxLayout.X_AXIS);
    box.add(completion);

    panel.add(box);
    panel.add(completionBox);

//        delay.setMaximumSize(new Dimension(100, (int)delay.getPreferredSize().getHeight()));

//        panel.add(box);

    builder = new GridLayoutBuilder();
    builder.getPanel().setBorder(new TitledBorder(new EtchedBorder(), " Autopopup after lookup item choosing "));
    builder.addComponent(chain);
    builder.addComponent(chainPath);
    builder.addShortLine(new JLabel("Delay (ms):"), chainDelay);
    builder.finish();

    chainBox = builder.getPanel();

    builder = new GridLayoutBuilder();
    builder.addComponent(completion);
    builder.addComponentPair(completionBox, chainBox);
    builder.finish();
    builder.getPanel().setBorder(border);
    return builder.getPanel();
  }

  private JComponent createDiagramPanel() {

    this.scrollIncrement.addChangeListener(this.changeListener);
    this.scrollIncrement.setMajorTickSpacing(20);
    this.scrollIncrement.setMinorTickSpacing(5);
//        this.scrollIncrement.createStandardLabels(10);

    this.scrollIncrement.setPaintLabels(true);
//        this.scrollIncrement.setPaintTrack(true);
    this.scrollIncrement.setPaintTicks(true);
    this.scrollIncrement.setSnapToTicks(true);
    this.scrollIncrement.setBorder(null);

    GridLayoutBuilder builder = new GridLayoutBuilder();
    builder.addLine(new JLabel("Srolling increment:"), this.scrollIncrement);

    builder.finish();
    builder.getPanel().setBorder(border);
    return builder.getPanel();
  }

  private final JCheckBox showInputs = new JCheckBox("Visualize input attributes for actions");

  private JComponent createProjectPane() {

    this.showInputs.addChangeListener(changeListener);
    GridLayoutBuilder builder = new GridLayoutBuilder();
//    builder.addLine("Struts distributive:", this.strutsPath.getComponent());
    builder.addComponent(showInputs);
    builder.finish();
    builder.getPanel().setBorder(border);
    return builder.getPanel();
  }

  public void reset() {

    StrutsConfiguration conf = StrutsConfiguration.getInstance();
    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Resetting...");


    completion.setSelected(conf.completion.enabled);

    dot.setSelected(conf.completion.dot);
    slash.setSelected(conf.completion.slash);
    delay.setText(Integer.toString(conf.completion.delay));

    chain.setSelected(conf.completion.chain);
    chainPath.setSelected(conf.completion.chainPath);
    chainDelay.setText(Integer.toString(conf.completion.chainDelay));

    this.scrollIncrement.setValue(conf.diagram.scrollIncrement);

    StrutsProjectSettings projectSettings = conf.getProjectSettings(project);
    strutsPath.setValue(projectSettings.resources.strutsPath);
    this.showInputs.setSelected(projectSettings.showInputs);

    modified = false;
  }

  public void apply() {
    StrutsConfiguration conf = StrutsConfiguration.getInstance();
    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Applying...");


    boolean reload = CompareUtil.compare(conf.completion.enabled, completion.isSelected()) != 0;

    conf.completion.enabled = completion.isSelected();

    conf.completion.dot = dot.isSelected();
    conf.completion.slash = slash.isSelected();
    conf.completion.delay = Integer.parseInt(delay.getText());

    conf.completion.chain = chain.isSelected();
    conf.completion.chainPath = chainPath.isSelected();
    conf.completion.chainDelay = Integer.parseInt(chainDelay.getText());

    conf.diagram.scrollIncrement = this.scrollIncrement.getValue();

    Project[] projects = ProjectManager.getInstance().getOpenProjects();
    if (projects != null) {
      StrutsProjectSettings projectSettings = conf.getProjectSettings(project);
      projectSettings.resources.strutsPath = (String)strutsPath.getValue();

      if (projectSettings.showInputs != this.showInputs.isSelected()) {

        projectSettings.showInputs = this.showInputs.isSelected();
      }
    }

    modified = false;

    if (reload) {
      AppManager.getInstance()
        .showMessage(null, "Warning", "To apply your changes, you should reload the currently opened project", MessageBox.WARNING_ICON);
    }
  }

  public boolean isModified() {
    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Asked if modified: " + modified);
    return modified;
  }
}
