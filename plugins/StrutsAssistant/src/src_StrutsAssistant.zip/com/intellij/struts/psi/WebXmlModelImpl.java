/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.psi;

import com.intellij.javaee.model.xml.SecurityRole;
import com.intellij.javaee.model.xml.web.Servlet;
import com.intellij.javaee.model.xml.web.ServletMapping;
import com.intellij.javaee.model.xml.web.WebApp;
import com.intellij.openapi.module.Module;
import com.intellij.psi.xml.XmlTag;
import com.intellij.struts.WebXmlModel;
import com.intellij.util.xml.DomUtil;
import com.intellij.util.xml.GenericDomValue;

import java.util.ArrayList;
import java.util.List;

import org.jetbrains.annotations.Nullable;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 17.11.2005
 * Time: 12:41:26
 * To change this template use File | Settings | File Templates.
 */
public class WebXmlModelImpl implements WebXmlModel {

  private final WebApp myProps;
  private final Module myModule;

  public WebXmlModelImpl(WebApp props, Module module) {

    myProps = props;
    myModule = module;
  }

  public String[] getRoleNames() {

    return DomUtil.getElementNames(myProps.getSecurityRoles());
  }

  @Nullable
  public XmlTag getRoleTag(String name) {
    SecurityRole role = DomUtil.findByName(myProps.getSecurityRoles(), name);
    return role == null ? null : role.getXmlTag();
  }

  public String[] getServletPaths() {
    String[] servlets = DomUtil.getElementNames(myProps.getServlets());
    ArrayList<String> result = new ArrayList<String>(servlets.length);
    List<XmlTag> mappings = DomUtil.getElementTags(myProps.getServletMappings());
    for (String servlet : servlets) {
      XmlTag mapping = null;
      for (XmlTag mapping1 : mappings) {
        XmlTag name = mapping1.findFirstSubTag("servlet-name");
        if (name != null && name.getValue().getText().equals(servlet)) {
          mapping = mapping1;
          break;
        }
      }
      if (mapping != null) {
        XmlTag url = mapping.findFirstSubTag("url-pattern");
        if (url != null) {
          String val = url.getValue().getText();
          if (val.indexOf('*') == -1) {
            result.add(val);
          }
        }
        continue;
      }
      result.add("/" + servlet);
    }
    return result.toArray(new String[result.size()]);
  }


  @Nullable
  public XmlTag getServletTag(String path) {
    List<ServletMapping> mappings = myProps.getServletMappings();
    for (ServletMapping map : mappings) {
      for (GenericDomValue<String> pattern : map.getUrlPatterns()) {
        String val = pattern.getValue();
        if (val != null && val.equals(path)) {
          return map.getXmlTag();
        }
      }
    }
    if (path.startsWith("/")) {
      Servlet servlet = DomUtil.findByName(myProps.getServlets(), path.substring(1));
      if (servlet != null) {
        return servlet.getXmlTag();
      }
    }
    return null;
  }

  public Module getModule() {
    return myModule;
  }
}
