/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.psi;

import com.intellij.javaee.model.xml.web.WebApp;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.javaee.web.WebUtil;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.xml.XmlDocument;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import com.intellij.struts.*;
import com.intellij.struts.dom.StrutsConfig;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.DomManager;
import com.intellij.util.xml.ExtendClass;
import com.intellij.util.xml.DomFileElement;
import com.intellij.util.xml.reflect.DomAttributeChildDescription;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 21.10.2005
 * Time: 18:07:22
 * To change this template use File | Settings | File Templates.
 */
public class StrutsManagerImpl extends StrutsManager implements ApplicationComponent {

  @NonNls private static final String STRUTS_CONFIG = "struts-config";

  public static StrutsManagerImpl getStrutsManagerImpl() {
    return (StrutsManagerImpl)getInstance();
  }

  @Nullable
  public WebXmlModel getWebXml(@Nullable Module module) {
    if (module == null) {
      return null;
    }
    WebModuleProperties props = WebUtil.getWebModuleProperties(module);
    if (props == null) {
      return null;
    }
    WebApp webApp = props.getRoot();
    if (webApp == null) {
      return null;
    }
    return new WebXmlModelImpl(webApp, module);
  }

  @Nullable
  public WebXmlModel getWebXmlByPsi(PsiElement psiElement, Project project) {
    return getWebXml(ModuleUtil.findModuleForPsiElement(psiElement));
  }

  @Nullable
  public StrutsModel getStrutsModel(@Nullable PsiElement psiElement) {
    if (psiElement == null) {
      return null;
    }
    final PsiFile psiFile = psiElement.getContainingFile();
    if (psiFile == null) {
      return null;
    }
    final StrutsDomFactory strutsFactory = StrutsProjectComponent.getInstance(psiElement.getProject()).myStrutsFactory;
    if (psiFile.getFileType().equals(StdFileTypes.XML)) {
      return strutsFactory.getModel(psiElement);
    } else {
      return getCombinedStrutsModel(ModuleUtil.findModuleForPsiElement(psiElement));
    }
  }

  @NotNull
  public List<StrutsModel> getAllStrutsModels(Module module) {
    if (module == null) {
      return Collections.emptyList();
    }
    return StrutsProjectComponent.getInstance(module.getProject()).myStrutsFactory.getAllModels(module);
  }

  @Nullable
  public StrutsConfig getStrutsConfig(@NotNull PsiFile configFile) {
    return configFile instanceof XmlFile ? StrutsProjectComponent.getInstance(configFile.getProject()).myStrutsFactory.getDom((XmlFile)configFile) : null;
  }

  @Nullable
  public StrutsModel getCombinedStrutsModel(Module module) {
    return module == null ? null : StrutsProjectComponent.getInstance(module.getProject()).myStrutsFactory.getCombinedModel(module);
  }

  @Nullable
  public ValidationModel getValidation(@Nullable PsiElement psiElement) {
    if (psiElement == null) {
      return null;
    }
    return StrutsProjectComponent.getInstance(psiElement.getProject()).myValidatorFactory.getModel(psiElement);
  }

  @NotNull
  public List<ValidationModel> getAllValidationModels(@Nullable Module module) {
    if (module == null) {
      return Collections.emptyList();
    }
    return StrutsProjectComponent.getInstance(module.getProject()).myValidatorFactory.getAllModels(module);
  }

  @Nullable
  public String getDefaultClassname(String attrName, XmlTag tag) {
    final DomElement domElement = DomManager.getDomManager(tag.getProject()).getDomElement(tag);
    if (domElement != null) {
      final DomAttributeChildDescription<?> childDescription = domElement.getGenericInfo().getAttributeChildDescription(attrName);
      if (childDescription != null) {
        final ExtendClass annotation = childDescription.getAnnotation(ExtendClass.class);
        if (annotation != null) {
          return annotation.value();
        }
      }
    }
    return null;
  }

  @Nullable
  public TilesModel getTiles(@Nullable PsiElement psiElement) {
    if (psiElement == null) {
      return null;
    }
    return StrutsProjectComponent.getInstance(psiElement.getProject()).myTilesFactory.getModel(psiElement);
  }

  @NotNull
  public List<TilesModel> getAllTilesModels(@Nullable Module module) {
    if (module == null) {
      return Collections.emptyList();
    }
    return StrutsProjectComponent.getInstance(module.getProject()).myTilesFactory.getAllModels(module);
  }

  public boolean isStrutsConfig(@NotNull XmlFile file) {
    return hasRoot(file, STRUTS_CONFIG);
  }

  public static boolean hasRoot(XmlFile file, String root) {
    final DomFileElement<DomElement> element = DomManager.getDomManager(file.getProject()).getFileElement(file);
    if (element == null) return false;

    XmlDocument doc = file.getDocument();
    if (doc != null) {
      XmlTag rootTag = doc.getRootTag();
      if (rootTag != null && rootTag.getName().equals(root)) {
        return true;
      }
    }
    return false;

  }

  @NotNull
  public Set<XmlFile> getStrutsConfigFiles(@Nullable PsiElement psiElement) {
    final StrutsModel model = getStrutsModel(psiElement);
    if (model == null) {
      return Collections.emptySet();
    }
    else {
      return model.getConfigFiles();
    }
  }

  @NonNls
  @NotNull
  public String getComponentName() {
    return "StrutsManager";
  }

  /**
   * Component should do initialization and communication with another components in this method.
   */
  public void initComponent() {

  }

  /**
   * Component should dispose system resources or perform another cleanup in this method.
   */
  public void disposeComponent() {

  }
}
