/**
 * Functionality for accessing the DOM-Models of configuration files. 
 */
package com.intellij.struts.psi;