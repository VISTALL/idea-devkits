/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.facet.ui;

import com.intellij.facet.ui.FacetEditorTab;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.struts.facet.StrutsValidationConfiguration;
import org.jetbrains.annotations.Nls;

import javax.swing.*;

/**
 * @author Dmitry Avdeev
 */
public class StrutsValidationEditor extends FacetEditorTab {
  private JPanel myMainPanel;
  private JCheckBox myStrutsValidationCheckBox;
  private JCheckBox myTilesValidationCheckBox;
  private JCheckBox myValidatorValidationCheckBox;
  private JCheckBox myReportErrorsAsWarningsCheckBox;
  private JCheckBox myDisablePropertyKeysValidationCheckBox;
  private StrutsValidationConfiguration myConfiguration;

  public StrutsValidationEditor(StrutsValidationConfiguration configuration) {
    myConfiguration = configuration;
  }

  public JComponent createComponent() {
    return myMainPanel;
  }

  public boolean isModified() {
    return myConfiguration.myStrutsValidationEnabled != myStrutsValidationCheckBox.isSelected() ||
           myConfiguration.myTilesValidationEnabled != myTilesValidationCheckBox.isSelected() ||
           myConfiguration.myValidatorValidationEnabled != myValidatorValidationCheckBox.isSelected() ||
           myConfiguration.myReportErrorsAsWarnings != myReportErrorsAsWarningsCheckBox.isSelected() ||
      myConfiguration.mySuppressPropertiesValidation != myDisablePropertyKeysValidationCheckBox.isSelected();
  }

  public void apply() throws ConfigurationException {
    myConfiguration.myStrutsValidationEnabled = myStrutsValidationCheckBox.isSelected();
    myConfiguration.myTilesValidationEnabled = myTilesValidationCheckBox.isSelected();
    myConfiguration.myValidatorValidationEnabled = myValidatorValidationCheckBox.isSelected();
    myConfiguration.myReportErrorsAsWarnings = myReportErrorsAsWarningsCheckBox.isSelected();
    myConfiguration.mySuppressPropertiesValidation = myDisablePropertyKeysValidationCheckBox.isSelected();
  }

  public void reset() {
    myStrutsValidationCheckBox.setSelected(myConfiguration.myStrutsValidationEnabled);
    myTilesValidationCheckBox.setSelected(myConfiguration.myTilesValidationEnabled);
    myValidatorValidationCheckBox.setSelected(myConfiguration.myValidatorValidationEnabled);
    myReportErrorsAsWarningsCheckBox.setSelected(myConfiguration.myReportErrorsAsWarnings);
    myDisablePropertyKeysValidationCheckBox.setSelected(myConfiguration.mySuppressPropertiesValidation);
  }


  @Nls
  public String getDisplayName() {
    return "Validation";
  }

  public void disposeUIResources() {
  }

  public String getHelpTopic() {
    return "project.struts";
  }
}
