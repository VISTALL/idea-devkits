/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.inspections;

import com.intellij.codeHighlighting.HighlightDisplayLevel;
import com.intellij.codeInspection.*;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiManager;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.util.InheritanceUtil;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.psi.xml.XmlFile;
import com.intellij.struts.StrutsManager;
import com.intellij.struts.StrutsModel;
import com.intellij.struts.ValidationModel;
import com.intellij.struts.dom.Action;
import com.intellij.struts.dom.FormBean;
import com.intellij.struts.dom.validator.Form;
import com.intellij.struts.dom.validator.FormValidation;
import com.intellij.struts.dom.validator.Formset;
import com.intellij.util.xml.DomFileElement;
import com.intellij.util.xml.DomManager;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Dmitry Avdeev
 */
public class ValidatorFormInspection extends LocalInspectionTool {

  @Nls
  @NotNull
  public String getGroupDisplayName() {
    return InspectionConstants.GROUP_NAME;
  }

  @Nls
  @NotNull
  public String getDisplayName() {
    return "Struts Validator form inspection";
  }

  @NonNls
  @NotNull
  public String getShortName() {
    return "StrutsValidatorFormInspection";
  }

  @Nullable
  public ProblemDescriptor[] checkFile(@NotNull PsiFile file, @NotNull InspectionManager manager, boolean isOnTheFly) {
    if (file instanceof XmlFile) {
      final DomFileElement<FormValidation> fileElement = DomManager.getDomManager(file.getProject()).getFileElement((XmlFile)file, FormValidation.class);
      if (fileElement != null) {
        return checkDomFile(fileElement, manager, isOnTheFly);
      }
    }
    return null;
  }

  @NotNull
  public HighlightDisplayLevel getDefaultLevel() {
    return HighlightDisplayLevel.ERROR;
  }

  public boolean isEnabledByDefault() {
    return true;
  }

  @Nullable
  protected static ProblemDescriptor[] checkDomFile(@NotNull final DomFileElement<FormValidation> element, @NotNull final InspectionManager manager, final boolean isOnTheFly) {

    final ValidationModel validationModel = StrutsManager.getInstance().getValidation(element.getFile());
    if (validationModel == null) {
      return null;
    }
    StrutsModel strutsModel = validationModel.getStrutsModel();

    final FormValidation formValidation = element.getRootElement();
    final ArrayList<ProblemDescriptor> problems = new ArrayList<ProblemDescriptor>();

    final PsiManager psiManager = PsiManager.getInstance(manager.getProject());
    GlobalSearchScope scope = GlobalSearchScope.allScope(manager.getProject());

    final PsiClass validatorForm = psiManager.findClass("org.apache.struts.validator.ValidatorForm", scope);
    final PsiClass dynaValidatorForm = psiManager.findClass("org.apache.struts.validator.DynaValidatorForm", scope);

    final PsiClass validatorActionForm = psiManager.findClass("org.apache.struts.validator.ValidatorActionForm", scope);
    final PsiClass dynaValidatorActionForm = psiManager.findClass("org.apache.struts.validator.DynaValidatorActionForm", scope);

    final PsiClass beanValidatorForm = psiManager.findClass("org.apache.struts.validator.BeanValidatorForm", scope);

    for (Formset formset: formValidation.getFormsets()) {
      for (Form form: formset.getForms()) {
        final String formName = form.getName().getValue();
        if (formName != null && formName.length() > 0) {
          final XmlAttributeValue xmlAttributeValue = form.getName().getXmlAttributeValue();
          if (formName.startsWith("/")) {
            final Action action = strutsModel.findAction(formName);
            if (action != null) {
              checkAction(manager, action, xmlAttributeValue, problems, validatorActionForm, dynaValidatorActionForm);
            }
          }
          final FormBean bean = strutsModel.findFormBean(formName);
          if (bean != null) {
            checkFormBean(manager, bean, xmlAttributeValue, problems, validatorForm, dynaValidatorForm);
          } else {
            final Action action = strutsModel.findAction("/" + formName);
            if (action != null) {
              checkAction(manager, action, xmlAttributeValue, problems, beanValidatorForm);
            }
          }
        }
      }
    }
    return problems.size() == 0 ? null : problems.toArray(new ProblemDescriptor[problems.size()]);
  }

  private static void checkFormBean(InspectionManager manager, FormBean formBean, PsiElement element, List<ProblemDescriptor> problems, PsiClass... requiredClass) {
    final PsiClass psiClass = formBean.getType().getValue();
    if (psiClass == null) {
      problems.add(createProblemDescriptor(manager, element, "Form Bean has not valid type"));
    } else  {
      PsiClass wanted = null;
      for (PsiClass required: requiredClass) {
        if (required != null) {
          if (!InheritanceUtil.isInheritorOrSelf(psiClass, required, true)) {
            wanted = required;
          } else {
            return;
          }
        }
      }
      if (wanted != null) {
        problems.add(createProblemDescriptor(manager, element, "Form Bean is not " + wanted.getName()));
      }
    }
  }

  private static void checkAction(InspectionManager manager, Action action, PsiElement element, List<ProblemDescriptor> problems, PsiClass... requiredClass) {
    final FormBean formBean = action.getName().getValue();
    if (formBean == null) {
      problems.add(createProblemDescriptor(manager, element, "No Form Bean configured for action"));
    } else {
      checkFormBean(manager, formBean, element, problems, requiredClass);
    }
  }

  private static ProblemDescriptor createProblemDescriptor(InspectionManager manager, PsiElement element, String description) {
    return manager.createProblemDescriptor(element, description, (LocalQuickFix)null, ProblemHighlightType.GENERIC_ERROR_OR_WARNING);
  }
}
