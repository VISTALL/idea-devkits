/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace;

import com.intellij.ide.IdeEventQueue;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.actionSystem.ex.ActionManagerEx;
import com.intellij.openapi.actionSystem.ex.AnActionListener;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.command.CommandProcessor;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiDocumentManager;
import com.intellij.psi.PsiFile;
import com.intellij.struts.config.CompletionSettings;
import com.intellij.struts.config.StrutsConfiguration;
import com.intellij.struts.inplace.reference.StrutsAutoLookupHandler;
import com.intellij.util.Alarm;
import org.jetbrains.annotations.NotNull;

public class StrutsAutoPopupController implements ProjectComponent {

  private final Project project;
  private final Alarm alarm = new Alarm();
  private AnActionListener actionListener;
  private Runnable runner;


  public static StrutsAutoPopupController getInstance(Project project) {
    return project.getComponent(StrutsAutoPopupController.class);
  }

  public StrutsAutoPopupController(Project project) {
    this.project = project;
  }

  @NotNull
  public String getComponentName() {
    return "StrutsAssistantAutoPopup";
  }

  public void initComponent() {
  }

  public void disposeComponent() {
  }

  public void projectOpened() {


    actionListener = new AnActionListener() {

      public void beforeActionPerformed(AnAction anaction, DataContext datacontext) {

        alarm.cancelAllRequests();
      }

      public void beforeEditorTyping(char c1, DataContext context) {
        alarm.cancelAllRequests();

        Editor editor = (Editor)context.getData(DataConstants.EDITOR);
        if (editor == null) {
          return;
        }
        int offset = editor.getCaretModel().getOffset() + 1;
        CompletionSettings settings = StrutsConfiguration.getInstance().completion;
        switch (c1) {
          case'.':
            if (settings.dot) {
              autoPopupXmlLookup(settings.delay, offset);
            }
            break;
          case'/':
            if (settings.slash) {
              autoPopupXmlLookup(settings.delay, offset);
            }
            break;
          case',':
            if (settings.comma) {
              autoPopupXmlLookup(settings.delay, offset);
            }
            break;
          case'"':
/*
                            CharSequence chars = editor.getDocument().getCharsSequence();
                            char ch = chars.charAt(offset - 2);
                            char ch1 = chars.charAt(offset);
*/
//                            autoPopupXmlLookup(settings.delay, offset);
            break;
          default:
/*
                            if (s.toString().contains("\"\"")) {
                                autoPopupXmlLookup(settings.delay, offset);
                            }
*/
        }

      }

    };

    ActionManagerEx.getInstanceEx().addAnActionListener(actionListener);
    runner = new Runnable() {

      public void run() {
        alarm.cancelAllRequests();
      }

    };
    IdeEventQueue.getInstance().addActivityListener(runner);

//        ActionManager.getInstance().
/*
        String handlerName = "StrutsAssistantAutoPopupController";
        EditorActionHandler handler = EditorActionManager.getInstance().getActionHandler(handlerName);
        if (handler == null) {
            handler = new EditorActionHandler() {

                 public void execute(Editor editor, DataContext dataContext) {
                     Object o = dataContext.getData("gu");
                 }
             };
             EditorActionManager.getInstance().setActionHandler(handlerName, handler);
        }
*/
/*
        FileEditorManager.getInstance(project).addFileEditorManagerListener(new FileEditorManagerListener() {
            public void fileOpened(FileEditorManager source, VirtualFile file) {
                Document doc = FileDocumentManager.getInstance().getDocument(file);
                if (doc != null) {
                    doc.addDocumentListener(listener);
                }
            }

            public void fileClosed(FileEditorManager source, VirtualFile file) {
                Document doc = FileDocumentManager.getInstance().getDocument(file);
                 if (doc != null) {
                     doc.removeDocumentListener(listener);
                 }
            }

            public void selectionChanged(FileEditorManagerEvent event) {
            }
        });
*/
  }

  public void projectClosed() {
    ActionManagerEx.getInstanceEx().removeAnActionListener(actionListener);
    IdeEventQueue.getInstance().removeActivityListener(runner);
  }

  public void autoPopupXmlLookup(final int delay, int offset) {
    if (ApplicationManager.getApplication().isUnitTestMode()) return;

    final CompletionSettings settings = StrutsConfiguration.getInstance().completion;

    if (settings.dot || settings.slash) {
      final Editor editor = FileEditorManager.getInstance(project).getSelectedTextEditor();
      if (editor == null) {
        return;
      }

      if (offset > 0) {
        int edOffset = editor.getCaretModel().getOffset() + 1;
        if (offset != edOffset) {
          return;
        }
      }

      final PsiFile file = PsiDocumentManager.getInstance(project).getPsiFile(editor.getDocument());
      if (file == null) return;
      final Runnable request = new Runnable() {
        public void run() {
          if (!project.isDisposed()) {
            PsiDocumentManager.getInstance(project).commitAllDocuments();
            CommandProcessor.getInstance().executeCommand(project, new Runnable() {
              public void run() {
                new StrutsAutoLookupHandler().invoke(project, editor, file);
              }
            }, "", null);
          }
        }
      };

      ApplicationManager.getApplication().invokeLater(new Runnable() {
        public void run() {
          alarm.addRequest(request, delay);
        }
      });
    }
  }
}
