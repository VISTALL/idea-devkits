/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace;

import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.project.Project;
import com.intellij.struts.inplace.reference.StrutsReferenceProvider;
import org.apache.log4j.Logger;
import org.jetbrains.annotations.NotNull;

/**
 * Small wrapper for registration of {@link StrutsReferenceProvider}.
 *
 * TODO: obsolete?
 */
public class StrutsReferenceComponent implements ProjectComponent {

  protected static final Logger logger = Logger.getLogger(StrutsReferenceComponent.class);

  private final Project project;

  public StrutsReferenceComponent(Project project) {
    this.project = project;
  }

  public void projectClosed() {
  }

  public void projectOpened() {
  }

  @NotNull
  public String getComponentName() {
    return StrutsReferenceComponent.class.getName();
  }

  public void disposeComponent() {
  }

  public void initComponent() {
    if (!Constants.ENABLE) {
      return;
    }
    try {
      new StrutsReferenceProvider(project).initComponent();
    }
    catch (Exception e) {
      logger.info("Cannot load reference provider: " + e.getMessage());
    }
  }
}
