/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.intentions;

import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.editor.markup.*;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiJavaFile;
import com.intellij.struts.inplace.gutter.GotoDeclGutter;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * @author davdeev
 */
public class AddDeclarationIntention extends PsiIntentionBase {

  private final Icon gutterIcon;

  public AddDeclarationIntention(Icon icon) {
    super("Struts Assistant Intentions");
    this.gutterIcon = icon;
  }

  public String getText() {
    return "Add declaration";
  }

  /**
   * Called when user invokes intention. This method is called inside command.
   * If {@link #startInWriteAction()} returns true, this method is also called
   * inside write action.
   *
   * @param project the project in which the intention is invoked.
   * @param editor  the editor in which the intention is invoked.
   * @param file    the file open in the editor.
   */
  public void invoke(Project project, Editor editor, PsiFile file) throws IncorrectOperationException {
    //To change body of implemented methods use File | Settings | File Templates.
  }


  protected boolean isAvailable(Project project, Editor editor, PsiFile file, @NotNull PsiElement element) {
    if (file instanceof PsiJavaFile && element instanceof PsiClass) {

      PsiClass[] classes = ((PsiJavaFile)file).getClasses();
      for (PsiClass clazz : classes) {

        if (clazz.equals(element) && clazz.hasModifierProperty("public")) {

          int line = editor.getCaretModel().getVisualPosition().line;
          MarkupModel model = editor.getDocument().getMarkupModel(project);

          RangeHighlighter[] highlighters = model.getAllHighlighters();
          for (RangeHighlighter h : highlighters) {
            if (h.getGutterIconRenderer()instanceof GotoDeclGutter) {
              model.removeHighlighter(h);
            }
          }

          TextAttributes attrs = new TextAttributes();
          attrs.setEffectType(EffectType.WAVE_UNDERSCORE);
          RangeHighlighter highlighter = model.addLineHighlighter(line, HighlighterLayer.ADDITIONAL_SYNTAX, null);
          //         highlighter.setGutterIconRenderer(new GotoDeclGutter(element, gutterIcon));

          return true;
        }

      }

    }
    return false;
  }
}
