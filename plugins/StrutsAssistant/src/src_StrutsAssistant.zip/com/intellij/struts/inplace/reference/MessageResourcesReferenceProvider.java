/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference;

import com.intellij.codeInsight.lookup.LookupValueFactory;
import com.intellij.lang.properties.PropertiesFilesManager;
import com.intellij.lang.properties.PropertiesUtil;
import com.intellij.lang.properties.ResourceBundleImpl;
import com.intellij.lang.properties.psi.PropertiesFile;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VirtualFileManager;
import com.intellij.psi.*;
import com.intellij.psi.xml.XmlAttributeValue;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 01.11.2005
 * Time: 13:54:00
 * To change this template use File | Settings | File Templates.
 */
public class MessageResourcesReferenceProvider extends XmlAttributeReferenceProvider {

  protected PsiReference[] create(XmlAttributeValue attribute) {
    PsiReference ref = new XmlValueReference(attribute, "Resource Bundle", MessageResourcesReferenceProvider.this) {

      protected PsiElement doResolve() {
        String path = getValue();
        String pack;
        String name;
        int pos = path.lastIndexOf('.');
        if (pos == -1) {
          pack = "";
          name = path;
        }
        else {
          pack = path.substring(0, pos);
          name = path.substring(pos + 1);
        }


        final PsiManager psiManager = PsiManager.getInstance(getProject());
        PsiPackage p = psiManager.findPackage(pack);
        if (p == null) {
          return null;
        }
        PsiDirectory[] dirs = p.getDirectories();


        Collection<VirtualFile> props = PropertiesFilesManager.getInstance().getAllPropertiesFiles();
        for (VirtualFile file : props) {
          String base = PropertiesUtil.getBaseName(file);
          if (name.equals(base)) {
            for (PsiDirectory dir : dirs) {
              if (dir.findFile(file.getName()) != null) {
                return psiManager.findFile(file);
              }
            }
          }
        }

        VirtualFile file = VirtualFileManager.getInstance().findFileByUrl(path);
        if (file != null) {
          PsiFile psi = PsiManager.getInstance(getProject()).findFile(file);
          if (psi instanceof PropertiesFile) {
            return psi;
          }
        }
        return null;  
      }

      protected Object[] doGetVariants() {

        ArrayList<Object> result = new ArrayList<Object>();
        Collection<VirtualFile> props = PropertiesFilesManager.getInstance().getAllPropertiesFiles();
        for (VirtualFile file : props) {
          PsiDirectory prop = PsiManager.getInstance(getProject()).findDirectory(file.getParent());
          if (prop == null) {
            continue;
          }

          PsiPackage pack = prop.getPackage();
          if (pack == null) {
            continue;
          }
          String base = PropertiesUtil.getBaseName(file);
          if (!result.contains(base)) {
            String packName = pack.getQualifiedName();
            String name;
            if (packName.equals("")) {
              name = base;
            }
            else {
              name = packName + "." + base;
            }
            Object item = LookupValueFactory.createLookupValue(name, ResourceBundleImpl.ICON);
            result.add(item);
          }
        }

        return result.toArray();
      }
    };
    return new PsiReference[] {ref};
  }
}
