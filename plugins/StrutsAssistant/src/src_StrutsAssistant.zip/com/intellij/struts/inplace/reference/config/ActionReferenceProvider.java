/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference.config;

import com.intellij.javaee.web.WebUtil;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiReference;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.struts.StrutsManager;
import com.intellij.struts.StrutsModel;
import com.intellij.struts.dom.Action;
import com.intellij.struts.inplace.reference.XmlAttributeReferenceProvider;
import com.intellij.struts.inplace.reference.XmlValueReference;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 27.10.2005
 * Time: 15:04:02
 */
public class ActionReferenceProvider extends XmlAttributeReferenceProvider {

  @NonNls public static final String CANONICAL = "Action mapping";

  public final static Icon icon = IconLoader.getIcon("/com/intellij/struts/icons/ActionMapping.png");
  private final boolean myParamsAllowed;

  public ActionReferenceProvider(boolean allowParams) {
    myParamsAllowed = allowParams;
  }

  protected PsiReference[] create(XmlAttributeValue attribute) {

    String value = attribute.getValue();
    int paramPos = WebUtil.getLastPosOfURL(value);
    XmlValueReference ref = new XmlValueReference(attribute, paramPos == -1 ? null : new TextRange(1, paramPos + 1), CANONICAL, icon, ActionReferenceProvider.this) {

      @NotNull
      protected String getValue() {
        String path = super.getValue();
        if (!myParamsAllowed) {
          return path;
        }
        return WebUtil.trimURL(path);
      }

      public PsiElement doResolve() {
        StrutsModel model = StrutsManager.getInstance().getStrutsModel(myValue);
        if (model == null) {
          return null;
        }
        String path = getValue();
        Action action = model.findAction(path);
        return action == null ? null : action.getXmlTag();
      }

      @Nullable
      public Object[] doGetVariants() {
        StrutsModel model = StrutsManager.getInstance().getStrutsModel(myValue);
        return model == null ? null : getItems(model.getActions());
      }
    };
    final int dynaPos = WebUtil.indexOfDynamicJSP(value);
    if (dynaPos != -1 && (paramPos == -1 || dynaPos < paramPos)) {
      ref.setSoft(true);
    }
    return new PsiReference[] {ref};
  }
}
