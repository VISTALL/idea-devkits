/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.inspections.config;

import com.intellij.codeInspection.InspectionManager;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.psi.PsiFile;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.psi.xml.XmlFile;
import com.intellij.struts.StrutsManager;
import com.intellij.struts.inplace.inspections.BasePsiVisitor;
import com.intellij.struts.inplace.inspections.InspectionBase;
import com.intellij.struts.inplace.inspections.InspectionConstants;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 07.10.2005
 * Time: 17:56:14
 * To change this template use File | Settings | File Templates.
 */
public class ActionInspection extends InspectionBase {

  public ActionInspection() {
    super(InspectionConstants.GROUP_NAME, "ActionMapping inspection", XmlFile.class);
  }

  /**
   * Override this to report problems at file level.
   *
   * @param file       to check.
   * @param manager    InspectionManager to ask for ProblemDescriptor's from.
   * @param isOnTheFly true if called during on the fly editor highlighting. Called from Inspect Code action otherwise.
   * @return <code>null</code> if no problems found or not applicable at field level.
   */
  protected ProblemDescriptor[] doCheckFile(PsiFile file, InspectionManager manager, boolean isOnTheFly) {
    if (StrutsManager.getInstance().getStrutsConfig(file) == null) {
      return null;
    }

    BasePsiVisitor visitor = new BasePsiVisitor(manager) {

      public void visitXmlAttributeValue(XmlAttributeValue value) {
/*
                     XmlAttribute xmlAttribute = (XmlAttribute)value.getParent();
                     if(!"path".equals(xmlAttribute.getName()))
                         return;
                     if(!xmlAttribute.getParent().getName().equals("action"))
                         return;
                     String pathValue = xmlAttribute.getValue();
                     if(!pathValue.startsWith("/"))
                         addError(value, "Illegal Action-path #ref, must start with '/'", null, ProblemHighlightType.LIKE_UNKNOWN_SYMBOL);
*/
      }
    };
/*
        List<Action> actions = config.getActions();
        for(Action action: actions) {
            XmlTag actionTag = action.getXmlTag();
            actionTag.accept(visitor);
        }
*/
    return visitor.getErrors();

//        return super.checkFile(file, manager, isOnTheFly);

  }

}
