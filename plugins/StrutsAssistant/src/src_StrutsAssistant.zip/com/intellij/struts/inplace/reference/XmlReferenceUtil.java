/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference;

import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiManager;
import com.intellij.psi.PsiClass;
import com.intellij.psi.util.InheritanceUtil;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.xml.XmlTag;
import com.intellij.openapi.project.Project;
import com.intellij.xml.XmlElementDescriptor;
import com.intellij.jsp.impl.TldTagDescriptor;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

/**
 * @author davdeev
 */
public class XmlReferenceUtil {
  @NonNls private static final String ROOT = "root";

  private XmlReferenceUtil() {
  }

  /**
   * @param tag tag to start from
   * @return form tag
   */
  @Nullable
  public static XmlTag findEnclosingTag(XmlTag tag, @NonNls String enclosingTagName) {
    return findEnclosingTag(tag, enclosingTagName, tag.getNamespace(), null);
  }

  @Nullable
  public static XmlTag findEnclosingTagByClass(XmlTag tag, @NonNls String enclosingTagName, @NonNls String tagClassName) {
    final Project project = tag.getProject();
    final PsiClass psiClass = PsiManager.getInstance(project).findClass(tagClassName, GlobalSearchScope.allScope(project));
    return findEnclosingTag(tag, enclosingTagName, tag.getNamespace(), psiClass);
  }

  /**
   * @param tag tag to start from
   * @param ns  namespace
   * @return form tag
   */
  @Nullable
  protected static XmlTag findEnclosingTag(XmlTag tag, String enclosingTagName, @Nullable String ns, @Nullable PsiClass clazz) {

    String name = tag.getLocalName();
    if (name.equals(ROOT)) return null;

    if (name.equals(enclosingTagName)) {
      if (ns != null) {
        String namespace = tag.getNamespace();
        if (namespace.equals(ns)) {
          return tag;
        }
      }
      if (clazz != null) {
        final XmlElementDescriptor descriptor = tag.getDescriptor();
        if (descriptor instanceof TldTagDescriptor) {
          final String tagClassName = ((TldTagDescriptor)descriptor).getTagClass();
          if (tagClassName != null) {
            final Project project = tag.getProject();
            final PsiClass psiClass = PsiManager.getInstance(project).findClass(tagClassName, GlobalSearchScope.allScope(project));
            if (InheritanceUtil.isCorrectDescendant(psiClass, clazz, true)) {
              return tag;
            }
          }
        }
      }
    }

    PsiElement parent = tag.getContext();
    if (!(parent instanceof XmlTag)) {
      return null;
    }
    return findEnclosingTag((XmlTag)parent, enclosingTagName, ns, clazz);
  }

}
