/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference.config;

import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiElement;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.struts.StrutsManager;
import com.intellij.struts.ValidationModel;
import com.intellij.struts.inplace.reference.ListAttrReferenceProvider;
import com.intellij.struts.inplace.reference.XmlValueReference;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NonNls;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 17.11.2005
 * Time: 16:22:46
 * To change this template use File | Settings | File Templates.
 */
public class ValidatorReferenceProvider extends ListAttrReferenceProvider {

  public final static Icon icon = IconLoader.getIcon("/com/intellij/struts/icons/validator/Validator.png");
  @NonNls public final static String CANONICAL = "validator";

  public ValidatorReferenceProvider() {
    super(false);
  }

  @NotNull
  protected XmlValueReference create(final XmlAttributeValue attribute, TextRange range) {
    return new XmlValueReference(attribute, range, CANONICAL, icon, ValidatorReferenceProvider.this) {

      @Nullable
      protected PsiElement doResolve() {
        ValidationModel model = StrutsManager.getInstance().getValidation(attribute);
        final String name = getValue();
        return model == null ? null : model.getRuleTag(name);
      }

      @Nullable
      protected Object[] doGetVariants() {
        ValidationModel model = StrutsManager.getInstance().getValidation(attribute);
        return model == null ? null : getItems(model.getRuleNames());
      }
    };
  }
}