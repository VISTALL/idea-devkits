/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference.config;

import com.intellij.openapi.util.IconLoader;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiReference;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.struts.StrutsManager;
import com.intellij.struts.StrutsModel;
import com.intellij.struts.dom.Forward;
import com.intellij.struts.inplace.reference.XmlAttributeReferenceProvider;
import com.intellij.struts.inplace.reference.XmlValueReference;
import org.jetbrains.annotations.NonNls;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 09.11.2005
 * Time: 12:43:02
 * To change this template use File | Settings | File Templates.
 */
public class ForwardReferenceProvider extends XmlAttributeReferenceProvider {

  @NonNls public static final String CANONICAL = "Global Forward";

  public final static Icon icon = IconLoader.getIcon("/com/intellij/struts/icons/Forward.png");
  private final boolean includeLocal;

  public ForwardReferenceProvider(boolean includeLocal) {
    this.includeLocal = includeLocal;
  }

  protected PsiReference[] create(XmlAttributeValue attribute) {

    PsiReference ref = new XmlValueReference(attribute, includeLocal ? "Forward" : CANONICAL, icon, ForwardReferenceProvider.this) {

      public PsiElement doResolve() {
        StrutsModel model = StrutsManager.getInstance().getStrutsModel(myValue);
        if (model == null) {
          return null;
        }
        else {
          String val = myValue.getValue();
          Forward el = model.findForward(val);
          if (el != null) {
            return el.getName().getXmlAttributeValue();
          }
          else if (includeLocal) {
          }
          return null;
        }
      }

      public Object[] doGetVariants() {
        StrutsModel model = StrutsManager.getInstance().getStrutsModel(myValue);
        if (model == null) {
          return null;
        }
        return getItems(model.getForwards());
      }
    };
    return new PsiReference[] {ref};
  }
}

