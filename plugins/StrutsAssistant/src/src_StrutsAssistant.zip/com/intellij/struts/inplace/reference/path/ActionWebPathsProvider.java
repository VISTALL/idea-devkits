/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference.path;

import com.intellij.codeInsight.daemon.QuickFixProvider;
import com.intellij.codeInsight.daemon.impl.HighlightInfo;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.javaee.web.WebPath;
import com.intellij.javaee.web.WebPathImpl;
import com.intellij.javaee.web.WebPathsProvider;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiReference;
import com.intellij.psi.PsiReferenceBase;
import com.intellij.psi.xml.XmlElement;
import com.intellij.struts.ServletMappingInfo;
import com.intellij.struts.StrutsManager;
import com.intellij.struts.StrutsModel;
import com.intellij.struts.dom.Action;
import com.intellij.util.Function;
import com.intellij.util.xml.ElementPresentationManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * @author Dmitry Avdeev
 */
public class ActionWebPathsProvider implements WebPathsProvider {

  @Nullable
  public WebPath getPath(@NotNull String path, @NotNull WebModuleProperties properties, @NotNull final PsiFile context) {
    StrutsModel model = StrutsManager.getInstance().getStrutsModel(context);
    if (model != null) {
      Action action = model.findAction(path);
      if (action != null) {
        return new WebPathImpl(path, this, null);
      }
    }
    return null;
  }

  public boolean createReferences(@NotNull PsiElement psiElement, @NotNull final List<PsiReference> references, final boolean soft) {

    final StrutsModel model = StrutsManager.getInstance().getStrutsModel(psiElement);

    if (model != null) {
      ActionReference reference = new ActionReference((XmlElement)psiElement, soft, model);
      references.add(reference);
      String url = reference.getValue();
      final ServletMappingInfo info = model.getServletMappingInfo();
        TextRange range = info.getActionRange(url);
        if (range != null) {
          range = range.shiftRight(reference.getRangeInElement().getStartOffset());
          reference.setRangeInElement(range);
          PsiReference mappingReference = info.getMappingReference((XmlElement)psiElement, url, soft);
          if (mappingReference != null) {
            references.add(mappingReference);
          }
          return true;
        }
      reference.setMappingFound(false);
      return false;
    }
    return false;
  }

  private static class ActionReference extends PsiReferenceBase<XmlElement> implements QuickFixProvider {
    private final StrutsModel myModel;
    private boolean myMappingFound = true;

    public ActionReference(final XmlElement element, final boolean soft, StrutsModel model) {
      super(element, soft);
      myModel = model;
    }

    @Nullable
    public PsiElement resolve() {
      if (!myMappingFound) {
        return null;
      }
      String url = getValue();
      Action action = myModel.findAction(url);
      if (action != null) {
        return action.getPath().getXmlTag();
      }
      else {
        return null;
      }
    }

    public Object[] getVariants() {
      final ServletMappingInfo info = myModel.getServletMappingInfo();
      List<Action> actions = myModel.getActions();
      return ElementPresentationManager.getInstance().createVariants(actions, new Function<Action, String>() {
        @Nullable
        public String fun(final Action action) {
          final String actionPath = action.getPath().getValue();
          return actionPath == null ? null : info.createUrl(actionPath);
        }
      });
    }

    public void setMappingFound(final boolean mappingFound) {
      myMappingFound = mappingFound;
    }

    public void registerQuickfix(HighlightInfo info, PsiReference reference) {
      // todo create "addMapping" quickfix
    }
  }
}
