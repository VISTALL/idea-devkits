/**
 * Gutter icons/navigation functionality.
 */
package com.intellij.struts.inplace.gutter;