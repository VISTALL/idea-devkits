/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference.code;

import com.intellij.psi.*;
import com.intellij.psi.filters.ElementFilter;
import com.intellij.psi.util.InheritanceUtil;
import org.jetbrains.annotations.NonNls;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * ElementFilter for finding method calls on elements of given class.
 * <p/>
 * Taken from GWT plugin.
 */
public class PsiMethodCallFilter implements ElementFilter {
  @NonNls
  private String myClassName;
  @NonNls
  private Set<String> myMethodNames;

  public PsiMethodCallFilter(@NonNls final String className, @NonNls final String... methodNames) {
    myClassName = className;
    myMethodNames = new HashSet<String>(Arrays.asList(methodNames));
  }

  public boolean isAcceptable(final Object element, final PsiElement context) {
    if (element instanceof PsiMethodCallExpression) {
      final PsiMethodCallExpression callExpression = (PsiMethodCallExpression) element;
      final PsiMethod psiMethod = callExpression.resolveMethod();
      if (psiMethod != null) {
        if (!myMethodNames.contains(psiMethod.getName())) {
          return false;
        }
        final PsiClass psiClass = psiMethod.getContainingClass();
        final PsiClass expectedClass = PsiManager.getInstance(psiClass.getProject()).findClass(myClassName, psiClass.getResolveScope());
        return InheritanceUtil.isInheritorOrSelf(psiClass, expectedClass, true);
      }
    }
    return false;
  }

  public boolean isClassAcceptable(final Class hintClass) {
    return PsiMethodCallExpression.class.isAssignableFrom(hintClass);
  }

  @NonNls
  public String toString() {
    return "PsiMethodCallFilter(" + myClassName + "." + myMethodNames + ")";
  }

}