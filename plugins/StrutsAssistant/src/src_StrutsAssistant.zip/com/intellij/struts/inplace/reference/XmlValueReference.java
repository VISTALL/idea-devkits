/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference;

import com.intellij.codeInsight.daemon.QuickFixProvider;
import com.intellij.codeInsight.daemon.impl.HighlightInfo;
import com.intellij.codeInsight.daemon.impl.quickfix.QuickFixAction;
import com.intellij.codeInsight.intention.IntentionAction;
import com.intellij.codeInsight.lookup.LookupValueFactory;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiDocumentManager;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiReference;
import com.intellij.psi.impl.source.resolve.reference.PsiReferenceProvider;
import com.intellij.psi.impl.source.resolve.reference.ReferenceType;
import com.intellij.psi.impl.source.resolve.reference.impl.GenericReference;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.util.IncorrectOperationException;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.ElementPresentationManager;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.util.Collection;

/**
 */
public abstract class XmlValueReference extends GenericReference implements QuickFixProvider {

  protected final XmlAttributeValue myValue;
  protected final String myCanonical;

  public void setSoft(boolean soft) {
    mySoft = soft;
  }

  protected boolean mySoft;
  private final Icon myIcon;
  protected final TextRange myRange;
  protected final PsiReferenceProvider myProvider;

  /**
   * may affect getRangeInElement() and getUnresolvedMessage()
   */
  protected int errorType;

  protected final static int ERROR_NO = 0;
  protected final static int ERROR_EMPTY = 1;
  protected final static int ERROR_DEFAULT = 2;

  @NonNls protected String nameProperty = "name";

  protected int quickFixes;
  protected final static int QUICK_FIX_CHOOSE = 1;
  protected final static int QUICK_FIX_CREATE = 2;

  public XmlValueReference(XmlAttributeValue attribute, @NonNls String canonical, PsiReferenceProvider provider) {

    this(attribute, null, canonical, null, provider);
  }

  public XmlValueReference(XmlAttributeValue attribute, @NonNls String canonical, Icon icon, PsiReferenceProvider provider) {

    this(attribute, null, canonical, icon, provider);
  }

  public XmlValueReference(XmlAttributeValue attribute, TextRange range, @NonNls String canonical, PsiReferenceProvider provider) {

    this(attribute, range, canonical, null, provider);
  }

  public XmlValueReference(XmlAttributeValue attribute,
                           TextRange range,
                           @NonNls String canonical,
                           Icon icon,
                           PsiReferenceProvider provider) {

    super(provider);
    myRange = range == null ? new TextRange(1, attribute.getValue().length() + 1) : range;
    myProvider = provider;
    myValue = attribute;
    myCanonical = canonical;
    myIcon = icon;
    quickFixes = QUICK_FIX_CHOOSE;
  }

  @NotNull
  public Project getProject() {
    return myValue.getProject();
  }

  @Nullable
  public Module getModule() {
    return ModuleUtil.findModuleForPsiElement(myValue);
  }

  protected PsiFile getFile() {
    PsiFile psiFile = myValue.getContainingFile();
    if (!psiFile.isPhysical()) {
      psiFile = psiFile.getOriginalFile();
    }

    return psiFile;
  }

  @Nullable
  protected Object[] getItems(String[] names) {
    if (names == null) {
      return null;
    }
    Object[] result = new Object[names.length];
    for (int i = 0; i < names.length; i++) {
      result[i] = LookupValueFactory.createLookupValue(names[i], myIcon);
    }
    return result;
  }

  @Nullable
  protected static Object[] getItems(Collection<? extends DomElement> elements) {
    if (elements == null) {
      return null;
    }
    return ElementPresentationManager.getInstance().createVariants(elements);
  }

  @NotNull
  protected String getValue() {
    String s = myValue.getValue();
    if (myRange == null) {
      return s;
    }
    else {
      return s.substring(myRange.getStartOffset() - 1, myRange.getEndOffset() - 1);
    }
  }

  public String getCanonicalText() {
    return myCanonical + " " + getValue();
  }

  public PsiElement bindToElement(PsiElement psiElement) throws IncorrectOperationException {
    return null;
  }

  public PsiElement getElement() {
    return myValue;
  }

  public Object[] getVariants() {
    return doGetVariants();
  }

  public TextRange getRangeInElement() {
    switch (errorType) {
      case ERROR_EMPTY:
        return new TextRange(1, getValue().length() + 1);
      default:
    }

    if (myRange == null) {
      return new TextRange(1, getValue().length() + 1);
    }
    else {
      return myRange;
    }
  }

  /**
   * Base resolver
   *
   * @return null if the attribute is empty
   */
  public PsiElement resolve() {
    if (myValue.getValue().trim().length() == 0) {
      errorType = ERROR_EMPTY;
      return null;
    }
    else {
      errorType = ERROR_NO;
      PsiElement result = doResolve();
      if (result == null && errorType == ERROR_NO) {
        errorType = ERROR_DEFAULT;
      }
      return result;
    }
  }

  @Nullable
  protected abstract PsiElement doResolve();

  @Nullable
  protected abstract Object[] doGetVariants();

  public boolean isReferenceTo(PsiElement psielement) {
    return psielement.getManager().areElementsEquivalent(psielement, resolve());
  }

  @Nullable
  public PsiElement getContext() {
    return null;
  }

  @Nullable
  public PsiReference getContextReference() {
    return null;
  }

  @Nullable
  public ReferenceType getType() {
    return null; //ReferenceType.NONE;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public ReferenceType getSoftenType() {
    return getType();
  }

  public boolean needToCheckAccessibility() {
    return false;
  }

  public boolean isSoft() {
    return mySoft;
  }

  public String getUnresolvedMessagePattern() {
    switch (errorType) {
      case ERROR_EMPTY:
        return "Wrong attribute value";
      default:
        return "Cannot resolve " + getCanonicalText();
    }
  }

  protected String createNewQuickFix() {
    /*
    FileAdapter config = null; //getConfigFile();
    if (config != null) {
        SmartAction action = WizardFactory.getInstance().getAction(actionName, project, config);
        if (action != null) {
            try {
                ActionEvent event = new ActionEvent(action, 0, getValue());

                Object result = action.perform(event);
                if (result instanceof PropertiesSource) {
                    Property p = ((PropertiesSource)result).getProperty(nameProperty);
                    if (p != null) {
                        return (String)p.getValue();
                    }
                }
            }
            catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
    }
    */
    return null;
  }

  public void registerQuickfix(HighlightInfo highlightInfo, PsiReference psiReference) {

    if ((quickFixes & QUICK_FIX_CREATE) != 0) {
      IntentionAction action = new BaseIntentionAction("Create") {

        public String getText() {
          return "Create new " + getCanonicalText();
        }

        public void invoke(Project project, Editor editor, PsiFile file) throws IncorrectOperationException {
          String newValue = createNewQuickFix();
          if (newValue != null) {
            PsiDocumentManager.getInstance(project).commitAllDocuments();
            handleElementRename(newValue);
          }
        }
      };
      QuickFixAction.registerQuickFixAction(highlightInfo, action);
    }

    if ((quickFixes & QUICK_FIX_CHOOSE) != 0) {
      IntentionAction action = new BaseIntentionAction("Create") {

        public String getText() {
          return "Choose an existing " + myCanonical;
        }

        public void invoke(Project project, Editor editor, PsiFile file) {
          int offset = myValue.getTextOffset() + getRangeInElement().getStartOffset() - 1;
          editor.getCaretModel().moveToOffset(offset);
          new StrutsAutoLookupHandler().invoke(project, editor, file);
        }

        /**
         * Checks whether this intention is available at a caret offset in file.
         * If this method returns true, a light bulb for this intention is shown.
         */
        public boolean isAvailable(Project project, Editor editor, PsiFile file) {
          Object[] variants = null; //doGetVariants();
          return variants != null && variants.length > 0;
        }
      };
      QuickFixAction.registerQuickFixAction(highlightInfo, action);
    }
  }
}
