/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference.lookup;

import com.intellij.codeInsight.completion.CompletionContext;
import com.intellij.codeInsight.completion.DefaultInsertHandler;
import com.intellij.codeInsight.completion.LookupData;
import com.intellij.codeInsight.lookup.LookupItem;
import com.intellij.struts.config.CompletionSettings;
import com.intellij.struts.config.StrutsConfiguration;
import com.intellij.struts.inplace.StrutsAutoPopupController;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 20.10.2005
 * Time: 12:29:07
 * To change this template use File | Settings | File Templates.
 */
public class SmartInsertHandler extends DefaultInsertHandler {

  public final static SmartInsertHandler INSTANCE = new SmartInsertHandler();

  /**
   * Let's try the first approach: replace ENTIRE attribute value with fullValue from the item
   * <p/>
   * Three main usecases:
   * 1) simple value, e.g. form name.
   * 2) class name (set .)
   * 3) path (set /)
   * 4) The most interesting is COMMA-DELIMITED list
   *
   * @param context
   * @param i
   * @param lookupData
   * @param item
   * @param b
   * @param c
   */
  public void handleInsert(CompletionContext context, int i, LookupData lookupData, LookupItem item, boolean b, char c) {

//        com.intellij.codeInsight.AutoPopupController.getInstance(null).autoPopupXmlLookup();
    Object o = item.getObject();
    String s;
    if (o instanceof EnhancedItem && ((EnhancedItem)o).getValueWithPrefix() != null) {
      s = ((EnhancedItem)o).getValueWithPrefix();
    }
    else {
      s = item.getLookupString();
    }

    CharSequence chars = context.editor.getDocument().getCharsSequence();
    int start = context.startOffset;

    search:
    for (; start > 0; start--) {
      switch (chars.charAt(start)) {
        case'"':
        case',':
        case'>':
          start++;
          break search;
      }
    }

    // the range including "IntellijIdeaRulezz "
//            TextRange range = ((BaseLookupItem)o).getTextRange();
//            start += range.getStartOffset();

//            int end = start + 1;

    // here, the "s" is already inserted- "IntellijIdeaRulezz ".length()
    int end = start; // + range.getLength()  + s.length();

    loop:
    for (; end < chars.length(); end++) {
      switch (chars.charAt(end)) {
        case'"':
        case',':
        case'?':
        case'<':
          break loop;
      }
    }

//            String from = chars.subSequence(start, end).toString();
    context.editor.getDocument().replaceString(start, end, s);

    super.handleInsert(context, i, lookupData, item, b, c);    //To change body of overridden methods use File | Settings | File Templates.

    context.editor.getCaretModel().moveToOffset(start + s.length());
//            int old = context.editor.getCaretModel().getOffset();

    CompletionSettings settings = StrutsConfiguration.getInstance().completion;
    if (settings.chainPath && s.endsWith("/")) {
      StrutsAutoPopupController.getInstance(context.project).autoPopupXmlLookup(settings.chainDelay, -1);
    }
    else if (settings.chain && s.endsWith(".")) {
      StrutsAutoPopupController.getInstance(context.project).autoPopupXmlLookup(settings.chainDelay, -1);
    }
  }
}
