/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference;

import com.intellij.javaee.web.WebUtil;
import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.lang.properties.ResourceBundleReference;
import com.intellij.lang.properties.ResourceBundleReferenceProvider;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.TextRange;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VirtualFileManager;
import com.intellij.psi.*;
import com.intellij.psi.filters.AndFilter;
import com.intellij.psi.filters.ClassFilter;
import com.intellij.psi.filters.ScopeFilter;
import com.intellij.psi.filters.position.ParentElementFilter;
import com.intellij.psi.impl.source.resolve.reference.PsiReferenceProvider;
import com.intellij.psi.impl.source.resolve.reference.ReferenceProvidersRegistry;
import com.intellij.psi.impl.source.resolve.reference.impl.providers.PathListReferenceProvider;
import com.intellij.psi.impl.source.resolve.reference.impl.providers.WebPathReferenceProvider;
import com.intellij.psi.impl.source.resolve.reference.impl.providers.JavaClassReferenceProvider;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.psi.xml.XmlTag;
import com.intellij.struts.dom.PlugIn;
import com.intellij.struts.dom.converters.StrutsPagesReferenceProvider;
import com.intellij.struts.facet.StrutsFacet;
import com.intellij.struts.inplace.Filters;
import com.intellij.struts.inplace.reference.code.FindForwardReferenceProvider;
import com.intellij.struts.inplace.reference.code.PsiMethodCallFilter;
import com.intellij.struts.inplace.reference.config.*;
import com.intellij.struts.inplace.reference.property.FormPropertyReferenceProvider;
import com.intellij.struts.inplace.reference.property.IndexedFormPropertyReferenceProvider;
import com.intellij.struts.inplace.reference.property.SetPropertyReferenceProvider;
import com.intellij.struts.inplace.reference.property.ValidatorFormPropertyReferenceProvider;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Registers all ReferenceProviders.
 *
 * @author Dmitry Avdeev
 */
public class StrutsReferenceProvider extends SmartReferenceProvider implements ProjectComponent {

  private final PsiReferenceProvider actionProvider;
  private final PsiReferenceProvider moduleProvider = new ModuleReferenceProvider();
  private final PsiReferenceProvider forwardProvider;

  private final PsiReferenceProvider pathProvider;
  private final PsiReferenceProvider softPathProvider;
  private final PsiReferenceProvider relativePathProvider;

  private final PsiReferenceProvider rolesProvider;
  private final PsiReferenceProvider singleRoleProvider;
  private final PsiReferenceProvider tileProvider;
  private final PsiReferenceProvider myJspFormPropertyProvider;

  private final PsiReferenceProvider propProvider;
  private final PsiReferenceProvider originalPropProvider;

  @NonNls
  public static final String VALIDATOR_RULES_XML = "/org/apache/struts/validator/validator-rules.xml";
  @NonNls private static final String DATA_SOURCE = "data-source";

  public StrutsReferenceProvider(final Project project) {
    super(project);

    actionProvider = new ActionReferenceProvider();
    forwardProvider = new ForwardReferenceProvider(false);
    rolesProvider = new RolesReferenceProvider(false);
    singleRoleProvider = new RolesReferenceProvider(true);

    final StrutsPagesReferenceProvider pagesReferenceProvider = new StrutsPagesReferenceProvider();

    pathProvider = new PathReferenceAdapter(pagesReferenceProvider, false);
    softPathProvider = new PathReferenceAdapter(pagesReferenceProvider, true);
    relativePathProvider = new WebPathReferenceProvider(false, true, true);

    tileProvider = new TilesReferenceProvider(false);
    myJspFormPropertyProvider = new FormPropertyReferenceProvider();
    originalPropProvider = registry.getProviderByType(ReferenceProvidersRegistry.PROPERTIES_FILE_KEY_PROVIDER);
    
    propProvider = new WrappedReferenceProvider(originalPropProvider){

      protected boolean accept(@NotNull final PsiElement psiElement) {
        return isPropertiesValidationEnabled(psiElement);
      }
    };

// TODO ??? IntentionManager.getInstance(project).addAction(new AddDeclarationIntention(ActionReferenceProvider.icon));
  }

  private static boolean isPropertiesValidationEnabled(final PsiElement psiElement) {
    final WebFacet webFacet = WebUtil.getWebFacet(psiElement);
    if (webFacet == null) {
      return false;
    }
    final StrutsFacet strutsFacet = StrutsFacet.getInstance(webFacet);
    return strutsFacet == null || !strutsFacet.getConfiguration().getValidationConfiguration().mySuppressPropertiesValidation;
  }

  @NonNls
  @NotNull
  public String getComponentName() {
    return "StrutsReferenceProvider";
  }

  public void initComponent() {

    registerStrutsConfigReferences();

    registerJspReferences();

    registerJspTilesTags();

    registerTilesReferences();

    registerValidationReferences();

    registerWebAppReferences();

    registerCodeReferences();
  }

  public void disposeComponent() {
  }

  public void projectOpened() {
  }

  public void projectClosed() {
  }

  private void registerCodeReferences() {
    // actionMapping.findForward(XXX)
    // TODO: trigger only in Action-subclasses
    registry.registerReferenceProvider(
      new ParentElementFilter(new PsiMethodCallFilter("org.apache.struts.action.ActionMapping", "findForward"), 2),
      PsiLiteralExpression.class,
      new FindForwardReferenceProvider());
  }

  private void registerStrutsConfigReferences() {

    registerTags(rolesProvider, "roles", Filters.NAMESPACE_STRUTS_CONFIG, "action");

    registerTags(new SetPropertyReferenceProvider("className", "type") {

      protected String getClassNameAttribute(final XmlTag tag) {
        if (tag.getLocalName().equals(DATA_SOURCE)) {
          return "type";
        } else {
          return super.getClassNameAttribute(tag);
        }
      }
    }, "property", Filters.NAMESPACE_STRUTS_CONFIG, "set-property");

    registerTags(new PathListReferenceProvider() {

      protected PsiReference[] createReferences(final PsiElement element, final String s, final int offset, boolean soft) {
        final PsiElement tag = element.getParent().getParent().getParent();
        soft = tag instanceof XmlTag && !((XmlTag) tag).getName().equals(PlugIn.PLUGIN);
        if (s.equals(VALIDATOR_RULES_XML)) {
          final PsiReferenceBase<PsiElement> reference =
            new PsiReferenceBase<PsiElement>(element, new TextRange(offset, offset + s.length())) {
              public PsiElement resolve() {
                return resolveValidatorConfigInJAR(project);
              }

              public Object[] getVariants() {
                return new Object[0];
              }
            };
          return new PsiReference[]{reference};
        }
        return super.createReferences(element, s, offset, soft);
      }
    }, "value", Filters.NAMESPACE_STRUTS_CONFIG, "set-property");

    registerTags(new ResourceBundleReferenceProvider() {

      @NotNull
      public PsiReference[] getReferencesByElement(final PsiElement element) {
        final XmlTag tag = (XmlTag) element.getParent().getParent();
        final String factory = tag.getAttributeValue("factory");
        final boolean soft = factory != null;
        final ResourceBundleReference reference = new ResourceBundleReference(element, soft);
        return new PsiReference[]{reference};
      }
    }, "parameter", Filters.NAMESPACE_STRUTS_CONFIG, "message-resources");

    registerTags(propProvider, "key", Filters.NAMESPACE_STRUTS_CONFIG, "exception");

    registerTags(moduleProvider, "module", Filters.NAMESPACE_STRUTS_CONFIG, "forward");
  }

  private void registerWebAppReferences() {
    registry.registerReferenceProvider(Filters.andTagValue(Filters.NAMESPACE_WEBAPP, "param-value"), XmlTag.class,
                                       new WebAppPathListProvider());
  }

  private void registerJspReferences() {

    // Struts html taglib  -------------------------------------------------

    // action + paths stuff
    registerTags(actionProvider,
                 "action", Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                 "form", "frame", "img", "link", "rewrite");

    registerTags(moduleProvider,
                 "module", Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                 "frame", "img", "image", "link", "rewrite");

    registerTags(forwardProvider,
                 "forward", Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                 "frame", "link", "rewrite");

    registerTags(pathProvider,
                 "page", Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                 "frame", "link", "rewrite", "img", "image");

    registerTags(softPathProvider,
                 "href", Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                 "frame", "link", "rewrite");

    // img, image
    registerTags(softPathProvider,
                 "src", Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                 "img", "image");

    // form stuff
    registerTags(myJspFormPropertyProvider,
                 "property", Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                 "button", "cancel", "checkbox", "file", "hidden", "img", "link", "multibox",
                 "option", "options", "optionsCollection", "password", "radio", "select", "text", "textarea");

    registerTags(myJspFormPropertyProvider,
                 "labelProperty", Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                 "options");

    registerTags(myJspFormPropertyProvider,
                 "focus", Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                 "form");

    registerTags(new FormReferenceProvider(),
                 "formName", Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                 "javascript");


    registry.registerXmlAttributeValueReferenceProvider(
      new String[]{"altKey","titleKey","pageKey","srcKey"},
      new ScopeFilter(
        new ParentElementFilter(
          new AndFilter(
            Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
            new ClassFilter(XmlTag.class)
          ), 2
        )
      ), propProvider);

    // Struts logic/bean taglib -------------------------------------------------

    // <logic:redirect>
    registerTags(actionProvider,
                 "action", Filters.NAMESPACE_TAGLIB_STRUTS_LOGIC,
                 "redirect");

    registerTags(softPathProvider,
                 "href", Filters.NAMESPACE_TAGLIB_STRUTS_LOGIC,
                 "redirect");

    registerTags(pathProvider,
                 "page", Filters.NAMESPACE_TAGLIB_STRUTS_LOGIC,
                 "redirect");

    registerTags(actionProvider,
                 "mapping", Filters.NAMESPACE_TAGLIB_STRUTS_BEAN,
                 "struts");

    // forwards
    registerTags(forwardProvider,
                 "forward", Filters.NAMESPACE_TAGLIB_STRUTS_LOGIC,
                 "redirect");

    registerTags(forwardProvider,
                 "forward", Filters.NAMESPACE_TAGLIB_STRUTS_BEAN,
                 "include", "struts");

    registerTags(forwardProvider,
                 "name", Filters.NAMESPACE_TAGLIB_STRUTS_LOGIC,
                 "forward");

    // <bean:define>
    final JavaClassReferenceProvider classReferenceProvider = new JavaClassReferenceProvider();
    classReferenceProvider.setOption(JavaClassReferenceProvider.ADVANCED_RESOLVE, Boolean.TRUE);
    registerTags(classReferenceProvider,
                 "type", Filters.NAMESPACE_TAGLIB_STRUTS_BEAN, "define");
  }

  private void registerJspTilesTags() {

    registerSubclass(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "insert", "controllerClass",
                     "org.apache.struts.tiles.Controller",
                     "org.apache.struts.tiles.ControllerSupport",
                     "org.apache.struts.action.Action");

    // <tiles:insert>
    registerTags(tileProvider,
                 "definition", Filters.NAMESPACE_TAGLIB_STRUTS_TILES,
                 "insert");

    registerAttributes(relativePathProvider, "insert", Filters.NAMESPACE_TAGLIB_STRUTS_TILES,
                       "page", "component", "template");

    registerTags(pathProvider,
                 "controllerUrl", Filters.NAMESPACE_TAGLIB_STRUTS_TILES,
                 "insert");

    registerTags(singleRoleProvider,
                 "role", Filters.NAMESPACE_TAGLIB_STRUTS_TILES,
                 "insert");

    // <tiles:definition>
    registerTags(tileProvider,
                 "extends", Filters.NAMESPACE_TAGLIB_STRUTS_TILES,
                 "definition");

    registerAttributes(pathProvider, "definition", Filters.NAMESPACE_TAGLIB_STRUTS_TILES,
                       "page", "template");

    registerTags(singleRoleProvider,
                 "role", Filters.NAMESPACE_TAGLIB_STRUTS_TILES,
                 "definition");

    // <tiles:put>
    registerTags(new TilesValueReferenceProvider(),
                 "value", Filters.NAMESPACE_TAGLIB_STRUTS_TILES,
                 "put");

    registerTags(new TilesJSPPutsReferenceProvider(),
                 "name", Filters.NAMESPACE_TAGLIB_STRUTS_TILES,
                 "put");

    registerSubclass(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "useAttribute", "classname");

    registerSubclass(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "initComponentDefinitions", "classname",
                     "org.apache.struts.tiles.DefinitionsFactory");
  }

  private void registerTilesReferences() {

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"link", "icon"},
                                                        Filters.andTagName(Filters.NAMESPACE_TILES_CONFIG, "item"),
                                                        softPathProvider);
/*   TODO what's up with this?
    registerSubclass(Filters.NAMESPACE_TILES_CONFIG, "definition", new String[]{"controllerClass"}, new String[]{
      "org.apache.struts.tiles.Controller", "org.apache.struts.tiles.ControllerSupport", "org.apache.struts.action.Action"});
*/
    registerTags(new SetPropertyReferenceProvider("classtype", null),
                 "property", Filters.NAMESPACE_TILES_CONFIG,
                 "set-property");

    // <put>
    registerTags(new TilesValueReferenceProvider(),
                 "value", Filters.NAMESPACE_TILES_CONFIG,
                 "put");

    registerTags(new TilesPutsReferenceProvider(),
                 "name", Filters.NAMESPACE_TILES_CONFIG,
                 "put");
  }

  private void registerValidationReferences() {

    // form, fields
    registerTags(new ValidatorFormReferenceProvider(), "name", Filters.NAMESPACE_VALIDATOR_CONFIG, "form");

    registerTags(new ValidatorFormPropertyReferenceProvider(),
                 "property", Filters.NAMESPACE_VALIDATOR_CONFIG, "field");

    registerTags(new IndexedFormPropertyReferenceProvider(),
                 "indexedListProperty", Filters.NAMESPACE_VALIDATOR_CONFIG, "field");

    // TODO move to DOM w/ customized DependsConverter
    final ValidatorReferenceProvider myWrappedValidatorProvider = new ValidatorReferenceProvider() {

      @NotNull
      public PsiReference[] getReferencesByElement(final PsiElement psiElement) {
        final String value = ((XmlAttributeValue) psiElement).getValue();
        if (StringUtil.isEmpty(value)) {
          return PsiReference.EMPTY_ARRAY;
        }
        return super.getReferencesByElement(psiElement);
      }
    };

    registerTags(myWrappedValidatorProvider, "depends", Filters.NAMESPACE_VALIDATOR_CONFIG, "validator");

    // messages
    final WrappedReferenceProvider msgProvider = new WrappedReferenceProvider(originalPropProvider) {
      protected boolean accept(@NotNull final PsiElement psiElement) {
        if (!isPropertiesValidationEnabled(psiElement)) {
          return false;
        }
        final PsiElement element = psiElement.getContext();
        assert element != null;
        final PsiElement context = element.getContext();
        if (context instanceof XmlTag) {
          @NonNls final String res = ((XmlTag) context).getAttributeValue("classname");
          if (res == null || res.trim().length() == 0) {
            return false;
          }
        }
        return true;
      }
    };
    registerTags(msgProvider, "msg", Filters.NAMESPACE_VALIDATOR_CONFIG, "validator");


    final WrappedReferenceProvider myWrappedPropProvider = new WrappedReferenceProvider(originalPropProvider) {
      protected boolean accept(@NotNull final PsiElement psiElement) {
        if (!isPropertiesValidationEnabled(psiElement)) {
          return false;
        }
        final PsiElement element = psiElement.getContext();
        assert element != null;
        final PsiElement context = element.getContext();
        if (context instanceof XmlTag) {
          @NonNls final String res = ((XmlTag) context).getAttributeValue("resource");
          if (res != null && res.equals("false")) {
            return false;
          }
        }
        return true;
      }
    };

    registerTags(myWrappedPropProvider, "key", Filters.NAMESPACE_VALIDATOR_CONFIG,
                 "msg", "arg", "arg0", "arg1", "arg2", "arg3");
  }

  /**
   * Struts 1.3: Resolves the default <code>validator-rules.xml</code> configuration file located in struts.jar.
   *
   * @param project Project.
   * @return Reference to file or null if not resolved.
   */
  @Nullable
  public static PsiFile resolveValidatorConfigInJAR(final Project project) {

    final PsiClass psiClass =
      PsiManager.getInstance(project).findClass("org.apache.struts.validator.ValidatorForm", GlobalSearchScope.allScope(project));
    if (psiClass == null) {
      return null;
    }
    final VirtualFile file = psiClass.getContainingFile().getVirtualFile();
    if (file == null) {
      return null;
    }
    String formPath = file.getUrl();
    formPath = StringUtil.replace(formPath, "ValidatorForm.class", "validator-rules.xml");

    final VirtualFile virtualFile = VirtualFileManager.getInstance().findFileByUrl(formPath);
    if (virtualFile == null) {
      return null;
    } else {
      return PsiManager.getInstance(project).findFile(virtualFile);
    }
  }

}