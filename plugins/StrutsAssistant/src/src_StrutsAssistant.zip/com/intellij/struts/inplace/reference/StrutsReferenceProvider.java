/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference;

import com.intellij.lang.properties.ResourceBundleReference;
import com.intellij.lang.properties.ResourceBundleReferenceProvider;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.TextRange;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VirtualFileManager;
import com.intellij.psi.*;
import com.intellij.psi.impl.source.resolve.reference.PsiReferenceProvider;
import com.intellij.psi.impl.source.resolve.reference.ReferenceProvidersRegistry;
import com.intellij.psi.impl.source.resolve.reference.impl.providers.PathListReferenceProvider;
import com.intellij.psi.impl.source.resolve.reference.impl.providers.WebPathReferenceProvider;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.xml.XmlTag;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.struts.config.StrutsConfiguration;
import com.intellij.struts.dom.PlugIn;
import com.intellij.struts.inplace.Filters;
import com.intellij.struts.inplace.reference.config.*;
import com.intellij.struts.inplace.reference.property.FormPropertyReferenceProvider;
import com.intellij.struts.inplace.reference.property.IndexedFormPropertyReferenceProvider;
import com.intellij.struts.inplace.reference.property.SetPropertyReferenceProvider;
import com.intellij.struts.inplace.reference.property.ValidatorFormPropertyReferenceProvider;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;


public class StrutsReferenceProvider extends SmartReferenceProvider {

  private final PsiReferenceProvider actionProvider;
  private final PsiReferenceProvider forwardProvider;

  private final PsiReferenceProvider pathProvider;
  private final PsiReferenceProvider softPathProvider;

  private final PsiReferenceProvider rolesProvider;
  private final PsiReferenceProvider singleRoleProvider;
  private final PsiReferenceProvider validatorProvider;
  private final PsiReferenceProvider tileProvider;
  private final PsiReferenceProvider myJspFormPropertyProvider;

  private final PsiReferenceProvider propProvider;
  private final PsiReferenceProvider originalPropProvider;

  @NonNls public static final String VALIDATOR_RULES_XML = "/org/apache/struts/validator/validator-rules.xml";

  public StrutsReferenceProvider(Project project) {
    super(project);

    actionProvider = new ActionReferenceProvider(true);
    forwardProvider = new ForwardReferenceProvider(false);
    rolesProvider = new RolesReferenceProvider();
    singleRoleProvider = new RolesReferenceProvider(true);
    validatorProvider = new ValidatorReferenceProvider();

    pathProvider = new WebPathReferenceProvider(false);
    softPathProvider = new WebPathReferenceProvider(true);

    tileProvider = new TilesReferenceProvider();
    myJspFormPropertyProvider = new FormPropertyReferenceProvider();
    originalPropProvider = registry.getProviderByType(ReferenceProvidersRegistry.PROPERTIES_FILE_KEY_PROVIDER);
    propProvider = new WrappedReferenceProvider(originalPropProvider);

//        IntentionManager.getInstance(project).addAction(new AddDeclarationIntention(ActionReferenceProvider.icon));


  }


  public void initComponent() {

    if (!StrutsConfiguration.getInstance().completion.enabled) {
      return;
    }
    if (registry == null) {
      return;
    }

    registerStrutsConfigReferences();

    registerJspReferences();

    registerJspTilesTags();

    registerTilesReferences();

    registerValidationReferences();

    registerWebAppReferences();
  }

  protected void registerStrutsConfigReferences() {

    // register declarations
//    registerProvider(Filters.NAMESPACE_STRUTS_CONFIG, "form-property", "type", new DynaPropertyReferenceProvider());

    registerProvider(Filters.NAMESPACE_STRUTS_CONFIG, "action", "roles", rolesProvider);

    registerProvider(Filters.NAMESPACE_STRUTS_CONFIG, "set-property", "property", new SetPropertyReferenceProvider("className", "type"));

    registerProvider(Filters.NAMESPACE_STRUTS_CONFIG, "set-property", "value", new PathListReferenceProvider() {

      protected PsiReference[] createReferences(PsiElement element, final String s, int offset, boolean soft) {
        final PsiElement tag = element.getParent().getParent().getParent();
        soft = tag instanceof XmlTag && !((XmlTag)tag).getName().equals(PlugIn.PLUGIN);
        if (s.equals(VALIDATOR_RULES_XML)) {
          final PsiReferenceBase<PsiElement> reference =
            new PsiReferenceBase<PsiElement>(element, new TextRange(offset, offset + s.length())) {
              public PsiElement resolve() {
                return resolveJarFile(project);
              }

              public Object[] getVariants() {
                return new Object[0];
              }
            };
          return new PsiReference[] { reference };
        }
        return super.createReferences(element, s, offset, soft);
      }
    });

    registerProvider(Filters.NAMESPACE_STRUTS_CONFIG, "message-resources", "parameter", new ResourceBundleReferenceProvider() {

      @NotNull
      public PsiReference[] getReferencesByElement(PsiElement element) {
        final XmlTag tag = (XmlTag)element.getParent().getParent();
        final String factory = tag.getAttributeValue("factory");
        final boolean soft = factory != null;
        ResourceBundleReference reference = new ResourceBundleReference(element, soft);
        return new PsiReference[] { reference };
      }
    });
    registerProvider(Filters.NAMESPACE_STRUTS_CONFIG, "exception", "key", propProvider);
  }

  protected void registerWebAppReferences() {
    registry.registerReferenceProvider(Filters.andTagValue(Filters.NAMESPACE_WEBAPP, "param-value"), XmlTag.class,
                                       new WebAppPathListProvider());
  }

  protected void registerJspReferences() {

    // Struts html taglib
    registerProvider(Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                     new String[]{"form", "frame", "img", "link", "rewrite"}, new String[]{"action"},
                     actionProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"forward"}, Filters.andTagNames(Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                                                                                                     new String[]{"frame", "link",
                                                                                                       "rewrite"}), forwardProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"src"}, Filters.andTagNames(Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                                                                                                 new String[]{"img", "image"}),
                                                                             softPathProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"page"}, Filters.andTagNames(Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                                                                                                  new String[]{"img", "image"}),
                                                                              pathProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"page"}, Filters.andTagNames(Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                                                                                                  new String[]{"frame", "link", "rewrite"}),
                                                                              pathProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"href"}, Filters.andTagNames(Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                                                                                                  new String[]{"frame", "link", "rewrite"}),
                                                                              softPathProvider);


    registry.registerXmlAttributeValueReferenceProvider(new String[]{"property"}, Filters.andTagNames(Filters.NAMESPACE_TAGLIB_STRUTS_HTML,
                                                                                                      new String[]{"button", "cancel",
                                                                                                        "checkbox", "file", "hidden", "img",
                                                                                                        "link", "multibox", "option",
                                                                                                        "options", "optionsCollection",
                                                                                                        "password", "radio", "select",
                                                                                                        "text", "textarea"}),
                                                        myJspFormPropertyProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"labelProperty"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_HTML, "options"),
                                                        myJspFormPropertyProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"focus"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_HTML, "form"),
                                                        myJspFormPropertyProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"formName"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_HTML, "javascript"),
                                                        new FormReferenceProvider());

    // Struts logic taglib
    registry.registerXmlAttributeValueReferenceProvider(new String[]{"action"}, Filters.andTagNames(Filters.NAMESPACE_TAGLIB_STRUTS_LOGIC,
                                                                                                    new String[]{"redirect"}),
                                                                                actionProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"mapping"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_BEAN, "struts"),
                                                        new ActionReferenceProvider(false));

    // forwards
    registry.registerXmlAttributeValueReferenceProvider(new String[]{"forward"}, Filters.andTagNames(Filters.NAMESPACE_TAGLIB_STRUTS_LOGIC,
                                                                                                     new String[]{"redirect"}),
                                                                                 forwardProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"forward"}, Filters.andTagNames(Filters.NAMESPACE_TAGLIB_STRUTS_BEAN,
                                                                                                     new String[]{"include", "struts"}),
                                                                                 forwardProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"name"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_LOGIC, "forward"),
                                                        forwardProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"href"}, Filters.andTagNames(Filters.NAMESPACE_TAGLIB_STRUTS_LOGIC,
                                                                                                  new String[]{"redirect"}),
                                                                              softPathProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"page"}, Filters.andTagNames(Filters.NAMESPACE_TAGLIB_STRUTS_LOGIC,
                                                                                                  new String[]{"redirect"}),
                                                                              pathProvider);

    registerProvider(Filters.NAMESPACE_TAGLIB_STRUTS_BEAN, "define", "type",
                     registry.getProviderByType(ReferenceProvidersRegistry.CLASS_REFERENCE_PROVIDER));
  }

  private void registerJspTilesTags() {

    registerSubclass(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "insert", new String[]{"controllerClass"}, new String[]{
      "org.apache.struts.tiles.Controller", "org.apache.struts.tiles.ControllerSupport", "org.apache.struts.action.Action"});

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"definition"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "insert"),
                                                        tileProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"page", "component", "template"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "insert"),
                                                        pathProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"controllerUrl"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "insert"),
                                                        pathProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"role"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "insert"),
                                                        singleRoleProvider);

    // tiles:definition
    registry.registerXmlAttributeValueReferenceProvider(new String[]{"extends"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "definition"),
                                                        tileProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"page", "template"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "definition"),
                                                        pathProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"role"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "definition"),
                                                        singleRoleProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"value"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "put"),
                                                        new TilesValueReferenceProvider());

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"name"},
                                                        Filters.andTagName(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "put"),
                                                        new TilesJSPPutsReferenceProvider());

    registerSubclass(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "useAttribute", "classname");

    registerSubclass(Filters.NAMESPACE_TAGLIB_STRUTS_TILES, "initComponentDefinitions", "classname",
                     "org.apache.struts.tiles.DefinitionsFactory");
  }

  protected void registerTilesReferences() {

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"link", "icon"},
                                                        Filters.andTagName(Filters.NAMESPACE_TILES_CONFIG, "item"),
                                                        softPathProvider);
/*
    registerSubclass(Filters.NAMESPACE_TILES_CONFIG, "definition", new String[]{"controllerClass"}, new String[]{
      "org.apache.struts.tiles.Controller", "org.apache.struts.tiles.ControllerSupport", "org.apache.struts.action.Action"});
*/
    registry.registerXmlAttributeValueReferenceProvider(new String[]{"property"},
                                                        Filters.andTagName(Filters.NAMESPACE_TILES_CONFIG, "set-property"),
                                                        new SetPropertyReferenceProvider("classtype", null));

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"value"}, Filters.andTagName(Filters.NAMESPACE_TILES_CONFIG, "put"),
                                                        new TilesValueReferenceProvider());

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"name"}, Filters.andTagName(Filters.NAMESPACE_TILES_CONFIG, "put"),
                                                        new TilesPutsReferenceProvider());
  }

  protected void registerValidationReferences() {


    registry.registerXmlAttributeValueReferenceProvider(new String[]{"name"},
                                                        Filters.andTagName(Filters.NAMESPACE_VALIDATOR_CONFIG, "form"),
                                                        new ValidatorFormReferenceProvider());

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"property"},
                                                        Filters.andTagName(Filters.NAMESPACE_VALIDATOR_CONFIG, "field"),
                                                        new ValidatorFormPropertyReferenceProvider());

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"indexedListProperty"},
                                                        Filters.andTagName(Filters.NAMESPACE_VALIDATOR_CONFIG, "field"),
                                                        new IndexedFormPropertyReferenceProvider());

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"depends"},
                                                        Filters.andTagName(Filters.NAMESPACE_VALIDATOR_CONFIG, "field"),
                                                        validatorProvider);

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"depends"},
                                                        Filters.andTagName(Filters.NAMESPACE_VALIDATOR_CONFIG, "validator"),
                                                        new ValidatorReferenceProvider() {

                                                          @NotNull
                                                          public PsiReference[] getReferencesByElement(PsiElement psiElement) {
                                                            final String value = ((XmlAttributeValue)psiElement).getValue();
                                                            if (StringUtil.isEmpty(value)) {
                                                              return PsiReference.EMPTY_ARRAY;
                                                            }
                                                            return super.getReferencesByElement(psiElement);
                                                          }
                                                        });

    final WrappedReferenceProvider msgProvider = new WrappedReferenceProvider(originalPropProvider) {
      protected boolean accept(PsiElement psiElement) {
        final PsiElement element = psiElement.getContext();
        assert element != null;
        final PsiElement context = element.getContext();
        if (context instanceof XmlTag) {
          @NonNls final String res = ((XmlTag)context).getAttributeValue("classname");
          if (res == null || res.trim().length() == 0) {
            return false;
          }
        }
        return true;
      }
    };

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"msg"},
                                                        Filters.andTagName(Filters.NAMESPACE_VALIDATOR_CONFIG, "validator"),
                                                        msgProvider);

    final WrappedReferenceProvider provider = new WrappedReferenceProvider(originalPropProvider) {
      protected boolean accept(PsiElement psiElement) {
        final PsiElement element = psiElement.getContext();
        assert element != null;
        final PsiElement context = element.getContext();
        if (context instanceof XmlTag) {
          @NonNls final String res = ((XmlTag)context).getAttributeValue("resource");
          if (res != null && res.equals("false")) {
            return false;
          }
        }
        return true;
      }
    };

    registry.registerXmlAttributeValueReferenceProvider(new String[]{"key"}, Filters.andTagNames(Filters.NAMESPACE_VALIDATOR_CONFIG,
                                                                                                 new String[]{"msg", "arg", "arg0", "arg1",
                                                                                                   "arg2", "arg3"}), provider);
  }

  @Nullable
  public static PsiFile resolveJarFile(Project project) {

    final PsiClass psiClass =
      PsiManager.getInstance(project).findClass("org.apache.struts.validator.ValidatorForm", GlobalSearchScope.allScope(project));
    if (psiClass == null) {
      return null;
    }
    final VirtualFile file = psiClass.getContainingFile().getVirtualFile();
    if (file == null) {
      return null;
    }
    String formPath = file.getUrl();
    formPath = StringUtil.replace(formPath, "ValidatorForm.class", "validator-rules.xml");

    final VirtualFile virtualFile = VirtualFileManager.getInstance().findFileByUrl(formPath);
    if (virtualFile == null) {
      return null;
    } else {
      return PsiManager.getInstance(project).findFile(virtualFile);
    }
  }
}
