/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference.config;

import com.intellij.codeInsight.lookup.LookupValueFactory;
import com.intellij.psi.*;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.struts.inplace.reference.XmlAttributeReferenceProvider;
import com.intellij.struts.inplace.reference.XmlValueReference;
import org.jetbrains.annotations.NonNls;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 24.10.2005
 * Time: 18:37:31
 * To change this template use File | Settings | File Templates.
 */
public class DynaPropertyReferenceProvider extends XmlAttributeReferenceProvider {

//    private final static Icon icon = IconLoader.getIcon("/com/intellij/struts/icons/form-bean.png");

  protected final static int ERROR_ARRAY = 3;

  @NonNls private final static String[] primitives = new String[]{

    "java.math.BigDecimal", "java.math.BigInteger", "boolean", "java.lang.Boolean", "byte", "java.lang.Byte", "char", "java.lang.Character",
    "java.lang.Class", "double", "java.lang.Double", "float", "java.lang.Float", "int", "java.lang.Integer", "long", "java.lang.Long",
    "short", "java.lang.Short", "java.lang.String", "java.sql.Date", "java.sql.Time", "java.sql.Timestamp"};

  protected DynaPropertyReferenceProvider() {
    super("type");
  }

  static {
    Arrays.sort(primitives);
  }

  protected PsiReference[] create(XmlAttributeValue attribute) {

    PsiReference ref = new XmlValueReference(attribute, this) {

      public PsiElement doResolve() {

        String s = myValue.getValue();
        int pos = s.indexOf('[');
        if (pos >= 0) {
          if (pos != s.length() - 2 || s.charAt(pos + 1) != ']') {
            errorType = ERROR_ARRAY;
            return null;
          }
          s = s.substring(0, pos);
        }

        pos = Arrays.binarySearch(primitives, s);
        if (pos >= 0) {  // primitive found
          return myValue;
        }
        GlobalSearchScope scope = GlobalSearchScope.allScope(getProject());
        PsiManager manager = PsiManager.getInstance(getProject());
        PsiClass clazz = manager.findClass(s, scope);
        if (clazz != null) {
          PsiClass list = manager.findClass("java.util.List", scope);
          // check List or Map implementation
          if (list != null && clazz.isInheritor(list, true)) {
            return clazz;
          }
          PsiClass map = manager.findClass("java.util.Map", scope);
          // check List or Map implementation
          if (map != null && clazz.isInheritor(map, true)) {
            return clazz;
          }
          return null;
        }
        return clazz;
      }

      public Object[] doGetVariants() {
        PsiManager manager = PsiManager.getInstance(getProject());
        GlobalSearchScope scope = GlobalSearchScope.allScope(getProject());

        ArrayList<Object> lookups = new ArrayList<Object>();
        for (String primitive : primitives) {
          PsiClass clazz = manager.findClass(primitive, scope);
          Object item;
          if (clazz == null) {
            item = LookupValueFactory.createLookupValue(primitive, null);
          }
          else {
            item = clazz;
          }
          lookups.add(item);
        }
        return lookups.toArray();
      }

      public String getCanonicalText() {
        int pos = myValue.getValue().indexOf('[');
        if (pos == -1) {
          return super.getCanonicalText();
        }
        else {
          return myCanonicalName + " " + myValue.getValue().substring(0, pos);
        }
      }

      public String getUnresolvedMessagePattern() {
        switch (errorType) {
          case ERROR_ARRAY:
            return "Array declaration should end with []";
          default:
            return super.getUnresolvedMessagePattern();

        }
      }
    };
    return new PsiReference[] {ref};
  }
}