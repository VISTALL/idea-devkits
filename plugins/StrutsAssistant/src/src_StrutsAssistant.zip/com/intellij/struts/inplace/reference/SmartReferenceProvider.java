/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference;

import com.intellij.openapi.project.Project;
import com.intellij.psi.filters.position.NamespaceFilter;
import com.intellij.psi.impl.source.resolve.reference.PsiReferenceProvider;
import com.intellij.psi.impl.source.resolve.reference.ReferenceProvidersRegistry;
import com.intellij.psi.impl.source.resolve.reference.impl.providers.JavaClassReferenceProvider;
import com.intellij.struts.inplace.Filters;
import org.jetbrains.annotations.NonNls;

/**
 * @author davdeev
 */
public class SmartReferenceProvider {

  protected final Project project;
  protected final ReferenceProvidersRegistry registry;

  protected SmartReferenceProvider(Project project) {

    this.project = project;
    registry = ReferenceProvidersRegistry.getInstance(project);
  }

  protected void registerProvider(NamespaceFilter ns, @NonNls String element, @NonNls String attr, PsiReferenceProvider provider) {
    registerProvider(ns, element, new String[]{attr}, provider);
  }

  protected void registerProvider(NamespaceFilter ns, @NonNls String element, @NonNls String[] attrs, PsiReferenceProvider provider) {
    registry.registerXmlAttributeValueReferenceProvider(attrs, Filters.andTagName(ns, element), provider);
  }

  protected void registerProvider(NamespaceFilter ns, @NonNls String[] elements, @NonNls String[] attrs, PsiReferenceProvider provider) {
    registry.registerXmlAttributeValueReferenceProvider(attrs, Filters.andTagNames(ns, elements), provider);
  }

  protected void registerSubclass(NamespaceFilter ns, @NonNls String element, @NonNls String attr) {
    JavaClassReferenceProvider provider = new JavaClassReferenceProvider();
    registerProvider(ns, element, new String[]{attr}, provider);
  }

  protected void registerSubclass(NamespaceFilter ns, @NonNls String element, @NonNls String attr, @NonNls String clazz) {
    registerSubclass(ns, element, new String[]{attr}, clazz);
  }

  protected void registerSubclass(NamespaceFilter ns, @NonNls String element, @NonNls String[] attrs, @NonNls String[] classes) {
    JavaClassReferenceProvider provider = new JavaClassReferenceProvider(classes, true);
    registerProvider(ns, element, attrs, provider);
  }

  protected void registerSubclass(NamespaceFilter ns, @NonNls String element, @NonNls String[] attrs, @NonNls String clazz) {
    registerSubclass(ns, element, attrs, new String[]{clazz});
  }
}
