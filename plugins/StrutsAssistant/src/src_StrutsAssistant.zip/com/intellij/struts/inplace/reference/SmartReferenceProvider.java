/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference;

import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiReferenceProvider;
import com.intellij.psi.filters.position.NamespaceFilter;
import com.intellij.psi.impl.source.resolve.reference.ReferenceProvidersRegistry;
import com.intellij.psi.impl.source.resolve.reference.impl.providers.JavaClassReferenceProvider;
import com.intellij.struts.inplace.Filters;
import com.intellij.xml.util.XmlUtil;
import org.jetbrains.annotations.NonNls;

/**
 * Base class for installing ReferenceProviders in XML context.
 *
 * @author Dmitry Avdeev
 */
public abstract class SmartReferenceProvider {

  protected final Project project;
  protected final ReferenceProvidersRegistry registry;

  protected SmartReferenceProvider(final Project project) {
    this.project = project;
    registry = ReferenceProvidersRegistry.getInstance(project);
  }

  /**
   * Register the given provider on the given XmlAttribute(s)/Namespace/XmlTag combination.
   *
   * @param provider        Provider to install.
   * @param tagName         Tag name.
   * @param namespaceFilter Namespace for tag.
   * @param attributeNames  Attribute name(s).
   */
  protected void registerAttributes(final PsiReferenceProvider provider,
                                    final @NonNls String tagName,
                                    final NamespaceFilter namespaceFilter,
                                    final @NonNls String... attributeNames) {
    XmlUtil.registerXmlAttributeValueReferenceProvider(registry, attributeNames, Filters.andTagNames(namespaceFilter, tagName), provider);
  }

  /**
   * Register the given provider on the given XmlAttribute/Namespace/XmlTag(s) combination.
   *
   * @param provider        Provider to install.
   * @param attributeName   Attribute name.
   * @param namespaceFilter Namespace for tag(s).
   * @param tagNames        Tag name(s).
   */
  protected void registerTags(final PsiReferenceProvider provider,
                              final @NonNls String attributeName,
                              final NamespaceFilter namespaceFilter,
                              final @NonNls String... tagNames) {
    XmlUtil.registerXmlAttributeValueReferenceProvider(registry, new String[]{attributeName}, Filters.andTagNames(namespaceFilter, tagNames),
                                                       provider);
  }

  /**
   * Registers a class provider with no restrictions on the given XmlAttribute/Namespace/XmlTag combination.
   *
   * @param namespaceFilter Namespace for tag.
   * @param tagName         Tag name.
   * @param attributeName   Attribute name.
   */
  protected void registerSubclass(final NamespaceFilter namespaceFilter,
                                  final @NonNls String tagName,
                                  final @NonNls String attributeName) {
    final JavaClassReferenceProvider provider = new JavaClassReferenceProvider(project);
    registerTags(provider, attributeName, namespaceFilter, tagName);
  }

  /**
   * Registers a class provider allowing only the given subclass(es) on the given XmlAttribute/Namespace/XmlTag combination.
   *
   * @param namespaceFilter Namespace for tag.
   * @param tagName         Tag name.
   * @param attributeName   Attribute name.
   * @param classes         Sub-class(es) to allow.
   */
  protected void registerSubclass(final NamespaceFilter namespaceFilter,
                                  final @NonNls String tagName,
                                  final @NonNls String attributeName,
                                  final @NonNls String... classes) {
    final JavaClassReferenceProvider provider = new JavaClassReferenceProvider(project);
    provider.setOption(JavaClassReferenceProvider.EXTEND_CLASS_NAMES, classes);
    provider.setOption(JavaClassReferenceProvider.INSTANTIATABLE, Boolean.TRUE);
    registerTags(provider, attributeName, namespaceFilter, tagName);
  }

}