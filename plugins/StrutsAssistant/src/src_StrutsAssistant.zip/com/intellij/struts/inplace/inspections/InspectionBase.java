/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.inspections;

import com.intellij.codeInspection.InspectionManager;
import com.intellij.codeInspection.LocalInspectionTool;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.psi.PsiFile;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 14.10.2005
 * Time: 15:04:51
 * To change this template use File | Settings | File Templates.
 */
public abstract class InspectionBase extends LocalInspectionTool {

  private final String group;
  private final String name;
  private final Class fileType;

  public InspectionBase(String group, String name, Class fileType) {

    this.group = group;
    this.name = name;
    this.fileType = fileType;
  }

  public String getGroupDisplayName() {
    return group;
  }

  public String getDisplayName() {
    return name;
  }

  /**
   * @return short name that is used in two cases: \inspectionDescriptions\&lt;short_name&gt;.html resource may contain short inspection
   *         description to be shown in "Inspect Code..." dialog and also provide some file name convention when using offline
   *         inspection or export to HTML function. Should be unique among all inspections.
   */
  public String getShortName() {
    return name;
  }

  /**
   * Override this to report problems at file level.
   *
   * @param file       to check.
   * @param manager    InspectionManager to ask for ProblemDescriptor's from.
   * @param isOnTheFly true if called during on the fly editor highlighting. Called from Inspect Code action otherwise.
   * @return <code>null</code> if no problems found or not applicable at field level.
   */
  public ProblemDescriptor[] checkFile(PsiFile file, InspectionManager manager, boolean isOnTheFly) {
    if (fileType.isAssignableFrom(file.getClass())) {
      return doCheckFile(file, manager, isOnTheFly);
    }
    else {
      return super.checkFile(file, manager, isOnTheFly);
    }
  }

  protected abstract ProblemDescriptor[] doCheckFile(PsiFile file, InspectionManager manager, boolean isOnTheFly);
}
