/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.inplace.reference.config;

import com.intellij.openapi.util.IconLoader;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiReference;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.struts.StrutsManager;
import com.intellij.struts.TilesModel;
import com.intellij.struts.inplace.reference.XmlAttributeReferenceProvider;
import com.intellij.struts.inplace.reference.XmlValueReference;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NonNls;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 11.11.2005
 * Time: 15:01:44
 * To change this template use File | Settings | File Templates.
 */
public class TilesReferenceProvider extends XmlAttributeReferenceProvider {

  @NonNls public static final String CANONICAL = "Tile definition";

  public final static Icon icon = IconLoader.getIcon("/com/intellij/struts/icons/tiles/Tile.png");

  protected PsiReference[] create(XmlAttributeValue attribute) {

    PsiReference ref = new XmlValueReference(attribute, CANONICAL, icon, this) {

      @Nullable
      public PsiElement doResolve() {
        TilesModel model = StrutsManager.getInstance().getTiles(myValue);
        String tileName = getValue();
        return model == null ? null : model.getTileTag(tileName);
      }

      @Nullable
      public Object[] doGetVariants() {
        TilesModel model = StrutsManager.getInstance().getTiles(myValue);
        return model == null ? null : getItems(model.getDefinitions());
      }
    };
    return new PsiReference[] {ref};
  }
}
