/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts;

import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiManager;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.struts.ui.tooltip.HyperLinkToolTipProvider;

import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

/**
 */
public class StrutsToolTipProvider extends HyperLinkToolTipProvider {

  public StrutsToolTipProvider(final Object project) {

    super(new HyperlinkListener() {


      public void hyperlinkUpdate(HyperlinkEvent e) {
        if (project instanceof Project && e.getEventType().equals(HyperlinkEvent.EventType.ACTIVATED)) {
          String descr = e.getDescription();
          if (descr.startsWith("class://")) {
            String className = descr.substring("class://".length());
            com.intellij.psi.search.GlobalSearchScope.projectScope((Project)project);
            PsiClass clazz = PsiManager.getInstance((Project)project).findClass(className, GlobalSearchScope.allScope((Project)project));
            if (clazz != null) {
//                            NavigationUtil.navigate(clazz, project);
            }

          }
        }
      }
    });
  }

  public String getToolTipText(Object object) {
/*
        if (object instanceof TreeElementObject) {

            TreeElementObject o = (TreeElementObject)object;
            if (true) {
                return o.getTooltip();
            }
            Element el = o.getElement();
            if (el == null) {
                return null;
            }
            boolean present = false;
            StringBuffer buf = new StringBuffer();
            String comment = XMLUtil.getComment(el);
            if (comment != null && comment.trim().length() > 0) {
                buf.append("<html>&nbsp;<b>Comment:</b>&nbsp;<br>&nbsp;");
                this.markup(comment, buf);
                present = true;
            }

            comment = XMLUtil.getTextValue(el, "description");
            if (comment != null && comment.trim().length() > 0) {
                buf.append("<html>&nbsp;<b>Description:</b>&nbsp;<br>&nbsp;");
                this.markup(comment, buf);
                present = true;
            }

            String type = el.getAttribute("type");
            if (type != null && type.length() > 0) {
                buf.append("<br>&nbsp;<b>Type:</b> <a href='class://").append(type).append("'>").append(type).append("</a>&nbsp;");
                present = true;
            }

            if (present) {
                buf.append("</html>");
                return buf.toString();
            } else {
                return null;
            }
        }
*/
    return null;
  }

  private void markup(String comment, StringBuffer buf) {
    for (int i = 0; i < comment.length(); i++) {
      char ch = comment.charAt(i);
      switch (ch) {
        case('\n'):
          buf.append("&nbsp;<br>&nbsp;");
          break;
        default:
          buf.append(ch);
      }
    }
    buf.append("&nbsp;");
  }
}
