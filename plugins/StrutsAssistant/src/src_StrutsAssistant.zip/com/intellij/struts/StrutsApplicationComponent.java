/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts;

import com.intellij.codeInsight.template.impl.TemplateSettings;
import com.intellij.codeInspection.InspectionToolProvider;
import com.intellij.facet.FacetTypeRegistry;
import com.intellij.ide.IconProvider;
import com.intellij.javaee.ExternalResourceManager;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.util.*;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.psi.filters.AndFilter;
import com.intellij.psi.filters.ClassFilter;
import com.intellij.psi.filters.ElementFilter;
import com.intellij.psi.filters.TextFilter;
import com.intellij.psi.jsp.JspFile;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import com.intellij.refactoring.rename.RegExpValidator;
import com.intellij.refactoring.rename.RenameInputValidatorRegistry;
import com.intellij.struts.config.StrutsConfiguration;
import com.intellij.struts.core.JDOMClassExternalizer;
import com.intellij.struts.dom.SetProperty;
import com.intellij.struts.dom.StrutsConfig;
import com.intellij.struts.dom.tiles.TilesDefinitions;
import com.intellij.struts.dom.validator.*;
import com.intellij.struts.facet.StrutsFacet;
import com.intellij.struts.facet.StrutsFacetType;
import com.intellij.struts.highlighting.StrutsInspection;
import com.intellij.struts.highlighting.TilesInspection;
import com.intellij.struts.highlighting.ValidatorInspection;
import com.intellij.struts.inplace.Filters;
import com.intellij.struts.inplace.inspections.ValidatorFormInspection;
import com.intellij.struts.util.PsiClassUtil;
import com.intellij.ui.LayeredIcon;
import com.intellij.util.Function;
import com.intellij.util.xml.DomManager;
import com.intellij.util.xml.ElementPresentationManager;
import gnu.trove.TIntObjectHashMap;
import org.jdom.Document;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

/**
 * Represents Struts support at application level.
 *
 * @author Dmitry Avdeev
 */
public class StrutsApplicationComponent
  implements ApplicationComponent, JDOMExternalizable, IconProvider, InspectionToolProvider {

  private static final Logger LOG = Logger.getInstance(StrutsApplicationComponent.class.getName());

  @NonNls private static final String HTTP_PREFIX = "http://";

  @NotNull
  public String getComponentName() {
    return StrutsConstants.PLUGIN_NAME;
  }

  public void initComponent() {
    // register all DTD mappings for user convenience
    registerDTDs(StrutsConstants.STRUTS_DTDS);
    registerDTDs(StrutsConstants.TILES_DTDS);
    registerDTDs(StrutsConstants.VALIDATOR_DTDS);

    registerPresentations();
    registerLiveTemplates();

    // validate <action> "path"-attribute on Refactor->Rename
    ElementFilter actionTagFilter =  new AndFilter(Filters.NAMESPACE_STRUTS_CONFIG,
                                         new ClassFilter(XmlTag.class),
                                         new TextFilter("action"));
    final RegExpValidator validator = new RegExpValidator("/[\\d\\w\\_\\.\\-/]+");
    RenameInputValidatorRegistry.getInstance().registerInputValidator(actionTagFilter, validator);

    FacetTypeRegistry.getInstance().registerFacetType(StrutsFacetType.INSTANCE);
  }

  private void registerLiveTemplates() {
    final TemplateSettings settings = TemplateSettings.getInstance();
    try {
      final Document document = JDOMUtil.loadDocument(getClass().getResourceAsStream("/liveTemplates/struts.xml"));
      settings.readTemplateFile(document, "struts", true);
    }
    catch (Exception e) {
      LOG.error("Can't load Struts live templates", e);
    }
  }

  /**
   * Registers the given DTD URIs with files provided in our classpath (/com/intellij/struts/dtds/[filename]).
   *
   * @param dtds URIs.
   */
  private static void registerDTDs(final String[] dtds) {
    for (String url : dtds) {
      if (url.startsWith(HTTP_PREFIX)) {
        int pos = url.lastIndexOf('/');
        @NonNls String file = "/com/intellij/struts/dtds" + url.substring(pos);
        ExternalResourceManager.getInstance().addStdResource(url, file, StrutsApplicationComponent.class);
      }
    }
  }

  public void disposeComponent() {
  }

  /**
   * Writes struts configuration
   *
   * TODO switch to PersistentStateComponent
   * @param element JDOM Element.
   * @throws WriteExternalException
   */
  public void writeExternal(Element element) throws WriteExternalException {
    JDOMClassExternalizer.writeExternal(StrutsConfiguration.getInstance(), element);
  }

  public void readExternal(Element element) throws InvalidDataException {
    JDOMClassExternalizer.readExternal(StrutsConfiguration.getInstance(), element);
  }

  // IconProvider -------------------------------------------------------------
  // original code posted by Sascha Weinreuter

  private boolean active;
  private static final Key<TIntObjectHashMap<Icon>> ICON_KEY = Key.create("STRUTS_ASSISTANT_OVERLAY_ICON");

  @Nullable
  public Icon getIcon(@NotNull final PsiElement element, final int flags) {

    if (element instanceof JspFile) {
      return null;
    }
    if (!(element instanceof PsiClass || element instanceof XmlFile)) {
      return null;
    }
    // IconProvider queries non-physical PSI as well (e.g. completion items)
    if (!element.isPhysical()) {
      return null;
    }

    if (!StrutsFacet.isPresentForContainingWebFacet(element)) {
      return null;
    }

    // for getting the original icon from IDEA
    if (active) {
      return null;
    }

    active = true;

    try {
      TIntObjectHashMap<Icon> icons = element.getUserData(ICON_KEY);
      if (icons != null) {
        final Icon icon = icons.get(flags);
        if (icon != null) {
          return icon;
        }
      }

      Icon strutsIcon = null;
      LayeredIcon icon = null;

      // handle XML files
      if (element instanceof XmlFile) {
        final XmlFile xmlFile = (XmlFile) element;
        final DomManager domManager = DomManager.getDomManager(xmlFile.getProject());

        if (domManager.getFileElement(xmlFile, StrutsConfig.class) != null) {
          strutsIcon = StrutsIcons.ACTION_SMALL_ICON;
        } else if (domManager.getFileElement(xmlFile, TilesDefinitions.class) != null) {
          strutsIcon = StrutsIcons.TILES_SMALL_ICON;
        } else if (domManager.getFileElement(xmlFile, FormValidation.class) != null) {
          strutsIcon = StrutsIcons.VALIDATOR_SMALL_ICON;
        }
      }
      // handle JAVA classes
      else if (element instanceof PsiClass) {
        final PsiClass psiClass = (PsiClass) element;

        if (PsiClassUtil.isSuper(psiClass, "org.apache.struts.action.Action")) {
          strutsIcon = StrutsIcons.ACTION_SMALL_ICON;
        } else if (PsiClassUtil.isSuper(psiClass, "org.apache.struts.action.ActionForm")) {
          strutsIcon = StrutsIcons.FORMBEAN_SMALL_ICON;
        } else if (PsiClassUtil.isSuper(psiClass, "org.apache.struts.tiles.Controller")) {
          strutsIcon = StrutsIcons.TILES_SMALL_ICON;
        }
      }

      // match? build new layered icon
      if (strutsIcon != null) {
        icon = new LayeredIcon(2);
        final Icon original = element.getIcon(flags & ~Iconable.ICON_FLAG_VISIBILITY);
        icon.setIcon(original, 0);
        icon.setIcon(strutsIcon, 1, StrutsIcons.OVERLAY_ICON_OFFSET_X, StrutsIcons.OVERLAY_ICON_OFFSET_Y);
      }

      // cache built icon
      if (icon != null) {
        if (icons == null) {
          element.putUserData(ICON_KEY, icons = new TIntObjectHashMap<Icon>(3));
        }
        icons.put(flags, icon);
      }

      return icon;
    } finally {
      active = false;
    }

  }


  private static void registerPresentations() {
    ElementPresentationManager
      .registerIcon(FormValidation.class, StrutsIcons.getIcon("validator/ValidatorConfig.png"));

    ElementPresentationManager.registerIcon(Global.class, StrutsIcons.getIcon("validator/Global.png"));
    ElementPresentationManager.registerIcon(Validator.class, StrutsIcons.VALIDATOR_ICON);
    ElementPresentationManager.registerIcon(Constant.class, StrutsIcons.getIcon("validator/Constant.png"));

    ElementPresentationManager.registerIcon(Formset.class, StrutsIcons.getIcon("validator/Formset.png"));
    ElementPresentationManager.registerIcon(Form.class, StrutsIcons.getIcon("validator/Form.png"));
    ElementPresentationManager.registerIcon(Field.class, StrutsIcons.getIcon("FormProperty.png"));

    ElementPresentationManager.registerIcon(Msg.class, StrutsIcons.getIcon("validator/Msg.png"));
    ElementPresentationManager.registerIcon(Arg.class, StrutsIcons.getIcon("validator/Arg.png"));
    ElementPresentationManager.registerIcon(Var.class, StrutsIcons.getIcon("validator/Var.png"));

    // <set-property>, <formset>
    ElementPresentationManager.registerNameProvider(new Function<Object, String>() {
      @Nullable
      public String fun(final Object s) {
        if (s instanceof SetProperty) {
          final SetProperty setProperty = ((SetProperty)s);
          final String property = setProperty.getProperty().getStringValue();
          if (property != null) {
            return property;
          }
          return setProperty.getKey().getStringValue();
        } else if (s instanceof Formset) {
          final Formset formset = ((Formset) s);
          String lang = formset.getLanguage().getStringValue();
          String country = formset.getCountry().getStringValue();
          String variant = formset.getVariant().getStringValue();
          String name = lang == null ? null : lang;
          if (country != null) {
            name = name == null ? country : name + "_" + country;
          }
          if (variant != null) {
            name = name == null ? variant : name + "_" + variant;
          }
          return name;
        } else if (s instanceof Arg) {
          final String name = ((Arg) s).getName().getStringValue();
          if (name == null) {
            return null;
          }
          final String position = ((Arg) s).getPosition().getStringValue();
          return position == null ? name : name + position;
        }
        return null;
      }
    });
  }

  public Class[] getInspectionClasses() {
    return new Class[]{
      StrutsInspection.class,
      TilesInspection.class,
      ValidatorInspection.class,
      ValidatorFormInspection.class
    };
  }

}
