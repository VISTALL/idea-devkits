/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts;

import com.intellij.ide.IconProvider;
import com.intellij.ide.fileTemplates.FileTemplateGroupDescriptor;
import com.intellij.ide.fileTemplates.FileTemplateGroupDescriptorFactory;
import com.intellij.ide.util.projectWizard.ProjectWizardStepFactory;
import com.intellij.javaee.ExternalResourceManager;
import com.intellij.javaee.web.WebPathsManager;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleType;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMExternalizable;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.psi.PsiElement;
import com.intellij.psi.filters.ElementFilter;
import com.intellij.psi.filters.AndFilter;
import com.intellij.psi.filters.ClassFilter;
import com.intellij.psi.filters.TextFilter;
import com.intellij.psi.jsp.JspFile;
import com.intellij.psi.util.SimpleCachedValueProvider;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import com.intellij.refactoring.rename.RegExpValidator;
import com.intellij.refactoring.rename.RenameInputValidatorRegistry;
import com.intellij.struts.config.StrutsConfiguration;
import com.intellij.struts.core.FileTypeBase;
import com.intellij.struts.core.JDOMClassExternalizer;
import com.intellij.struts.dom.tiles.TilesDefinitions;
import com.intellij.struts.dom.validator.FormValidation;
import com.intellij.struts.inplace.Filters;
import com.intellij.struts.inplace.reference.path.ActionWebPathsProvider;
import com.intellij.struts.psi.StrutsManagerImpl;
import com.intellij.struts.wizards.support.StrutsWizardStepsProvider;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

/**
 * Represents Struts support at application level.
 *
 * @author Dmitry Avdeev
 */
public class StrutsApplicationComponent
  implements ApplicationComponent, JDOMExternalizable, IconProvider, FileTemplateGroupDescriptorFactory {

  protected final static Logger logger = Logger.getInstance("StrutsApplicationComponent.class");

  @NonNls public static final String STRUTS_CONFIG_XML = "struts-config.xml";
  @NonNls public static final String TILES_DEFS_XML = "tiles-defs.xml";
  @NonNls public static final String VALIDATION_XML = "validation.xml";
  @NonNls public static final String VALIDATOR_RULES_XML = "validator-rules.xml";
  @NonNls public static final String MESSAGE_RESOURCES_PROPERTIES = "MessageResources.properties";

  @NotNull
  public String getComponentName() {
    return StrutsConstants.PLUGIN_NAME;
  }

  public void initComponent() {
    try {
      FileType type = new FileTypeBase(StrutsConstants.DIAGRAM_FILE_NAME, StrutsConstants.DIAGRAM_FILE_DESCRIPTION,
                                       StrutsConstants.DIAGRAM_FILE_EXTENSION, StrutsConstants.ICON_STRUTS_SMALL);
      FileTypeManager.getInstance().registerFileType(type, new String[]{StrutsConstants.DIAGRAM_FILE_EXTENSION});

    }
    catch (Throwable e) {
      logger.error("Cannot initialize Struts Assistant application component", e);
    }

    registerDTDs(StrutsConstants.STRUTS_DTDS);
    registerDTDs(StrutsConstants.TILES_DTDS);
    registerDTDs(StrutsConstants.VALIDATOR_DTDS);

    ElementFilter filter = new AndFilter(Filters.NAMESPACE_STRUTS_CONFIG, new ClassFilter(XmlTag.class), new TextFilter("action"));
    final RegExpValidator validator = new RegExpValidator("/[\\d\\w\\_\\.\\-/]+");
    RenameInputValidatorRegistry.getInstance().registerInputValidator(filter, validator);

    WebPathsManager.getInstance().registerProvider(new ActionWebPathsProvider());

    ProjectWizardStepFactory.getInstance().registerAddSupportProvider(ModuleType.WEB, new StrutsWizardStepsProvider());
  }

  protected static void registerDTDs(String[] dtds) {
    for (String url : dtds) {
      int pos = url.lastIndexOf('/');
      @NonNls String file = "/com/intellij/struts/dtds" + url.substring(pos);
      ExternalResourceManager.getInstance().addStdResource(url, file, StrutsApplicationComponent.class);
    }
  }

  public void disposeComponent() {
  }

  /**
   * Writes struts configuration
   *
   * @param element
   * @throws WriteExternalException
   */
  public void writeExternal(Element element) throws WriteExternalException {
    JDOMClassExternalizer.writeExternal(StrutsConfiguration.getInstance(), element);
  }

  public void readExternal(Element element) throws InvalidDataException {
    JDOMClassExternalizer.readExternal(StrutsConfiguration.getInstance(), element);
  }

  @Nullable
  public Icon getIcon(PsiElement element, int flags) {
    if (element instanceof JspFile) {
      return null;
    }
    if (element instanceof XmlFile) {
      return myValueProvider.getValue((XmlFile)element);
    }
    return null;
  }

  private final SimpleCachedValueProvider<Icon, XmlFile> myValueProvider = new SimpleCachedValueProvider<Icon, XmlFile>("STRUTS_ICON") {

    @Nullable
    protected Icon updateValue(final XmlFile file) {
      final Module module = ModuleUtil.findModuleForPsiElement(file);
      if (module == null || !module.getModuleType().equals(ModuleType.WEB)) {
        return null;
      }
      final StrutsManager strutsManager = StrutsManager.getInstance();
      if (strutsManager.isStrutsConfig(file)) {
        return StrutsConstants.STRUTS_CONFIG_ICON;
      }
      else if (StrutsManagerImpl.hasRoot(file, TilesDefinitions.TILES_DEFINITIONS)) {
        return StrutsConstants.TILES_CONFIG_ICON;
      }
      else if (StrutsManagerImpl.hasRoot(file, FormValidation.FORM_VALIDATION)) {
        return StrutsConstants.VALIDATOR_CONFIG_ICON;
      }
      return null;
    }
  };

  public FileTemplateGroupDescriptor getFileTemplatesDescriptor() {
    final FileTemplateGroupDescriptor groupDescriptor = new FileTemplateGroupDescriptor("Struts templates", StrutsConstants.ICON_STRUTS_SMALL);
    groupDescriptor.addTemplate(STRUTS_CONFIG_XML);
    groupDescriptor.addTemplate(TILES_DEFS_XML);
    groupDescriptor.addTemplate(VALIDATION_XML);
    groupDescriptor.addTemplate(VALIDATOR_RULES_XML);

    groupDescriptor.addTemplate(MESSAGE_RESOURCES_PROPERTIES);
    return groupDescriptor;
  }
}
