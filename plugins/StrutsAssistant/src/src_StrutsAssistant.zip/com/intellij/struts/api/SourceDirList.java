/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.api;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;
import java.awt.*;

/**
 * Date: 01.09.2005 Time: 12:31:44
 *
 * @author Dmitry Avdeev
 */
public class SourceDirList extends JList {

  private final static Icon SOURCE = IconLoader.getIcon("/com/intellij/struts/icons/sourceFolder.png");
  private final static Icon TEST = IconLoader.getIcon("/com/intellij/struts/icons/testSourceFolder.png");

  public SourceDirList() {

    super();

    setCellRenderer(new DefaultListCellRenderer() {

      public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        setText(((SourceDir)value).getFile().getPath());
        setIcon(((SourceDir)value).getType() == SourceDir.TEST ? TEST : SOURCE);
        return this;
      }
    });

  }

  public void setDirs(final SourceDir[] listData) {
    super.setModel(new AbstractListModel() {
      public int getSize() {
        return listData.length;
      }

      public Object getElementAt(int i) {
        return listData[i];
      }
    });
    if (listData.length > 0) {
      setSelectedIndex(0);
    }

  }
}
