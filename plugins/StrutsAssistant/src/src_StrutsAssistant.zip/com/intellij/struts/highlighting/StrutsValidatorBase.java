/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.highlighting;

import com.intellij.codeHighlighting.HighlightDisplayLevel;
import com.intellij.javaee.InspectionValidatorBase;
import com.intellij.openapi.compiler.CompileScope;
import com.intellij.openapi.compiler.CompilerMessageCategory;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleType;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.xml.XmlFile;
import com.intellij.struts.WebDomFactory;
import com.intellij.struts.config.StrutsConfiguration;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Set;

/**
 * @author Dmitry Avdeev
 */
public abstract class StrutsValidatorBase extends InspectionValidatorBase {

  private final WebDomFactory myFactory;

  protected StrutsValidatorBase(final Project project, WebDomFactory factory) {
    super(project);
    myFactory = factory;
  }

  @Nullable
  protected Set<XmlFile> getConfigFiles(@Nullable Module module) {
    return myFactory.getAllConfigFiles(module);
  }

  protected boolean isAvailableOnScope(CompileScope scope) {
    for (Module module: scope.getAffectedModules()) {
      if (module.getModuleType().equals(ModuleType.WEB)) {
        return true;
      }
    }
    return false;
  }

  protected Collection<VirtualFile> getFilesToProcess(final CompileScope compileScope) {
    final ArrayList<VirtualFile> list = new ArrayList<VirtualFile>();
    for (final Module module : compileScope.getAffectedModules()) {
      final Set<? extends PsiFile> psiFiles = getConfigFiles(module);
      if (psiFiles != null) {
        for (final PsiFile psiFile : psiFiles) {
          ContainerUtil.addIfNotNull(psiFile.getVirtualFile(), list);
        }
      }
    }
    return list;
  }

  protected boolean isAvailableOnFile(Module module, PsiFile psiFile) {
    final Set<? extends PsiFile> psiFiles = getConfigFiles(module);
    return psiFiles != null && psiFiles.contains(psiFile);
  }

  @NotNull
  protected Collection<? extends PsiElement> getDependencies(final PsiFile psiFile) {
    final Module module = ModuleUtil.findModuleForPsiElement(psiFile);
    final Set<? extends PsiFile> psiFiles = getConfigFiles(module);
    if (psiFiles == null) {
      return Collections.emptyList();
    }
    psiFiles.remove(psiFile);
    return psiFiles;
  }

  protected CompilerMessageCategory getCategoryByHighlightDisplayLevel(final HighlightDisplayLevel severity) {

    final CompilerMessageCategory level = super.getCategoryByHighlightDisplayLevel(severity);
    if (level == CompilerMessageCategory.ERROR && StrutsConfiguration.getProjectSettings(myProject).myReportErrorsAsWarnings) {
      return CompilerMessageCategory.WARNING;
    }
    return level;
  }
}
