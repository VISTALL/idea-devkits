/**
 * Provides inspections and validators for config files.
 */
package com.intellij.struts.highlighting;