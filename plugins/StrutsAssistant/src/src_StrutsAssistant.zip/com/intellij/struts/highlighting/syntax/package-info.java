/**
 * Provides additional syntax highlighting.
 */
package com.intellij.struts.highlighting.syntax;