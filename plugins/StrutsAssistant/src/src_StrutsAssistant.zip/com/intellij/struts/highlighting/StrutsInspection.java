package com.intellij.struts.highlighting;

import com.intellij.struts.dom.StrutsConfig;
import com.intellij.util.xml.highlighting.BasicDomElementsInspection;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

/**
 * User: Sergey.Vasiliev
 */
public class StrutsInspection extends BasicDomElementsInspection<StrutsConfig> {

  public StrutsInspection() {
    super(StrutsConfig.class);
  }

  @NotNull
  public String getGroupDisplayName() {
    return "Struts Assistant";   // todo Dm.Avdeev: bundle string literal
  }

  @NotNull
  public String getDisplayName() {
    return "Struts inspection";
  }

  @NotNull
  @NonNls
  public String getShortName() {
    return "StrutsInspection";
  }
}