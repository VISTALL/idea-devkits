package com.intellij.struts.highlighting;

import com.intellij.codeInspection.InspectionToolProvider;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.struts.inplace.inspections.ValidatorFormInspection;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

/**
 * User: Sergey.Vasiliev
 */
public class StrutsInspectionToolProvider implements ApplicationComponent, InspectionToolProvider {

  @NotNull
  @NonNls
  public String getComponentName() {
    return getClass().getName();
  }

  public void initComponent() {
  }

  public void disposeComponent() {
  }

  public Class[] getInspectionClasses() {
    return new Class[]{
      StrutsInspection.class,
      TilesInspection.class,
      ValidatorInspection.class,
      ValidatorFormInspection.class
    };
  }
}
