/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts;

import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.javaee.web.WebUtil;
import com.intellij.javaee.JavaeeDeploymentDescriptor;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.util.CachedValueProvider;
import com.intellij.psi.xml.XmlFile;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.DomFileElement;
import com.intellij.util.xml.DomManager;
import com.intellij.util.xml.ModelMerger;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * @author Dmitry Avdeev
 */
public abstract class WebDomFactory<T extends DomElement, M extends DomModel<T>> {

  private final Class<T> myClass;
  private final ModelMerger myModelMerger;

  private final DomModelCache<M> myModelCache;
  private final DomModelCache<M> myCombinedModelCache;
  private final DomModelCache<List<M>> myAllModelsCache;


  protected WebDomFactory(@NotNull Class<T> aClass,
                          @NotNull ModelMerger modelMerger,
                          final Project project,
                          @NonNls String name) {

    myClass = aClass;
    myModelMerger = modelMerger;

    myModelCache = new DomModelCache<M>(project, name + " model") {
       @NotNull
       protected CachedValueProvider.Result<M> computeValue(@NotNull final XmlFile dataHolder) {
         final M model = computeModel(dataHolder);
         return new CachedValueProvider.Result<M>(model, computeDependencies(model, null, project));
      }
    };

    myCombinedModelCache = new AllModelsCache<M>(project, name + " combined model") {
      @NotNull
      protected CachedValueProvider.Result<M> computeValue(@Nullable final WebModuleProperties module) {
        final M model = module == null ? null : computeCombinedModel(module.getModule());
        return new CachedValueProvider.Result<M>(model, computeDependencies(model, null, project));
      }
    };

    myAllModelsCache = new AllModelsCache<List<M>>(project, name + " models list") {
      @NotNull
      protected CachedValueProvider.Result<List<M>> computeValue(@Nullable final WebModuleProperties module) {
        final List<M> models = computeModels(module);
        return new CachedValueProvider.Result<List<M>>(models, computeDependencies(null, module, project));
      }
    };

  }

  protected abstract Object[] computeDependencies(@Nullable M model, @Nullable WebModuleProperties moduleProperties, @NotNull final Project project);

  @Nullable
  public abstract M getModel(@NotNull PsiElement psiElement);

  @NotNull
  public List<M> getAllModels(@Nullable Module module) {

    final XmlFile xmlFile = getWebXml(module);
    if (xmlFile == null) {
      return Collections.emptyList();
    }
    final List<M> models = myAllModelsCache.getCachedValue(xmlFile);
    if (models == null) {
      return Collections.emptyList();
    }
    else {
      return models;
    }
  }

  @Nullable
  protected static XmlFile getWebXml(Module module) {
    if (module == null) {
      return null;
    }
    WebModuleProperties moduleProperties = WebUtil.getWebModuleProperties(module);
    if (moduleProperties == null) {
      return null;
    }
    final JavaeeDeploymentDescriptor descriptor = moduleProperties.getWebModuleProperties().getMainDeploymentDescriptor();
    if (descriptor == null) {
      return null;
    }
    return descriptor.getXmlFile();
  }

  @Nullable
  protected abstract List<M> computeModels(@Nullable WebModuleProperties moduleProperties);

  @Nullable
  protected M getModelByConfigFile(@Nullable XmlFile psiFile) {
    if (psiFile == null) {
      return null;
    }
    return myModelCache.getCachedValue(psiFile);
  }

  @Nullable
  protected M computeModel(XmlFile psiFile) {
    final PsiFile originalFile = psiFile.getOriginalFile();
    if (originalFile != null) {
      psiFile = (XmlFile)originalFile;
    }

    final Module module = ModuleUtil.findModuleForPsiElement(psiFile);
    if (module == null) {
      return null;
    }
    final List<M> models = getAllModels(module);
    for (M model: models) {
      final Set<XmlFile> configFiles = model.getConfigFiles();
      if (configFiles.contains(psiFile)) {
        return model;
      }
    }
    return null;
  }

  @Nullable
  public M getCombinedModel(@Nullable Module module) {
    final XmlFile xmlFile = getWebXml(module);
    if (xmlFile == null) {
      return null;
    }
    return myCombinedModelCache.getCachedValue(xmlFile);
  }

  @Nullable
  protected M computeCombinedModel(Module module) {
    final List<M> strutsModels = getAllModels(module);
    switch (strutsModels.size()) {
      case 0:
        return null;
      case 1:
        return strutsModels.get(0);
    }
    Set<XmlFile> configFiles = new LinkedHashSet<XmlFile>();
    final ArrayList<T> list = new ArrayList<T>(strutsModels.size());
    for (M model: strutsModels) {
      final Set<XmlFile> files = model.getConfigFiles();
      for (XmlFile file: files) {
        list.add(getDom(file));
      }
      configFiles.addAll(files);
    }
    final T mergedModel = getModelMerger().mergeModels(getClazz(), list);
    final M firstModel = strutsModels.get(0);
    return createCombinedModel(configFiles, mergedModel, firstModel);
  }

  protected abstract M createCombinedModel(Set<XmlFile> configFiles, T mergedModel, M firstModel);

  @NotNull
  public Set<XmlFile> getConfigFiles(@Nullable PsiElement psiElement) {
    if (psiElement == null) {
      return Collections.emptySet();
    }
    final M model = getModel(psiElement);
    if (model == null) {
      return Collections.emptySet();
    }
    else {
      return model.getConfigFiles();
    }
  }

  @NotNull
  public Set<XmlFile> getAllConfigFiles(@Nullable Module module) {
    final HashSet<XmlFile> xmlFiles = new HashSet<XmlFile>();
    for (M model: getAllModels(module)) {
      xmlFiles.addAll(model.getConfigFiles());
    }
    return xmlFiles;
  }

  @Nullable
  public T getDom(@NotNull XmlFile configFile) {
    final DomFileElement<T> element = DomManager.getDomManager(configFile.getProject()).getFileElement(configFile, myClass);
    return element == null ? null : element.getRootElement();
  }

  public List<DomFileElement<T>> getFileElements(M model) {
    final ArrayList<DomFileElement<T>> list = new ArrayList<DomFileElement<T>>(model.getConfigFiles().size());
    for (XmlFile configFile: model.getConfigFiles()) {
      final DomFileElement<T> element = DomManager.getDomManager(configFile.getProject()).getFileElement(configFile, myClass);
      if (element != null) {
        list.add(element);
      }
    }
    return list;
  }

  @NotNull
  protected T createMergedModel(Set<XmlFile> configFiles) {
    List<T> configs = new ArrayList<T>(configFiles.size());
    for (XmlFile configFile : configFiles) {
      final T dom = getDom(configFile);
      if (dom != null) {
        configs.add(dom);
      }
    }

    return myModelMerger.mergeModels(myClass, configs);
  }

  public ModelMerger getModelMerger() {
    return myModelMerger;
  }

  public Class<T> getClazz() {
    return myClass;
  }
}
