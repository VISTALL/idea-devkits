/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.wizards.support;

import com.intellij.ide.fileTemplates.FileTemplate;
import com.intellij.ide.fileTemplates.FileTemplateManager;
import com.intellij.ide.fileTemplates.FileTemplateUtil;
import com.intellij.ide.util.projectWizard.AddSupportContext;
import com.intellij.ide.util.projectWizard.LibraryInfo;
import com.intellij.javaee.JavaeeDeploymentDescriptor;
import com.intellij.javaee.make.MakeUtil;
import com.intellij.javaee.model.xml.ParamValue;
import com.intellij.javaee.model.xml.web.Servlet;
import com.intellij.javaee.model.xml.web.ServletMapping;
import com.intellij.javaee.model.xml.web.WebApp;
import com.intellij.javaee.web.ServletDataHolder;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.javaee.web.WebRoot;
import com.intellij.javaee.web.WebUtil;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ModifiableRootModel;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.roots.libraries.Library;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiDirectory;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiManager;
import com.intellij.psi.impl.source.jsp.JspManager;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.xml.XmlAttribute;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlProlog;
import com.intellij.psi.xml.XmlTag;
import com.intellij.struts.*;
import com.intellij.struts.actions.AddStrutsSupportAction;
import com.intellij.struts.core.IdeaUtils;
import com.intellij.struts.util.FormatUtil;
import com.intellij.struts.wizards.StrutsSupportModel;
import com.intellij.util.ArrayUtil;
import com.intellij.util.IncorrectOperationException;
import com.intellij.util.xml.DomUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;

/**
 * @author Dmitry Avdeev
 */
public class StrutsAddSupportContext extends AddSupportContext {

  @NonNls private static final String TILES_REQUEST_PROCESSOR = "org.apache.struts.tiles.TilesRequestProcessor";
  @NonNls private static final String TILES_PLUGIN = "org.apache.struts.tiles.TilesPlugin";
  @NonNls private static final String VALIDATOR_PLUGIN = "org.apache.struts.validator.ValidatorPlugIn";
  @NonNls private static final String DEFAULT_STRUTS_MAPPING = "*.do";

  private StrutsVersion myVersion;

  private boolean myTilesSupport;
  private boolean myValidatorSupport;
  private boolean myStrutsTaglibSupport;
  private boolean myStrutsELSupport;
  private boolean myScriptingSupport;
  private boolean myExtrasSupport;
  private boolean myStrutsFacesSupport;

  private String myWebAppVersion;
  public StrutsAddSupportContext(final boolean isInsideAddModuleWizard, Project project) {
    super("struts", project, isInsideAddModuleWizard);
  }

  public boolean isStruts13x() {
    return myVersion == StrutsVersion.Struts1_3_5;
  }

  public StrutsVersion getVersion() {
    return myVersion;
  }
  public boolean isTilesSupport() {
    return myTilesSupport;
  }

  public void setTilesSupport(final boolean tilesSupport) {
    myTilesSupport = tilesSupport;
  }

  public boolean isValidatorSupport() {
    return myValidatorSupport;
  }

  public void setValidatorSupport(final boolean validatorSupport) {
    myValidatorSupport = validatorSupport;
  }

  public boolean isStrutsELSupport() {
    return myStrutsELSupport;
  }

  public void setStrutsELSupport(final boolean strutsELSupport) {
    myStrutsELSupport = strutsELSupport;
  }

  public String getWebAppVersion() {
    return myWebAppVersion;
  }

  public void setWebAppVersion(final String webAppVersion) {
    myWebAppVersion = webAppVersion;
  }


  public void installSupport(final Module module, final ModifiableRootModel rootModel) {
    try {
      doInstallStruts(module, rootModel);
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  protected PsiFile[] getPotentiallyModifiedFiles(Module module) {
    ArrayList<PsiFile> result = new ArrayList<PsiFile>();
    final WebModuleProperties properties = WebUtil.getWebModuleProperties(module);
    if (properties != null) {
      final JavaeeDeploymentDescriptor deploymentDescriptor = properties.getWebModuleProperties().getMainDeploymentDescriptor();
      if (deploymentDescriptor != null) {
        final PsiFile psiFile = deploymentDescriptor.getPsiFile();
        if (psiFile != null) {
          result.add(psiFile);
        }
      }
    }
    final List<StrutsModel> strutsModels = StrutsManager.getInstance().getAllStrutsModels(module);
    if (strutsModels.size() > 0) {
      final Set<XmlFile> files = strutsModels.get(0).getConfigFiles();
      if (files.size() > 0) {
        result.add(files.iterator().next());
      }
    }
    return result.toArray(PsiFile.EMPTY_ARRAY);
  }

  @NotNull
  public LibraryInfo[] getRequiredLibraries() {
    MavenJarInfo[] libs = getVersion().getJars();
    if (isStrutsTaglibSupport() && getVersion().getStrutsTaglib() != null) {
      libs = ArrayUtil.append(libs, getVersion().getStrutsTaglib());
    }
    if ((isTilesSupport() || isStrutsFacesSupport()) && getVersion().getTiles() != null) {
      libs = ArrayUtil.append(libs, getVersion().getTiles());
    }
    if (isStrutsFacesSupport()) {
      libs = ArrayUtil.append(libs, getVersion().getStrutsFaces());
    }
    if (isScriptingSupport()) {
      libs = ArrayUtil.mergeArrays(libs, getVersion().getScripting(), MavenJarInfo.class);
    }
    if (isExtrasSupport()) {
      libs = ArrayUtil.append(libs, getVersion().getExtras());
    }
    if (isStrutsELSupport()) {
      libs = ArrayUtil.mergeArrays(libs, getVersion().getStrutsEl(), MavenJarInfo.class);
    }
    return libs;
  }

  /**
   * @param module
   * @throws IncorrectOperationException
   */
  public void doInstallStruts(Module module, ModifiableRootModel rootModel)
    throws Exception {

    if (myLibrary != null || myJars.length > 0) {
      Library library = addLibrary(module, rootModel);
      MakeUtil.getInstance().addLibraryLink(module, library, rootModel);
    }

    Project project = module.getProject();
    WebModuleProperties props = WebUtil.getWebModuleProperties(module);
    final WebApp app = props.getRoot();
    if (app == null) {
      return;
    }

    StrutsModel strutsModel = null;
    List<StrutsModel> strutsModels = StrutsManager.getInstance().getAllStrutsModels(module);
    if (strutsModels.size() > 0) {
      strutsModel = strutsModels.get(0);
    }

    Servlet actionServlet = strutsModel == null ? null : strutsModel.getActionServlet();
    if (actionServlet == null) {
      actionServlet = app.addServlet();

      ServletDataHolder holder = new ServletDataHolder(actionServlet);
      holder.setName("action");
      holder.setClassName("org.apache.struts.action.ActionServlet");
      holder.installTo(actionServlet);
    }

/*
        int loadOnStartup = actionServlet.getLoadOnStartup();
        if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("load on startup: " + loadOnStartup);
        if (loadOnStartup != wizard.getLoadOnStartup()) {
            actionServlet.setLoadOnStartup(wizard.getLoadOnStartup());
        }
*/
    if (strutsModel == null || strutsModel.getServletMappingInfo().getServletMapping() == null) {
      ServletMapping mapping = props.getRoot().addServletMapping();
      mapping.getServletName().setValue(actionServlet);
      mapping.addUrlPattern().setValue(DEFAULT_STRUTS_MAPPING);
    }

    // create struts-config

    ParamValue config = DomUtil.findByName(actionServlet.getInitParams(), "config");
    if (config == null) {
      config = addParam(actionServlet, "config", "/WEB-INF/struts-config.xml");
    }
    String configFile = config.getParamValue().getValue();
    if (configFile == null || configFile.trim().length() == 0) {
      config.getParamValue().setValue("/WEB-INF/struts-config.xml");
    }

    String[] configs = configFile.split(",");

    VirtualFile file = JspManager.getInstance(module.getProject()).findVirtualFileByPath(configs[0].trim(), props);

    // check WEB-INF
    VirtualFile webinf = JspManager.getInstance(module.getProject()).findVirtualFileByPath("/WEB-INF", props);

    PsiManager manager = PsiManager.getInstance(project);
    XmlFile conf;
    if (file == null) {
      if (webinf == null) {
        // first, check if our web.xml located in a /WEB-INF
        VirtualFile web = props.getWebModuleProperties().getMainDeploymentDescriptor().getVirtualFile();
        if (web.getParent().getName().equals("WEB-INF")) {
          // add root with it
          props.addWebRoot(new WebRoot(web.getParent(), "/WEB-INF"));
          webinf = web.getParent();
        }
        else {

          WebRoot root;
          List webroots = props.getWebRoots(false);
          if (webroots.size() == 0) {
            VirtualFile[] roots = ModuleRootManager.getInstance(module).getContentRoots();
            if (roots.length == 0) {
              throw new IllegalStateException("The module has no content roots");
            }
            VirtualFile resources = roots[0].createChildDirectory(this, "resources");
            root = new WebRoot(resources, "/");
            props.addWebRoot(root);
          }
          else {
            root = (WebRoot)webroots.get(0);
          }
          webinf = root.getFile().createChildDirectory(this, "WEB-INF");
        }
      }
      final PsiDirectory directory = PsiManager.getInstance(project).findDirectory(webinf);
      final FileTemplate fileTemplate = FileTemplateManager.getInstance().getJ2eeTemplate(StrutsApplicationComponent.STRUTS_CONFIG_XML);
      final Properties properties = FileTemplateManager.getInstance().getDefaultProperties();
      properties.setProperty("version", "1");
      properties.setProperty("subversion", isStruts13x() ? "3" : "2");
      conf = (XmlFile)FileTemplateUtil.createFromTemplate(fileTemplate, "struts-config.xml", properties, project, directory);
    }
    else {
      webinf = file.getParent();
      conf = (XmlFile)manager.findFile(file);
    }

    StrutsSupportModel support = AddStrutsSupportAction.checkStrutsSupport(module);


/*
    VirtualFile libDir = wizard.getLibDir();
    VirtualFile instDir = wizard.getInstDir();
    VirtualFile extDir = IdeaUtils.findPath(instDir, "contrib/struts-el/lib");
    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("extdir: " + extDir);
*/
    @Nullable XmlTag root = conf.getDocument().getRootTag();
    if (root == null) {
      throw new RuntimeException("Existing Struts configuration file is not valid");
    }

    if (!support.tiles && isTilesSupport()) {

      XmlTag controller = root.findFirstSubTag("controller");
      if (controller == null) {
        controller = root.createChildTag("controller", root.getNamespace(), "", true);
        controller.setAttribute("processorClass", TILES_REQUEST_PROCESSOR);
        root.add(controller);
      }
      else {
        XmlAttribute processor = controller.getAttribute("processorClass", "");
        if (processor == null) {
          controller.setAttribute("processorClass", TILES_REQUEST_PROCESSOR);
        }
        else {
          String className = processor.getValue();
          if (className != null) {
            PsiClass clazz = manager.findClass(className, GlobalSearchScope.allScope(project));
            if (!IdeaUtils.isSubclass(clazz, TILES_REQUEST_PROCESSOR)) {
              controller.setAttribute("processorClass", TILES_REQUEST_PROCESSOR);
            }
          }
        }
      }


//      PlugIn p = strutsModel == null ? null : strutsModel.
      XmlTag plugin = null; //p == null ? null : p.getXmlTag();

      if (plugin == null) {
        plugin = root.createChildTag("plug-in", root.getNamespace(), "", false);
        plugin.setAttribute("className", TILES_PLUGIN);

        XmlTag prop = plugin.createChildTag("set-property", plugin.getNamespace(), "", false);
        prop.setAttribute("property", "definitions-config");
        prop.setAttribute("value", "/WEB-INF/tiles-defs.xml");
        plugin.add(prop);
        root.add(plugin);
      } /*else {
                XmlTag prop = tiles.getConfigTag();
                if (prop == null) {
                    prop = plugin.createChildTag("set-property", plugin.getNamespace(), "", false);
                    prop.setAttribute("property", "definitions-config");
                    prop.setAttribute("value", "/WEB-INF/tiles-defs.xml");
                    plugin.add(prop);
                }
            }
*/

      VirtualFile tilesDefs = webinf.findChild("tiles-defs.xml");
      if (tilesDefs == null) {
        final PsiDirectory directory = PsiManager.getInstance(project).findDirectory(webinf);
        final FileTemplate fileTemplate = FileTemplateManager.getInstance().getJ2eeTemplate(StrutsApplicationComponent.TILES_DEFS_XML);
        FileTemplateUtil.createFromTemplate(fileTemplate, "tiles-defs.xml", null, project, directory);
      }

    }
    if (!support.validation && isValidatorSupport()) {
      XmlTag plugin = root.createChildTag("plug-in", root.getNamespace(), "", false);
      plugin.setAttribute("className", VALIDATOR_PLUGIN);

      XmlTag prop = plugin.createChildTag("set-property", plugin.getNamespace(), "", false);
      prop.setAttribute("property", "pathnames");
      @NonNls String rules = isStruts13x() ? "/org/apache/struts/validator/validator-rules.xml" : "/WEB-INF/validator-rules.xml";
      prop.setAttribute("value", rules + ",/WEB-INF/validation.xml");
      plugin.add(prop);

      root.add(plugin);

      VirtualFile validationXml = webinf.findChild("validation.xml");
      if (validationXml == null) {
        if (isStruts13x()) {
          createValidationXml("1_3_0", project, webinf);
        }
        else {
          // copying validator-rules.xml
          VirtualFile rulesXml = webinf.findChild("validator-rules.xml");
          if (rulesXml == null) {
            final PsiDirectory directory = PsiManager.getInstance(project).findDirectory(webinf);
            final FileTemplate fileTemplate = FileTemplateManager.getInstance().getJ2eeTemplate(StrutsApplicationComponent.VALIDATOR_RULES_XML);
            final PsiFile psiElement = (PsiFile)FileTemplateUtil.createFromTemplate(fileTemplate, "validator-rules.xml", null, project, directory);
            rulesXml = psiElement.getVirtualFile();
          }

          // creating validation.xml
          if (rulesXml != null) {
            XmlFile psi = (XmlFile)PsiManager.getInstance(project).findFile(rulesXml);
            if (psi != null) {
              XmlProlog prolog = psi.getDocument().getProlog();
              if (prolog != null && prolog.getDoctype() != null) {
                String uri = prolog.getDoctype().getDtdUri();
                String v = FormatUtil.getVersion(uri);
                if (v != null) {
                  createValidationXml(v, project, webinf);
                }
              }
            }
          }
        }
      }

      // adding message resource
      VirtualFile[] roots = ModuleRootManager.getInstance(module).getSourceRoots();
      if (roots.length > 0) {

        @NonNls String newParam = "MessageResources";
        for (XmlTag res : root.findSubTags("message-resources")) {
          String param = res.getAttributeValue("parameter");
          if (param != null && param.equals(newParam)) {
            newParam = "ValidatorResources";
            break;
          }
        }

        final PsiDirectory directory = PsiManager.getInstance(project).findDirectory(roots[0]);
        String name = newParam;
        int i = 1;
        while (directory.findFile(name + ".properties") != null) {
          name = newParam + i++;
        }

        final FileTemplate fileTemplate =
          FileTemplateManager.getInstance().getJ2eeTemplate(StrutsApplicationComponent.MESSAGE_RESOURCES_PROPERTIES);
        FileTemplateUtil.createFromTemplate(fileTemplate, name + ".properties", null, project, directory);

        XmlTag res = root.createChildTag("message-resources", root.getNamespace(), "", false);
        res.setAttribute("parameter", name);
        root.add(res);
      }
    }

    XmlTag[] plugins = root.findSubTags("plug-in");
    if (plugins != null) {
      for (XmlTag plugin : plugins) {
        XmlAttribute className = plugin.getAttribute("className", "");
        if (className == null) {
          continue;
        }
        if (className.getValue().equals(VALIDATOR_PLUGIN)) {
          if (!isValidatorSupport()) {
            plugin.delete();
          }
        }
        else if (className.getValue().equals(TILES_PLUGIN)) {
          if (!isTilesSupport()) {
            plugin.delete();
          }
        }
      }
    }

    boolean taglibsStep = true;
    if (support.webAppVersion != null && support.webAppVersion.compareTo("2.3") >= 0) {
      taglibsStep = false;
    }

    if (taglibsStep) {
/*
  todo add taglibs
            props.getTaglibUriToResourceMap()

        for (Iterator i = wizard.getTaglibs().values().iterator(); i.hasNext(); ) {
            JCheckBox box = (JCheckBox)i.next();
            String tld = box.getText();

            String uri = FormatUtil.getUriName(tld);

            TaglibObject dd = null;
            for (int i1 = 0; i1 < taglibs.size(); i1++) {
                String name = FormatUtil.getUriName(((Taglib)taglibs.get(i1)).getUri());
                if (name.equals(uri)) {
                    dd = (TaglibObject)taglibs.get(i1);
                    break;
                }
            }
            if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Existing: " + dd);

            if (box.isEnabled() && box.isSelected()) {
                String location = "/WEB-INF/" + tld;
                if (dd == null) {
                    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Installing " + tld);
                    TaglibObject taglib = (TaglibObject)taglibs.createNewInstance(Taglib.class);
                    taglib.setLocation(location);
                    taglib.setUri("/tags/" + uri);
                    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Taglib created: " + taglib.getName());
                } else {
                    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Taglib " + uri + " already exists");
                }
                // check if tld file copied
                if (webinf.findChild(tld) == null) {
                    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("copying " + tld);
                    VirtualFile tldFile = libDir.findChild(tld);
                    if (tldFile == null) {
                        tldFile = extDir.findChild(tld);
                    }
                    if (tldFile != null) {
                        VfsUtil.copyFile(wizard, tldFile, webinf);
                    } else {
                        logger.error(tld + " not found in " + libDir);
                    }
                }

            } else {
                if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Deleting " + uri);
                if (dd != null) {
                    dd.getXmlData().delete(null);
                }
            }
        }
*/
    }


    final StrutsView view = StrutsProjectComponent.getInstance(project).getStrutsView();
    if (view != null) {
      view.openDefault();
    }
  }

  private static void createValidationXml(final String v, final Project project, final VirtualFile webinf) throws Exception {
    String dotted = FormatUtil.replace(v, '_', '.');

    final PsiDirectory directory = PsiManager.getInstance(project).findDirectory(webinf);
    final FileTemplate fileTemplate = FileTemplateManager.getInstance().getJ2eeTemplate(StrutsApplicationComponent.VALIDATION_XML);
    final Properties properties = FileTemplateManager.getInstance().getDefaultProperties();
    properties.setProperty("version", v);
    properties.setProperty("dotted", dotted);
    FileTemplateUtil.createFromTemplate(fileTemplate, "validation.xml", properties, project, directory);
  }

  protected static ParamValue addParam(Servlet servlet, @NonNls String paramName, @NonNls String paramValue) {

    ParamValue param = servlet.addInitParam();
    param.getParamName().setValue(paramName);
    param.getParamValue().setValue(paramValue);
    return param;
  }

  public boolean isStrutsTaglibSupport() {
    return myStrutsTaglibSupport;
  }

  public void setStrutsTaglibSupport(final boolean strutsTaglibSupport) {
    myStrutsTaglibSupport = strutsTaglibSupport;
  }

  public boolean isScriptingSupport() {
    return myScriptingSupport;
  }

  public void setScriptingSupport(final boolean scriptingSupport) {
    myScriptingSupport = scriptingSupport;
  }

  public boolean isExtrasSupport() {
    return myExtrasSupport;
  }

  public void setExtrasSupport(final boolean extrasSupport) {
    myExtrasSupport = extrasSupport;
  }

  public void setVersion(final StrutsVersion version) {
    myVersion = version;
  }

  public boolean isStrutsFacesSupport() {
    return myStrutsFacesSupport;
  }

  public void setStrutsFacesSupport(final boolean strutsFacesSupport) {
    myStrutsFacesSupport = strutsFacesSupport;
  }
}
