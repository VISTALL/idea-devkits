/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.wizards;

import com.intellij.openapi.project.Project;
import com.intellij.struts.ui.properties.*;
import com.intellij.struts.ui.wizard.WizardImpl;
import com.intellij.struts.ui.wizard.WizardPage;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Date: 25.04.2005 Time: 14:09:23
 *
 * @author Dmitry Avdeev
 */
public class PropertiesWizard extends WizardImpl {

  protected PropertiesSource source;
  protected DefaultPropertiesSource current;
  private final Map editors = new HashMap();
  protected final Object context;

  public PropertiesWizard(Project project, String title, Icon icon, Object context) {

    super(project, title, icon);

    this.context = context;
  }

  public PropertiesWizard(Dialog owner, Project project, String title, Icon icon, Object context) {

    super(owner, project, title, icon);

    this.context = context;
  }

  protected PropertyLayoutBuilder getBuilder() {
    return new PropertyLayoutBuilder(this, context);
  }

  public void setInitial(Object source) {
    if (source instanceof PropertiesSource) {
      this.source = (PropertiesSource)source;
      this.current = new DefaultPropertiesSource((PropertiesSource)source);
    }
    super.setInitial(source);
  }

  protected void setPages(WizardPage[] pages) {
    super.setPages(pages);
    Property.Listener listener = new Property.Listener() {
      public void changed() {
        checkState();
      }
    };
    if (current == null) {
      return;
    }
    for (Iterator i = current.getProperties().iterator(); i.hasNext();) {
      ((Property)i.next()).addListener(listener);
    }
  }

  protected void addProperty(PropertyLayoutBuilder builder, String name, String caption) {

    Property p = current.getProperty(name);
    if (p != null) {
      PropertyEditor editor = builder.addProperty(p, caption);
      if (defaultComponent == null) {
        defaultComponent = editor.getComponent();
      }
      editors.put(name, editor);
    }
  }

  protected void checkState() {

    super.checkState();

    // check dependencies
    if (current == null) {
      return;
    }
    for (Iterator i = current.getProperties().iterator(); i.hasNext();) {
      Property p = (Property)i.next();
      String name = p.getName();
      PropertyEditor editor = (PropertyEditor)editors.get(name);
      String depend = p.getDepend();
      if (editor != null) {
        // let's check dependence...
        if (depend != null && !depend.equals(name) && current.getProperty(depend).isEmpty()) {
          editor.setEnabled(false);
        }
        else {
          editor.setEnabled(true);
        }
      }
    }

    if (!current.isValid()) {
      finish.setEnabled(false);
    }
    else {
      finish.setEnabled(true);
    }
  }

  protected void onOk() {
    if (current != null) {
/*
            if (source instanceof TreeUserObject && ((TreeUserObject)source).getTreeNode() != null) {
                PropertiesSource newSource = (PropertiesSource)((TreeUserObject)source).getTreeNode().getUserObject();
                if (newSource != source) {
                    source = newSource;
                }
            }
*/
      current.copyTo(source);
    }
    super.onOk();
    if (source != null) {
      result = source;
    }
  }
}
