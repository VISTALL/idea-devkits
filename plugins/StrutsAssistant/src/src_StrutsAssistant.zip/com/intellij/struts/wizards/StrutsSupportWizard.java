/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.wizards;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VirtualFileManager;
import com.intellij.struts.config.StrutsConfiguration;
import com.intellij.struts.ui.UIUtil;
import com.intellij.struts.ui.edit.BrowseFileField;
import com.intellij.struts.ui.wizard.WizardPage;
import com.intellij.struts.util.Constants;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

/**
 * Date: 08.04.2005 Time: 15:30:43
 *
 * @author Dmitry Avdeev
 */
public class StrutsSupportWizard extends BaseStrutsWizard {

  protected final static Logger logger = Logger.getLogger(StrutsSupportWizard.class);

  //
  private final BrowseFileField distr;
  private final JComboBox version = new JComboBox();
  private final JSpinner loadOnStartup = new JSpinner(new SpinnerNumberModel(0, 0, 1000, 1));

  // standard
  private JCheckBox validation = new JCheckBox("Enable Struts validation");
  private JCheckBox tiles;

  // extended
  private JCheckBox jstl;
  private JCheckBox strutsel;

  // tag libs
  private JCheckBox struts_html; // JCheckBox("struts-html.tld");
  private JCheckBox struts_logic; // JCheckBox("struts-logic.tld");
  private JCheckBox struts_bean; // JCheckBox("struts-bean.tld");
  private JCheckBox struts_tiles; // JCheckBox("struts-tiles.tld");

  private JComponent strutsel_box;
  private JCheckBox struts_bean_el; // JCheckBox("struts-bean-el.tld");
  private JCheckBox struts_tiles_el; // JCheckBox("struts-tiles-el.tld");

  private JComponent jstl_box;
  private JCheckBox jstl_c; // JCheckBox("c.tld");
  private JCheckBox jstl_x; // JCheckBox("x.tld");
  private JCheckBox jstl_fmt; // JCheckBox("fmt.tld");

  private JComponent jstl_rt_box;
  private JCheckBox jstl_sql_rt; // JCheckBox("sql-rt.tld");

  private VirtualFile libDir;
  private VirtualFile instDir;

  public VirtualFile getInstDir() {
    return instDir;
  }

  public Map getTaglibs() {
    return taglibs;
  }

  public String getVersion() {
    return (String)version.getSelectedItem();
  }

  public boolean getTiles() {
    return tiles.isSelected();
  }

  public boolean getValidation() {
    return validation.isSelected();
  }

  public boolean getJstl() {
    return jstl.isSelected();
  }

  public boolean getStrutsel() {
    return strutsel.isSelected();
  }

  public int getLoadOnStartup() {
    return ((Integer)loadOnStartup.getValue()).intValue();
  }

  private Map taglibs = new HashMap();

  private void addTaglib(JCheckBox box) {
    taglibs.put(box.getText(), box);
  }

  public StrutsSupportModel getInit() {
    return init;
  }

  private StrutsSupportModel init;

  public StrutsSupportWizard(Project project, StrutsSupportModel init) {

    super(project, "Struts Support Wizard");

    this.init = init;


    distr = new BrowseFileField(true);


    if (loadVersions()) {
    }
/*
        pack();
		setLocationRelativeTo(null);
*/
  }

  protected WizardPage[] createPages() {

    JPanel panel1 = new JPanel(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    c.fill = GridBagConstraints.HORIZONTAL;
    c.anchor = GridBagConstraints.NORTHWEST;
    c.insets = new Insets(5, 5, 5, 5);

    JLabel info = new JLabel("<html>Please select Struts distributive location.<br>" +
                             "Standard Struts features will be installed from <b>lib</b> subdirectory.<br>" +
                             "Extended Struts features will be installed from <b>contrib/struts-el/lib</b> subdirectory.</html>");
    info.setBorder(new EmptyBorder(0, 0, 5, 0));
    c.gridwidth = 3;
    panel1.add(info, c);

    c.anchor = GridBagConstraints.CENTER;
    c.gridwidth = 1;
    c.gridy = 1;
    panel1.add(new JLabel("Distributive location:", SwingConstants.RIGHT), c);
    distr.setValue(StrutsConfiguration.getInstance().resources.strutsPath);
    distr.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        StrutsConfiguration.getInstance().resources.strutsPath = (String)distr.getValue();
      }
    });

    c.gridwidth = 2;
    c.anchor = GridBagConstraints.CENTER;
    c.weightx = 1.0;
    c.gridwidth = 2;
    panel1.add(distr.getComponent(), c);

    c.weightx = -1.0;
    c.gridy = 2;
    c.gridwidth = 1;
    panel1.add(new JLabel("Struts version:", SwingConstants.RIGHT), c);
    panel1.add(version, c);
    panel1.add(Box.createHorizontalGlue(), c);

    c.gridy = 3;
    panel1.add(new JLabel("Load on startup:", SwingConstants.RIGHT), c);
    panel1.add(loadOnStartup, c);
    panel1.add(Box.createHorizontalGlue(), c);
/*
		c.gridy = 4;
		c.weightx = 1.0;
		c.gridwidth = 3;
		panel1.add(Box.createRigidArea(new Dimension(600, 10)));
*/
    c.gridy = 5;
    c.fill = GridBagConstraints.VERTICAL;
    c.weighty = 1.0;
    panel1.add(Box.createVerticalGlue(), c);

    WizardPage page1 = new WizardPage(panel1, "Select Struts distributive and version", "strutsAssistant.ui.wizards.strutsSupport.page1") {
      public boolean isValid() {
        return super.isValid() && loadVersions();
      }
    };

    page1.addRequired(distr.getTextField());

    // Struts features page: validation & tiles support
    WizardPage page2 = new WizardPage(createFeaturesPage(), "Add Struts features", "strutsAssistant.ui.wizards.strutsSupport.page2") {
    };

    WizardPage page3 = new WizardPage(createTaglibsPage(), "Select tag libraries", "strutsAssistant.ui.wizards.strutsSupport.page3") {
    };
/*
        WizardPage page4 = new WizardPage(this.createTreePage(),
                "Struts project structure",
                "strutsAssistant.ui.wizards.strutsSupport.page3") {
        };
*/
    boolean taglibs = true;
    if (init.webAppVersion != null && init.webAppVersion.compareTo("2.3") >= 0) {
      taglibs = false;
    }

    ArrayList<WizardPage> pages = new ArrayList<WizardPage>();
//        if (StrutsFeatureFactory.getInstance().isProf()) {
//            pages.add(page4);
//        }
    pages.add(page1);
    pages.add(page2);
    if (taglibs) {
      pages.add(page3);
    }
    return pages.toArray(WizardPage.EMPTY_ARRAY);
  }

  protected JComponent createFeaturesPage() {

//        validation = new JCheckBox("Enable Struts validation");
    validation.setVisible(true);
    tiles = new JCheckBox("Enable Tiles support");
    tiles.setVisible(true);
    jstl = new JCheckBox("Enable JSTL support");
    jstl.setVisible(true);
    strutsel = new JCheckBox("Enable Struts-EL support");
    strutsel.setVisible(true);

    tiles.addChangeListener(new ChangeListener() {

      public void stateChanged(ChangeEvent e) {
        if (tiles.isSelected()) {
          struts_tiles.setSelected(true);
          if (strutsel.isSelected()) struts_tiles.setSelected(true);
        }
        else {
          struts_tiles.setSelected(true);
          struts_tiles.setSelected(false);
        }
      }
    });

    Box stand = new Box(BoxLayout.Y_AXIS);
    stand.setBorder(new javax.swing.border.TitledBorder(new EtchedBorder(), "Standard Struts features"));

    stand.add(validation);
    stand.add(tiles);
    stand.setMinimumSize(new Dimension(100, 100));

    Box ext = new Box(BoxLayout.Y_AXIS);
    ext.setBorder(new javax.swing.border.TitledBorder(new EtchedBorder(), "Extended Struts features"));
    ext.add(jstl);
    ext.add(strutsel);

    JPanel features = new JPanel(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    c.fill = GridBagConstraints.HORIZONTAL;
    c.anchor = GridBagConstraints.NORTHWEST;
    c.insets = new Insets(5, 5, 5, 5);
    c.weightx = 1.0;
//                features.add();
    features.add(stand, c);
    c.gridy = 1;
    features.add(ext, c);


    c.fill = GridBagConstraints.VERTICAL;
    c.gridy = 5;
    c.weighty = 1.0;
    features.add(new JLabel(), c);

    return features;
  }

  protected JComponent createTaglibsPage() {
    struts_html = new JCheckBox("struts-html.tld");
    struts_logic = new JCheckBox("struts-logic.tld");
    struts_bean = new JCheckBox("struts-bean.tld");
    JCheckBox struts_nested = new JCheckBox("struts-nested.tld");
    struts_tiles = new JCheckBox("struts-tiles.tld");

    JCheckBox struts_html_el = new JCheckBox("struts-html-el.tld");
    JCheckBox struts_logic_el = new JCheckBox("struts-logic-el.tld");
    struts_bean_el = new JCheckBox("struts-bean-el.tld");
    struts_tiles_el = new JCheckBox("struts-tiles-el.tld");

    jstl_c = new JCheckBox("c.tld");
    jstl_x = new JCheckBox("x.tld");
    jstl_fmt = new JCheckBox("fmt.tld");
    JCheckBox jstl_sql = new JCheckBox("sql.tld");

    JCheckBox jstl_c_rt = new JCheckBox("c-rt.tld");
    JCheckBox jstl_x_rt = new JCheckBox("x-rt.tld");
    JCheckBox jstl_fmt_rt = new JCheckBox("fmt-rt.tld");
    jstl_sql_rt = new JCheckBox("sql-rt.tld");

    addTaglib(struts_html);
    addTaglib(struts_logic);
    addTaglib(struts_bean);
    addTaglib(struts_nested);
    addTaglib(struts_tiles);

    addTaglib(struts_html_el);
    addTaglib(struts_logic_el);
    addTaglib(struts_bean_el);
    addTaglib(struts_tiles_el);

    addTaglib(jstl_c);
    addTaglib(jstl_x);
    addTaglib(jstl_fmt);
    addTaglib(jstl_sql);

    addTaglib(jstl_c_rt);
    addTaglib(jstl_x_rt);
    addTaglib(jstl_fmt_rt);
    addTaglib(jstl_sql_rt);

    Box struts = new Box(BoxLayout.Y_AXIS);
    struts.setBorder(new TitledBorder(new EtchedBorder(), "Standard Struts libraries"));
    struts.add(struts_html);
    struts.add(struts_bean);
    struts.add(struts_logic);
    struts.add(struts_nested);
    struts.add(struts_tiles);

    strutsel_box = new Box(BoxLayout.Y_AXIS);
    strutsel_box.setBorder(new TitledBorder(new EtchedBorder(), "Struts EL libraries"));
    strutsel_box.add(struts_html_el);
    strutsel_box.add(struts_bean_el);
    strutsel_box.add(struts_logic_el);
    strutsel_box.add(struts_tiles_el);

    jstl_box = new Box(BoxLayout.Y_AXIS);
    jstl_box.setBorder(new TitledBorder(new EtchedBorder(), "JSTL libraries"));
    jstl_box.add(jstl_c);
    jstl_box.add(jstl_x);
    jstl_box.add(jstl_fmt);
    jstl_box.add(jstl_sql);

    jstl_rt_box = new Box(BoxLayout.Y_AXIS);
    jstl_rt_box.setBorder(new TitledBorder(new EtchedBorder(), "JSTL RT libraries"));
    jstl_rt_box.add(jstl_c_rt);
    jstl_rt_box.add(jstl_x_rt);
    jstl_rt_box.add(jstl_fmt_rt);
    jstl_rt_box.add(jstl_sql_rt);
//	    jstlrt.getBorder().setEnabled(false);

    JPanel features = new JPanel(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    c.fill = GridBagConstraints.BOTH;
    c.anchor = GridBagConstraints.NORTHWEST;
//		c.insets = new Insets(5, 5, 5, 5);
    c.weightx = 0.5;
    features.add(struts, c);
    features.add(strutsel_box, c);
    c.gridy = 1;
    features.add(jstl_box, c);
    features.add(jstl_rt_box, c);


    c.fill = GridBagConstraints.VERTICAL;
    c.gridy = 5;
    c.weighty = 1.0;
    features.add(new JLabel(), c);


    return features;
  }

  public void setInitial(Object source) {
    super.setInitial(source);    //To change body of overridden methods use File | Settings | File Templates.

    validation.setSelected(init.validation);
    tiles.setSelected(init.tiles);
    jstl.setSelected(init.jstl);
    strutsel.setSelected(init.strutsel);

/*
    if (init.actionServletInstalled) {
      loadOnStartup.setValue(init.loadOnStartup);
    }
    else {
      loadOnStartup.setValue(2);
      struts_html.setSelected(true);
      struts_logic.setSelected(true);
      struts_bean.setSelected(true);
    }
*/
    if (init.taglibs != null) {
      for (Object o : init.taglibs.values()) {
        String location = (String)o;

        JCheckBox box = (JCheckBox)taglibs.get(new File(location).getName());
        if (box != null) {
          box.setSelected(true);
        }
      }
    }

  }

  protected void checkState() {

    boolean jstlEnabled = jstl.isSelected();
    UIUtil.enableBox(strutsel_box, strutsel.isSelected());
    UIUtil.enableBox(jstl_box, jstlEnabled);
    UIUtil.enableBox(jstl_rt_box, jstlEnabled);

    struts_tiles.setEnabled(tiles.isSelected());
    struts_tiles_el.setEnabled(tiles.isSelected() && strutsel.isSelected());

    // disable/enable buttons...
    super.checkState();
  }

  private boolean loadVersions() {

    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Loading versions...");
    Vector results = new Vector();
    String path = (String)distr.getValue();
    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Distributive path: " + path);
    instDir = VirtualFileManager.getInstance().findFileByUrl("file://" + path);
    if (instDir != null) {
      libDir = instDir.findChild("lib");
      loadVersions(libDir, results);
    }
    version.setModel(new DefaultComboBoxModel(results));
    version.setEnabled(results.size() != 0);

    String v = null; //StrutsSupportModel.formatVersion(init.strutsVersion);
    if (v != null) {
      version.setSelectedItem(v);
      if (version.getSelectedItem() != null) {
        boolean enabled = version.getSelectedItem().equals(v);
        version.setEnabled(!enabled);
      }
    }
    else {
      version.setSelectedIndex(version.getItemCount() - 1);
    }

    return (results.size() != 0);
  }

  private boolean loadVersions(VirtualFile file, Vector<String> results) {

    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Loading versions from " + file);
    if (file != null) {
      VirtualFile[] children = file.getChildren();
      for (VirtualFile aChildren : children) {
        if (Constants.LOG_DEBUG) logger.debug(aChildren);
        if (aChildren.getName().startsWith("struts-config")) {
          String ver = StrutsSupportModel.formatVersion(aChildren.getName());
          if (ver != null) {
            results.add(ver);
          }
        }
      }
    }
    return (results.size() != 0);
  }

  public VirtualFile getLibDir() {
    return libDir;
  }
}
