/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.wizards;

import com.intellij.openapi.project.Project;
import com.intellij.struts.ui.properties.PropertyLayoutBuilder;
import com.intellij.struts.ui.wizard.WizardPage;

import javax.swing.*;
import java.awt.*;

/**
 * Date: 13.05.2005 Time: 17:31:09
 *
 * @author Dmitry Avdeev
 */
public class TilePutWizard extends BaseStrutsWizard {

  public TilePutWizard(Project project) {
    super(project, "Tile Wizard");
  }

  protected WizardPage[] createPages() {
    return new WizardPage[]{

      new WizardPage(createPage(), "Set Tile attributes") {

      }};
  }

  protected Component createPage() {

    PropertyLayoutBuilder builder = getBuilder();
    addProperty(builder, "name", "Name*");
    addProperty(builder, "type", "Type");
    addProperty(builder, "role", "Role");
    builder.addComponent(Box.createRigidArea(new Dimension(500, 10)));

    builder.finish();
    return builder.getPanel();
  }
}
