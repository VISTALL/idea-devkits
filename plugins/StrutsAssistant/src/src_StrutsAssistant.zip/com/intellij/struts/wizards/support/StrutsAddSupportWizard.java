/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.wizards.support;

import com.intellij.ide.wizard.AbstractWizard;
import com.intellij.ide.util.projectWizard.AddSupportStep;
import com.intellij.ide.util.projectWizard.ProjectWizardStepFactory;
import com.intellij.openapi.module.Module;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

/**
 * @author Dmitry Avdeev
 */
public class StrutsAddSupportWizard extends AbstractWizard<AddSupportStep> {

  private final StrutsAddSupportContext myContext;
  private final Module myModule;

  public StrutsAddSupportWizard(final StrutsAddSupportContext context, Module module) {
    super("Add Struts support", context.getProject());

    myContext = context;
    myModule = module;
    addStep(new StrutsFeaturesStep(myContext, null));
    addStep(ProjectWizardStepFactory.getInstance().createLoadJarsStep(myContext, "Struts Libraries", "Struts libraries", null));
    init();
  }

  protected int getNextStep(final int step) {
    for (int i = step + 1; i < mySteps.size(); i++) {
      if (mySteps.get(i).isStepVisible()) {
        return i;
      }
    }
    return step;
  }

  protected int getPreviousStep(final int step) {
    for (int i = step - 1; i >= 0; i--) {
      if (mySteps.get(i).isStepVisible()) {
        return i;
      }
    }
    return step;
  }

  protected void updateStep() {
    super.updateStep();
    final int currentStep = getCurrentStep();
    getNextButton().setEnabled(currentStep != getNextStep());
    getPreviousButton().setEnabled(currentStep != getPreviousStep());
  }

  protected void doOKAction() {
    super.doOKAction();
    myContext.installSupportInAction(myModule, null);
  }


  @Nullable
  @NonNls
  protected String getHelpID() {
    return null;
  }
}
