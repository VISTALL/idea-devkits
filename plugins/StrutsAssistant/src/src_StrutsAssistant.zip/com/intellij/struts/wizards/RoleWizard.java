/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.wizards;

import com.intellij.javaee.model.xml.SecurityRole;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.javaee.web.WebUtil;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.application.Result;
import com.intellij.struts.ui.properties.DefaultPropertiesSource;
import com.intellij.struts.ui.properties.DefaultProperty;
import com.intellij.struts.ui.properties.Property;
import com.intellij.struts.ui.properties.PropertyLayoutBuilder;
import com.intellij.struts.ui.wizard.WizardPage;

import javax.swing.*;
import java.awt.*;

/**
 */
public class RoleWizard extends BaseStrutsWizard {
/*
    public RoleWizard(Object project) {
        super(project, "Security Role Wizard");
    }
*/

  public RoleWizard(Project project, Object module) {
    super(project, "Security Role Wizard", module);
  }

  public RoleWizard(Dialog owner, Project project, Object module) {
    super(owner, project, "Security Role Wizard", module);
  }

  protected WizardPage[] createPages() {
    return new WizardPage[]{

      new WizardPage(createPage(), "Security Role attributes") {

      }};
  }

  protected Object onSuccess() {
    return new WriteCommandAction<String>(project) {
      protected void run(Result<String> runResult) {
        WebModuleProperties prop = WebUtil.getWebModuleProperties((Module)context);
          String rolename = current.getPropertyValue("role-name");
          String desc = current.getPropertyValue("role-description");
          SecurityRole role = prop.getRoot().addSecurityRole();
          role.getRoleName().setValue(rolename);
          role.addDescription().setValue(desc);
          runResult.setResult(rolename);
      }

    }.execute().getResultObject();
  }

  protected Component createPage() {

    PropertyLayoutBuilder builder = getBuilder();
    addProperty(builder, "role-name", "Name*");
    addProperty(builder, "role-description", "Description");
    builder.addComponent(Box.createRigidArea(new Dimension(500, 10)));

    builder.finish();
    return builder.getPanel();
  }

  public void setInitial(Object source) {
    DefaultPropertiesSource props = new DefaultPropertiesSource();
    DefaultProperty name = new DefaultProperty("role-name", null, true, null);
    if (source instanceof Property) {
//            name.setValue(((Property)source).getValue());
    }
    else {
      name.setValue(source);
    }
    props.addProperty(name);
    props.addProperty(new DefaultProperty("role-description", null, false, null));

    super.setInitial(props);
  }
}
