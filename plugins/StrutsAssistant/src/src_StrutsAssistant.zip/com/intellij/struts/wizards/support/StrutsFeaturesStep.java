/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.wizards.support;

import com.intellij.ide.util.projectWizard.AddSupportStep;

import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.*;

/**
 * @author Dmitry Avdeev
 */
public class StrutsFeaturesStep extends AddSupportStep<StrutsAddSupportContext> {

  private JPanel myMainPanel;
  private JCheckBox myTilesSupport;
  private JCheckBox myValidatorSupport;
  private JCheckBox myStrutsELSupport;
  private JPanel myDescriptionPanel;
  private JComboBox myVersionComboBox;
  private JCheckBox myStrutsTaglibCheckBox;
  private JCheckBox myScriptingCheckBox;
  private JCheckBox myExtrasCheckBox;
  private JCheckBox myStrutsFacesCheckBox;

  protected StrutsFeaturesStep(final StrutsAddSupportContext context, Icon icon) {
    
    super(context, icon);

    myVersionComboBox.setModel(new EnumComboBoxModel<StrutsVersion>(StrutsVersion.class));
    final StrutsVersion strutsVersion = context.getVersion();
    myVersionComboBox.setEnabled(strutsVersion == null);
    myVersionComboBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        final StrutsVersion strutsVersion = (StrutsVersion)myVersionComboBox.getModel().getSelectedItem();
        switch (strutsVersion) {
          case Struts1_2_9:
            if (!myStrutsTaglibCheckBox.isSelected()) {
              myStrutsTaglibCheckBox.setSelected(true);
            }
            myStrutsTaglibCheckBox.setEnabled(false);
            myStrutsFacesCheckBox.setEnabled(false);
            myScriptingCheckBox.setEnabled(false);
            myExtrasCheckBox.setEnabled(false);

            myStrutsFacesCheckBox.setSelected(false);
            myScriptingCheckBox.setSelected(false);
            myExtrasCheckBox.setSelected(false);

            break;
          case Struts1_3_5:
            myScriptingCheckBox.setSelected(myContext.isScriptingSupport());
            myExtrasCheckBox.setSelected(myContext.isExtrasSupport());
            myStrutsFacesCheckBox.setSelected(myContext.isStrutsFacesSupport());
            myStrutsTaglibCheckBox.setSelected(myContext.isStrutsTaglibSupport() || myContext.isInsideAddModuleWizard());

            myStrutsTaglibCheckBox.setEnabled(!myContext.isStrutsTaglibSupport() || myContext.isInsideAddModuleWizard());
            myStrutsFacesCheckBox.setEnabled(!myContext.isStrutsFacesSupport());
            myScriptingCheckBox.setEnabled(!myContext.isScriptingSupport());
            myExtrasCheckBox.setEnabled(!myContext.isExtrasSupport());

            break;
        }
        myContext.setVersion(strutsVersion);
      }
    });

    myTilesSupport.setSelected(context.isTilesSupport());
    myValidatorSupport.setSelected(context.isValidatorSupport());
    myStrutsFacesCheckBox.setSelected(context.isStrutsFacesSupport());
    myStrutsELSupport.setSelected(context.isStrutsELSupport());
    myScriptingCheckBox.setSelected(context.isScriptingSupport());
    myExtrasCheckBox.setSelected(context.isExtrasSupport());

    myStrutsTaglibCheckBox.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        if (!myStrutsTaglibCheckBox.isSelected()) {
          myStrutsELSupport.setSelected(false);        
        }
        myStrutsELSupport.setEnabled(myStrutsTaglibCheckBox.isSelected() && !myContext.isStrutsELSupport());
      }
    });
    myStrutsTaglibCheckBox.setSelected(context.isStrutsTaglibSupport() || context.isInsideAddModuleWizard());
    myVersionComboBox.setSelectedItem(strutsVersion == null ? StrutsVersion.Struts1_3_5 : strutsVersion);


    if (context.isInsideAddModuleWizard()) {
      myDescriptionPanel.setVisible(false);
    }
    else {
      myDescriptionPanel.setLayout(new BorderLayout());
      myDescriptionPanel.add(BorderLayout.CENTER, StrutsWizardStepsProvider.createDescriptionPanel());
    }

    updateDataModel();
    fireStateChanged();
  }


  public JComponent getComponent() {
    return myMainPanel;
  }

  public void updateDataModel() {

    myContext.setTilesSupport(myTilesSupport.isSelected());
    myContext.setValidatorSupport(myValidatorSupport.isSelected());
    myContext.setStrutsELSupport(myStrutsELSupport.isSelected());

    myContext.setScriptingSupport(myScriptingCheckBox.isSelected());
    myContext.setExtrasSupport(myExtrasCheckBox.isSelected());
    myContext.setStrutsFacesSupport(myStrutsFacesCheckBox.isSelected());
    myContext.setStrutsTaglibSupport(myStrutsTaglibCheckBox.isSelected());

  }
}
