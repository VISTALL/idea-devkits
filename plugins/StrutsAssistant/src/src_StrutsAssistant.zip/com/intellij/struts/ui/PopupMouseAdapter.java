/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui;

import org.apache.log4j.Logger;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Date: 25.11.2004 Time: 16:58:15
 *
 * @author Dmitry Avdeev
 */
public abstract class PopupMouseAdapter extends MouseAdapter {

  protected static final Logger logger = Logger.getLogger(PopupMouseAdapter.class);

  public void mouseClicked(MouseEvent e) {
//		if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Mouse clicked: " + e);
    if (e.isPopupTrigger() || e.getButton() == MouseEvent.BUTTON3) {
      showPopup(e);
    }
  }

  public void mousePressed(MouseEvent e) {
//		if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Mouse pressed: " + e);
    if (e.isPopupTrigger() || e.getButton() == MouseEvent.BUTTON3) {
      //		showPopup(e);
    }
  }
/*
	public void mouseReleased(MouseEvent e) {
		if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Mouse released: " + e);
		if (e.isPopupTrigger()) {
			showPopup(e);
		}
	}
*/

  protected abstract JPopupMenu createMenu(MouseEvent e);

  protected void showPopup(MouseEvent e) {
    JPopupMenu menu = createMenu(e);
    if (menu != null) {
      menu.show(e.getComponent(), e.getX(), e.getY());
    }
  }
}
