/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.checks;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Date: 12.09.2005 Time: 17:09:57
 *
 * @author Dmitry Avdeev
 */
public class CheckList extends JList implements Checker {

  private final Object[] values;

  private static CheckBoxItem[] createModel(Object[] values) {
    CheckBoxItem[] model = new CheckBoxItem[values.length];
    for (int i = 0; i < model.length; i++) {
      model[i] = new CheckBoxItem(values[i]);
    }
    return model;
  }

  public CheckList(Object[] values) {

    super(createModel(values));

    this.values = values;
    this.setCellRenderer(new CheckBoxRenderer(this));

    addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent me) {
        int selectedIndex = locationToIndex(me.getPoint());
        if (selectedIndex < 0) return;
        CheckBoxItem item = (CheckBoxItem)getModel().getElementAt(selectedIndex);
        item.setChecked(!item.isChecked());
        repaint();

      }
    });

  }

  public Object getValue(int i) {
    return values[i];
  }

  public String getCaption(Object o) {
    return o.toString();
  }

  public void checkItem(int i) {
    ((CheckBoxItem)this.getModel().getElementAt(i)).setChecked(true);
  }

  public List getCheckedValues() {
    ArrayList result = new ArrayList();
    for (int i = 0; i < values.length; i++) {
      if (((CheckBoxItem)this.getModel().getElementAt(i)).isChecked()) {
        result.add(values[i]);
      }
    }
    return result;
  }

}
