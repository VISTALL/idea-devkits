/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.properties;

import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiManager;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.struts.ui.action.ActionWrapper;
import com.intellij.struts.ui.action.SmartAction;
import com.intellij.struts.ui.edit.*;
import com.intellij.openapi.util.IconLoader;
import com.intellij.struts.ui.table.ObjectFormat;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.util.Vector;

/**
 * Date: 25.04.2005 Time: 15:58:35
 *
 * @author Dmitry Avdeev
 */
public class PropertyEditor implements EditField {

  private final static Icon ICON = IconLoader.getIcon("/com/intellij/struts/ui/edit/star.png");

  protected final static Logger logger = Logger.getLogger(PropertyEditor.class);

  private final Property p;
  private final EditField field;
  private ChangeListener l;

  /**
   * @param p
   * @param owner
   * @param context typically FileAdapter
   */
  public PropertyEditor(final Property p, Dialog owner, Object context) {

    if (p == null) {
      throw new NullPointerException("Property cannot be null to create an editor");
    }
    this.p = p;
    ObjectFormat format = p.getFormat();
    if (format != null && format.getBrowser() != null) {
      JComponent c = null;
      if (format.getList() != null) {
        c = new JComboBox(new ListSourceComboModel(format.getList()));
        ((JComboBox)c).setEditable(true);
      }
      else if (format.getBrowser()instanceof ClassBrowser) {
        String extend = ((ClassBrowser)format.getBrowser()).getExtendClass();
        if (extend != null) {
          Object pr = ((ClassBrowser)format.getBrowser()).getProject();
          if (pr instanceof Project) {
            Project project = (Project)pr;
            GlobalSearchScope scope = GlobalSearchScope.allScope(project);
            if (extend != null) {
              PsiClass clazz = PsiManager.getInstance(project).findClass(extend, scope);
              if (clazz != null) {
                PsiClass[] classes = PsiManager.getInstance(project).getSearchHelper().findInheritors(clazz, scope, true);
                if (classes != null && classes.length > 0) {
                  Vector names = new Vector(classes.length);
                  for (int i = 0; i < classes.length; i++) {
                    if (classes[i].getQualifiedName().startsWith("org.apache.struts") &&
                        !classes[i].getModifierList().hasModifierProperty("abstract")) {
                      names.add(classes[i].getQualifiedName());
                    }
                  }
                  c = new JComboBox(names);
                  ((JComboBox)c).setEditable(true);
                  ((JComboBox)c).setSelectedItem(null);
                }
              }
            }
          }
        }
      }
      field = new BrowseField(c, format.getBrowser(), owner, true);
    }
    else if (format != null && format.getList() != null) {
      if (format.hasFlag(ObjectFormat.FLAG_CSV)) {
        field = new CheckComboField(format.getList());
      }
      else {
        field = new ComboEditField(format.getList());
      }
    }
    else if (format != null && format.getType() == Boolean.class) {
      Boolean defaultValue = null;
      if (p.getDefault()instanceof Boolean) {
        defaultValue = (Boolean)p.getDefault();
      }
      field = new CheckBoxField(defaultValue);
    }
    else {
      field = new TextEditField();
    }

    if (format != null && format.getEditProvider() != null && format.getEditProvider().isEditable(p)) {
      SmartAction a = format.getEditProvider().getCreateNewAction(p, owner, context);
      if (a != null && field instanceof ComplexField) {
        ActionWrapper w = new ActionWrapper(a) {

          protected void onSuccess(Object result) {
            if (field instanceof CheckComboField) {
              ((CheckComboField)field).addValue((String)result);
            }
            else {
              field.setValue(result);
            }
          }
        };
        w.putValue(Action.SMALL_ICON, ICON);
        String name = (String)w.getValue(Action.NAME);
        w.putValue(Action.NAME, null);
        w.putValue(Action.SHORT_DESCRIPTION, name);
        ((ComplexField)field).addAction(w);
      }
    }
    setValue(p.getValue());

    field.addChangeListener(new ChangeListener() {

      public void stateChanged(ChangeEvent e) {
        PropertyEditor.this.p.setValue(field.getValue());
        field.displayAsDefault(false);
        if (l != null) {
          l.stateChanged(e);
        }
      }
    });
  }

  public JComponent getComponent() {
    return field.getComponent();
  }

  public void updateUI() {
    field.updateUI();
  }

  public JLabel getLabel() {
    return field.getLabel();
  }

  public Object getValue() {
    return p.getValue();
  }

  public void setValue(Object value) {

    if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Setting " + p.getName() + " = " + value);
    if (value == null && p.getDefault() != null) {
      // display default value
      field.setValue(p.getDefault());
      field.displayAsDefault(true);
    }
    else {
      field.setValue(value);
      field.displayAsDefault(false);
    }
//		p.setValue(value);
  }

  public void displayAsDefault(boolean on) {
    field.displayAsDefault(on);
  }

  public void setEnabled(boolean on) {
    field.setEnabled(on);
  }

  public boolean isShort() {
    return field.isShort();
  }

  public void addChangeListener(final ChangeListener l) {
    this.l = l;
  }

  public boolean isEmpty() {
    Object val = this.getValue();
    return val == null || (val instanceof String && ((String)val).trim().length() == 0);
  }

  public boolean isValid() {
    return true;
  }

}
