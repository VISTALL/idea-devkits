/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.edit;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;
import java.awt.*;

/**
 * Date: 23.11.2004 Time: 17:13:00
 *
 * @author Dmitry Avdeev
 */
public class BrowseButton extends JButton {

  private final JComponent attachedComponent;
  private final boolean wide;

  public BrowseButton(JComponent component, Icon icon, boolean wide) {

    super(icon);
    this.attachedComponent = component;
    this.wide = wide;
    setMargin(new Insets(0, 0, 0, 0));
    setDefaultCapable(false);
    setFocusable(false);
  }

  public BrowseButton(JComponent component, boolean wide) {
    this(component, IconLoader.getIcon("/com/intellij/struts/ui/edit/ellipsis.png"), wide);
  }

  public Dimension getMinimumSize() {
    return getPreferredSize();
  }

  public Dimension getMaximumSize() {
    return getPreferredSize();
  }

  public Dimension getPreferredSize() {
    int width = super.getPreferredSize().width;
    if (wide) {
      width += 2;
    }
    int height = attachedComponent.getPreferredSize().height;
    return new Dimension(width, height);
  }
}
