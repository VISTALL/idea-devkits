/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.edit;

import javax.swing.*;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * TODO: implement reset to default feature
 *
 * @author Dmitry Avdeev
 */
public class CheckBoxField extends BaseField {

  private final JCheckBox checkBox;
//	private final Boolean defaultValue;
  private final boolean def;

  /**
   * @param defaultValue if null, no default value applied
   */
  public CheckBoxField(Boolean defaultValue) {
//		this.defaultValue = defaultValue;
    this.def = defaultValue != null && defaultValue.booleanValue();
    checkBox = new JCheckBox();
    checkBox.setBorder(null);
  }

  public JComponent getComponent() {
    return checkBox;
  }

  public Object getValue() {
    return Boolean.valueOf(checkBox.isSelected());
  }

  public void setValue(Object value) {
    if (value == null) {
      checkBox.setSelected(def);
    }
    else {
      checkBox.setSelected(((Boolean)value).booleanValue());
    }
  }

  public void displayAsDefault(boolean on) {
    checkBox.setText(on ? " (default)" : "");
//		checkBox.addMouseMotionListener();
//		Map map = checkBox.getFont().getAttributes();
/*
		if (on) {
			map.remove(TextAttribute.UNDERLINE);
		} else {
			map.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
		}
		Font newFont = new Font(map);
		checkBox.setFont(newFont);
*/
//		checkBox.setRolloverEnabled(true);
//		checkBox
//		checkBox.setFont();
  }

  public boolean isShort() {
    return true;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public void addChangeListener(final ChangeListener l) {
    checkBox.addActionListener(new ActionListener() {

      public void actionPerformed(ActionEvent e) {
        l.stateChanged(null);
			}
		});
	}
}
