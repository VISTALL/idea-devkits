/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.properties;

import com.intellij.struts.ui.table.ObjectFormat;

/**
 * Date: 08.10.2004 Time: 18:21:18
 *
 * @author Dmitry Avdeev
 */
public class BaseProperty extends AbstractProperty {

  protected String name;
  protected int type;
  private boolean expanded;

  public BaseProperty() {
  }

  public BaseProperty(String name, ObjectFormat format) {
    this.name = name;
    this.format = format;
  }

  public String getName() {
    return name;
  }

  public String getCaption() {
    return name;
  }

  public boolean isRequired() {
    return false;
  }

  public int getPropertyType() {
    return type;
  }

  public String getDepend() {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public int getProf() {
    return 0;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public boolean isExpanded() {
    return expanded;
  }

  public void setExpanded(boolean expanded) {
    this.expanded = expanded;
  }


}
