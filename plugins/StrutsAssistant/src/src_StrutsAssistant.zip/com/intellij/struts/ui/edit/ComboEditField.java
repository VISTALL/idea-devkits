/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.edit;

import com.intellij.struts.util.ListSource;

import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.event.PopupMenuEvent;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * Date: 05.05.2005 Time: 16:03:38
 *
 * @author Dmitry Avdeev
 */
public class ComboEditField extends ComplexField {

  private final JComboBox combo;
  private Object context;

  public ComboEditField(List items) {
    super(new JComboBox(items.toArray()));
    combo = (JComboBox)editComponent;
    init();
  }

  public ComboEditField(ListSource source) {
    super(new JComboBox(new ListSourceComboModel(source)));
    combo = (JComboBox)editComponent;
    combo.addPopupMenuListener(new PopupMenuAdapter() {

      public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
        ((ListSourceComboModel)combo.getModel()).update(context);
        combo.setModel(combo.getModel());
      }
    });
    init();
  }

  protected void init() {
    combo.setRenderer(new ListRenderer());
    combo.setEditable(true);
  }


  public Object getValue() {
    Object value;
    if (combo.getSelectedItem() == getDefaultItem()) {
      value = null;
    }
    else {
      value = combo.getSelectedItem();
    }
    return value;
  }

  public void setValue(Object newValue) {
    if (newValue == null) {
      newValue = getDefaultItem();
    }
    combo.setSelectedItem(newValue);
  }

  protected Object getDefaultItem() {
    for (int i = 0; i < combo.getItemCount(); i++) {
      if (combo.getItemAt(i)instanceof String && ((String)combo.getItemAt(i)).endsWith("(default)")) {
        return combo.getItemAt(i);
      }
    }
    return null;
  }

  public void displayAsDefault(boolean on) {
    if (on) {
      combo.setSelectedItem(getDefaultItem());
    }
  }

  public boolean isShort() {
    return true;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public void addChangeListener(final ChangeListener l) {
    combo.addActionListener(new ActionListener() {

      public void actionPerformed(ActionEvent e) {
        l.stateChanged(null);
      }
    });
  }

  public void setContext(Object context) {
    this.context = context;
  }

  protected static class ListRenderer extends DefaultListCellRenderer {

    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
      Component result = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
      if (value instanceof String && ((String)value).indexOf("(default)") != -1) {
        result.setEnabled(false);
      }

      return result;
    }
  }


}
