/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;
import java.awt.*;

/**
 * Date: 25.01.2005 Time: 13:46:03
 *
 * @author Dmitry Avdeev
 */
public class MessageBox extends SmartDialog {

  public final static int QUESTION_ICON = 0x0001;
  public final static int WARNING_ICON = 0x0002;
  public final static int ERROR_ICON = 0x0003;

  public final static int OK_BUTTON = 0x0000;


  private final String message;
  private final int flags;
  private int resultButton = 0x1111;

  public MessageBox(Frame owner, String title, String message, int flags) {
    super(owner, title);
    this.message = message;
    this.flags = flags;
    init();
  }

  protected JComponent createCenterPanel() {
    Box panel = new Box(BoxLayout.X_AXIS);
    Icon icon = IconLoader.getIcon("/com/intellij/struts/ui/questionDialog.png");
    panel.add(new JLabel(icon));
    panel.add(new JLabel(message));
    return panel;
  }

  protected JComponent createBottomPanel() {
    return super.createBottomPanel();
  }

  protected void onOk() {
    resultButton = OK_BUTTON;
    hide();
  }

  public static int showMessage(Frame frame, String title, String message, int flags) {
    MessageBox dlg = new MessageBox(frame, title, message, flags);
    dlg.pack();
    dlg.setLocationRelativeTo(null);
    dlg.show();
    return dlg.resultButton;
  }
}
