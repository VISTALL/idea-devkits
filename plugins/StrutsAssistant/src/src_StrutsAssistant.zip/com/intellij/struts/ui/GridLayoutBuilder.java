/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui;

import javax.swing.*;
import java.awt.*;

/**
 * Date: 25.04.2005 Time: 17:01:29
 *
 * @author Dmitry Avdeev
 */
public class GridLayoutBuilder {

  private final JPanel panel = new JPanel(new GridBagLayout());

  public GridBagConstraints getConstraints() {
    return c;
  }

  private final GridBagConstraints c = new GridBagConstraints();

  public GridLayoutBuilder() {
    c.fill = GridBagConstraints.HORIZONTAL;
    c.anchor = GridBagConstraints.CENTER;
    c.insets = new Insets(5, 5, 5, 5);
    c.gridy = 0;
  }

  public JPanel getPanel() {
    return panel;
  }

  public void addComponent(Component comp) {
    c.weightx = 1.0;
    c.gridwidth = 3;
    panel.add(comp, c);
//		c.weightx = 1.0;
    c.gridy++;
  }

  public void addComponentPair(Component comp, Component comp2) {
    c.fill = GridBagConstraints.BOTH;
    c.weightx = 0.5;
    c.gridwidth = 1;
    panel.add(comp, c);
    c.gridwidth = 2;
    panel.add(comp2, c);
    c.gridy++;
  }

  public void addLine(String label) {
    JLabel l = new JLabel(label);
    l.setFocusable(false);
    addLine(l);
  }

  public void addLine(Component label) {
//		c.weightx = -1.0;
    c.gridwidth = 3;
    panel.add(label, c);
    c.gridy++;
  }

  public void addLine(JLabel label, Component comp) {

    c.weightx = -1.0;
    c.gridwidth = 1;
    label.setHorizontalAlignment(SwingConstants.RIGHT);
    label.setFocusable(false);
    panel.add(label, c);
    c.weightx = 1.0;
    c.gridwidth = 2;
    panel.add(comp, c);
    c.gridy++;
  }

  public void addLine(String label, Component comp) {

    c.weightx = -1.0;
    c.gridwidth = 1;
    JLabel lab = new JLabel(label, SwingConstants.RIGHT);
    lab.setFocusable(false);
    panel.add(lab, c);
    c.weightx = 1.0;
    c.gridwidth = 2;
    panel.add(comp, c);
    c.gridy++;
  }

  public void addShortLine(JLabel label, Component comp) {

    c.weightx = -1.0;
    c.gridwidth = 1;
    label.setHorizontalAlignment(SwingConstants.RIGHT);
    label.setFocusable(false);
    panel.add(label, c);
//		c.weightx = 1.0;
    panel.add(comp, c);
    c.gridy++;
  }

  public void finish() {
    c.weightx = -1.0;
    c.weighty = 1.0;
    panel.add(Box.createVerticalGlue(), c);
  }
}
