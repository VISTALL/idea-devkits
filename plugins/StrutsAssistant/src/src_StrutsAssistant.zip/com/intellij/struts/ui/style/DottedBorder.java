/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.style;

import javax.swing.border.LineBorder;
import java.awt.*;

/**
 * Date: 13.01.2005 Time: 16:04:20
 *
 * @author Dmitry Avdeev
 */
public class DottedBorder extends LineBorder {

  public DottedBorder(Color color) {
    super(color);
  }

  public void paintBorder(Component c, Graphics g, int startX, int startY, int width, int height) {

    g.setColor(lineColor);
    int endX = startX + width - 1;
    int endY = startY + height - 1;
    int p;
    for (p = startX; p <= endX; p += 2) {
      g.drawLine(p, startY, p, startY);
    }

    for (p = p == endX + 1 ? startY + 1 : startY + 2; p <= endY; p += 2) {
      g.drawLine(endX, p, endX, p);
    }

    for (p = p == endY + 1 ? endX - 1 : endX - 2; p >= startX; p -= 2)
      g.drawLine(p, endY, p, endY);

    for (p = p == startX - 1 ? endY - 1 : endY - 2; p >= startY; p -= 2)
      g.drawLine(startX, p, startX, p);
  }
}
