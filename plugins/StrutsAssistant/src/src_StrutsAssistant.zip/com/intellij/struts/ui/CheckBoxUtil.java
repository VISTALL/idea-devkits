/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui;

import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Date: 18.02.2005 Time: 17:21:10
 *
 * @author Dmitry Avdeev
 */
public class CheckBoxUtil {

  protected final static Logger logger = Logger.getLogger(CheckBoxUtil.class);

  public static void synchronize(JCheckBox a, JCheckBox b, ChangeListener l) {
    synchronize(new JCheckBox[]{a, b}, l);
  }

  private static class BoxListener implements ChangeListener {

    private boolean lastValue;
    final JCheckBox[] boxes;
    final ChangeListener l;

    BoxListener(JCheckBox[] boxes, ChangeListener l) {
      this.boxes = boxes;
      this.l = l;
      lastValue = boxes[0].isSelected();
    }

    public synchronized void stateChanged(ChangeEvent e) {

      JCheckBox source = (JCheckBox)e.getSource();
      boolean value = source.isSelected();
      if (value == lastValue) {
        return;
      }
      lastValue = value;
      if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Checkbox " + source + " is " + value);
      for (int i = 0; i < boxes.length; i++) {
        if (boxes[i] != source && value != boxes[i].isSelected()) {
          boxes[i].setSelected(value);
        }
      }
      l.stateChanged(e);
    }
  }

  public static void synchronize(final JCheckBox[] boxes, final ChangeListener l) {

    ChangeListener listener = new BoxListener(boxes, l);

    for (int i = 0; i < boxes.length; i++) {
      boxes[i].addChangeListener(listener);
    }
  }
}
