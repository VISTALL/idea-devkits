/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui;

import javax.swing.*;

/**
 * Date: 11.02.2005 Time: 18:13:46
 *
 * @author Dmitry Avdeev
 */
public class ListUtil {

  public static void select(JList list, int index) {
    list.setSelectedIndex(index);
  }

  public static void moveUp(JList list) {
    int sel = list.getSelectedIndex();
    if (sel < 0) {
      sel = 0;
    }
    else if (sel > 0) {
      sel--;
    }
    list.setSelectedIndex(sel);
    list.ensureIndexIsVisible(sel);
  }

  public static void moveDown(JList list) {
    int sel = list.getSelectedIndex();
    if (sel < 0) {
      sel = 0;
    }
    else if (sel < list.getModel().getSize() - 1) {
      sel++;
    }
    list.setSelectedIndex(sel);
    list.ensureIndexIsVisible(sel);
  }
}
