/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.edit;

import com.intellij.struts.ui.checks.CheckComboBox;
import com.intellij.struts.ui.checks.CheckComboModel;
import com.intellij.struts.util.ListSource;

import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.event.PopupMenuEvent;

/**
 * Date: 05.05.2005 Time: 16:03:38
 *
 * @author Dmitry Avdeev
 */
public class CheckComboBaseField extends BaseField {

  private final CheckComboBox combo;

  public CheckComboBaseField(ListSource source) {
    combo = new CheckComboBox(source);
  }

  public CheckComboBaseField() {
    combo = new CheckComboBox();
  }

  public void setSource(ListSource model) {
    combo.setModel(new CheckComboModel(model));
  }

  public JComponent getComponent() {
    return combo;
  }

  public Object getValue() {
    return combo.getValue();
  }

  public void setValue(Object value) {
    combo.setValue(value == null ? "" : (String)value);
  }

  public void addValue(String value) {
    combo.addValue(value);
  }

  protected Object getDefaultItem() {
    for (int i = 0; i < combo.getItemCount(); i++) {
      if (combo.getItemAt(i)instanceof String && ((String)combo.getItemAt(i)).endsWith("(default)")) {
        return combo.getItemAt(i);
      }
    }
    return null;
  }

  public void displayAsDefault(boolean on) {
    if (on) {
      combo.setSelectedItem(getDefaultItem());
    }
  }

  public boolean isShort() {
    return false;
  }

  public void addChangeListener(final ChangeListener l) {

    combo.addPopupMenuListener(new PopupMenuAdapter() {

      public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
        l.stateChanged(null);
      }
    });

/*
        addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				l.stateChanged(null);
			}
		});
*/
  }
}
