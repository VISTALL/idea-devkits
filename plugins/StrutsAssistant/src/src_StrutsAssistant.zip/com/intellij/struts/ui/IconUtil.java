/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui;

import org.jetbrains.annotations.NonNls;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

/**
 * Date: 07.02.2005 Time: 12:39:15
 *
 * @author Dmitry Avdeev
 */
public class IconUtil {

  private IconUtil() {
  }

  public static Icon mergeIcons(ImageIcon icon, @NonNls String sign, int x, int y) throws IOException {

    // create BufferedImage from the icon
    Image image = icon.getImage();
    BufferedImage buffImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_ARGB);

    Graphics g = buffImage.getGraphics();
    g.drawImage(image, 0, 0, null);
    g.dispose();

    return mergeIcons(buffImage, IconUtil.class.getResource(sign), x, y);
  }

  public static Icon mergeIcons(URL main, URL sign, int x, int y) throws IOException {
    BufferedImage image = ImageIO.read(main);
    return mergeIcons(image, sign, x, y);
  }

  public static Icon mergeIcons(BufferedImage image, URL sign, int x, int y) throws IOException {

    Image signImage = ImageIO.read(sign);

    Graphics2D g = image.createGraphics();
    g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER));
    g.drawImage(signImage, x, y, null);
    g.dispose();

    return new ImageIcon(image);
  }

  public static Icon mergeIcons(String main, String sign, int x, int y) throws IOException {
    return mergeIcons(IconUtil.class.getResource(main), (IconUtil.class.getResource(sign)), x, y);
  }
}
