/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.properties;

import com.intellij.struts.ui.GridLayoutBuilder;

import java.awt.*;

/**
 * Date: 25.04.2005 Time: 17:07:36
 *
 * @author Dmitry Avdeev
 */
public class PropertyLayoutBuilder extends GridLayoutBuilder {

  private final Dialog owner;
  private final Object context;

  public PropertyLayoutBuilder(Dialog owner, Object context) {

    this.owner = owner;
    this.context = context;
  }

  public PropertyEditor addProperty(Property p, String label) {
    PropertyEditor editor = new PropertyEditor(p, owner, context);
    editor.getLabel().setText(label);
    editor.getLabel().setFocusable(false);
    if (editor.isShort()) {
      addShortLine(editor.getLabel(), editor.getComponent());
    }
    else {
      addLine(editor.getLabel(), editor.getComponent());
    }
    return editor;
  }
}
