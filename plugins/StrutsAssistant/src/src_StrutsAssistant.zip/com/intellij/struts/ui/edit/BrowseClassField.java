/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.edit;

import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiManager;
import com.intellij.psi.search.GlobalSearchScope;

import javax.swing.*;
import java.awt.*;

/**
 * Date: 25.04.2005 Time: 13:53:59
 *
 * @author Dmitry Avdeev
 */
public class BrowseClassField extends BrowseField {

  private final Project project;
  private boolean inter;

  public BrowseClassField(JComponent component, Project project, String extendClass, Dialog owner) {

    super(component, null, owner, true);
    this.project = project;
    ClassBrowser browser = new ClassBrowser(project, "Select Class", extendClass);
    setBrowser(browser);
  }

  public BrowseClassField(Project project, String extendClass, Dialog owner) {

    this(new JTextField(), project, extendClass, owner);
  }

  public boolean isValid() {
    if (isEmpty()) {
      return false;
    }
    String className = (String)getValue();
    PsiClass clazz = PsiManager.getInstance(project).findClass(className, GlobalSearchScope.allScope(project));
    if (clazz == null) {
      return false;
    }
    inter = clazz.isInterface();
    return super.isValid();
  }

  public boolean isInterface() {
    return inter;
  }
}
