/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.edit;

import com.intellij.ui.DocumentAdapter;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 05.12.2005
 * Time: 15:09:15
 * To change this template use File | Settings | File Templates.
 */
public abstract class ComplexField extends BaseField {

  protected final JPanel panel;
  protected final JComponent editComponent;
  protected final Box box;
  protected ActionListener listener;

  public ComplexField(JComponent component) {

    panel = new JPanel(new BorderLayout());

//		this.setBorder(null);
    if (component == null) {
      throw new IllegalArgumentException("Cannot create browse field with null component");
    }

    editComponent = component;
    panel.add(editComponent, BorderLayout.CENTER);

    box = new Box(BoxLayout.X_AXIS);
    box.setBorder(null);

    panel.add(box, BorderLayout.EAST);
    panel.setFocusable(false);
  }

  public ComplexField() {
    this(new JTextField());
  }


  public Object getValue() {
    if (editComponent instanceof JTextField) {
      return ((JTextField)editComponent).getText();
    }
    else if (editComponent instanceof JComboBox) {
      return ((JComboBox)editComponent).getSelectedItem();
    }
    else {
      throw new RuntimeException("Unknown editing component: " + editComponent.getClass());
    }
  }

  public void setValue(Object value) {
    if (editComponent instanceof JTextField) {
      ((JTextField)editComponent).setText(value == null ? null : value.toString());
    }
    else if (editComponent instanceof JComboBox) {
      ((JComboBox)editComponent).setSelectedItem(value);
    }
    else {
      throw new RuntimeException("Unknown editing component: " + editComponent.getClass());
    }
  }

  public void displayAsDefault(boolean on) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  public boolean isShort() {
    return false;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public JComponent getComponent() {
    return panel;
  }

  public JTextField getTextField() {
    return (JTextField)editComponent;
  }
/*
    public JButton getButton() {
        return browseButton;
    }
*/

  public void setEnabled(boolean enabled) {
    panel.setEnabled(enabled);
    com.intellij.struts.ui.UIUtil.enableBox(box, enabled);
    editComponent.setEnabled(enabled);
  }

  /**
   * public void setButtonEnabled(boolean buttonEnabled) {
   * myButtonEnabled = buttonEnabled;
   * setEnabled(panel.isEnabled());
   * }
   */

  public void addChangeListener(final ChangeListener l) {
    if (editComponent instanceof JTextField) {
      ((JTextField)editComponent).getDocument().addDocumentListener(new DocumentAdapter() {
        protected void textChanged(DocumentEvent e) {
          l.stateChanged(new ChangeEvent(this));
        }
      });
    }
    else if (editComponent instanceof JComboBox) {
      ((JComboBox)editComponent).addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          l.stateChanged(new ChangeEvent(this));
        }
      });
    }
    else {
      throw new RuntimeException("Unknown editing component: " + editComponent.getClass());
    }
  }


  /**
   * Now, accepts only one listener
   *
   * @param l
   */
  public void addActionListener(ActionListener l) {
    this.listener = l;
  }

  public void addAction(Action a) {
    JButton b = new BrowseButton(editComponent, true);
    b.setAction(a);
    box.add(b);
  }
}
