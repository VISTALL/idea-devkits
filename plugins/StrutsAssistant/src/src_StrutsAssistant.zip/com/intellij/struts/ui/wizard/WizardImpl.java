/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.wizard;

import com.intellij.openapi.project.Project;
import com.intellij.struts.api.AppManager;
import com.intellij.struts.ui.SmartDialog;
import com.intellij.struts.ui.action.MnemonicAction;
import com.intellij.openapi.util.IconLoader;
import com.intellij.struts.wizards.Wizard;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

/**
 * Date: 08.04.2005 Time: 12:04:42
 *
 * @author Dmitry Avdeev
 */
public class WizardImpl extends SmartDialog implements Wizard {

  protected final static Logger logger = Logger.getLogger(WizardImpl.class);

  protected final static Icon WIZARD_ICON = IconLoader.getIcon("/com/intellij/struts/ui/wizard/wizard.gif");

  protected Action previous;
  protected Action next;
  protected Action finish;
  private Action cancel;
  private Action help;

  protected ChangeListener listener;

  private JButton previousButton;
  private JButton nextButton;
  private JButton helpButton;

  private final Icon icon;

  private JPanel center;
  private CardLayout cardLayout;
  private WizardPage[] pages;
  protected int pageIndex;
  private JLabel caption;
  protected final Project project;

  public WizardImpl(Project project, String title, Icon icon) {
    super(project, title);
    this.project = project;
    this.icon = icon;
    setup();
  }

  public WizardImpl(Dialog owner, Project project, String title, Icon icon) {

    super(owner, title);
    this.project = project;
    this.icon = icon;
    setup();
  }

  protected void setup() {
    listener = new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        checkState();
      }
    };

    previous = new MnemonicAction("&Previous") {
      public void actionPerformed(ActionEvent e) {
        cardLayout.previous(center);
        pageIndex--;
        checkState();
        //               requestFocus(center);
        requestFocus(getCurrentPage().getComponent());
      }
    };

    next = new MnemonicAction("&Next") {

      {
        putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0));
      }

      public void actionPerformed(ActionEvent e) {
        cardLayout.next(center);
        pageIndex++;
        checkState();
        requestFocus(getCurrentPage().getComponent());
      }
    };
/*
    help = new AbstractAction("Help") {
      {
        putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
      }

      public void actionPerformed(ActionEvent e) {
        String helpId = getCurrentPage().getHelpId();
        if (helpId == null) {
          setEnabled(false);
        }
        else {
          AppManager.getInstance().showHelp(helpId);
        }
      }
    };
*/
    cancel = new CancelAction();
    finish = new OkAction("&Finish");

    init();

    ((JComponent)getContentPane()).setBorder(null);
  }

  protected boolean requestFocus(Component cm) {

    if (cm instanceof Container) {
      Container c = (Container)cm;
      for (int i = 0; i < c.getComponentCount(); i++) {
        Component co = c.getComponent(i);
        if (co.hasFocus()) return true;
      }
      for (int i = 0; i < c.getComponentCount(); i++) {
        Component co = c.getComponent(i);
        if (co.isFocusable()) {
          co.requestFocus();
          return true;
        }
        else {
          if (requestFocus(co)) {
            return true;
          }
        }

      }
    }
    return false;
  }

  public void setInitial(Object initial) {
    setPages(createPages());
    pack();
    if (forceLocation == null) {
      setLocationRelativeTo(null);
    }
  }

  protected WizardPage[] createPages() {
    return null;
  }

  /**
   * Method to be called from setInitial method
   *
   * @param pages
   */
  protected void setPages(WizardPage[] pages) {
    this.pages = pages;
    center.removeAll();
    if (pages != null) {
      for (int i = 0; i < pages.length; i++) {
        center.add(pages[i].getComponent(), "");
        pages[i].addChangeListener(listener);
        //              pages[i].getComponent().addKeyListener(keyListener);
      }
      if (pages.length == 1) {
        previousButton.setVisible(false);
        nextButton.setVisible(false);
      }
    }
//        center.requestFocus();

    checkState();
  }

  protected WizardPage getCurrentPage() {
    return pages[pageIndex];
  }

  protected void checkState() {

    WizardPage page = getCurrentPage();
    caption.setText(page.getCaption());

    previous.setEnabled(pageIndex > 0);

    // how many enabled pages after the current?
    boolean enabled = false;
    for (int i = pageIndex + 1; i < pages.length; i++) {
      if (pages[i].isEnabled()) {
        enabled = true;
        break;
      }
    }
    next.setEnabled(enabled && page.isValid());
    finish.setEnabled(!enabled && page.isValid());

    if (helpButton != null) {
    helpButton.setVisible(page.getHelpId() != null);
    }
  }

  protected JComponent createBottomPanel() {

    JPanel buttonPanel = new JPanel();
    JSeparator separator = new JSeparator();
    Box buttonBox = new Box(BoxLayout.X_AXIS);

    buttonPanel.setLayout(new BorderLayout());
    buttonPanel.add(separator, BorderLayout.NORTH);

    buttonBox.setBorder(new EmptyBorder(5, 10, 5, 10));
    buttonBox.setPreferredSize(new Dimension((int)BUTTON_SIZE.getWidth() * 5 + 10 * 8, (int)BUTTON_SIZE.getHeight() + 10));

    if (help != null) {
    buttonBox.add(helpButton = createButton(help));
    }
    buttonBox.add(Box.createHorizontalStrut(10));
//        helpButton.setVisible(false);

    buttonBox.add(Box.createHorizontalGlue());
    buttonBox.add(previousButton = createButton(previous));
    buttonBox.add(Box.createHorizontalStrut(10));
    buttonBox.add(nextButton = createButton(next));
    buttonBox.add(Box.createHorizontalStrut(10));
    buttonBox.add(createButton(finish));
    buttonBox.add(Box.createHorizontalStrut(10));
    buttonBox.add(createButton(cancel));

    buttonPanel.add(buttonBox, BorderLayout.CENTER);
    return buttonPanel;
  }

  protected void onActivated() {
    requestFocus(getCurrentPage().getComponent());
  }

  protected JComponent createCenterPanel() {

    cardLayout = new CardLayout();

    center = new JPanel(cardLayout);
    center.setBorder(new EmptyBorder(5, 5, 5, 5));
    return center;
  }

  protected JComponent createTopPanel() {

    JPanel topPanel = new JPanel(new BorderLayout());
    topPanel.add(new JSeparator(), BorderLayout.SOUTH);

    JPanel imagePanel = new JPanel();
    imagePanel.add(new JLabel(icon));
//		JLabel label = new JLabel(WIZARD_ICON);
//		imagePanel.add(label);
    imagePanel.setBackground(Color.WHITE);
    imagePanel.setBorder(new EmptyBorder(5, 5, 5, 5));

    topPanel.add(imagePanel, BorderLayout.EAST);
    caption = new JLabel();
    caption.setBorder(new EmptyBorder(5, 10, 5, 5));
    caption.setFont(caption.getFont().deriveFont(Font.BOLD));
    topPanel.add(caption, BorderLayout.WEST);

    topPanel.setBackground(Color.WHITE);
    return topPanel;
  }

  public Object launch(Object initial) {
    this.setInitial(initial);
    setVisible(true);
    Object result = getResult();
    if (result != null) {
      return onSuccess();
    }
    return result;
  }

  /**
   * Override it to create pages classes etc...
   */
  protected Object onSuccess() {
    return getResult();
  }
}
