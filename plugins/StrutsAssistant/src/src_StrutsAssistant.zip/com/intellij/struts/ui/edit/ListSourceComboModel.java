/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.edit;

import com.intellij.struts.util.ListSource;

import javax.swing.*;

/**
 */
public class ListSourceComboModel extends AbstractListModel implements MutableComboBoxModel {

  private final ListSource source;
  private Object selectedObject;
  private Object context;

  public ListSourceComboModel(ListSource source) {

    this.source = source;
  }

  public ListSource getSource() {
    return source;
  }

  /**
   * Returns the length of the list.
   *
   * @return the length of the list
   */
  public int getSize() {
    String[] items = source.getItems(context);
    return items == null ? 0 : items.length;
  }

  /**
   * Returns the value at the specified index.
   *
   * @param index the requested index
   * @return the value at <code>index</code>
   */
  public Object getElementAt(int index) {
    String[] items = source.getItems(context);

    return items == null || index < 0 || index >= items.length ? null : items[index];
  }

  /**
   * Returns the selected item
   *
   * @return The selected item or <code>null</code> if there is no selection
   */
  public Object getSelectedItem() {
    return selectedObject;
  }

  /**
   * Set the selected item. The implementation of this  method should notify
   * all registered <code>ListDataListener</code>s that the contents
   * have changed.
   *
   * @param anObject the list object to select or <code>null</code>
   *                 to clear the selection
   */
  public void setSelectedItem(Object anObject) {
    if ((selectedObject != null && !selectedObject.equals(anObject)) || selectedObject == null && anObject != null) {
      selectedObject = anObject;
      fireContentsChanged(this, -1, -1);
    }
  }

  public void update(Object context) {
    this.context = context;

    int size = this.getSize();
    if (size == 0) {
      this.fireContentsChanged(this, -1, -1);
    }
    else {
      this.fireContentsChanged(this, 0, size - 1);
    }
  }

  /**
   * Removes an item at a specific index. The implementation of this method
   * should notify all registered <code>ListDataListener</code>s that the
   * item has been removed.
   *
   * @param index location of object to be removed
   */
  public void removeElementAt(int index) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  /**
   * Adds an item at the end of the model. The implementation of this method
   * should notify all registered <code>ListDataListener</code>s that the
   * item has been added.
   *
   * @param obj the <code>Object</code> to be added
   */
  public void addElement(Object obj) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  /**
   * Removes an item from the model. The implementation of this method should
   * should notify all registered <code>ListDataListener</code>s that the
   * item has been removed.
   *
   * @param obj the <code>Object</code> to be removed
   */
  public void removeElement(Object obj) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  /**
   * Adds an item at a specific index.  The implementation of this method
   * should notify all registered <code>ListDataListener</code>s that the
   * item has been added.
   *
   * @param obj   the <code>Object</code> to be added
   * @param index location to add the object
   */
  public void insertElementAt(Object obj, int index) {
    //To change body of implemented methods use File | Settings | File Templates.
  }
}
