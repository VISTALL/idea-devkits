/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.tooltip;

import javax.swing.*;
import javax.swing.event.HyperlinkListener;
import javax.swing.plaf.ToolTipUI;
import java.awt.*;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 19.01.2006
 * Time: 18:44:31
 * To change this template use File | Settings | File Templates.
 */
public class HyperLinkToolTip extends JToolTip {
  private JEditorPane theEditorPane;

  public HyperLinkToolTip() {
    setLayout(new BorderLayout());
    LookAndFeel.installBorder(this, "ToolTip.border");
//        LookAndFeel.installColors(this, );
    LookAndFeel.installColorsAndFont(this, "ToolTip.background", "ToolTip.foreground", "ToolTip.font");
    theEditorPane = new JEditorPane();
    theEditorPane.setContentType("text/html");
    theEditorPane.setEditable(false);
    add(theEditorPane);
  }

  public synchronized void addHyperlinkListener(HyperlinkListener listener) {
    theEditorPane.addHyperlinkListener(listener);
  }

  public void setTipText(String tipText) {
    theEditorPane.setText(tipText);
  }

  public void updateUI() {
//        super.updateUI();
    setUI(new ToolTipUI() {
    });
  }

  public static void main(String[] args) {
    final JFrame frame = new JFrame(HyperLinkToolTip.class.getName());
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JPanel panel = new JPanel() {
      public JToolTip createToolTip() {
        JToolTip tip = new HyperLinkToolTip();
        tip.setComponent(this);
        return tip;
      }
    };
    panel.setToolTipText("<html><body><a href=\"http://www.sun.com\">www.sun.com</a></body></html>");
    frame.setContentPane(panel);
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        frame.setSize(400, 400);
        frame.show();
      }
    });
  }
}