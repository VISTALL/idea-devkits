/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.style;

import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.util.ArrayList;

/**
 * Date: 13.01.2005 Time: 12:42:07
 *
 * @author Dmitry Avdeev
 */
public class StyledComponent extends JComponent {

  protected static final Logger logger = Logger.getLogger(StyledComponent.class);

  private final ArrayList styles = new ArrayList();
  private final ArrayList fragments = new ArrayList();
  private Icon icon;
  private Insets insets;
  private int iconGap;
  private boolean paintFocusBorder;
  private boolean focusIconBorder;
  private Border border;

  public StyledComponent() {
    insets = new Insets(1, 2, 1, 2);
    border = StrokeBorder.DOTTED_BORDER;
    iconGap = 2;
    setOpaque(true);
  }

  public void setStyle(int index, Style style) {
    if (styles.size() - 1 < index) {
      styles.add(style);
      fragments.add(null);
    }
    else {
      styles.set(index, style);
    }
  }

  public void setText(int index, String text) {
    fragments.set(index, text);
  }

  public String getText(int index) {
    return (String)fragments.get(index);
  }

  public Icon getIcon() {
    return icon;
  }

  public void setIcon(Icon icon) {
    this.icon = icon;
  }

  public Insets getInsets() {
    return insets;
  }

  public void setInsets(Insets insets) {
    this.insets = insets;
  }

  public int getIconTextGap() {
    return iconGap;
  }

  public void setIconTextGap(int j) {
    if (j < 0) {
      throw new IllegalArgumentException("wrong iconTextGap: " + j);
    }
    else {
      iconGap = j;
    }
  }

  public void setPaintFocusBorder(boolean flag) {
    paintFocusBorder = flag;
  }

  public void setFocusBorderAroundIcon(boolean flag) {
    focusIconBorder = flag;
  }

  public Dimension getPreferredSize() {
    int width = insets.left + insets.right;
    if (icon != null) {
      width += icon.getIconWidth() + iconGap;
    }
    Insets insets = border.getBorderInsets(this);
    width += insets.left + insets.right;
    Font font = getFont();
    for (int k = fragments.size() - 1; k >= 0; k--) {
      Style style = (Style)styles.get(k);
      String text = getText(k);
      if (text == null) {
        continue;
      }
      if (font.getStyle() != style.getFont().getStyle()) {
        font = font.deriveFont(style.getFont().getStyle());
      }
      FontMetrics fm = getFontMetrics(font);
      width += fm.stringWidth(text);
    }

    int height = this.insets.top + this.insets.bottom;
    FontMetrics fm = getFontMetrics(font);
    int fontHeight = fm.getHeight();
    fontHeight += insets.top + insets.bottom;
    if (icon != null) {
      height += Math.max(icon.getIconHeight(), fontHeight);
    }
    else {
      height += fontHeight;
    }
    Insets insets1 = getInsets();
    width += insets1.left + insets1.right;
    height += insets1.top + insets1.bottom;
    return new Dimension(width, height);
  }

  protected void paintComponent(Graphics g) {
    int width = 0;
    if (icon != null) {
      Container container = getParent();
      Color color;
      if (container != null && !focusIconBorder) {
        color = container.getBackground();
      }
      else {
        color = getBackground();
      }
      g.setColor(color);
      g.fillRect(0, 0, icon.getIconWidth() + insets.left + iconGap, getHeight());
      icon.paintIcon(this, g, insets.left, (getHeight() - icon.getIconHeight()) / 2);
      width += insets.left + icon.getIconWidth() + iconGap;
    }
    if (isOpaque()) {
      g.setColor(getBackground());
      g.fillRect(width, 0, getWidth() - width, getHeight());
    }
    if (width == 0) {
      width = insets.left;
    }
    if (paintFocusBorder) {
      if (focusIconBorder || icon == null) {
        border.paintBorder(this, g, 0, 0, getWidth(), getHeight());
      }
      else {
        border.paintBorder(this, g, width, 0, getWidth() - width, getHeight());
      }
    }
    width += border.getBorderInsets(this).left;
    for (int k = 0; k < fragments.size(); k++) {
      String text = getText(k);
      if (text == null) {
        continue;
      }
      Style style = (Style)styles.get(k);
      Color color = style.getColor();
      if (color == null) color = getForeground();
      g.setColor(color);
      Font font = getFont();
      if (font.getStyle() != style.getFont().getStyle()) {
        font = font.deriveFont(style.getFont().getStyle());
      }
      g.setFont(font);
      FontMetrics fontmetrics = getFontMetrics(font);
      int l = (getHeight() - fontmetrics.getHeight()) / 2 + fontmetrics.getAscent();
      g.drawString(text, width, l);
      width += fontmetrics.stringWidth(text);
    }

  }


  public void setForeground(Color c) {
    ((Style)styles.get(0)).setColor(c);
    super.setForeground(c);
  }

  public void setForeground(Color c, int i) {
    ((Style)styles.get(i)).setColor(c);
  }

  public void setBorderSelectionColor(Color borderSelectionColor) {
    border = new DottedBorder(borderSelectionColor);
  }
}
