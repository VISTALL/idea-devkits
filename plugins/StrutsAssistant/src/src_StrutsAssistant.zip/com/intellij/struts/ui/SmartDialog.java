/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui;

import com.intellij.struts.ui.action.MnemonicAction;
import com.intellij.openapi.wm.WindowManager;
import com.intellij.openapi.project.Project;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.*;

/**
 * Date: 10.01.2005 Time: 17:47:21
 *
 * @author Dmitry Avdeev
 */
public class SmartDialog extends JDialog {

  protected final static Logger logger = Logger.getLogger(SmartDialog.class);

  private static final Border DEFAULT_BORDER = new EmptyBorder(8, 8, 8, 8);

  protected Action okAction;
  protected Object result;
  protected Component defaultComponent;
  protected Point forceLocation;

  public SmartDialog(Frame owner, String title) {

    super(owner, title, true);
    okAction = new OkAction();
    this.addWindowListener(new WinListener());
  }

  public SmartDialog(Dialog owner, String title) {

    super(owner, title, true);

    if (owner != null) {
      Rectangle r = owner.getBounds();
      forceLocation = new Point((int)r.getX() + 50, (int)r.getY() + 50);
      this.setLocation(forceLocation);
    }
    okAction = new OkAction();
    this.addWindowListener(new WinListener());
  }

  public SmartDialog(Project project, String title) {
    this((Frame)WindowManager.getInstance().suggestParentWindow(project), title);
  }

  protected void init() {

    JComponent top = createTopPanel();
    if (top != null) {
      getContentPane().add(top, BorderLayout.NORTH);
    }

    JComponent center = createCenterPanel();
    if (center != null) {
      getContentPane().add(center, BorderLayout.CENTER);
    }

    JComponent bottom = createBottomPanel();
    if (bottom != null) {
      getContentPane().add(bottom, BorderLayout.SOUTH);
    }

    ((JComponent)getContentPane()).setBorder(DEFAULT_BORDER);
//        setLocationRelativeTo(null);
    if (forceLocation == null) {
      setLocationRelativeTo(null);
    }

  }


  protected JComponent createCenterPanel() {
    return null;
  }

  protected JComponent createTopPanel() {
    return null;
  }

  protected JComponent createBottomPanel() {
    Box buttonsPanel = new Box(BoxLayout.X_AXIS);
    buttonsPanel.setBorder(new EmptyBorder(4, 0, 0, 0));

    buttonsPanel.add(Box.createHorizontalGlue());
    buttonsPanel.add(createButton(okAction));
    buttonsPanel.add(Box.createHorizontalStrut(4));
    buttonsPanel.add(createButton(new CancelAction()));
    return buttonsPanel;
  }

  public Object getResult() {
    return result;
  }

  protected static final Dimension BUTTON_SIZE = new Dimension(80, 24);

  protected JButton createButton(Action a) {

    JButton button = new JButton(a);
    button.setPreferredSize(BUTTON_SIZE);
    KeyStroke key = (KeyStroke)a.getValue(Action.ACCELERATOR_KEY);
    if (key != null) {
      button.getActionMap().put(a.getValue(Action.NAME), a);
      button.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(key, a.getValue(Action.NAME));
    }
    return button;
  }

  protected JButton createButton(String a) {

    JButton button = new JButton(a);
    button.setPreferredSize(BUTTON_SIZE);
    return button;
  }

  protected void onOk() {
    result = Boolean.TRUE;
    onExit();
  }

  protected void onCancel() {
    result = null;
    onExit();
  }

  protected void onExit() {
    setVisible(false);
  }

  protected void onActivated() {
    if (defaultComponent != null) {
      defaultComponent.requestFocus();
    }
  }

  public class WinListener extends WindowAdapter {

    public void windowActivated(WindowEvent e) {
      onActivated();
    }
  }

  protected class OkAction extends MnemonicAction {

    public OkAction() {
      this("Ok");
    }

    public OkAction(String caption) {
      super(caption);
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0));
    }

    public void actionPerformed(ActionEvent e) {
      onOk();
    }
  }

  protected class CancelAction extends AbstractAction {
    public CancelAction() {
      putValue(Action.NAME, "Cancel");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0));
    }

    public void actionPerformed(ActionEvent e) {
      onCancel();
    }
  }

  protected MouseListener mouseListener = new MouseAdapter() {
    public void mouseClicked(MouseEvent e) {
      if (e.getClickCount() > 1 && okAction.isEnabled()) {
        onOk();
      }
    }
  };

  protected ListSelectionListener selectionListener = new ListSelectionListener() {
    public void valueChanged(ListSelectionEvent e) {
      okAction.setEnabled(e.getFirstIndex() >= 0);
    }
  };

}
