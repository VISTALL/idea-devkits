/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.action;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 06.10.2005
 * Time: 18:22:44
 * To change this template use File | Settings | File Templates.
 */
public abstract class MnemonicAction extends AbstractAction {


  /**
   * Defines an <code>Action</code> object with the specified
   * description string and a the specified icon.
   */
  protected MnemonicAction(String text) {
    super(text);

    char myMnemonic = 0;
    StringBuffer plainText = new StringBuffer();
    for (int i = 0; i < text.length(); i++) {
      char ch = text.charAt(i);
      if (ch == '_' || ch == '&') {
        i++;
        if (i >= text.length()) {
          break;
        }
        ch = text.charAt(i);
        if (ch != '_' && ch != '&') {
          // Mnemonic is case insensitive.
          myMnemonic = Character.toUpperCase(ch);
        }
      }
      plainText.append(ch);
    }
    putValue(Action.NAME, plainText.toString());
    if (myMnemonic != 0) {
      putValue(Action.MNEMONIC_KEY, new Integer(myMnemonic));
    }
  }
}
