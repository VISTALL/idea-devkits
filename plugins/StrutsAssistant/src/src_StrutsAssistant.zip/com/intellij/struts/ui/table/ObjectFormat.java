/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.table;

import com.intellij.struts.ui.edit.Browser;
import com.intellij.struts.ui.edit.EditProvider;
import com.intellij.struts.util.ListSource;

/**
 * Date: 24.12.2004 Time: 17:06:50
 *
 * @author Dmitry Avdeev
 */
public interface ObjectFormat {

  int FLAG_NONE = 0x0000;
  int FLAG_SMART = 0x0001;
  int FLAG_CSV = 0x0002;

  Object getDefault();

  ListSource getList();

  Browser getBrowser();

  Class getType();

  EditProvider getEditProvider();

  boolean hasFlag(int flag);

  String getObjectType();

  String getCanonical();

  Object getInitial();
}
