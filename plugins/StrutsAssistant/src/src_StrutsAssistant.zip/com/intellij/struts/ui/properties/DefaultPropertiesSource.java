/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.properties;

import com.intellij.struts.util.Validatable;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Date: 25.04.2005 Time: 14:29:21
 *
 * @author Dmitry Avdeev
 */
public class DefaultPropertiesSource implements PropertiesSource, Validatable {

  protected static final Logger logger = Logger.getLogger(DefaultPropertiesSource.class);

  private final List props = new ArrayList();

  public DefaultPropertiesSource() {
  }

  public DefaultPropertiesSource(PropertiesSource initial) {
    for (Iterator i = initial.getProperties().iterator(); i.hasNext();) {
      Property p = (Property)i.next();
      props.add(new DefaultProperty(p));
    }
  }

  public void copyTo(PropertiesSource dest) {
    for (Iterator i = props.iterator(); i.hasNext();) {
      Property p = (Property)i.next();
      Property to = dest.getProperty(p.getName());
      if (to != null) {
        to.setValue(p.getValue());
      }
    }
  }

  public void addProperty(Property p) {
    props.add(p);
  }

  public List getProperties() {
    return props;
  }

  public Property getProperty(String name) {
    List props = getProperties();
    for (int i = 0; i < props.size(); i++) {
      Property p = (Property)props.get(i);
      if (p.getName().equals(name)) {
        return p;
      }
    }
    logger.warn("Property not found: " + name);
    return null;
  }

  public String getPropertyValue(String name) {
    Property p = getProperty(name);
    if (p == null) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
    else {
      Object o = p.getValue();
      return o == null ? null : o.toString();
    }
  }

  public boolean isValid() {

    for (Iterator i = getProperties().iterator(); i.hasNext();) {
      Property p = (Property)i.next();
      if (!p.isValid()) {
        return false;
      }
      /*
      if (p.getDepend() != null) {
          if (com.intellij.struts.util.Constants.LOG_DEBUG) logger.debug("Checking dependency from " + p.getDepend() + " for " + p);
          if ((!p.isEmpty()) && (getProperty(p.getDepend())).isEmpty()) {
              return false;
          }
      }
      */
    }
    return true;
  }
}
