/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.edit;

import com.intellij.openapi.fileChooser.FileChooser;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.fileChooser.FileChooserDescriptorFactory;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VirtualFileManager;
import com.intellij.struts.api.AppManager;

import javax.swing.*;
import java.awt.*;
import java.io.File;

/**
 * Date: 07.04.2005 Time: 11:53:19
 *
 * @author Dmitry Avdeev
 */
public class BrowseFileField extends BrowseField {

  public BrowseFileField(final boolean dirChooser) {

    if (AppManager.getInstance().isIdea()) {
      this.setBrowser(new Browser() {

        public Object browse(Object initial, Dialog owner) {
          try {
            FileChooserDescriptor desc;
            if (dirChooser) {
              desc = FileChooserDescriptorFactory.createSingleFolderDescriptor();
            }
            else {
              desc = FileChooserDescriptorFactory.createSingleLocalFileDescriptor();
            }
            VirtualFile f = null;
            if (initial instanceof String) {
              f = VirtualFileManager.getInstance().findFileByUrl("file://" + initial);
            }
            VirtualFile[] result = FileChooser.chooseFiles(getComponent(), desc, f);
            if (result != null && result.length > 0) {
              return result[0].getPath();
            }
          }
          catch (Exception e) {
            logger.error("Cannot browse", e);
          }
          return null;
        }
      });
    }
    else {
      final JFileChooser chooser = new JFileChooser();
      chooser.setCurrentDirectory(new java.io.File("."));

      if (dirChooser) {
        chooser.setDialogTitle("Choose Directory");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
      }
      else {
        chooser.setDialogTitle("Choose File");
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
      }

      this.setBrowser(new Browser() {
        public Object browse(Object initial, Dialog owner) {
          if (chooser.showOpenDialog(getComponent()) == JFileChooser.APPROVE_OPTION) {
            File result = chooser.getSelectedFile();
            if (result != null) {
              return result.getPath();
            }
          }
          return null;
        }
      });
    }
  }
}
