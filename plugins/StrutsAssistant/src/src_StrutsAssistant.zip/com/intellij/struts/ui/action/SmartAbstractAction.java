/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.action;

import com.intellij.struts.api.edit.ReadOnlyException;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 * Date: 18.05.2005 Time: 14:42:11
 *
 * @author Dmitry Avdeev
 */
public abstract class SmartAbstractAction extends AbstractAction implements SmartAction {

  protected final static Logger logger = Logger.getLogger(SmartAbstractAction.class);

  public Object getProject() {
    return project;
  }

  protected final Object project;

  public SmartAbstractAction(String name, Icon icon, Object project) {
    this(name, icon, project, null);
  }

  public SmartAbstractAction(String name, Icon icon, Object project, KeyStroke accelerator) {
    super(name, icon);
    this.project = project;
    this.putValue(Action.ACCELERATOR_KEY, accelerator);
  }


  public void actionPerformed(ActionEvent e) {
    if (update(null)) {
      try {
        perform(e);
      }
      catch (ReadOnlyException e1) {
        e1.display(project);
      }
      catch (Exception e1) {
        logger.error("Cannot perform action: " + e1.getMessage(), e1);
      }
    }
  }


  public String getName() {
    return (String)this.getValue(Action.NAME);
  }

  public Icon getIcon() {
    return (Icon)this.getValue(Action.SMALL_ICON);
  }

  public boolean update(Object context) {
    boolean result = checkEnabled(context);
    setEnabled(result);
    return result;
  }

  protected boolean checkEnabled(Object context) {
    return true;
  }

  public static void register(JComponent tree, Action go) {
    tree.getInputMap().put((KeyStroke)go.getValue(Action.ACCELERATOR_KEY), go);
    tree.getActionMap().put(go, go);
  }
}
