/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.properties;

import com.intellij.struts.ui.table.ObjectFormat;

/**
 * Date: 05.01.2005 Time: 19:16:51
 *
 * @author Dmitry Avdeev
 */
public abstract class AbstractProperty implements Property {

  private Object value;
  protected ObjectFormat format;
  private Listener listener;

  public void addListener(Listener listener) {
    this.listener = listener;
  }

  public void setValue(Object value) {
    this.value = value;
    if (listener != null) {
      listener.changed();
    }
  }

  /**
   * @return e.g. String, Integer or Boolean
   */
  public Object getValue() {
    return value;
  }

  public ObjectFormat getFormat() {
    return format;
  }

  public Object getDefault() {
    return format == null ? null : format.getDefault();
  }

  public boolean isEnabled() {
    return true;
  }

  public String toString() {
    return getName() + " (" + getValue() + ")";
  }

  public boolean isValid() {
    return !(isRequired() && isEmpty());
  }

  public boolean isEmpty() {
    return value == null || value instanceof String && ((String)value).trim().length() == 0;
  }

  public String getCaption() {
    return isRequired() ? getName() + '*' : getName();
  }
}
