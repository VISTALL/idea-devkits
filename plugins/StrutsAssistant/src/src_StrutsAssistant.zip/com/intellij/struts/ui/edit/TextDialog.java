/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.edit;

import com.intellij.struts.ui.SmartDialog;
import com.intellij.openapi.project.Project;

import javax.swing.*;
import javax.swing.text.Document;
import java.awt.*;

/**
 * Date: 10.01.2005 Time: 18:41:08
 *
 * @author Dmitry Avdeev
 */
public class TextDialog extends SmartDialog {

  private JTextArea textArea;

  public TextDialog(Dialog owner, String title) {
    super(owner, title);
    setSize(300, 200);
    init();
  }

  public TextDialog(Project project, String title) {
    super(project, title);
    setSize(300, 200);
    init();
  }

  protected JComponent createCenterPanel() {
    textArea = new JTextArea();
    return new JScrollPane(textArea);
  }

  protected void onOk() {
    result = textArea.getText();
    onExit();
  }

  protected void onActivated() {
    textArea.requestFocus();
  }

  public void setInitial(String text) {
    textArea.setText(text);
    Document doc = textArea.getDocument();
    if (doc != null) {
      textArea.setCaretPosition(doc.getLength());
    }

  }
}
