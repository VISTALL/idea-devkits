/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.edit;

import org.apache.log4j.Logger;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Date: 23.11.2004 Time: 17:10:20
 *
 * @author Dmitry Avdeev
 */
public class BrowseField extends ComplexField implements ActionListener {

  protected final static Logger logger = Logger.getLogger(BrowseField.class);
  private Dialog owner;
  protected final JButton browseButton;

  public Browser getBrowser() {
    return browser;
  }

  private Browser browser;

  public BrowseField(JComponent c, Browser browser, Dialog owner, boolean allowAdditionalButtons) {
    super(c == null ? new JTextField() : c);

//        editComponent.setBorder(null);
//        editComponent.setMinimumSize(new Dimension(12, 12));
    this.owner = owner;
    setBrowser(browser);
    browseButton = new BrowseButton(editComponent, allowAdditionalButtons);
    browseButton.setToolTipText("Choose...");
    if (allowAdditionalButtons) {
//            box.add(Box.createHorizontalStrut(2));
      box.add(browseButton);
    }
    else {
      panel.add(browseButton, BorderLayout.EAST);
    }

    browseButton.addActionListener(this);
  }

  public BrowseField(JComponent c) {
    this(c, null, null, false);
  }

  public BrowseField() {
    this(new JTextField(), null, null, false);
  }

  public void actionPerformed(ActionEvent e) {
    if (browser != null) {
      Object newValue = browser.browse(getValue(), owner);
      if (newValue != null) {
        setValue(newValue);
        if (listener != null) {
          listener.actionPerformed(new ActionEvent(BrowseField.this, 0, null));
        }
      }
    }
  }

  public void setBrowseObject(Browser o, Object val) {
    this.browser = o;
    setValue(val);
  }

  public void setBrowser(Browser o) {
    this.browser = o;
  }

  public void setToolTip(String toolTip) {
    browseButton.setToolTipText(toolTip);
  }
}
