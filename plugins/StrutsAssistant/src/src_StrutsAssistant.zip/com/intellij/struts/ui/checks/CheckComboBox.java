/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.ui.checks;

import com.intellij.struts.ui.edit.ListSourceComboModel;
import com.intellij.struts.ui.edit.PopupMenuAdapter;
import com.intellij.struts.util.CompareUtil;
import com.intellij.struts.util.ListSource;
import com.intellij.ui.DocumentAdapter;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.PopupMenuEvent;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 02.12.2005
 * Time: 16:02:40
 * To change this template use File | Settings | File Templates.
 */
public class CheckComboBox extends JComboBox implements Checker {

  private final ArrayList boxes;
  private final Renderer renderer = new Renderer();

  public CheckComboBox(ListSource source) {
    this();
    super.setModel(new CheckComboModel(source));
  }

  public CheckComboBox() {

    super();
//        this.setEditable(true);
    boxes = new ArrayList();
/*
        for (int i = 0; i < this.getItemCount(); i++) {
            JCheckBox box = new JCheckBox();
            boxes.add(box);
        }
*/
//        final CheckBoxRenderer renderer = new CheckBoxRenderer(this);
    this.setRenderer(renderer);

    //       Object ui = this.getUI();
    //       this.getUI().setPopupVisible(this, false);
    addActionListener(this);

    this.setPrototypeDisplayValue(renderer);

    this.setEditor(new Editor(this.getEditor()));
    this.setEditable(true);
    this.addPopupMenuListener(new PopupMenuAdapter() {

      public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
        ((ListSourceComboModel)getModel()).update(null);
      }
    });
//        BasicComboBoxEditor
//        setBorder(new EmptyBorder(0,0,0,0));
  }

  public void updateUI() {
    super.updateUI();    //To change body of overridden methods use File | Settings | File Templates.
    ((JComponent)editor.getEditorComponent()).updateUI();
  }

  public String getValue() {
    return renderer.getText();
  }

  public void setValue(String value) {
    renderer.setText(value);
    getEditor().setItem(value);
  }

  public void addValue(String value) {
    String current = getValue();
    if (current == null || current.length() == 0) {
      setValue(value);
    }
    else {
      setValue(current + "," + value);
    }
  }

  public void actionPerformed(ActionEvent e) {
    int index = this.getSelectedIndex();
    if (index == -1) {
      return;
    }
    JCheckBox box = (JCheckBox)boxes.get(index);
    box.setSelected(!box.isSelected());
    String val = null;
    for (int i = 0; i < boxes.size(); i++) {
      box = (JCheckBox)boxes.get(i);
      if (box.isSelected()) {
        if (val == null) {
          val = box.getText();
        }
        else {
          val = val + "," + box.getText();
        }
      }
    }
    renderer.setText(val);
//        this.getEditor().
    setSelectedIndex(-1);
  }

  public void setPopupVisible(boolean flag) {
// Not code her prevents the populist from closing
  }

  public Object getValue(int i) {
    return getModel().getElementAt(i);
  }

  public String getCaption(Object o) {
    return o == null ? null : o.toString();
  }

  protected class Renderer extends DefaultListCellRenderer {

//        private boolean first = true;

    Renderer() {
      super();
      this.setMinimumSize(new Dimension(10, 10));
    }

    /**
     * Return a component that has been configured to display the specified
     * value. That component's <code>paint</code> method is then called to
     * "render" the cell.  If it is necessary to compute the dimensions
     * of a list because the list cells do not have a fixed size, this method
     * is called to generate a component on which <code>getPreferredSize</code>
     * can be invoked.
     *
     * @param list         The JList we're painting.
     * @param value        The value returned by list.getModel().getElementAt(index).
     * @param index        The cells index.
     * @param isSelected   True if the specified cell was selected.
     * @param cellHasFocus True if the specified cell has the focus.
     * @return A component whose paint() method will render the specified value.
     * @see javax.swing.JList
     * @see javax.swing.ListSelectionModel
     * @see javax.swing.ListModel
     */
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
      if (value == this) {
        return new DefaultListCellRenderer().getListCellRendererComponent(list, "hi", index, isSelected, cellHasFocus);
      }
      if (index == -1) {
/*
                setEnabled(list.isEnabled());
                setFont(list.getFont());
                setBorder((cellHasFocus) ? UIManager.getBorder("List.focusCellHighlightBorder") : noFocusBorder);
*/
        return this; //super
      }
      String text = value.toString();
      JCheckBox box;
      if (index >= boxes.size()) {
        box = new JCheckBox(value.toString());
        boxes.add(index, box);
      }
      else {
        box = (JCheckBox)boxes.get(index);
      }
      String val = getValue();
      if (val != null && text != null) {
        String[] vals = val.split(",");
        boolean found = false;
        for (int i = 0; i < vals.length; i++) {
          if (text.equals(vals[i].trim())) {
            found = true;
            break;
          }
        }
        if (CompareUtil.compare(found, box.isSelected()) != 0) {
          box.setSelected(found);
        }
      }
      // check if selected
      box.setText(text);
      return box;
    }
  }

  protected class Editor implements ComboBoxEditor {

    private final ComboBoxEditor inner;

    Editor(ComboBoxEditor inner) {
      this.inner = inner;
      Font font = CheckComboBox.this.getFont();
      final JTextField editor = (JTextField)inner.getEditorComponent();
      editor.setFont(font);
      editor.getDocument().addDocumentListener(new DocumentAdapter() {

        protected void textChanged(DocumentEvent e) {
          renderer.setText(editor.getText());
/*
                    if (boxes.size() > 0 )
                    ((JCheckBox)boxes.get(1)).setSelected(true);
*/
//                    CheckComboBox.this.invalidate();
//                    setSelectedIndex(-1);
//                    CheckComboBox.this.paintChildren();
          ((CheckComboModel)getModel()).fire();
        }
      });
    }

    public void selectAll() {
      inner.selectAll();
    }

    public Component getEditorComponent() {
      return inner.getEditorComponent();
    }

    public void addActionListener(ActionListener l) {
      inner.addActionListener(l);
    }

    public void removeActionListener(ActionListener l) {
      inner.removeActionListener(l);
    }

    public Object getItem() {
      return inner.getItem();
    }

    public void setItem(Object anObject) {
      String text = renderer.getText();
      ((JTextField)inner.getEditorComponent()).setText(text == null ? "" : text);
    }
  }
}
