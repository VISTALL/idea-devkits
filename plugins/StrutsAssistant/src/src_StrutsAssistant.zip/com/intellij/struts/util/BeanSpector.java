/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.util;


import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Date: 28.10.2004 Time: 15:46:22
 *
 * @author Dmitry Avdeev
 */
public class BeanSpector {

  public static final Object[] EMPTY_ARGS = new Object[0];

  protected static Map beanSpectors = new HashMap();

  public static BeanSpector getBeanSpector(Class clazz) {
    BeanSpector inspector = (BeanSpector)beanSpectors.get(clazz);
    if (inspector == null) {
      inspector = new BeanSpector(clazz);
      beanSpectors.put(clazz, inspector);
    }
    return inspector;
  }

  protected Map properties;

  public BeanSpector(Class bean) {
    properties = new HashMap();
    Method[] methods = bean.getMethods();
    for (int i = 0; i < methods.length; i++) {
      Method method = methods[i];
      int params = method.getParameterTypes().length;
      if (params > 1 || method.getName().equals("getClass")) {
        continue;
      }
      if (params == 1 && method.getName().startsWith("set")) {
        String name = getPropertyName(method.getName(), 3);
        Property property = createProperty(name);
        property.setter = method;
      }
      else if (params == 0 && method.getName().startsWith("get")) {
        String name = getPropertyName(method.getName(), 3);
        Property property = createProperty(name);
        property.getter = method;
      }
      else if (params == 0 && method.getName().startsWith("is")) {
        String name = getPropertyName(method.getName(), 2);
        Property property = createProperty(name);
        property.getter = method;
      }
    }
  }

  public Map getProperties() {
    return properties;
  }

  public Property getProperty(String name) {
    return (Property)properties.get(name);
  }

  protected Property createProperty(String name) {
    Property property = getProperty(name);
    if (property == null) {
      property = new Property(name);
      properties.put(name, property);
    }
    return property;
  }

  /**
   * @param propertyName
   * @return null if no property setter found
   */
  public Method getSetter(String propertyName) {
    Property property = getProperty(propertyName);
    return property == null ? null : property.setter;
  }

  public static String getPropertyName(String methodName, int prefixLength) {
    char[] chars = methodName.toCharArray();
    chars[prefixLength] = Character.toLowerCase(chars[prefixLength]);
    return new String(chars, prefixLength, chars.length - prefixLength);
  }

  public static Class getWrapper(Class clazz) {

    if (!clazz.isPrimitive()) {
      return clazz;
    }
    else if (clazz.equals(boolean.class)) {
      return Boolean.class;
    }
    else if (clazz.equals(int.class)) {
      return Integer.class;
    }
    else if (clazz.equals(long.class)) {
      return Long.class;
    }
    else if (clazz.equals(double.class)) {
      return Double.class;
    }
    else if (clazz.equals(float.class)) {
      return Float.class;
    }
    else {
      throw new IllegalArgumentException("Unknown class: " + clazz);
    }
  }

  /**
   * @param name e.g. "package.Class"
   * @return short class name e.g. "Class"
   */
  public static String getClassName(String name) {

    int pos = name.lastIndexOf('.');
    if (pos == -1) {
      return name;
    }
    else {
      return name.substring(pos + 1);
    }
  }

  public static String getPackage(String name) {

    int pos = name.lastIndexOf('.');
    if (pos == -1) {
      return null;
    }
    else {
      return name.substring(0, pos);
    }
  }

  public static String getClassName(Class clazz) {

    return getClassName(clazz.getName());
  }

  public static Object createFromString(Class clazz, String value)
    throws IllegalAccessException, InvocationTargetException, InstantiationException, NoSuchMethodException {

    clazz = getWrapper(clazz);
    Constructor ctor = clazz.getConstructor(new Class[]{String.class});
    return ctor.newInstance(new Object[]{value});
  }

  public static void set(Object bean, Method setter, String value)
    throws IllegalAccessException, InvocationTargetException, NoSuchMethodException, InstantiationException {

    Class clazz = setter.getParameterTypes()[0];
    Object o = BeanSpector.createFromString(clazz, value);
    setter.invoke(bean, new Object[]{o});
  }

  public static Object evaluate(String constant) throws ClassNotFoundException, NoSuchFieldException, IllegalAccessException {
    int pos = constant.lastIndexOf('.');
    String className = constant.substring(0, pos);
    Class clazz = Class.forName(className);
    String fieldName = constant.substring(pos + 1);
    return clazz.getField(fieldName).get(null);
  }

  public static Object getField(Object o, String fieldName) {

    try {
      Class clazz = o.getClass();
      Field field = clazz.getDeclaredField(fieldName);
      field.setAccessible(true);
      return field.get(o);
    }
    catch (Exception e) {
      return null;
    }
  }

  /**
   * public void populate(Object bean, Map attributes)
   * throws IllegalAccessException, InvocationTargetException {
   * <p/>
   * for (Iterator i = 0; i < attributes.getLength(); i++) {
   * Method setter = getSetter(attributes.getLocalName(i));
   * if (setter != null) {
   * setter.invoke(bean, new Object[] { attributes.getValue(i)});
   * }
   * }
   * }
   */


  public static class Property {

    private final String name;
    private Method setter;
    private Method getter;

    public Property(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }

    public Method getSetter() {
      return setter;
    }

    public Method getGetter() {
      return getter;
    }

    public Object get(Object bean) throws IllegalAccessException, InvocationTargetException {
      return getter.invoke(bean, EMPTY_ARGS);
    }
  }
}
