/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.util;

import org.apache.log4j.Logger;
import org.jetbrains.annotations.NonNls;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 28.09.2005
 * Time: 16:13:40
 * To change this template use File | Settings | File Templates.
 */
public class FormatUtil {

  protected static final Logger logger = Logger.getLogger(FormatUtil.class);

  private FormatUtil() {
  }

  public static boolean isEmpty(String s) {
    return s == null || s.length() == 0;
  }

  /**
   * http://jakarta.apache.org/commons/dtds/validator_1_1_3.dtd -> 1_1_3
   * http://jakarta.apache.org/commons/dtds/validator_1_0.dtd -> 1_0
   *
   * @param uri e.g. http://jakarta.apache.org/commons/dtds/validator_1_1_3.dtd
   * @return extracted version
   */
  public static String getVersion(String uri) {
    int pos = uri.indexOf('_');
    int dtdPos = uri.lastIndexOf('.');
    if (pos == -1 || dtdPos == -1 || dtdPos <= pos) {
      return null;
    }
    return uri.substring(pos + 1, dtdPos);

  }

  public static String replace(String source, char from, char to) {

    StringBuffer buf = new StringBuffer(source);

    for (int i = 0; i < buf.length(); i++) {
      if (buf.charAt(i) == from) {
        buf.setCharAt(i, to);
      }
    }
    return buf.toString();
  }

  /**
   * @param uri
   * @return nevwr null
   */
  public static String getUriName(String uri) {

    int pos = uri.lastIndexOf('/');
    if (pos != -1) {
      uri = uri.substring(pos + 1);
    }
    int dotPos = uri.indexOf('.');
    if (dotPos != -1) {
      uri = uri.substring(0, dotPos);
    }
    return uri;
  }

  public static String replaceExtension(String file, @NonNls String ext) {
    int pos = file.lastIndexOf('.');
    if (pos == -1) {
      return file + "." + ext;
    }
    else {
      return file.substring(0, pos) + "." + ext;
    }
  }

}
