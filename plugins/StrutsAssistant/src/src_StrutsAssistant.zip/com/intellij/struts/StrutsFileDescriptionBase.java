/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts;

import com.intellij.javaee.JavaeeDeploymentDescriptor;
import com.intellij.javaee.model.xml.web.WebApp;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.javaee.web.WebUtil;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.psi.PsiFile;
import com.intellij.psi.xml.XmlFile;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.DomFileElement;
import com.intellij.util.xml.MergingFileDescription;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.Set;

/**
 * @author Dmitry Avdeev
 */
abstract class StrutsFileDescriptionBase<T extends DomElement> extends MergingFileDescription<T> {

  protected StrutsFileDescriptionBase(final Class<T> rootElementClass, @NonNls final String rootTagName) {
    super(rootElementClass, rootTagName);
  }

  protected void initializeFileDescription() {}

  @NotNull
  public Set<Class<? extends DomElement>> getDomModelDependencyItems() {
    return convertToSet(WebApp.class);
  }

  @NotNull
  public Set<XmlFile> getDomModelDependentFiles(@NotNull final DomFileElement changedRoot) {
    return getFilesToMerge(changedRoot);
  }

  @NotNull
  public Set<? extends Object> getDependencyItems(final XmlFile file) {
    final WebModuleProperties properties = WebUtil.getWebModuleProperties(file);
    if (properties != null) {
      final JavaeeDeploymentDescriptor deploymentDescriptor = properties.getWebModuleProperties().getMainDeploymentDescriptor();
      if (deploymentDescriptor != null) {
        final PsiFile psiFile = deploymentDescriptor.getPsiFile();
        if (psiFile != null) {
          return Collections.singleton(psiFile);
        }
      }
    }
    return super.getDependencyItems(file);
  }
}

abstract class StrutsPluginDescriptor<T extends DomElement> extends StrutsFileDescriptionBase<T> {

  protected StrutsPluginDescriptor(final Class<T> rootElementClass, final String rootTagName) {
    super(rootElementClass, rootTagName);
  }

  @NotNull
  public Set<? extends Object> getDependencyItems(final XmlFile file) {
    final Module module = ModuleUtil.findModuleForPsiElement(file);
    if (module != null) {
      return StrutsProjectComponent.getInstance(module.getProject()).myStrutsFactory.getAllConfigFiles(module);
    }
    return super.getDependencyItems(file);
  }
}
