/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts;

import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.compiler.CompilerManager;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.options.Configurable;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ModuleRootEvent;
import com.intellij.openapi.roots.ModuleRootListener;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.startup.StartupManager;
import com.intellij.openapi.util.*;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.openapi.wm.ToolWindowAnchor;
import com.intellij.openapi.wm.ToolWindowManager;
import com.intellij.psi.PsiManager;
import com.intellij.psi.PsiElement;
import com.intellij.psi.impl.source.jsp.JspManager;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.xml.XmlFile;
import com.intellij.struts.config.StrutsConfigPane;
import com.intellij.struts.config.StrutsConfiguration;
import com.intellij.struts.config.StrutsProjectSettings;
import com.intellij.struts.core.JDOMClassExternalizer;
import com.intellij.struts.dom.StrutsConfig;
import com.intellij.struts.dom.StrutsWebPathConverter;
import com.intellij.struts.dom.StrutsWebPathConverterImpl;
import com.intellij.struts.dom.tiles.TilesDefinitions;
import com.intellij.struts.dom.validator.FormValidation;
import com.intellij.struts.highlighting.StrutsValidator;
import com.intellij.struts.highlighting.TilesValidator;
import com.intellij.struts.highlighting.ValidationValidator;
import com.intellij.struts.psi.ValidationModelImpl;
import com.intellij.struts.inplace.reference.StrutsReferenceProvider;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.DomFileDescription;
import com.intellij.util.xml.DomManager;
import com.intellij.util.xml.ModelMerger;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Set;

/**
 * Represents an IDEA project with Struts support
 *
 * @author Dmitry Avdeev
 */
public class StrutsProjectComponent implements ProjectComponent, JDOMExternalizable, Configurable {

  @NonNls private static final String VALIDATOR_PLUGIN_CLASS = "org.apache.struts.validator.ValidatorPlugIn";
  @NonNls private static final String PATHNAMES_PROPERTY = "pathnames";


  private StrutsConfigPane myConfigPane;
  protected final Project myProject;
  private final CompilerManager myCompilerManager;

  private StrutsView myStrutsView;
  protected ToolWindow myToolWindow;

  private final StrutsProjectSettings mySettings = new StrutsProjectSettings();

  private boolean myStrutsEnabled;
  private final StrutsValidator myStrutsValidator;
  private final TilesValidator myTilesValidator;
  private final ValidationValidator myValidationValidator;

  @Nullable
  public StrutsView getStrutsView() {
    return myStrutsView;
  }


  @NotNull
  public static StrutsProjectComponent getInstance(@NotNull Project project) {
    return project.getComponent(StrutsProjectComponent.class);
  }

  public final DomFileDescription myStrutsFileDescription;
  public final DomFileDescription myTilesFileDescription;
  public final DomFileDescription myValidatorFileDescription;

  public final ModelMerger myModelMerger;


  public final StrutsDomFactory myStrutsFactory;
  public final StrutsPluginDomFactory<TilesDefinitions, TilesModel> myTilesFactory;
  public final StrutsPluginDomFactory<FormValidation, ValidationModel> myValidatorFactory;

  /**
   * Called by IDEA framework
   *
   * @param project IDEA project
   */
  public StrutsProjectComponent(Project project, final DomManager domManager, CompilerManager compilerManager) {
    myProject = project;
    myCompilerManager = compilerManager;
    myModelMerger = domManager.createModelMerger();

    myStrutsFileDescription = new StrutsFileDescriptionBase<StrutsConfig>(StrutsConfig.class, "struts-config") {
      @NotNull
      protected Set<XmlFile> getFilesToMerge(DomElement element) {
        return StrutsManager.getInstance().getStrutsConfigFiles(element.getXmlElement());
      }
    };
    myTilesFileDescription = new StrutsPluginDescriptor<TilesDefinitions>(TilesDefinitions.class, TilesDefinitions.TILES_DEFINITIONS) {
      @NotNull
      protected Set<XmlFile> getFilesToMerge(DomElement element) {
        return myTilesFactory.getConfigFiles(element.getXmlElement());
      }
    };
    myValidatorFileDescription = new StrutsPluginDescriptor<FormValidation>(FormValidation.class, FormValidation.FORM_VALIDATION) {
      @NotNull
      protected Set<XmlFile> getFilesToMerge(DomElement element) {
        return myValidatorFactory.getConfigFiles(element.getXmlElement());
      }
    };

    myStrutsFactory = new StrutsDomFactory(myModelMerger, project);

    myTilesFactory = new TilesDomFactory(myStrutsFactory, project);

    myValidatorFactory = new StrutsPluginDomFactory<FormValidation, ValidationModel>(FormValidation.class,
                                                                                   VALIDATOR_PLUGIN_CLASS,
                                                                                   PATHNAMES_PROPERTY,
                                                                                   myStrutsFactory,
                                                                                   project,
                                                                                   "Validator") {

      protected ValidationModel createModel(final Set<XmlFile> configFiles, final FormValidation mergedModel, final StrutsModel strutsModel) {
        return new ValidationModelImpl(configFiles, mergedModel, strutsModel);
      }

      protected PsiElement resolveFile(final String path, final JspManager jspManager, final WebModuleProperties props) {
        if (path.equals(StrutsReferenceProvider.VALIDATOR_RULES_XML)) {
          return StrutsReferenceProvider.resolveJarFile(myProject);
        }
        return super.resolveFile(path, jspManager, props);
      }

      protected Object[] computeDependencies(@Nullable final ValidationModel model,
                                             @Nullable WebModuleProperties moduleProperties,
                                             @NotNull final Project project) {
        StrutsModel strutsModel;
        if (model == null) {
          strutsModel = moduleProperties == null ? null : StrutsManager.getInstance().getCombinedStrutsModel(moduleProperties.getModule());
        }
        else {
          strutsModel = model.getStrutsModel();
        }
        return computeDepenedencies(strutsModel, moduleProperties, project);
      }

      protected ValidationModel createCombinedModel(final Set<XmlFile> configFiles,
                                                    final FormValidation mergedModel,
                                                    final ValidationModel firstModel) {
        return new ValidationModelImpl(configFiles, mergedModel, firstModel.getStrutsModel());
      }
    };

    domManager.registerFileDescription(myStrutsFileDescription);
    domManager.registerFileDescription(myTilesFileDescription);
    domManager.registerFileDescription(myValidatorFileDescription);

    domManager.getConverterManager().registerConverterImplementation(StrutsWebPathConverter.class, new StrutsWebPathConverterImpl());

    myTilesValidator = new TilesValidator(myProject, myTilesFactory);
    myValidationValidator = new ValidationValidator(myProject, myValidatorFactory);
    myStrutsValidator = new StrutsValidator(myProject, myStrutsFactory);
  }

  static Object[] computeDepenedencies(@Nullable StrutsModel strutsModel,
                                               @Nullable WebModuleProperties moduleProperties,
                                               @NotNull final Project project) {
    moduleProperties = strutsModel == null ? moduleProperties : strutsModel.getWebModuleProperties();
    final ProjectRootManager manager = ProjectRootManager.getInstance(project);
    if (strutsModel != null) {
      final ArrayList<Object> dependencies = new ArrayList<Object>(strutsModel.getConfigFiles());
      dependencies.add(moduleProperties);
      dependencies.add(manager);
      return dependencies.toArray(new Object[dependencies.size()]);
    } else {
      return new Object[] { moduleProperties, manager };
    }
  }


  /**
   * Registers a tool window, which should be defined at Project level
   */
  public void projectOpened() {


    ProjectRootManager.getInstance(myProject).addModuleRootListener(myModuleRootListener, myProject);

    StartupManager.getInstance(myProject).runWhenProjectIsInitialized(new Runnable() {

      public void run() {
        myModuleRootListener.rootsChanged(null);
      }
    });


  }

  /**
   * Unregisters tool window
   */
  public void projectClosed() {
  }

  @NotNull
  public String getComponentName() {
    return StrutsConstants.PLUGIN_NAME;
  }

  public void initComponent() {
    myCompilerManager.addCompiler(myStrutsValidator);
    myCompilerManager.addCompiler(myTilesValidator);
    myCompilerManager.addCompiler(myValidationValidator);
  }

  public void disposeComponent() {
    myCompilerManager.removeCompiler(myStrutsValidator);
    myCompilerManager.removeCompiler(myTilesValidator);
    myCompilerManager.removeCompiler(myValidationValidator);
  }

  public void readExternal(Element element) throws InvalidDataException {
    JDOMClassExternalizer.readExternal(mySettings, element);
    if (mySettings.resources.strutsPath == null) {
      mySettings.resources.strutsPath = StrutsConfiguration.getInstance().resources.strutsPath;
    }
  }

  public void writeExternal(Element element) throws WriteExternalException {
    JDOMClassExternalizer.writeExternal(mySettings, element);
  }

  public String getDisplayName() {
    return StrutsConstants.PLUGIN_NAME;
  }

  public Icon getIcon() {
    return IconLoader.getIcon("/com/intellij/struts/icons/settings.png");
  }

  public String getHelpTopic() {
    return "project.struts";
  }

  public JComponent createComponent() {
    if (myConfigPane == null) {
      myConfigPane = new StrutsConfigPane(mySettings);
    }

     return myConfigPane.createComponent();
  }

  public boolean isModified() {
    return myConfigPane.isModified();
  }

  /**
   * Store the settings from configurable to other components.
   */
  public void apply() throws ConfigurationException {
    myConfigPane.apply();
  }

  /**
   * Load settings from other components to configurable.
   */
  public void reset() {
    myConfigPane.reset();
  }

  public void disposeUIResources() {
  }

  private final ModuleRootListener myModuleRootListener = new ModuleRootListener() {

    public void beforeRootsChange(ModuleRootEvent event) {

    }

    public void rootsChanged(ModuleRootEvent event) {
      ApplicationManager.getApplication().invokeLater(new Runnable() {

        public void run() {
          if (myProject.isDisposed()) {
            return;
          }
          StartupManager.getInstance(myProject).runPostStartup(new Runnable() {

            public void run() {
              final PsiManager psiManager = PsiManager.getInstance(myProject);
              if (!psiManager.isDisposed()) {
                if (psiManager.findClass("org.apache.struts.action.Action", GlobalSearchScope.allScope(myProject)) == null) {
                  if (myToolWindow != null) {
                    myToolWindow.hide(null);
                    myToolWindow.setAvailable(false, null);
                  }
                  myStrutsEnabled = false;
                }
                else {

                  if (myStrutsView == null) {
                    ToolWindowManager toolWindowManager = ToolWindowManager.getInstance(myProject);

                    myStrutsView = new StrutsView(myProject, myStrutsFileDescription, myTilesFileDescription, myValidatorFileDescription);
                    Disposer.register(myProject, myStrutsView);
                    myToolWindow = toolWindowManager.registerToolWindow(StrutsConstants.TOOL_WINDOW_ID,
                                                                        myStrutsView.getComponent(),
                                                                        ToolWindowAnchor.LEFT,
                                                                  myProject);

                    myToolWindow.setIcon(StrutsConstants.ICON_STRUTS_SMALL);
                  }

                  myToolWindow.setAvailable(true, null);
                  myStrutsView.openDefault();
                  myStrutsEnabled = true;
                }
              }
            }
          });
        }
      });
    }
  };

  public boolean isStrutsEnabled() {
    return myStrutsEnabled;
  }

  public StrutsProjectSettings getSettings() {
    return mySettings;
  }

}
