/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts;

import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.impl.source.jsp.JspManager;
import com.intellij.psi.util.InheritanceUtil;
import com.intellij.psi.xml.XmlFile;
import com.intellij.struts.dom.PlugIn;
import com.intellij.struts.dom.SetProperty;
import com.intellij.util.xml.DomElement;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * @author Dmitry Avdeev
 */
public abstract class StrutsPluginDomFactory<T extends DomElement, M extends DomModel<T>> extends WebDomFactory<T, M> {

  private final String mySuperClass;
  private final String myConfigProperty;
  protected final StrutsDomFactory myStrutsFactory;

  public StrutsPluginDomFactory(@NotNull Class<T> aClass,
                                @NotNull String superClass,
                                @NotNull String configProperty,
                                @NotNull StrutsDomFactory strutsFactory,
                                Project project,
                                @NonNls String name) {

    super(aClass, strutsFactory.getModelMerger(), project, name);
    myStrutsFactory = strutsFactory;
    mySuperClass = superClass;
    myConfigProperty = configProperty;
  }

  @Nullable
  public PlugIn getPlugin(@NotNull StrutsModel struts) {
    PsiClass superClass = null;
    for (PlugIn plugin : struts.getMergedModel().getPlugIns()) {
      PsiClass pluginClass = plugin.getClassName().getValue();
      if (pluginClass != null) {
        if (superClass == null) {
          superClass = pluginClass.getManager().findClass(mySuperClass, pluginClass.getResolveScope());
          if (superClass == null) {
            return null;
          }
        }
        if (InheritanceUtil.isInheritorOrSelf(pluginClass, superClass, true)) {
          return plugin;
        }
      }
    }
    return null;
  }

  @Nullable
  public M getModel(@NotNull final PsiElement psiElement) {
    final PsiFile psiFile = psiElement.getContainingFile();
    if (psiFile instanceof XmlFile) {
      return getModelByConfigFile((XmlFile)psiFile);
    }
    return null;
  }

  @Nullable
  public List<M> computeModels(WebModuleProperties moduleProperties) {

    if (moduleProperties == null) {
      return null;
    }
    Module module = moduleProperties.getModule();
    final List<StrutsModel> strutsModels = myStrutsFactory.getAllModels(module);
    if (strutsModels.size() == 0) {
      return Collections.emptyList();
    }

    final ArrayList<M> list = new ArrayList<M>(strutsModels.size());

    for (StrutsModel strutsModel: strutsModels) {
      final M model = getModel(strutsModel);
      if (model != null) {
        list.add(model);
      }
    }
    return list;
  }

  @Nullable
  public M getModel(@NotNull StrutsModel strutsModel) {
    PlugIn plugin = getPlugin(strutsModel);
    if (plugin != null) {
      Set<XmlFile> configFiles = new LinkedHashSet<XmlFile>();
      WebModuleProperties props = strutsModel.getWebModuleProperties();
      final JspManager jspManager = JspManager.getInstance(props.getModule().getProject());
      for (SetProperty prop : plugin.getSetProperties()) {
        String name = prop.getProperty().getValue();
        if (name != null && name.equals(myConfigProperty)) {
          String configString = prop.getValue().getValue();
          if (configString != null) {
            String[] configPaths = configString.split(",");
            for (String configPath : configPaths) {
              PsiElement el = resolveFile(configPath, jspManager, props);
              if (el instanceof XmlFile) {
                configFiles.add((XmlFile)el);
              }
            }
          }
        }
      }
      final T mergedModel = createMergedModel(configFiles);
      return createModel(configFiles, mergedModel, strutsModel);
    }
    return null;
  }

  protected abstract M createModel(Set<XmlFile> configFiles, T mergedModel, StrutsModel strutsModel);

  @Nullable
  protected PsiElement resolveFile(String path, JspManager jspManager, WebModuleProperties props) {
    return jspManager.findFileByPath(path.trim(), props);
  }
}
