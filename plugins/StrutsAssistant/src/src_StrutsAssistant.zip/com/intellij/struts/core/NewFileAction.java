/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.core;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ContentEntry;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.roots.SourceFolder;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.struts.api.SourceDir;
import org.apache.log4j.Logger;

import java.util.ArrayList;

/**
 * Date: 12.09.2005 Time: 12:50:17
 *
 * @author Dmitry Avdeev
 */
public abstract class NewFileAction extends AnAction {

  private static final Logger logger = Logger.getLogger(NewFileAction.class);

  protected ArrayList dirs;
  private final boolean addModuleRoots;

  protected NewFileAction(boolean addModuleRoots) {

    this.addModuleRoots = addModuleRoots;
  }

  public void update(AnActionEvent event) {


    Presentation presentation = event.getPresentation();
    try {
      Project project = (Project)event.getDataContext().getData(DataConstants.PROJECT);

      dirs = new ArrayList();
      VirtualFile[] files = (VirtualFile[])event.getDataContext().getData(DataConstants.VIRTUAL_FILE_ARRAY);
      Module module = (Module)event.getDataContext().getData(DataConstants.MODULE);
      if (IdeaUtils.isModuleNode(event)) {
        // maybe a Module node?
        if (addModuleRoots && module != null) {
          // set files to module root dirs
          if (com.intellij.struts.util.Constants.LOG_DEBUG) {
            logger.debug("Module: " + module + "; allowing new class actions for root dirs...");
          }
          ContentEntry[] entries = ModuleRootManager.getInstance(module).getContentEntries();
          for (int i = 0; i < entries.length; i++) {
            SourceFolder[] folders = entries[i].getSourceFolders();
            for (int j = 0; j < folders.length; j++) {
              VirtualFile vf = folders[j].getFile();
              if (vf == null) {
                continue;
              }
              dirs.add(new SourceDir(vf, folders[j].isTestSource() ? SourceDir.TEST : SourceDir.SOURCE));
            }
          }
        }
      }
      else if (files != null) {
        for (int i = 0; i < files.length; i++) {
          VirtualFile vf = files[i];
          if (!vf.isDirectory()) {
            vf = vf.getParent();
          }
/*
                    Module m = (Module)PathManager.getInstance(project).getModule(file);
                    int type = PathManager.getInstance(project).isTestDir(file, m);
                    if (checkDir(file, project, m, type)) {
                        dirs.add(new SourceDir(file, type));
                    }
*/
        }
      }

      if (check(event)) {
        presentation.setEnabled(true);
        presentation.setVisible(true);
        return;
      }
    }
    catch (Exception e) {
      logger.error("Error when updating the action", e);
    }
    presentation.setEnabled(false);
    presentation.setVisible(false);
  }

  protected boolean check(AnActionEvent event) {
    return dirs.size() > 0;
  }

  protected boolean checkDir(VirtualFile file, Project project, Module module, int type) {
    return true;
  }
}
