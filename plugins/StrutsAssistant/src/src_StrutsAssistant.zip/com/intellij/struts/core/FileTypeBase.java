/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.core;

import com.intellij.ide.structureView.StructureViewBuilder;
import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.fileTypes.SyntaxHighlighter;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

/**
 * Date: 29.10.2004 Time: 17:30:24
 *
 * @author Dmitry Avdeev
 */
public class FileTypeBase implements FileType {

  private final String name;
  private final String description;
  private final String defaultExtension;
  private final Icon icon;

  public FileTypeBase(String name, String description, String defaultExtension, Icon icon) {

    this.name = name;
    this.description = description;
    this.defaultExtension = defaultExtension;
    this.icon = icon;
  }

  public String getName() {
    return name;
  }

  public String getDescription() {
    return description;
  }

  public String[] getAssociatedExtensions() {
    return new String[]{defaultExtension};
  }

  public String getDefaultExtension() {
    return defaultExtension;
  }

  public Icon getIcon(VirtualFile file) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Icon getIcon() {
    return icon;
  }

  public boolean isBinary() {
    return false;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public boolean isReadOnly() {
    return false;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public String getCharset(VirtualFile file) {
    return "UTF-8";
  }

  @Nullable
  public SyntaxHighlighter getHighlighter(@Nullable Project project, VirtualFile virtualFile) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  @Nullable
  public StructureViewBuilder getStructureViewBuilder(@NotNull VirtualFile virtualFile, @NotNull Project project) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

}
