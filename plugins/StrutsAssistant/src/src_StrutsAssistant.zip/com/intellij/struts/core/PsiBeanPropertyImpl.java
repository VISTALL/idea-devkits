/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.core;

import com.intellij.openapi.util.IconLoader;
import com.intellij.psi.*;
import com.intellij.psi.util.PropertyUtil;
import com.intellij.psi.xml.XmlTag;
import com.intellij.struts.dom.FormProperty;
import com.intellij.struts.util.BeanSpector;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 10.11.2005
 * Time: 15:08:37
 * To change this template use File | Settings | File Templates.
 */
public class PsiBeanPropertyImpl implements PsiBeanProperty, Comparable<PsiBeanProperty> {

  private final static Icon PROPERTY_READ = IconLoader.getIcon("/com/intellij/struts/icons/propertyRead.png");
  private final static Icon PROPERTY_READ_STATIC = IconLoader.getIcon("/com/intellij/struts/icons/propertyReadStatic.png");
  private final static Icon PROPERTY_READ_WRITE = IconLoader.getIcon("/com/intellij/struts/icons/propertyReadWrite.png");
  private final static Icon PROPERTY_READ_WRITE_STATIC = IconLoader.getIcon("/com/intellij/struts/icons/propertyReadWriteStatic.png");
  private final static Icon PROPERTY_WRITE = IconLoader.getIcon("/com/intellij/struts/icons/propertyWrite.png");
  private final static Icon PROPERTY_WRITE_STATIC = IconLoader.getIcon("/com/intellij/struts/icons/propertyWriteStatic.png");

  private final PsiElement[] myPsiElements;
  private final String myName;
  private String myType;
  private Icon myIcon;

  private boolean myHasSetter;
  private boolean myHasGetter;

  private PsiMethod myGetter;

  public PsiBeanPropertyImpl(@NonNls String name, @NonNls String type) {
    myPsiElements = null;
    myName = name;
    myType = type;
    myIcon = PROPERTY_READ_WRITE;
    myHasSetter = true;
    myHasGetter = true;
  }

  @Nullable
  public static PsiBeanProperty create(FormProperty tag) {
    String name = tag.getName().getValue();
    return name == null ? null : new PsiBeanPropertyImpl(tag);
  }

  private PsiBeanPropertyImpl(FormProperty tag) {
    myName = tag.getName().getValue();
    PsiType type = tag.getType().getValue();
    if (type != null) {
      myType = type.getCanonicalText();
    }
    else {
      myType = null;
    }
    XmlTag xmlTag = tag.getName().getXmlTag();
    myPsiElements = xmlTag == null ? null : new PsiElement[]{xmlTag};
    myIcon = PROPERTY_READ_WRITE;
    myHasSetter = true;
    myHasGetter = true;
  }

  public PsiBeanPropertyImpl(PsiClass clazz, String name, PsiField field) {
    myName = name;
    myGetter = PropertyUtil.findPropertyGetter(clazz, name, false, true);
    PsiMethod setter = PropertyUtil.findPropertySetter(clazz, name, false, true);
    myIcon = null;
    if (myGetter != null || setter != null) {
      if (myGetter != null && setter != null) {
        myIcon = PROPERTY_READ_WRITE;
        myHasSetter = true;
        myHasGetter = true;
      }
      else if (myGetter != null) {
        myIcon = PROPERTY_READ;
        myHasGetter = true;
      }
      else {
        myIcon = PROPERTY_WRITE;
        myHasSetter = true;
      }
    }
    else {
      myGetter = PropertyUtil.findPropertyGetter(clazz, name, true, true);
      setter = PropertyUtil.findPropertySetter(clazz, name, true, true);
      if (myGetter != null && setter != null) {
        myIcon = PROPERTY_READ_WRITE_STATIC;
        myHasSetter = true;
        myHasGetter = true;
      }
      else if (myGetter != null) {
        myIcon = PROPERTY_READ_STATIC;
        myHasGetter = true;
      }
      else {
        myIcon = PROPERTY_WRITE_STATIC;
        myHasSetter = true;
      }
    }
    ArrayList<PsiElement> elements = new ArrayList<PsiElement>();
    if (field != null) {
      elements.add(field);
      myType = BeanSpector.getClassName(field.getType().getCanonicalText());
    }
    if (myGetter != null) {
      elements.add(myGetter);
      final PsiType returnType = myGetter.getReturnType();
      assert returnType != null;
      myType = BeanSpector.getClassName(returnType.getCanonicalText());
    }
    if (setter != null) {
      elements.add(setter);
      myType = BeanSpector.getClassName(setter.getParameterList().getParameters()[0].getType().getCanonicalText());
    }
    myPsiElements = elements.toArray(new PsiElement[elements.size()]);
  }


  public PsiElement[] getPsiElements() {
    return myPsiElements;
  }

  public Icon getIcon() {
    return myIcon;
  }

  public String getName() {
    return myName;
  }

  public String getType() {
    return myType;
  }

  public boolean hasGetter() {
    return myHasGetter;
  }

  public PsiMethod getGetter() {
    return myGetter;
  }

  public boolean hasSetter() {
    return myHasSetter;
  }

  public String toString() {
    return myName + " (" + myType + ")";
  }

  public int compareTo(final PsiBeanProperty o) {
    return myName.compareTo(o.getName());
  }
}
