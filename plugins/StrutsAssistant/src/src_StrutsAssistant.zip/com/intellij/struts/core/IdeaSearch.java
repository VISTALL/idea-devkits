/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.core;

import java.util.Comparator;


class NamesComparator implements Comparator {

  public int compare(Object obj, Object obj1) {
    if (obj == obj1) return 0;
    String s = (String)obj;
    String s1 = (String)obj1;
    int i = s.length();
    int j = s1.length();
    int k = Math.min(i, j);
    boolean flag = false;
    for (int l = 0; l < k; l++) {
      char c1 = s.charAt(l);
      char c3 = s1.charAt(l);
      if (c1 == c3) continue;
      flag = true;
      char c5 = Character.toLowerCase(c1);
      char c6 = Character.toLowerCase(c3);
      if (c5 != c6) return c5 - c6;
    }

    if (i != j) return i - j;
    if (flag) {
      for (int i1 = 0; i1 < k; i1++) {
        char c2 = s.charAt(i1);
        char c4 = s1.charAt(i1);
        if (c2 != c4) return c2 - c4;
      }

    }
    return 0;
  }
}
