/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.core;

import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiManager;
import com.intellij.psi.PsiPackage;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.struts.util.BeanSpector;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 06.02.2006
 * Time: 16:21:53
 * To change this template use File | Settings | File Templates.
 */
public class ClassManager {

  private final static Map instances = new HashMap();

  public static synchronized ClassManager getInstance(Object project) {
    ClassManager model = (ClassManager)instances.get(project);
    if (model == null) {
      model = new ClassManager(project);
      instances.put(project, model);
    }
    return model;
  }

  public static synchronized void remove(Object project) {
    instances.remove(project);
  }

  private final Object project;

  private final Map packages = new HashMap();

  private ClassManager(Object project) {

    this.project = project;
  }

  public String advisePackage(String baseClass) {
    String pack = (String)packages.get(baseClass);
    if (pack == null) {
      PsiManager manager = PsiManager.getInstance((Project)project);
      GlobalSearchScope scope = GlobalSearchScope.projectScope((Project)project);
      PsiClass clazz = manager.findClass(baseClass, scope);
      if (clazz == null) {
        return null;
      }
      PsiClass[] inheritors = manager.getSearchHelper().findInheritors(clazz, scope, true);
      if (inheritors.length == 0) {
        PsiPackage app = findAppPackage(scope, manager.findPackage(""));
        if (app != null) {
          pack = app.getQualifiedName();
        }
      }
      else {
        long maxStamp = -1;
        PsiClass last = null;
        for (int i = 0; i < inheritors.length; i++) {
          long stamp = inheritors[i].getContainingFile().getModificationStamp();
          if (stamp > maxStamp) {
            last = inheritors[i];
            maxStamp = stamp;
          }
        }
        if (last != null) {
          pack = BeanSpector.getPackage(last.getQualifiedName());
        }
      }
      if (pack != null) {
        packages.put(baseClass, pack);
      }
    }
    return pack;
  }

  public void setPackage(String baseClass, String pack) {
    packages.put(baseClass, pack);
  }

  public void gotoClass(String className) {
    PsiManager manager = PsiManager.getInstance((Project)project);
    PsiClass clazz = manager.findClass(className, GlobalSearchScope.allScope((Project)project));
    if (clazz != null) {
    }
  }

  private PsiPackage findAppPackage(GlobalSearchScope scope, PsiPackage pack) {
    if (pack.getClasses(scope).length > 0) {
      return pack;
    }
    PsiPackage[] sub = pack.getSubPackages(scope);
    if (sub.length == 0) {
      return null;
    }
    for (int i = 0; i < sub.length; i++) {
      PsiPackage result = findAppPackage(scope, sub[i]);
      if (result != null) {
        return result;
      }
    }
    return null;
  }
}
