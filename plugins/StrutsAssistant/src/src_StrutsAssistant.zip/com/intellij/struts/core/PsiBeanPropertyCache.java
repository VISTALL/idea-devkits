/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Created by IntelliJ IDEA.
 * User: DAvdeev
 * Date: 27.01.2006
 * Time: 10:54:42
 * To change this template use File | Settings | File Templates.
 */
package com.intellij.struts.core;

import com.intellij.openapi.components.AbstractProjectComponent;
import com.intellij.openapi.project.Project;
import com.intellij.psi.*;
import com.intellij.psi.util.PropertyUtil;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;

public class PsiBeanPropertyCache extends AbstractProjectComponent {

  public static synchronized PsiBeanPropertyCache getInstance(Project project) {
    return project.getComponent(PsiBeanPropertyCache.class);
  }

  private final HashMap<String, PsiClassInfo> cache = new HashMap<String, PsiClassInfo>();
  private final HashMap<String, SuperInfo> supersCache = new HashMap<String, SuperInfo>();

  protected PsiBeanPropertyCache(final Project project) {
    super(project);
  }

  @NotNull
  public PsiBeanProperty[] getBeanProperties(PsiClass clazz) {

    if (clazz == null) {
      return PsiBeanProperty.EMPTY_ARRAY;
    }
    String className = clazz.getQualifiedName();
    PsiClassInfo info = cache.get(className);
    if (info != null) {
      final PsiFile psiFile = clazz.getContainingFile();
      if (psiFile != null) {
        final long l = psiFile.getModificationStamp();
        if (info.clazz == clazz && l == info.modificationStamp) {
          return info.props;
        }
      }
    }

    PsiMethod[] methods = clazz.getAllMethods();
    Set<PsiBeanProperty> props = new TreeSet<PsiBeanProperty>();
    for (PsiMethod method : methods) {
      if (!method.hasModifierProperty(PsiModifier.PUBLIC)) {
        continue;
      }
      String containing = method.getContainingClass().getQualifiedName();
      if ("java.lang.Object".equals(containing) ||
          "org.apache.struts.action.ActionForm".equals(containing) ||
          "org.apache.struts.validator.ValidatorForm".equals(containing)) {
        continue;
      }

      String name = PropertyUtil.getPropertyName(method);
      if (name != null) {
        PsiField field = PropertyUtil.findPropertyField(myProject, clazz, name, method.hasModifierProperty(PsiModifier.STATIC));
        PsiBeanPropertyImpl prop = new PsiBeanPropertyImpl(clazz, name, field);
        props.add(prop);
      }
    }
    info = new PsiClassInfo();
    info.clazz = clazz;
    final PsiFile psiFile = clazz.getContainingFile();
    if (psiFile != null) {
      info.modificationStamp = psiFile.getModificationStamp();      
    }
    info.props = props.toArray(new PsiBeanProperty[props.size()]);
    cache.put(className, info);
    return info.props;
  }


  public boolean isSuper(PsiClass clazz, PsiClass superClass) {
    if (clazz == null || superClass == null) {
      return false;
    }
    String key = clazz.getQualifiedName() + ":" + superClass.getQualifiedName();
    SuperInfo result = supersCache.get(key);
    if (result == null) {
      result = new SuperInfo();
      result.isSuper = (clazz == superClass || clazz.isInheritor(superClass, true));
      result.clazz = clazz;
      result.superClass = superClass;
      supersCache.put(key, result);
    }
    else {
      if (!result.clazz.isValid() || !result.superClass.isValid()) {
        result.isSuper = (clazz == superClass || clazz.isInheritor(superClass, true));
        result.clazz = clazz;
        result.superClass = superClass;
      }
    }
    return result.isSuper;
  }

  public void projectOpened() {

  }

  public void projectClosed() {
    cache.clear();
    supersCache.clear();
  }

  private static class SuperInfo {
    PsiClass clazz;
    PsiClass superClass;
    boolean isSuper;
  }

  private static class PsiClassInfo {
    PsiClass clazz;
    PsiBeanProperty[] props;
    long modificationStamp;
  }
}
