/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.core;

import com.intellij.javaee.model.xml.ParamValue;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.actionSystem.ex.DataConstantsEx;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ProjectFileIndex;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import org.jdom.Element;

import java.util.List;

/**
 * Date: 29.10.2004 Time: 17:24:26
 *
 * @author Dmitry Avdeev
 */
public class IdeaUtils {

  public static VirtualFile findPath(VirtualFile result, String path) {
    String[] split = path.split("/");
    for (int i = 0; i < split.length; i++) {
      result = result.findChild(split[i]);
      if (result == null) {
        return null;
      }
    }
    return result;
  }

  public static void addOption(Element parent, String name, String value) {
    Element el = new Element("option");
    el.setAttribute("name", name);
    el.setAttribute("value", value);
    parent.addContent(el);
  }

  public static boolean isModuleNode(AnActionEvent event) {
    final DataContext dataContext = event.getDataContext();
    final Project project = (Project)dataContext.getData(DataConstantsEx.PROJECT);
    final Module module = (Module)dataContext.getData(DataConstantsEx.MODULE_CONTEXT);
    return project != null && module != null;
  }

  public static boolean isSubclass(PsiClass clazz, String superClass) {
    if (clazz == null) {
      return false;
    }
    if (clazz.getQualifiedName().equals(superClass)) {
      return true;
    }
    else {
      if (isSubclass(clazz.getSupers(), superClass)) {
        return true;
      }
      else if (isSubclass(clazz.getInterfaces(), superClass)) {
        return true;
      }

    }
    return false;
  }


  protected static boolean isSubclass(PsiClass[] supers, String superClass) {
    for (int i = 0; i < supers.length; i++) {
      if (isSubclass(supers[i], superClass)) {
        return true;
      }
    }
    return false;
  }

  public static ParamValue findValueByName(List<ParamValue> list, String name) {
    for (ParamValue value : list) {
      if (value.getParamName().getValue().equals(name)) {
        return value;
      }
    }
    return null;
  }
}
