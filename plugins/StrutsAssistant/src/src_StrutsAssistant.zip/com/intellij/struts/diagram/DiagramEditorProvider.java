/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.struts.diagram;

import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.fileEditor.FileEditor;
import com.intellij.openapi.fileEditor.FileEditorPolicy;
import com.intellij.openapi.fileEditor.FileEditorProvider;
import com.intellij.openapi.fileEditor.FileEditorState;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Disposer;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiManager;
import com.intellij.psi.xml.XmlFile;
import com.intellij.struts.StrutsManager;
import com.intellij.struts.dom.StrutsConfig;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

/**
 * Date: 24.09.2004 Time: 18:46:18
 *
 * @author Dmitry Avdeev
 */
public class DiagramEditorProvider implements FileEditorProvider, ApplicationComponent {

  public boolean accept(@NotNull Project project, @NotNull final VirtualFile file) {

    PsiFile psiFile = PsiManager.getInstance(project).findFile(file);
    if (psiFile instanceof XmlFile && StrutsManager.getInstance().isStrutsConfig((XmlFile)psiFile)) {
      return true;
    }
    return false;
  }

  @NotNull
  public FileEditor createEditor(@NotNull final Project project, @NotNull final VirtualFile file) {

    PsiFile configFile = PsiManager.getInstance(project).findFile(file);
    final StrutsConfig strutsConfig = StrutsManager.getInstance().getStrutsConfig(configFile).createStableCopy();
    /*
    final String diagramUrl = FormatUtil.replaceExtension(file.getUrl(), StrutsConstants.DIAGRAM_FILE_EXTENSION);
    VirtualFile diagramFile = VirtualFileManager.getInstance().findFileByUrl(diagramUrl);
    if (diagramFile == null) {
      ApplicationManager.getApplication().runWriteAction(new Runnable() {
        public void run() {
          try {
            VirtualFile parent = file.getParent();
            assert parent != null;
            String diagramFileName = FormatUtil.replaceExtension(file.getName(), StrutsConstants.DIAGRAM_FILE_EXTENSION);
            parent.createChildData(this, diagramFileName);
          }
          catch (IOException e) {
            LOG.error("Can't create diagram file", e);
          }
        }
      });
      diagramFile = VirtualFileManager.getInstance().findFileByUrl(diagramUrl);
    }

    DiagramManager.SerializerFactory factory = new DiagramManager.SerializerFactory() {
      @NotNull
      public GraphSerializer createSerializer(GraphModelAdapter model) {
        return new DomSerializerImpl(model, new StrutsDiagramObjectFactory(strutsConfig));
      }
    };
    */
/*
    GraphDocument doc;
    try {
      assert diagramFile != null;
      doc = DiagramManager.getInstance(project).getDocument(diagramFile, factory);
    }
    catch (DiagramCorruptedException e) {
      doc = e.getDoc();
    }
*/
    return new StrutsGraphEditor(project, file, strutsConfig);
  }

  public void disposeEditor(@NotNull FileEditor editor) {
    Disposer.dispose((StrutsGraphEditor)editor);
  }

  @NotNull
  public FileEditorState readState(@NotNull Element sourceElement, @NotNull Project project, @NotNull VirtualFile file) {
    return FileEditorState.INSTANCE;
  }

  public void writeState(@NotNull FileEditorState state, @NotNull Project project, @NotNull Element targetElement) {

  }

  @NotNull
  @NonNls
  public String getEditorTypeId() {
    return "com.intellij.struts.diagram.DiagramEditorProvider";
  }

  @NotNull
  public FileEditorPolicy getPolicy() {
    return FileEditorPolicy.PLACE_AFTER_DEFAULT_EDITOR;
  }

  @NonNls
  @NotNull
  public String getComponentName() {
    return "StrutsDiagramEditorProvider";
  }

  public void initComponent() {

  }

  public void disposeComponent() {

  }
}
