package com.intellij.struts;

import org.jetbrains.annotations.Nullable;
import com.intellij.javaee.model.xml.web.ServletMapping;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiReference;
import com.intellij.psi.xml.XmlElement;

/**
 * @author Dmitry Avdeev
 */
public interface ServletMappingInfo {
  @Nullable
  String getUrlPattern();

  ServletMapping getServletMapping();

  @Nullable
  String stripMapping(String actionUrl);

  String createUrl(String actionPath);

  @Nullable
  TextRange getActionRange(String actionUrl);

  @Nullable
  TextRange getMappingRange(String actionUrl);

  @Nullable
  PsiReference getMappingReference(XmlElement element, String actionUrl, boolean soft);
}
