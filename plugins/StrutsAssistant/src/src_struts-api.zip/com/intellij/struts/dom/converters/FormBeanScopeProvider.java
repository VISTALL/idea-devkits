/*
 * Copyright (c) 2007, Your Corporation. All Rights Reserved.
 */

package com.intellij.struts.dom.converters;

import com.intellij.struts.dom.StrutsConfig;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.MergingFileDescription;
import com.intellij.util.xml.ScopeProvider;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author Dmitry Avdeev
 */
public class FormBeanScopeProvider extends ScopeProvider {

  @Nullable
  public DomElement getScope(@NotNull final DomElement element) {
    final MergingFileDescription<StrutsConfig> description = (MergingFileDescription<StrutsConfig>)element.getManager().getFileDescription(element);
    final StrutsConfig config = description.getMergedRoot(element.<StrutsConfig>getRoot());
    return config.getFormBeans();
  }
}
