/*
 * Copyright (c) 2007, Your Corporation. All Rights Reserved.
 */

package com.intellij.struts.dom.converters;

import com.intellij.struts.dom.StrutsConfig;
import com.intellij.util.xml.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author Dmitry Avdeev
 */
public class FormBeanScopeProvider extends ScopeProvider {

  @Nullable
  public DomElement getScope(@NotNull final DomElement element) {
    final MergingFileDescription<StrutsConfig> description = (MergingFileDescription)element.getRoot().getFileDescription();
    final StrutsConfig config = description.getMergedRoot(element.<StrutsConfig>getRoot());
    return config.getFormBeans();
  }
}
