package com.sixrr.inspectjs.bugs;

import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.lang.javascript.psi.JSBinaryExpression;
import com.intellij.lang.javascript.psi.JSExpression;
import com.intellij.psi.tree.IElementType;
import com.sixrr.inspectjs.BaseInspectionVisitor;
import com.sixrr.inspectjs.InspectionJSBundle;
import com.sixrr.inspectjs.JSGroupNames;
import com.sixrr.inspectjs.JavaScriptInspection;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

public class EqualityComparisonWithCoercionJSInspection extends JavaScriptInspection {

    @NotNull
    public String getID() {
        return "EqualityComparisonWithCoercionJS";
    }

    @NotNull
    public String getDisplayName() {
        return InspectionJSBundle.message("equality.comparison.with.coercion.display.name");
    }

    @NotNull
    public String getGroupDisplayName() {
        return JSGroupNames.BUGS_GROUP_NAME;
    }

    @NotNull
    protected String buildErrorString(Object... args) {
        return InspectionJSBundle.message("equality.comparison.with.coercion.error.string");
    }

    public BaseInspectionVisitor buildVisitor() {
        return new DivisionByZeroVisitor();
    }

    private static class DivisionByZeroVisitor extends BaseInspectionVisitor {

        public void visitJSBinaryExpression(
                @NotNull JSBinaryExpression expression) {
            super.visitJSBinaryExpression(expression);
            final JSExpression lhs = expression.getLOperand();
            if (lhs == null) {
                return;
            }
            final JSExpression rhs = expression.getROperand();
            if (rhs == null) {
                return;
            }
            final IElementType tokenType = expression.getOperationSign();
            if (!tokenType.equals(JSTokenTypes.EQEQ) &&
                    !tokenType.equals(JSTokenTypes.NE)) {
                return;
            }
            if(!mayCauseCoercion(rhs) &&!mayCauseCoercion(lhs))
            {
                return;
            }
            registerError(expression);
        }


    }

    private static boolean mayCauseCoercion(JSExpression expression) {
        @NonNls
        final String text = expression.getText();
        return "0".equals(text) ||
                "0x0".equals(text) ||
                "0X0".equals(text) ||
                "0.0".equals(text) ||
                "0L".equals(text) ||
                "0l".equals(text) ||
                "null".equals(text) ||
                "undefined".equals(text) ||
                "true".equals(text) ||
                "false".equals(text) ||
                "''".equals(text);
    }

}
