package com.sixrr.inspectjs.dataflow;

import com.intellij.psi.*;
import com.intellij.psi.tree.IElementType;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.JSTokenTypes;
import com.sixrr.inspectjs.JSRecursiveElementVisitor;
import org.jetbrains.annotations.NotNull;

public class VariableAssignedVisitor extends JSRecursiveElementVisitor {

    private boolean assigned = false;
    @NotNull private final JSVariable variable;

    public VariableAssignedVisitor(@NotNull JSVariable variable) {
        super();
        this.variable = variable;
    }

    public void visitElement(@NotNull PsiElement element) {
        if (!assigned) {
            super.visitElement(element);
        }
    }

    public void visitJSAssignmentExpression(
            @NotNull JSAssignmentExpression assignment) {
        if (assigned) {
            return;
        }
        super.visitJSAssignmentExpression(assignment);
        final JSExpression arg = assignment.getLOperand();
        if (VariableAccessUtils.mayEvaluateToVariable(arg, variable)) {
            assigned = true;
        }
    }

    public void visitJSPrefixExpression(
            @NotNull JSPrefixExpression prefixExpression) {
        if (assigned) {
            return;
        }
        super.visitJSPrefixExpression(prefixExpression);
        final IElementType operationSign = prefixExpression.getOperationSign();
        if (!JSTokenTypes.PLUSPLUS.equals(operationSign) &&
                !JSTokenTypes.MINUSMINUS.equals(operationSign)) {
            return;
        }
        final JSExpression operand = prefixExpression.getExpression();
        if (VariableAccessUtils.mayEvaluateToVariable(operand, variable)) {
            assigned = true;
        }
    }

    public void visitJSPostfixExpression(
            @NotNull JSPostfixExpression postfixExpression) {
        if (assigned) {
            return;
        }
        super.visitJSPostfixExpression(postfixExpression);
        final IElementType operationSign = postfixExpression.getOperationSign();
        if (!operationSign.equals(JSTokenTypes.PLUSPLUS) &&
                !operationSign.equals(JSTokenTypes.MINUSMINUS)) {
            return;
        }
        final JSExpression operand = postfixExpression.getExpression();
        if (VariableAccessUtils.mayEvaluateToVariable(operand, variable)) {
            assigned = true;
        }
    }

    public boolean isAssigned() {
        return assigned;
    }
}
