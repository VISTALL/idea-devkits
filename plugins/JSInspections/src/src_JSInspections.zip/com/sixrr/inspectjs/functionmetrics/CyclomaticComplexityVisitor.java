package com.sixrr.inspectjs.functionmetrics;

import com.intellij.lang.javascript.psi.*;
import com.sixrr.inspectjs.JSRecursiveElementVisitor;
import org.jetbrains.annotations.NotNull;

class CyclomaticComplexityVisitor extends JSRecursiveElementVisitor {
    private int complexity = 1;

    public void visitJSElement(JSElement jsElement) {
        int oldComplexity = 0;
        if(jsElement instanceof JSFunction)
        {
            oldComplexity = complexity;
        }
        super.visitJSElement(jsElement);

        if (jsElement instanceof JSFunction) {
            complexity = oldComplexity;
        }
    }

    public void visitJSForStatement(@NotNull JSForStatement statement) {
        super.visitJSForStatement(statement);
        complexity++;
    }

    public void visitJSForeachStatement(@NotNull JSForInStatement statement) {
        super.visitJSForInStatement(statement);
        complexity++;
    }

    public void visitJSIfStatement(@NotNull JSIfStatement statement) {
        super.visitJSIfStatement(statement);
        complexity++;
    }

    public void visitJSDoWhileStatement(@NotNull JSDoWhileStatement statement) {
        super.visitJSDoWhileStatement(statement);
        complexity++;
    }

    public void visitJSConditionalExpression(JSConditionalExpression expression) {
        super.visitJSConditionalExpression(expression);
        complexity++;
    }

    public void visitJSSwitchStatement(@NotNull JSSwitchStatement statement) {
        super.visitJSSwitchStatement(statement);
        final JSCaseClause[] caseClauses = statement.getCaseClauses();
        for (JSCaseClause clause : caseClauses) {
            final JSStatement[] statements = clause.getStatements();
            if(statements!=null && statements.length!=0)
            {
                complexity++;
            }
        }
    }

    public void visitJSWhileStatement(@NotNull JSWhileStatement statement) {
        super.visitJSWhileStatement(statement);
        complexity++;
    }

    public int getComplexity() {
        return complexity;
    }
}
