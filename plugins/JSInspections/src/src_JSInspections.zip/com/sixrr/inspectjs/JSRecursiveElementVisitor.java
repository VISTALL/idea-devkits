package com.sixrr.inspectjs;

import com.intellij.lang.javascript.psi.JSElementVisitor;
import com.intellij.psi.PsiElement;

public class JSRecursiveElementVisitor extends JSElementVisitor {
    public void visitElement(PsiElement element) {

        super.visitElement(element);
        final PsiElement[] children = element.getChildren();
        for (PsiElement child : children) {
            child.accept(this);
        }
    }
}
