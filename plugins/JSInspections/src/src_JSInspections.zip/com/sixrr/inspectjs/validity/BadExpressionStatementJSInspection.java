package com.sixrr.inspectjs.validity;

import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.psi.PsiElement;
import com.intellij.psi.tree.IElementType;
import com.sixrr.inspectjs.BaseInspectionVisitor;
import com.sixrr.inspectjs.JSGroupNames;
import com.sixrr.inspectjs.JavaScriptInspection;
import com.sixrr.inspectjs.InspectionJSBundle;
import org.jetbrains.annotations.*;

public class BadExpressionStatementJSInspection extends JavaScriptInspection {

  @NotNull
  public String getDisplayName() {
    return InspectionJSBundle.message("expression.statement.which.is.not.assignment.or.call.display.name");
  }

  @NotNull
  public String getGroupDisplayName() {
    return JSGroupNames.VALIDITY_GROUP_NAME;
  }

  public boolean isEnabledByDefault() {
    return true;
  }

  @Nullable
  protected String buildErrorString(Object... args) {
    return InspectionJSBundle.message("expression.statement.is.not.assignment.or.call.error.string");
  }

  public BaseInspectionVisitor buildVisitor() {
    return new Visitor();
  }

  private static class Visitor extends BaseInspectionVisitor {

    public void visitJSExpressionStatement(JSExpressionStatement jsExpressionStatement) {
      super.visitJSExpressionStatement(jsExpressionStatement);
      final JSExpression expression = jsExpressionStatement.getExpression();
      if (isNotPointless(expression)) return;

      if (expression instanceof JSReferenceExpression) {
        if ("debugger".equals(expression.getText())) {
          return;
        }
      }
      registerError(jsExpressionStatement);
    }

    private boolean isNotPointless(final JSExpression expression) {
      if (expression instanceof JSCallExpression) {
        return true;
      }
      if (expression instanceof JSAssignmentExpression) {
        return true;
      }

      if (expression instanceof JSPrefixExpression) {
        final JSPrefixExpression prefix = (JSPrefixExpression)expression;
        final IElementType sign = prefix.getOperationSign();
        if (JSTokenTypes.PLUSPLUS.equals(sign) || JSTokenTypes.MINUSMINUS.equals(sign)) {
          return true;
        }
        final PsiElement signElement = expression.getFirstChild();
        if (signElement != null) {
          @NonNls final String text = signElement.getText();
          if ("delete".equals(text)) {
            return true;
          }
        }
      }
      if (expression instanceof JSPostfixExpression) {
        final JSPostfixExpression prefix = (JSPostfixExpression)expression;
        final IElementType sign = prefix.getOperationSign();
        if (JSTokenTypes.PLUSPLUS.equals(sign) || JSTokenTypes.MINUSMINUS.equals(sign)) {
          return true;
        }
      }

      if (expression instanceof JSBinaryExpression) {
        final JSBinaryExpression binary = (JSBinaryExpression)expression;
        final IElementType sign = binary.getOperationSign();

        if (sign == JSTokenTypes.ANDAND) {
          final JSExpression leftOp = binary.getLOperand();

          if ((leftOp instanceof JSReferenceExpression || leftOp instanceof JSIndexedPropertyAccessExpression) &&
              isNotPointless(binary.getROperand())) {
            return true;
          }
        }
        else if (sign == JSTokenTypes.COMMA) {
          return isNotPointless(binary.getLOperand()) || isNotPointless(binary.getROperand());
        }
      }
      return false;
    }
  }
}
