package com.sixrr.inspectjs.style;

import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.lang.javascript.psi.*;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiElement;
import com.intellij.util.IncorrectOperationException;
import com.sixrr.inspectjs.*;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

public class UnterminatedStatementJSInspection extends JavaScriptInspection {
    private final TerminateStatementFix fix = new TerminateStatementFix();

    @NotNull
    public String getDisplayName() {
        return InspectionJSBundle.message("unterminated.statement.display.name");
    }

    @NotNull
    public String getGroupDisplayName() {
        return JSGroupNames.STYLE_GROUP_NAME;
    }

    @Nullable
    protected String buildErrorString(Object... args) {
        return InspectionJSBundle.message("unterminated.statement.error.string");
    }

    public BaseInspectionVisitor buildVisitor() {
        return new Visitor();
    }

    public InspectionJSFix buildFix(PsiElement location) {
        return fix;
    }

    private static class TerminateStatementFix extends InspectionJSFix {
        @NotNull
        public String getName() {
            return InspectionJSBundle.message("terminate.statement.fix");
        }

        public void doFix(Project project, ProblemDescriptor descriptor)
                throws IncorrectOperationException {
            final JSStatement expression = (JSStatement) descriptor.getPsiElement();
            final String text = expression.getText();
            replaceStatement(expression, text + ';');
        }
    }

    private static class Visitor extends BaseInspectionVisitor {

        public void visitJSExpressionStatement(JSExpressionStatement statement) {
            super.visitJSExpressionStatement(statement);
            if (isTerminated(statement)) {
                return;
            }
            registerError(statement);
        }
        public void visitJSBreakStatement(JSBreakStatement jsBreakStatement) {
            super.visitJSBreakStatement(jsBreakStatement);
            if (isTerminated(jsBreakStatement)) {
                return;
            }
            registerError(jsBreakStatement);
        }

        public void visitJSContinueStatement(JSContinueStatement jsContinueStatement) {
            super.visitJSContinueStatement(jsContinueStatement);
            if (isTerminated(jsContinueStatement)) {
                return;
            }
            registerError(jsContinueStatement);
        }

        public void visitJSReturnStatement(JSReturnStatement jsReturnStatement) {
            super.visitJSReturnStatement(jsReturnStatement);
            if (isTerminated(jsReturnStatement)) {
                return;
            }
            registerError(jsReturnStatement);
        }

        public void visitJSThrowStatement(JSThrowStatement jsThrowStatement) {
            super.visitJSThrowStatement(jsThrowStatement);
            if (isTerminated(jsThrowStatement)) {
                return;
            }
            registerError(jsThrowStatement);
        }

        public void visitJSDoWhileStatement(JSDoWhileStatement jsDoWhileStatement) {
            super.visitJSDoWhileStatement(jsDoWhileStatement);
            if (isTerminated(jsDoWhileStatement)) {
                return;
            }
            registerError(jsDoWhileStatement);
        }

        public void visitJSVarStatement(JSVarStatement jsVarStatement) {
            super.visitJSVarStatement(jsVarStatement);
            if (isTerminated(jsVarStatement)) {
                return;
            }
            registerError(jsVarStatement);
        }
    }

    private static boolean isTerminated(JSStatement statement) {
        final PsiElement parent = statement.getParent();
        if (parent instanceof JSForInStatement ||
                parent instanceof JSForStatement) {
            return true;
        }
        final String text = statement.getText();
        if (text == null) {
            return true;
        }
        return text.endsWith(";");
    }
}
