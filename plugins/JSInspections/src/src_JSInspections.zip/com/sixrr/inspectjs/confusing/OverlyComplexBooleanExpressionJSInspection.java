package com.sixrr.inspectjs.confusing;

import com.intellij.psi.*;
import com.intellij.psi.tree.IElementType;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.JSTokenTypes;
import com.sixrr.inspectjs.BaseInspectionVisitor;
import com.sixrr.inspectjs.JSGroupNames;
import com.sixrr.inspectjs.JavaScriptInspection;
import com.sixrr.inspectjs.InspectionJSBundle;
import com.sixrr.inspectjs.ui.SingleIntegerFieldOptionsPanel;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

public class OverlyComplexBooleanExpressionJSInspection extends JavaScriptInspection {
    private static final int TERM_LIMIT = 3;

    /**
     * @noinspection PublicField
     */
    public int m_limit = TERM_LIMIT;

    @NotNull
    public String getDisplayName() {
        return InspectionJSBundle.message("overly.complex.boolean.expression.display.name");
    }

    @NotNull
    public String getGroupDisplayName() {
        return JSGroupNames.CONFUSING_GROUP_NAME;
    }

    private int getLimit() {
        return m_limit;
    }

    public JComponent createOptionsPanel() {
        return new SingleIntegerFieldOptionsPanel(InspectionJSBundle.message("maximum.number.of.terms.parameter"),
                this, "m_limit");
    }

    protected boolean buildQuickFixesOnlyForOnTheFlyErrors() {
        return true;
    }

    protected String buildErrorString(Object... args) {
        return InspectionJSBundle.message("overly.complex.boolean.expression.error.string");
    }

    public BaseInspectionVisitor buildVisitor() {
        return new Visitor();
    }

    private class Visitor extends BaseInspectionVisitor {

        public void visitJSBinaryExpression(@NotNull JSBinaryExpression expression) {
            super.visitJSBinaryExpression(expression);
            checkExpression(expression);
        }

        public void visitJSPrefixExpression(@NotNull JSPrefixExpression expression) {
            super.visitJSPrefixExpression(expression);
            checkExpression(expression);
        }

        public void visitJSParenthesizedExpression(JSParenthesizedExpression expression) {
            super.visitJSParenthesizedExpression(expression);
            checkExpression(expression);
        }

        private void checkExpression(JSExpression expression) {
            if (!isBoolean(expression)) {
                return;
            }
            if (isParentBoolean(expression)) {
                return;
            }
            final int numTerms = countTerms(expression);
            if (numTerms <= getLimit()) {
                return;
            }
            registerError(expression);
        }

        private int countTerms(JSExpression expression) {
            if (expression == null) {
                return 0;
            }
            if (!isBoolean(expression)) {
                return 1;
            }
            if (expression instanceof JSBinaryExpression) {
                final JSBinaryExpression binaryExpression = (JSBinaryExpression) expression;
                final JSExpression lhs = binaryExpression.getLOperand();
                final JSExpression rhs = binaryExpression.getROperand();
                return countTerms(lhs) + countTerms(rhs);
            } else if (expression instanceof JSPrefixExpression) {
                final JSPrefixExpression prefixExpression = (JSPrefixExpression) expression;
                final JSExpression operand = prefixExpression.getExpression();
                return countTerms(operand);
            } else if (expression instanceof JSParenthesizedExpression) {
                final JSParenthesizedExpression parenthesizedExpression = (JSParenthesizedExpression) expression;
                final JSExpression contents = parenthesizedExpression.getInnerExpression();
                return countTerms(contents);
            }
            return 1;
        }

        private boolean isParentBoolean(JSExpression expression) {
            final PsiElement parent = expression.getParent();
            if (!(parent instanceof JSExpression)) {
                return false;
            }
            return isBoolean((JSExpression) parent);
        }

        private boolean isBoolean(JSExpression expression) {
            if (expression instanceof JSBinaryExpression) {
                final JSBinaryExpression binaryExpression = (JSBinaryExpression) expression;
                final IElementType sign = binaryExpression.getOperationSign();
                return JSTokenTypes.ANDAND.equals(sign) ||
                        JSTokenTypes.OROR.equals(sign);
            } else if (expression instanceof JSPrefixExpression) {
                final JSPrefixExpression prefixExpression = (JSPrefixExpression) expression;
                final IElementType sign = prefixExpression.getOperationSign();
                return JSTokenTypes.EXCL.equals(sign);
            } else if (expression instanceof JSParenthesizedExpression) {
                final JSParenthesizedExpression parenthesizedExpression = (JSParenthesizedExpression) expression;
                final JSExpression contents = parenthesizedExpression.getInnerExpression();
                return isBoolean(contents);
            }
            return false;
        }
    }
}
