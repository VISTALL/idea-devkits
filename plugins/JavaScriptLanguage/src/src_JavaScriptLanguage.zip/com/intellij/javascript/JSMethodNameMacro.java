package com.intellij.javascript;

import com.intellij.codeInsight.template.*;
import com.intellij.codeInsight.lookup.LookupElement;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.psi.JSFunction;
import com.intellij.lang.javascript.psi.JSFunctionExpression;
import com.intellij.psi.PsiElement;
import com.intellij.psi.util.PsiTreeUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

public class JSMethodNameMacro implements Macro {

  @NonNls
  public String getName() {
    return "jsMethodName";
  }

  public String getDescription() {
    return JSBundle.message("js.methodname.macro.description");
  }

  @NonNls
  public String getDefaultValue() {
    return "";
  }

  public Result calculateResult(@NotNull Expression[] params, ExpressionContext context) {
    final PsiElement elementAtCaret = JSClassNameMacro.findElementAtCaret(context);
    if (elementAtCaret != null) {
      JSFunction function = PsiTreeUtil.getParentOfType(elementAtCaret, JSFunction.class);
      if (function instanceof JSFunctionExpression) {
        function = ((JSFunctionExpression)function).getFunction();
      }

      if (function != null) {
        final String name = function.getName();
        if (name != null) return new TextResult(name);
      }
    }
    return null;
  }

  public Result calculateQuickResult(@NotNull Expression[] params, ExpressionContext context) {
    return null;
  }

  public LookupElement[] calculateLookupItems(@NotNull Expression[] params, ExpressionContext context) {
    return null;
  }
}
