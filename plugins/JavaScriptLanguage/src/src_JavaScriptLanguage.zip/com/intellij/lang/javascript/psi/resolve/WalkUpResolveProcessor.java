/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript.psi.resolve;

import com.intellij.psi.ResolveResult;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiNamedElement;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.index.JSNamespace;
import com.intellij.lang.javascript.index.JSNamedElementProxy;

import java.util.List;
import java.util.ArrayList;

import org.jetbrains.annotations.Nullable;

/**
 * Created by IntelliJ IDEA.
* User: Maxim.Mossienko
* Date: Jun 3, 2006
* Time: 4:22:58 PM
* To change this template use File | Settings | File Templates.
*/
public class WalkUpResolveProcessor extends BaseJSSymbolProcessor {
  private String myText;
  protected int[] myNameIds;
  private int myFilePartialResultsCount;
  private List<ResolveResult> myPartialMatchResults;
  private int myFileCompleteResultsCount;
  private List<ResolveResult> myCompleteMatchResults;
  private boolean myDefinitelyGlobalReference;
  private boolean myDefinitelyNonglobalReference;

  public WalkUpResolveProcessor(String text,
                            int[] nameIds,
                            PsiFile targetFile,
                            boolean skipDclsInTargetFile,
                            PsiElement context
                            ) {
    super(targetFile,skipDclsInTargetFile,context);
    myText = text;
    myNameIds = nameIds;

    if (myNameIds.length == 1 &&
        myContext instanceof JSReferenceExpression &&
        ((JSReferenceExpression)myContext).getQualifier() == null &&
        PsiTreeUtil.getParentOfType(myContext, JSWithStatement.class) == null
       ) {
      myDefinitelyGlobalReference = true;
    }

    if (myNameIds.length > 2 ||
        ( myNameIds.length == 2 &&
          myIndex.getStringByIndex(myNameIds[0]).length() > 0 &&
          myNameIds[0] != myWindowIndex
        )
      ) {
      myDefinitelyNonglobalReference = true;
    }
  }

  public void processFunction(JSNamespace namespace, final int nameId, final JSNamedElement function) {
    doQualifiedCheck(namespace, nameId, function);
  }

  protected MatchType isAcceptableQualifiedItem(JSNamespace namespace, final int nameId) {
    boolean partialMatch = myNameIds[myNameIds.length - 1] == nameId;
    if (partialMatch) {
      int i;
      for(i = myNameIds.length - 2; i >= 0; --i) {
        if (namespace == null) break;
        if (namespace.getNameId() != myNameIds[i]) break;
        namespace = namespace.getParent();
      }
      if (i < 0 && isGlobalNS(namespace)) return MatchType.COMPLETE;
    }

    return  partialMatch ? MatchType.PARTIAL: MatchType.NOMATCH;
  }

  private void doQualifiedCheck(final JSNamespace namespace, int nameId, final PsiNamedElement element) {
    final MatchType matchType = isAcceptableQualifiedItem(namespace, nameId);

    if ( matchType == MatchType.PARTIAL ) {
      if (myDefinitelyGlobalReference &&
          ( ( element instanceof JSNamedElementProxy &&
             ( ((JSNamedElementProxy)element).getType() == JSNamedElementProxy.NamedItemType.FunctionProperty ||
               ((JSNamedElementProxy)element).getType() == JSNamedElementProxy.NamedItemType.Property ||
               ( ((JSNamedElementProxy)element).getType() == JSNamedElementProxy.NamedItemType.Definition && !isGlobalNS(namespace))
             )
            ) ||
            ( element instanceof JSFunctionExpression ||
              element instanceof JSProperty ||
              ( element instanceof JSDefinitionExpression && !isGlobalNS(namespace))
            )
          )
        ) {
        return; // nonqualified item could not be resolved into property
      }

      if (myDefinitelyNonglobalReference &&
            ( element instanceof JSNamedElementProxy &&
              ( ((JSNamedElementProxy)element).getType() == JSNamedElementProxy.NamedItemType.Variable ||
                ((JSNamedElementProxy)element).getType() == JSNamedElementProxy.NamedItemType.Function
              )
            ) ||
            ( element instanceof JSVariable ||
              ( element instanceof JSFunction && !(element instanceof JSFunctionExpression))
            )
        ) {
        return; // qualified item could not be resolved into function/variable
      }
      addPartialResult(element);
    } else if (matchType == MatchType.COMPLETE) {
      addCompleteResult(element);
    }
  }

  private void addCompleteResult(PsiElement element) {
    if (myCompleteMatchResults == null) myCompleteMatchResults = new ArrayList<ResolveResult>(1);
    final JSResolveUtil.MyResolveResult o = new JSResolveUtil.MyResolveResult(element);
    if (isFromRelevantFileOrDirectory()) {
      myCompleteMatchResults.add(myFileCompleteResultsCount++, o);
    } else {
      myCompleteMatchResults.add( o );
    }
  }

  private void addPartialResult(PsiElement element) {
    if (myPartialMatchResults == null) myPartialMatchResults = new ArrayList<ResolveResult>(1);
    final JSResolveUtil.MyResolveResult o = new JSResolveUtil.MyResolveResult(element);

    if (isFromRelevantFileOrDirectory()) {
      myPartialMatchResults.add(myFilePartialResultsCount++, o);
    } else {
      myPartialMatchResults.add( o );
    }
  }

  public void processProperty(JSNamespace namespace, final int nameId, JSNamedElement property) {
    doQualifiedCheck(namespace, nameId, property);
  }

  public void processVariable(JSNamespace namespace, final int nameId, JSNamedElement variable) {
    if (shouldProcessVariable(nameId)) {
      addCompleteResult(variable);
    }
  }

  public PsiFile getBaseFile() {
    return myTargetFile;
  }

  public void processDefinition(final JSNamespace namespace, final int nameId, final JSNamedElement refExpr) {
    //if(myCurrentFile != myTargetFile || !mySkipDclsInTargetFile)
    doQualifiedCheck(namespace, nameId, refExpr);
  }

  @Nullable
  public int getRequiredNameId() {
    return myNameIds[myNameIds.length - 1];
  }

  public void processTag(JSNamespace namespace, final int nameId, PsiNamedElement namedElement, final String attrName) {
    doQualifiedCheck(namespace, nameId, namedElement);
  }

  protected boolean shouldProcessVariable(final int nameId) {
    return ( !myDefinitelyNonglobalReference &&
               myNameIds[myNameIds.length - 1] == nameId
           );
  }

  public ResolveResult[] getResults() {
    int resultCount = 0;
    if (myCompleteMatchResults != null) resultCount += myCompleteMatchResults.size();
    if (myPartialMatchResults != null) resultCount += myPartialMatchResults.size();

    final ResolveResult[] result = resultCount != 0 ? new ResolveResult[resultCount]:ResolveResult.EMPTY_ARRAY;

    if (myCompleteMatchResults != null) {
      for(int i = 0; i < myCompleteMatchResults.size(); ++i) {
        result[i] = myCompleteMatchResults.get( i );
      }
    }

    if (myPartialMatchResults != null) {
      int offset = myCompleteMatchResults != null ? myCompleteMatchResults.size():0;
      for(int i = 0; i < myPartialMatchResults.size(); ++i) {
        result[offset + i] = myPartialMatchResults.get( i );
      }
    }

    return result;
  }
  
  public String getText() {
    return myText;
  }
}
