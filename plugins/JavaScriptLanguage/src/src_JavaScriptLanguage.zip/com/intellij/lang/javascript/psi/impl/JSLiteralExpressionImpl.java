/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi.impl;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.index.JavaScriptIndex;
import com.intellij.lang.javascript.psi.JSElementVisitor;
import com.intellij.lang.javascript.psi.JSLiteralExpression;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.VariantsProcessor;
import com.intellij.lang.javascript.psi.resolve.WalkUpResolveProcessor;
import com.intellij.openapi.util.TextRange;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.*;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 30, 2005
 * Time: 11:24:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSLiteralExpressionImpl extends JSExpressionImpl implements JSLiteralExpression{
  private String myReferenceText;
  private PsiReference[] myReferences;

  public JSLiteralExpressionImpl(final ASTNode node) {
    super(node);
  }

  @NotNull
  public PsiReference[] getReferences() {
    String text = getText();
    if (myReferences != null &&
        myReferenceText != null &&
        myReferenceText.equals(text)) {
      return myReferences;
    }

    if (!StringUtil.startsWithChar(text,'"') && !StringUtil.startsWithChar(text,'\'')) {
      myReferenceText = text;
      myReferences = PsiReference.EMPTY_ARRAY;
    }

    String value = StringUtil.stripQuotesAroundValue(text);
    List<PsiReference> refs = new ArrayList<PsiReference>(1);
    int lastPos = 0;
    int dotPos = value.indexOf('.');

    while(dotPos != -1) {
      final String s = value.substring(lastPos,dotPos).trim();

      if (s.length() > 0) {
        refs.add( new MyPsiReference(s,lastPos + 1) );
      }

      lastPos = dotPos + 1;
      dotPos = value.indexOf('.',lastPos);
    }

    final String s = value.substring(lastPos).trim();

    if (s.length() > 0) {
      refs.add( new MyPsiReference(s,lastPos + 1) );
    }

    myReferenceText = text;
    myReferences = refs.toArray(new PsiReference[refs.size()]);
    return myReferences;
  }

  public void accept(PsiElementVisitor visitor) {
    if (visitor instanceof JSElementVisitor) {
      ((JSElementVisitor)visitor).visitJSLiteralExpression(this);
    }
    else {
      visitor.visitElement(this);
    }
  }

  private class MyPsiReference implements PsiPolyVariantReference {
    private String myText;
    private int myOffset;

    MyPsiReference(final String s, final int i) {
      myText = s;
      myOffset = i;
    }

    public PsiElement getElement() {
      return JSLiteralExpressionImpl.this;
    }

    public TextRange getRangeInElement() {
      return new TextRange(myOffset,myOffset + myText.length());
    }

    @Nullable
    public PsiElement resolve() {
      final ResolveResult[] resolveResults = multiResolve(false);
      return resolveResults.length == 1 ? resolveResults[0].getElement():null;
    }

    public String getCanonicalText() {
      return myText;
    }

    public PsiElement handleElementRename(String newElementName) throws IncorrectOperationException {
      int sizeChange = newElementName.length() - myText.length();
      boolean found = false;
      String newLiteralText = myReferenceText.substring(0,myOffset) + newElementName + myReferenceText.substring(myOffset + myText.length());
      final ASTNode expressionFromText = JSChangeUtil.createExpressionFromText(getProject(), newLiteralText);
      if (expressionFromText.getPsi() instanceof JSLiteralExpression) {
        getNode().replaceChild(
          getNode().getFirstChildNode(),
          expressionFromText.getFirstChildNode()
        );
      }
      myText = newElementName;

      for (final PsiReference reference : myReferences) {
        if (reference == this) {
          found = true;
        }
        else if (found) {
          ((MyPsiReference)reference).myOffset += sizeChange;
        }
      }
      return null;
    }

    public PsiElement bindToElement(PsiElement element) throws IncorrectOperationException {
      return null;
    }

    public boolean isReferenceTo(PsiElement element) {
      if (element instanceof PsiNamedElement || element instanceof XmlAttributeValue)
        return JSResolveUtil.isReferenceTo(this, myText, element);
      return false;
    }

    public Object[] getVariants() {
      final VariantsProcessor processor = new VariantsProcessor(
        null,
        getContainingFile(),
        false,
        JSLiteralExpressionImpl.this
      );
      JavaScriptIndex.getInstance(getProject()).processAllSymbols(processor);

      return processor.getResult();
    }

    public boolean isSoft() {
      return true;
    }

    @NotNull
    public ResolveResult[] multiResolve(final boolean incompleteCode) {
      final PsiFile psiFile = getContainingFile();
      final WalkUpResolveProcessor processor = new WalkUpResolveProcessor(
        myText,
        new int[]{ JavaScriptIndex.getInstance(psiFile.getProject()).getIndexOf( myText) },
        psiFile,
        false,
        JSLiteralExpressionImpl.this
      );

      return JSResolveUtil.resolve(psiFile, processor);
    }
  }

}
