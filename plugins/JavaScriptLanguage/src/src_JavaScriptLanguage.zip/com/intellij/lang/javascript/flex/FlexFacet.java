package com.intellij.lang.javascript.flex;

import com.intellij.facet.Facet;
import com.intellij.facet.FacetType;
import com.intellij.facet.FacetTypeId;
import com.intellij.openapi.module.Module;

public class FlexFacet extends Facet<FlexFacetConfiguration> {
  public static final FacetTypeId<FlexFacet> ID = new FacetTypeId<FlexFacet>("flex");

  public static final FacetType<FlexFacet, FlexFacetConfiguration> ourFacetType = new FlexFacetType();

  public FlexFacet(Module module, String name, FlexFacetConfiguration configuration) {
    super(ourFacetType, module, name, configuration, null);
  }
}