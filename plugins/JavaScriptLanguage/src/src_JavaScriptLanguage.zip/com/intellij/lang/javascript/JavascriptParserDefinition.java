/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript;

import com.intellij.extapi.psi.ASTWrapperPsiElement;
import com.intellij.lang.ASTNode;
import com.intellij.lang.LanguageUtil;
import com.intellij.lang.ParserDefinition;
import com.intellij.lang.PsiParser;
import com.intellij.lang.javascript.parsing.JSParser;
import com.intellij.lang.javascript.psi.JSFile;
import com.intellij.lang.javascript.psi.impl.*;
import com.intellij.lexer.Lexer;
import com.intellij.openapi.project.Project;
import com.intellij.psi.FileViewProvider;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.tree.IElementType;
import com.intellij.psi.tree.IFileElementType;
import com.intellij.psi.tree.TokenSet;
import org.jetbrains.annotations.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 27, 2005
 * Time: 6:07:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class JavascriptParserDefinition implements ParserDefinition {
  @NotNull
  public Lexer createLexer(Project project) {
    return new JavaScriptParsingLexer(JavascriptLanguage.DIALECT_OPTION_HOLDER);
  }

  public IFileElementType getFileNodeType() {
    return JSElementTypes.FILE;
  }

  @NotNull
  public TokenSet getWhitespaceTokens() {
    return TokenSet.create(JSTokenTypes.WHITE_SPACE);
  }

  @NotNull
  public TokenSet getCommentTokens() {
    return JSTokenTypes.COMMENTS;
  }

  @NotNull
  public PsiParser createParser(final Project project) {
    return new JSParser();
  }

  public PsiFile createFile(FileViewProvider viewProvider) {
    return new JSFile(viewProvider);
  }

  public SpaceRequirements spaceExistanceTypeBetweenTokens(ASTNode left, ASTNode right) {
    final Lexer lexer = createLexer(left.getPsi().getProject());
    return LanguageUtil.canStickTokensTogetherByLexer(left, right, lexer, 0);
  }

  @NotNull
  public PsiElement createElement(ASTNode node) {
    final IElementType type = node.getElementType();
    if (type == JSElementTypes.FUNCTION_DECLARATION) {
      return new JSFunctionImpl(node);
    }
    else if (type == JSElementTypes.PARAMETER_LIST) {
      return new JSParameterListImpl(node);
    }
    else if (type == JSElementTypes.VARIABLE) {
      return new JSVariableImpl(node);
    }
    else if (type == JSElementTypes.FORMAL_PARAMETER) {
      return new JSParameterImpl(node);
    }
    else if (type == JSElementTypes.ARGUMENT_LIST) {
      return new JSArgumentListImpl(node);
    }
    else if (type == JSElementTypes.ATTRIBUTE_LIST) {
      return new JSAttributeListImpl(node);
    }
    else if (type == JSElementTypes.ATTRIBUTE) {
      return new JSAttributeImpl(node);
    } else if (type == JSElementTypes.ATTRIBUTE_NAME_VALUE_PAIR) {
      return new JSAttributeNameValuePairImpl(node);
    }
    else if (type == JSElementTypes.PACKAGE_STATEMENT) {
      return new JSPackageStatementImpl(node);
    }
    else if (type == JSElementTypes.IMPORT_STATEMENT) {
      return new JSImportStatementImpl(node);
    } else if (type == JSElementTypes.CLASS) {
      return new JSClassImpl(node);
    } else if (type == JSElementTypes.REFERENCE_LIST) {
      return new JSReferenceListImpl(node);
    } else if (type == JSElementTypes.USE_NAMESPACE_DIRECTIVE) {
      return new JSUseNamespaceDirectiveImpl(node);
    } else if (type == JSElementTypes.INCLUDE_DIRECTIVE) {
      return new JSIncludeDirectiveImpl(node);
    } else if (type == JSElementTypes.NAMESPACE_DECLARATION) {
      return new JSNamespaceDeclarationImpl(node);
    }
    else if (type == JSElementTypes.BLOCK) {
      return new JSBlockStatementImpl(node);
    }
    else if (type == JSElementTypes.LABELED_STATEMENT) {
      return new JSLabeledStatementImpl(node);
    }
    else if (type == JSElementTypes.EXPRESSION_STATEMENT) {
      return new JSExpressionStatementImpl(node);
    }
    else if (type == JSElementTypes.VAR_STATEMENT) {
      return new JSVarStatementImpl(node);
    }
    else if (type == JSElementTypes.EMPTY_STATEMENT) {
      return new JSEmptyStatementImpl(node);
    }
    else if (type == JSElementTypes.IF_STATEMENT) {
      return new JSIfStatementImpl(node);
    }
    else if (type == JSElementTypes.CONTINUE_STATEMENT) {
      return new JSContinueStatementImpl(node);
    }
    else if (type == JSElementTypes.BREAK_STATEMENT) {
      return new JSBreakStatementImpl(node);
    }
    else if (type == JSElementTypes.WITH_STATEMENT) {
      return new JSWithStatementImpl(node);
    }
    else if (type == JSElementTypes.RETURN_STATEMENT) {
      return new JSReturnStatementImpl(node);
    }
    else if (type == JSElementTypes.THROW_STATEMENT) {
      return new JSThrowStatementImpl(node);
    }
    else if (type == JSElementTypes.TRY_STATEMENT) {
      return new JSTryStatementImpl(node);
    }
    else if (type == JSElementTypes.CATCH_BLOCK) {
      return new JSCatchBlockImpl(node);
    }
    else if (type == JSElementTypes.SWITCH_STATEMENT) {
      return new JSSwitchStatementImpl(node);
    }
    else if (type == JSElementTypes.CASE_CLAUSE) {
      return new JSCaseClauseImpl(node);
    }
    else if (type == JSElementTypes.WHILE_STATEMENT) {
      return new JSWhileStatementImpl(node);
    }
    else if (type == JSElementTypes.DOWHILE_STATEMENT) {
      return new JSDoWhileStatementImpl(node);
    }
    else if (type == JSElementTypes.FOR_STATEMENT) {
      return new JSForStatementImpl(node);
    }
    else if (type == JSElementTypes.FOR_IN_STATEMENT) {
      return new JSForInStatementImpl(node);
    }
    else if (type == JSElementTypes.THIS_EXPRESSION) {
      return new JSThisExpressionImpl(node);
    }
    else if (type == JSElementTypes.SUPER_EXPRESSION) {
      return new JSSuperExpressionImpl(node);
    }
    else if (type == JSElementTypes.LITERAL_EXPRESSION) {
      return new JSLiteralExpressionImpl(node);
    } else if (type == JSElementTypes.XML_LITERAL_EXPRESSION) {
      return new JSXmlLiteralExpressionImpl(node);
    }
    else if (type == JSElementTypes.REFERENCE_EXPRESSION) {
      return new JSReferenceExpressionImpl(node);
    } else if (type == JSElementTypes.GWT_REFERENCE_EXPRESSION) {
      return new JSGwtReferenceExpressionImpl(node);
    }
    else if (type == JSElementTypes.DEFINITION_EXPRESSION) {
      return new JSDefinitionExpressionImpl(node);
    }
    else if (type == JSElementTypes.PARENTHESIZED_EXPRESSION) {
      return new JSParenthesizedExpressionImpl(node);
    }
    else if (type == JSElementTypes.ARRAY_LITERAL_EXPRESSION) {
      return new JSArrayLiteralExpressionImpl(node);
    }
    else if (type == JSElementTypes.OBJECT_LITERAL_EXPRESSION) {
      return new JSObjectLiteralExpressionImpl(node);
    }
    else if (type == JSElementTypes.PROPERTY) {
      return new JSPropertyImpl(node);
    }
    else if (type == JSElementTypes.BINARY_EXPRESSION) {
      return new JSBinaryExpressionImpl(node);
    }
    else if (type == JSElementTypes.ASSIGNMENT_EXPRESSION) {
      return new JSAssignmentExpressionImpl(node);
    }
    else if (type == JSElementTypes.COMMA_EXPRESSION) {
      return new JSCommaExpressionImpl(node);
    }
    else if (type == JSElementTypes.CONDITIONAL_EXPRESSION) {
      return new JSConditionalExpressionImpl(node);
    }
    else if (type == JSElementTypes.POSTFIX_EXPRESSION) {
      return new JSPostfixExpressionImpl(node);
    }
    else if (type == JSElementTypes.PREFIX_EXPRESSION) {
      return new JSPrefixExpressionImpl(node);
    }
    else if (type == JSElementTypes.FUNCTION_EXPRESSION) {
      return new JSFunctionExpressionImpl(node);
    }
    else if (type == JSElementTypes.NEW_EXPRESSION) {
      return new JSNewExpressionImpl(node);
    }
    else if (type == JSElementTypes.INDEXED_PROPERTY_ACCESS_EXPRESSION) {
      return new JSIndexedPropertyAccessExpressionImpl(node);
    }
    else if (type == JSElementTypes.CALL_EXPRESSION) {
      return new JSCallExpressionImpl(node);
    }
    else if (type == JSElementTypes.EMBEDDED_CONTENT) {
      return new JSEmbeddedContentImpl(node);
    } else if (type == JSTokenTypes.XML_JS_SCRIPT ||
               type == JSElementTypes.EMBEDDED_EXPRESSION
              ) {
      return new JSEmbeddedContentImpl(node);
    } else if (type == JSTokenTypes.DOC_COMMENT2) {
      return new JSEmbeddedContentImpl(node);
    }

    return new ASTWrapperPsiElement(node);
  }
}
