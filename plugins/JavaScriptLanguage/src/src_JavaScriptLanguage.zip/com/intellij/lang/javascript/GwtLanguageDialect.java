/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript;

import com.intellij.lang.ParserDefinition;
import com.intellij.lang.refactoring.NamesValidator;
import com.intellij.lexer.Lexer;
import com.intellij.openapi.editor.colors.CodeInsightColors;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.fileTypes.SyntaxHighlighter;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.tree.IElementType;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;

/**
 * @author nik
*/
class GwtLanguageDialect extends JSLanguageDialect {
  private JSNamesValidator myNamesValidator;
  private JavascriptParserDefinition myParserDefinition;
  public static final DialectOptionHolder DIALECT_OPTION_HOLDER = new DialectOptionHolder(false, true);
  private JSHighlighter myHighlighter;

  public GwtLanguageDialect() {
    super("GWT JavaScript", JavaScriptSupportLoader.JAVASCRIPT.getLanguage());
  }

  @NonNls
  public String getFileExtension() {
    return "GwtJavaScript";
  }

  @Nullable
  public ParserDefinition getParserDefinition() {
    if (myParserDefinition == null) {
      myParserDefinition = new JavascriptParserDefinition() {
        @NotNull
        public Lexer createLexer(final Project project) {
          return new JavaScriptParsingLexer(DIALECT_OPTION_HOLDER);
        }
      };
    }
    return myParserDefinition;
  }

  @NotNull
  public NamesValidator getNamesValidator() {
    if (myNamesValidator == null){
      myNamesValidator = new JSNamesValidator(DIALECT_OPTION_HOLDER);
    }
    return myNamesValidator;
  }

  @NotNull
  public SyntaxHighlighter getSyntaxHighlighter(Project project, final VirtualFile virtualFile) {
    if (myHighlighter == null) {
      myHighlighter = new GwtSyntaxHighlighter();
    }
    return myHighlighter;
  }

  private static class GwtSyntaxHighlighter extends JSHighlighter {
    private Map<IElementType, TextAttributesKey> myKeysMap = new HashMap<IElementType, TextAttributesKey>();

    public GwtSyntaxHighlighter() {
      super(GwtLanguageDialect.DIALECT_OPTION_HOLDER);
      myKeysMap.put(JSTokenTypes.COLON_COLON, JS_OPERATION_SIGN);
      myKeysMap.put(JSTokenTypes.GWT_FIELD_OR_METHOD, CodeInsightColors.METHOD_CALL_ATTRIBUTES);
      myKeysMap.put(JSTokenTypes.AT, JS_OPERATION_SIGN);
      myKeysMap.put(JSTokenTypes.IDENTIFIER, CodeInsightColors.CLASS_NAME_ATTRIBUTES);
    }

    @NotNull
  public TextAttributesKey[] getTokenHighlights(final IElementType tokenType) {
      if (myKeysMap.containsKey(tokenType)) {
        return pack(myKeysMap.get(tokenType));
      }
      return super.getTokenHighlights(tokenType);
    }
  }

}
