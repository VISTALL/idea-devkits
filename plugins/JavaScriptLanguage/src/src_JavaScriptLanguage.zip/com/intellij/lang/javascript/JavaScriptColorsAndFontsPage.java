package com.intellij.lang.javascript;

import com.intellij.openapi.options.colors.AttributesDescriptor;
import com.intellij.openapi.options.colors.ColorDescriptor;
import com.intellij.openapi.options.colors.ColorSettingsPage;
import com.intellij.openapi.fileTypes.SyntaxHighlighter;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: Maxim.Mossienko
 * Date: Nov 2, 2005
 * Time: 10:12:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class JavaScriptColorsAndFontsPage implements ColorSettingsPage {
  private static final AttributesDescriptor[] ATTRS;

  static {
    ATTRS = new AttributesDescriptor[]{
      new AttributesDescriptor(JSBundle.message("javascript.keyword"), JSHighlighter.JS_KEYWORD),
      new AttributesDescriptor(JSBundle.message("javascript.string"), JSHighlighter.JS_STRING),
      new AttributesDescriptor(JSBundle.message("javascript.valid.string.escape"), JSHighlighter.JS_VALID_STRING_ESCAPE),
      new AttributesDescriptor(JSBundle.message("javascript.invalid.string.escape"), JSHighlighter.JS_INVALID_STRING_ESCAPE),
      new AttributesDescriptor(JSBundle.message("javascript.number"), JSHighlighter.JS_NUMBER),
      new AttributesDescriptor(JSBundle.message("javascript.regexp"), JSHighlighter.JS_REGEXP),
      new AttributesDescriptor(JSBundle.message("javascript.linecomment"), JSHighlighter.JS_LINE_COMMENT),
      new AttributesDescriptor(JSBundle.message("javascript.blockcomment"), JSHighlighter.JS_BLOCK_COMMENT),
      new AttributesDescriptor(JSBundle.message("javascript.doccomment"), JSHighlighter.JS_DOC_COMMENT),
      new AttributesDescriptor(JSBundle.message("javascript.operation"), JSHighlighter.JS_OPERATION_SIGN),
      new AttributesDescriptor(JSBundle.message("javascript.parens"), JSHighlighter.JS_PARENTHS),
      new AttributesDescriptor(JSBundle.message("javascript.brackets"), JSHighlighter.JS_BRACKETS),
      new AttributesDescriptor(JSBundle.message("javascript.braces"), JSHighlighter.JS_BRACES),
      new AttributesDescriptor(JSBundle.message("javascript.comma"), JSHighlighter.JS_COMMA),
      new AttributesDescriptor(JSBundle.message("javascript.dot"), JSHighlighter.JS_DOT),
      new AttributesDescriptor(JSBundle.message("javascript.semicolon"), JSHighlighter.JS_SEMICOLON),
      new AttributesDescriptor(JSBundle.message("javascript.badcharacter"), JSHighlighter.JS_BAD_CHARACTER),
      new AttributesDescriptor(JSBundle.message("javascript.docmarkup"), JSHighlighter.JS_DOC_MARKUP),
      new AttributesDescriptor(JSBundle.message("javascript.doctag"), JSHighlighter.JS_DOC_TAG),
    };
  }

  private static final ColorDescriptor[] COLORS = new ColorDescriptor[0];

  @NotNull
  public String getDisplayName() {
    //noinspection HardCodedStringLiteral
    return "Java Script";
  }

  public Icon getIcon() {
    return JavaScriptSupportLoader.JAVASCRIPT.getIcon();
  }

  @NotNull
  public AttributesDescriptor[] getAttributeDescriptors() {
    return ATTRS;
  }

  @NotNull
  public ColorDescriptor[] getColorDescriptors() {
    return COLORS;
  }

  @NotNull
  public SyntaxHighlighter getHighlighter() {
    return JavaScriptSupportLoader.JAVASCRIPT.getHighlighter(null, null);
  }

  @NotNull
  public String getDemoText() {
    return "/**\n" +
           " * Constructor for <code>AjaxRequest</code> class\n" +
           " * @param url the url for the request<p/>\n" +
           " */\n" +
           "function AjaxRequest(url) {\n" +
           "  var urls = [ \"www.cnn.com\", 5];\n" +
           "  this.request = new XMLHttpRequest();\n" +
           "  url = url.replace(/^\\s*(.*)/, \"$1\"); // skip leading whitespace\n" +
           "  /* check the url to be in urls */\n" +
           "  var a = \"\\u1111\\z\\n\\u11\";\n" +
           "  #\n"+
           "}";
  }

  public Map<String, TextAttributesKey> getAdditionalHighlightingTagToDescriptorMap() {
    return null;
  }
}
