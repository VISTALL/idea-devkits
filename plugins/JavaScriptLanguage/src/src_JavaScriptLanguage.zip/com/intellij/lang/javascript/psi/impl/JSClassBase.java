/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi.impl;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.index.JSNamedElementProxy;
import com.intellij.lang.javascript.index.JavaScriptIndex;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.ResolveProcessor;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiElementVisitor;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiSubstitutor;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.util.Icons;
import com.intellij.util.IncorrectOperationException;
import gnu.trove.THashMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @by Maxim.Mossienko
 */
public abstract class JSClassBase extends JSElementImpl implements JSClass {
  private volatile Map<String,JSFunction> myName2FunctionMap;

  protected JSClassBase(final ASTNode node) {
    super(node);
  }

  public void accept(@NotNull PsiElementVisitor visitor) {
    if (visitor instanceof JSElementVisitor) {
      ((JSElementVisitor)visitor).visitJSClass(this);
    }
    else {
      visitor.visitElement(this);
    }
  }

  public void subtreeChanged() {
    dropCaches();

    super.subtreeChanged();
  }

  protected Object clone() {
    final JSClassBase o = (JSClassBase)super.clone();
    o.dropCaches();
    return o;
  }

  private void dropCaches() {
    myName2FunctionMap = null;
  }

  public JSFunction[] getFunctions() {
    final List<JSFunction> functions = new ArrayList<JSFunction>();
    processDeclarations(new PsiScopeProcessor() {
      public boolean execute(final PsiElement element, final PsiSubstitutor substitutor) {
        if (element instanceof JSFunction) functions.add((JSFunction)element);
        return true;
      }

      public <T> T getHint(final Class<T> hintClass) {
        return null;
      }

      public void handleEvent(final Event event, final Object associated) {
      }
    }, PsiSubstitutor.EMPTY, this, this);
    return functions.toArray(JSFunction.EMPTY_ARRAY);
  }

  public JSFunction findFunctionByName(String functionName) {
    if (functionName == null) return null;
    Map<String,JSFunction> name2FunctionMap = myName2FunctionMap;

    if (name2FunctionMap == null) {
      name2FunctionMap = new THashMap<String, JSFunction>();
      for(JSFunction function:getFunctions()) {
        final String name = function.getName();
        if (name != null) name2FunctionMap.put(name, function);
      }
      myName2FunctionMap = name2FunctionMap;
    }
    return name2FunctionMap.get(functionName);
  }

  public JSClass[] getSupers() {
    List<JSClass> superClasses = getClassesFromReferenceList(getExtendsList(), true);
    superClasses.addAll(getClassesFromReferenceList(getImplementsList(), false));
    return superClasses.toArray(new JSClass[superClasses.size()]);
  }

  private List<JSClass> getClassesFromReferenceList(final @Nullable JSReferenceList extendsList, boolean extendList) {
    final ArrayList<JSClass> supers = new ArrayList<JSClass>(1);
    if (extendsList == null) {
      if (extendList && !"Object".equals(getQualifiedName())) {
        final PsiElement element = findClassFromNamespace("Object", JavaScriptIndex.getInstance(getProject()));
        if (element instanceof JSClass) supers.add((JSClass)element);
      }

      return supers;
    }

    for(JSReferenceExpression expr:extendsList.getExpressions()) {
      final String s = JSResolveUtil.resolveTypeName(expr.getText(), this);
      final PsiElement element = findClassFromNamespace(s, JavaScriptIndex.getInstance(getProject()));
      if (element instanceof JSClass) {
        supers.add((JSClass)element);
      }
    }
    return supers;
  }

  public boolean processDeclarations(@NotNull final PsiScopeProcessor processor,
                                     @NotNull final PsiSubstitutor substitutor,
                                     final PsiElement lastParent,
                                     @NotNull final PsiElement place) {
    processor.handleEvent(PsiScopeProcessor.Event.SET_DECLARATION_HOLDER, this);
    final ResolveProcessor resolveProcessor = processor instanceof ResolveProcessor ? (ResolveProcessor)processor:null;
    boolean toProcessClass = resolveProcessor != null && resolveProcessor.isTypeContext();

    if (toProcessClass) {
      if(!processor.execute(this, null)) return false;
    }

    if (lastParent == null) {
      return true;
    }

    boolean toProcessMembers = (resolveProcessor == null || (!resolveProcessor.isToSkipClassDeclarationOnce() && resolveProcessor.isToProcessMembers()));
    if (toProcessMembers) {
      if (!processMembers(processor, substitutor, lastParent, place)) return false;
    } else {
      resolveProcessor.setToSkipClassDeclarationsOnce(false);
    }

    final boolean toProcessInHierarchy = processor instanceof ResolveProcessor && ((ResolveProcessor)processor).isToProcessHierarchy();

    if (!toProcessInHierarchy || ((ResolveProcessor)processor).checkVisited(getQualifiedName())) return true;

    for(JSClass clazz:getSuperClasses()) {
      if (!clazz.processDeclarations(processor, PsiSubstitutor.EMPTY, lastParent, place)) return false;
    }

    return true;
  }

  protected abstract boolean processMembers(final PsiScopeProcessor processor, final PsiSubstitutor substitutor, final PsiElement lastParent,
                                 final PsiElement place);

  public JSClass[] getSuperClasses() {
    final JSReferenceList extendsList = getExtendsList();
    final List<JSClass> supers = getClassesFromReferenceList(extendsList, true);
    return supers.toArray(new JSClass[supers.size()]);
  }

  public static PsiElement findClassFromNamespace(final String qname, final JavaScriptIndex index) {
    PsiElement realClazz = null;
    final PsiElement clazz = JSResolveUtil.findClassByQName(qname, index);

    if (clazz instanceof JSNamedElementProxy) {
      final JSNamedElementProxy elementProxy = (JSNamedElementProxy)clazz;
      final JSNamedElementProxy.NamedItemType itemType = elementProxy.getType();

      if (itemType == JSNamedElementProxy.NamedItemType.Clazz) {
        realClazz = elementProxy.getElement();
      }
    } else {
      realClazz = clazz;
    }
    return realClazz;
  }

  protected void updateFileName(final String newName, final String oldName) throws IncorrectOperationException {
    final PsiFile containingFile = getContainingFile();

    if (containingFile.getContext() == null) {
      final VirtualFile virtualFile = containingFile.getVirtualFile();

      if (virtualFile != null && virtualFile.getNameWithoutExtension().equals(oldName)) {
        final String s = containingFile.getName();
        containingFile.setName(newName + "." + s.substring(s.lastIndexOf('.') + 1));
      }
    }
  }

  @Nullable
  public Icon getIcon(int flags) {
    final JSAttributeList attributeList = getAttributeList();
    final JSAttributeList.AccessType type = attributeList != null ? attributeList.getAccessType(): JSAttributeList.AccessType.PACKAGE_LOCAL;
    return buildIcon(isInterface() ? Icons.INTERFACE_ICON : Icons.CLASS_ICON,type.getIcon());
  }
}
