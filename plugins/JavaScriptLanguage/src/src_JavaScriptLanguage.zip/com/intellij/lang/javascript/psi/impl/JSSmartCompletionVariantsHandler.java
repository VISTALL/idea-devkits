package com.intellij.lang.javascript.psi.impl;

import com.intellij.javascript.documentation.JSDocumentationUtils;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.index.JSNamespace;
import com.intellij.lang.javascript.index.JSTypeEvaluateManager;
import com.intellij.lang.javascript.index.JavaScriptIndex;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.util.JSLookupUtil;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiSubstitutor;
import com.intellij.psi.ResolveResult;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import gnu.trove.THashMap;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Maxim.Mossienko
 * Date: Jan 25, 2008
 * Time: 12:40:48 AM
 */
public class JSSmartCompletionVariantsHandler {
  static Object[] getSmartVariants(final @NotNull PsiElement expr, final boolean ecma) {
    final PsiElement parent = expr.getParent();

    if (expr instanceof JSReferenceExpression &&
        ((JSReferenceExpression)expr).getQualifier() == null &&
        parent instanceof JSArgumentList &&
        ((JSArgumentList)parent).getArguments()[0] == expr &&
        ecma &&
        ((JSReferenceExpression)expr).getQualifier() == null
       ) {
      final JSExpression calledExpr = ((JSCallExpression) parent.getParent()).getMethodExpression();

      if (calledExpr instanceof JSReferenceExpression) {
        final JSReferenceExpression expression = (JSReferenceExpression)calledExpr;
        final @NonNls String s = expression.getReferencedName();

        if ("addEventListener".equals(s) || "removeElementListener".equals(s)) {
          final List<Object> variants = new ArrayList<Object>();
          final MyEventSubclassesProcessor subclassesProcessor = new MyEventSubclassesProcessor(expr, variants);
          subclassesProcessor.findAcceptableVariants(expression, parent.getProject());
          if (variants.size() > 0) return variants.toArray(new Object[variants.size()]);
        }
      }
    }

    return null;
  }

  private static class MyEventSubclassesProcessor implements JSTypeEvaluateManager.NamespaceProcessor, PsiScopeProcessor, JSResolveUtil.MetaDataProcessor {
    private final JavaScriptIndex index;
    private final PsiElement myExpr;
    private final List<Object> myVariants;
    private final Map<String, JSVariable> myCandidatesMap = new THashMap<String, JSVariable>();
    private PsiElement myClazz;
    private boolean findAcceptableEvents;

    public MyEventSubclassesProcessor(final PsiElement expr, final List<Object> variants) {
      myExpr = expr;
      myVariants = variants;
      index = JavaScriptIndex.getInstance(myExpr.getProject());
    }

    public boolean process(final JSNamespace jsNamespace) {
      if (findAcceptableEvents) {
        final PsiElement jsClazz = JSClassImpl.findClassFromNamespace(jsNamespace.getQualifiedName(index), index);
        if (jsClazz instanceof JSNamedElement) JSResolveUtil.processMetaAttributesForClass((JSNamedElement)jsClazz, this);
        return true;
      }

      final PsiElement clazz = JSClassImpl.findClassFromNamespace(jsNamespace.getQualifiedName(index), index);

      if (clazz instanceof JSClass) {
        myClazz = clazz;
        clazz.processDeclarations(this, PsiSubstitutor.EMPTY, clazz, clazz);
      }
      return true;
    }

    public boolean execute(final PsiElement element, final PsiSubstitutor substitutor) {
      if (element instanceof JSVariable) {
        final JSVariable variable = (JSVariable)element;
        final JSAttributeList attributeList = variable.getAttributeList();

        if (attributeList != null &&
            attributeList.getAccessType() == JSAttributeList.AccessType.PUBLIC &&
            attributeList.hasModifier(JSAttributeList.ModifierType.STATIC) &&
            "String".equals(JSDocumentationUtils.findVariableType(variable))
          ) {
          final JSExpression initializerExpression = variable.getInitializer();
          if (initializerExpression instanceof JSLiteralExpression) {
            myCandidatesMap.put(StringUtil.stripQuotesAroundValue(initializerExpression.getText()), variable);
          }
        }
      }
      return true;
    }

    public <T> T getHint(final Class<T> hintClass) {
      return null;
    }

    public void handleEvent(final Event event, final Object associated) {
    }

    public void findAcceptableVariants(JSReferenceExpression expression, final Project project) {
      final JSExpression qualifier = expression.getQualifier();
      JSTypeEvaluateManager.getInstance(project).iterateSubclasses(
        "flash.events.Event", this,
        true
      );

      JSClass clazzToProcess = null;

      if (qualifier instanceof JSThisExpression || qualifier instanceof JSSuperExpression) {
        clazzToProcess = PsiTreeUtil.getParentOfType(qualifier, JSClass.class);
      } else if (qualifier instanceof JSReferenceExpression) {
        final ResolveResult[] results = ((JSReferenceExpression)qualifier).multiResolve(false);
        if (results.length > 0 && results[0].getElement() instanceof JSClass) {
          clazzToProcess = (JSClass) results[0].getElement();
        }
      }

      if (clazzToProcess == null) {
        final PsiElement context = expression.getContainingFile().getContext();
        clazzToProcess = JSResolveUtil.getClassFromTagNameInMxml(context);
        if (clazzToProcess == null && context != null) {
          XmlFile file = PsiTreeUtil.getParentOfType(context, XmlFile.class);
          if (file != null) {
            final XmlTag rootTag = file.getDocument().getRootTag();
            final XmlTag[] tags = rootTag != null ?rootTag.findSubTags("Metadata", JavaScriptSupportLoader.MXML_URI): XmlTag.EMPTY;
            final MyJSInjectedFilesVisitor injectedFilesVisitor = new MyJSInjectedFilesVisitor();

            for(XmlTag tag: tags) {
              JSResolveUtil.processInjectedFileForTag(tag, injectedFilesVisitor);
            }
          }
        }
      }

      if (clazzToProcess != null) {
        findAcceptableEvents = true;
        JSResolveUtil.processMetaAttributesForClass(clazzToProcess, this);
        JSTypeEvaluateManager.getInstance(project).iterateTypeHierarchy(clazzToProcess.getQualifiedName(), this);
      }
    }

    public boolean process(final @NotNull JSAttribute jsAttribute) {
      if ("Event".equals(jsAttribute.getName())) {
        final JSAttributeNameValuePair eventName = jsAttribute.getValueByName("name");

        if (eventName != null) {
          final String value = eventName.getSimpleValue();
          final JSVariable variable = myCandidatesMap.get(value);

          if (variable != null) {
            myCandidatesMap.remove(value);
            myVariants.add(
              JSLookupUtil.getInstance().createPrioritizedLookupItem(
                variable,
                ((JSClass)variable.getParent().getParent()).getName() + "." + variable.getName(),
                3
              )
            );
          }
        }
      }
      return true;
    }

    private class MyJSInjectedFilesVisitor extends JSResolveUtil.JSInjectedFilesVisitor {
      protected void process(final JSFile file) {
        for(PsiElement element:file.getChildren()) {
          if (element instanceof JSAttributeList) {
            JSResolveUtil.processAttributeList(MyEventSubclassesProcessor.this, null, (JSAttributeList)element, true);
          }
        }
      }
    }
  }
}
