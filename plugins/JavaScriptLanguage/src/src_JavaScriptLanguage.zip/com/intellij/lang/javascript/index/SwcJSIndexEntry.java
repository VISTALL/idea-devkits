package com.intellij.lang.javascript.index;

import com.intellij.lang.javascript.flex.FlexImporter;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.ModificationTracker;
import com.intellij.openapi.vfs.JarFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiFile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;

/**
 * @by yole, maxim.mossienko
 */
public final class SwcJSIndexEntry extends JSIndexEntry {
  private VirtualFile file;
  private static Key<VirtualFile> ourOriginalFileKey = Key.create("original.file");

  public SwcJSIndexEntry(final DeserializationContext context, @Nullable VirtualFile file) throws IOException {
    super(context, file);
  }

  public SwcJSIndexEntry(final @NotNull VirtualFile file, Project project, boolean lazy) {
    super(file, project, lazy);
  }

  protected PsiFile buildPsiFileFromFile(final Object constructionData, final Project project) {
    assert constructionData instanceof VirtualFile;
    file = (VirtualFile)constructionData;
    if (file != null) {
      final VirtualFile jarRoot = JarFileSystem.getInstance().getJarRootForLocalFile(file);
      final VirtualFile child = jarRoot != null ? jarRoot.findChild("library.swf"):null;
      if (child != null) {
        try {
          String s = FlexImporter.buildInterfaceFromStream(child.getInputStream());
          final PsiFile fileFromText = PredefinedJSIndexEntry.createReadOnlyFileFromText(s, project, file.getPath() + ".as");
          fileFromText.putUserData( ourOriginalFileKey, file);
          return fileFromText;
        }
        catch (IOException ex) {
          throw new RuntimeException(ex);
        }
      }
    }
    return null;
  }

  public long getTimeStamp() {
    return file.getTimeStamp();
  }

  VirtualFile getVirtualFile() {
    return file;
  }

  public static ModificationTracker getOriginalFile(final PsiFile containingFile) {
    return containingFile.getUserData(ourOriginalFileKey);
  }
}