/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.parsing;

import com.intellij.lang.PsiBuilder;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.psi.tree.IElementType;

/**
 * @author max
 */
public class StatementParsing extends Parsing{
  private static final Logger LOG = Logger.getInstance("#com.intellij.lang.javascript.parsing.StatementParsing");
  private StatementParsing() { }

  public static void parseSourceElement(PsiBuilder builder) {
    if (builder.getTokenType() == JSTokenTypes.FUNCTION_KEYWORD) {
      FunctionParsing.parseFunctionDeclaration(builder);
    }
    else {
      parseStatement(builder);
    }
  }

  public static void parseStatement(PsiBuilder builder) {
    final IElementType firstToken = builder.getTokenType();

    if (firstToken == null) return;

    if (firstToken == JSTokenTypes.LBRACE) {
      parseBlock(builder);
      return;
    }

    if (firstToken == JSTokenTypes.VAR_KEYWORD || firstToken == JSTokenTypes.CONST_KEYWORD) {
      parseVarStatement(builder, false);
      return;
    }

    if (firstToken == JSTokenTypes.SEMICOLON) {
      parseEmptyStatement(builder);
      return;
    }

    if (firstToken == JSTokenTypes.IF_KEYWORD) {
      parseIfStatement(builder);
      return;
    }

    if (firstToken == JSTokenTypes.DO_KEYWORD ||
        firstToken == JSTokenTypes.WHILE_KEYWORD ||
        firstToken == JSTokenTypes.FOR_KEYWORD) {
      parseIterationStatement(builder);
      return;
    }

    if (firstToken == JSTokenTypes.CONTINUE_KEYWORD) {
      parseContinueStatement(builder);
      return;
    }

    if (firstToken == JSTokenTypes.BREAK_KEYWORD) {
      parseBreakStatement(builder);
      return;
    }

    if (firstToken == JSTokenTypes.RETURN_KEYWORD) {
      parseReturnStatement(builder);
      return;
    }

    if (firstToken == JSTokenTypes.WITH_KEYWORD) {
      parseWithStatement(builder);
      return;
    }

    if (firstToken == JSTokenTypes.SWITCH_KEYWORD) {
      parseSwitchStatement(builder);
      return;
    }

    if (firstToken == JSTokenTypes.THROW_KEYWORD) {
      parseThrowStatement(builder);
      return;
    }

    if (firstToken == JSTokenTypes.TRY_KEYWORD) {
      parseTryStatement(builder);
      return;
    }

    if (firstToken == JSTokenTypes.FUNCTION_KEYWORD) {
      FunctionParsing.parseFunctionDeclaration(builder);
      return;
    }


    if (firstToken == JSTokenTypes.IDENTIFIER) {
      // Try labeled statement:
      final PsiBuilder.Marker labeledStatement = builder.mark();
      builder.advanceLexer();
      if (builder.getTokenType() == JSTokenTypes.COLON) {
        builder.advanceLexer();
        parseStatement(builder);
        labeledStatement.done(JSElementTypes.LABELED_STATEMENT);
        return;
      }
      else {
        labeledStatement.rollbackTo();
      }
    }

    if (firstToken != JSTokenTypes.LBRACE && firstToken != JSTokenTypes.FUNCTION_KEYWORD) {
      // Try expression statement
      final PsiBuilder.Marker exprStatement = builder.mark();
      if (ExpressionParsing.parseExpressionOptional(builder)) {
        checkForSemicolon(builder);
        exprStatement.done(JSElementTypes.EXPRESSION_STATEMENT);
        return;
      }
      else {
        exprStatement.drop();
      }
    }

    builder.advanceLexer();
    builder.error(JSBundle.message("javascript.parser.message.expected.statement"));
  }

  private static void parseTryStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.TRY_KEYWORD);
    final PsiBuilder.Marker statement = builder.mark();
    builder.advanceLexer();
    parseBlock(builder);

    if (builder.getTokenType() == JSTokenTypes.CATCH_KEYWORD) {
      parseCatchBlock(builder);
    }

    if (builder.getTokenType() == JSTokenTypes.FINALLY_KEYWORD) {
      builder.advanceLexer();
      parseBlock(builder);
    }

    statement.done(JSElementTypes.TRY_STATEMENT);
  }

  private static void parseCatchBlock(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.CATCH_KEYWORD);
    final PsiBuilder.Marker block = builder.mark();
    builder.advanceLexer();
    checkMatches(builder, JSTokenTypes.LPAR, JSBundle.message("javascript.parser.message.expected.lparen"));

    if (builder.getTokenType() == JSTokenTypes.IDENTIFIER) {
      final PsiBuilder.Marker param = builder.mark();
      builder.advanceLexer();
      param.done(JSElementTypes.FORMAL_PARAMETER);
    }
    else {
      builder.error(JSBundle.message("javascript.parser.message.expected.parameter.name"));
    }

    checkMatches(builder, JSTokenTypes.RPAR, JSBundle.message("javascript.parser.message.expected.rparen"));

    parseBlock(builder);

    block.done(JSElementTypes.CATCH_BLOCK);
  }

  private static void parseThrowStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.THROW_KEYWORD);
    final PsiBuilder.Marker statement = builder.mark();
    builder.advanceLexer();

    ExpressionParsing.parseExpressionOptional(builder);

    checkForSemicolon(builder);
    statement.done(JSElementTypes.THROW_STATEMENT);
  }

  private static void parseSwitchStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.SWITCH_KEYWORD);
    final PsiBuilder.Marker statement = builder.mark();
    builder.advanceLexer();

    checkMatches(builder, JSTokenTypes.LPAR, JSBundle.message("javascript.parser.message.expected.lparen"));
    ExpressionParsing.parseExpression(builder);
    checkMatches(builder, JSTokenTypes.RPAR, JSBundle.message("javascript.parser.message.expected.rparen"));

    checkMatches(builder, JSTokenTypes.LBRACE, JSBundle.message("javascript.parser.message.expected.lbrace"));
    while (builder.getTokenType() != JSTokenTypes.RBRACE) {
      if (builder.eof()) {
        builder.error(JSBundle.message("javascript.parser.message.unexpected.end.of.file"));
        statement.done(JSElementTypes.SWITCH_STATEMENT);
        return;
      }
      parseCaseOrDefaultClause(builder);
    }

    builder.advanceLexer();
    statement.done(JSElementTypes.SWITCH_STATEMENT);
  }

  private static void parseCaseOrDefaultClause(final PsiBuilder builder) {
    final IElementType firstToken = builder.getTokenType();
    final PsiBuilder.Marker clause = builder.mark();
    if (firstToken != JSTokenTypes.CASE_KEYWORD && firstToken != JSTokenTypes.DEFAULT_KEYWORD) {
      builder.error(JSBundle.message("javascript.parser.message.expected.catch.or.default"));
    }
    builder.advanceLexer();
    if (firstToken == JSTokenTypes.CASE_KEYWORD) {
      ExpressionParsing.parseExpression(builder);
    }
    checkMatches(builder, JSTokenTypes.COLON, JSBundle.message("javascript.parser.message.expected.colon"));
    while (true) {
      IElementType token = builder.getTokenType();
      if (token == null || token == JSTokenTypes.CASE_KEYWORD || token == JSTokenTypes.DEFAULT_KEYWORD || token == JSTokenTypes.RBRACE) break;
      parseStatement(builder);
    }
    clause.done(JSElementTypes.CASE_CLAUSE);
  }

  private static void parseWithStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.WITH_KEYWORD);
    final PsiBuilder.Marker statement = builder.mark();
    builder.advanceLexer();

    checkMatches(builder, JSTokenTypes.LPAR, JSBundle.message("javascript.parser.message.expected.lparen"));
    ExpressionParsing.parseExpression(builder);
    checkMatches(builder, JSTokenTypes.RPAR, JSBundle.message("javascript.parser.message.expected.rparen"));

    parseStatement(builder);

    statement.done(JSElementTypes.WITH_STATEMENT);
  }

  private static void parseReturnStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.RETURN_KEYWORD);
    final PsiBuilder.Marker statement = builder.mark();
    builder.advanceLexer();
    boolean hasNewLine = builder.getTokenType() == JSTokenTypes.SEMANTIC_LINEFEED;

    if(!hasNewLine) {
      ExpressionParsing.parseExpressionOptional(builder);

      checkForSemicolon(builder);
    }
    statement.done(JSElementTypes.RETURN_STATEMENT);

    if (hasNewLine) builder.advanceLexer();
  }

  private static void parseBreakStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.BREAK_KEYWORD);
    final PsiBuilder.Marker statement = builder.mark();
    builder.advanceLexer();

    if (builder.getTokenType() == JSTokenTypes.IDENTIFIER) {
      builder.advanceLexer();
    }

    if (builder.getTokenType() == JSTokenTypes.SEMICOLON || builder.getTokenType() == JSTokenTypes.SEMANTIC_LINEFEED) {
      builder.advanceLexer();
    }

    statement.done(JSElementTypes.BREAK_STATEMENT);
  }

  private static void parseContinueStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.CONTINUE_KEYWORD);
    final PsiBuilder.Marker statement = builder.mark();
    builder.advanceLexer();
    if (builder.getTokenType() == JSTokenTypes.IDENTIFIER) {
      builder.advanceLexer();
    }

    if (builder.getTokenType() == JSTokenTypes.SEMICOLON || builder.getTokenType() == JSTokenTypes.SEMANTIC_LINEFEED) {
      builder.advanceLexer();
    }

    statement.done(JSElementTypes.CONTINUE_STATEMENT);
  }

  private static void parseIterationStatement(final PsiBuilder builder) {
    final IElementType tokenType = builder.getTokenType();
    if (tokenType == JSTokenTypes.DO_KEYWORD) {
      parseDoWhileStatement(builder);
    }
    else if (tokenType == JSTokenTypes.WHILE_KEYWORD) {
      parseWhileStatement(builder);
    }
    else if (tokenType == JSTokenTypes.FOR_KEYWORD) {
      parseForStatement(builder);
    }
    else {
      LOG.error("Unknown iteration statement");
    }
  }

  private static void parseForStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.FOR_KEYWORD);
    final PsiBuilder.Marker statement = builder.mark();
    builder.advanceLexer();
    checkMatches(builder, JSTokenTypes.LPAR, JSBundle.message("javascript.parser.message.expected.lparen"));
    final boolean empty;
    if (builder.getTokenType() == JSTokenTypes.VAR_KEYWORD) {
      parseVarStatement(builder, true);
      empty = false;
    }
    else {
      empty = !ExpressionParsing.parseExpressionOptional(builder, false);
    }

    boolean forin = false;
    if (builder.getTokenType() == JSTokenTypes.SEMICOLON) {
      builder.advanceLexer();
      ExpressionParsing.parseExpressionOptional(builder);
      
      if (builder.getTokenType() == JSTokenTypes.SEMICOLON) {
        builder.advanceLexer();
      } else {
        builder.error(JSBundle.message("javascript.parser.message.expected.semicolon"));
      }
      ExpressionParsing.parseExpressionOptional(builder);
    }
    else if (builder.getTokenType() == JSTokenTypes.IN_KEYWORD) {
      forin = true;
      if (empty) builder.error(JSBundle.message("javascript.parser.message.expected.forloop.left.hand.side.expression.or.variable.declaration"));
      builder.advanceLexer();
      ExpressionParsing.parseExpression(builder);
    }
    else {
      builder.error(JSBundle.message("javascript.parser.message.expected.forloop.in.or.semicolon"));
    }

    checkMatches(builder, JSTokenTypes.RPAR, JSBundle.message("javascript.parser.message.expected.rparen"));

    parseStatement(builder);
    statement.done(forin ? JSElementTypes.FOR_IN_STATEMENT : JSElementTypes.FOR_STATEMENT);
  }

  private static void parseWhileStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.WHILE_KEYWORD);
    final PsiBuilder.Marker statement = builder.mark();
    builder.advanceLexer();

    checkMatches(builder, JSTokenTypes.LPAR, JSBundle.message("javascript.parser.message.expected.lparen"));
    ExpressionParsing.parseExpression(builder);
    checkMatches(builder, JSTokenTypes.RPAR, JSBundle.message("javascript.parser.message.expected.rparen"));

    parseStatement(builder);
    statement.done(JSElementTypes.WHILE_STATEMENT);
  }

  private static void parseDoWhileStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.DO_KEYWORD);
    final PsiBuilder.Marker statement = builder.mark();
    builder.advanceLexer();

    parseStatement(builder);
    checkMatches(builder, JSTokenTypes.WHILE_KEYWORD, JSBundle.message("javascript.parser.message.expected.while.keyword"));
    checkMatches(builder, JSTokenTypes.LPAR, JSBundle.message("javascript.parser.message.expected.lparen"));
    ExpressionParsing.parseExpression(builder);
    checkMatches(builder, JSTokenTypes.RPAR, JSBundle.message("javascript.parser.message.expected.rparen"));
    checkForSemicolon(builder);

    statement.done(JSElementTypes.DOWHILE_STATEMENT);
  }

  private static void parseIfStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.IF_KEYWORD);
    final PsiBuilder.Marker ifStatement = builder.mark();
    builder.advanceLexer();

    checkMatches(builder, JSTokenTypes.LPAR, JSBundle.message("javascript.parser.message.expected.lparen"));
    ExpressionParsing.parseExpression(builder);
    
    // handle empty expressions inside
    while (builder.getTokenType() == JSTokenTypes.OROR || builder.getTokenType() == JSTokenTypes.EQEQ) {
      builder.advanceLexer();
    }
    
    checkMatches(builder, JSTokenTypes.RPAR, JSBundle.message("javascript.parser.message.expected.rparen"));

    parseStatement(builder);

    if (builder.getTokenType() == JSTokenTypes.ELSE_KEYWORD) {
      builder.advanceLexer();
      parseStatement(builder);
    }

    ifStatement.done(JSElementTypes.IF_STATEMENT);
  }

  private static void parseEmptyStatement(final PsiBuilder builder) {
    LOG.assertTrue(builder.getTokenType() == JSTokenTypes.SEMICOLON);
    final PsiBuilder.Marker statement = builder.mark();
    builder.advanceLexer();
    statement.done(JSElementTypes.EMPTY_STATEMENT);
  }

  private static void parseVarStatement(final PsiBuilder builder, final boolean inForInitializationContext) {
    final IElementType declType = builder.getTokenType();
    LOG.assertTrue(declType == JSTokenTypes.VAR_KEYWORD || declType == JSTokenTypes.CONST_KEYWORD);
    final PsiBuilder.Marker var = builder.mark();
    builder.advanceLexer();
    boolean first = true;
    while (true) {
      if (first) {
        first = false;
      }
      else {
        checkMatches(builder, JSTokenTypes.COMMA, JSBundle.message("javascript.parser.message.expected.comma"));
      }

      parseVarDeclaration(builder, !inForInitializationContext);

      if (builder.getTokenType() != JSTokenTypes.COMMA) {
        break;
      }
    }

    if (!inForInitializationContext) {
      checkForSemicolon(builder);
    }

    var.done(JSElementTypes.VAR_STATEMENT);
  }

  private static void checkForSemicolon(final PsiBuilder builder) {
    if (builder.getTokenType() == JSTokenTypes.SEMICOLON) {
      builder.advanceLexer();
    }
  }

  private static void parseVarDeclaration(final PsiBuilder builder, boolean allowIn) {
    if (builder.getTokenType() != JSTokenTypes.IDENTIFIER) {
      builder.error(JSBundle.message("javascript.parser.message.expected.variable.name"));
      builder.advanceLexer();
      return;
    }
    final PsiBuilder.Marker var = builder.mark();
    builder.advanceLexer();
    if (builder.getTokenType() == JSTokenTypes.EQ) {
      builder.advanceLexer();
      if (allowIn) {
        if (!ExpressionParsing.parseAssignmentExpression(builder)) {
          builder.error(JSBundle.message("javascript.parser.message.expected.expression"));
        }
      }
      else {
        if (!ExpressionParsing.parseAssignmentExpressionNoIn(builder)) {
          builder.error(JSBundle.message("javascript.parser.message.expected.expression"));
        }
      }
    }
    var.done(JSElementTypes.VARIABLE);
  }

  public static void parseBlock(final PsiBuilder builder) {
    parseBlockOrFunctionBody(builder, false);
  }

  public static void parseFunctionBody(final PsiBuilder builder) {
    parseBlockOrFunctionBody(builder, true);
  }

  private static void parseBlockOrFunctionBody(final PsiBuilder builder, boolean functionBody) {
    if (builder.getTokenType() != JSTokenTypes.LBRACE) {
      builder.error(JSBundle.message("javascript.parser.message.expected.lbrace"));
      return;
    }

    final PsiBuilder.Marker block = builder.mark();
    builder.advanceLexer();
    while (builder.getTokenType() != JSTokenTypes.RBRACE) {
      if (builder.eof()) {
        builder.error(JSBundle.message("javascript.parser.message.missing.rbrace"));
        block.done(JSElementTypes.BLOCK);
        return;
      }

      if (functionBody) {
        parseSourceElement(builder);
      }
      else {
        parseStatement(builder);
      }
    }

    builder.advanceLexer();
    block.done(JSElementTypes.BLOCK);
  }
}
