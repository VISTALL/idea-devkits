package com.intellij.lang.javascript.inspections;

import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.fileEditor.OpenFileDescriptor;
import com.intellij.openapi.util.TextRange;
import com.intellij.openapi.util.Ref;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiNamedElement;
import com.intellij.psi.PsiWhiteSpace;
import com.intellij.psi.tree.IElementType;
import com.intellij.psi.xml.*;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.index.JavaScriptIndex;
import com.intellij.lang.javascript.psi.JSReferenceExpression;
import com.intellij.lang.javascript.psi.JSExpression;
import com.intellij.lang.javascript.psi.JSClass;
import com.intellij.lang.javascript.psi.JSFile;
import com.intellij.lang.javascript.psi.util.JSUtils;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.BaseJSSymbolProcessor;
import com.intellij.codeInsight.CodeInsightUtil;
import com.intellij.codeInsight.lookup.LookupItem;
import com.intellij.codeInsight.template.*;
import org.jetbrains.annotations.NotNull;

/**
 * @author Maxim.Mossienko
*/
abstract class BaseCreateFix implements LocalQuickFix {
  private static final String ANY_TYPE = "*";
  private static final String SCRIPT_TAG_NAME = "Script";

  public void applyFix(@NotNull Project project, @NotNull ProblemDescriptor descriptor) {
    final PsiElement psiElement = descriptor.getPsiElement();
    PsiFile file = psiElement.getContainingFile();
    PsiFile realFile = file.getContext() != null ? file.getContext().getContainingFile() : file;
    final boolean ecma = file.getLanguageDialect() == JavaScriptSupportLoader.ECMA_SCRIPT_L4;

    JSReferenceExpression referenceExpression = (JSReferenceExpression)psiElement.getParent();
    final JSExpression qualifier = referenceExpression.getQualifier();
    PsiElement predefinedAnchor = null;

    if (qualifier != null && ecma) {
      final PsiElement type = getType(qualifier, file, ecma);

      if (type != null && type.isWritable()) {
        final PsiElement element = JSResolveUtil.unwrapProxy(type);

        if (element instanceof JSClass) {
          file = type.getContainingFile();
          realFile = file;
          predefinedAnchor = element.getLastChild().getPrevSibling();
        } else if (element instanceof XmlFile) {
          file = type.getContainingFile();
          realFile = file;
          predefinedAnchor = element;
        }
      }
    }

    if ( !CodeInsightUtil.prepareFileForWrite(realFile)) return;

    Editor editor = FileEditorManager.getInstance(project).openTextEditor(
      new OpenFileDescriptor(project, realFile.getVirtualFile(), 0), true
    );

    PsiElement anchor = predefinedAnchor != null ? predefinedAnchor: JSUtils.findStatementAnchor(referenceExpression, file);
    boolean insertAtEnd = false;
    PsiElement anchorParent = null;

    String prefix = "";
    String suffix = "";

    if (anchor != null && ecma) {
      anchorParent = anchor.getParent();
      while(anchorParent != null && !(anchorParent instanceof JSClass) && !(anchorParent instanceof JSFile)) {
        anchor = anchorParent;
        anchorParent = anchor.getParent();
      }

      insertAtEnd = anchorParent instanceof JSClass;

      XmlFile contextFile = null;
      if (anchorParent instanceof JSFile && anchorParent.getContext() != null) {
        final PsiElement context = anchorParent.getContext();
        if (context instanceof XmlAttributeValue ||
            context instanceof XmlText && !(SCRIPT_TAG_NAME.equals(((XmlTag)context.getParent()).getLocalName()))
           ) {
          contextFile = (XmlFile)context.getContainingFile();
        }
      } else if (realFile instanceof XmlFile) {
        contextFile = (XmlFile)realFile;
      }

      if (contextFile != null) {
        final XmlTag rootTag = contextFile.getDocument().getRootTag();
        final XmlTag[] tags = rootTag.findSubTags(SCRIPT_TAG_NAME, JavaScriptSupportLoader.MXML_URI);

        if (tags.length > 0) {
          final Ref<PsiElement> anchorInScript = new Ref<PsiElement>();
          JSResolveUtil.processInjectedFileForTag(tags[0], new JSResolveUtil.JSInjectedFilesVisitor() {
            protected void process(final JSFile file) {
              anchorInScript.set(file.getFirstChild());
            }
          });
          anchor = anchorInScript.get();
          if (anchor instanceof PsiWhiteSpace && anchor.getNextSibling() != null) anchor = anchor.getNextSibling();
        } else {
          String nsPrefix = rootTag.getPrefixByNamespace(JavaScriptSupportLoader.MXML_URI);
          prefix = "\n<" + nsPrefix + ":"+ SCRIPT_TAG_NAME + "><![CDATA[";
          suffix = "\n]]></" + nsPrefix + ":" + SCRIPT_TAG_NAME +">";
          for(PsiElement e:rootTag.getChildren()) {
            final IElementType type = e.getNode().getElementType();
            if (type == XmlTokenType.XML_TAG_END) {
              anchor = e;
              insertAtEnd = true;
              break;
            }
          }
        }
      }
    }

    if (anchor != null) {
      final TemplateManager templateManager = TemplateManager.getInstance(project);
      Template template = templateManager.createTemplate("","");

      if (prefix.length() > 0) template.addTextSegment(prefix);
      if (insertAtEnd) template.addTextSegment("\n");

      buildTemplate(template, referenceExpression, ecma, file, anchorParent);
      if (!insertAtEnd) template.addTextSegment("\n");

      if (suffix.length() > 0) template.addTextSegment(suffix);

      final TextRange anchorRange = anchor.getTextRange();
      int offset = insertAtEnd ? anchorRange.getEndOffset() : anchorRange.getStartOffset();

      if (file != realFile || file instanceof XmlFile) {
        final PsiFile anchorContainingFile = anchor.getContainingFile();
        final PsiElement anchorFileContext = anchorContainingFile.getContext();

        if (anchorFileContext != null) {
          if (anchorFileContext instanceof XmlText)  offset += ((XmlText)anchorFileContext).displayToPhysical(0);
          offset += anchorFileContext.getTextOffset();
        }
      }
      editor.getCaretModel().moveToOffset(offset);
      templateManager.startTemplate(editor, template);
    }
  }

  protected abstract void buildTemplate(final Template template, JSReferenceExpression referenceExpression,
                               boolean ecma, PsiFile file, PsiElement anchorParent);

  static String getTypeOfValue(final JSExpression passedParameterValue, final PsiFile file, boolean ecma) {
    final PsiElement type = getType(passedParameterValue, file, ecma);
    return type != null ? type instanceof JSClass ? ((JSClass)type).getQualifiedName() : ((PsiNamedElement)type).getName():ANY_TYPE;
  }

  static PsiElement getType(final JSExpression passedParameterValue, final PsiFile file, boolean ecma) {
    final BaseJSSymbolProcessor.SimpleTypeProcessor processor = new BaseJSSymbolProcessor.SimpleTypeProcessor(ecma);
    BaseJSSymbolProcessor.doEvalForExpr(passedParameterValue, file, processor);
    String type = processor.getType();
    PsiElement source = processor.getSource();

    if (type != null) {
      if (!(source instanceof JSClass) && !(source instanceof XmlFile)) {
        source = JSResolveUtil.findClassByQName(type, JavaScriptIndex.getInstance(file.getProject()));
      }
    }
    return source;
  }

  static class MyExpression implements Expression {
    TextResult result;
    private final String myVar1;

    public MyExpression(final String var1) {
      myVar1 = var1;
      result = new TextResult(myVar1);
    }

    public Result calculateResult(ExpressionContext context) {
      return result;
    }

    public Result calculateQuickResult(ExpressionContext context) {
      return result;
    }

    public LookupItem[] calculateLookupItems(ExpressionContext context) {
      return new LookupItem[0];
    }
  }
}
