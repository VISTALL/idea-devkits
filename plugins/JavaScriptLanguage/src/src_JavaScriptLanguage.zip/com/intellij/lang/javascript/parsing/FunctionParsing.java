/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.parsing;

import com.intellij.lang.PsiBuilder;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.openapi.diagnostic.Logger;

/**
 * @author max
 */
public class FunctionParsing {
  private static final Logger LOG = Logger.getInstance("#com.intellij.lang.javascript.parsing.FunctionParsing");

  private FunctionParsing() { }  

  public static void parseFunctionExpression(PsiBuilder builder) {
    parseFunction(builder, true);
  }

  public static void parseFunctionDeclaration(PsiBuilder builder) {
    parseFunction(builder, false);
  }

  private static void parseFunction(PsiBuilder builder, boolean expressionContext) {
    final PsiBuilder.Marker functionMarker = builder.mark();
    if (builder.getTokenType() == JSTokenTypes.FUNCTION_KEYWORD) { // function keyword may be ommited in context of get/set property definition
      builder.advanceLexer();
    }

    // Function name
    if (builder.getTokenType() == JSTokenTypes.IDENTIFIER) {
      builder.advanceLexer();
    }
    else {
      if (!expressionContext) {
        builder.error(JSBundle.message("javascript.parser.message.expected.function.name"));
      }
    }

    parseParameterList(builder);

    StatementParsing.parseFunctionBody(builder);

    functionMarker.done(expressionContext ? JSElementTypes.FUNCTION_EXPRESSION : JSElementTypes.FUNCTION_DECLARATION);
  }

  private static void parseParameterList(final PsiBuilder builder) {
    final PsiBuilder.Marker parameterList;
    if (builder.getTokenType() != JSTokenTypes.LPAR) {
      builder.error(JSBundle.message("javascript.parser.message.expected.lparen"));
      parameterList = builder.mark(); // To have non-empty parameters list at all the time.
      parameterList.done(JSElementTypes.PARAMETER_LIST);
      return;
    }
    else {
      parameterList = builder.mark();
      builder.advanceLexer();
    }

    boolean first = true;
    while (builder.getTokenType() != JSTokenTypes.RPAR) {
      if (first) {
        first = false;
      }
      else {
        if (builder.getTokenType() == JSTokenTypes.COMMA) {
          builder.advanceLexer();
        }
        else {
          builder.error(JSBundle.message("javascript.parser.message.expected.comma.or.rparen"));
          break;
        }
      }

      final PsiBuilder.Marker parameter = builder.mark();
      if (builder.getTokenType() == JSTokenTypes.IDENTIFIER) {
        builder.advanceLexer();
        parameter.done(JSElementTypes.FORMAL_PARAMETER);
      }
      else {
        builder.error(JSBundle.message("javascript.parser.message.expected.formal.parameter.name"));
        parameter.drop();
      }
    }

    if (builder.getTokenType() == JSTokenTypes.RPAR) {
      builder.advanceLexer();
    }

    parameterList.done(JSElementTypes.PARAMETER_LIST);
  }
}
