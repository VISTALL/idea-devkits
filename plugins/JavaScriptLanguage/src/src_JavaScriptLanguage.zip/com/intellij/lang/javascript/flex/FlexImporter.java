package com.intellij.lang.javascript.flex;

import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.*;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.zip.InflaterInputStream;

/**
 * Produced from abcdump.as
 */
public class FlexImporter {
  private static final @NonNls String TAB = "  ";
  @NonNls private static final String $CINIT = "$cinit";
  @NonNls private static final String $ = "$";

  // method flags
  private static final int NEED_ARGUMENTS = 0x01;
  private static final int NEED_ACTIVATION = 0x02;
  private static final int NEED_REST = 0x04;
  private static final int HAS_OPTIONAL = 0x08;
  private static final int IGNORE_REST = 0x10;
  private static final int NATIVE = 0x20;
  private static final int HAS_ParamNames = 0x80;

  private static final int CONSTANT_Utf8 = 0x01;
  private static final int CONSTANT_Int = 0x03;
  private static final int CONSTANT_UInt = 0x04;
  private static final int CONSTANT_PrivateNs = 0x05; // non-shared namespace
  private static final int CONSTANT_Double = 0x06;
  private static final int CONSTANT_Qname = 0x07; // o.ns::name, ct ns, ct name
  private static final int CONSTANT_Namespace = 0x08;
  private static final int CONSTANT_Multiname = 0x09; // o.name, ct nsset, ct name
  private static final int CONSTANT_False = 0x0A;
  private static final int CONSTANT_True = 0x0B;
  private static final int CONSTANT_Null = 0x0C;
  private static final int CONSTANT_QnameA = 0x0D; // o.@ns::name, ct ns, ct attr-name
  private static final int CONSTANT_MultinameA = 0x0E; // o.@name, ct attr-name
  private static final int CONSTANT_RTQname = 0x0F; // o.ns::name, rt ns, ct name
  private static final int CONSTANT_RTQnameA = 0x10; // o.@ns::name, rt ns, ct attr-name
  private static final int CONSTANT_RTQnameL = 0x11; // o.ns::[name], rt ns, rt name
  private static final int CONSTANT_RTQnameLA = 0x12; // o.@ns::[name], rt ns, rt attr-name
  private static final int CONSTANT_NameL = 0x13;    // o.[], ns=public implied, rt name
  private static final int CONSTANT_NameLA = 0x14; // o.@[], ns=public implied, rt attr-name
  private static final int CONSTANT_NamespaceSet = 0x15;
  private static final int CONSTANT_PackageNs = 0x16;
  private static final int CONSTANT_PackageInternalNs = 0x17;
  private static final int CONSTANT_ProtectedNs = 0x18;
  private static final int CONSTANT_StaticProtectedNs = 0x19;
  private static final int CONSTANT_StaticProtectedNs2 = 0x1a;
  private static final int CONSTANT_MultinameL = 0x1B;
  private static final int CONSTANT_MultinameLA = 0x1C;
  private static final int CONSTANT_TypeName = 0x1D;

  static final @NonNls String[] constantKinds = {"0", "utf8", "2", "int", "uint", "private", "double", "qname", "namespace", "multiname",
    "false", "true", "null", "@qname", "@multiname", "rtqname", "@rtqname", "[qname]", "@[qname]", "[name]", "@[name]", "nsset"};

  private static final int TRAIT_Slot = 0x00;
  private static final int TRAIT_Method = 0x01;
  private static final int TRAIT_Getter = 0x02;
  private static final int TRAIT_Setter = 0x03;
  private static final int TRAIT_Class = 0x04;
  private static final int TRAIT_Function = 0x05;
  private static final int TRAIT_Const = 0x06;

  private static final @NonNls String[] traitKinds = {"var", "function", "function get", "function set", "class", "function", "const"};

  private static final int OP_bkpt = 0x01;
  private static final int OP_nop = 0x02;
  private static final int OP_throw = 0x03;
  private static final int OP_getsuper = 0x04;
  private static final int OP_setsuper = 0x05;
  private static final int OP_dxns = 0x06;
  private static final int OP_dxnslate = 0x07;
  private static final int OP_kill = 0x08;
  private static final int OP_label = 0x09;
  private static final int OP_ifnlt = 0x0C;
  private static final int OP_ifnle = 0x0D;
  private static final int OP_ifngt = 0x0E;
  private static final int OP_ifnge = 0x0F;
  private static final int OP_jump = 0x10;
  private static final int OP_iftrue = 0x11;
  private static final int OP_iffalse = 0x12;
  private static final int OP_ifeq = 0x13;
  private static final int OP_ifne = 0x14;
  private static final int OP_iflt = 0x15;
  private static final int OP_ifle = 0x16;
  private static final int OP_ifgt = 0x17;
  private static final int OP_ifge = 0x18;
  private static final int OP_ifstricteq = 0x19;
  private static final int OP_ifstrictne = 0x1A;
  private static final int OP_lookupswitch = 0x1B;
  private static final int OP_pushwith = 0x1C;
  private static final int OP_popscope = 0x1D;
  private static final int OP_nextname = 0x1E;
  private static final int OP_hasnext = 0x1F;
  private static final int OP_pushnull = 0x20;
  private static final int OP_pushundefined = 0x21;
  private static final int OP_pushconstant = 0x22;
  private static final int OP_nextvalue = 0x23;
  private static final int OP_pushbyte = 0x24;
  private static final int OP_pushshort = 0x25;
  private static final int OP_pushtrue = 0x26;
  private static final int OP_pushfalse = 0x27;
  private static final int OP_pushnan = 0x28;
  private static final int OP_pop = 0x29;
  private static final int OP_dup = 0x2A;
  private static final int OP_swap = 0x2B;
  private static final int OP_pushstring = 0x2C;
  private static final int OP_pushint = 0x2D;
  private static final int OP_pushuint = 0x2E;
  private static final int OP_pushdouble = 0x2F;
  private static final int OP_pushscope = 0x30;
  private static final int OP_pushnamespace = 0x31;
  private static final int OP_hasnext2 = 0x32;
  private static final int OP_newfunction = 0x40;
  private static final int OP_call = 0x41;
  private static final int OP_construct = 0x42;
  private static final int OP_callmethod = 0x43;
  private static final int OP_callstatic = 0x44;
  private static final int OP_callsuper = 0x45;
  private static final int OP_callproperty = 0x46;
  private static final int OP_returnvoid = 0x47;
  private static final int OP_returnvalue = 0x48;
  private static final int OP_constructsuper = 0x49;
  private static final int OP_constructprop = 0x4A;
  private static final int OP_callsuperid = 0x4B;
  private static final int OP_callproplex = 0x4C;
  private static final int OP_callinterface = 0x4D;
  private static final int OP_callsupervoid = 0x4E;
  private static final int OP_callpropvoid = 0x4F;
  private static final int OP_newobject = 0x55;
  private static final int OP_newarray = 0x56;
  private static final int OP_newactivation = 0x57;
  private static final int OP_newclass = 0x58;
  private static final int OP_getdescendants = 0x59;
  private static final int OP_newcatch = 0x5A;
  private static final int OP_findpropstrict = 0x5D;
  private static final int OP_findproperty = 0x5E;
  private static final int OP_finddef = 0x5F;
  private static final int OP_getlex = 0x60;
  private static final int OP_setproperty = 0x61;
  private static final int OP_getlocal = 0x62;
  private static final int OP_setlocal = 0x63;
  private static final int OP_getglobalscope = 0x64;
  private static final int OP_getscopeobject = 0x65;
  private static final int OP_getproperty = 0x66;
  private static final int OP_getpropertylate = 0x67;
  private static final int OP_initproperty = 0x68;
  private static final int OP_setpropertylate = 0x69;
  private static final int OP_deleteproperty = 0x6A;
  private static final int OP_deletepropertylate = 0x6B;
  private static final int OP_getslot = 0x6C;
  private static final int OP_setslot = 0x6D;
  private static final int OP_getglobalslot = 0x6E;
  private static final int OP_setglobalslot = 0x6F;
  private static final int OP_convert_s = 0x70;
  private static final int OP_esc_xelem = 0x71;
  private static final int OP_esc_xattr = 0x72;
  private static final int OP_convert_i = 0x73;
  private static final int OP_convert_u = 0x74;
  private static final int OP_convert_d = 0x75;
  private static final int OP_convert_b = 0x76;
  private static final int OP_convert_o = 0x77;
  private static final int OP_coerce = 0x80;
  private static final int OP_coerce_b = 0x81;
  private static final int OP_coerce_a = 0x82;
  private static final int OP_coerce_i = 0x83;
  private static final int OP_coerce_d = 0x84;
  private static final int OP_coerce_s = 0x85;
  private static final int OP_astype = 0x86;
  private static final int OP_astypelate = 0x87;
  private static final int OP_coerce_u = 0x88;
  private static final int OP_coerce_o = 0x89;
  private static final int OP_negate = 0x90;
  private static final int OP_increment = 0x91;
  private static final int OP_inclocal = 0x92;
  private static final int OP_decrement = 0x93;
  private static final int OP_declocal = 0x94;
  private static final int OP_typeof = 0x95;
  private static final int OP_not = 0x96;
  private static final int OP_bitnot = 0x97;
  private static final int OP_concat = 0x9A;
  private static final int OP_add_d = 0x9B;
  private static final int OP_add = 0xA0;
  private static final int OP_subtract = 0xA1;
  private static final int OP_multiply = 0xA2;
  private static final int OP_divide = 0xA3;
  private static final int OP_modulo = 0xA4;
  private static final int OP_lshift = 0xA5;
  private static final int OP_rshift = 0xA6;
  private static final int OP_urshift = 0xA7;
  private static final int OP_bitand = 0xA8;
  private static final int OP_bitor = 0xA9;
  private static final int OP_bitxor = 0xAA;
  private static final int OP_equals = 0xAB;
  private static final int OP_strictequals = 0xAC;
  private static final int OP_lessthan = 0xAD;
  private static final int OP_lessequals = 0xAE;
  private static final int OP_greaterthan = 0xAF;
  private static final int OP_greaterequals = 0xB0;
  private static final int OP_instanceof = 0xB1;
  private static final int OP_istype = 0xB2;
  private static final int OP_istypelate = 0xB3;
  private static final int OP_in = 0xB4;
  private static final int OP_increment_i = 0xC0;
  private static final int OP_decrement_i = 0xC1;
  private static final int OP_inclocal_i = 0xC2;
  private static final int OP_declocal_i = 0xC3;
  private static final int OP_negate_i = 0xC4;
  private static final int OP_add_i = 0xC5;
  private static final int OP_subtract_i = 0xC6;
  private static final int OP_multiply_i = 0xC7;
  private static final int OP_getlocal0 = 0xD0;
  private static final int OP_getlocal1 = 0xD1;
  private static final int OP_getlocal2 = 0xD2;
  private static final int OP_getlocal3 = 0xD3;
  private static final int OP_setlocal0 = 0xD4;
  private static final int OP_setlocal1 = 0xD5;
  private static final int OP_setlocal2 = 0xD6;
  private static final int OP_setlocal3 = 0xD7;
  private static final int OP_debug = 0xEF;
  private static final int OP_debugline = 0xF0;
  private static final int OP_debugfile = 0xF1;
  private static final int OP_bkptline = 0xF2;

  private static final @NonNls String opNames[] = {"OP_0x00       ", "bkpt          ", "nop           ", "throw         ", "getsuper      ",
    "setsuper      ", "dxns          ", "dxnslate      ", "kill          ", "label         ", "OP_0x0A       ", "OP_0x0B       ",
    "ifnlt         ", "ifnle         ", "ifngt         ", "ifnge         ", "jump          ", "iftrue        ", "iffalse       ",
    "ifeq          ", "ifne          ", "iflt          ", "ifle          ", "ifgt          ", "ifge          ", "ifstricteq    ",
    "ifstrictne    ", "lookupswitch  ", "pushwith      ", "popscope      ", "nextname      ", "hasnext       ", "pushnull      ",
    "pushundefined ", "pushconstant  ", "nextvalue     ", "pushbyte      ", "pushshort     ", "pushtrue      ", "pushfalse     ",
    "pushnan       ", "pop           ", "dup           ", "swap          ", "pushstring    ", "pushint       ", "pushuint      ",
    "pushdouble    ", "pushscope     ", "pushnamespace ", "hasnext2      ", "OP_0x33       ", "OP_0x34       ", "OP_0x35       ",
    "OP_0x36       ", "OP_0x37       ", "OP_0x38       ", "OP_0x39       ", "OP_0x3A       ", "OP_0x3B       ", "OP_0x3C       ",
    "OP_0x3D       ", "OP_0x3E       ", "OP_0x3F       ", "newfunction   ", "call          ", "construct     ", "callmethod    ",
    "callstatic    ", "callsuper     ", "callproperty  ", "returnvoid    ", "returnvalue   ", "constructsuper", "constructprop ",
    "callsuperid   ", "callproplex   ", "callinterface ", "callsupervoid ", "callpropvoid  ", "OP_0x50       ", "OP_0x51       ",
    "OP_0x52       ", "OP_0x53       ", "OP_0x54       ", "newobject     ", "newarray      ", "newactivation ", "newclass      ",
    "getdescendants", "newcatch      ", "OP_0x5B       ", "OP_0x5C       ", "findpropstrict", "findproperty  ", "finddef       ",
    "getlex        ", "setproperty   ", "getlocal      ", "setlocal      ", "getglobalscope", "getscopeobject", "getproperty   ",
    "OP_0x67       ", "initproperty  ", "OP_0x69       ", "deleteproperty", "OP_0x6A       ", "getslot       ", "setslot       ",
    "getglobalslot ", "setglobalslot ", "convert_s     ", "esc_xelem     ", "esc_xattr     ", "convert_i     ", "convert_u     ",
    "convert_d     ", "convert_b     ", "convert_o     ", "checkfilter   ", "OP_0x79       ", "OP_0x7A       ", "OP_0x7B       ",
    "OP_0x7C       ", "OP_0x7D       ", "OP_0x7E       ", "OP_0x7F       ", "coerce        ", "coerce_b      ", "coerce_a      ",
    "coerce_i      ", "coerce_d      ", "coerce_s      ", "astype        ", "astypelate    ", "coerce_u      ", "coerce_o      ",
    "OP_0x8A       ", "OP_0x8B       ", "OP_0x8C       ", "OP_0x8D       ", "OP_0x8E       ", "OP_0x8F       ", "negate        ",
    "increment     ", "inclocal      ", "decrement     ", "declocal      ", "typeof        ", "not           ", "bitnot        ",
    "OP_0x98       ", "OP_0x99       ", "concat        ", "add_d         ", "OP_0x9C       ", "OP_0x9D       ", "OP_0x9E       ",
    "OP_0x9F       ", "add           ", "subtract      ", "multiply      ", "divide        ", "modulo        ", "lshift        ",
    "rshift        ", "urshift       ", "bitand        ", "bitor         ", "bitxor        ", "equals        ", "strictequals  ",
    "lessthan      ", "lessequals    ", "greaterthan   ", "greaterequals ", "instanceof    ", "istype        ", "istypelate    ",
    "in            ", "OP_0xB5       ", "OP_0xB6       ", "OP_0xB7       ", "OP_0xB8       ", "OP_0xB9       ", "OP_0xBA       ",
    "OP_0xBB       ", "OP_0xBC       ", "OP_0xBD       ", "OP_0xBE       ", "OP_0xBF       ", "increment_i   ", "decrement_i   ",
    "inclocal_i    ", "declocal_i    ", "negate_i      ", "add_i         ", "subtract_i    ", "multiply_i    ", "OP_0xC8       ",
    "OP_0xC9       ", "OP_0xCA       ", "OP_0xCB       ", "OP_0xCC       ", "OP_0xCD       ", "OP_0xCE       ", "OP_0xCF       ",
    "getlocal0     ", "getlocal1     ", "getlocal2     ", "getlocal3     ", "setlocal0     ", "setlocal1     ", "setlocal2     ",
    "setlocal3     ", "OP_0xD8       ", "OP_0xD9       ", "OP_0xDA       ", "OP_0xDB       ", "OP_0xDC       ", "OP_0xDD       ",
    "OP_0xDE       ", "OP_0xDF       ", "OP_0xE0       ", "OP_0xE1       ", "OP_0xE2       ", "OP_0xE3       ", "OP_0xE4       ",
    "OP_0xE5       ", "OP_0xE6       ", "OP_0xE7       ", "OP_0xE8       ", "OP_0xE9       ", "OP_0xEA       ", "OP_0xEB       ",
    "OP_0xEC       ", "OP_0xED       ", "OP_0xEE       ", "debug         ", "debugline     ", "debugfile     ", "bkptline      ",
    "timestamp     ", "OP_0xF4       ", "verifypass    ", "alloc         ", "mark          ", "wb            ", "prologue      ",
    "sendenter     ", "doubletoatom  ", "sweep         ", "codegenop     ", "verifyop      ", "decode        "};

  static class Multiname {
    String[] nsset;
    String name;

    Multiname(String[] nsset, String name) {
      this.nsset = nsset;
      this.name = name;
    }

    public String toString() {
      String s = "";
      if (hasNotEmptyNs()) s += nsset[0] + "::";
      s += name;

      return s;
    }

    private boolean hasNotEmptyNs() {
      return nsset != null && nsset.length > 0 && nsset[0] != null && nsset[0].length() > 0;
    }

    public boolean hasNamespace() {
      return hasNotEmptyNs() && ( nsset[0].startsWith("http://") || nsset[0].equals("private"));
    }

    public String getNsName() {
      return nsset[0].equals("http://adobe.com/AS3/2006/builtin") ? "AS3" :
             nsset[0].equals("http://www.adobe.com/2006/flex/mx/internal") ? "mx_internal" :
             nsset[0].equals("http://www.adobe.com/2006/actionscript/flash/objectproxy") || nsset[0].equals("http://www.adobe.com/2006/actionscript/flash/proxy") ? "object_proxy":
             nsset[0];
    }
  }

  static class MetaData extends LinkedHashMap<String, String> {
    String name;

    public String dump(@NotNull FlexByteCodeInformationProcessor processor) {
      String s = '[' + name;
      if (size() > 0 || processor.doStarMetaAttrNameDump()) s+='(';

      boolean first = true;

      for (String n : keySet()) {
        if (!first) s+=',';
        first = false;
        s += (!"*".equals(n) || processor.doStarMetaAttrNameDump() ?  n + "=":"") + ('"' + get(n) + '"');
      }

      if (size() > 0 || processor.doStarMetaAttrNameDump()) s+=')';
      s+= "]";
      return s;
    }
  }

  static abstract class MemberInfo {
    Traits parentTraits;
    int id;
    int kind;
    Multiname name;
    MetaData[] metadata;
    boolean isOverride;
    boolean isPublic;
    boolean isFinal;

    abstract void dump(Abc abc, String indent, String attr, final @NotNull FlexByteCodeInformationProcessor processor);

    protected void dumpMetaData(String indent, final @NotNull FlexByteCodeInformationProcessor processor) {
      if (metadata != null) {
        for (MetaData md : metadata) {
          if (processor.doDumpMetaData(md)) processor.append(indent + md.dump(processor) + "\n");
        }
      }
    }
  }

  static class LabelInfo extends LinkedHashMap<Integer, String> {
    int count;

    String labelFor(int target) {
      if (containsKey(target)) return get(target);
      final String s = "L" + (++count);
      put(target, s);
      return s;
    }
  }

  static class MethodInfo extends MemberInfo {
    int flags;
    String debugName;
    Multiname paramTypes[];
    String paramNames[];
    Multiname optionalValues[];
    Multiname returnType;
    int local_count;
    int max_scope;
    int max_stack;
    int code_length;
    ByteBuffer code;
    Traits activation;
    boolean anon;

    public String format(FlexByteCodeInformationProcessor processor, boolean verbose) {
      @NonNls String s = processor.dumpMemberKindAndName(this, verbose);

      s += "(";

      for (int i = 0; i < paramTypes.length; ++i) {
        final Multiname paramType = paramTypes[i];
        if (i > 0) s += ",";
        s += processor.dumpArgName(this, i);
        s += processor.dumpMultinameAsPackageName(paramType,null, true);
        s += processor.dumpArgValue(this, i);
      }

      s += "):" + processor.dumpMultinameAsPackageName(returnType,null, verbose) + (processor.doDumpDispOrSlotId() ? "\t/* disp_id " + id + "*/" : ";");

      return s;
    }

    void dump(Abc abc, String indent, String attr, final FlexByteCodeInformationProcessor processor) {
      if (!processor.doDumpMember(this)) return;

      processor.append("\n");

      dumpMetaData(indent, processor);

      processor.append(indent + attr + format(processor,false) + "\n");
      if (code != null && processor.doDumpCode()) {
        processor.append(indent + "{\n");
        String oldindent = indent;
        indent += TAB;

        if ((flags & NEED_ACTIVATION) != 0) {
          processor.append(indent + "activation {\n");
          activation.dump(abc, indent + TAB, "", processor);
          processor.append(indent + "}\n");
        }
        processor.append(indent + "// local_count=" + local_count + " max_scope=" + max_scope + " max_stack=" + max_stack + " code_len=" + code.bytesSize() +
                  "\n");
        code.position = 0;
        LabelInfo labels = new LabelInfo();

        while (!code.eof()) {
          int start = code.position;
          @NonNls String s = indent + start;
          while (s.length() < 12) s += ' ';
          int opcode = code.readUnsignedByte();

          if (opcode == OP_label || (labels.containsKey(code.position - 1))) {
            processor.append(indent + "\n");
            processor.append(indent + labels.labelFor(code.position - 1) + ": \n");
          }

          s += opNames[opcode];
          s += opNames[opcode].length() < 8 ? "\t\t" : "\t";

          switch (opcode) {
            case OP_debugfile:
            case OP_pushstring:
              s += '"' + abc.strings[readU32()].replaceAll("/\n/g", "\\n").replaceAll("/\t/g", "\\t") + '"';
              break;
            case OP_pushnamespace:
              s += abc.namespaces[readU32()];
              break;
            case OP_pushint:
              int i = abc.ints[readU32()];
              s += i + "\t// 0x" + Integer.toString(i, 16);
              break;
            case OP_pushuint:
              int u = abc.uints[readU32()];
              s += u + "\t// 0x" + Integer.toString(u, 16);
              break;
            case OP_pushdouble:
              s += abc.doubles[readU32()];
              break;
            case OP_getsuper:
            case OP_setsuper:
            case OP_getproperty:
            case OP_initproperty:
            case OP_setproperty:
            case OP_getlex:
            case OP_findpropstrict:
            case OP_findproperty:
            case OP_finddef:
            case OP_deleteproperty:
            case OP_istype:
            case OP_coerce:
            case OP_astype:
            case OP_getdescendants:
              s += abc.names[readU32()];
              break;
            case OP_constructprop:
            case OP_callproperty:
            case OP_callproplex:
            case OP_callsuper:
            case OP_callsupervoid:
            case OP_callpropvoid:
              s += abc.names[readU32()];
              s += " (" + readU32() + ")";
              break;
            case OP_newfunction: {
              int method_id = readU32();
              s += abc.methods[method_id].format(processor, true);
              abc.methods[method_id].anon = true;
              break;
            }
            case OP_callstatic:
              s += abc.methods[readU32()].format(processor, true);
              s += " (" + readU32() + ")";
              break;
            case OP_newclass:
              s += abc.instances[readU32()];
              break;
            case OP_lookupswitch:
              int pos = code.position - 1;
              int target = pos + readS24();
              int maxindex = readU32();
              s += "default:" + labels.labelFor(target); // target + "("+(target-pos)+")"
              s += " maxcase:" + maxindex;
              for (i = 0; i <= maxindex; i++) {
                target = pos + readS24();
                s += " " + labels.labelFor(target); // target + "("+(target-pos)+")"
              }
              break;
            case OP_jump:
            case OP_iftrue:
            case OP_iffalse:
            case OP_ifeq:
            case OP_ifne:
            case OP_ifge:
            case OP_ifnge:
            case OP_ifgt:
            case OP_ifngt:
            case OP_ifle:
            case OP_ifnle:
            case OP_iflt:
            case OP_ifnlt:
            case OP_ifstricteq:
            case OP_ifstrictne:
              int offset = readS24();
              target = code.position + offset;
              //s += target + " ("+offset+")"
              s += labels.labelFor(target);
              if (!(labels.containsKey(code.position))) s += "\n";
              break;
            case OP_inclocal:
            case OP_declocal:
            case OP_inclocal_i:
            case OP_declocal_i:
            case OP_getlocal:
            case OP_kill:
            case OP_setlocal:
            case OP_debugline:
            case OP_getglobalslot:
            case OP_getslot:
            case OP_setglobalslot:
            case OP_setslot:
            case OP_pushshort:
            case OP_newcatch:
              s += readU32();
              break;
            case OP_debug:
              s += code.readUnsignedByte();
              s += " " + readU32();
              s += " " + code.readUnsignedByte();
              s += " " + readU32();
              break;
            case OP_newobject:
              s += "{" + readU32() + "}";
              break;
            case OP_newarray:
              s += "[" + readU32() + "]";
              break;
            case OP_call:
            case OP_construct:
            case OP_constructsuper:
              s += "(" + readU32() + ")";
              break;
            case OP_pushbyte:
            case OP_getscopeobject:
              s += code.readByte();
              break;
            case OP_hasnext2:
              s += readU32() + " " + readU32();
            default:
              /*if (opNames[opcode] == ("0x"+opcode.toString(16).toUpperCase()))
          s += " UNKNOWN OPCODE"*/
              break;
          }

          int size = code.position - start;
          abc.totalSize += size;
          abc.opSizes[opcode] += size;
          processor.append(s + "\n");
        }
        processor.append(oldindent + "}\n");
      }
    }

    int readU32() {
      return code.readU32();
    }

    int readS24() {
      int b = code.readUnsignedByte();
      b |= code.readUnsignedByte() << 8;
      b |= code.readByte() << 16;
      return b;
    }
  }

  static class SlotInfo extends MemberInfo {
    Multiname type;
    Object value;

    public @NonNls String format(FlexByteCodeInformationProcessor processor) {
      String s = processor.dumpMemberKindAndName(this, false);
      return s + ":" + processor.dumpMultinameAsPackageName(type, null, true) +
             (value != null ? (" = " + (value instanceof String ? ('"' + value.toString() + '"') : value)) : "") +
             (processor.doDumpDispOrSlotId() ? "\t/* slot_id " + id + " */": ";");
    }

    void dump(Abc abc, String indent, String attr, final FlexByteCodeInformationProcessor processor) {
      if (!processor.doDumpMember(this)) return;

      if (kind == TRAIT_Const || kind == TRAIT_Slot) {
        dumpMetaData(indent, processor);

        processor.append(indent + attr + format(processor));
        processor.append("\n");
        return;
      }

      // else, class

      Traits ct = (Traits)value;
      Traits it = ct.itraits;
      processor.append("\n");
      dumpMetaData(indent, processor);

      @NonNls String def;
      if ((it.flags & CLASS_FLAG_interface) != 0) def = "interface";
      else {
        def = "class";
        if ((it.flags & CLASS_FLAG_sealed) == 0) def = "dynamic " + def;
        if ((it.flags & CLASS_FLAG_final) != 0) def = "final " + def;

      }

      if (!processor.doStarTypeDumpInExtends()) attr += "public ";

      processor.append(indent + attr + def + " " + processor.dumpMultinameAsPackageName(name,null, true));
      if (!"*".equals(it.base.name) || processor.doStarTypeDumpInExtends()) processor.append(" extends " + processor.dumpMultinameAsPackageName(it.base, null, true));
      processor.append("\n");
      String oldindent = indent;
      indent += TAB;
      if (it.interfaces.length > 0) {
        processor.append(indent + "implements ");
        boolean first = true;

        for (Multiname name : it.interfaces) {
          if (!first) processor.append(",");
          first = false;
          processor.append(processor.dumpMultinameAsPackageName(name,null, true));
        }
        processor.append("\n");
      }
      processor.append(oldindent + "{\n");
      it.init.dump(abc, indent, "", processor);
      it.dump(abc, indent, "", processor);
      ct.dump(abc, indent, "static ", processor);
      ct.init.dump(abc, indent, "static ", processor);
      processor.append(oldindent + "}\n");
    }
  }

  static class Traits {
    Object name;
    MethodInfo init;
    Traits itraits;
    Multiname base;
    int flags;
    String protectedNs;
    Multiname interfaces[];
    Map<String, MemberInfo> names = new LinkedHashMap<String, MemberInfo>();
    Map<Integer, SlotInfo> slots = new LinkedHashMap<Integer, SlotInfo>();
    Map<Integer, MethodInfo> methods = new LinkedHashMap<Integer, MethodInfo>();
    Map<Integer, MemberInfo> members = new LinkedHashMap<Integer, MemberInfo>();

    public String toString() {
      return name.toString();
    }

    public void dump(Abc abc, String indent, String attr, final FlexByteCodeInformationProcessor processor) {
      for (MemberInfo m : members.values())
        m.dump(abc, indent, attr, processor);
    }
  }

  private static final int ATTR_final = 0x01; // 1=final, 0=virtual
  private static final int ATTR_override = 0x02; // 1=override, 0=new
  private static final int ATTR_metadata = 0x04; // 1=has metadata, 0=no metadata
  private static final int ATTR_public = 0x08; // 1=add public namespace

  private static final int CLASS_FLAG_sealed = 0x01;
  private static final int CLASS_FLAG_final = 0x02;
  private static final int CLASS_FLAG_interface = 0x04;

  static class Abc {
    private FlexByteCodeInformationProcessor processor;
    int totalSize;
    final int opSizes[] = new int[256];

    public Abc(final @NotNull ByteBuffer _data, @NotNull FlexByteCodeInformationProcessor _processor) {
      data = _data;
      processor = _processor;

      data.setPosition(0);
      magic = data.readInt();

      _processor.dumpStat("magic " + Integer.toString(magic, 16) + "\n");

      if (magic != (46 << 16 | 14) && magic != (46 << 16 | 15) && magic != (46 << 16 | 16))
        throw new Error("not an abc file.  magic=" + Integer.toString(magic, 16));

      parseCpool();

      defaults[CONSTANT_Utf8] = strings;
      defaults[CONSTANT_Int] = ints;
      defaults[CONSTANT_UInt] = uints;
      defaults[CONSTANT_Double] = doubles;
      defaults[CONSTANT_Int] = ints;
      defaults[CONSTANT_False] = buildSparseArray(10, "false");
      defaults[CONSTANT_True] = buildSparseArray(11, "true");
      defaults[CONSTANT_Namespace] = namespaces;
      defaults[CONSTANT_PrivateNs] = namespaces;
      defaults[CONSTANT_PackageNs] = namespaces;
      defaults[CONSTANT_PackageInternalNs] = namespaces;
      defaults[CONSTANT_ProtectedNs] = namespaces;
      defaults[CONSTANT_StaticProtectedNs] = namespaces;
      defaults[CONSTANT_StaticProtectedNs2] = namespaces;
      defaults[CONSTANT_Null] = buildSparseArray(12, "null");

      parseMethodInfos();
      parseMetadataInfos();
      parseInstanceInfos();
      parseClassInfos();
      parseScriptInfos();
      parseMethodBodies();
    }

    private static Object[] buildSparseArray(int index, @NonNls String s1) {
      final Object[] result = new Object[index + 1];
      result[index] = s1;
      return result;
    }

    public void dump(String indent) {
      for (Traits t : scripts) {
        processor.dumpTopLevelTraits(this, t, indent);
      }

      for (MethodInfo m : methods) {
        if (m.anon) {
          processor.dumpToplevelAnonymousMethod(this, m);
        }
      }

      processor.dumpStat("OPCODE\tSIZE\t% OF " + totalSize + "\n");
      final Set<Integer> done = new HashSet<Integer>();
      while (true) {
        int max = -1;
        int maxsize = 0;
        for (int i = 0; i < 256; i++) {
          if (opSizes[i] > maxsize && !done.contains(i)) {
            max = i;
            maxsize = opSizes[i];
          }
        }
        if (max == -1) break;
        done.add(max);
        processor.dumpStat(opNames[max] + "\t" + opSizes[max] + "\t" + (int)(100f * opSizes[max] / totalSize) + "%\n");
      }
    }

    private final ByteBuffer data;
    int major;
    int minor;

    Integer[] ints;
    Integer[] uints;
    Double[] doubles;
    @NonNls String[] strings;
    @NonNls String[] namespaces;
    @NonNls String[][] nssets;
    Multiname[] names;

    final Object[][] defaults = new Object[Math.max(constantKinds.length, CONSTANT_MultinameLA + 1)][];

    MethodInfo methods[];
    Traits instances[];
    Traits classes[];
    Traits[] scripts;
    MetaData metadata[];

    @NonNls String publicNs = "";
    @NonNls String anyNs = "*";

    final int magic;

    int readU32() {
      return data.readU32();
    }

    void parseCpool() {
      int i, j;
      int n;
      int start = data.position;

      // ints
      n = readU32();
      ints = new Integer[n > 0 ? n : 1];
      ints[0] = 0;
      for (i = 1; i < n; i++)
        ints[i] = readU32();

      // uints
      n = readU32();
      uints = new Integer[n > 0 ? n : 1];
      uints[0] = 0;
      for (i = 1; i < n; i++)
        uints[i] = readU32();

      // doubles
      n = readU32();
      doubles = new Double[n > 0 ? n : 1];
      doubles[0] = Double.NaN;
      for (i = 1; i < n; i++)
        doubles[i] = data.readDouble();

      reportAboutPercentage("Cpool numbers size ", data, start, processor);
      start = data.position;

      // strings
      n = readU32();
      strings = new String[n];
      strings[0] = "";
      for (i = 1; i < n; i++)
        strings[i] = data.readUTFBytes(readU32());

      reportAboutPercentage("Cpool strings count " + n + " size ", data, start, processor);
      start = data.position;

      // namespaces
      n = readU32();
      namespaces = new String[n];
      namespaces[0] = publicNs;
      for (i = 1; i < n; i++)
        switch (data.readByte()) {
          case CONSTANT_Namespace:
          case CONSTANT_PackageNs:
          case CONSTANT_PackageInternalNs:
          case CONSTANT_ProtectedNs:
          case CONSTANT_StaticProtectedNs:
          case CONSTANT_StaticProtectedNs2: {
            namespaces[i] = strings[readU32()];
            // todo mark kind of namespace.
            break;
          }
          case CONSTANT_PrivateNs:
            readU32();
            namespaces[i] = "private";
            break;
        }

      reportAboutPercentage("Cpool namespaces count " + n + " size ", data, start, processor);
      start = data.position;

      // namespace sets
      n = readU32();
      nssets = new String[n][];
      for (i = 1; i < n; i++) {
        int count = readU32();
        String[] nsset = nssets[i] = new String[count];
        for (j = 0; j < count; j++)
          nsset[j] = namespaces[readU32()];
      }

      reportAboutPercentage("Cpool nssets count " + n + " size ", data, start, processor);
      start = data.position;

      // multinames
      n = readU32();
      names = new Multiname[n];
      namespaces[0] = anyNs;
      strings[0] = "*"; // any name
      for (i = 1; i < n; i++)
        switch (data.readByte()) {
          case CONSTANT_Qname:
          case CONSTANT_QnameA:
            names[i] = new Multiname(new String[]{namespaces[readU32()]}, strings[readU32()]);
            break;

          case CONSTANT_RTQname:
          case CONSTANT_RTQnameA:
            names[i] = new Multiname(new String[]{strings[readU32()]}, null);
            break;

          case CONSTANT_RTQnameL:
          case CONSTANT_RTQnameLA:
            names[i] = null;
            break;

          case CONSTANT_NameL:
          case CONSTANT_NameLA:
            names[i] = new Multiname(new String[]{""}, null);
            break;

          case CONSTANT_Multiname:
          case CONSTANT_MultinameA:
            String name = strings[readU32()];
            names[i] = new Multiname(nssets[readU32()], name);
            break;

          case CONSTANT_MultinameL:
          case CONSTANT_MultinameLA:
            names[i] = new Multiname(nssets[readU32()], null);
            break;

          case CONSTANT_TypeName:
            // TODO:
            int nameId = readU32();
            names[i] = new Multiname(new String[]{""}, "S_O_M_E___G_E_N_E_R_I_C___S_T_U_F_F");
            int count = readU32();

            for (int k = 0; k < count; k++) readU32();
            break;

          default:
            throw new Error("invalid kind " + data.getByte(data.position - 1));
        }

      reportAboutPercentage("Cpool names count " + n + " size ", data, start, processor);
      start = data.position;

      namespaces[0] = publicNs;
      strings[0] = "*";
    }

    void parseMethodInfos() {
      int start = data.position;
      names[0] = new Multiname(new String[]{publicNs}, "*");
      int method_count = readU32();
      methods = new MethodInfo[method_count];

      for (int i = 0; i < method_count; i++) {
        MethodInfo m = methods[i] = new MethodInfo();
        int param_count = readU32();
        m.returnType = names[readU32()];
        m.paramTypes = new Multiname[param_count];
        for (int j = 0; j < param_count; j++)
          m.paramTypes[j] = names[readU32()];
        m.debugName = strings[readU32()];
        m.flags = data.readByte();

        if ((m.flags & HAS_OPTIONAL) != 0) {
          // has_optional
          int optional_count = readU32();
          m.optionalValues = new Multiname[param_count];
          for (int k = param_count - optional_count; k < param_count; ++k) {
            int index = readU32();    // optional value index
            int kind = data.readByte(); // kind byte for each default value
            if (index == 0) {
              // kind is ignored, default value is based on type
              String value;
              final @NonNls String type = m.paramTypes[k].toString();

              if ("Number".equals(type) || "decimal".equals(type)) {
                value = "0";
              } else if ("*".equals(type)) {
                value = "null";
              } else if ("String".equals(type)) {
                value = "";
              }
              else {
                value = "null";
              }
              m.optionalValues[k] = new Multiname(null, value);
            }
            else {
              if (defaults[kind] == null) processor.hasError("ERROR kind=" + kind + " method_id " + i + "\n");
              else m.optionalValues[k] = new Multiname(null, defaults[kind][index].toString());
            }
          }
        }
        if ((m.flags & HAS_ParamNames) != 0) {
          m.paramNames = new String[param_count];
          for (int k = 0; k < param_count; ++k) {
            final int index = readU32();
            final String name = strings[index];
            m.paramNames[k] = StringUtil.isJavaIdentifier(name)? name : "_" + index;
          }
        }
      }

      reportAboutPercentage("MethodInfo count " + method_count + " size ", data, start, processor);
    }

    void parseMetadataInfos() {
      int count = readU32();
      metadata = new MetaData[count];
      for (int i = 0; i < count; i++) {
        // MetadataInfo
        MetaData m = metadata[i] = new MetaData();
        m.name = strings[readU32()];
        int values_count = readU32();
        String names[] = new String[values_count];

        for (int q = 0; q < values_count; ++q)
          names[q] = strings[readU32()]; // name
        for (int q = 0; q < values_count; ++q)
          m.put(names[q], strings[readU32()]); // value
      }
    }

    void parseInstanceInfos() {
      int start = data.position;
      int count = readU32();
      instances = new Traits[count];
      for (int i = 0; i < count; i++) {
        Traits t = instances[i] = new Traits();
        t.name = names[readU32()];
        t.base = names[readU32()];
        t.flags = data.readByte();
        if ((t.flags & 8) != 0) t.protectedNs = namespaces[readU32()];
        int interface_count = readU32();
        t.interfaces = new Multiname[interface_count];
        for (int j = 0; j < interface_count; j++)
          t.interfaces[j] = names[readU32()];
        MethodInfo m = t.init = methods[readU32()];
        m.name = ((Multiname)t.name);
        m.kind = TRAIT_Method;
        m.id = -1;
        m.parentTraits = t;
        parseTraits(t);
      }

      reportAboutPercentage("InstanceInfo size ", data, start, processor);
    }

    void parseTraits(Traits t) {
      int namecount = readU32();
      for (int i = 0; i < namecount; i++) {
        Multiname name = names[readU32()];
        int tag = data.readByte();
        int kind = tag & 0xf;
        MemberInfo member = null;

        switch (kind) {
          case TRAIT_Slot:
          case TRAIT_Const:
          case TRAIT_Class:
            SlotInfo slot = new SlotInfo();
            member = slot;
            slot.id = readU32();
            t.slots.put(slot.id, slot);
            if (kind == TRAIT_Slot || kind == TRAIT_Const) {
              slot.type = names[readU32()];
              int index = readU32();
              if (index > 0) slot.value = defaults[data.readByte()][index];
            }
            else // (kind == TRAIT_Class)
            {
              slot.value = classes[readU32()];
            }
            break;
          case TRAIT_Method:
          case TRAIT_Getter:
          case TRAIT_Setter:
            int disp_id = readU32();
            MethodInfo method = methods[readU32()];
            member = method;
            t.methods.put(disp_id, method);
            method.id = disp_id;
            //sb.append("\t",traitKinds[kind],name,disp_id,method,"// disp_id", disp_id)
            break;
        }
        if (member == null) processor.hasError("error trait kind " + kind + "\n");
        member.kind = kind;
        member.name = name;
        t.members.put(i, member);
        t.names.put(name.toString(), member);
        member.parentTraits = t;

        final int val = tag >> 4;
        if ((val & ATTR_metadata) != 0) {
          int mdCount = readU32();
          member.metadata = new MetaData[mdCount];
          for (int j = 0; j < mdCount; ++j)
            member.metadata[j] = metadata[readU32()];
        }

        if ((val & ATTR_final) != 0) {
          member.isFinal = true;
        }

        if ((val & ATTR_public) != 0) {
          member.isPublic = true;
        }

        if ((val & ATTR_override) != 0) {
          member.isOverride = true;
        }
      }
    }

    void parseClassInfos() {
      int start = data.position;
      int count = instances.length;
      classes = new Traits[count];
      for (int i = 0; i < count; i++) {
        Traits t = classes[i] = new Traits();
        t.init = methods[readU32()];
        t.base = new Multiname(null, "Class");
        t.itraits = instances[i];
        t.name = t.itraits.name + $;
        t.init.parentTraits = t;
        t.init.name = new Multiname(null, t.itraits.name + $CINIT);
        t.init.kind = TRAIT_Method;
        parseTraits(t);
      }
      reportAboutPercentage("ClassInfo size ", data, start, processor);
    }

    void parseScriptInfos() {
      int start = data.position;
      int count = readU32();
      scripts = new Traits[count];

      for (int i = 0; i < count; i++) {
        Traits t = new Traits();
        scripts[i] = t;
        t.name = "script" + i;
        t.base = names[0]; // Object
        t.init = methods[readU32()];
        t.init.name = new Multiname(null, t.name + "$init");
        t.init.kind = TRAIT_Method;
        t.init.parentTraits = t;
        parseTraits(t);
      }

      reportAboutPercentage("ScriptInfo size ", data, start, processor);
    }

    void parseMethodBodies() {
      int start = data.position;
      int count = readU32();

      for (int i = 0; i < count; i++) {
        MethodInfo m = methods[readU32()];
        m.max_stack = readU32();
        m.local_count = readU32();
        int initScopeDepth = readU32();
        int maxScopeDepth = readU32();
        m.max_scope = maxScopeDepth - initScopeDepth;
        int code_length = readU32();
        m.code = new ByteBuffer();
        m.code.setLittleEndian();

        if (code_length > 0) data.readBytes(m.code, code_length);

        int ex_count = readU32();
        for (int j = 0; j < ex_count; j++) {
          int from = readU32();
          int to = readU32();
          int target = readU32();
          Multiname type = names[readU32()];
          //sb.append("magic " + magic.toString(16))
          //if (magic >= (46<<16|16))
          Multiname name = names[readU32()];
        }
        parseTraits(m.activation = new Traits());
      }

      reportAboutPercentage("MethodBodies size ", data, start, processor);
    }
  }

  static class Rect {
    int nBits;
    int xMin, xMax;
    int yMin, yMax;

    public
    @NonNls
    String toString() {
      return "[Rect " + xMin + " " + yMin + " " + xMax + " " + yMax + "]";
    }
  }

  private static final int stagDoABC = 72;   // embedded .abc (AVM+) bytecode
  private static final int stagSymbolClass = 76;
  private static final int stagDoABC2 = 82;   // revised ABC version with a name

  private static final @NonNls String tagNames[] = {"End",                    // 00
    "ShowFrame",            // 01
    "DefineShape",            // 02
    "FreeCharacter",        // 03
    "PlaceObject",            // 04
    "RemoveObject",            // 05
    "DefineBits",            // 06
    "DefineButton",            // 07
    "JPEGTables",            // 08
    "SetBackgroundColor",    // 09

    "DefineFont",            // 10
    "DefineText",            // 11
    "DoAction",                // 12
    "DefineFontInfo",        // 13

    "DefineSound",            // 14
    "StartSound",            // 15
    "StopSound",            // 16

    "DefineButtonSound",    // 17

    "SoundStreamHead",        // 18
    "SoundStreamBlock",        // 19

    "DefineBitsLossless",    // 20
    "DefineBitsJPEG2",        // 21

    "DefineShape2",            // 22
    "DefineButtonCxform",    // 23

    "Protect",                // 24

    "PathsArePostScript",    // 25

    "PlaceObject2",            // 26
    "27 (invalid)",            // 27
    "RemoveObject2",        // 28

    "SyncFrame",            // 29
    "30 (invalid)",            // 30
    "FreeAll",                // 31

    "DefineShape3",            // 32
    "DefineText2",            // 33
    "DefineButton2",        // 34
    "DefineBitsJPEG3",        // 35
    "DefineBitsLossless2",    // 36
    "DefineEditText",        // 37

    "DefineVideo",            // 38

    "DefineSprite",            // 39
    "NameCharacter",        // 40
    "ProductInfo",            // 41
    "DefineTextFormat",        // 42
    "FrameLabel",            // 43
    "DefineBehavior",        // 44
    "SoundStreamHead2",        // 45
    "DefineMorphShape",        // 46
    "FrameTag",                // 47
    "DefineFont2",            // 48
    "GenCommand",            // 49
    "DefineCommandObj",        // 50
    "CharacterSet",            // 51
    "FontRef",                // 52

    "DefineFunction",        // 53
    "PlaceFunction",        // 54

    "GenTagObject",            // 55

    "ExportAssets",            // 56
    "ImportAssets",            // 57

    "EnableDebugger",        // 58

    "DoInitAction",            // 59
    "DefineVideoStream",    // 60
    "VideoFrame",            // 61

    "DefineFontInfo2",        // 62
    "DebugID",                 // 63
    "EnableDebugger2",         // 64
    "ScriptLimits",         // 65

    "SetTabIndex",             // 66

    "DefineShape4",         // 67
    "DefineMorphShape2",     // 68

    "FileAttributes",         // 69

    "PlaceObject3",         // 70
    "ImportAssets2",         // 71

    "DoABC",                 // 72
    "73 (invalid)",            // 73
    "74 (invalid)",            // 74
    "75 (invalid)",            // 75
    "SymbolClass",            // 76
    "77 (invalid)",         // 77
    "78 (invalid)",         // 78
    "79 (invalid)",         // 79
    "80 (invalid)",         // 80
    "81 (invalid)",         // 81
    "DoABC2",               // 82
    "83 (invalid)"          // 83
  };

  static class Swf {
    private FlexByteCodeInformationProcessor processor;

    public Swf(final ByteBuffer _data, final FlexByteCodeInformationProcessor _processor) {
      data = _data;
      processor = _processor;

      final Rect rect = decodeRect();
      final int rate = data.readUnsignedByte() << 8 | data.readUnsignedByte();
      final int count = data.readUnsignedShort();

      processor.dumpStat("size " + rect + "\n");
      processor.dumpStat("frame rate " + rate + "\n");
      processor.dumpStat("frame count " + count + "\n");

      decodeTags();
    }

    private int bitPos;
    private int bitBuf;

    private ByteBuffer data;

    private void decodeTags() {
      int type, h, length;

      while (data.position < data.bytesSize()) {
        type = (h = data.readUnsignedShort()) >> 6;

        if (((length = h & 0x3F) == 0x3F)) length = data.readInt();

        processor.dumpStat((type < tagNames.length ? tagNames[type] : "undefined") + " " + length + "b " + ((int)100f * length / data.bytesSize()) +
                    "%\n");

        switch (type) {
          case 0:
            return;
          case stagDoABC2:
            int pos1 = data.position;
            data.readInt();
            final String abcName = readString();
            processor.dumpStat("\nabc name " + abcName + "\n");
            length -= (data.position - pos1);
            // fall through
          case stagDoABC:
            ByteBuffer data2 = new ByteBuffer();
            data2.setLittleEndian();
            data.readBytes(data2, length);
            new Abc(data2, processor).dump("  ");
            processor.append("\n");
            break;
          default:
            data.position += length;
        }
      }
    }

    private String readString() {
      String s = "";
      int c;

      while ((c = data.readUnsignedByte()) != 0) s += (char)c;

      return s;
    }

    private void syncBits() {
      bitPos = 0;
    }

    private Rect decodeRect()

    {
      syncBits();

      Rect rect = new Rect();

      int nBits = readUBits(5);
      rect.xMin = readSBits(nBits);
      rect.xMax = readSBits(nBits);
      rect.yMin = readSBits(nBits);
      rect.yMax = readSBits(nBits);

      return rect;
    }

    int readSBits(int numBits) {
      if (numBits > 32) throw new Error("Number of bits > 32");

      int num = readUBits(numBits);
      int shift = 32 - numBits;
      // sign extension
      num = (num << shift) >> shift;
      return num;
    }

    int readUBits(int numBits) {
      if (numBits == 0) return 0;

      int bitsLeft = numBits;
      int result = 0;

      if (bitPos == 0) //no value in the buffer - read a byte
      {
        bitBuf = data.readUnsignedByte();
        bitPos = 8;
      }

      while (true) {
        int shift = bitsLeft - bitPos;
        if (shift > 0) {
          // Consume the entire buffer
          result |= bitBuf << shift;
          bitsLeft -= bitPos;

          // Get the next byte from the input stream
          bitBuf = data.readUnsignedByte();
          bitPos = 8;
        }
        else {
          // Consume a portion of the buffer
          result |= bitBuf >> -shift;
          bitPos -= bitsLeft;
          bitBuf &= 0xff >> (8 - bitPos); // mask off the consumed bits

          //                if (sb.append) System.out.sb.appendln("  read"+numBits+" " + result);
          return result;
        }
      }
    }
  }

  static class ByteBuffer {
    private byte[] bytes;
    private int position;
    private boolean littleEndian;

    void read(@NotNull InputStream inputStream) throws IOException {
      try {
        bytes = readStream(inputStream);
      }
      finally {
        if (inputStream != null) inputStream.close();
      }
    }

    void setLittleEndian() {
      littleEndian = true;
    }

    int readInt() {
      int result;
      if (littleEndian) {
        result = (((bytes[position + 3] & 0xFF) << 8 | (bytes[position + 2] & 0xFF)) << 16) + ((bytes[position + 1] & 0xFF) << 8) | (bytes[position] & 0xFF);
      }
      else {
        result = (((bytes[position] & 0xFF) << 8 | (bytes[position + 1] & 0xFF)) << 16) + ((bytes[position + 2] & 0xFF) << 8) | (bytes[position + 3] & 0xFF);
      }
      position += 4;
      return result;
    }

    public int readUnsignedInt() {
      return readInt();
    }

    public void setPosition(final int i) {
      position = i;
    }

    public int bytesSize() {
      return bytes.length;
    }

    public void uncompress() throws IOException {
      final InflaterInputStream zipInputStream = new InflaterInputStream(new ByteArrayInputStream(bytes));

      bytes = readStream(zipInputStream);

      zipInputStream.close();
    }

    private static byte[] readStream(final InputStream zipInputStream) throws IOException {
      final byte[] buf = new byte[8192];
      byte[] result = new byte[8192];
      int total = 0;

      while (true) {
        int read = zipInputStream.read(buf);
        if (read == -1) break;
        if (total + read >= result.length) {
          byte[] newresult = new byte[result.length * 2];
          System.arraycopy(result, 0, newresult, 0, total);
          result = newresult;
        }

        System.arraycopy(buf, 0, result, total, read);
        total += read;
      }

      final byte[] realResult = new byte[total];
      System.arraycopy(result, 0, realResult, 0, total);
      return realResult;
    }

    public int readUnsignedByte() {
      return bytes[position++] & 0xFF;
    }

    public int readByte() {
      return bytes[position++];
    }

    public int readUnsignedShort() {
      int result;
      if (littleEndian) {
        result = (bytes[position + 1] & 0xFF) << 8 | (bytes[position] & 0xFF);
      }
      else {
        result = (bytes[position] & 0xFF) << 8 | (bytes[position + 1] & 0xFF);
      }
      position += 2;
      return result;
    }

    public void readBytes(ByteBuffer data2, int length) {
      data2.bytes = new byte[length];
      System.arraycopy(bytes, position, data2.bytes, 0, length);
      position += length;
    }

    public boolean eof() {
      return position >= bytes.length;
    }

    public String readUTFBytes(int i) {
      try {
        final byte[] buf = new byte[i];
        while (i > 0) {
          buf[buf.length - i] = (byte)readByte();
          --i;
        }
        return new String(buf, "utf-8");
      }
      catch (UnsupportedEncodingException e) {
        throw new RuntimeException(e);
      }
    }

    public double readDouble() {
      int first = readInt();
      int second = readInt();
      return Double.longBitsToDouble(((long)second << 32) | first);
    }

    public int readU32() {
      int result = readUnsignedByte();
      if ((result & 0x00000080) == 0) return result;
      result = result & 0x0000007f | readUnsignedByte() << 7;
      if ((result & 0x00004000) == 0) return result;
      result = result & 0x00003fff | readUnsignedByte() << 14;
      if ((result & 0x00200000) == 0) return result;
      result = result & 0x001fffff | readUnsignedByte() << 21;
      if ((result & 0x10000000) == 0) return result;
      return result & 0x0fffffff | readUnsignedByte() << 28;
    }

    public byte getByte(int i) {
      return bytes[i];
    }
  }
  
  private static void reportAboutPercentage(String s, ByteBuffer data, int start, @NotNull FlexByteCodeInformationProcessor processor) {
    processor.dumpStat(s + (data.position - start) + " " + (int)100f * (data.position - start) / data.bytesSize() + " %\n");
  }

  public static void main(String[] args) throws IOException {
    if (args.length < 1) {
      System.out.print("FlexImporter\nusage:\nFlexImporter <filename>");
    }
    else {
      long started = System.currentTimeMillis();

      for (String file : args) {
        try {
          String result = dumpContentsFromStream(new BufferedInputStream(new FileInputStream(file)), true);

          saveStringAsFile(result, file + ".il");
        }
        finally {
          long total = System.currentTimeMillis() - started;
          System.out.println("File created... " + total + "ms");
        }
      }
    }
  }

  private static void saveStringAsFile(final String result, final String fileName) throws IOException {
    final FileOutputStream fileOutputStream = new FileOutputStream(fileName);
    try {
      fileOutputStream.write(result.getBytes());
    } finally {
      fileOutputStream.close();
    }
  }

  public static String dumpContentsFromStream(final InputStream in, boolean _dumpCode) throws IOException {
    final AbstractDumpProcessor abcDumper = new AbcDumper(_dumpCode);
    processFlexByteCode(in, abcDumper);
    return abcDumper.getResult();
  }

  public static String buildInterfaceFromStream(final InputStream in) throws IOException {
    final AbstractDumpProcessor abcDumper = new AS3InterfaceDumper();
    processFlexByteCode(in, abcDumper);
    final String s = abcDumper.getResult();
    //saveStringAsFile(s, File.createTempFile("fleximport", ".as").getPath());
    return s;
  }

  interface FlexByteCodeInformationProcessor {
    void dumpStat(@NotNull @NonNls String stat);
    void hasError(@NotNull String error);
    void append(@NotNull @NonNls String str);

    String dumpMemberKindAndName(@NotNull MemberInfo member, boolean referenceNameRequested);
    String dumpMultinameAsPackageName(@NotNull Multiname name, @Nullable String parentName, boolean referenceNameRequested);

    void dumpToplevelAnonymousMethod(final @NotNull Abc abc, final @NotNull MethodInfo m);

    void dumpTopLevelTraits(final @NotNull Abc abc, final @NotNull Traits t, final String indent);

    boolean doDumpMember(final @NotNull MemberInfo memberInfo);
    boolean doDumpCode();
    boolean doDumpMetaData(final @NotNull MetaData md);

    String dumpArgName(final @NotNull MethodInfo methodInfo, final int index);
    String dumpArgValue(final @NotNull MethodInfo methodInfo, final int index);

    boolean doDumpDispOrSlotId();

    boolean doStarTypeDumpInExtends();
    boolean doStarMetaAttrNameDump();
  }

  static abstract class AbstractDumpProcessor implements FlexByteCodeInformationProcessor {
    protected @NonNls StringBuilder sb = new StringBuilder();

    String getResult() { return sb.toString(); }

    public void append(@NotNull @NonNls String str) {
      sb.append(str);
    }
  }

  static class AbcDumper extends AbstractDumpProcessor {
    private boolean dumpCode;

    public AbcDumper(final boolean _dumpCode) {
      dumpCode = _dumpCode;
    }

    public void dumpStat(@NotNull final String stat) {
      sb.append(stat);
    }

    public void hasError(@NotNull final String error) {
      sb.append(error);
    }

    public String dumpMemberKindAndName(@NotNull final MemberInfo member, final boolean referenceNameRequested) {
      String s = member instanceof MethodInfo && (((MethodInfo)member).flags & NATIVE) != 0 ? "native ":"";

      s += traitKinds[member.kind] + " ";

      s += (member.name != null ? member.name.toString(): "undefined");
      return s;
    }

    public String dumpMultinameAsPackageName(@NotNull final Multiname name, @Nullable final String parentName, final boolean referenceNameRequested) {
      return name.toString();
    }

    public void dumpToplevelAnonymousMethod(final @NotNull Abc abc, final @NotNull MethodInfo m) {
      m.dump(abc, "", "", this);
    }

    public void dumpTopLevelTraits(final Abc abc, final @NotNull Traits t, final String indent) {
      sb.append(indent + t.name + "\n");
      t.dump(abc, indent, "", this);
      t.init.dump(abc, indent, "", this);
    }

    public boolean doDumpMember(final @NotNull MemberInfo memberInfo) {
      return true;
    }

    public boolean doDumpCode() {
      return dumpCode;
    }

    public boolean doDumpMetaData(final @NotNull MetaData md) {
      return true;
    }

    public String dumpArgName(final MethodInfo methodInfo, final int index) {
      return "";
    }

    public String dumpArgValue(final @NotNull MethodInfo methodInfo, final int index) {
      return "";
    }

    public boolean doDumpDispOrSlotId() {
      return true;
    }

    public boolean doStarTypeDumpInExtends() {
      return true;
    }

    public boolean doStarMetaAttrNameDump() {
      return true;
    }
  }

  static class AS3InterfaceDumper extends AbstractDumpProcessor {
    public void dumpStat(@NotNull final String stat) {}

    public void dumpToplevelAnonymousMethod(final @NotNull Abc abc, final @NotNull MethodInfo m) {}

    public void dumpTopLevelTraits(final Abc abc, final @NotNull Traits t, final String indent) {
      t.dump(abc, indent, "", this);
    }

    public boolean doDumpMember(final @NotNull MemberInfo memberInfo) {
      if (memberInfo.name == null) return false;
      if (memberInfo.name.name != null && memberInfo.name.name.indexOf($CINIT) >= 0) return false;
      return true;
    }

    public boolean doDumpCode() {
      return false;
    }

    public boolean doDumpMetaData(final @NotNull MetaData md) {
      return md.name.indexOf("__") == -1;
    }

    public String dumpArgName(final MethodInfo methodInfo, final int index) {
      return (methodInfo.paramNames != null ? methodInfo.paramNames[index] : "a" + (index > 0 ? "" + (index + 1) : "")) + ":";
    }

    public String dumpArgValue(final @NotNull MethodInfo methodInfo, final int index) {
      Multiname temp = methodInfo.optionalValues != null ? methodInfo.optionalValues[index] : null;
      if (temp != null) {
        String s = temp.toString();
        if (s.length() == 0) s = "\"\"";
        return " = " + s;
      }
      return "";
    }

    public boolean doDumpDispOrSlotId() {
      return false;
    }

    public boolean doStarTypeDumpInExtends() {
      return false;
    }

    public boolean doStarMetaAttrNameDump() {
      return false;
    }

    public void hasError(@NotNull final String error) {
      sb.append("/*" + error + "*/");
    }

    public String dumpMultinameAsPackageName(Multiname name, String parentName, boolean verbose) {
      if (name == null) {
        return "*";
      }
      if (name.hasNotEmptyNs()) {
        if (name.hasNamespace() ||
            (!verbose && parentName != null && 
             ( parentName.equals(name.nsset[0]) || parentName.equals(name.nsset[0] + $) || parentName.equals(name.toString().replaceAll("::",":"))))
          ) {
          return name.name;
        }
        return name.nsset[0] + "." + name.name;
      }
      return name.toString();
    }

    public String dumpMemberKindAndName(@NotNull final MemberInfo member, final boolean referenceNameRequested) {
      String s = "";

      s += "native ";

      if (member.name != null && member.name.hasNotEmptyNs() && member.name.hasNamespace()) s+= member.name.getNsName() + " ";
      if (s.indexOf("private") == -1) s+="public ";

      if (member.isFinal) s+= "final ";
      if (member.isOverride) s+= "override ";
      s += traitKinds[member.kind] + " ";

      s += (member.name != null ? dumpMultinameAsPackageName(member.name,(member.parentTraits != null ? member.parentTraits.name.toString().replaceAll("::", ":") : null), referenceNameRequested)
            : "undefined");
      return s;
    }
  }

  private static void processFlexByteCode(final @NotNull InputStream in, @NotNull FlexByteCodeInformationProcessor processor) throws IOException {
    ByteBuffer data = new ByteBuffer();
    data.read(in);
    data.setLittleEndian();
    int version = data.readUnsignedInt();

    switch (version) {
      case 46 << 16 | 14:
      case 46 << 16 | 15:
      case 46 << 16 | 16:
        Abc abc = new Abc(data, processor);
        abc.dump("");
        break;
      case 67 | 87 << 8 | 83 << 16 | 9 << 24: // SWC9
      case 67 | 87 << 8 | 83 << 16 | 8 << 24: // SWC8
      case 67 | 87 << 8 | 83 << 16 | 7 << 24: // SWC7
      case 67 | 87 << 8 | 83 << 16 | 6 << 24: // SWC6
        final int delta = 8;
        data.setPosition(delta);
        ByteBuffer udata = new ByteBuffer();
        udata.setLittleEndian();
        data.readBytes(udata, data.bytesSize() - delta);
        int csize = udata.bytesSize();
        udata.uncompress();
        processor.dumpStat("decompressed swf " + csize + " -> " + udata.bytesSize() + "\n");
        udata.setPosition(0);
        new Swf(udata, processor);
        break;
      case 70 | 87 << 8 | 83 << 16 | 9 << 24: // SWC9
      case 70 | 87 << 8 | 83 << 16 | 8 << 24: // SWC8
      case 70 | 87 << 8 | 83 << 16 | 7 << 24: // SWC7
      case 70 | 87 << 8 | 83 << 16 | 6 << 24: // SWC6
      case 70 | 87 << 8 | 83 << 16 | 5 << 24: // SWC5
      case 70 | 87 << 8 | 83 << 16 | 4 << 24: // SWC4
        data.setPosition(8); // skip header and length
        new Swf(data, processor);
        break;
      default:
        processor.hasError("unknown format " + version + "\n");
        break;
    }
    in.close();
  }
}
