/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript.psi.resolve;

import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.util.JSLookupUtil;
import com.intellij.openapi.util.Key;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiSubstitutor;
import com.intellij.psi.ResolveResult;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.util.ArrayUtil;
import gnu.trove.THashSet;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @by Maxim.Mossienko
*/
public class ResolveProcessor implements PsiScopeProcessor {
  private final Set<String> visitedClasses = new THashSet<String>();
  public static Key<String> toProcessAssignmentsKey = Key.create("to.process.js.assignments");
  private boolean myToStopOnAssignment;
  private String myName;
  private JSElement myResult;
  private JSElement myCandidateResult;
  private List<JSElement> myResults;
  private boolean toProcessHierarchy;
  private boolean toSkipClassDeclarationOnce;
  private boolean toProcessMembers = true;
  private boolean encounteredDynamicClasses;
  private boolean processStatics;
  private boolean allowUnqualifiedStaticsFromInstance;

  private boolean myTypeContext;
  private boolean encounteredWithStatement;
  private boolean localResolve;
  protected final PsiElement place;
  private String myTypeName;

  public ResolveProcessor(final String name) {
    this(name, false);
  }

  public ResolveProcessor(final String name, boolean toStopOnAssignment) {
    myName = name;
    myToStopOnAssignment = toStopOnAssignment;
    place = null;
  }

  public ResolveProcessor(final String name, PsiElement _place) {
    myName = name;
    place = _place;
    final boolean b = place instanceof JSReferenceExpression && ((JSReferenceExpression)place).getQualifier() == null;
    allowUnqualifiedStaticsFromInstance = b;
  }

  public JSElement getResult() {
    if (myResult == null && myCandidateResult != null) {
      assert myResults == null;
      return myCandidateResult;
    }
    return myResult;
  }

  public List<JSElement> getResults() {
    if (myResults == null && myResult == null && myCandidateResult != null) {
      myResults = new ArrayList<JSElement>(1);
      myResults.add(myCandidateResult);
    }
    return myResults;
  }

  public boolean execute(PsiElement element, PsiSubstitutor substitutor) {
    if (element instanceof JSVariable || element instanceof JSFunction) {
      final JSAttributeList attributeList = ((JSAttributeListOwner)element).getAttributeList();

      if (processStatics) {
        if (attributeList == null || !attributeList.hasModifier(JSAttributeList.ModifierType.STATIC)) return true;
      } else if (!allowUnqualifiedStaticsFromInstance) {
        if (attributeList != null && attributeList.hasModifier(JSAttributeList.ModifierType.STATIC)) return true;
      }
    }

    if (place != null && element instanceof JSFunction && !(element instanceof JSFunctionExpression)) {
      final JSFunction function = (JSFunction)element;

      final PsiElement parent = place.getParent();
      if (parent instanceof JSDefinitionExpression ||
          parent instanceof JSExpressionStatement ||
          (place instanceof JSFunction && ((JSFunction)place).isSetProperty())
         ) {
        if (function.isGetProperty()) return true;
      } else {
        if (function.isSetProperty()) return true;
      }
    }

    if (place != null && (place.getParent() instanceof JSNewExpression || place instanceof JSSuperExpression)) {
      if(element instanceof JSClass) {
        final JSFunction byName = ((JSClass)element).findFunctionByName(((JSClass)element).getName());
        if (byName != null) element = byName;
      } else if (element instanceof JSFunction && !((JSFunction)element).isConstructor()) {
        return true;
      }
    } else if (element instanceof JSFunction && ((JSFunction)element).isConstructor() && !(place instanceof JSClass)) {
      return true;
    }

    boolean checkStopOnMatch = false;
    boolean doStopOnMatch = false;

    if (element instanceof JSDefinitionExpression) {
      boolean toProcess = false;
      final JSExpression expression = ((JSDefinitionExpression)element).getExpression();
      
      if (expression instanceof JSReferenceExpression &&
          ((JSReferenceExpression)expression).getQualifier() == null
        ) {
        toProcess = true;
      }

      if (!toProcess) return true;
      checkStopOnMatch = true;
      doStopOnMatch = myToStopOnAssignment;
    }

    if (element instanceof JSNamedElement) {
      if (myName == null || myName.equals(((JSNamedElement)element).getName())) {
        if (checkStopOnMatch && !doStopOnMatch) {
          myCandidateResult = (JSElement)element;
        } else {
          if (myResults == null) myResults = new ArrayList<JSElement>(1);
          myResults.add((JSElement)element);
          myResult = (JSElement)element;
          return myName == null;
        }
      }
    }

    return true;
  }

  public <T> T getHint(Class<T> hintClass) {
    return null;
  }

  public void handleEvent(Event event, Object associated) {
    if (event == Event.SET_DECLARATION_HOLDER) {
      if (associated instanceof JSClass) {
        final JSClass jsClass = (JSClass)associated;
        if (!encounteredDynamicClasses && !"Object".equals(jsClass.getName())) {
          final JSAttributeList attributeList = jsClass.getAttributeList();
          if (attributeList != null && attributeList.hasModifier(JSAttributeList.ModifierType.DYNAMIC)) {
            encounteredDynamicClasses = true;
          }
        }

        if (processStatics) {
          if (myTypeName != null && !myTypeName.equals(jsClass.getQualifiedName())) {
            processStatics = false;
          }
        }
      } else if (associated instanceof JSFunction) {
        final JSAttributeList attributeList = ((JSFunction)associated).getAttributeList();
        if (attributeList != null &&
            attributeList.hasModifier(JSAttributeList.ModifierType.STATIC) &&
            ( place == null ||
              !(place.getParent() instanceof JSNewExpression)
            )
          ) {
          processStatics = true;
        }
      }
    }
  }

  protected void setTypeName(final String qualifiedName) {
    myTypeName = qualifiedName;
  }

  public String getName() {
    return myName;
  }

  public boolean isToProcessHierarchy() {
    return toProcessHierarchy;
  }

  public void setToProcessHierarchy(final boolean toProcessHierarchy) {
    this.toProcessHierarchy = toProcessHierarchy;
  }

  public boolean isToSkipClassDeclarationOnce() {
    return toSkipClassDeclarationOnce;
  }

  public void setToSkipClassDeclarationsOnce(final boolean toSkipClassDeclarationOnce) {
    this.toSkipClassDeclarationOnce = toSkipClassDeclarationOnce;
  }

  public boolean foundAllValidResults() {
    return getResult() != null && !encounteredDynamicClasses;
  }

  public void setTypeContext(final boolean b) {
    myTypeContext = b;
  }

  public boolean isTypeContext() {
    return myTypeContext;
  }

  public ResolveResult[] getResultsAsResolveResults() {
    final List<JSElement> processorResults = getResults();
    if (processorResults == null) return ResolveResult.EMPTY_ARRAY;
    final ResolveResult[] results = new ResolveResult[processorResults.size()];
    for(int i = 0; i < results.length; ++i) results[i] = new JSResolveUtil.MyResolveResult(processorResults.get(i));
    return results;
  }

  public Object[] getResultsAsObjects() {
    final List<JSElement> processorResults = getResults();
    if (processorResults == null) return ArrayUtil.EMPTY_OBJECT_ARRAY;
    final Object[] objects = processorResults.toArray(new Object[processorResults.size()]);
    final JSLookupUtil lookupUtil = JSLookupUtil.getInstance();

    for(int i = 0; i < objects.length; ++i) {
      final JSNamedElement namedElement = (JSNamedElement)objects[i];
      objects[i] = lookupUtil.createPrioritizedLookupItem(namedElement, namedElement.getName(), 3);
    }
    return objects;
  }

  public boolean processingEncounteredAbsenceOfTypes() {
    return encounteredDynamicClasses || encounteredWithStatement;
  }

  public void setEncounteredWithStatement(final boolean b) {
    encounteredWithStatement = b;
  }

  public boolean isToProcessMembers() {
    return toProcessMembers;
  }

  public void setToProcessMembers(final boolean toProcessMembers) {
    this.toProcessMembers = toProcessMembers;
  }

  public void setProcessStatics(final boolean processStatics) {
    this.processStatics = processStatics;
  }

  public boolean checkVisited(String className) {
    if (visitedClasses.contains(className)) return true;
    visitedClasses.add(className);
    return false;
  }

  public boolean isLocalResolve() {
    return localResolve;
  }

  public void setLocalResolve(final boolean localResolve) {
    this.localResolve = localResolve;
  }
}
