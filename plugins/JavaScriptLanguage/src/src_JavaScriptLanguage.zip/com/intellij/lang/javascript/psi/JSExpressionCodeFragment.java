package com.intellij.lang.javascript.psi;

/**
 * @author nik
 */
public interface JSExpressionCodeFragment extends JSFile {
}
