/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.structureView;

import com.intellij.ide.structureView.StructureViewTreeElement;
import com.intellij.ide.structureView.TextEditorBasedStructureViewModel;
import com.intellij.ide.util.treeView.smartTree.*;
import com.intellij.ide.IdeBundle;
import com.intellij.lang.javascript.psi.*;
import com.intellij.psi.PsiFile;
import com.intellij.util.Icons;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.NonNls;

import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Feb 10, 2005
 * Time: 3:13:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSStructureViewModel extends TextEditorBasedStructureViewModel {
  private JSElement myRoot;
  private Filter[] myFilters = new Filter[]{ourFilter};

  @NonNls private static final String ID = "KIND";
  private static Sorter ourKindSorter = new Sorter() {
    private Comparator myComparator = new Comparator() {
      public int compare(final Object o, final Object o2) {
        return getWeight(o) - getWeight(o2);
      }

      private int getWeight(final Object s) {
        final Object o = ((StructureViewTreeElement)s).getValue();
        if (o instanceof JSFunction) return 10;
        if (o instanceof JSVariable) return 20;
        return 30;
      }
    };

    public Comparator getComparator() {
      return myComparator;
    }

    @NotNull
    public ActionPresentation getPresentation() {
      return null; // will not be shown
    }

    @NotNull
    public String getName() {
      return ID;
    }
  };

  private static Filter ourFilter = new Filter() {
    @NonNls public static final String ID = "SHOW_FIELDS";

    public boolean isVisible(TreeElement treeNode) {
      final JSElement element = ((JSStructureViewElement)treeNode).getValue();
      return element instanceof JSFunction ||
             (element instanceof JSProperty && ((JSProperty)element).getValue() instanceof JSFunction) ||
             element instanceof JSObjectLiteralExpression;
    }

    public boolean isReverted() {
      return true;
    }

    @NotNull
    public ActionPresentation getPresentation() {
      return new ActionPresentationData(
        IdeBundle.message("action.structureview.show.fields"),
        null,
        Icons.FIELD_ICON
      );
    }

    @NotNull
    public String getName() {
      return ID;
    }
  };

  public JSStructureViewModel(final JSElement root) {
    super(root.getContainingFile());
    myRoot = root;
  }

  @NotNull
  public StructureViewTreeElement getRoot() {
    return new JSStructureViewElement(myRoot);
  }

  @NotNull
  public Grouper[] getGroupers() {
    return Grouper.EMPTY_ARRAY;
  }

  @NotNull
  public Sorter[] getSorters() {
    return new Sorter[] {ourKindSorter, Sorter.ALPHA_SORTER};
  }

  @NotNull
  public Filter[] getFilters() {
    return myFilters;
  }

  protected PsiFile getPsiFile() {
    return myRoot.getContainingFile();
  }

  @NotNull
  protected Class[] getSuitableClasses() {
    return new Class[] {JSFunction.class, JSVariable.class};
  }

  public void setFilters(final Filter[] filters) {
    myFilters = filters;
  }
}
