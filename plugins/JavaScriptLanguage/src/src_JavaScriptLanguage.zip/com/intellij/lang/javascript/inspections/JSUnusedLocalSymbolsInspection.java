/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript.inspections;

import com.intellij.codeHighlighting.HighlightDisplayLevel;
import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.codeInspection.ProblemsHolder;
import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.psi.*;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Key;
import com.intellij.psi.PsiElement;
import com.intellij.psi.ResolveResult;
import com.intellij.psi.PsiFile;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.util.IncorrectOperationException;
import gnu.trove.THashSet;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.PropertyKey;

import java.util.Set;
import java.util.Collections;

/**
 * @author Maxim.Mossienko
 */
public class JSUnusedLocalSymbolsInspection extends JSInspection {
  private static final Logger LOG = Logger.getInstance("JSUnusedLocalSymbols");
  @NonNls private static final String SHORT_NAME = "JSUnusedLocalSymbols";

  @NotNull
  public String getGroupDisplayName() {
    return JSBundle.message("js.inspection.group.name");
  }

  @NotNull
  public String getDisplayName() {
    return JSBundle.message("js.unused.local.symbol.inspection.name");
  }

  @NotNull
  @NonNls
  public String getShortName() {
    return SHORT_NAME;
  }

  private static final Key<Set<PsiElement>> ourUnusedLocalDeclarationsSetKey = Key.create("js unused local dcls key");
  private static final Key<Set<PsiElement>> ourUsedLocalDeclarationsSetKey = Key.create("js used local functions key");

  protected BasePsiElementVisitor createVisitor(final ProblemsHolder holder) {
    return new BasePsiElementVisitor() {
      public void visitJSVariable(final JSVariable node) {
        handleLocalDeclaration(node);
      }

      public void visitJSParameterList(final JSParameterList node) {
        PsiElement parent = node.getParent();
        final Set<PsiElement> set = parent.getUserData(ourUnusedLocalDeclarationsSetKey);

        if (set == null) {
          parent.putUserData(ourUnusedLocalDeclarationsSetKey, Collections.synchronizedSet(new THashSet<PsiElement>(3)));
        } else if (node.getParameters().length == 0) {
          set.clear();
        }
      }

      public void visitFile(final PsiFile file) {
        final Set<PsiElement> set = file.getUserData(ourUnusedLocalDeclarationsSetKey);
        if (set != null) set.clear();
      }

      public void visitJSParameter(final JSParameter node) {
        final PsiElement scopeNode = PsiTreeUtil.getParentOfType(node, JSFunction.class, JSCatchBlock.class);
        final Set<PsiElement> unusedParametersSet;
        final PsiElement parameterList = node.getParent();

        if(scopeNode == null) return;
        
        if (parameterList.getNode().findChildByType(JSElementTypes.FORMAL_PARAMETER) == node.getNode()) {
          unusedParametersSet = Collections.synchronizedSet(new THashSet<PsiElement>(3));
          scopeNode.putUserData(ourUnusedLocalDeclarationsSetKey, unusedParametersSet);
        } else {
          unusedParametersSet = scopeNode.getUserData(ourUnusedLocalDeclarationsSetKey);
          if(unusedParametersSet == null) return;
        }
        unusedParametersSet.add(node);
      }

      public void visitJSReferenceExpression(final JSReferenceExpression node) {
        if (node.getParent() instanceof JSFunction) return;
        if (node.getQualifier() == null) {
          if ("arguments".equals(node.getText())) {
            JSFunction function = PsiTreeUtil.getParentOfType(node, JSFunction.class);
            if(function == null) return;
            Set<PsiElement> unusedParametersSet = function.getUserData(ourUnusedLocalDeclarationsSetKey);
            if(unusedParametersSet == null) return;
            for(JSParameter p:function.getParameterList().getParameters()) unusedParametersSet.remove(p);
            return;
          }

          ResolveResult[] results = node.multiResolve(false);

          for(ResolveResult r:results) {
            final PsiElement element = r.getElement();

            if (element instanceof JSVariable ||
                ( element instanceof JSFunction && isSupportedFunction((JSFunction)element) )
               ) {
              assert !(element instanceof JSFunctionExpression);
              PsiElement scopeHandler = PsiTreeUtil.getParentOfType(element, JSFunction.class);

              if (scopeHandler != null) {
                Set<PsiElement> unusedParametersSet = scopeHandler.getUserData(ourUnusedLocalDeclarationsSetKey);

                if (unusedParametersSet != null) {
                  final boolean removed = unusedParametersSet.remove(element);

                  if (!removed && element instanceof JSFunction) {
                    Set<PsiElement> set = scopeHandler.getUserData(ourUsedLocalDeclarationsSetKey);
                    if (set == null) {
                      set = new THashSet<PsiElement>(3);
                      scopeHandler.putUserData(ourUsedLocalDeclarationsSetKey, set);
                    }
                    set.add(element);
                  }
                }
              }
            }
          }
        }
      }

      public void visitJSFunctionExpression(final JSFunctionExpression node) {
        visitJSFunctionDeclaration((JSFunction)node);
      }

      public void visitJSFunctionDeclaration(final JSFunction node) {
        processDeclarationHost(node, holder);
        handleLocalDeclaration(node);
      }
    };
  }

  private static boolean isSupportedFunction(final JSFunction element) {
    return !(element instanceof JSFunctionExpression ||
      element.getParent() instanceof JSProperty
    );
  }

  private static void processDeclarationHost(final PsiElement node, final ProblemsHolder holder) {
    Set<PsiElement> unusedDeclarationsSet = node.getUserData(ourUnusedLocalDeclarationsSetKey);
    if (unusedDeclarationsSet == null ||
        node instanceof JSFunction &&
        ((JSFunction)node).getBody().length == 0
       ) {
      return;
    }

    try {
      unusedDeclarationsSet = new THashSet<PsiElement>(unusedDeclarationsSet);

      for(PsiElement p:unusedDeclarationsSet) {
        if (unusedDeclarationsSet.contains(p)) {
          final @NonNls @PropertyKey(resourceBundle = JSBundle.BUNDLE) String messageId;
          final @NotNull PsiElement highlightedElement;

          if (p instanceof JSParameter) {
            messageId = "js.unused.parameter";
            highlightedElement = p;
          } else if (p instanceof JSFunction) {
            final ASTNode nameIdentifier = ((JSFunction)p).findNameIdentifier();
            if (nameIdentifier == null) {
              continue;
            }
            highlightedElement = nameIdentifier.getPsi();
            messageId = "js.unused.function.declaration";
          } else {
            highlightedElement = ((JSVariable)p).findNameIdentifier().getPsi();
            messageId = "js.unused.local.variable";
          }

          if (p.getParent() instanceof JSCatchBlock) {
            holder.registerProblem(highlightedElement, JSBundle.message(messageId));
          } else {
            holder.registerProblem(highlightedElement, JSBundle.message(messageId), new RemoveElementLocalQuickFix());
          }
        }
      }
    }
    finally {
      node.putUserData(ourUnusedLocalDeclarationsSetKey, null);
    }
  }

  private static void handleLocalDeclaration(final JSNamedElement node) {
    if (node instanceof JSFunction && !isSupportedFunction((JSFunction)node)) return;
    final PsiElement scopeNode = PsiTreeUtil.getParentOfType(node, JSFunction.class, JSCatchBlock.class);
    if(scopeNode == null) return;
    final Set<PsiElement> unusedParametersSet = scopeNode.getUserData(ourUnusedLocalDeclarationsSetKey);
    final Set<PsiElement> usedSet = scopeNode.getUserData(ourUsedLocalDeclarationsSetKey);
    if (usedSet != null && usedSet.contains(node)) {
      return;
    }
    if(unusedParametersSet == null) return;
    unusedParametersSet.add(node);
  }

  @NotNull
  public HighlightDisplayLevel getDefaultLevel() {
    return HighlightDisplayLevel.WARNING;
  }

  private static class RemoveElementLocalQuickFix implements LocalQuickFix {
    @NotNull
    public String getName() {
      return JSBundle.message("js.unused.symbol.remove");
    }

    @NotNull
    public String getFamilyName() {
      return getName();
    }

    public void applyFix(@NotNull final Project project, @NotNull final ProblemDescriptor descriptor) {
      try {
        PsiElement element = descriptor.getPsiElement();
        if (!(element instanceof JSNamedElement)) element = element.getParent();
        element.delete();
      }
      catch (IncorrectOperationException e) {
        LOG.error(e);
      }
    }
  }
}
