/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi.impl;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.lang.javascript.psi.*;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiElementVisitor;
import com.intellij.psi.PsiSubstitutor;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.psi.search.LocalSearchScope;
import com.intellij.psi.search.SearchScope;
import com.intellij.psi.tree.TokenSet;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.util.Icons;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 30, 2005
 * Time: 8:47:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSVariableImpl extends JSElementImpl implements JSVariable {
  private static final TokenSet IDENTIFIER_TOKENS_SET = TokenSet.orSet(JSTokenTypes.IDENTIFIER_TOKENS_SET, TokenSet.create(JSElementTypes.REFERENCE_EXPRESSION));
  
  public JSVariableImpl(final ASTNode node) {
    super(node);
  }

  public boolean hasInitializer() {
    return getInitializer() != null;
  }

  public JSExpression getInitializer() {
    final ASTNode eqNode = getNode().findChildByType(JSTokenTypes.EQ);
    final ASTNode node = eqNode != null ? getNode().findChildByType(JSElementTypes.EXPRESSIONS,eqNode):null;
    return node != null ? (JSExpression)node.getPsi() : null;
  }

  public String getName() {
    final ASTNode name = findNameIdentifier();

    if (name != null) {
      final PsiElement element = name.getPsi();

      if (element instanceof JSReferenceExpression) {
        return ((JSReferenceExpression)element).getReferencedName();
      }
    }
    return name != null ? name.getText() : "";
  }

  public ASTNode findNameIdentifier() {
    return getNode().findChildByType(IDENTIFIER_TOKENS_SET);
  }

  public JSAttributeList getAttributeList() {
    final ASTNode node = getNode().getTreeParent().findChildByType(JSElementTypes.ATTRIBUTE_LIST);
    return node != null ? (JSAttributeList)node.getPsi():null;
  }

  public void setInitializer(JSExpression expr) throws IncorrectOperationException {
    throw new UnsupportedOperationException("TODO: implement");
  }

  public JSType getType() {
    return null; //TODO
  }

  public PsiElement setName(@NotNull String name) throws IncorrectOperationException {
    final ASTNode nameNode = findNameIdentifier();
    if (nameNode == null) return this;
    final ASTNode nameElement = JSChangeUtil.createNameIdentifier(getProject(), name);
    getNode().replaceChild(nameNode, nameElement);
    return this;
  }

  public void accept(@NotNull PsiElementVisitor visitor) {
    if (visitor instanceof JSElementVisitor) {
      ((JSElementVisitor)visitor).visitJSVariable(this);
    }
    else {
      visitor.visitElement(this);
    }
  }

  public int getTextOffset() {
    final ASTNode name = findNameIdentifier();
    return name != null ? name.getStartOffset() : super.getTextOffset();
  }

  public boolean isConst() {
    final ASTNode parent = getNode().getTreeParent();
    return parent.getElementType() == JSElementTypes.VAR_STATEMENT && parent.getFirstChildNode().getElementType() == JSTokenTypes.CONST_KEYWORD;
  }

  public Icon getIcon(int flags) {
    final PsiElement parent = getParent();
    final PsiElement grandParent = parent != null ? parent.getParent():null;
    
    if (grandParent instanceof JSClass) {
      final JSAttributeList attributeList = getAttributeList();
      if (attributeList != null) {
        return buildIcon(Icons.VARIABLE_ICON, attributeList.getAccessType().getIcon());
      }
    } else if (grandParent instanceof JSBlockStatement || grandParent instanceof JSLoopStatement) {
      return buildIcon(Icons.VARIABLE_ICON, Icons.PRIVATE_ICON);
    }
    return Icons.VARIABLE_ICON;
  }

  public void delete() throws IncorrectOperationException {
    final ASTNode myNode = getNode();
    final ASTNode parent = myNode.getTreeParent();

    if (parent.getElementType() == JSElementTypes.VAR_STATEMENT) {
      final JSVariable[] jsVariables = ((JSVarStatement)parent.getPsi()).getVariables();

      if (jsVariables.length == 1) parent.getPsi().delete();
      else {
        JSChangeUtil.removeRangeWithRemovalOfCommas(myNode, parent);
      }
      return;
    }

    throw new IncorrectOperationException("Cannot delete variable from parent : " + parent.getElementType());
  }

  public boolean processDeclarations(@NotNull final PsiScopeProcessor processor, @NotNull final PsiSubstitutor substitutor, final PsiElement lastParent,
                                     @NotNull final PsiElement place) {
    return processor.execute(this, substitutor);
  }

  @NotNull
  public SearchScope getUseScope() {
    //This is true as long as we have no inter-file references
    final PsiElement element = PsiTreeUtil.getParentOfType(this, JSFunction.class, JSCatchBlock.class);

    if (element != null) return new LocalSearchScope(element);
    return super.getUseScope();
  }
}
