/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi;

import com.intellij.extapi.psi.PsiFileBase;
import com.intellij.lang.LanguageDialect;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.index.JavaScriptIndex;
import com.intellij.lang.javascript.psi.impl.JSChangeUtil;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.openapi.fileTypes.FileType;
import com.intellij.psi.FileViewProvider;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiElementVisitor;
import com.intellij.psi.PsiSubstitutor;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 28, 2005
 * Time: 12:25:04 AM
 * To change this template use File | Settings | File Templates.
 */
public class JSFile extends PsiFileBase implements JSElement {
  public JSFile(FileViewProvider fileViewProvider) {
    super(fileViewProvider, JavaScriptSupportLoader.JAVASCRIPT.getLanguage());
  }

  @NotNull
  public FileType getFileType() {
    return JavaScriptSupportLoader.JAVASCRIPT;
  }

  public String toString() {
    return "JSFile:" + getName();
  }

  public boolean processDeclarations(@NotNull PsiScopeProcessor processor,
                                     @NotNull PsiSubstitutor substitutor,
                                     @Nullable PsiElement lastParent,
                                     @NotNull PsiElement place) {
    boolean result = JSResolveUtil.processDeclarationsInScope(this, processor, substitutor, lastParent, place);
    if (result) result = JSResolveUtil.tryResolveImports(processor, this, place);
    return result;
  }

  public void accept(@NotNull PsiElementVisitor visitor) {
    if (visitor instanceof JSElementVisitor) {
      ((JSElementVisitor)visitor).visitJSElement(this);
    }
    else {
      super.accept(visitor);
    }
  }

  public PsiElement addRangeBefore(@NotNull PsiElement first, @NotNull PsiElement last, PsiElement anchor) throws IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(first)) {
      return JSChangeUtil.doAddRangeBefore(this, first, last, anchor);
    }
    return super.addRangeBefore(first, last, anchor);
  }

  public PsiElement addRange(PsiElement first, PsiElement last) throws IncorrectOperationException {
    return addRangeAfter(first, last, null);
  }

  public PsiElement addAfter(@NotNull PsiElement element, PsiElement anchor) throws IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(element)) {
      return JSChangeUtil.doAddAfter(this, element, anchor);
    }
    return super.addAfter(element, anchor);
  }

  public PsiElement addBefore(@NotNull PsiElement element, PsiElement anchor) throws IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(element)) {
      return JSChangeUtil.doAddBefore(this, element, anchor);
    }
    return super.addBefore(element, anchor);
  }

  public boolean isWritable() {
    return super.isWritable() && 
           (getVirtualFile() != null || getUserData(JavaScriptIndex.READONLY_JS_FILE_KEY) == null);
  }

  public PsiElement addRangeAfter(PsiElement first, PsiElement last, PsiElement anchor) throws IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(first)) {
      return JSChangeUtil.doAddRangeAfter(this, first, last, anchor);
    }

    return super.addRangeAfter(first, last, anchor);
  }

  public PsiElement add(@NotNull PsiElement element) throws IncorrectOperationException {
    return addAfter(element, null);
  }

  @NonNls
  @Nullable
  public LanguageDialect getLanguageDialect() {
    LanguageDialect dialect = JavaScriptSupportLoader.getLanguageDialect(getViewProvider().getVirtualFile());
    if (dialect == null) {
      dialect = super.getLanguageDialect();
    }
    return dialect;
  }
}
