/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi;

import com.intellij.extapi.psi.PsiFileBase;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.psi.impl.JSChangeUtil;
import com.intellij.openapi.fileTypes.FileType;
import com.intellij.psi.FileViewProvider;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiElementVisitor;
import com.intellij.psi.PsiSubstitutor;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 28, 2005
 * Time: 12:25:04 AM
 * To change this template use File | Settings | File Templates.
 */
public class JSFile extends PsiFileBase implements JSElement {
  public JSFile(FileViewProvider fileViewProvider) {
    super(fileViewProvider, JavaScriptSupportLoader.JAVASCRIPT.getLanguage());
  }

  @NotNull
  public FileType getFileType() {
    return JavaScriptSupportLoader.JAVASCRIPT;
  }

  public String toString() {
    return "JSFile:" + getName();
  }

  public boolean processDeclarations(PsiScopeProcessor processor,
                                     PsiSubstitutor substitutor,
                                     PsiElement lastParent,
                                     PsiElement place) {
    final PsiElement[] children = getChildren();
    for (PsiElement child : children) {
      if (child == lastParent) break;
      if (!child.processDeclarations(processor, substitutor, lastParent, place)) return false;
    }
    return true;
  }

  public void accept(PsiElementVisitor visitor) {
    if (visitor instanceof JSElementVisitor) {
      ((JSElementVisitor)visitor).visitJSElement(this);
    }
    else {
      super.accept(visitor);
    }
  }

  public PsiElement addRangeBefore(PsiElement first, PsiElement last, PsiElement anchor) throws IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(first)) {
      return JSChangeUtil.doAddRangeBefore(this, first, last, anchor);
    }
    return super.addRangeBefore(first, last, anchor);
  }

  public PsiElement addRange(PsiElement first, PsiElement last) throws IncorrectOperationException {
    return addRangeAfter(first, last, null);
  }

  public PsiElement addAfter(PsiElement element, PsiElement anchor) throws IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(element)) {
      return JSChangeUtil.doAddAfter(this, element, anchor);
    }
    return super.addAfter(element, anchor);
  }

  public PsiElement addBefore(PsiElement element, PsiElement anchor) throws IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(element)) {
      return JSChangeUtil.doAddBefore(this, element, anchor);
    }
    return super.addBefore(element, anchor);
  }

  public boolean isWritable() {
    return super.isWritable() && getVirtualFile() != null;
  }

  public PsiElement addRangeAfter(PsiElement first, PsiElement last, PsiElement anchor) throws IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(first)) {
      return JSChangeUtil.doAddRangeAfter(this, first, last, anchor);
    }

    return super.addRangeAfter(first, last, anchor);
  }

  public PsiElement add(@NotNull PsiElement element) throws IncorrectOperationException {
    return addAfter(element, null);
  }
}
