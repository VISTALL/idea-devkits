package com.intellij.lang.javascript;

/**
 * @author Maxim.Mossienko
 */
public final class DialectOptionHolder {
  public final boolean isECMAL4Level;
  public final boolean isGwt;

  public DialectOptionHolder(boolean _ecma, boolean _gwt) {
    isECMAL4Level = _ecma;
    isGwt = _gwt;

    assert !isGwt || !isECMAL4Level;
  }
}
