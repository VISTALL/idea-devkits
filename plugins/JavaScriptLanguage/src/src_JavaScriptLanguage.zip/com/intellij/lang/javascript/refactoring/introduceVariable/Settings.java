package com.intellij.lang.javascript.refactoring.introduceVariable;

/**
 * @author ven
 */
public interface Settings {
  boolean isReplaceAllOccurences();

  String getVariableName();
}
