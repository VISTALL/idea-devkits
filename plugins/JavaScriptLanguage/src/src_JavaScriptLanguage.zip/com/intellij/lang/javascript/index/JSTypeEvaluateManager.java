/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript.index;

import com.intellij.lang.javascript.psi.JSNamedElement;
import com.intellij.lang.javascript.psi.JSReferenceExpression;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiNamedElement;
import com.intellij.psi.ResolveResult;
import com.intellij.psi.xml.XmlTag;
import com.intellij.psi.xml.XmlToken;
import com.intellij.util.Processor;
import gnu.trove.TIntObjectHashMap;
import gnu.trove.TObjectHashingStrategy;
import gnu.trove.TObjectIntHashMap;
import gnu.trove.TIntHashSet;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: Maxim.Mossienko
 * Date: Apr 26, 2006
 * Time: 5:14:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSTypeEvaluateManager implements ProjectComponent {
  private TObjectIntHashMap<JSNamedElement> myTypeMap = new TObjectIntHashMap<JSNamedElement>(30);
  private TObjectIntHashMap<JSNamespace> mySupersMap = new TObjectIntHashMap<JSNamespace>(50);
  private TIntObjectHashMap<List<JSNamespace>> myName2ElementMap = new TIntObjectHashMap<List<JSNamespace>>(30);
  private final JavaScriptIndex myIndex;

  public static JSTypeEvaluateManager getInstance(Project project) {
    return project.getComponent(JSTypeEvaluateManager.class);
  }

  public JSTypeEvaluateManager(JavaScriptIndex index) {
    myIndex = index;
  }

  public void projectOpened() {}
  public void projectClosed() {}

  @NonNls
  @NotNull
  public String getComponentName() {
    return "JS.TypeEvaluateManager";
  }

  public void initComponent() {}
  public void disposeComponent() {}

  public void setElementType(JSNamedElement element,String type) {
    myTypeMap.put(element, myIndex.getIndexOf(type));
  }

  public String getElementType(PsiNamedElement element) {
    if (element instanceof JSNamedElement) {
      int i = myTypeMap.get((JSNamedElement)element);
      if (i == 0) return null;
      return myIndex.getStringByIndex(i);
    }
    return null;
  }

  public void setBaseType(JSNamespace namespace,String fqtype, JSNamespace superNs, String superFQType) {
    final int fqSuperIndex = myIndex.getIndexOf(superFQType);
    mySupersMap.put(namespace, fqSuperIndex);
    doAddNsWithType(myIndex.getIndexOf(fqtype), namespace);
    doAddNsWithType(fqSuperIndex, superNs);
  }

  public void iterateTypeHierarchy(String fqTypeName, Processor<JSNamespace> processor) {
    final int key = myIndex.getIndexOf(fqTypeName);

    List<JSNamespace> namedElements = myName2ElementMap.get(key);
    if (namedElements != null) {
      for(JSNamespace namespace:namedElements) {
        if (!doIterateType(namespace, processor)) return;
      }
    }
  }

  public boolean doIterateType(final JSNamespace namespace, final Processor<JSNamespace> processor) {
    return doIterateTypeImpl(namespace, processor, new TIntHashSet());
  }

  private boolean doIterateTypeImpl(final JSNamespace namespace, final Processor<JSNamespace> processor, TIntHashSet visited) {
    final int superNameId = mySupersMap.get(namespace);

    if (superNameId != 0 && !visited.contains(superNameId)) {
      visited.add(superNameId);
      final List<JSNamespace> superNamedElements = myName2ElementMap.get(superNameId);

      if (superNamedElements != null) {
        for(JSNamespace superNs:superNamedElements) {
          if (!processor.process(superNs)) return false;
          if (!doIterateTypeImpl(superNs, processor, visited)) return false;
        }
      }
    }
    return true;
  }

  public boolean isTypeWithDefaultIndexedProperty(String s) {
    if (s == null) return false;
    return isArrayType(s) || s.endsWith("List") || s.endsWith("Map");
  }

  public boolean isArrayType(String s) {
    if (s == null) return false;
    return s.endsWith("[]");
  }

  public String getComponentType(String s) {
    if (isArrayType(s)) return s.substring(0,s.length() - 2);
    return s;
  }

  public String evaluateType(JSReferenceExpression expr) {
    for(ResolveResult r:expr.multiResolve(false)) {
      final String type = getElementType((JSNamedElement)r.getElement());
      if (type != null) return type;
    }
    return null;
  }

  public String getInstanceNameByType(String className) {
    if ("Document".equals(className)) return "HTMLDocument";
    if ("Element".equals(className)) return "HTMLElement";
    return className;
  }

  public void clear() {
    myTypeMap.clear();
    mySupersMap.clear();
    myName2ElementMap.clear();
  }

  public void removeNSInfo(final JSNamespace el) {
    final int i = mySupersMap.remove(el);

    if (i != 0) {
      final List<JSNamespace> list = myName2ElementMap.get(i);

      if (list != null) {
        list.remove(el);
        if (list.size() == 0) myName2ElementMap.remove(i);
      }
    }
  }

  public void removeElementInfo(final JSNamedElement el) {
    myTypeMap.remove(el);
  }

  public String getBaseType(final JSNamespace namespace) {
    int i = mySupersMap.get(namespace);
    if (i == 0) return null;
    return myIndex.getStringByIndex(i);
  }

  private void doAddNsWithType(final int key, final JSNamespace superNs) {
    List<JSNamespace> namespaces = myName2ElementMap.get(key);

    if (namespaces == null) {
      namespaces = new ArrayList<JSNamespace>(1);
      myName2ElementMap.put(key, namespaces);
      namespaces.add(superNs);
    } else {
      if (namespaces.indexOf(superNs) == -1) namespaces.add(superNs);
    }
  }

  private static class MyTObjectHashingStrategy implements TObjectHashingStrategy<JSNamespace> {
    static MyTObjectHashingStrategy INSTANCE = new MyTObjectHashingStrategy();

    public int computeHashCode(final JSNamespace object) {
      return object.getNameId();
    }

    public boolean equals(JSNamespace o1, JSNamespace o2) {
      while(o1 != null && o2 != null && o1.getNameId() == o2.getNameId()) {
        o1 = o1.getParent();
        o2 = o2.getParent();
      }

      return o1 == o2;
    }
  }
}
