package com.intellij.lang.javascript.psi;

/**
 * Created by IntelliJ IDEA.
 * User: Maxim.Mossienko
 * Date: 19.03.2009
 * Time: 16:15:34
 * To change this template use File | Settings | File Templates.
 */
public interface JSPackage extends JSQualifiedNamedElement {
}
