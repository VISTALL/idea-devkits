/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript;

import com.intellij.psi.TokenType;
import com.intellij.psi.JavaDocTokenType;
import com.intellij.psi.tree.IElementType;
import com.intellij.psi.tree.TokenSet;
import com.intellij.lang.StdLanguages;
import com.intellij.lexer.Lexer;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 27, 2005
 * Time: 6:40:01 PM
 * To change this template use File | Settings | File Templates.
 */
public interface JSTokenTypes {  
  IElementType IDENTIFIER = new JSElementType("IDENTIFIER");
  IElementType WHITE_SPACE = TokenType.WHITE_SPACE;
  IElementType BAD_CHARACTER = TokenType.BAD_CHARACTER;

  IElementType SEMANTIC_LINEFEED = new JSElementType("SEMANTIC_LINEFEED");

  IElementType END_OF_LINE_COMMENT = new JSElementType("END_OF_LINE_COMMENT");
  IElementType C_STYLE_COMMENT = new JSElementType("C_STYLE_COMMENT");
  IElementType XML_STYLE_COMMENT = new JSElementType("XML_STYLE_COMMENT");
  IElementType XML_STYLE_COMMENT_START = new JSElementType("XML_STYLE_COMMENT_START");
  IElementType DOC_COMMENT = new JSElementType("DOC_COMMENT");

  // Keywords:
  IElementType BREAK_KEYWORD = new JSElementType("BREAK_KEYWORD");
  IElementType CASE_KEYWORD = new JSElementType("CASE_KEYWORD");
  IElementType CATCH_KEYWORD = new JSElementType("CATCH_KEYWORD");
  IElementType CONST_KEYWORD = new JSElementType("CONST_KEYWORD");
  IElementType CONTINUE_KEYWORD = new JSElementType("CONTINUE_KEYWORD");
  IElementType DELETE_KEYWORD = new JSElementType("DELETE_KEYWORD");
  IElementType DEFAULT_KEYWORD = new JSElementType("DEFAULT_KEYWORD");
  IElementType DO_KEYWORD = new JSElementType("DO_KEYWORD");
  IElementType ELSE_KEYWORD = new JSElementType("ELSE_KEYWORD");
  IElementType FINALLY_KEYWORD = new JSElementType("FINALLY_KEYWORD");
  IElementType FOR_KEYWORD = new JSElementType("FOR_KEYWORD");
  IElementType FUNCTION_KEYWORD = new JSElementType("FUNCTION_KEYWORD");
  IElementType IF_KEYWORD = new JSElementType("IF_KEYWORD");
  IElementType IN_KEYWORD = new JSElementType("IN_KEYWORD");
  IElementType INSTANCEOF_KEYWORD = new JSElementType("INSTANCEOF_KEYWORD");
  IElementType NEW_KEYWORD = new JSElementType("NEW_KEYWORD");
  IElementType RETURN_KEYWORD = new JSElementType("RETURN_KEYWORD");
  IElementType SWITCH_KEYWORD = new JSElementType("SWITCH_KEYWORD");
  IElementType THIS_KEYWORD = new JSElementType("THIS_KEYWORD");
  IElementType THROW_KEYWORD = new JSElementType("THROW_KEYWORD");
  IElementType TRY_KEYWORD = new JSElementType("TRY_KEYWORD");
  IElementType TYPEOF_KEYWORD = new JSElementType("TYPEOF_KEYWORD");
  IElementType VAR_KEYWORD = new JSElementType("VAR_KEYWORD");
  IElementType VOID_KEYWORD = new JSElementType("VOID_KEYWORD");
  IElementType WHILE_KEYWORD = new JSElementType("WHILE_KEYWORD");
  IElementType WITH_KEYWORD = new JSElementType("WITH_KEYWORD");

  // Hardcoded literals
  IElementType TRUE_KEYWORD = new JSElementType("TRUE_KEYWORD");
  IElementType FALSE_KEYWORD = new JSElementType("FALSE_KEYWORD");
  IElementType NULL_KEYWORD = new JSElementType("NULL_KEYWORD");
  IElementType UNDEFINED_KEYWORD = new JSElementType("UNDEFINED_KEYWORD");

  TokenSet KEYWORDS = TokenSet.create(
                        BREAK_KEYWORD, CASE_KEYWORD, CATCH_KEYWORD, CONST_KEYWORD, CONTINUE_KEYWORD, DELETE_KEYWORD, DEFAULT_KEYWORD,
                            DO_KEYWORD, ELSE_KEYWORD, FINALLY_KEYWORD, FOR_KEYWORD, FUNCTION_KEYWORD, IF_KEYWORD, IN_KEYWORD,
                            INSTANCEOF_KEYWORD, NEW_KEYWORD, RETURN_KEYWORD, SWITCH_KEYWORD, THIS_KEYWORD, THROW_KEYWORD,
                            TRY_KEYWORD, TYPEOF_KEYWORD, VAR_KEYWORD, VOID_KEYWORD, WHILE_KEYWORD, WITH_KEYWORD, TRUE_KEYWORD,
                            FALSE_KEYWORD, NULL_KEYWORD, UNDEFINED_KEYWORD);

  // Literals
  IElementType NUMERIC_LITERAL = new JSElementType("NUMERIC_LITERAL");
  IElementType STRING_LITERAL = new JSElementType("STRING_LITERAL");
  IElementType SINGLE_QUOTE_STRING_LITERAL = new JSElementType("SINGLE_QUOTE_STRING_LITERAL");
  IElementType REGEXP_LITERAL = new JSElementType("REGEXP_LITERAL");

  // Punctuators
  IElementType LBRACE = new JSElementType("LBRACE");// {
  IElementType RBRACE = new JSElementType("RBRACE");// }
  IElementType LPAR = new JSElementType("LPAR");// (
  IElementType RPAR = new JSElementType("RPAR");// )
  IElementType LBRACKET = new JSElementType("LBRACKET");// [
  IElementType RBRACKET = new JSElementType("RBRACKET");// ]
  IElementType DOT = new JSElementType("DOT");// .
  IElementType SEMICOLON = new JSElementType("SEMICOLON");// ;
  IElementType COMMA = new JSElementType("COMMA");// ,

  IElementType LT = new JSElementType("LT");// <
  IElementType GT = new JSElementType("GT");// >
  IElementType LE = new JSElementType("LE");// <=
  IElementType GE = new JSElementType("GE");// >=
  IElementType EQEQ = new JSElementType("EQEQ");// ==
  IElementType NE = new JSElementType("NE");// !=
  IElementType EQEQEQ = new JSElementType("EQEQEQ");// ===
  IElementType NEQEQ = new JSElementType("NEQEQ");// !==
  IElementType PLUS = new JSElementType("PLUS");// +
  IElementType MINUS = new JSElementType("MINUS");// -
  IElementType MULT = new JSElementType("MULT");// *
  IElementType PERC = new JSElementType("PERC");// %
  IElementType PLUSPLUS = new JSElementType("PLUSPLUS");// ++
  IElementType MINUSMINUS = new JSElementType("MINUSMINUS");// --
  IElementType LTLT = new JSElementType("LTLT");// <<
  IElementType GTGT = new JSElementType("GTGT");// >>
  IElementType GTGTGT = new JSElementType("GTGTGT");// >>>
  IElementType AND = new JSElementType("AND");// &
  IElementType OR = new JSElementType("OR");// |
  IElementType XOR = new JSElementType("XOR");// ^
  IElementType EXCL = new JSElementType("EXCL");// !
  IElementType TILDE = new JSElementType("TILDE");// ~
  IElementType ANDAND = new JSElementType("ANDAND");// &&
  IElementType OROR = new JSElementType("OROR");// ||
  IElementType QUEST = new JSElementType("QUEST");// ?
  IElementType COLON = new JSElementType("COLON");// :
  IElementType EQ = new JSElementType("EQ");// =
  IElementType PLUSEQ = new JSElementType("PLUSEQ");// +=
  IElementType MINUSEQ = new JSElementType("MINUSEQ");// -=
  IElementType MULTEQ = new JSElementType("MULTEQ");// *=
  IElementType PERCEQ = new JSElementType("PERCEQ");// %=
  IElementType LTLTEQ = new JSElementType("LTLTEQ");// <<=
  IElementType GTGTEQ = new JSElementType("GTGTEQ");// >>=
  IElementType GTGTGTEQ = new JSElementType("GTGTGTEQ");// >>>=
  IElementType ANDEQ = new JSElementType("ANDEQ");// &=
  IElementType OREQ = new JSElementType("OREQ");// |=
  IElementType XOREQ = new JSElementType("XOREQ");// ^=
  IElementType DIV = new JSElementType("DIV"); // /
  IElementType DIVEQ = new JSElementType("DIVEQ"); // /=

  IElementType CDATA_START = new JSElementType("CDATA_START"); // <![CDATA[
  IElementType CDATA_END = new JSElementType("CDATA_END"); // ]]>

  TokenSet OPERATIONS = TokenSet.create(
    LT, GT, LE, GE, EQEQ, NE, EQEQEQ, NEQEQ, PLUS, MINUS, MULT, PERC, PLUSPLUS, MINUSMINUS, LTLT, GTGT, GTGTGT, AND, OR,
    XOR, EXCL, TILDE, ANDAND, OROR, QUEST, COLON, EQ, PLUSEQ, MINUSEQ, MULTEQ, PERCEQ, LTLTEQ, GTGTEQ, GTGTGTEQ, ANDEQ,
    OREQ, XOREQ, DIV, DIVEQ, COMMA
  );

  TokenSet ASSOC_OPERATIONS = TokenSet.create(PLUS, MULT, AND, OR, XOR, OROR, ANDAND);

  TokenSet ASSIGNMENT_OPERATIONS = TokenSet.create(
    EQ, PLUSEQ, MINUSEQ, MULTEQ, PERCEQ, LTLTEQ, GTGTEQ, GTGTGTEQ, ANDEQ,
    OREQ, XOREQ, DIVEQ
  );


  TokenSet EQUALITY_OPERATIONS = TokenSet.create(
    EQEQ, NE, EQEQEQ, NEQEQ
  );

  TokenSet RELATIONAL_OPERATIONS = TokenSet.create(
    LT, GT, LE, GE, INSTANCEOF_KEYWORD, IN_KEYWORD
  );

  TokenSet ADDITIVE_OPERATIONS = TokenSet.create(
    PLUS, MINUS
  );

  TokenSet MULTIPLICATIVE_OPERATIONS = TokenSet.create(
    MULT, DIV, PERC
  );

  TokenSet SHIFT_OPERATIONS = TokenSet.create(
    LTLT, GTGT, GTGTGT
  );

  TokenSet UNARY_OPERATIONS = TokenSet.create(
    PLUS, MINUS, PLUSPLUS, MINUSMINUS, TILDE, EXCL, TYPEOF_KEYWORD, VOID_KEYWORD, DELETE_KEYWORD
  );

  TokenSet COMMENTS = TokenSet.create(
    END_OF_LINE_COMMENT, DOC_COMMENT, C_STYLE_COMMENT, XML_STYLE_COMMENT, CDATA_START, CDATA_END,
    XML_STYLE_COMMENT_START, JavaScriptHighlightingLexer.getTagContentTokenType()
  );
}
