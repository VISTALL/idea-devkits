/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript.inspections;

import com.intellij.codeInsight.template.*;
import com.intellij.codeInsight.template.impl.MacroCallNode;
import com.intellij.codeInsight.template.macro.MacroFactory;
import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.codeInspection.ProblemHighlightType;
import com.intellij.codeInspection.ProblemsHolder;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.util.JSUtils;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.ResolveResult;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedList;
import java.util.List;

/**
 * @by Maxim.Mossienko
 */
public class JSUnresolvedFunctionInspection extends JSInspection {
  @NonNls private static final String SHORT_NAME = "JSUnresolvedFunction";

  @NotNull
  public String getGroupDisplayName() {
    return JSBundle.message("js.inspection.group.name");
  }

  @NotNull
  public String getDisplayName() {
    return JSBundle.message("js.unresolved.function.inspection.name");
  }

  @NotNull
  @NonNls
  public String getShortName() {
    return SHORT_NAME;
  }

  protected BasePsiElementVisitor createVisitor(final ProblemsHolder holder) {
    return new BasePsiElementVisitor() {
      public void visitJSCallExpression(final JSCallExpression node) {
        final JSExpression methodExpression = node.getMethodExpression();

        if (methodExpression instanceof JSReferenceExpression) {
          final JSReferenceExpression referenceExpression = (JSReferenceExpression)methodExpression;
          final ResolveResult[] resolveResults = referenceExpression.multiResolve(false);

          boolean noCompleteResolve = true;

          for(ResolveResult r:resolveResults) {
            if (r.isValidResult()) {
              noCompleteResolve = false;
              break;
            }
          }

          if (resolveResults.length == 0 || noCompleteResolve) {
            final JSExpression qualifier = referenceExpression.getQualifier();
            final List<LocalQuickFix> quickFixes = new LinkedList<LocalQuickFix>();

            final String refName = referenceExpression.getReferencedName();
            if (myOnTheFly && (qualifier == null || JSUtils.isLHSExpression(qualifier))) {
              quickFixes.add(
                new CreateJSFunctionIntentionAction(refName, true)
              );

              if (qualifier == null) {
                quickFixes.add(
                  new CreateJSFunctionIntentionAction(refName, false)
                );
              }
            }

            final PsiElement referenceNameElement = referenceExpression.getReferenceNameElement();

            if (referenceNameElement != null) {
              holder.registerProblem(referenceNameElement,
                JSBundle.message(
                  node instanceof JSNewExpression ?
                    "javascript.unresolved.type.name.message":
                    "javascript.unresolved.function.name.message", refName
                ),
                ProblemHighlightType.GENERIC_ERROR_OR_WARNING,
                quickFixes.size() > 0 ? quickFixes.toArray(new LocalQuickFix[quickFixes.size()]):null
              );
            }
          }
        }

        super.visitJSCallExpression(node);
      }
    };
  }

  private static class CreateJSFunctionIntentionAction extends BaseCreateFix {
    private final boolean myIsMethod;
    private final String myName;

    CreateJSFunctionIntentionAction(String name,boolean isMethod) {
      myIsMethod = isMethod;
      myName = name;
    }

    @NotNull
    public String getName() {
      return JSBundle.message(
        myIsMethod ? "javascript.create.method.intention.name":"javascript.create.function.intention.name",
        myName
      );
    }

    @NotNull
    public String getFamilyName() {
      return JSBundle.message("javascript.create.function.intention.family");
    }

    protected void buildTemplate(final Template template, JSReferenceExpression referenceExpression,
                                 boolean ecma, PsiFile file, PsiElement anchorParent) {
      JSCallExpression methodInvokation = (JSCallExpression)referenceExpression.getParent();

      String createdMethodName = ecma ? referenceExpression.getReferencedName():referenceExpression.getText();

      final JSArgumentList list = methodInvokation.getArgumentList();
      final JSExpression[] expressions = list.getArguments();
      int paramCount = expressions.length;

      if (!myIsMethod || ecma) template.addTextSegment("function ");
      template.addTextSegment(createdMethodName);
      if (myIsMethod && !ecma) template.addTextSegment(" = function ");
      template.addTextSegment("(");

      for(int i = 0 ; i < paramCount; ++i) {
        if (i != 0) template.addTextSegment(", ");
        String var = null;

        final JSExpression passedParameterValue = expressions[i];
        if (passedParameterValue instanceof JSReferenceExpression) {
          var = ((JSReferenceExpression)passedParameterValue).getReferencedName();
        }

        if (var == null || var.length() == 0) var = "param" + (i != 0 ? Integer.toString(i + 1):"");

        final String var1 = var;
        Expression expression = new MyExpression(var1);

        template.addVariable(var, expression, expression, true);
        if (ecma) {
          template.addTextSegment(":");
          String type = getTypeOfValue(passedParameterValue, file, ecma);

          final MyExpression paramTypeExpr = new MyExpression(type);
          template.addVariable(var1 + "Type", paramTypeExpr, paramTypeExpr, true);
        }
      }

      template.addTextSegment(")");
      if (ecma) {
        template.addTextSegment(":");
        final Expression paramTypeExpr = new MacroCallNode(MacroFactory.createMacro("complete"));
        template.addVariable("__funType", paramTypeExpr, paramTypeExpr, true);
      }

      if (anchorParent instanceof JSClass && ((JSClass)anchorParent).isInterface()) {
        template.addEndVariable();
      } else {
        template.addTextSegment(" {");
        template.addEndVariable();
        template.addTextSegment("}");
      }

      if (myIsMethod && !ecma) template.addTextSegment(";");
    }
  }
}
