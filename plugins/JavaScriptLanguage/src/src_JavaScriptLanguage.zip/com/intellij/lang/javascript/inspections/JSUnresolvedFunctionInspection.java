/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript.inspections;

import com.intellij.codeHighlighting.HighlightDisplayLevel;
import com.intellij.codeInsight.CodeInsightUtil;
import com.intellij.codeInsight.lookup.LookupItem;
import com.intellij.codeInsight.template.*;
import com.intellij.codeInspection.*;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.psi.JSArgumentList;
import com.intellij.lang.javascript.psi.JSCallExpression;
import com.intellij.lang.javascript.psi.JSExpression;
import com.intellij.lang.javascript.psi.JSReferenceExpression;
import com.intellij.lang.javascript.psi.util.JSUtils;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.fileEditor.OpenFileDescriptor;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.ResolveResult;
import org.jetbrains.annotations.NonNls;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: Maxim.Mossienko
 * Date: Apr 17, 2006
 * Time: 9:53:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSUnresolvedFunctionInspection extends JSInspection {
  @NonNls public static final String SHORT_NAME = "JSUnresolvedFunction";

  public String getGroupDisplayName() {
    return JSBundle.message("js.inspection.group.name");
  }

  public String getDisplayName() {
    return JSBundle.message("js.unresolved.function.inspection.name");
  }

  @NonNls
  public String getShortName() {
    return SHORT_NAME;
  }

  protected BasePsiElementVisitor createVisitor(final ProblemsHolder holder) {
    return new BasePsiElementVisitor() {
      public void visitJSCallExpression(final JSCallExpression node) {
        final JSExpression methodExpression = node.getMethodExpression();

        if (methodExpression instanceof JSReferenceExpression) {
          final JSReferenceExpression referenceExpression = (JSReferenceExpression)methodExpression;
          final ResolveResult[] resolveResults = referenceExpression.multiResolve(false);

          if (resolveResults.length == 0) {
            final JSExpression qualifier = referenceExpression.getQualifier();
            final List<LocalQuickFix> quickFixes = new LinkedList<LocalQuickFix>();

            if (myOnTheFly && (qualifier == null || JSUtils.isLHSExpression(qualifier))) {
              quickFixes.add(
                new CreateJSFunctionIntentionAction(node, true)
              );

              if (qualifier == null) {
                quickFixes.add(
                  new CreateJSFunctionIntentionAction(node, false)
                );
              }
            }

            final PsiElement referenceNameElement = referenceExpression.getReferenceNameElement();

            if (referenceNameElement != null) {
              holder.registerProblem(referenceNameElement,
                JSBundle.message(
                  "javascript.unresolved.function.name.message",
                  referenceExpression.getReferencedName()
                ),
                ProblemHighlightType.GENERIC_ERROR_OR_WARNING,
                quickFixes.size() > 0 ? quickFixes.toArray(new LocalQuickFix[quickFixes.size()]):null
              );
            }
          }
        }

        super.visitJSCallExpression(node);
      }
    };
  }

  private static class CreateJSFunctionIntentionAction implements LocalQuickFix {
    private final JSReferenceExpression myReferenceExpression;
    private final JSCallExpression myNode;
    private final boolean myIsMethod;
    private final PsiFile file;

    CreateJSFunctionIntentionAction(final JSCallExpression node, boolean isMethod) {
      myNode = node;
      myReferenceExpression = (JSReferenceExpression)node.getMethodExpression();
      myIsMethod = isMethod;
      file = node.getContainingFile();
    }

    public String getName() {
      return JSBundle.message(
        myIsMethod ? "javascript.create.method.intention.name":"javascript.create.function.intention.name",
        myReferenceExpression.getReferencedName()
      );
    }

    public String getFamilyName() {
      return JSBundle.message("javascript.create.function.intention.family");
    }

    public void applyFix(Project project, ProblemDescriptor descriptor) {
      if ( !CodeInsightUtil.prepareFileForWrite(file)) return;

      Editor editor = FileEditorManager.getInstance(project).openTextEditor(
        new OpenFileDescriptor(project, file.getVirtualFile()), false
      );

      PsiElement anchor = JSUtils.findStatementAnchor(myReferenceExpression, file);

      if (anchor != null) {
        final TemplateManager manager = TemplateManager.getInstance(project);
        Template template = manager.createTemplate("", "");

        final JSArgumentList list = myNode.getArgumentList();
        int paramCount = list.getArguments().length;

        if (!myIsMethod) template.addTextSegment("function ");
        template.addTextSegment(myReferenceExpression.getText());
        if (myIsMethod) template.addTextSegment(" = function ");
        template.addTextSegment("(");

        for(int i = 1 ; i <= paramCount; ++i) {
          if (i != 1) template.addTextSegment(", ");
          final String var = "param" + (i != 1 ? Integer.toString(i):"");

          Expression expression = new Expression() {
            TextResult result = new TextResult(var);

            public Result calculateResult(ExpressionContext context) {
              return result;
            }

            public Result calculateQuickResult(ExpressionContext context) {
              return result;
            }

            public LookupItem[] calculateLookupItems(ExpressionContext context) {
              return new LookupItem[0];
            }
          };

          template.addVariable(var, expression, expression, true);
        }

        template.addTextSegment(") {");
        template.addEndVariable();
        template.addTextSegment("}");

        if (myIsMethod) template.addTextSegment(";");
        template.addTextSegment("\n");

        editor.getCaretModel().moveToOffset(anchor.getTextOffset());
        manager.startTemplate(editor, template);
      }
    }
  }
}
