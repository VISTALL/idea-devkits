package com.intellij.lang.javascript.index;

import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.ResolveProcessor;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.xml.XmlDocument;
import com.intellij.psi.xml.XmlTag;
import gnu.trove.TIntArrayList;
import org.jetbrains.annotations.NonNls;

/**
 * Created by IntelliJ IDEA.
 * User: yole
 * Date: 04.10.2005
 * Time: 20:41:47
 * To change this template use File | Settings | File Templates.
 */
public class JSSymbolUtil {
  @NonNls private static final String PROTOTYPE_FIELD_NAME = "prototype";

  public static void visitSymbols(final PsiFile file, JSNamespace namespace, final JavaScriptSymbolProcessor symbolVisitor) {
    file.acceptChildren(new JSSymbolVisitor(namespace, symbolVisitor, file.getProject()));
  }

  private static JSElement findNameComponent(JSElement expr) {
    if (expr instanceof JSReferenceExpression) return (JSReferenceExpression)expr;
    JSElement current = expr;

    while(expr != null) {
      if (expr instanceof JSReferenceExpression) {
        return expr;
      } else if (expr instanceof JSAssignmentExpression) {
        final JSExpression _lOperand = ((JSAssignmentExpression)expr).getLOperand();
        if (!(_lOperand instanceof JSDefinitionExpression)) break;
        final JSExpression lOperand = ((JSDefinitionExpression)_lOperand).getExpression();

        if (lOperand instanceof JSReferenceExpression) {
          expr = lOperand;
          continue;
        }
      } else if (expr instanceof JSVariable) {
        return expr;
      } else {
        current = expr;
      }

      if (current != null) {
        final PsiElement parent = current.getParent();
        if (!(parent instanceof JSElement)) break;
        if (parent instanceof JSStatement) break;
        expr = (JSElement)parent;
      }
    }

    return null;
  }

  public static int[] buildNameIndexArray(final JSElement _expr, JSNamespace contextNamespace, final JavaScriptIndex index) {
    final TIntArrayList nameComponents = new TIntArrayList();

    JSElement nameComponent = findNameComponent(_expr);
    JSReferenceExpression expr = null;

    if (nameComponent instanceof JSVariable) {
      String varName = ((JSVariable) nameComponent).getName();
      if (varName != null) {
        nameComponents.add(index.getIndexOf( varName) );
      }
    } else if (nameComponent instanceof JSReferenceExpression) {
      expr = (JSReferenceExpression)nameComponent;
    }

    if (expr != null) {
      final JSReferenceExpression expr1 = expr;
      visitReferenceExpressionComponentsInRootFirstOrder(
        expr,
        contextNamespace,
        new ReferenceExpressionProcessor() {
          public void processNamespace(JSNamespace ns) {
            nameComponents.add( ns.getNameId() );
          }

          public void processExpression(JSReferenceExpression expr) {
            nameComponents.add( index.getIndexOf(expr.getReferencedName()) );
          }

          public void processUnresolvedThis() {
            nameComponents.add( index.getIndexOf("") );
          }

          public boolean isTopLevel(final JSReferenceExpression expression) {
            return expr1 == expression;
          }
        }
      );
    }

    return nameComponents.toNativeArray();
  }

  interface ReferenceExpressionProcessor {
    void processNamespace(JSNamespace ns);
    void processExpression(JSReferenceExpression expr);
    void processUnresolvedThis();
    boolean isTopLevel(final JSReferenceExpression expression);
  }

  private static void visitNamespaceComponentsInRootFirstOrder(JSNamespace namespace, ReferenceExpressionProcessor processor) {
    final JSNamespace parentNs = namespace.getParent();
    if (parentNs != null) visitNamespaceComponentsInRootFirstOrder(parentNs, processor);
    processor.processNamespace(namespace);
  }

  private static void visitReferenceExpressionComponentsInRootFirstOrder(JSReferenceExpression expr, final JSNamespace contextNamespace, ReferenceExpressionProcessor processor) {
    final JSExpression qualifier = expr.getQualifier();

    if (qualifier instanceof JSReferenceExpression) {
      visitReferenceExpressionComponentsInRootFirstOrder((JSReferenceExpression)qualifier, contextNamespace, processor);
    }

    if (qualifier instanceof JSThisExpression) {
      if (contextNamespace != null) {
        visitNamespaceComponentsInRootFirstOrder(contextNamespace, processor);
      } else {
        processor.processUnresolvedThis();
      }
    }

    final String refName = expr.getReferencedName();

    if (refName != null &&
        ( !refName.equals(PROTOTYPE_FIELD_NAME) ||
          processor.isTopLevel(expr)
        )
      ) {
      processor.processExpression(expr);
    }
  }

  private static class JSSymbolVisitor extends JSElementVisitor implements ReferenceExpressionProcessor {
    private final JavaScriptSymbolProcessor mySymbolVisitor;
    private JSNamespace myThisNamespace;
    private JSNamespace myNamespace;
    private final JSNamespace myFileNamespace;
    private boolean myInsideWithStatement;
    private JSFunction myFunction;
    private JavaScriptIndex myIndex;
    private JSTypeEvaluateManager myTypeEvaluateManager;

    private JSNamespace currentNamespace;
    private JSElement topExpression;

    public JSSymbolVisitor(JSNamespace namespace, final JavaScriptSymbolProcessor symbolVisitor, Project project) {
      mySymbolVisitor = symbolVisitor;
      myThisNamespace = myFileNamespace = myNamespace = namespace;
      myIndex = JavaScriptIndex.getInstance(project);
      myTypeEvaluateManager = JSTypeEvaluateManager.getInstance(project);
    }

    public void processNamespace(JSNamespace ns) {
      if (ns.getNameId() == -1) currentNamespace = myFileNamespace;
      else currentNamespace = currentNamespace.getChildNamespace( ns.getNameId() );
    }

    public void processExpression(JSReferenceExpression expr) {
      if (expr != topExpression) {
        final int referencedNamedId = myIndex.getIndexOf(expr.getReferencedName());
        currentNamespace = ((currentNamespace != null)?currentNamespace:myFileNamespace).getChildNamespace(referencedNamedId);
      }
    }

    public void processUnresolvedThis() {
      currentNamespace = myFileNamespace.getChildNamespace( myIndex.getIndexOf("") );
    }

    public boolean isTopLevel(final JSReferenceExpression expression) {
      return expression == topExpression;
    }

    private JSNamespace findNamespace(JSElement _expr, JSNamespace contextNamespace) {
      JSElement nameComponent = findNameComponent(_expr);
      JSReferenceExpression expr = null;

      if (nameComponent instanceof JSVariable) {
        return myFileNamespace;
      }

      if (nameComponent instanceof JSReferenceExpression) {
        expr = (JSReferenceExpression)nameComponent;
      }

      if(expr != null) {
        currentNamespace = null;
        topExpression = _expr;
        visitReferenceExpressionComponentsInRootFirstOrder(expr, contextNamespace, this);
        topExpression = null;
        if (currentNamespace != null) return currentNamespace;
      }

      return myFileNamespace;
    }

    public void visitJSFunctionDeclaration(final JSFunction node) {
      final String name = node.getName();

      if (name != null) {
        int nameId = myIndex.getIndexOf(name);
        if (node.getParent() instanceof PsiFile) { // global function declaration
          mySymbolVisitor.processFunction(myNamespace, nameId, node);
        }
        processFunctionBody(myNamespace.getChildNamespace(nameId), node);
      }
    }

    public void visitJSVarStatement(final JSVarStatement node) {
      node.acceptChildren(this);
    }

    public void visitJSVariable(final JSVariable node) {
      final int nameId = myIndex.getIndexOf(node.getName());
      if (myFunction == null) {
        mySymbolVisitor.processVariable(myNamespace, nameId, node);
      }
      
      final JSExpression initializer = node.getInitializer();
      if (initializer != null) {
        visitWithNamespace(myNamespace.getChildNamespace(nameId), initializer, false);
      }
    }

    private void processReferenceExpression(JSReferenceExpression element, JSExpression rOperand) {
      final PsiElement parent = element.getParent();
      if (!(parent instanceof JSNamedElement)) return; // some wrong tree
      JSNamespace namespace = findNamespace(element, myThisNamespace);

      if (namespace.getParent() == null && myInsideWithStatement) {
        namespace = namespace.getChildNamespace( myIndex.getIndexOf( "" ));
      }

      final String name = element.getReferencedName();
      final int nameId = myIndex.getIndexOf(name);

      try {
        if (element.getQualifier() == null && myFunction != null) {
          final JSElement jsElement = JSResolveUtil.treeWalkUp(
            new ResolveProcessor(name),
            element,
            element.getParent(),
            element
          );

          if (jsElement != null) return;
        }

        mySymbolVisitor.processDefinition(
          namespace, nameId, (JSNamedElement)parent
        );
      }
      finally {
        if (rOperand != null) {
          visitWithNamespace(getNestedNsWithName(name, namespace), rOperand, true);
        }
      }
    }

    public void visitJSWithStatement(final JSWithStatement node) {
      boolean oldInsideWith = myInsideWithStatement;
      try {
        myInsideWithStatement = true;
        super.visitJSWithStatement(node);
      } finally {
        myInsideWithStatement = oldInsideWith;
      }
    }

    public void visitJSDefinitionExpression(final JSDefinitionExpression node) {}

    public void visitJSBinaryExpression(final JSBinaryExpression node) {}

    public void visitXmlDocument(XmlDocument element) {
      element.acceptChildren(this);
    }

    public void visitXmlTag(XmlTag element) {
      String name = element.getAttributeValue("name");
      if (name != null) {
        JSNamespace ns = myNamespace;
        if (ns == myFileNamespace) ns = myFileNamespace.getChildNamespace(myIndex.getIndexOf("document"));
        int nameId = myIndex.getIndexOf(name);
        mySymbolVisitor.processTag(ns, nameId, element, "name");
        visitWithNamespace(ns.getChildNamespace(nameId), element, true);
      } else {
        name = element.getAttributeValue("id");
        if (name != null) {
          int nameId = myIndex.getIndexOf(name);
          mySymbolVisitor.processTag(myNamespace, nameId, element, "id");
        }

        //name = element.getAttributeValue("class");
        //if (name != null) {
        //  int nameId = myIndex.getIndexOf(name);
        //  mySymbolVisitor.processTag(myNamespace, nameId, element, "class");
        //}

        element.acceptChildren(this);
      }
    }

    public void visitJSElement(JSElement element) {
      element.acceptChildren(this);
    }

    public void visitJSObjectLiteralExpression(final JSObjectLiteralExpression node) {
      JSNamespace namespace = myNamespace;

      if (namespace.getParent() == null) {
        // Find some ns that is used for extending
        JSNamespace candidateNs = null;

        final PsiElement parent = node.getParent();
        if (parent instanceof JSArgumentList) {
          for(JSExpression expr:((JSArgumentList)parent).getArguments()) {
            if (expr instanceof JSReferenceExpression) {
              candidateNs = findNsForExpr(expr);
              break;
            }
          }
        }

        if(candidateNs == null) candidateNs = namespace.getChildNamespace( myIndex.getIndexOf( "" ) );
        namespace = candidateNs;
      }

      visitWithNamespace(namespace, node, true);
    }

    private JSNamespace findNsForExpr(final JSExpression expr) {
      JSNamespace candidateNs = findNamespace(expr, null);

      if (candidateNs != null) {
        String name = null;
        if (expr instanceof JSReferenceExpression)
          name = ((JSReferenceExpression)expr).getReferencedName();

        if (name != null) candidateNs = getNestedNsWithName(name, candidateNs);
      }
      return candidateNs;
    }

    private JSNamespace getNestedNsWithName(final String name, JSNamespace candidateNs) {
      if (!PROTOTYPE_FIELD_NAME.equals(name)) {
        candidateNs = candidateNs.getChildNamespace( myIndex.getIndexOf(name) );
      }
      return candidateNs;
    }

    private void visitWithNamespace(final JSNamespace namespace, final PsiElement node, boolean fromChildren) {
      final JSNamespace previousNamespace = myNamespace;
      try {
        myNamespace = namespace;
        if (fromChildren) node.acceptChildren(this);
        else node.accept(this);
      } finally {
        myNamespace = previousNamespace;
      }
    }

    public void visitJSProperty(final JSProperty node) {
      final JSExpression value = node.getValue();

      String name = node.getName();
      final int nameId = myIndex.getIndexOf(name);

      if (value instanceof JSFunction) {
        final JSFunction function = (JSFunction)value;
        mySymbolVisitor.processFunction(myNamespace, nameId, function);
        final JSNamespace childNs = nameId != -1 ? myNamespace.getChildNamespace(nameId) : myNamespace;
        processFunctionBody(childNs,function);
      } else if (value != null) {
        mySymbolVisitor.processProperty( myNamespace, nameId, node );
      }
    }

    public void visitJSCallExpression(final JSCallExpression node) {
      final JSExpression methodExpression = node.getMethodExpression();

      if (methodExpression instanceof JSReferenceExpression &&
          !(node instanceof JSNewExpression)
        ) {
        final JSReferenceExpression referenceExpression = (JSReferenceExpression)methodExpression;
        final JSExpression qualifier = referenceExpression.getQualifier();

        if ("call".equals(referenceExpression.getReferencedName()) &&
            qualifier != null &&
            myFunction != null
           ) {
          final JSExpression[] jsExpressions = node.getArgumentList().getArguments();

          if (jsExpressions.length == 1) {
            for(JSExpression expr: jsExpressions) {
              if (expr instanceof JSThisExpression) {
                final JSNamespace namespace = findNsForExpr(qualifier);
                //System.out.println(
                //  myThisNamespace.getQualifiedName(myIndex) + "," + myFunction.getName() + "," + qualifier.getText() + "," +
                //                   namespace.getQualifiedName(myIndex)
                //);
                myTypeEvaluateManager.setBaseType(myThisNamespace,
                  myFunction.getName(), namespace,
                  qualifier.getText()
                );
                break;
              }
            }
          }
        } else if (qualifier == null && myFunction == null) {
          final JSExpression[] jsExpressions = node.getArgumentList().getArguments();
          if (jsExpressions.length == 2 &&
              jsExpressions[0] instanceof JSReferenceExpression &&
              jsExpressions[1] instanceof JSReferenceExpression
             ) {
            final JSNamespace namespace = findNsForExpr(jsExpressions[0]);
            final JSNamespace namespace2 = findNsForExpr(jsExpressions[1]);
            //System.out.println(
            //  namespace.getQualifiedName(myIndex) + "," + jsExpressions[0].getText() + "," + jsExpressions[1].getText() + "," +
            //                   namespace2.getQualifiedName(myIndex)
            //);
            myTypeEvaluateManager.setBaseType(namespace,
              jsExpressions[0].getText(), namespace2,
              jsExpressions[1].getText()
            );
          }
        }
      }

      super.visitJSCallExpression(node);
    }

    public void visitJSAssignmentExpression(final JSAssignmentExpression node) {
      JSExpression _lOperand = node.getLOperand();
      if (_lOperand instanceof JSDefinitionExpression) _lOperand = ((JSDefinitionExpression)_lOperand).getExpression();

      if (_lOperand instanceof JSReferenceExpression) {
        final JSReferenceExpression lOperand = (JSReferenceExpression) _lOperand;
        final JSExpression rOperand = node.getROperand();
        final JSExpression lqualifier = lOperand.getQualifier();

        if (rOperand instanceof JSFunction) {
          final JSNamespace namespace = findNamespace(lOperand, myThisNamespace);
          final int nameId = myIndex.getIndexOf( lOperand.getReferencedName() );
          final JSNamespace childNamespace = namespace.getChildNamespace(nameId);

          if (lqualifier instanceof JSReferenceExpression) {
            final JSFunction function = (JSFunction)rOperand;
            mySymbolVisitor.processFunction(namespace, nameId, function);
            processFunctionBody(childNamespace, function);
          } else {
            mySymbolVisitor.processFunction(namespace, nameId, (JSFunction)rOperand);
            processFunctionBody(childNamespace, (JSFunction)rOperand);
          }
        }
        else if (rOperand instanceof JSObjectLiteralExpression) {
          JSObjectLiteralExpression literalExpr = (JSObjectLiteralExpression) rOperand;

          if (PROTOTYPE_FIELD_NAME.equals(lOperand.getReferencedName()) &&
              lqualifier instanceof JSReferenceExpression) {
            final JSNamespace namespace = findNamespace(lOperand, null);

            for(JSProperty prop: literalExpr.getProperties()) {
              final JSExpression expression = prop.getValue();
              final int nameId = myIndex.getIndexOf(prop.getName());

              if (expression instanceof JSFunction) {
                mySymbolVisitor.processFunction(namespace, nameId, (JSFunction) expression);
                processFunctionBody(namespace.getChildNamespace(nameId), (JSFunction) expression);
              } else if (expression != null) {
                mySymbolVisitor.processProperty( namespace, nameId, prop );
              }
            }
          } else {
            processReferenceExpression(lOperand, rOperand);
          }
        } else if (rOperand instanceof JSCallExpression) {
          if (PROTOTYPE_FIELD_NAME.equals(lOperand.getReferencedName()) &&
              lqualifier instanceof JSReferenceExpression) {

            JSExpression methodExpression = null;
            if (rOperand instanceof JSNewExpression) {
              methodExpression = ((JSNewExpression)rOperand).getMethodExpression();
            } else {
              for(JSExpression expr:((JSCallExpression)rOperand).getArgumentList().getArguments()) {
                if (expr instanceof JSNewExpression) {
                  methodExpression = ((JSNewExpression)expr).getMethodExpression();
                  break;
                }
              }
            }

            if (methodExpression instanceof JSReferenceExpression) {
              final JSNamespace subTypeNS = findNamespace(lOperand, myThisNamespace);
              final String superType = methodExpression.getText();
              JSNamespace superNs = findNamespace(methodExpression,null);
              superNs = superNs.getChildNamespace( myIndex.getIndexOf(((JSReferenceExpression)methodExpression).getReferencedName()) );

              myTypeEvaluateManager.setBaseType(
                subTypeNS,
                lqualifier.getText(),
                superNs,
                superType
              );
            }
          }
          processReferenceExpression(lOperand, rOperand);
        }
        else if (!(rOperand instanceof JSLiteralExpression) || !"null".equals(rOperand.getText())) {
          processReferenceExpression(lOperand, rOperand);
        }
      } else {
        int a = 1;
      }
    }

    public void visitJSFunctionExpression(final JSFunctionExpression node) {
      processFunctionBody(myNamespace,node.getFunction());
    }

    private void processFunctionBody(final JSNamespace namespace, final JSFunction node) {
      ProgressManager.getInstance().checkCanceled();
      final JSNamespace previousNamespace = myNamespace;
      final JSFunction previousFunction = myFunction;
      final JSNamespace previousThisNamespace = myThisNamespace;

      myThisNamespace = namespace;

      if (node instanceof JSFunctionExpression) {
        final PsiElement parentElement = node.getParent();
        if (parentElement instanceof JSAssignmentExpression) {
          final JSExpression expression = ((JSDefinitionExpression)((JSAssignmentExpression)parentElement).getLOperand()).getExpression();

          if (expression instanceof JSReferenceExpression) {
            final JSExpression qualifier = ((JSReferenceExpression)expression).getQualifier();

            if (qualifier instanceof JSReferenceExpression) {
              final String referencedName = ((JSReferenceExpression)qualifier).getReferencedName();

              if (PROTOTYPE_FIELD_NAME.equals(referencedName)) {
                myThisNamespace = myThisNamespace.getParent();
              }
            }
            if (qualifier instanceof JSThisExpression) {
              myThisNamespace = myThisNamespace.getParent();
            }
          }
        } else if (parentElement instanceof JSProperty ||
                   parentElement instanceof JSReferenceExpression
                  ) {
          myThisNamespace = myThisNamespace.getParent();
        }
      }

      myNamespace = namespace;
      myFunction = node;
      try {
        for (JSSourceElement srcElement: node.getBody()) {
          srcElement.acceptChildren(this);
        }
      } finally {
        myNamespace = previousNamespace;
        myFunction = previousFunction;
        myThisNamespace = previousThisNamespace;
      }
    }
  }
}
