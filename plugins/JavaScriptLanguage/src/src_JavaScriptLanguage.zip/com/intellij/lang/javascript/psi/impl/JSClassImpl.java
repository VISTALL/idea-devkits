/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi.impl;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.lang.javascript.index.JSNamedElementProxy;
import com.intellij.lang.javascript.index.JSNamespace;
import com.intellij.lang.javascript.index.JSTypeEvaluateManager;
import com.intellij.lang.javascript.index.JavaScriptIndex;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.ResolveProcessor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.pom.Navigatable;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiSubstitutor;
import com.intellij.psi.ResolveResult;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.util.Icons;
import com.intellij.util.IncorrectOperationException;
import gnu.trove.THashSet;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @by Maxim.Mossienko
 */
public class JSClassImpl extends JSClassBase {
  public JSClassImpl(final ASTNode node) {
    super(node);
  }

  public int getTextOffset() {
    ASTNode node = findNameIdentifier();
    return node == null ? super.getTextOffset():node.getStartOffset();
  }

  public JSAttributeList getAttributeList() {
    final ASTNode node = getNode().findChildByType(JSElementTypes.ATTRIBUTE_LIST);
    return node != null ? (JSAttributeList)node.getPsi(): null;
  }

  public String getName() {
    final ASTNode node = findNameIdentifier();
    if (node != null) {
      return ((JSReferenceExpression)node.getPsi()).getReferencedName();
    }
    return null;
  }

  public PsiElement setName(@NonNls @NotNull String newName) throws IncorrectOperationException {
    final String oldName = getName();
    final JSFunction constructor = findFunctionByName(oldName);

    getNode().replaceChild(findNameIdentifier(), JSChangeUtil.createExpressionFromText(getProject(), newName));

    if (constructor != null) {
      constructor.setName(newName);
    }
    updateFileName(newName, oldName);

    return this;
  }

  @Nullable
  public ASTNode findNameIdentifier() {
    return getNode().findChildByType(JSElementTypes.REFERENCE_EXPRESSION);
  }

  public JSReferenceList getExtendsList() {
    final ASTNode refListNode = getNode().findChildByType(JSElementTypes.REFERENCE_LIST);
    if (refListNode != null) {
      final ASTNode node = refListNode.getTreePrev().getTreePrev();
      if (node.getElementType() == JSTokenTypes.EXTENDS_KEYWORD) return (JSReferenceList)refListNode.getPsi();
    }
    return null;
  }

  @Nullable
  public JSReferenceList getImplementsList() {
    final ASTNode implementsKeyword = getNode().findChildByType(JSTokenTypes.IMPLEMENTS_KEYWORD);

    if (implementsKeyword != null) {
      ASTNode nextNode = implementsKeyword.getTreeNext();
      if (nextNode != null && nextNode.getElementType() == JSTokenTypes.WHITE_SPACE) {
        nextNode = nextNode.getTreeNext();
      } else {
        nextNode = null;
      }

      if (nextNode != null && nextNode.getElementType() == JSElementTypes.REFERENCE_LIST) {
        return (JSReferenceList)nextNode.getPsi();
      }
    }
    return null;
  }

  public String getQualifiedName() {
    return getQName(this);
  }

  public boolean isInterface() {
    return getNode().findChildByType(JSTokenTypes.INTERFACE_KEYWORD) != null;
  }

  static String getQName(final JSNamedElement jsClass) {
    final ASTNode node = jsClass.findNameIdentifier();
    final String className = node != null ? node.getText():null;
    final PsiElement element = jsClass.getParent();

    if (element instanceof JSPackageStatement && className != null) {
      final String packageName = ((JSPackageStatement)element).getQualifiedName();
      if (!StringUtil.isEmpty(packageName)) return packageName.concat(".").concat(className);
    }
    return className;
  }

  protected Icon getBaseIcon() {
    return Icons.CLASS_ICON;
  }

  public void delete() throws IncorrectOperationException {
    getNode().getTreeParent().removeChild(getNode());
  }

  protected boolean processMembers(final PsiScopeProcessor processor, final PsiSubstitutor substitutor, final PsiElement lastParent,
                                 final PsiElement place) {
    return JSResolveUtil.processDeclarationsInScope(this, processor, substitutor, lastParent, place);
  }
}
