/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.validation;

import com.intellij.codeInsight.daemon.EmptyResolveMessageProvider;
import com.intellij.codeInsight.daemon.impl.quickfix.RenameFileFix;
import com.intellij.codeInsight.daemon.impl.quickfix.RenamePublicClassFix;
import com.intellij.codeInsight.intention.IntentionAction;
import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.codeInspection.LocalQuickFixProvider;
import com.intellij.lang.ASTNode;
import com.intellij.lang.annotation.Annotation;
import com.intellij.lang.annotation.AnnotationHolder;
import com.intellij.lang.annotation.Annotator;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JSLanguageDialect;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.impl.JSChangeUtil;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.ResolveProcessor;
import com.intellij.lang.javascript.psi.util.JSUtils;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.TextRange;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.*;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.psi.xml.XmlTagChild;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.PropertyKey;

import java.text.MessageFormat;

/**
 * @by max, maxim.mossienko
 */
public class JSAnnotatingVisitor extends JSElementVisitor implements Annotator {
  private AnnotationHolder myHolder;

  public synchronized void annotate(PsiElement psiElement, AnnotationHolder holder) {
    myHolder = holder;
    psiElement.accept(this);
    myHolder = null;
  }

  public void visitJSAttributeNameValuePair(final JSAttributeNameValuePair attributeNameValuePair) {
    checkReferences(attributeNameValuePair);
  }

  public void visitJSIncludeDirective(final JSIncludeDirective includeDirective) {
    checkReferences(includeDirective);
  }

  private void checkReferences(final PsiElement includeDirective) {
    for(PsiReference ref:includeDirective.getReferences()) {
      if (hasBadResolve(ref)) {
        final TextRange elementRange = ref.getElement().getTextRange();
        final TextRange textRange = ref.getRangeInElement();

        final TextRange range = new TextRange(elementRange.getStartOffset() + textRange.getStartOffset(),
                                              elementRange.getStartOffset() + textRange.getEndOffset());
        Annotation annotation = myHolder.createErrorAnnotation(range,
          MessageFormat.format(((EmptyResolveMessageProvider)ref).getUnresolvedMessagePattern(), ref.getCanonicalText())
        );

        if (ref instanceof LocalQuickFixProvider) {
          for(LocalQuickFix fix:((LocalQuickFixProvider)ref).getQuickFixes()) {
            if (fix instanceof IntentionAction) {
              annotation.registerFix((IntentionAction)fix, range);
            }
          }
        }
      }
    }
  }

  private boolean hasBadResolve(final PsiReference ref) {
    if (ref instanceof PsiPolyVariantReference) {
      return ((PsiPolyVariantReference)ref).multiResolve(false).length == 0;
    }
    return ref.resolve() == null;
  }

  public void visitJSCallExpression(final JSCallExpression node) {
    final JSExpression methodExpression = node.getMethodExpression();
    
    if (methodExpression instanceof JSLiteralExpression) {
      myHolder.createErrorAnnotation(methodExpression, JSBundle.message("javascript.parser.message.expected.function.name"));
    }
  }

  public void visitJSReferenceExpression(final JSReferenceExpression node) {
    final PsiElement parent = node.getParent();

    if (parent instanceof JSNamedElement) {
      final ASTNode nameIdentifier = ((JSNamedElement)parent).findNameIdentifier();

      if (nameIdentifier != null && nameIdentifier.getPsi() == node) {
        if (parent instanceof JSPackageStatement) {
          checkPackageStatement((JSPackageStatement)parent);
        } else if (!(parent instanceof JSImportStatement) && !(parent instanceof JSNamespaceDeclaration) && parent.getParent() instanceof JSPackageStatement) {
          checkNamedObjectIsInCorrespondingFile((JSNamedElement)parent);
        }
      }
    }

    if (!(parent instanceof JSCallExpression) && node.getQualifier() == null) {
      if ("arguments".equals(node.getText())) {
        if (PsiTreeUtil.getParentOfType(node,JSFunction.class) == null) {
          myHolder.createErrorAnnotation(node, JSBundle.message("javascript.validation.message.arguments.out.of.function"));
        }
      }
    }
  }

  public void visitJSPackageStatement(final JSPackageStatement packageStatement) {
    final ASTNode node = packageStatement.findNameIdentifier();
    if (node == null) checkPackageStatement(packageStatement);
  }

  public void visitJSAssignmentExpression(final JSAssignmentExpression expression) {
    JSExpression lExpr = expression.getLOperand();
    if (lExpr == null) return;
    if (lExpr instanceof JSDefinitionExpression) lExpr = ((JSDefinitionExpression)lExpr).getExpression();

    if (lExpr instanceof JSReferenceExpression && ((JSReferenceExpression)lExpr).getQualifier() == null) {
      PsiElement resolved = ((JSReferenceExpression)lExpr).resolve();
      if (resolved instanceof JSVariable && ((JSVariable)resolved).isConst()) {
        myHolder.createErrorAnnotation(lExpr, JSBundle.message("javascript.validation.message.assignment.to.const"));
      }
    }

    if (!JSUtils.isLHSExpression(lExpr)) {
      myHolder.createErrorAnnotation(lExpr, JSBundle.message("javascript.validation.message.must.be.lvalue"));
    }
  }

  public void visitJSVariable(final JSVariable var) {
    if (var.isConst() && var.getInitializer() == null) {
      myHolder.createWarningAnnotation(var, JSBundle.message("javascript.validation.message.const.variable.without.initializer."));
    }
  }

  public void visitJSContinueStatement(final JSContinueStatement node) {
    if (node.getStatementToContinue() == null) {
      myHolder.createErrorAnnotation(node, JSBundle.message("javascript.validation.message.continue.without.target"));
    }
  }

  public void visitJSBreakStatement(final JSBreakStatement node) {
    if (node.getStatementToBreak() == null) {
      myHolder.createErrorAnnotation(node, JSBundle.message("javascript.validation.message.break.without.target"));
    }
  }

  public void visitJSThisExpression(final JSThisExpression node) {
    checkClassReferenceInStaticContext(node, "javascript.validation.message.this.referenced.from.static.context");
  }

  private void checkClassReferenceInStaticContext(final JSExpression node, @PropertyKey(resourceBundle = JSBundle.BUNDLE) String key) {
    PsiElement element =
      PsiTreeUtil.getParentOfType(node, JSFunction.class, JSFile.class, JSClass.class, JSObjectLiteralExpression.class, XmlTagChild.class);

    if (element instanceof JSFunction) {
      final JSFunction function = (JSFunction)element;

      final JSAttributeList attributeList = function.getAttributeList();
      if (attributeList != null && attributeList.hasModifier(JSAttributeList.ModifierType.STATIC)) {
        myHolder.createErrorAnnotation(node, JSBundle.message(key));
        return;
      }
    }

    PsiElement elementParent;
    if (node instanceof JSSuperExpression &&
        ( element == null ||
          ( !((elementParent = element.getParent()) instanceof JSClass) &&
            ( !(elementParent instanceof JSFile) ||
              elementParent.getContext() == null
            )
          )
         )
       ) {
      myHolder.createErrorAnnotation(node, JSBundle.message("javascript.validation.message.super.referenced.without.class.instance.context"));
    }
  }

  public void visitJSSuperExpression(final JSSuperExpression node) {
    checkClassReferenceInStaticContext(node, "javascript.validation.message.super.referenced.from.static.context");
  }

  @Override
  public void visitJSFunctionDeclaration(final JSFunction node) {
    final ASTNode nameIdentifier = node.findNameIdentifier();
    if (nameIdentifier == null) return;
    PsiElement parent = node.getParent();

    if (parent instanceof JSFile) {
      parent = JSResolveUtil.getClassReferenceForXmlFromContext(parent);
    }

    if (parent instanceof JSPackageStatement) {
      checkNamedObjectIsInCorrespondingFile(node);
    }

    if (parent instanceof JSClass && !node.isConstructor()) {
      final JSAttributeList attributeList = node.getAttributeList();
      final JSClass clazz = (JSClass)parent;

      if (clazz.isInterface()) {
        if (attributeList != null &&
            ( attributeList.getAccessType() != JSAttributeList.AccessType.PACKAGE_LOCAL ||
              attributeList.getNode().findChildByType(JSTokenTypes.INTERNAL_KEYWORD) != null
            )
           ) {
          final ASTNode astNode = attributeList.getNode().findChildByType(JSTokenTypes.ACCESS_MODIFIERS);
          final Annotation annotation = myHolder.createErrorAnnotation(astNode,
              JSBundle.message("javascript.validation.message.interface.members.cannot.have.access.modifiers"));

          annotation.registerFix(new RemoveASTNodeFix(astNode, "javascript.fix.remove.access.modifier.modifier"));
        }
      }

      if (attributeList == null ||
          (!attributeList.hasModifier(JSAttributeList.ModifierType.STATIC) &&
           attributeList.getAccessType() != JSAttributeList.AccessType.PRIVATE)) {
        final String qName = clazz.getQualifiedName();
        final boolean hasOverride = attributeList != null ? attributeList.hasModifier(JSAttributeList.ModifierType.OVERRIDE):false;
        
        boolean b = JSResolveUtil.iterateType(
          node,
          parent, qName, new JSResolveUtil.OverrideHandler() {
          public void process(final ResolveProcessor processor, final PsiElement scope, final String className, final String overrideKey) {
            if (qName.equals(className)) return;
            if ("Object".equals(className)) {
              if (hasOverride) {
                final ASTNode astNode = attributeList.getNode().findChildByType(JSTokenTypes.OVERRIDE_KEYWORD);
                final Annotation annotation = myHolder.createErrorAnnotation(astNode, JSBundle.message(
                "javascript.validation.message.function.override.for.object.method"));

                annotation.registerFix(
                    new RemoveASTNodeFix(astNode,"javascript.fix.remove.override.modifier")
                );
              }
              return;
            }

            if (!hasOverride) {
              final Annotation annotation = myHolder.createErrorAnnotation(nameIdentifier, JSBundle.message(
                "javascript.validation.message.function.override.without.override.modifier", className));

              annotation.registerFix(new IntentionAction() {
                @NotNull
                public String getText() {
                  return JSBundle.message("javascript.fix.add.override.modifier");
                }

                @NotNull
                public String getFamilyName() {
                  return getText();
                }

                public boolean isAvailable(@NotNull final Project project, final Editor editor, final PsiFile file) {
                  return node.isValid();
                }

                public void invoke(@NotNull final Project project, final Editor editor, final PsiFile file) throws IncorrectOperationException {
                  final ASTNode fromText = JSChangeUtil.createJSTreeFromText(project, "override class A {}", (JSLanguageDialect)node.getContainingFile().getLanguageDialect());
                  final JSAttributeList jsAttributeList = node.getAttributeList();
                  final JSAttributeList createdAttrList = ((JSClass)fromText.getPsi()).getAttributeList();

                  if (jsAttributeList != null) {
                    jsAttributeList.add(createdAttrList.getFirstChild());
                  }
                  else node.addBefore(createdAttrList, node.getFirstChild());
                }

                public boolean startInWriteAction() {
                  return true;
                }
              });
            }

          }
        }
        );


        if (b && hasOverride) {
          final ASTNode astNode = attributeList.getNode().findChildByType(JSTokenTypes.OVERRIDE_KEYWORD);
          final Annotation annotation = myHolder.createErrorAnnotation(astNode, JSBundle.message(
              "javascript.validation.message.function.override.without.parent.method"));

          annotation.registerFix(
              new RemoveASTNodeFix(astNode,"javascript.fix.remove.override.modifier")
          );
        }
      }
    }
  }

  public void visitJSReturnStatement(final JSReturnStatement node) {
    final PsiElement element = PsiTreeUtil.getParentOfType(node, JSFunction.class, XmlTagChild.class, XmlAttributeValue.class, JSFile.class);
    if ( ( element instanceof JSFile &&
          !(element.getContext() instanceof PsiLanguageInjectionHost)
         ) ||
         (element instanceof XmlTagChild && !(element .getParent() instanceof XmlAttributeValue))
       ) {
      myHolder.createErrorAnnotation(node, JSBundle.message("javascript.validation.message.return.outside.function.definition"));
    }
  }

  public void visitJSLabeledStatement(final JSLabeledStatement node) {
    final String label = node.getLabel();
    if (label != null) {
      PsiElement run = node.getParent();
      while(run != null) {
        if (run instanceof JSLabeledStatement) {
          if (label.equals(((JSLabeledStatement)run).getLabel())) {
            myHolder.createErrorAnnotation(node.getLabelIdentifier(), JSBundle.message("javascript.validation.message.duplicate.label"));
            break;
          }
        }

        if (run instanceof JSFunction) break;
        run = run.getParent();
      }
    }
  }

  private void checkNamedObjectIsInCorrespondingFile(final JSNamedElement aClass) {
    final PsiFile containingFile = aClass.getContainingFile();
    final PsiElement fileContext = containingFile.getContext();

    if (aClass instanceof JSAttributeListOwner) {
      final JSAttributeListOwner attributeListOwner = (JSAttributeListOwner)aClass;
      final JSAttributeList attributeList = attributeListOwner.getAttributeList();

      if (attributeList != null && !(aClass.getParent() instanceof JSClass) && fileContext == null) {
        final JSAttributeList.AccessType type = attributeList.getAccessType();
        
        if (type != JSAttributeList.AccessType.PACKAGE_LOCAL &&
            type != JSAttributeList.AccessType.PUBLIC
           ) {
          final ASTNode astNode = attributeList.getNode().findChildByType(JSTokenTypes.ACCESS_MODIFIERS);
            final Annotation annotation = myHolder.createErrorAnnotation(astNode,
                JSBundle.message("javascript.validation.message.only.class.members.can.have.access.modifiers"));

          annotation.registerFix(new RemoveASTNodeFix(astNode, "javascript.fix.remove.access.modifier.modifier"));
        }
      }
    }

    if (fileContext != null) return;
    final VirtualFile file = containingFile.getVirtualFile();

    if (file != null && !file.getNameWithoutExtension().equals(aClass.getName())) {
      final ASTNode node = aClass.findNameIdentifier();

      if (node != null) {
        final String name = aClass.getName();

        final Annotation annotation = myHolder.createErrorAnnotation(
            node,
            JSBundle.message(
            aClass instanceof JSClass ?
              "javascript.validation.message.class.should.be.in.file":
              "javascript.validation.message.function.should.be.in.file",
            name, name + "." + file.getExtension()
          )
        );

        annotation.registerFix(new RenameFileFix(name));
        annotation.registerFix(new RenamePublicClassFix(aClass));
      }
    }
  }

  private void checkPackageStatement(final JSPackageStatement packageStatement) {
    final String s = packageStatement.getQualifiedName();

    final PsiFile containingFile = packageStatement.getContainingFile();
    final String expected = JSResolveUtil.getExpectedPackageNameFromFile(containingFile.getVirtualFile(), containingFile.getProject(), false);

    if (expected!= null && ((s == null && expected.length() != 0) || (s != null && !expected.equals(s)))) {
      final ASTNode nameIdentifier = packageStatement.findNameIdentifier();
      final Annotation annotation = myHolder.createErrorAnnotation(
          nameIdentifier != null ? nameIdentifier:packageStatement.getFirstChild().getNode(),
          JSBundle.message(
            "javascript.validation.message.incorrect.package.name", s, expected
          )
      );
      annotation.registerFix(new IntentionAction() {
        @NotNull
        public String getText() {
          return JSBundle.message("javascript.fix.package.name", expected);
        }

        @NotNull
        public String getFamilyName() {
          return getText();
        }

        public boolean isAvailable(@NotNull final Project project, final Editor editor, final PsiFile file) {
          return packageStatement.isValid();
        }

        public void invoke(@NotNull final Project project, final Editor editor, final PsiFile file) throws IncorrectOperationException {
          final ASTNode node = packageStatement.findNameIdentifier();
          final ASTNode parent = packageStatement.getNode();

          if (expected.length() == 0) {
            if (node != null) {
              final ASTNode treeNext = node.getTreeNext();
              parent.removeChild(node);
              if (treeNext.getPsi() instanceof PsiWhiteSpace) parent.removeChild(treeNext);
            }
          } else {
            final ASTNode child = JSChangeUtil.createExpressionFromText(project, expected);
            if (node != null) parent.replaceChild(node, child);
            else parent.addChild(child, parent.findChildByType(JSTokenTypes.LBRACE));
          }
        }

        public boolean startInWriteAction() {
          return true;
        }
      });
    }
  }

  private static class RemoveASTNodeFix implements IntentionAction {
    private final ASTNode myAstNode;
    private final String myPropKey;

    public RemoveASTNodeFix(final ASTNode astNode, @PropertyKey(resourceBundle = JSBundle.BUNDLE) String propKey) {
      myAstNode = astNode;
      myPropKey = propKey;
    }

    @NotNull
    public String getText() {
      return JSBundle.message(myPropKey);
    }

    @NotNull
    public String getFamilyName() {
      return getText();
    }

    public boolean isAvailable(@NotNull final Project project, final Editor editor, final PsiFile file) {
      return myAstNode.getPsi().isValid();
    }

    public void invoke(@NotNull final Project project, final Editor editor, final PsiFile file) throws IncorrectOperationException {
      myAstNode.getPsi().delete();
    }

    public boolean startInWriteAction() {
      return true;
    }
  }
}
