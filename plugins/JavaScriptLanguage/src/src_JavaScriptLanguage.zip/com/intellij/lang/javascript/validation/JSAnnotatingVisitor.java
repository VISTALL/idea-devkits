/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.validation;

import com.intellij.lang.ASTNode;
import com.intellij.lang.annotation.AnnotationHolder;
import com.intellij.lang.annotation.Annotator;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JSElementType;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.impl.JSEmbeddedContentImpl;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.ResolveProcessor;
import com.intellij.lang.javascript.psi.util.JSUtils;
import com.intellij.psi.*;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.psi.xml.XmlTagChild;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Feb 3, 2005
 * Time: 3:11:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSAnnotatingVisitor extends JSElementVisitor implements Annotator {
  private AnnotationHolder myHolder;

  public void annotate(PsiElement psiElement, AnnotationHolder holder) {
    myHolder = holder;
    psiElement.accept(this);
  }

  @Override public void visitJSFunctionDeclaration(final JSFunction node) {
    final String name = node.getName();
    if (name == null) return;
    final ASTNode nameIdentifier = node.findNameIdentifier();

    checkForDuplicateDeclaration(name, node, nameIdentifier);
  }

  private void checkForDuplicateDeclaration(final String name, final PsiElement decl, final ASTNode nameIdentifier) {
    final ResolveProcessor processor = new ResolveProcessor(name) {
      public boolean execute(PsiElement element, PsiSubstitutor substitutor) {
        if (element == decl) return true;
        if (!decl.getClass().isInstance(element)) return true;
        if (decl instanceof JSParameter && decl.getParent() != element.getParent()) return false;
        return super.execute(element, substitutor);
      }

      public <T> T getHint(Class<T> hintClass) {
        return null;
      }

      public void handleEvent(Event event, Object associated) {
      }
    };

    final PsiElement scope = PsiTreeUtil.getNonStrictParentOfType(decl, JSFunction.class, JSFile.class, JSEmbeddedContentImpl.class);
    JSResolveUtil.treeWalkUp(processor, decl, null, decl, scope);

    if (processor.getResult() != null) {
      myHolder.createWarningAnnotation(nameIdentifier, JSBundle.message("javascript.validation.message.duplicate.declaration"));
    }
  }


  public void visitJSCallExpression(final JSCallExpression node) {
    final JSExpression methodExpression = node.getMethodExpression();
    
    if (methodExpression instanceof JSLiteralExpression) {
      myHolder.createErrorAnnotation(methodExpression, JSBundle.message("javascript.parser.message.expected.function.name"));
    }
  }

  public void visitJSReferenceExpression(final JSReferenceExpression node) {
    if (!(node.getParent() instanceof JSCallExpression) && node.getQualifier() == null) {
      if ("arguments".equals(node.getText())) {
        if (PsiTreeUtil.getParentOfType(node,JSFunction.class) == null) {
          myHolder.createErrorAnnotation(node, JSBundle.message("javascript.validation.message.arguments.out.of.function"));
        }
      }
    }
  }

  public void visitJSAssignmentExpression(final JSAssignmentExpression expression) {
    JSExpression lExpr = expression.getLOperand();
    if (lExpr instanceof JSDefinitionExpression) lExpr = ((JSDefinitionExpression)lExpr).getExpression();

    if (lExpr instanceof JSReferenceExpression && ((JSReferenceExpression)lExpr).getQualifier() == null) {
      PsiElement resolved = ((JSReferenceExpression)lExpr).resolve();
      if (resolved instanceof JSVariable && ((JSVariable)resolved).isConst()) {
        myHolder.createErrorAnnotation(lExpr, JSBundle.message("javascript.validation.message.assignment.to.const"));
      }
    }

    if (!JSUtils.isLHSExpression(lExpr)) {
      myHolder.createErrorAnnotation(lExpr, JSBundle.message("javascript.validation.message.must.be.lvalue"));
    }
  }

  public void visitJSVariable(final JSVariable var) {
    if (var.isConst() && var.getInitializer() == null) {
      myHolder.createWarningAnnotation(var, JSBundle.message("javascript.validation.message.const.variable.without.initializer."));
    }

    final ASTNode nameIdentifier = var.findNameIdentifier();
    final ASTNode next = nameIdentifier != null ? nameIdentifier.getTreeNext():null;
    final String name = nameIdentifier != null ? nameIdentifier.getText():null;

    // Actully skip outer language elements
    if (name != null &&
        ( next == null ||
          next.getElementType() instanceof JSElementType ||
          next.getPsi() instanceof PsiWhiteSpace)
       ) {
      checkForDuplicateDeclaration(name, var, nameIdentifier);
    }
  }

  public void visitJSContinueStatement(final JSContinueStatement node) {
    if (node.getStatementToContinue() == null) {
      myHolder.createErrorAnnotation(node, JSBundle.message("javascript.validation.message.continue.without.target"));
    }
  }

  public void visitJSBreakStatement(final JSBreakStatement node) {
    if (node.getStatementToBreak() == null) {
      myHolder.createErrorAnnotation(node, JSBundle.message("javascript.validation.message.break.without.target"));
    }
  }

  public void visitJSReturnStatement(final JSReturnStatement node) {
    if (PsiTreeUtil.getParentOfType(node, JSFunction.class, XmlTagChild.class) == null) {
      myHolder.createErrorAnnotation(node, JSBundle.message("javascript.validation.message.return.outside.function.definition"));
    }
  }

  public void visitJSLabeledStatement(final JSLabeledStatement node) {
    final String label = node.getLabel();
    if (label != null) {
      PsiElement run = node.getParent();
      while(run != null) {
        if (run instanceof JSLabeledStatement) {
          if (label.equals(((JSLabeledStatement)run).getLabel())) {
            myHolder.createErrorAnnotation(node.getLabelIdentifier(), JSBundle.message("javascript.validation.message.duplicate.label"));
            break;
          }
        }

        if (run instanceof JSFunction) break;
        run = run.getParent();
      }
    }
  }

}
