package com.intellij.lang.javascript.flex.importer;

import java.util.LinkedHashMap;

/**
 * @author Maxim.Mossienko
*         Date: Oct 20, 2008
*         Time: 7:00:50 PM
*/
class MetaData extends LinkedHashMap<String, String> {
  String name;
}
