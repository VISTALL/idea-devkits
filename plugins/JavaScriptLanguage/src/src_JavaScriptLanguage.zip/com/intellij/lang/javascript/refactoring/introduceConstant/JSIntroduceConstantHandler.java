package com.intellij.lang.javascript.refactoring.introduceConstant;

import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.refactoring.JSBaseIntroduceHandler;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Ref;
import com.intellij.openapi.editor.Editor;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.util.IncorrectOperationException;
import com.intellij.refactoring.util.CommonRefactoringUtil;
import org.jetbrains.annotations.NonNls;

/**
 * @author Maxim.Mossienko
 *         Date: May 29, 2008
 *         Time: 8:20:03 PM
 */
public class JSIntroduceConstantHandler extends JSBaseIntroduceHandler<JSElement, JSIntroduceConstantSettings, JSIntroduceConstantDialog> {
  protected String getRefactoringName() {
    return JSBundle.message("javascript.introduce.constant.title");
  }

  protected String getCannotIntroduceMessagePropertyKey() {
    return "javascript.introduce.constant.error.no.expression.selected";
  }

  protected JSIntroduceConstantDialog createDialog(final Project project, final JSExpression expression, final JSExpression[] occurrences) {
    return new JSIntroduceConstantDialog(project, occurrences, expression);
  }

  @Override
  protected String getDeclText(final JSIntroduceConstantSettings settings) {
    @NonNls String baseDeclText = "static const " + settings.getVariableName();
    final JSAttributeList.AccessType type = settings.getAccessType();
    if (type != JSAttributeList.AccessType.PACKAGE_LOCAL) baseDeclText = type.toString().toLowerCase() + " " + baseDeclText;

    return baseDeclText;
  }

  @Override
  protected JSElement findAnchor(final BaseIntroduceContext<JSIntroduceConstantSettings> context, final boolean replaceAllOccurences) {
    return findClassAnchor(context.expression);
  }

  protected JSElement addStatementBefore(final JSElement anchorStatement, final JSVarStatement declaration) throws                                                                                     IncorrectOperationException {
    return addToClassAnchor(anchorStatement, declaration);
  }

  @Override
  protected JSExpression findIntroducedExpression(final PsiFile file, final int start, final int end, Editor editor) {
    if (file.getLanguage() != JavaScriptSupportLoader.ECMA_SCRIPT_L4) {
      CommonRefactoringUtil.showErrorHint(file.getProject(), editor, JSBundle.message("javascript.introduce.constant.error.not.available.in.javascript.code"),
                                          getRefactoringName(), null);
      return null;
    }

    final JSExpression expression = super.findIntroducedExpression(file, start, end, editor);
    if (expression == null) return null;

    final Ref<Boolean> hasAccesibilityProblem = new Ref<Boolean>();
    expression.accept(new JSElementVisitor() {
      @Override
      public void visitJSReferenceExpression(final JSReferenceExpression node) {
        if (node.getQualifier() == null) {
          final PsiElement element = node.resolve();

          if (element instanceof JSAttributeListOwner && !(element instanceof JSClass)) {
            final JSAttributeList attributeList = ((JSAttributeListOwner)element).getAttributeList();
            if (attributeList == null || !attributeList.hasModifier(JSAttributeList.ModifierType.STATIC)) {
              hasAccesibilityProblem.set(Boolean.TRUE);
            }
          } else if (element == null) {
            hasAccesibilityProblem.set(Boolean.TRUE);
          }
        }
        super.visitJSReferenceExpression(node);
      }

      @Override
      public void visitJSElement(final JSElement node) {
        node.acceptChildren(this);
      }
    });

    if (Boolean.TRUE.equals(hasAccesibilityProblem.get())) {
      CommonRefactoringUtil.showErrorHint(file.getProject(), editor, JSBundle.message("javascript.introduce.constant.error.not.constant.expression.selected"),
                                          getRefactoringName(), null);
      return null;
    }
    return expression;
  }
}
