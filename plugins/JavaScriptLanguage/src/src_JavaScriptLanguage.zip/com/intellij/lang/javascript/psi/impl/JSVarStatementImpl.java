/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi.impl;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.psi.*;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiElementVisitor;
import com.intellij.psi.PsiSubstitutor;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.psi.tree.TokenSet;
import org.jetbrains.annotations.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 30, 2005
 * Time: 9:35:47 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSVarStatementImpl extends JSStatementImpl implements JSVarStatement {
  private static final TokenSet VARIABLE_FILTER = TokenSet.create(JSElementTypes.VARIABLE);

  public JSVarStatementImpl(final ASTNode node) {
    super(node);
  }

  public JSVariable[] getVariables() {
    final ASTNode[] nodes = getNode().getChildren(VARIABLE_FILTER);
    JSVariable[] vars = new JSVariable[nodes.length];
    for (int i = 0; i < vars.length; i++) {
      vars[i] = (JSVariable)nodes[i].getPsi();
    }
    return vars;
  }

  public void declareVariable(String name, JSExpression initializer) {
    throw new UnsupportedOperationException("TODO: implement");
  }

  public void accept(@NotNull PsiElementVisitor visitor) {
    if (visitor instanceof JSElementVisitor) {
      ((JSElementVisitor)visitor).visitJSVarStatement(this);
    }
    else {
      visitor.visitElement(this);
    }
  }

  public boolean processDeclarations(@NotNull PsiScopeProcessor processor,
                                     @NotNull PsiSubstitutor substitutor,
                                     PsiElement lastParent,
                                     @NotNull PsiElement place) {
    final JSVariable[] vars = getVariables();
    
    for (JSVariable var : vars) {
      if (lastParent != null && lastParent.getParent() == var) break;
      if (!processor.execute(var, substitutor)) return false;
    }


    return true;
  }
}
