/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript;

import com.intellij.codeInspection.InspectionToolProvider;
import com.intellij.ide.IconProvider;
import com.intellij.lang.LanguageDialect;
import com.intellij.lang.ParserDefinition;
import com.intellij.lang.annotation.Annotator;
import com.intellij.lang.javascript.inspections.*;
import com.intellij.lang.javascript.psi.JSAttribute;
import com.intellij.lang.javascript.psi.JSAttributeList;
import com.intellij.lang.javascript.psi.JSAttributeNameValuePair;
import com.intellij.lang.javascript.psi.JSClass;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.refactoring.NamesValidator;
import com.intellij.lexer.Lexer;
import com.intellij.lexer.LexerBase;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.fileTypes.*;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.StringEscapesTokenTypes;
import com.intellij.psi.codeStyle.CodeStyleSettings;
import com.intellij.psi.codeStyle.FileTypeIndentOptionsProvider;
import com.intellij.psi.tree.IElementType;
import com.intellij.psi.tree.TokenSet;
import com.intellij.psi.xml.XmlTag;
import com.intellij.util.PairConsumer;
import gnu.trove.THashMap;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.Map;

/**
 * @by max, maxim.mossienko
 */
public class JavaScriptSupportLoader extends FileTypeFactory implements ApplicationComponent, InspectionToolProvider,
                                                                        FileTypeIndentOptionsProvider, IconProvider {
  public static final LanguageFileType JAVASCRIPT = new JavaScriptFileType();

  public static final LanguageDialect ECMA_SCRIPT_L4 = new ECMAL4LanguageDialect();
  public static final LanguageDialect JSON = new JSONLanguageDialect();
  public static final JSLanguageDialect GWT_DIALECT = new GwtLanguageDialect();

  private static final @NonNls String ECMA_SCRIPT_L4_FILE_EXTENSION = "as";
  public static final @NonNls String ECMA_SCRIPT_L4_FILE_EXTENSION2 = "js2";
  private static final @NonNls String ECMA_SCRIPT_L4_FILE_EXTENSION3 = "es";
  public static final @NonNls String JSON_FILE_EXTENSION = "json";
  public static final @NonNls String MXML_URI = "http://www.adobe.com/2006/mxml";
  public static final @NonNls String MXML_URI2 = "http://www.macromedia.com/2003/mxml";
  public static final @NonNls String BINDOWS_URI = "http://www.bindows.net";

  public void initComponent() {
  }

  public void disposeComponent() {
  }

  @NotNull
  public String getComponentName() {
    return "javascript support loader";
  }

  public Class[] getInspectionClasses() {
    return new Class[] {
      JSUnresolvedVariableInspection.class,
      JSUndeclaredVariableInspection.class,
      JSUntypedDeclarationInspection.class,
      JSUnresolvedFunctionInspection.class,
      JSDuplicatedDeclarationInspection.class,
      JSDeprecatedSymbolsInspection.class,
      JSUnusedLocalSymbolsInspection.class, 
      JSShowOverridingMarkersInspection.class
    };
  }

  public CodeStyleSettings.IndentOptions createIndentOptions() {
    return new CodeStyleSettings.IndentOptions();
  }

  public FileType getFileType() {
    return JAVASCRIPT;
  }

  public static @Nullable LanguageDialect getLanguageDialect(VirtualFile file) {
    if (file != null) {
      final String extension = file.getExtension();
      if (ECMA_SCRIPT_L4_FILE_EXTENSION.equals(extension) ||
          ECMA_SCRIPT_L4_FILE_EXTENSION2.equals(extension)  ||
          ECMA_SCRIPT_L4_FILE_EXTENSION3.equals(extension)) {
        return ECMA_SCRIPT_L4;
      } else if (JSON_FILE_EXTENSION.equals(extension)) {
        return JSON;
      } else if (ApplicationManager.getApplication().isUnitTestMode() && GWT_DIALECT.getFileExtension().equals(extension)) {
        return GWT_DIALECT;
      }
    }
    return null;
  }

  public void createFileTypes(final @NotNull PairConsumer<FileType, String> consumer) {
    consumer.consume(JAVASCRIPT, "js;" + ECMA_SCRIPT_L4_FILE_EXTENSION + ";" + ECMA_SCRIPT_L4_FILE_EXTENSION2 + ";" + JSON_FILE_EXTENSION +
                                 ";" + ECMA_SCRIPT_L4_FILE_EXTENSION3);
  }

  public static boolean isFlexMxmFile(final PsiFile file) {
    return file.getFileType() == StdFileTypes.XML && nameHasMxmlExtension(file.getName());
  }

  public static boolean isFlexMxmFile(final VirtualFile file) {
    return file.getFileType() == StdFileTypes.XML && nameHasMxmlExtension(file.getName());
  }

  private static boolean nameHasMxmlExtension(final String s) {
    return s.endsWith(".mxml") || s.endsWith(".mxm");
  }

  private static class ECMAL4LanguageDialect extends JSLanguageDialect {
    private JSNamesValidator myNamesValidator;
    private JavascriptParserDefinition myParserDefinition;
    public static final DialectOptionHolder DIALECT_OPTION_HOLDER = new DialectOptionHolder(true, false);

    public ECMAL4LanguageDialect() {
      super("ECMA Script Level 4", JavaScriptSupportLoader.JAVASCRIPT.getLanguage());
    }

    @Override
    @Nullable
    public Annotator getAnnotator() {
      return getBaseLanguage().getAnnotator();
    }

    @Nullable
    public ParserDefinition getParserDefinition() {
      if (myParserDefinition == null) {
        myParserDefinition = new JavascriptParserDefinition() {
          @NotNull
          public Lexer createLexer(final Project project) {
            return new JavaScriptParsingLexer(DIALECT_OPTION_HOLDER);
          }
        };
      }
      return myParserDefinition;
    }

    @NotNull
    public NamesValidator getNamesValidator() {
      if (myNamesValidator == null) myNamesValidator = new JSNamesValidator(DIALECT_OPTION_HOLDER);
      return myNamesValidator;
    }

    @NotNull
    public SyntaxHighlighter getSyntaxHighlighter(Project project, final VirtualFile virtualFile) {
      return new JSHighlighter(DIALECT_OPTION_HOLDER);
    }

    public String getFileExtension() {
      return ECMA_SCRIPT_L4_FILE_EXTENSION2;
    }
  }

  private static class JSONLanguageDialect extends JSLanguageDialect {
    private JavascriptParserDefinition myParserDefinition;
    private JSNamesValidator myNamesValidator;

    public String getFileExtension() {
      return JSON_FILE_EXTENSION;
    }

    static final class JSONLexer extends LexerBase {
      private final Lexer myLexer;
      private final TokenSet myAllowedTokenSet = TokenSet.orSet(JSTokenTypes.IDENTIFIER_TOKENS_SET, TokenSet.create(
        JSTokenTypes.NULL_KEYWORD,
        JSTokenTypes.LBRACE,
        JSTokenTypes.LBRACKET,
        JSTokenTypes.RBRACE,
        JSTokenTypes.RBRACKET,
        JSTokenTypes.TRUE_KEYWORD,
        JSTokenTypes.FALSE_KEYWORD,
        JSTokenTypes.NUMERIC_LITERAL,
        JSTokenTypes.STRING_LITERAL,
        JSTokenTypes.SINGLE_QUOTE_STRING_LITERAL,
        JSTokenTypes.COMMA,
        JSTokenTypes.COLON,
        JSTokenTypes.WHITE_SPACE,
        JSTokenTypes.MINUS,
        JSTokenTypes.C_STYLE_COMMENT,
        JSTokenTypes.END_OF_LINE_COMMENT,
        StringEscapesTokenTypes.INVALID_CHARACTER_ESCAPE_TOKEN,
        StringEscapesTokenTypes.VALID_STRING_ESCAPE_TOKEN,
        StringEscapesTokenTypes.INVALID_UNICODE_ESCAPE_TOKEN
      ));

      JSONLexer(Lexer baseLexer) {
        myLexer = baseLexer;
      }

      public void start(final CharSequence buffer, final int startOffset, final int endOffset, final int initialState) {
        myLexer.start(buffer, startOffset, endOffset,initialState);
      }

      @Deprecated
      public void start(char[] buffer, int startOffset, int endOffset, int initialState) {
        myLexer.start(buffer, startOffset, endOffset,initialState);
      }

      public int getState() {
        return myLexer.getState();
      }

      @Nullable
      public IElementType getTokenType() {
        final IElementType tokenType = myLexer.getTokenType();
        if (myAllowedTokenSet.contains(tokenType) || tokenType == null) return tokenType;
        return JSTokenTypes.BAD_CHARACTER;
      }

      public int getTokenStart() {
        return myLexer.getTokenStart();
      }

      public int getTokenEnd() {
        return myLexer.getTokenEnd();
      }

      public void advance() {
        myLexer.advance();
      }

      @Deprecated
      public char[] getBuffer() {
        return myLexer.getBuffer();
      }

      public int getBufferEnd() {
        return myLexer.getBufferEnd();
      }
    }

    public JSONLanguageDialect() {
      super("JavaScript Object Notation", JavaScriptSupportLoader.JAVASCRIPT.getLanguage());
    }

    @Nullable
    public ParserDefinition getParserDefinition() {
      if (myParserDefinition == null) {
        myParserDefinition = new JavascriptParserDefinition() {
          @NotNull
          public Lexer createLexer(final Project project) {
            return new JSONLexer(new JavaScriptParsingLexer(JavascriptLanguage.DIALECT_OPTION_HOLDER));
          }
        };
      }
      return myParserDefinition;
    }

    @NotNull
    public SyntaxHighlighter getSyntaxHighlighter(Project project, final VirtualFile virtualFile) {
      return new JSHighlighter(JavascriptLanguage.DIALECT_OPTION_HOLDER) {
        @NotNull
        public Lexer getHighlightingLexer() {
          return new JSONLexer(super.getHighlightingLexer());
        }
      };
    }

    @NotNull
    public NamesValidator getNamesValidator() {
      if (myNamesValidator == null) {
        myNamesValidator = new JSNamesValidator(JavascriptLanguage.DIALECT_OPTION_HOLDER) {
          protected Lexer createLexer(final DialectOptionHolder optionHolder) {
            return new JSONLexer(new JavaScriptLexer(optionHolder));
          }

          public synchronized boolean isIdentifier(String name, final Project project) {
            if (!StringUtil.startsWithChar(name,'\'') && !StringUtil.startsWithChar(name,'\"')) {
              name = "\"" + name;
            }

            if (!StringUtil.endsWithChar(name,'"') && !StringUtil.endsWithChar(name,'\"')) {
              name += "\"";
            }

            myLexer.start(name, 0, name.length(), 0);
            IElementType type = myLexer.getTokenType();

            return myLexer.getTokenEnd() == name.length() && (type == JSTokenTypes.STRING_LITERAL || type == JSTokenTypes.SINGLE_QUOTE_STRING_LITERAL);
          }
        };
      }
      return myNamesValidator;
    }
  }

  private static Map<String, Icon> myQNameToIconMap = new THashMap<String, Icon>();
  private static long myQNameToIconModificationCount;

  public Icon getIcon(@NotNull final PsiElement element, final int flags) {
    if (element instanceof XmlTag) {
      if (isFlexMxmFile(element.getContainingFile())) {
        XmlTag tag = (XmlTag)element;
        final long count = element.getManager().getModificationTracker().getModificationCount();
        final String tagName = tag.getName();

        if (myQNameToIconModificationCount == count) {
          final Icon icon = myQNameToIconMap.get(tagName);
          if (icon != null) return icon;
          if (myQNameToIconMap.containsKey(tagName)) return null;
        } else {
          myQNameToIconMap.clear();
          myQNameToIconModificationCount = count;
        }

        final JSClass aClass = JSResolveUtil.getClassFromTagNameInMxml(element.getFirstChild());
        if (aClass != null) {
          final JSAttributeList attributeList = aClass.getAttributeList();

          if (attributeList != null) {
            final JSAttribute[] attrs = attributeList.getAttributesByName("IconFile");

            if (attrs.length > 0) {
              final JSAttributeNameValuePair pair = attrs[0].getValueByName(null);

              if (pair != null) {
                final String s = pair.getSimpleValue();
                final VirtualFile file = aClass.getContainingFile().getVirtualFile();

                if (file != null) {
                  final VirtualFile child = file.getParent().findChild(s);
                  if (child != null) {
                    final ImageIcon icon = new ImageIcon(child.getPath());
                    myQNameToIconMap.put(tagName, icon);
                    return icon;
                  }
                }
              }
            }
          }
        }

        myQNameToIconMap.put(tagName, null);
      }
    }
    return null;
  }
}
