/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.folding;

import com.intellij.lang.ASTNode;
import com.intellij.lang.folding.FoldingBuilder;
import com.intellij.lang.folding.FoldingDescriptor;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.openapi.editor.Document;
import com.intellij.codeInsight.folding.CodeFoldingSettings;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Feb 1, 2005
 * Time: 12:11:46 AM
 * To change this template use File | Settings | File Templates.
 */
public class JavaScriptFoldingBuilder implements FoldingBuilder {
  public FoldingDescriptor[] buildFoldRegions(ASTNode node, Document document) {
    List<FoldingDescriptor> descriptors = new ArrayList<FoldingDescriptor>();
    appendDescriptors(node, document, descriptors);
    return descriptors.toArray(new FoldingDescriptor[descriptors.size()]);
  }

  private void appendDescriptors(final ASTNode node, final Document document, final List<FoldingDescriptor> descriptors) {
    if (node.getElementType() == JSElementTypes.BLOCK) {
      if (document.getLineNumber(node.getStartOffset()) != document.getLineNumber(node.getTextRange().getEndOffset())) {
        descriptors.add(new FoldingDescriptor(node, node.getTextRange()));
      }
    }
    else if (node.getElementType() == JSTokenTypes.DOC_COMMENT) {
      descriptors.add(new FoldingDescriptor(node, node.getTextRange()));
    }
    else if (node.getElementType() == JSTokenTypes.C_STYLE_COMMENT) {
      descriptors.add(new FoldingDescriptor(node, node.getTextRange()));
    }

    ASTNode child = node.getFirstChildNode();
    while (child != null) {
      appendDescriptors(child, document, descriptors);
      child = child.getTreeNext();
    }
  }

  public String getPlaceholderText(ASTNode node) {
    if (node.getElementType() == JSTokenTypes.DOC_COMMENT) {
      return "/**...*/";
    }
    else if (node.getElementType() == JSTokenTypes.C_STYLE_COMMENT) {
      return "/*...*/";
    }
    else if (node.getElementType() == JSElementTypes.BLOCK) {
      return "{...}";
    }
    return null;
  }

  public boolean isCollapsedByDefault(ASTNode node) {
    return CodeFoldingSettings.getInstance().isCollapseJavadocs() && node.getElementType() == JSTokenTypes.DOC_COMMENT;
  }
}
