/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.folding;

import com.intellij.codeInsight.folding.CodeFoldingSettings;
import com.intellij.lang.ASTNode;
import com.intellij.lang.folding.FoldingBuilder;
import com.intellij.lang.folding.FoldingDescriptor;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiWhiteSpace;
import com.intellij.psi.tree.IElementType;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Feb 1, 2005
 * Time: 12:11:46 AM
 * To change this template use File | Settings | File Templates.
 */
public class JavaScriptFoldingBuilder implements FoldingBuilder {
  public FoldingDescriptor[] buildFoldRegions(ASTNode node, Document document) {
    List<FoldingDescriptor> descriptors = new ArrayList<FoldingDescriptor>();
    appendDescriptors(node, document, descriptors);
    return descriptors.toArray(new FoldingDescriptor[descriptors.size()]);
  }

  private static ASTNode appendDescriptors(final ASTNode node, final Document document, final List<FoldingDescriptor> descriptors) {
    final IElementType type = node.getElementType();
    if (type == JSElementTypes.BLOCK || type == JSElementTypes.OBJECT_LITERAL_EXPRESSION) {
      if (document.getLineNumber(node.getStartOffset()) != document.getLineNumber(node.getTextRange().getEndOffset())) {
        descriptors.add(new FoldingDescriptor(node, node.getTextRange()));
      }
    }
    else if (type == JSTokenTypes.DOC_COMMENT) {
      descriptors.add(new FoldingDescriptor(node, node.getTextRange()));
    }
    else if (type == JSTokenTypes.C_STYLE_COMMENT) {
      descriptors.add(new FoldingDescriptor(node, node.getTextRange()));
    } else if (type == JSTokenTypes.END_OF_LINE_COMMENT) {
      return collapseConsequentNodesOfSpecifiedType(node, descriptors, JSTokenTypes.END_OF_LINE_COMMENT);
    } else if (type == JSElementTypes.IMPORT_STATEMENT) {
      return collapseConsequentNodesOfSpecifiedType(node, descriptors, JSElementTypes.IMPORT_STATEMENT);
    }

    if (type == JSElementTypes.FILE) {
      // expand chameleon
      final PsiElement firstChild = node.getPsi().getFirstChild();
    }

    ASTNode child = node.getFirstChildNode();
    while (child != null) {
      child = appendDescriptors(child, document, descriptors).getTreeNext();
    }

    return node;
  }

  private static ASTNode collapseConsequentNodesOfSpecifiedType(final ASTNode node, final List<FoldingDescriptor> descriptors,
                                                                final IElementType endOfLineComment) {
    ASTNode lastEoLComment = node;
    ASTNode current = node.getTreeNext();

    while(current != null && current.getPsi() instanceof PsiWhiteSpace) {
      current = current.getTreeNext();
      if (current != null && current.getElementType() == endOfLineComment) {
        lastEoLComment = current;
        current = current.getTreeNext();
      }
    }

    if (lastEoLComment != node) {
      descriptors.add(new FoldingDescriptor(node, new TextRange(node.getStartOffset(), lastEoLComment.getStartOffset() + lastEoLComment.getTextLength())));
      return lastEoLComment;
    } else {
      return node;
    }
  }

  public String getPlaceholderText(ASTNode node) {
    final IElementType type = node.getElementType();
    if (type == JSTokenTypes.DOC_COMMENT) {
      return "/**...*/";
    }
    else if (type == JSTokenTypes.C_STYLE_COMMENT) {
      return "/*...*/";
    } else if (type == JSTokenTypes.END_OF_LINE_COMMENT) {
      return "//...";
    } else if (type == JSElementTypes.IMPORT_STATEMENT) {
      return "import ...";
    }
    else if (type == JSElementTypes.BLOCK || type == JSElementTypes.OBJECT_LITERAL_EXPRESSION) {
      return "{...}";
    }
    return null;
  }

  public boolean isCollapsedByDefault(ASTNode node) {
    if (node.getTreeParent().getElementType() == JSElementTypes.FILE && node.getTreePrev() == null) {
      return CodeFoldingSettings.getInstance().isCollapseFileHeader();
    }
    if (node.getElementType() == JSElementTypes.IMPORT_STATEMENT) {
      return CodeFoldingSettings.getInstance().isCollapseImports();
    }
    return CodeFoldingSettings.getInstance().isCollapseJavadocs() && node.getElementType() == JSTokenTypes.DOC_COMMENT;
  }
}
