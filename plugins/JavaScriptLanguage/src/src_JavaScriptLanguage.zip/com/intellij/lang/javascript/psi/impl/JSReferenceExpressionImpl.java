/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi.impl;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.lang.javascript.index.JSSymbolUtil;
import com.intellij.lang.javascript.index.JavaScriptIndex;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.VariantsProcessor;
import com.intellij.lang.javascript.psi.resolve.WalkUpResolveProcessor;
import com.intellij.lang.javascript.psi.resolve.ResolveProcessor;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.*;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NonNls;

/**
 * TODO: implement all reference stuff...
 */
public class JSReferenceExpressionImpl extends JSExpressionImpl implements JSReferenceExpression {
  @NonNls private static final String PROTOTYPE_FIELD_NAME = "prototype";

  public JSReferenceExpressionImpl(final ASTNode node) {
    super(node);
  }

  @Nullable public JSExpression getQualifier() {
    final ASTNode[] nodes = getNode().getChildren(JSElementTypes.EXPRESSIONS);
    return (JSExpression)(nodes.length == 1 ? nodes[0].getPsi() : null);
  }

  @Nullable public String getReferencedName() {
    final ASTNode nameElement = getNameElement();
    return nameElement != null ? nameElement.getText() : null;
  }

  @Nullable
  public PsiElement getReferenceNameElement() {
    final ASTNode element = getNameElement();
    return element != null ? element.getPsi():null;
  }

  public PsiElement getElement() {
    return this;
  }

  public PsiReference getReference() {
    return this;
  }

  public TextRange getRangeInElement() {
    final ASTNode nameElement = getNameElement();
    final int startOffset = nameElement != null ? nameElement.getStartOffset() : getNode().getTextRange().getEndOffset();
    return new TextRange(startOffset - getNode().getStartOffset(), getTextLength());
  }

  private ASTNode getNameElement() {
    return getNode().findChildByType(JSTokenTypes.IDENTIFIER);
  }

  public PsiElement resolve() {
    final ResolveResult[] resolveResults = multiResolve(true);

    return resolveResults.length == 0 || resolveResults.length > 1 ? null:resolveResults[0].getElement();
  }

  public String getCanonicalText() {
    return null;
  }

  public PsiElement handleElementRename(String newElementName) throws IncorrectOperationException {
    JSChangeUtil.doIdentifierReplacement(this,getNameElement().getPsi(), newElementName);
    return this;
  }

  public PsiElement bindToElement(PsiElement element) throws IncorrectOperationException {
    final ASTNode nameElement = JSChangeUtil.createNameIdentifier(getProject(), ((JSNamedElement)element).getName());
    getNode().replaceChild(getNameElement(), nameElement);
    return this;
  }

  public boolean isReferenceTo(PsiElement element) {
    if (element instanceof PsiNamedElement || element instanceof XmlAttributeValue) {
      final String referencedName = getReferencedName();

      if (referencedName != null &&
          element instanceof JSDefinitionExpression &&
          referencedName.equals(((JSDefinitionExpression)element).getName())
         ) {
        final JSExpression expression = ((JSDefinitionExpression)element).getExpression();
        if (expression instanceof JSReferenceExpression) {
          final JSReferenceExpression jsReferenceExpression = (JSReferenceExpression)expression;
          final JSExpression qualifier = jsReferenceExpression.getQualifier();
          final JSExpression myQualifier = getQualifier();

          return (myQualifier != null ||
                  (qualifier == myQualifier ||
                   "window".equals(qualifier.getText())
                  ));
        } else {
          return true;
        }
      }
      return JSResolveUtil.isReferenceTo(this, referencedName, element);
    }
    return false;
  }

  public Object[] getVariants() {
    final JSExpression qualifier = getQualifier();
    int[] nameIds = null;
    final PsiFile psiFile = getContainingFile();
    final JavaScriptIndex index = JavaScriptIndex.getInstance(psiFile.getProject());

    if (qualifier instanceof JSThisExpression) {
      // We need to resolve ns mapping for 'this', which function was the constructor of the object
      JSFunction parentContainer = PsiTreeUtil.getParentOfType(this, JSFunction.class);

      if (parentContainer instanceof JSFunctionExpression) {
        JSElement qualifyingExpression = null;

        while(parentContainer instanceof JSFunctionExpression) {
          final PsiElement parentContainerParent = parentContainer.getParent();

          if (parentContainerParent instanceof JSAssignmentExpression) {
            final JSElement functionExpressionName = ((JSDefinitionExpression)((JSAssignmentExpression)parentContainerParent).getLOperand()).getExpression();
            qualifyingExpression = functionExpressionName;

            if (functionExpressionName instanceof JSReferenceExpression) {
              final JSExpression functionExpressionNameQualifier = ((JSReferenceExpression)functionExpressionName).getQualifier();

              if (functionExpressionNameQualifier instanceof JSThisExpression) {
                parentContainer = PsiTreeUtil.getParentOfType(functionExpressionName, JSFunction.class);
                continue;
              } else if (functionExpressionNameQualifier instanceof JSReferenceExpression) {
                final String functionExpressionNameQualifierText = ((JSReferenceExpression)functionExpressionNameQualifier).getReferencedName();

                if (PROTOTYPE_FIELD_NAME.equals(functionExpressionNameQualifierText)) {
                  qualifyingExpression = ((JSReferenceExpression)functionExpressionNameQualifier).getQualifier();
                }
              }
            }
          } else if (parentContainerParent instanceof JSProperty) {
            final JSElement element =
              PsiTreeUtil.getParentOfType(parentContainerParent, JSVariable.class, JSAssignmentExpression.class, JSArgumentList.class);
            if (element instanceof JSVariable) {
              nameIds = JSSymbolUtil.buildNameIndexArray(element, null, index);
            } else if (element instanceof JSAssignmentExpression) {
              qualifyingExpression = ((JSDefinitionExpression)((JSAssignmentExpression)element).getLOperand()).getExpression();
            } else if (element instanceof JSArgumentList) {
              for(JSExpression expr: ((JSArgumentList)element).getArguments()) {
                if (expr instanceof JSReferenceExpression) {
                  qualifyingExpression = expr; break;
                }
              }
            }
          } else if (parentContainerParent instanceof JSNewExpression) {
            final JSElement element =
              PsiTreeUtil.getParentOfType(parentContainerParent, JSVariable.class, JSAssignmentExpression.class, JSArgumentList.class);

            if (element instanceof JSVariable) {
              nameIds = JSSymbolUtil.buildNameIndexArray(element, null, index);
            } else if (element instanceof JSAssignmentExpression) {
              qualifyingExpression = ((JSDefinitionExpression)((JSAssignmentExpression)element).getLOperand()).getExpression();
            }
          } else if (parentContainerParent instanceof JSReferenceExpression) {
            parentContainer = PsiTreeUtil.getParentOfType(parentContainerParent, JSFunction.class);
            continue;
          }

          break;
        }

        if (qualifyingExpression instanceof JSReferenceExpression) {
          final String functionExpressionNameQualifierText = ((JSReferenceExpression)qualifyingExpression).getReferencedName();

          if (PROTOTYPE_FIELD_NAME.equals(functionExpressionNameQualifierText)) {
            qualifyingExpression = ((JSReferenceExpression)qualifyingExpression).getQualifier();
          }
          nameIds = JSSymbolUtil.buildNameIndexArray(qualifyingExpression, null, index);
        }
      } else if (parentContainer != null) {
        nameIds = new int[] { index.getIndexOf( parentContainer.getName() ) };
      }

      if (nameIds== null) nameIds = new int[] { index.getIndexOf( "" ) };
    } else {
      nameIds = JSSymbolUtil.buildNameIndexArray(qualifier, null, index);
    }

    final VariantsProcessor processor = new VariantsProcessor(
      nameIds,
      getContainingFile(),
      false,
      this
    );

    if (qualifier == null) {
      JSResolveUtil.treeWalkUp(processor, this, this, this);
    }

    JavaScriptIndex.getInstance(getProject()).processAllSymbols(processor);

    return processor.getResult();
  }

  public boolean isSoft() {
    return false;
  }

  public void accept(PsiElementVisitor visitor) {
    if (visitor instanceof JSElementVisitor) {
      ((JSElementVisitor)visitor).visitJSReferenceExpression(this);
    }
    else {
      visitor.visitElement(this);
    }
  }

  @NotNull
  public ResolveResult[] multiResolve(final boolean incompleteCode) {
    final String referencedName = getReferencedName();
    if (referencedName == null) return ResolveResult.EMPTY_ARRAY;

    final PsiElement parent = getParent();
    final JSExpression qualifier = getQualifier();
    if (parent instanceof JSDefinitionExpression && qualifier != null) {
      return new ResolveResult[] { new JSResolveUtil.MyResolveResult( (JSElement)parent) };
    }

    boolean doLocalLookup = qualifier == null;
    final PsiFile containingFile = getContainingFile();

    if (doLocalLookup) {
      final ResolveProcessor processor = new ResolveProcessor(referencedName);
      final JSElement jsElement = JSResolveUtil.treeWalkUp(processor, this, this, this);

      if (jsElement != null) {
        return new ResolveResult[]{new JSResolveUtil.MyResolveResult(jsElement)};
      }
    }

    final WalkUpResolveProcessor processor = new WalkUpResolveProcessor(
      getText(),
      JSSymbolUtil.buildNameIndexArray(this, null, JavaScriptIndex.getInstance(containingFile.getProject())),
      containingFile,
      false,
      this
    );

    return JSResolveUtil.resolve(containingFile, processor);
  }
}
