/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi.impl;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.index.JSNamedElementProxy;
import com.intellij.lang.javascript.index.JSPackage;
import com.intellij.lang.javascript.index.JavaScriptIndex;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.resolve.*;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.*;
import com.intellij.psi.tree.TokenSet;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlToken;
import com.intellij.util.ArrayUtil;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class JSReferenceExpressionImpl extends JSExpressionImpl implements JSReferenceExpression {
  private static final TokenSet IDENTIFIER_TOKENS_SET = TokenSet.orSet(JSTokenTypes.IDENTIFIER_TOKENS_SET, TokenSet.create(JSTokenTypes.ANY_IDENTIFIER));

  public JSReferenceExpressionImpl(final ASTNode node) {
    super(node);
  }

  @Nullable public JSExpression getQualifier() {
    final ASTNode node = getNode().findChildByType(JSElementTypes.EXPRESSIONS);
    return node != null ? (JSExpression)node.getPsi() : null;
  }

  @Nullable public String getReferencedName() {
    final ASTNode nameElement = getNameElement();
    return nameElement != null ? nameElement.getText() : null;
  }

  @Nullable
  public PsiElement getReferenceNameElement() {
    final ASTNode element = getNameElement();
    return element != null ? element.getPsi():null;
  }

  public PsiElement getElement() {
    return this;
  }

  public PsiReference getReference() {
    return this;
  }

  public TextRange getRangeInElement() {
    final ASTNode nameElement = getNameElement();
    final int startOffset = nameElement != null ? nameElement.getStartOffset() : getNode().getTextRange().getEndOffset();
    return new TextRange(startOffset - getNode().getStartOffset(), getTextLength());
  }

  private ASTNode getNameElement() {
    return getNode().findChildByType(IDENTIFIER_TOKENS_SET);
  }

  public PsiElement resolve() {
    final ResolveResult[] resolveResults = multiResolve(true);

    return resolveResults.length == 0 || resolveResults.length > 1 ? null:resolveResults[0].getElement();
  }

  public String getCanonicalText() {
    return getText();
  }

  public PsiElement handleElementRename(String newElementName) throws IncorrectOperationException {
    final int i = newElementName.lastIndexOf('.');
    if (i != -1) newElementName = newElementName.substring(0, i);
    if (!JavaScriptSupportLoader.JAVASCRIPT.getLanguage().getNamesValidator().isIdentifier(newElementName, null)) {
      throw new IncorrectOperationException("Invalid javascript element name:" + newElementName);
    }
    final PsiElement parent = getParent();
    if (parent instanceof JSClass || parent instanceof JSFunction) {
      final ASTNode node = ((JSNamedElement)parent).findNameIdentifier();
      if (node != null && node.getPsi() == this) return this; // JSNamedElement.setName will care of things
    }
    JSChangeUtil.doIdentifierReplacement(this,getNameElement().getPsi(), newElementName);
    return this;
  }

  public PsiElement bindToElement(@NotNull PsiElement element) throws IncorrectOperationException {
    final ASTNode nameElement = JSChangeUtil.createNameIdentifier(getProject(), ((PsiNamedElement)element).getName());
    getNode().replaceChild(getNameElement(), nameElement);
    return this;
  }

  public boolean isReferenceTo(PsiElement element) {
    if (element instanceof PsiNamedElement || element instanceof XmlAttributeValue) {
      final String referencedName = getReferencedName();

      if (referencedName != null) {
        if (element instanceof JSDefinitionExpression &&
            referencedName.equals(((JSDefinitionExpression)element).getName())
           ) {
          final JSExpression expression = ((JSDefinitionExpression)element).getExpression();
          if (expression instanceof JSReferenceExpression) {
            final JSReferenceExpression jsReferenceExpression = (JSReferenceExpression)expression;
            final JSExpression qualifier = jsReferenceExpression.getQualifier();
            final JSExpression myQualifier = getQualifier();
            if (expression == this) return false; // do not include self to usages

            return (myQualifier != null ||
                    (qualifier == myQualifier ||
                     "window".equals(qualifier.getText())
                    ));
          } else {
            return true;
          }
        } else if ( element instanceof JSProperty &&
          referencedName.equals(((JSProperty)element).getName())
        ) {
          if (getQualifier() != null) {
            return true; // TODO: check for type of element to be the same
          }
          //return false;
        }
      }
      return JSResolveUtil.isReferenceTo(this, referencedName, element);
    }
    return false;
  }

  private boolean doProcessLocalDeclarations(final JSExpression qualifier, final ResolveProcessor processor, boolean ecma, boolean completion) {
    JSClass jsClass = PsiTreeUtil.getParentOfType(this, JSClass.class);
    if (jsClass == null && ecma) {
      final PsiElement element = JSResolveUtil.getClassReferenceForXmlFromContext(getContainingFile());
      if (element instanceof JSClass) jsClass = (JSClass)element;
    }

    final boolean inTypeContext = JSResolveUtil.isExprInTypeContext(this);
    final boolean whereTypeCanBe = inTypeContext ||
                                  (completion && ecma ? JSResolveUtil.isInPlaceWhereTypeCanBeDuringCompletion(this):false);
    PsiElement elToProcess = this;
    PsiElement scopeToStopAt = null;

    final PsiElement parent = getParent();
    boolean toProcessMembers = true;

    if (qualifier != null) {
      elToProcess = jsClass;

      if (jsClass == null) {
        if (qualifier instanceof JSThisExpression) {
          if (ecma) {
            final JSFunction nearestFunction = PsiTreeUtil.getParentOfType(this, JSFunction.class);
            elToProcess = nearestFunction != null ? nearestFunction:this;
          } else {
            elToProcess = PsiTreeUtil.getParentOfType(this, JSProperty.class);
            if (elToProcess != null) scopeToStopAt = elToProcess.getParent();
          }
        } else if (qualifier instanceof JSSuperExpression) {
          elToProcess = JSResolveUtil.getClassFromTagNameInMxml(this);
        }
      }
    } else if (whereTypeCanBe) {
      if (inTypeContext) {
        if (!(parent instanceof JSNewExpression) && (!(parent instanceof JSAttributeList) || isStaticContext(parent))) {
          toProcessMembers = false;
          elToProcess = jsClass;
        }
      } else if (parent instanceof JSExpressionStatement && JSResolveUtil.isPlaceWhereNsCanBe(parent)) {
        toProcessMembers = false;
        elToProcess = null;
      }
    }

    if ( ( qualifier instanceof JSThisExpression ||
           qualifier instanceof JSSuperExpression
         ) && jsClass != null
       ) {
      scopeToStopAt = jsClass;
    }

    if (elToProcess == null && whereTypeCanBe) {
      elToProcess = PsiTreeUtil.getParentOfType(this, JSPackageStatement.class, JSFile.class);
    }

    processor.setTypeContext(whereTypeCanBe || (qualifier == null && parent instanceof JSReferenceExpression));
    processor.setToProcessMembers(toProcessMembers);
    
    if (elToProcess != null) {
      processor.setToProcessHierarchy(true);
      processor.setToSkipClassDeclarationsOnce(qualifier instanceof JSSuperExpression);
      JSResolveUtil.treeWalkUp(processor, elToProcess, elToProcess, this, scopeToStopAt);

      processor.setToProcessHierarchy(false);
      processor.setToSkipClassDeclarationsOnce(false);
    }
    
    return !processor.foundAllValidResults();
  }

  private static boolean isStaticContext(final PsiElement parent) {
    final PsiElement element = parent.getParent().getParent();
    return element instanceof JSClass || element instanceof JSPackageStatement;
  }

  public Object[] getVariants() {
    final PsiFile containingFile = getContainingFile();
    final boolean ecma = containingFile.getLanguageDialect() == JavaScriptSupportLoader.ECMA_SCRIPT_L4;
    Object[] smartVariants = JSSmartCompletionVariantsHandler.getSmartVariants(this, ecma);
    if (smartVariants != null) return smartVariants;
    final JSExpression qualifier = getQualifier();

    ResolveProcessor localProcessor = null;
    if (isLocalResolveQualifier(qualifier)) {
      final PsiElement parent = getParent();
      if (isSelfReference(parent)) { // Prevent Rulezz to appear
        return ArrayUtil.EMPTY_OBJECT_ARRAY;
      }

      localProcessor = new ResolveProcessor(null, this);

      doProcessLocalDeclarations(qualifier, localProcessor, ecma,      true);
    } else {
      final MyTypeProcessor processor = new MyTypeProcessor(null, ecma, this);
      BaseJSSymbolProcessor.doEvalForExpr(BaseJSSymbolProcessor.getOriginalQualifier(qualifier), containingFile, processor);

      if (processor.resolved == MyTypeProcessor.TypeResolveState.Resolved ||
          processor.resolved == MyTypeProcessor.TypeResolveState.Undefined
         ) {
        return processor.getResultsAsObjects();
      } else {
        localProcessor = processor;
      }
    }

    final VariantsProcessor processor = new VariantsProcessor(
      null, containingFile,
      false,
      this
    );

    if (localProcessor != null) processor.addLocalResults(localProcessor.getResults());

    JavaScriptIndex.getInstance(getProject()).processAllSymbols(processor);

    return processor.getResult();
  }

  public boolean isSoft() {
    return false;
  }

  public void accept(@NotNull PsiElementVisitor visitor) {
    if (visitor instanceof JSElementVisitor) {
      ((JSElementVisitor)visitor).visitJSReferenceExpression(this);
    }
    else {
      visitor.visitElement(this);
    }
  }

  @NotNull
  public ResolveResult[] multiResolve(final boolean incompleteCode) {
    return JSResolveUtil.resolve(getContainingFile(), this, MyResolver.INSTANCE);
  }

  static class MyResolver implements JSResolveUtil.Resolver<JSReferenceExpressionImpl> {
    private static final MyResolver INSTANCE = new MyResolver();

    public ResolveResult[] doResolve(final JSReferenceExpressionImpl jsReferenceExpression, final PsiFile file) {
      return jsReferenceExpression.doResolve(file);
    }
  }

  private ResolveResult[] doResolve(PsiFile containingFile) {
    final String referencedName = getReferencedName();
    if (referencedName == null) return ResolveResult.EMPTY_ARRAY;

    final PsiElement parent = getParent();
    final JSExpression qualifier = getQualifier();
    final boolean ecma = containingFile.getLanguageDialect() == JavaScriptSupportLoader.ECMA_SCRIPT_L4;
    final boolean localResolve = isLocalResolveQualifier(qualifier);
    final boolean parentIsDefinition = parent instanceof JSDefinitionExpression;

    final JavaScriptIndex index = JavaScriptIndex.getInstance(containingFile.getProject());

    // Handle self references
    PsiElement currentParent = parent;
    for(; currentParent instanceof JSReferenceExpression; currentParent = currentParent.getParent());
    if (isSelfReference(currentParent)) {
      return new ResolveResult[] { new JSResolveUtil.MyResolveResult( currentParent) };
    }

    if(currentParent instanceof JSImportStatement) {
      if (currentParent != parent) {
        final JSPackage aPackage = JSResolveUtil.findPackageByReference(this, index);

        if (aPackage != null) {
          return new ResolveResult[] { new JSResolveUtil.MyResolveResult( currentParent) };
        } else {
          return ResolveResult.EMPTY_ARRAY;
        }
      } else if ("*".equals(referencedName)) {
        return new ResolveResult[] { new JSResolveUtil.MyResolveResult( currentParent) };
      }
    }

    ResolveProcessor localProcessor;

    if (localResolve) {
      localProcessor = new ResolveProcessor(referencedName, this);

      final boolean canResolveAllLocally = !parentIsDefinition || !ecma;

      if (!doProcessLocalDeclarations(getQualifier(), localProcessor, ecma, false) && canResolveAllLocally) {
        final JSElement jsElement = localProcessor.getResult();

        if (jsElement != null) {
          return localProcessor.getResultsAsResolveResults();
        }
      }
    } else {
      final MyTypeProcessor processor = new MyTypeProcessor(referencedName, ecma, this);
      BaseJSSymbolProcessor.doEvalForExpr(qualifier, containingFile, processor);

      if (processor.resolved == MyTypeProcessor.TypeResolveState.Resolved ||
          processor.resolved == MyTypeProcessor.TypeResolveState.Undefined ||
          processor.getResult() != null
         ) {
        return processor.getResultsAsResolveResults();
      } else {
        localProcessor = processor;
      }
    }

    return doOldResolve(containingFile, referencedName, parent, qualifier, ecma, localResolve, parentIsDefinition, index, localProcessor);
  }

  private ResolveResult[] doOldResolve(final PsiFile containingFile, final String referencedName, final PsiElement parent,
                                       final JSExpression qualifier,
                                       final boolean ecma,
                                       final boolean localResolve,
                                       final boolean parentIsDefinition,
                                       final JavaScriptIndex index, ResolveProcessor localProcessor) {
    if (parentIsDefinition &&
        ((ecma && !localResolve) || (!ecma && qualifier != null)) ) {
      return new ResolveResult[] { new JSResolveUtil.MyResolveResult(parent) };
    }

    if (localResolve && parentIsDefinition && ecma) {
      if (!localProcessor.processingEncounteredAbsenceOfTypes()) return localProcessor.getResultsAsResolveResults();

      // Fallback for finding some assignment in global scope
    }

    final WalkUpResolveProcessor processor = new WalkUpResolveProcessor(
      index.getIndexOf(referencedName), null,
      containingFile,
      false,
      this
    );

    if (localProcessor != null) processor.addLocalResults(localProcessor.getResults());

    JavaScriptIndex.getInstance(containingFile.getProject()).processAllSymbols( processor );
    return processor.getResults();
  }

  private boolean isSelfReference(final PsiElement currentParent) {
    return currentParent instanceof JSPackageStatement ||
        currentParent instanceof JSNamespaceDeclaration ||
        currentParent instanceof JSFunction && ((JSFunction )currentParent).findNameIdentifier() == getNode() ||
        currentParent instanceof JSClass;
  }

  private static boolean isLocalResolveQualifier(final JSExpression qualifier) {
    return qualifier == null || qualifier instanceof JSThisExpression || qualifier instanceof JSSuperExpression;
  }


  private static class MyTypeProcessor extends ResolveProcessor implements BaseJSSymbolProcessor.TypeProcessor

  {
    private final boolean myEcma;

    public MyTypeProcessor(String referenceName, final boolean ecma, PsiElement _place) {
      super(referenceName, _place);
      myEcma = ecma;
      setToProcessHierarchy(true);
    }

    enum TypeResolveState {
      Unknown, Resolved, Undefined
    }

    TypeResolveState resolved = TypeResolveState.Unknown;

    public void process(String type,
                        @NotNull final BaseJSSymbolProcessor.EvaluateContext evaluateContext, final PsiElement source) {
      if (evaluateContext.visitedTypes.contains(type)) return;
      evaluateContext.visitedTypes.add(type);

      if ("*".equals(type) || "Object".equals(type)) {
        return;
      }

      PsiElement typeSource = evaluateContext.getSource();
      if (typeSource instanceof JSNamedElementProxy &&
          ((JSNamedElementProxy)typeSource).getType() == JSNamedElementProxy.NamedItemType.Clazz
          ) {
        typeSource = JSResolveUtil.unwrapProxy(typeSource);
      }
      
      setProcessStatics(false);

      final PsiElement placeParent = place.getParent();
      boolean setTypeContext = placeParent instanceof JSReferenceList;
      if (source instanceof JSPackageStatement ||
          ( source instanceof JSNamedElementProxy &&
            ((JSNamedElementProxy)source).getType() == JSNamedElementProxy.NamedItemType.Package
          )
         ) {
        type = (source instanceof JSPackageStatement? ((JSPackageStatement)source).getQualifiedName():((JSNamedElementProxy)source).getQualifiedName()) + "." + getName();
        setTypeContext |= placeParent instanceof JSReferenceExpression;
      } else if (source instanceof JSImportStatement) {
        type += "." + getName();
        setTypeContext = true;
      }

      final PsiElement clazz = source != null && (source instanceof JSClass || source instanceof XmlFile) ? 
                               source:JSClassImpl.findClassFromNamespace(type, evaluateContext.index);

      if (clazz instanceof JSClass) {
        final JSClass jsClass = (JSClass)clazz;

        final boolean statics =
          myEcma && isTheSameClass(typeSource, jsClass) && !(((JSReferenceExpression)place).getQualifier() instanceof JSCallExpression);
        setProcessStatics(statics);
        if (statics) {
          setTypeName(jsClass.getQualifiedName());
        }

        final boolean saveSetTypeContext = isTypeContext();
        final boolean saveToProcessMembers = isToProcessMembers();

        if (setTypeContext) {
          setTypeContext(setTypeContext);
          setToProcessMembers(false);
        }

        try {
          final boolean b = clazz.processDeclarations(this, PsiSubstitutor.EMPTY, clazz, place);
          if (!b) resolved = TypeResolveState.Resolved;
          else if (myEcma) {
            final JSAttributeList attrList = jsClass.getAttributeList();
            if (attrList == null || !attrList.hasModifier(JSAttributeList.ModifierType.DYNAMIC)) resolved = TypeResolveState.Resolved;
          }
        }
        finally {
          if (setTypeContext) {
            setTypeContext(saveSetTypeContext);
            setToProcessMembers(saveToProcessMembers);
          }
        }
      } else if (clazz instanceof XmlFile) {
        final boolean b = JSResolveUtil.processAllGlobals(this, (XmlFile)clazz, place);
        if (!b) resolved = TypeResolveState.Resolved;
      }
      else if (myEcma) {
        resolved = TypeResolveState.Undefined;
        if (source instanceof JSImportStatement) resolved = TypeResolveState.Unknown;
      }
    }

    private static boolean isTheSameClass(final PsiElement typeSource, final JSClass jsClass) {
      if (typeSource == jsClass) return true;
      if (typeSource instanceof JSClass && jsClass != null) {
        final String qName = ((JSClass)typeSource).getQualifiedName();
        return qName != null && qName.equals(jsClass.getQualifiedName());
      }
      return false;
    }

    public boolean ecma() {
      return myEcma;
    }

    public void setUnknownElement(@NotNull final PsiElement element) {
      if (!(element instanceof XmlToken)) resolved = TypeResolveState.Unknown;
    }
  }
}
