package com.intellij.lang.javascript.refactoring.extractMethod;

/**
 * @author ven
 */
public interface JSExtractFunctionSettings {
  String getMethodName();
}