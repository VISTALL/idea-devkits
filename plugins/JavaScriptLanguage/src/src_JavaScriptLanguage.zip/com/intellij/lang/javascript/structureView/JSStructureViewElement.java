/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.structureView;

import com.intellij.ide.structureView.StructureViewTreeElement;
import com.intellij.javascript.documentation.JSDocumentationUtils;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.index.*;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.VariantsProcessor;
import com.intellij.lang.ASTNode;
import com.intellij.navigation.ItemPresentation;
import com.intellij.navigation.NavigationItem;
import com.intellij.openapi.editor.colors.CodeInsightColors;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.util.Iconable;
import com.intellij.pom.Navigatable;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiNamedElement;
import com.intellij.psi.ResolveResult;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.util.ArrayUtil;
import com.intellij.util.Icons;
import com.intellij.util.Processor;
import gnu.trove.TIntHashSet;
import gnu.trove.TIntObjectHashMap;
import gnu.trove.TIntObjectIterator;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.*;

/**
 * @author max
 */
public class JSStructureViewElement implements StructureViewTreeElement {
  private PsiElement myElement;
  private JSNamedElementProxy myProxy;
  private boolean myInherited;

  public JSStructureViewElement(final PsiElement element) {
    this(element, null);
  }

  private JSStructureViewElement(final PsiElement element, JSNamedElementProxy proxy) {
    myElement = element;
    myProxy = proxy;
  }

  public PsiElement getValue() {
    if (myProxy != null) {
      return myProxy;
    }
    return myElement;
  }

  PsiElement getRealElement() {
    return myElement;
  }
  
  public void navigate(boolean requestFocus) {
    ((Navigatable)myElement).navigate(requestFocus);
  }

  public boolean canNavigate() {
    return ((Navigatable)myElement).canNavigate();
  }

  public boolean canNavigateToSource() {
    return canNavigate();
  }

  public StructureViewTreeElement[] getChildren() {
    if (!myElement.isValid() && myProxy != null) {
      if (!myProxy.isValid()) return EMPTY_ARRAY;
      myElement = myProxy.getElement();       // since we use proxies for StructureViewElement then real element may invalidate due to structural change
    }
    
    //assert myElement != null && myElement.isValid();
    final TIntObjectHashMap<PsiElement> offset2Proxy = new TIntObjectHashMap<PsiElement>();
    final TIntObjectHashMap<PsiElement> nameId2NsProxy = new TIntObjectHashMap<PsiElement>();
    final TIntHashSet referencedNamedIds = new TIntHashSet();
    final JavaScriptIndex index = JavaScriptIndex.getInstance(myElement.getProject());

    JSIndexEntry entry = null;
    JSNamespace ns = null;

    if (myProxy != null) {
      entry = myProxy.getEntry();
      ns = myProxy.getNamespace();
      ns = ns != null ? ns.findChildNamespace(myProxy.getNameId()):null;
    } else if (myElement instanceof PsiFile) {
      entry = index.getEntryForFile((PsiFile)myElement);
      ns = entry != null ? entry.getTopLevelNs():null;
    } else if (myElement instanceof VariantsProcessor.MyElementWrapper) {
      entry = index.getEntryForFile(myElement.getContainingFile());
      ns = ((VariantsProcessor.MyElementWrapper)myElement).getNamespace();
    }

    if (entry != null && ns != null) {
      final JSNamespace ns1 = ns;
      final JSIndexEntry entry1 = entry;

      entry.processSymbols(new JavaScriptSymbolProcessor.DefaultSymbolProcessor() {
        final boolean myElementIsFile = myElement instanceof JSFile;
        final boolean shouldFindNsInDepth = ( myElementIsFile && ((JSFile)myElement).getLanguageDialect() != JavaScriptSupportLoader.ECMA_SCRIPT_L4)
                                            || myElement instanceof VariantsProcessor.MyElementWrapper;

        protected boolean process(final PsiElement sym, JSNamespace namespace) {
          int textOffset = sym.getTextOffset();
          String nsName;
          final JSNamedElementProxy.NamedItemType type = ((JSNamedElementProxy)sym).getType();
          
          if (myElementIsFile &&
              (type == JSNamedElementProxy.NamedItemType.MemberFunction ||
               type == JSNamedElementProxy.NamedItemType.MemberVariable)
              ) {
            return true;
          }

          if (( namespace == ns1 || 
                (myElementIsFile && !shouldFindNsInDepth && findNsInParents(namespace, ns1) != null)) &&
              type != JSNamedElementProxy.NamedItemType.Package
             ) {
            if (type == JSNamedElementProxy.NamedItemType.ImplicitVariable) {
              textOffset++; // implicit var will have the same offset as implicit function so modify offset to prevent collision
            }
            offset2Proxy.put(textOffset, sym);
          } else if ((namespace.getParent() == ns1 || (shouldFindNsInDepth && (namespace = findNsInParents(namespace, ns1)) != null)) &&
                     (nsName = index.getStringByIndex(namespace.getNameId())).length() > 0 &&
                     type != JSNamedElementProxy.NamedItemType.Clazz &&
                     nameId2NsProxy.get(namespace.getNameId())  == null
                    ) {
            if (!nsName.equals("window")) {
              nameId2NsProxy.put(namespace.getNameId(), new VariantsProcessor.MyElementWrapper(namespace, entry1.getFile(), textOffset));
            }
          }
          return true;
        }

        private JSNamespace findNsInParents(JSNamespace namespace, final JSNamespace ns1) {
          while(namespace != null) {
            final JSNamespace parentNs = namespace.getParent();
            if (parentNs == ns1) return namespace;
            namespace = parentNs;
          }
          return null;
        }

        public int getRequiredNameId() {
          return -1;
        }

        public PsiFile getBaseFile() {
          return entry1.getFile();
        }
      });
    }

    final TIntObjectHashMap<PsiElement> offset2Element = new TIntObjectHashMap<PsiElement>();

    collectChildrenFromElement(myElement, referencedNamedIds, index, offset2Element);

    TIntObjectIterator<PsiElement> tIntObjectIterator = offset2Proxy.iterator();
    while(tIntObjectIterator.hasNext()) {
      tIntObjectIterator.advance();
      final JSNamedElementProxy elementProxy = (JSNamedElementProxy)tIntObjectIterator.value();
      int nameId = elementProxy.getNameId();
      PsiElement element = null;

      final JSNamedElementProxy.NamedItemType namedItemType = elementProxy.getType();
      if (namedItemType == JSNamedElementProxy.NamedItemType.Definition) {
        element = ((JSDefinitionExpression)elementProxy.getElement()).getExpression();
        final JSExpression jsExpression = JSResolveUtil.findClassIdentifier((JSExpression)element);
        if (element != jsExpression) {
          element = jsExpression;
          nameId = index.getIndexOf(jsExpression.getText());
        }
      } else if (namedItemType == JSNamedElementProxy.NamedItemType.ImplicitFunction ||
                 namedItemType == JSNamedElementProxy.NamedItemType.ImplicitVariable) {
        element = elementProxy;
      } else if(namedItemType == JSNamedElementProxy.NamedItemType.Clazz) {
        if (myElement instanceof JSFile && elementProxy.getElement().getParent() instanceof JSClass) {
          continue;
        }
      }

      if (!referencedNamedIds.contains(nameId)) {
        referencedNamedIds.add(nameId);
        offset2Element.put(tIntObjectIterator.key(), element == null ? elementProxy.getElement():element);
      }
    }

    tIntObjectIterator = nameId2NsProxy.iterator();
    while(tIntObjectIterator.hasNext()) {
      tIntObjectIterator.advance();
      final JSNamedElement e = (JSNamedElement)tIntObjectIterator.value();
      final int nameId = tIntObjectIterator.key();

      if (!referencedNamedIds.contains(nameId)) {
        referencedNamedIds.add(nameId);
        offset2Element.put(e.getTextOffset(), e);
      }
    }

    ArrayList<StructureViewTreeElement> elementsFromSupers = null;

    if (myElement instanceof JSClass) {
      final JSReferenceList extendsList = ((JSClass)myElement).getExtendsList();
      if (extendsList != null) {
        final JSReferenceExpression[] referenceExpressions = extendsList.getExpressions();

        for(JSReferenceExpression referenceExpression:referenceExpressions) {
          for(ResolveResult r: referenceExpression.multiResolve(false)) {
            final PsiElement _element = r.getElement();
            final PsiElement element = _element instanceof JSNamedElementProxy ? ((JSNamedElementProxy)_element).getElement() : _element;
            assert element.isValid();

            final StructureViewTreeElement[] structureViewTreeElements = new JSStructureViewElement(
              element, (JSNamedElementProxy)(element != _element ? _element:null)
            ).getChildren();

            if (elementsFromSupers == null) {
              elementsFromSupers = new ArrayList<StructureViewTreeElement>(structureViewTreeElements.length);
            }
            else {
              elementsFromSupers.ensureCapacity(elementsFromSupers.size() + structureViewTreeElements.length);
            }

            for(StructureViewTreeElement e:structureViewTreeElements) {
              if (!isVisible((PsiElement)e.getValue(), myElement)) continue;
              ((JSStructureViewElement)e).setInherited(true);
              elementsFromSupers.add(e);
            }
          }
        }
      }
    } else if ((myElement instanceof JSNamedElement || myElement instanceof JSReferenceExpression) && entry != null) {
      final Set<String> visitedTypes = new HashSet<String>();
      final ArrayList<StructureViewTreeElement> elements = new ArrayList<StructureViewTreeElement>();

      final MyProcessor processor = new MyProcessor(index, visitedTypes) {
        public boolean acceptsFile(final PsiFile file) {
          return file.getVirtualFile() != null && super.acceptsFile(file);
        }

        protected boolean process(final PsiElement namedElement, final JSNamespace namespace) {
          final JSNamedElementProxy elementProxy = (JSNamedElementProxy)namedElement;
          if (referencedNamedIds.contains(elementProxy.getNameId()) ||
              !isVisible(namedElement, myElement)
             ) {
            return true;
          }
          referencedNamedIds.add(elementProxy.getNameId());
          final JSStructureViewElement jsStructureViewElement = new JSStructureViewElement(
            elementProxy.getElement(), elementProxy);
          elements.add(jsStructureViewElement);
          jsStructureViewElement.setInherited(true);

          return true;
        }
      };
      
      String typeName = myElement instanceof JSNamedElement ? ((JSNamedElement)myElement).getName():myElement.getText();
      if (myElement instanceof JSFunction) {
        ASTNode node = ((JSFunction)myElement).findNameIdentifier();
        if (node != null && node.getPsi() != null && node.getPsi().getParent() instanceof JSReferenceExpression) {
          typeName =  node.getPsi().getParent().getText();
        }
      } else if (myElement instanceof VariantsProcessor.MyElementWrapper) {
        final JSNamespace namespace = ((VariantsProcessor.MyElementWrapper)myElement).getNamespace();
        typeName = namespace != null ?  namespace.getQualifiedName(index):typeName;
      }

      boolean doIterateTypes = true;
      if (myProxy != null) {
        if ("Object".equals(myProxy.getNamespace().getQualifiedName(index))) doIterateTypes = false;
      }

      if (doIterateTypes) {
        JSTypeEvaluateManager.getInstance(entry.getFile().getProject()).iterateTypeHierarchy(typeName, processor);
      }
      elementsFromSupers = elements;
    }

    final StructureViewTreeElement[] children = new StructureViewTreeElement[offset2Element.size()];
    tIntObjectIterator = offset2Element.iterator();
    for (int i = 0; i < children.length; i++) {
      tIntObjectIterator.advance();
      final PsiElement element = tIntObjectIterator.value();
      final int textOffset = tIntObjectIterator.key();
      final PsiElement psiElement = offset2Proxy.get(textOffset);
      children[i] = new JSStructureViewElement(element, psiElement instanceof JSNamedElementProxy ? (JSNamedElementProxy)psiElement:null);
    }

    Arrays.sort(children, new Comparator<StructureViewTreeElement>() {
      public int compare(final StructureViewTreeElement _o1, final StructureViewTreeElement _o2) {
        JSStructureViewElement o1 = (JSStructureViewElement)_o1;
        JSStructureViewElement o2 = (JSStructureViewElement)_o2;
        PsiElement e = o1.myProxy != null ? o1.myProxy:o1.myElement;
        PsiElement e2 = o2.myProxy != null ? o2.myProxy:o2.myElement;
        return e.getTextOffset() - e2.getTextOffset();
      }
    });

    if (elementsFromSupers != null) {
      return ArrayUtil.mergeArrays(children, elementsFromSupers.toArray(new StructureViewTreeElement[elementsFromSupers.size()]), StructureViewTreeElement.class);
    }
    return children;
  }

  private static boolean isVisible(PsiElement namedElement, final PsiElement element) {
    if (namedElement instanceof JSNamedElementProxy) {
      namedElement = ((JSNamedElementProxy)namedElement).getElement();
    }
    if (namedElement instanceof JSAttributeListOwner) {
      final JSAttributeListOwner attributeListOwner = (JSAttributeListOwner)namedElement;
      final JSAttributeList attributeList = attributeListOwner.getAttributeList();

      if (attributeList != null) {
        final JSAttributeList.AccessType type = attributeList.getAccessType();

        if (type == JSAttributeList.AccessType.PACKAGE_LOCAL) {
          final JSPackageStatement packageStatement = PsiTreeUtil.getParentOfType(namedElement, JSPackageStatement.class);
          final JSPackageStatement packageStatement2 = PsiTreeUtil.getParentOfType(element, JSPackageStatement.class);
          String packageQName;

          return packageStatement == packageStatement2 ||
                 ( packageStatement != null &&
                   packageStatement2 != null &&
                   (packageQName = packageStatement.getQualifiedName()) != null &&
                   packageQName.equals(packageStatement2.getQualifiedName()));
        }
        return type != JSAttributeList.AccessType.PRIVATE;
      }
    }
    return true;
  }

  private static void collectChildrenFromElement(final PsiElement element, final TIntHashSet referencedNamedIds, final JavaScriptIndex index,
                                                 final TIntObjectHashMap<PsiElement> offset2Element) {
    element.acceptChildren(new JSElementVisitor() {
      public void visitElement(PsiElement element) {
        if (element instanceof JSNamedElement &&
            ((JSNamedElement)element).getName() != null &&
            !(element instanceof JSDefinitionExpression) &&
            !(element instanceof JSLabeledStatement) &&
            !(element instanceof JSPackageStatement) &&
            !(element instanceof JSImportStatement)) {
          if (!(element instanceof JSFunction) || !(element.getParent() instanceof JSProperty)) {
            addElement(element);
          } else {
            element.acceptChildren(this);
          }
        }
        else {
          element.acceptChildren(this);
        }
      }

      public void visitJSParameter(final JSParameter node) {
        // Do not add parameters to structure view
      }

      public void visitJSObjectLiteralExpression(final JSObjectLiteralExpression node) {
        final PsiElement parent = node.getParent();
        if (parent instanceof JSVariable ||
            parent instanceof JSProperty ||
            parent instanceof JSFile ||
            parent instanceof JSReturnStatement ||
            parent instanceof JSAssignmentExpression) {
          node.acceptChildren(this);
          return;
        }
        if (parent instanceof JSArgumentList) {
          final JSExpression expression = JSSymbolUtil.findQualifyingExpressionFromArgumentList((JSArgumentList)parent);
          if (expression != null) {
            return;
          }
        }
        if (node.getProperties().length > 0) addElement(node);
      }

      @Override
      public void visitJSVariable(final JSVariable node) {
        if (element instanceof JSFunction) return;
        super.visitJSVariable(node);
      }

      public void visitJSAssignmentExpression(final JSAssignmentExpression node) {
        JSExpression rOperand = node.getROperand();
        final JSExpression lOperand = node.getLOperand();

        final boolean outsideFunction = PsiTreeUtil.getParentOfType(node, JSFunction.class) == null;
        if (!outsideFunction) return;

        if (rOperand instanceof JSCallExpression) {
          rOperand = ((JSCallExpression)rOperand).getMethodExpression();
        }

        if (rOperand instanceof JSFunction) {
          JSExpression qualifier = null;
          final JSExpression operand = ((JSDefinitionExpression)lOperand).getExpression();

          if (operand instanceof JSReferenceExpression) {
            qualifier = ((JSReferenceExpression)operand).getQualifier();
          }
          if ((qualifier == null || qualifier instanceof JSThisExpression)) {
            addElement(rOperand);
          }
        }
        else {
          final JSExpression operand = ((JSDefinitionExpression)lOperand).getExpression();
          if (operand instanceof JSReferenceExpression && ((JSReferenceExpression)operand).getQualifier() instanceof JSThisExpression) {
            final PsiElement resolved = ((JSReferenceExpression)operand).resolve();
            if (resolved == lOperand) addElement(lOperand);
          }
          //super.visitJSAssignmentExpression(node);
        }
      }

      private void addElement(final PsiElement lOperand) {
        if (lOperand instanceof JSNamedElement) {
          final int namedId = index.getIndexOf(((JSNamedElement)lOperand).getName());
          if (referencedNamedIds.contains(namedId)) return;
          referencedNamedIds.add(namedId);
        }
        offset2Element.put(lOperand.getTextOffset(), lOperand);
      }
    });
  }

  public ItemPresentation getPresentation() {
    if (myElement instanceof JSExpressionStatement && myProxy != null) {
      return new JSStructureItemPresentationBase() {
        final ItemPresentation originalPresentation = ((NavigationItem)myProxy).getPresentation();

        public String getPresentableText() {
          return originalPresentation.getPresentableText();
        }

        @Nullable
        public Icon getIcon(final boolean open) {
          return myProxy.getIcon(0);
        }
      };
    }
    return new JSStructureItemPresentation();
 }

  public boolean isInherited() {
    return myInherited;
  }

  private void setInherited(boolean b) {
    myInherited = b;
  }

  private abstract static class MyProcessor extends JavaScriptSymbolProcessor.DefaultSymbolProcessor implements JSTypeEvaluateManager.NamespaceProcessor {
    private final JavaScriptIndex myIndex;
    private final Set<String> myVisitedTypes;

    public MyProcessor(final JavaScriptIndex index, final Set<String> visitedTypes) {
      myIndex = index;
      myVisitedTypes = visitedTypes;
    }

    public boolean process(final JSNamespace jsNamespace) {
      final String qName = jsNamespace.getQualifiedName(myIndex);
      if (!myVisitedTypes.contains(qName) && qName.length() > 0) {
        myVisitedTypes.add(qName);
        jsNamespace.getPackage().processDeclarations(this);
      }
      return true;
    }

    public PsiFile getBaseFile() {
      return null;
    }

    public int getRequiredNameId() {
      return -1;
    }
  }

  private abstract class JSStructureItemPresentationBase implements ItemPresentation {
    public TextAttributesKey getTextAttributesKey() {
      if (myInherited) return CodeInsightColors.NOT_USED_ELEMENT_ATTRIBUTES;
      if (myProxy != null && myProxy.isDeprecated()) return CodeInsightColors.DEPRECATED_ATTRIBUTES;
      return null;
    }

    public String getLocationString() {
      return null;
    }
  }

  private class JSStructureItemPresentation extends JSStructureItemPresentationBase {
    public String getPresentableText() {
      if (!myElement.isValid() && myProxy != null) {
        if (!myProxy.isValid()) return "*invalid*";
        myElement = myProxy.getElement();
      }

      PsiElement element = myElement;
      if (element instanceof JSObjectLiteralExpression) {
        if (element.getParent() instanceof JSAssignmentExpression) {
          final JSExpression expression =
           ((JSDefinitionExpression)((JSAssignmentExpression)element.getParent()).getLOperand()).getExpression();
         return JSResolveUtil.findClassIdentifier(expression).getText();
       }
       else {
         return JSBundle.message("javascript.language.term.prototype");
       }
     }

     if (element instanceof JSDefinitionExpression) {
       element = ((JSDefinitionExpression)element).getExpression();
     }

     if (element instanceof JSReferenceExpression) {
       JSReferenceExpression expression = (JSReferenceExpression)element;

       if (myProxy != null && myProxy.getType() == JSNamedElementProxy.NamedItemType.Namespace) {
         final JSExpression jsExpression = expression.getQualifier();
         if (jsExpression instanceof JSReferenceExpression) {

           expression = (JSReferenceExpression)jsExpression;
         }
       }

       String s = expression.getReferencedName();

       if (JSResolveUtil.PROTOTYPE.equals(s)) {
         final JSExpression jsExpression = expression.getQualifier();
         if (jsExpression instanceof JSReferenceExpression) {
           s = ((JSReferenceExpression)jsExpression).getReferencedName();
         }
       }
       return s;
     }

     if (!(element instanceof PsiNamedElement)) {
       return element.getText();
     }

     String name = ((PsiNamedElement)element).getName();

     if (element instanceof JSProperty) {
       element = ((JSProperty)element).getValue();
     }

     if (element instanceof JSFunction) {
       if (name == null) name="<anonymous>";
       name+="(";
       JSParameterList parameterList = ((JSFunction)element).getParameterList();
       if (parameterList != null) {
         for(JSParameter p:parameterList.getParameters()) {
           if (!name.endsWith("(")) name += ", ";
           name+=p.getName();
           final String variableType = JSDocumentationUtils.findAnyVariableType(p);
           if (variableType != null) name+=":"+variableType;
         }
       }
       name+=")";

       final String type = JSDocumentationUtils.findReturnType((JSFunction)element);
       if (type != null) {
         name += ":"+type;
       }
     }

     if (name == null && element.getParent() instanceof JSAssignmentExpression) {
       JSExpression lOperand = ((JSDefinitionExpression)((JSAssignmentExpression)element.getParent()).getLOperand()).getExpression();
       lOperand = JSResolveUtil.findClassIdentifier(lOperand);
       if (lOperand instanceof JSReferenceExpression) {
         return ((JSReferenceExpression) lOperand).getReferencedName();
       }
       return lOperand.getText();
     }
     return name;
   }

    public Icon getIcon(boolean open) {
      if (myElement instanceof JSProperty) {
        final JSExpression expression = ((JSProperty)myElement).getValue();
        if (expression instanceof JSObjectLiteralExpression) return Icons.CLASS_ICON;
        if (expression instanceof JSFunction) return Icons.METHOD_ICON;
        return Icons.VARIABLE_ICON;
      }
      if (myElement instanceof JSReferenceExpression) {
        return Icons.VARIABLE_ICON;
      }
      if (myProxy != null) return myProxy.getIcon(Iconable.ICON_FLAG_OPEN);
      return myElement.getIcon(Iconable.ICON_FLAG_OPEN);
    }
  }
}
