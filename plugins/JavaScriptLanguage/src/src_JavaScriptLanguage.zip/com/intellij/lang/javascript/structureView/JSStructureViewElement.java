/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.structureView;

import com.intellij.ide.structureView.StructureViewTreeElement;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.psi.*;
import com.intellij.navigation.ItemPresentation;
import com.intellij.navigation.NavigationItem;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.util.Iconable;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiNamedElement;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.util.Icons;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Feb 10, 2005
 * Time: 3:26:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSStructureViewElement implements StructureViewTreeElement<JSElement> {
  private JSElement myParent;
  private JSElement myElement;

  public JSStructureViewElement(final JSElement element) {
    this(null,element);
  }

  public JSStructureViewElement(final JSElement parent, final JSElement element) {
    myParent = parent;
    myElement = element;
  }

  public JSElement getValue() {
    return myElement;
  }

  public void navigate(boolean requestFocus) {
    ((NavigationItem)myElement).navigate(requestFocus);
  }

  public boolean canNavigate() {
    return ((NavigationItem)myElement).canNavigate();
  }

  public boolean canNavigateToSource() {
    return ((NavigationItem)myElement).canNavigateToSource();
  }

  public StructureViewTreeElement[] getChildren() {
    final List<JSElement> childrenElements = new ArrayList<JSElement>();

    if (myElement instanceof JSReferenceExpression) {
      return getGroupChildren();
    }

    final Map<String,JSElement> groupElements = new HashMap<String, JSElement>();

    myElement.acceptChildren(new JSElementVisitor() {
      public void visitElement(PsiElement element) {
        if (element instanceof JSNamedElement &&
            ((JSNamedElement)element).getName() != null &&
            !(element instanceof JSDefinitionExpression) &&
            !(element instanceof JSLabeledStatement)
           ) {
          if (!(element instanceof JSFunction) || !(element.getParent() instanceof JSProperty)) {
            childrenElements.add((JSElement)element);
          }
        }
        else {
          element.acceptChildren(this);
        }
      }

      public void visitJSVariable(final JSVariable node) {
        // Do not add local variables to structure view.
        if (PsiTreeUtil.getParentOfType(node, JSFunction.class) == null) {
          super.visitJSVariable(node);
        }
      }

      public void visitJSParameter(final JSParameter node) {
        // Do not add parameters to structure view
      }

      public void visitJSObjectLiteralExpression(final JSObjectLiteralExpression node) {
        if(node.getParent() instanceof JSVariable) {
          node.acceptChildren(this);
          return;
        }
        if (node.getProperties().length > 0) childrenElements.add(node);
      }

      public void visitJSAssignmentExpression(final JSAssignmentExpression node) {
        if (node.getROperand() instanceof JSFunction) {
          JSExpression qualifier = null;
          final JSExpression lOperand = ((JSDefinitionExpression)node.getLOperand()).getExpression();

          if (lOperand instanceof JSReferenceExpression) {
            qualifier = ((JSReferenceExpression) lOperand).getQualifier();
          }
          if (qualifier != null && !(qualifier instanceof JSThisExpression)) {
            String qualifierText = qualifier.getText();
            if (!groupElements.containsKey(qualifierText)) {
              childrenElements.add(qualifier);
              groupElements.put(qualifierText, qualifier);
            }
          }
          else {
            childrenElements.add(node.getROperand());
          }
        } else {
          final JSExpression lOperand = ((JSDefinitionExpression)node.getLOperand()).getExpression();
          if (lOperand instanceof JSReferenceExpression && ((JSReferenceExpression) lOperand).getQualifier() instanceof JSThisExpression) {
            childrenElements.add(node.getLOperand());
          }
          super.visitJSAssignmentExpression(node);
        }
      }
    });

    return psiToStructureView(childrenElements);
  }

  private StructureViewTreeElement[] psiToStructureView(final List<JSElement> childrenElements) {
    StructureViewTreeElement[] children = new StructureViewTreeElement[childrenElements.size()];
    for (int i = 0; i < children.length; i++) {
      children[i] = new JSStructureViewElement(myElement, childrenElements.get(i));
    }

    return children;
  }

  private StructureViewTreeElement[] getGroupChildren() {
    final List<JSElement> childrenElements = new ArrayList<JSElement>();

    myParent.accept(new JSElementVisitor() {
      public void visitElement(PsiElement element) {
        element.acceptChildren(this);
      }

      public void visitJSAssignmentExpression(final JSAssignmentExpression node) {
        if (node.getROperand() instanceof JSFunction) {
          JSExpression qualifier = null;
          JSExpression lOperand = ((JSDefinitionExpression)node.getLOperand()).getExpression();

          if (lOperand instanceof JSReferenceExpression) {
            qualifier = ((JSReferenceExpression) lOperand).getQualifier();
          }
          if (qualifier != null && qualifier.getText().equals(myElement.getText())) {
            childrenElements.add(node.getROperand());
          }
        }
      }
    });

    return psiToStructureView(childrenElements);
  }

  public ItemPresentation getPresentation() {
   return new ItemPresentation() {
     public String getPresentableText() {
       if (myElement instanceof JSObjectLiteralExpression) {
         if (myElement.getParent() instanceof JSAssignmentExpression) {
           return ((JSAssignmentExpression)myElement.getParent()).getLOperand().getText();
         }
         else {
           return JSBundle.message("javascript.language.term.prototype");
         }
       }
       if (!(myElement instanceof PsiNamedElement)) {
         return myElement.getText();
       }

       String name = ((PsiNamedElement)myElement).getName();

       if (myElement instanceof JSFunction) {
         if (name == null) name="<anonymous>";
         name+="(";
         JSParameterList parameterList = ((JSFunction)myElement).getParameterList();
         if (parameterList != null) {
           for(JSParameter p:parameterList.getParameters()) {
             if (!name.endsWith("(")) name += ",";
             name+=p.getName();
           }
         }
         name+=")";
       }

       if (name == null && myElement.getParent() instanceof JSAssignmentExpression) {
         final JSExpression lOperand = ((JSDefinitionExpression)((JSAssignmentExpression)myElement.getParent()).getLOperand()).getExpression();
         if (lOperand instanceof JSReferenceExpression) {
           return ((JSReferenceExpression) lOperand).getReferencedName();
         }
         return lOperand.getText();
       }
       return name;
     }

     public TextAttributesKey getTextAttributesKey() {
       return null;
     }

     public String getLocationString() {
       return null;
     }

     public Icon getIcon(boolean open) {
       if (myElement instanceof JSReferenceExpression) {
         return Icons.CLASS_ICON;
       }
       return myElement.getIcon(Iconable.ICON_FLAG_OPEN);
     }
   };
 }
}
