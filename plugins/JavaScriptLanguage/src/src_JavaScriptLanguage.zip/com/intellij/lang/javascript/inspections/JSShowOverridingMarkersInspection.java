/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript.inspections;

import com.intellij.codeInspection.ProblemHighlightType;
import com.intellij.codeInspection.ProblemsHolder;
import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.ResolveProcessor;
import com.intellij.navigation.NavigationItem;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.editor.markup.GutterIconRenderer;
import com.intellij.openapi.editor.markup.HighlighterTargetArea;
import com.intellij.openapi.editor.markup.RangeHighlighter;
import com.intellij.openapi.fileEditor.FileEditor;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.fileEditor.TextEditor;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import gnu.trove.THashMap;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.Iterator;
import java.util.Map;

/**
 * @by Maxim.Mossienko
 */
public class JSShowOverridingMarkersInspection extends JSInspection {
  @NonNls private static final String SHORT_NAME = "JSShowOverridingMarkers";
  private static Key<Map<String, RangeHighlighter>> ourGutterMarkersKey = Key.create("gutter.markers.key");
  @NonNls private static final String OVERRIDES_METHOD_IN = "overrides method in ";

  @NotNull
  public String getGroupDisplayName() {
    return JSBundle.message("js.inspection.group.name");
  }

  @NotNull
  public String getDisplayName() {
    return JSBundle.message("js.show.overriding.markers.inspection.name");
  }

  @NotNull
  @NonNls
  public String getShortName() {
    return SHORT_NAME;
  }

  protected BasePsiElementVisitor createVisitor(final ProblemsHolder holder) {
    return new BasePsiElementVisitor() {
      public void visitJSFunctionDeclaration(final JSFunction node) {
        final String qName = JSResolveUtil.getQNameToStartHierarchySearch(node);

        if (qName != null) {
          PsiElement parentNode = JSResolveUtil.getClassReferenceForXmlFromContext(node.getParent());
          final MyOverrideHandler overrideHandler = new MyOverrideHandler(node, holder);
          JSResolveUtil.iterateType(
            node,
            parentNode,
            ((JSClass)parentNode).getQualifiedName(), overrideHandler
          );

          if (!overrideHandler.foundOverride && !ApplicationManager.getApplication().isUnitTestMode()) {
            requestRemovalOfOverrideIfAny(node);
          }
        }
      }

      public void visitJSFunctionExpression(final JSFunctionExpression node) {
        final String qName = JSResolveUtil.getQNameToStartHierarchySearch(node.getFunction());

        if (qName != null) {
          final MyOverrideHandler overrideHandler = new MyOverrideHandler(node.getFunction(), holder);
          JSResolveUtil.iterateType(node.getFunction(), node.getContainingFile(), qName, overrideHandler);
          if (!overrideHandler.foundOverride && !ApplicationManager.getApplication().isUnitTestMode()) {
            requestRemovalOfOverrideIfAny(node.getFunction());
          }
        }
      }
    };
  }

  static class MyOverrideHandler implements JSResolveUtil.OverrideHandler {
    final JSFunction node;
    final ProblemsHolder holder;
    boolean foundOverride = false;

    public MyOverrideHandler(final JSFunction node, final ProblemsHolder holder) {
      this.holder = holder;
      this.node = node;
    }

    public void process(final ResolveProcessor processor, final PsiElement scope, final String className, final String overrideKey) {
      foundOverride = true;
      final JSElement navigateTo = processor.getResult();
      final String message = OVERRIDES_METHOD_IN + className;

      if (ApplicationManager.getApplication().isUnitTestMode()) {
        holder.registerProblem(node.findNameIdentifier().getPsi(), message, ProblemHighlightType.GENERIC_ERROR_OR_WARNING);
      } else {
        requestToAddGutterMarker(navigateTo, node, scope, message, overrideKey);
      }
    }
  }

  private static void requestToAddGutterMarker(final JSElement navigateTo, final JSFunction node, final PsiElement scope, final String message,
                                        final String overrideKey) {
    ApplicationManager.getApplication().invokeLater(new Runnable() {
      public void run() {
        if (!node.isValid() || !navigateTo.isValid()) return;

        int injectedOffset = 0;
        PsiFile containingFile = node.getContainingFile();
        if (containingFile.getContext() != null) {
          final PsiElement context = containingFile.getContext();
          injectedOffset = context.getTextOffset();
          containingFile = context.getContainingFile();
        }
        Editor editor = findEditor(containingFile);

        if (editor != null) {
          Map<String, RangeHighlighter> ourMarkers = containingFile.getUserData(ourGutterMarkersKey);

          if (ourMarkers == null) {
            ourMarkers = new THashMap<String, RangeHighlighter>();
            containingFile.putUserData(ourGutterMarkersKey, ourMarkers);
          }

          final ASTNode nameIdentifier = node.findNameIdentifier();
          if (nameIdentifier == null) return;
          final int offset = nameIdentifier.getStartOffset() + injectedOffset;
          final RangeHighlighter value = addOverridingMarker(editor, offset, offset + nameIdentifier.getTextLength(), navigateTo, message);
          
          RangeHighlighter rangeHighlighter = ourMarkers.get(overrideKey);
          if (rangeHighlighter == null) {
            for(Iterator<RangeHighlighter> rIterator = ourMarkers.values().iterator();rIterator.hasNext();) {
              final RangeHighlighter r = rIterator.next();

              if (r != value && r.getStartOffset() == value.getStartOffset()) {
                rangeHighlighter = r;
                rIterator.remove();
                break;
              }
            }
          }

          if (rangeHighlighter != null && ((MyGutterIconRenderer)rangeHighlighter.getGutterIconRenderer()).myEditor == editor) {
            editor.getMarkupModel().removeHighlighter(rangeHighlighter);
          }
          ourMarkers.put(overrideKey, value);
        }
      }
    });
  }

  private static void requestRemovalOfOverrideIfAny(final JSFunction node) {
    final ASTNode nameIdentifier = node.findNameIdentifier();
    if (nameIdentifier == null) return;

    ApplicationManager.getApplication().invokeLater(new Runnable() {
      public void run() {
        if (!node.isValid()) return;
        final int offset = nameIdentifier.getStartOffset();
        PsiFile containingFile = node.getContainingFile();
        Editor editor = findEditor(containingFile);

        if (editor != null) {
          Map<String, RangeHighlighter> ourMarkers = containingFile.getUserData(ourGutterMarkersKey);

          if (ourMarkers != null) {
            for(Iterator<RangeHighlighter> highlighterIterator = ourMarkers.values().iterator();highlighterIterator.hasNext();) {
              RangeHighlighter highlighter = highlighterIterator.next();

              if (highlighter.getStartOffset() == offset) {
                editor.getMarkupModel().removeHighlighter(highlighter);
                highlighterIterator.remove();
              }
            }
          }
        }
      }

    });
  }

  private static Editor findEditor(final PsiFile containingFile) {
    final Project project = containingFile.getProject();
    if (project.isDisposed()) return null;
    final FileEditor[] editors =
      FileEditorManager.getInstance(project).getEditors(containingFile.getVirtualFile());
    Editor editor = null;
    for(FileEditor fe:editors) {
      if (fe instanceof TextEditor) {
        editor = ((TextEditor)fe).getEditor();
        break;
      }
    }
    return editor;
  }

  private static RangeHighlighter addOverridingMarker(final Editor editor, final int offset, final int endOffset, final JSElement result,
                                                      final String title) {
    final RangeHighlighter rangeHighlighter = editor.getMarkupModel()
      .addRangeHighlighter(offset, endOffset, 100, null, HighlighterTargetArea.EXACT_RANGE);
    rangeHighlighter.setGutterIconRenderer(new MyGutterIconRenderer(title, result, editor));
    return rangeHighlighter;
  }

  private static class MyGutterIconRenderer extends GutterIconRenderer {
    private final String myTitle;
    private final Editor myEditor;
    private final JSElement myResult;

    public MyGutterIconRenderer(final String title, final JSElement result, final Editor editor) {
      myTitle = title;
      myResult = result;
      myEditor = editor;
    }

    @NotNull
      public Icon getIcon() {
      return IconLoader.getIcon("/gutter/overridingMethod.png");
    }

    public boolean isNavigateAction() {
      return true;
    }

    @Nullable
      public String getTooltipText() {
      return myTitle;
    }

    @Nullable public AnAction getClickAction() {
      return new AnAction() {
        public void actionPerformed(final AnActionEvent e) {
          ((NavigationItem)myResult).navigate(true);
        }
      };
    }
  }
}