/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi.impl;

import com.intellij.extapi.psi.ASTWrapperPsiElement;
import com.intellij.lang.ASTNode;
import com.intellij.lang.Language;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.index.JSItemPresentation;
import com.intellij.lang.javascript.psi.*;
import com.intellij.navigation.ItemPresentation;
import com.intellij.psi.*;
import com.intellij.psi.search.LocalSearchScope;
import com.intellij.psi.search.SearchScope;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 30, 2005
 * Time: 8:23:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSElementImpl extends ASTWrapperPsiElement implements JSElement {
  @NonNls private static final String IMPL = "Impl";

  public JSElementImpl(final ASTNode node) {
    super(node);
  }

  @NotNull
  public Language getLanguage() {
    return JavaScriptSupportLoader.JAVASCRIPT.getLanguage();
  }

  public void accept(PsiElementVisitor visitor) {
    if (visitor instanceof JSElementVisitor) {
      ((JSElementVisitor)visitor).visitJSElement(this);
    }
    else {
      super.accept(visitor);
    }
  }

  @NotNull
  public SearchScope getUseScope() {
    //This is true as long as we have no inter-file references
    final PsiFile containingFile = getContainingFile();

    if (!(containingFile instanceof JSFile)) return new LocalSearchScope(containingFile);
    return super.getUseScope();
  }

  public String toString() {
    String classname = getClass().getName();
    if (classname.endsWith(IMPL)) {
      classname = classname.substring(0, classname.length() - IMPL.length());
    }

    classname = classname.substring(classname.lastIndexOf(".") + 1);
    return classname;
  }


  public ItemPresentation getPresentation() {
    if (this instanceof JSNamedElement) return new JSItemPresentation((JSNamedElement)this,null);
    return null;
  }

  public PsiElement addBefore(@NotNull PsiElement element, PsiElement anchor) throws IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(element)) {
      if (JSChangeUtil.isStatementContainer(this)) {
        return JSChangeUtil.doAddBefore(this, element, anchor);
      }
      else if (JSChangeUtil.isBlockStatementContainer(this) && anchor != null) {
        return JSChangeUtil.blockDoAddBefore(element, anchor);
      }
    }

    return super.addBefore(element, anchor);
  }

  public PsiElement addAfter(@NotNull PsiElement element, PsiElement anchor) throws IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(element)) {
      if (JSChangeUtil.isStatementContainer(this)) {
        return JSChangeUtil.doAddAfter(this, element, anchor);
      }
      else if (JSChangeUtil.isBlockStatementContainer(this) && anchor != null) {
        return JSChangeUtil.blockDoAddAfter(element, anchor);
      }
    }
    return super.addAfter(element, anchor);
  }

  public PsiElement addRangeBefore(@NotNull PsiElement first, @NotNull PsiElement last, PsiElement anchor) throws
                                                                                                           IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(first)) {
      if (JSChangeUtil.isStatementContainer(this)) {
        return JSChangeUtil.doAddRangeBefore(this, first, last, anchor);
      }
      else if (JSChangeUtil.isBlockStatementContainer(this) && anchor != null) {
        return JSChangeUtil.blockDoAddRangeBefore(first, last, anchor);
      }
    }
    return super.addRangeBefore(first, last, anchor);
  }

  public PsiElement addRangeAfter(PsiElement first, PsiElement last, PsiElement anchor) throws IncorrectOperationException {
    if (JSChangeUtil.isStatementOrComment(first)) {
      if (JSChangeUtil.isStatementContainer(this)) {
        return JSChangeUtil.doAddRangeAfter(this, first, last, anchor);
      }
      else if (JSChangeUtil.isBlockStatementContainer(this) && anchor != null) {
        return JSChangeUtil.blockDoAddRangeAfter(first, last, anchor);
      }
    }

    return super.addRangeAfter(first, last, anchor);
  }

  public PsiElement add(@NotNull PsiElement element) throws IncorrectOperationException {
    return addAfter(element, null);
  }

  public PsiElement addRange(PsiElement first, PsiElement last) throws IncorrectOperationException {
    return addRangeAfter(first, last, null);
  }

  public PsiElement replace(@NotNull PsiElement newElement) throws IncorrectOperationException {
    final ASTNode myNode = getNode();
    final ASTNode result = newElement.getNode().copyElement();
    myNode.getTreeParent().replaceChild(myNode, result);
    return result.getPsi();
  }
}
