package com.intellij.lang.javascript.flex;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSLanguageDialect;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.index.*;
import com.intellij.lang.javascript.psi.JSAttributeList;
import com.intellij.lang.javascript.psi.JSClass;
import com.intellij.lang.javascript.psi.JSFile;
import com.intellij.lang.javascript.psi.JSReferenceList;
import com.intellij.lang.javascript.psi.impl.JSChangeUtil;
import com.intellij.lang.javascript.psi.impl.JSClassBase;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.ResolveProcessor;
import com.intellij.lang.javascript.psi.resolve.WalkUpResolveProcessor;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.UserDataCache;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiSubstitutor;
import com.intellij.psi.impl.EquivalenceAware;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.psi.search.PsiElementProcessor;
import com.intellij.psi.util.CachedValue;
import com.intellij.psi.util.CachedValueProvider;
import com.intellij.psi.xml.*;
import com.intellij.util.IncorrectOperationException;
import com.intellij.xml.XmlElementDescriptor;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Maxim.Mossienko
 */
public class XmlBackedJSClassImpl extends JSClassBase implements JSClass, EquivalenceAware {
  private volatile JSReferenceList myExtendsList;
  private volatile JSReferenceList myImplementsList;

  public XmlBackedJSClassImpl(XmlFile file) {
    super(file.getNode());
  }

  @Nullable
  public JSReferenceList getExtendsList() {
    JSReferenceList refList = myExtendsList;
    if (refList == null) {
      final XmlTag rootTag = getRootTag();
      final XmlElementDescriptor descriptor = rootTag != null ? rootTag.getDescriptor():null;
      final PsiElement element = descriptor != null ? descriptor.getDeclaration():null;
      final String s = element instanceof JSNamedElementProxy ? ((JSNamedElementProxy)element).getQualifiedName():
        element instanceof JSClass ? ((JSClass)element).getQualifiedName() : "";
      myExtendsList = refList = createReferenceList(s);
    }
    return refList;
  }

  private JSReferenceList createReferenceList(final String s) {
    final JSClass element =
      (JSClass)JSChangeUtil.createJSTreeFromText(getProject(), "class C extends " + s + " {}", (JSLanguageDialect)JavaScriptSupportLoader.ECMA_SCRIPT_L4).getPsi();
    return element.getExtendsList();
  }

  @Nullable
  public JSReferenceList getImplementsList() {
    JSReferenceList refList = myImplementsList;

    if (refList == null) {
      final XmlTag rootTag = getRootTag();
      myImplementsList = refList = createReferenceList(rootTag != null ? rootTag.getAttributeValue("implements"): null);
    }
    return refList;
  }

  private XmlTag getRootTag() {
    final XmlFile file = (XmlFile)getNode().getPsi();
    final XmlDocument document = file.getDocument();
    final XmlTag rootTag = document != null ? document.getRootTag():null;
    return rootTag;
  }

  @Override
  public String getName() {
    final XmlFile psi = (XmlFile)getNode().getPsi();
    VirtualFile file = psi.getVirtualFile();
    if (file == null && psi.getOriginalFile() != null) {
      file = psi.getOriginalFile().getVirtualFile();
    }
    return file != null ? file.getNameWithoutExtension():null;
  }

  public String getQualifiedName() {
    final String name = getName();
    if (name == null) return null;
    final PsiFile containingFile = getNode().getPsi().getContainingFile();
    final String expectedPackageNameFromFile =
      JSResolveUtil.getExpectedPackageNameFromFile(containingFile.getVirtualFile(), containingFile.getProject(), true);
    if (expectedPackageNameFromFile != null && expectedPackageNameFromFile.length() > 0) return expectedPackageNameFromFile + "." + name;

    return name;
  }

  public boolean isInterface() {
    return false;
  }

  @Nullable
  public ASTNode findNameIdentifier() {
    final XmlFile xmlFile = (XmlFile)getParent();
    return xmlFile.getDocument().getRootTag().getNode();
  }

  public PsiElement setName(@NonNls @NotNull String name) throws IncorrectOperationException {
    final int i = name.lastIndexOf('.');
    if (i != -1) name = name.substring(0, i);
    updateFileName(name, getName());
    return null;
  }

  @Nullable
  public JSAttributeList getAttributeList() {
    return null;
  }

  protected boolean processMembers(final PsiScopeProcessor processor, final PsiSubstitutor substitutor, final PsiElement lastParent, final PsiElement place) {
    final XmlFile xmlfile = (XmlFile)getNode().getPsi();
    for(JSFile file:myCachedScriptsCache.get(OUR_CACHED_SCRIPTS_KEY, xmlfile, null).getValue()) {
      if (!file.processDeclarations(processor, PsiSubstitutor.EMPTY, null, place)) return false;
    }
    return true;
  }

  @Override
  public boolean processDeclarations(@NotNull final PsiScopeProcessor processor, @NotNull final PsiSubstitutor substitutor, final PsiElement lastParent,
                                     @NotNull final PsiElement place) {
    boolean b = super.processDeclarations(processor, substitutor, lastParent, place);

    if (b) {
      final XmlFile xmlFile = (XmlFile)getNode().getPsi();
      final JavaScriptIndex index = JavaScriptIndex.getInstance(xmlFile.getProject());
      final JSIndexEntry indexEntry = index.getEntryForFile(xmlFile);

      b = indexEntry.processSymbolsInNs(new JavaScriptSymbolProcessor.DefaultSymbolProcessor() {
        protected boolean process(final PsiElement namedElement, final JSNamespace namespace) {
          return processor.execute(namedElement, PsiSubstitutor.EMPTY);
        }

        public PsiFile getBaseFile() {
          return xmlFile;
        }

        public int getRequiredNameId() {
          if (processor instanceof ResolveProcessor) {
            final String name = ((ResolveProcessor)processor).getName();
            return name != null ? index.getIndexOf(name) : -1;
          } else if (processor instanceof WalkUpResolveProcessor) {
            return ((WalkUpResolveProcessor)processor).getRequiredNameId();
          }
          return -1;
        }
      }, indexEntry.getTopLevelNs());
    }

    if(b) {
      b = JSResolveUtil.tryResolveImports(processor, this, place);
      if (!b) return false;
      b = doImportFromScripts(processor, place);
    }

    return b;
  }

  public boolean doImportFromScripts(final PsiScopeProcessor processor, final PsiElement place) {
    PsiElement context = place.getContainingFile().getContext();
    if (context instanceof XmlText) {
      context = context.getParent();
    }

    if (context instanceof XmlAttributeValue ||
        (context instanceof XmlTag && !SCRIPT_TAG_NAME.equals(((XmlTag)context).getLocalName()))) {
      final XmlFile xmlfile = (XmlFile)getNode().getPsi();

      for(JSFile file:myCachedScriptsCache.get(OUR_CACHED_SCRIPTS_KEY, xmlfile, null).getValue()) {
        if(JSResolveUtil.isAdequatePlaceForImport(file, place)) {
          if (JSResolveUtil.importClass(processor, file)) return false;
        }
      }
    }
    return true;
  }

  private static final Key<CachedValue<JSFile[]>> OUR_CACHED_SCRIPTS_KEY = Key.create("cached.scripts");

  @NonNls private static final String SCRIPT_TAG_NAME = "Script";
  private static final UserDataCache<CachedValue<JSFile[]>,XmlFile, Object> myCachedScriptsCache =
      new UserDataCache<CachedValue<JSFile[]>, XmlFile, Object>() {
        protected CachedValue<JSFile[]> compute(final XmlFile file, final Object p) {
          return file.getManager().getCachedValuesManager().createCachedValue(
            new CachedValueProvider<JSFile[]>() {
              public Result<JSFile[]> compute() {
                final List<JSFile> files = new ArrayList<JSFile>(2);
                file.processElements(
                  new PsiElementProcessor() {
                    public boolean execute(final PsiElement element) {
                      if (element instanceof XmlTag) {
                        final XmlTag tag = (XmlTag)element;

                        if (SCRIPT_TAG_NAME.equals(tag.getLocalName())) {
                          JSResolveUtil.processInjectedFileForTag(tag, new JSResolveUtil.JSInjectedFilesVisitor() {
                            protected void process(final JSFile file) {
                              files.add(file);
                            }
                          });
                        } else {
                          tag.processElements(this, null);
                        }
                      }
                      return true;
                    }
                  },
                  null
                );
                return new Result<JSFile[]>(files.toArray(new JSFile[files.size()]), file);
              }
            }, false
          );
        }
      };

  @Override
  public boolean isValid() {
    return getNode().getPsi().isValid();
  }

  private static Key<CachedValue<JSClass>> ourArtificialPsiKey = Key.create("xml.backed.class");
  public static JSClass getXmlBackedClass(final XmlFile xmlFile) {
    return myCachedClassCache.get(ourArtificialPsiKey, xmlFile, null).getValue();
  }

  private static final UserDataCache<CachedValue<JSClass>,XmlFile, Object> myCachedClassCache =
    new UserDataCache<CachedValue<JSClass>, XmlFile, Object>() {
      protected CachedValue<JSClass> compute(final XmlFile file, final Object p) {
        return file.getManager().getCachedValuesManager().createCachedValue(
          new CachedValueProvider<JSClass>() {
            public Result<JSClass> compute() {
              return new Result<JSClass>(new XmlBackedJSClassImpl(file), file);
            }
          },
          false
        );
      }
    };

  @Override
  public PsiElement getParent() {
    return getNode().getPsi();
  }

  public boolean isEquivalentTo(final PsiElement element2) {
    return element2 == getParent();
  }
}
