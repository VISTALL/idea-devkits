package com.intellij.lang.javascript.index;

import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.index.predefined.Marker;
import com.intellij.lang.javascript.psi.JSFile;
import com.intellij.navigation.NavigationItem;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.application.PathManager;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.*;
import com.intellij.openapi.startup.StartupManager;
import com.intellij.openapi.util.JDOMUtil;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vfs.*;
import com.intellij.psi.*;
import com.intellij.util.LocalTimeCounter;
import com.intellij.util.containers.HashSet;
import gnu.trove.*;
import org.jdom.Document;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;

import java.io.*;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: yole
 * Date: 03.10.2005
 * Time: 14:06:16
 * To change this template use File | Settings | File Templates.
 */
public final class JavaScriptIndex implements ProjectComponent {
  private Project myProject;
  private final FileTypeManager myFileTypeManager;
  private THashMap<String, JSIndexEntry> myOldJavaScriptFiles;
  private THashMap<String, JSIndexEntry> myJavaScriptFiles = new THashMap<String, JSIndexEntry>();
  private THashMap<String, JSIndexEntry> myPredefinedJavaScriptFiles = new THashMap<String, JSIndexEntry>();
  private static Key<JSIndexEntry> ourEntryKey = Key.create("js.indexentry");

  private JSTreeChangeListener myTreeChangeListener;
  private VirtualFileListener myFileListener;
  private ModuleRootListener myRootListener;
  private Runnable myUpdateRunnable;
  private boolean myLoadingProject;

  private TObjectIntHashMap<String> myNames2Index = new TObjectIntHashMap<String>(50);
  private TIntObjectHashMap<String> myIndex2Names = new TIntObjectHashMap<String>(50);

  @NonNls private static final String NAME_ATTR_NAME = "name";
  @NonNls private static final String METHOD_TAG_NAME = "method";
  @NonNls private static final String PARAM_TAG_NAME = "param";
  @NonNls private static final String PROPERTY_TAG_NAME = "property";
  @NonNls private static final String EVENT_TAG_NAME = "event";
  @NonNls private static final String BROWSER_ATTR_NAME = "browser";

  @NonNls private static final String JS_CACHES_DIR_NAME = "js_caches";
  private static final byte CURRENT_VERSION = 17;
  private static final Logger LOG = Logger.getInstance("#com.intellij.lang.javascript.index.JavaScriptIndex");

  @NonNls private static final String DHTML_XML_FILE_NAME = "DHTML.xml";
  private static @NonNls Set<String> ourPredefinedFileNames = new HashSet<String>(Arrays.asList( "ECMAScript.xml", "DOMCore.xml",
                                                                                                 DHTML_XML_FILE_NAME, "AJAX.xml",
      "DOMEvents.xml", "DOMTraversalAndRange.xml", "DOMXPath.xml"));
  @NonNls private static final String PREDEFINES_PREFIX = "predefines.";
  @NonNls private static final String GLOBAL_CLASS_NAME = "Global";
  @NonNls private static final String OBJECT_CLASS_NAME = "Object";

  public JavaScriptIndex(final Project project, final FileTypeManager fileTypeManager) {
    myProject = project;
    myFileTypeManager = fileTypeManager;
    myTreeChangeListener = new JSTreeChangeListener();
    PsiManager.getInstance(myProject).addPsiTreeChangeListener(myTreeChangeListener);
  }

  public void projectOpened() {
    myLoadingProject = true;
    myUpdateRunnable = new Runnable() {
      public void run() {
        try {
          final ProgressIndicator progress = ProgressManager.getInstance().getProgressIndicator();

          if (myLoadingProject) loadCaches(progress);
          if (progress != null) {
            progress.pushState();
            progress.setIndeterminate(true);
            progress.setText(JSBundle.message("building.index.message"));
          }

          final ProjectFileIndex fileIndex = ProjectRootManager.getInstance(myProject).getFileIndex();
          final List<VirtualFile> filesToProcess = new ArrayList<VirtualFile>(5);

          fileIndex.iterateContent(new ContentIterator() {
            public boolean processFile(VirtualFile fileOrDir) {
              if (myFileTypeManager.getFileTypeByFile(fileOrDir) == JavaScriptSupportLoader.JAVASCRIPT &&
                  myJavaScriptFiles.get(fileOrDir.getPath()) == null
                 ) {
                filesToProcess.add(fileOrDir);
              }
              return true;
            }
          });

          if (progress != null) {
            progress.setIndeterminate(false);
          }

          int processed = 0;

          for(VirtualFile f:filesToProcess) {
            fileAdded(f);
            ++processed;
            if(progress != null) {
              progress.setFraction((double)processed/filesToProcess.size());
            }
          }

          if (progress != null) {
            progress.setFraction(1.0);
            progress.setText("");
            progress.setText2("");
            progress.popState();
          }
        }
        finally {
          myLoadingProject = false;
        }
      }
    };

    if (ApplicationManager.getApplication().isUnitTestMode()) {
      myUpdateRunnable.run();
    } else {
      StartupManager.getInstance(myProject).registerStartupActivity(myUpdateRunnable);
    }

    myFileListener = new VirtualFileAdapter() {
      public void fileCreated(VirtualFileEvent event) {
        fileAdded(event.getFile());
      }

      public void beforeFileDeleted(VirtualFileEvent event) {
        final VirtualFile fileOrDir = event.getFile();
        if (myFileTypeManager.getFileTypeByFile(fileOrDir) == JavaScriptSupportLoader.JAVASCRIPT) {
          processFileRemoved( (JSFile)PsiManager.getInstance(myProject).findFile(fileOrDir) );
        }
      }
    };

    VirtualFileManager.getInstance().addVirtualFileListener( myFileListener );
    ProjectRootManager.getInstance(myProject).addModuleRootListener(
      myRootListener = new ModuleRootListener() {
        public void beforeRootsChange(ModuleRootEvent event) {}

        public void rootsChanged(ModuleRootEvent event) {
          Runnable runnable = new Runnable() {
            public void run() {
              if (myProject.isDisposed()) return; // we are already removed
              myOldJavaScriptFiles = myJavaScriptFiles;
              myJavaScriptFiles = new THashMap<String, JSIndexEntry>(myOldJavaScriptFiles.size());

              if (ApplicationManager.getApplication().isUnitTestMode()) {
                myUpdateRunnable.run();
              } else {
                ProgressManager.getInstance().runProcessWithProgressSynchronously(
                  myUpdateRunnable,
                  JSBundle.message("building.index.message"),
                  false,
                  myProject
                );
              }

              myOldJavaScriptFiles = null;
            }
          };
          ApplicationManager.getApplication().invokeLater(runnable);
        }
      }
    );
  }

  private void initPredefines(ProgressIndicator progress) {
    for(String name:ourPredefinedFileNames) {
      if (myPredefinedJavaScriptFiles.get(name) == null) {
        if (progress != null) progress.setText2(name);
        createPredefinesFromModel(name);
      }
    }
  }

  public void loadCaches(final ProgressIndicator progress) {
    DataInputStream input = null;
    try {
      final File cacheFile = getCacheLocation(JS_CACHES_DIR_NAME);
      if (!cacheFile.exists()) return;

      input = new DataInputStream(new BufferedInputStream(new FileInputStream(cacheFile)));
      int version = input.readByte();
      if (version != CURRENT_VERSION) {
        return;
      }

      if (progress != null) {
        progress.pushState();
        progress.setText(JSBundle.message("loading.index.message"));
      }

      final int fileCount = input.readInt();
      final PsiManager manager = PsiManager.getInstance(myProject);
      final int namesCount = input.readInt();
      DeserializationContext context = new DeserializationContext(input, manager, myIndex2Names);

      myIndex2Names.ensureCapacity( namesCount );
      myNames2Index.ensureCapacity( namesCount );

      for(int i = 0; i < namesCount; ++i) {
        final String name = input.readUTF();
        final int index = input.readInt();
        myIndex2Names.put(index, name);
        myNames2Index.put(name, index);
      }

      for (int i = 0; i < fileCount; i++) {
        final String url = input.readUTF();
        final long stamp = input.readLong();

        if (progress != null) {
          progress.setText2(url);
          progress.setFraction(((double)i) / fileCount);
        }

        boolean predefined = ourPredefinedFileNames.contains(url);
        boolean outdated = false;
        final PsiFile psiFile;

        if (!predefined) {
          final VirtualFile relativeFile = VfsUtil.findRelativeFile(url, null);

          if (relativeFile == null || stamp != relativeFile.getTimeStamp()) {
            outdated = true;
          }

          psiFile = relativeFile != null ? manager.findFile(relativeFile):null;
          if (!(psiFile instanceof JSFile) || predefined) {
            outdated = true;
          }
        } else {
          psiFile = createPredefinesFile(url);
        }

        final JSIndexEntry value = new JSIndexEntry(context, outdated ? null:(JSFile)psiFile);

        if (!outdated) {
          ((predefined)?myPredefinedJavaScriptFiles:myJavaScriptFiles).put(url, value);
        }
      }

      if (progress != null) {
        progress.popState();
      }

      input.close();
    } catch (NoSuchElementException e) {
      // this might happen if index version is not updated on minor update
    }
    catch (IOException e) {
      LOG.debug(e);
    } finally {
      if (input != null) {
        try {
          input.close();
        }
        catch (IOException e1) {}
      }

      initPredefines(progress);
    }
  }

  private File getCacheLocation(final String dirName) {
    final String cacheFileName = myProject.getName() + "." + Integer.toHexString(FileUtil.toSystemIndependentName(myProject.getProjectFilePath()).hashCode());
    return new File(PathManager.getSystemPath() + File.separator + dirName + File.separator + cacheFileName);
  }

  public void saveCaches() {
    final File cacheFile = getCacheLocation(JS_CACHES_DIR_NAME);
    FileUtil.createParentDirs(cacheFile);
    DataOutputStream output = null;

    try {
      output = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(cacheFile)));
      output.writeByte(CURRENT_VERSION);
      output.writeInt(myJavaScriptFiles.size() + myPredefinedJavaScriptFiles.size());
      SerializationContext context = new SerializationContext(output, myProject);

      enumerateNames(myPredefinedJavaScriptFiles, context);
      enumerateNames(myJavaScriptFiles, context);

      int namesCount = context.myNames.size();
      output.writeInt(namesCount);

      TObjectIntIterator<String> iterator = context.myNames.iterator();
      while(iterator.hasNext()) {
        iterator.advance();
        output.writeUTF(iterator.key());
        output.writeInt(iterator.value());
        --namesCount;
      }

      writeEntries(myPredefinedJavaScriptFiles, output, context);
      writeEntries(myJavaScriptFiles, output, context);
      output.close();
    }
    catch (IOException e) {
      LOG.debug(e);
      if (output != null) {
        try {
          output.close();
          output = null;
        }
        catch (IOException e1) {}
      }
      cacheFile.delete();
    } finally {
      if (output != null) {
        try {
          output.close();
        }
        catch (IOException e1) {}
      }
    }
  }

  private static void writeEntries(final Map<String, JSIndexEntry> entries, final DataOutputStream output, final SerializationContext context)
    throws IOException {
    for (final String key : entries.keySet()) {
      final JSIndexEntry value = entries.get(key);
      final VirtualFile virtualFile = value.getFile().getVirtualFile();

      if (virtualFile == null) {
        output.writeUTF(key);
        output.writeLong(-1);
      } else {
        output.writeUTF(virtualFile.getPath());
        output.writeLong(virtualFile.getTimeStamp());
      }

      value.write(context);
    }
  }

  private static void enumerateNames(final Map<String, JSIndexEntry> entries, final SerializationContext context) {
    for (final JSIndexEntry value : entries.values()) {
      value.enumerateNames(context);
    }
  }

  private JSFile createPredefinesFile(String fileName) {
    final String type = fileName.substring(0,fileName.indexOf('.'));
    final String s = translateFile(fileName);

    if (s != null) {
      final PsiElementFactory psiElementFactory = PsiManager.getInstance(myProject).getElementFactory();

      try {
        // This method does not expand tree
        final Method method = psiElementFactory.getClass().getMethod(
          "createFileFromText",
          String.class,
          FileType.class,
          CharSequence.class,
          Long.TYPE,
          Boolean.TYPE,
          Boolean.TYPE
        );
        return (JSFile)method.invoke(
          psiElementFactory,
          PREDEFINES_PREFIX + type + ".js",
          JavaScriptSupportLoader.JAVASCRIPT,
          s,
          LocalTimeCounter.currentTime(),
          false,
          false
        );
      }
      catch (Exception e) {
        return (JSFile)psiElementFactory.createFileFromText(
          PREDEFINES_PREFIX + type + ".js",
          JavaScriptSupportLoader.JAVASCRIPT,
          s,
          LocalTimeCounter.currentTime(),
          false
        );
      }
    }
    return null;
  }

  private void createPredefinesFromModel(final String fileName) {
    final JSFile fileFromText = createPredefinesFile(fileName);

    if (fileFromText != null) {
      final JSIndexEntry value = new JSIndexEntry(fileFromText);
      myPredefinedJavaScriptFiles.put(fileName, value);
      value.initTypesAndBrowserSpecifics();
    }
  }

  private void fileAdded(final VirtualFile fileOrDir) {
    if (myFileTypeManager.getFileTypeByFile(fileOrDir) == JavaScriptSupportLoader.JAVASCRIPT) {
      final PsiFile psiFile = PsiManager.getInstance(myProject).findFile(fileOrDir);
      if (psiFile instanceof JSFile) processFileAdded((JSFile)psiFile);
    }
  }

  public void projectClosed() {
    VirtualFileManager.getInstance().removeVirtualFileListener( myFileListener );
    myFileListener = null;
    PsiManager.getInstance(myProject).removePsiTreeChangeListener(myTreeChangeListener);
    ProjectRootManager.getInstance(myProject).removeModuleRootListener(myRootListener);

    if (!ApplicationManager.getApplication().isUnitTestMode()) {
      saveCaches();
    }
    clear();
  }

  public void processFileAdded(final JSFile psiFile) {
    final String url = psiFile.getVirtualFile().getPath();

    if (myOldJavaScriptFiles != null) {
      final JSIndexEntry jsIndexEntry = myOldJavaScriptFiles.get(url);

      if (jsIndexEntry != null) {
        myJavaScriptFiles.put(url,jsIndexEntry);
        return;
      }
    }

    final ProgressIndicator progress = ProgressManager.getInstance().getProgressIndicator();
    if (progress != null) {
      progress.setText2(psiFile.getVirtualFile().getPresentableUrl());
    }
    myJavaScriptFiles.put(url, new JSIndexEntry(psiFile));
  }

  private void processFileChanged(final JSFile jsFile) {
    if (!jsFile.isPhysical()) return;
    final JSIndexEntry indexEntry = myJavaScriptFiles.get(jsFile.getVirtualFile().getPath());

    if (indexEntry == null) {
      processFileAdded(jsFile);
    }
  }

  private void processFileRemoved(final JSFile jsFile) {
    final JSIndexEntry jsIndexEntry = myJavaScriptFiles.remove(jsFile.getVirtualFile().getPath());
    if (jsIndexEntry != null) jsIndexEntry.invalidate();
  }

  @NonNls
  public String getComponentName() {
    return "JavaScriptIndex";
  }

  public void initComponent() {
  }

  public void disposeComponent() {
  }

  public static JavaScriptIndex getInstance(final Project project) {
    return project.getComponent(JavaScriptIndex.class);
  }

  public String[] getSymbolNames() {
    final Set<String> symbolNames = new HashSet<String>();
    for(JSIndexEntry entry: myPredefinedJavaScriptFiles.values()) {
      entry.fillSymbolNames(symbolNames);
    }
    for(JSIndexEntry entry: myJavaScriptFiles.values()) {
      entry.fillSymbolNames(symbolNames);
    }
    return symbolNames.toArray(new String[symbolNames.size()]);
  }

  public NavigationItem[] getSymbolsByName(final String name) {
    final Set<NavigationItem> symbolNavItems = new HashSet<NavigationItem>();
    for(JSIndexEntry entry: myJavaScriptFiles.values()) {
      entry.fillSymbolsByName(name, symbolNavItems);
    }
    return symbolNavItems.toArray(new NavigationItem[symbolNavItems.size()]);
  }

  public void clear() {
    myJavaScriptFiles.clear();
    myPredefinedJavaScriptFiles.clear();
    JSTypeEvaluateManager.getInstance(myProject).clear();
    BrowserSupportManager.getInstance(myProject).clear();
    myIndex2Names.clear();
    myNames2Index.clear();
  }

  public void processAllSymbols(JavaScriptSymbolProcessor processor) {
    for(JSIndexEntry entry: myPredefinedJavaScriptFiles.values()) {
      entry.processSymbols(processor);
    }

    final PsiFile psiFile = processor.getBaseFile();
    VirtualFile virtualFile = psiFile.getVirtualFile();
    if (virtualFile == null && psiFile.getOriginalFile() != null) {
      virtualFile = psiFile.getOriginalFile().getVirtualFile();
    }

    if (virtualFile == null) return;
    final ProjectFileIndex fileIndex = ProjectRootManager.getInstance(myProject).getFileIndex();

    final Module moduleForFile = fileIndex.getModuleForFile(virtualFile);
    
    if (moduleForFile != null) {
      final Module[] dependencies = ModuleRootManager.getInstance(moduleForFile).getDependencies();
      final Set<Module> modules = new java.util.HashSet<Module>(dependencies.length + 1);
      modules.addAll(Arrays.asList(dependencies));
      modules.add(moduleForFile);

      for(JSIndexEntry entry: myJavaScriptFiles.values()) {
        if (modules.contains(fileIndex.getModuleForFile(entry.getFile().getVirtualFile()))) {
          entry.processSymbols(processor);
        }
      }
    }

    if (psiFile.getFileType() != JavaScriptSupportLoader.JAVASCRIPT) {
      JSIndexEntry ourEntry = psiFile.getUserData(ourEntryKey);

      if (ourEntry == null) {
        ourEntry = new JSIndexEntry(processor.getBaseFile());
        psiFile.putUserData(ourEntryKey, ourEntry);
      }
      ourEntry.processSymbols(processor);
    }
  }

  public static boolean isFromPredefinedFile(final PsiFile containingFile) {
    return !containingFile.isPhysical();
  }

  private class JSTreeChangeListener extends PsiTreeChangeAdapter {
    public void childAdded(PsiTreeChangeEvent event) {
      final PsiElement child = event.getChild();
      if (child instanceof JSFile && child.isPhysical()) {
        processFileAdded((JSFile)child);
      }
      else {
        process(event);
      }
    }

    public void childrenChanged(PsiTreeChangeEvent event) {
      process(event);
    }

    public void childRemoved(PsiTreeChangeEvent event) {
      if (event.getChild() instanceof JSFile) {
        processFileRemoved((JSFile)event.getChild());
      }
      else {
        process(event);
      }
    }

    public void childReplaced(PsiTreeChangeEvent event) {
      process(event);
    }

    private void process(final PsiTreeChangeEvent event) {
      final PsiElement psiElement = event.getParent();

      if (psiElement != null && psiElement.isValid()) {
        final PsiFile psiFile = psiElement.getContainingFile();

        if (psiFile instanceof JSFile) processFileChanged((JSFile) psiFile);
      }
    }
  }

  private static String translateFile(final String fileName) {
    try {
      final Document document = JDOMUtil.loadDocument(Marker.class.getResourceAsStream(fileName));
      final List elements = document.getRootElement().getChildren("class");
      StringBuilder builder = new StringBuilder(8192);

      for(Object e:elements) {
        if (e instanceof Element) {
          if (builder.length() > 0) builder.append('\n');
          final Element element = (Element)e;
          String className = element.getAttributeValue(NAME_ATTR_NAME);
          String extendsFromName = element.getAttributeValue("extends");
          if (extendsFromName == null &&
              !GLOBAL_CLASS_NAME.equals(className) &&
              !OBJECT_CLASS_NAME.equals(className)
             ) {
            extendsFromName = OBJECT_CLASS_NAME;
          }

          translateOneClass(element, className, extendsFromName, builder);
        }
      }

      if (fileName.equals(DHTML_XML_FILE_NAME)) {
        try {
          Class cssPropertyTableClass = Class.forName("com.intellij.psi.css.impl.util.table.CssPropertyTable");
          final Method method = cssPropertyTableClass.getMethod("initPropertyNames", new Class[]{Set.class});
          Set<String> propertyNames = new java.util.HashSet<String>();
          method.invoke(null,new Object[] {propertyNames});

          StringBuffer result = new StringBuffer();
          for(String propertyName:propertyNames) {
            result.setLength(0);
            result.ensureCapacity(propertyName.length());
            StringTokenizer tokenizer = new StringTokenizer(propertyName, "-");

            while(tokenizer.hasMoreTokens()) {
              String token = tokenizer.nextToken();
              if (result.length() != 0) token = StringUtil.capitalize(token);
              result.append(token);
            }

            builder.append("style.").append(result.toString()).append(" = 0;\n");
          }
        }
        catch (Exception e) {}
      }
      return builder.toString();
    } catch(Exception e) {
      LOG.error(e);
    }
    return null;
  }

  private static void translateOneClass(final Element element, final String className, final String extendsClassName, final StringBuilder builder) {
    String targetBrowser = element.getAttributeValue(BROWSER_ATTR_NAME);
    String selectionExpr = !className.equals(GLOBAL_CLASS_NAME) ? className + '.' : "";

    List children = element.getChildren(PROPERTY_TAG_NAME);
    processNodes(children, builder, selectionExpr, targetBrowser);

    children = element.getChildren(METHOD_TAG_NAME);
    processNodes(children, builder, selectionExpr, targetBrowser);

    children = element.getChildren(EVENT_TAG_NAME);
    processNodes(children, builder, selectionExpr, targetBrowser);

    if (extendsClassName != null) {
      builder.append(className).append(".prototype = new ").append(extendsClassName).append("();\n");
    }
  }

  private static void processNodes(final List children, final StringBuilder builder, final String selectionExpr, String browserSpecific) {
    boolean headerStarted = false;
    boolean processingProperties = false;
    boolean seenConstructor = false;

    for(Object e2:children) {
      if (e2 instanceof Element) {
        final Element subelement = ((Element)e2);
        final String name = subelement.getAttributeValue(NAME_ATTR_NAME);
        final boolean method = METHOD_TAG_NAME.equals(subelement.getName());
        final boolean property = PROPERTY_TAG_NAME.equals(subelement.getName());
        final String type;
        final String typeValue;

        String elementBrowserSpecific = subelement.getAttributeValue(BROWSER_ATTR_NAME);
        if (elementBrowserSpecific == null) elementBrowserSpecific = browserSpecific;

        if (method) {
          final List grandchildren = subelement.getChildren(PARAM_TAG_NAME);
          String paramString = "";

          for(Object p:grandchildren) {
            final Element param = ((Element)p);

            //if (param.getAttributeValue("mandatory") == null) continue;
            final String paramName = param.getAttributeValue(NAME_ATTR_NAME);
            if (paramString.length() > 0) paramString += ",";
            paramString  += paramName;
          }

          type = "function("+paramString+") {}";
          typeValue = subelement.getAttributeValue("returnType");
        }
        else if (property) {
          processingProperties = true;

          if ("constructor".equals(name)) {
            seenConstructor = true;
            builder.append(selectionExpr.substring(0, selectionExpr.length() - 1)).append(" = ").append("function() {};\n");
          }

          type = "0";
          typeValue = subelement.getAttributeValue("type");
        } else { // event
          if (!headerStarted) {
            headerStarted = true;
            builder.append("var ").append(selectionExpr.substring(0,selectionExpr.length() - 1)).append(" = {\n");
          }
          builder.append(name).append(": function () {},\n");
          continue;
        }

        builder.append(selectionExpr).append(name) .append(" = ").append(type).append(";");
        JSIndexEntry.encodeBrowserSpecificsAndType(builder, elementBrowserSpecific, typeValue);
        builder.append('\n');
      }
    }

    if (headerStarted) {
      builder.append("};\n");
    }

    if (processingProperties && !seenConstructor && selectionExpr.length() > 0) {
      // Create static var for noncostructable classes e.g. Math
      builder.append(selectionExpr.substring(0,selectionExpr.length() - 1)).append( " = {};\n");
    }
  }

  public int getIndexOf(String s) {
    if (s == null) {
      return -1;
    }
    final int i = myNames2Index.get(s);
    if (i > 0) return i;
    final int value = myNames2Index.size() + 1;
    myNames2Index.put(s, value);
    myIndex2Names.put(value,s);
    return value;
  }

  public String getStringByIndex(int i) {
    final String s = myIndex2Names.get(i);
    if (s != null) return s;
    if (i == -1) return null;
    throw new NoSuchElementException();
  }
}
