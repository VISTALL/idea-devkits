package com.intellij.lang.javascript.index;

import com.intellij.ProjectTopics;
import com.intellij.facet.FacetManager;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.flex.FlexFacet;
import com.intellij.lang.javascript.psi.JSFile;
import com.intellij.navigation.NavigationItem;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.application.ModalityState;
import com.intellij.openapi.application.PathManager;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleManager;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.*;
import com.intellij.openapi.startup.StartupManager;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vfs.*;
import com.intellij.openapi.vfs.newvfs.NewVirtualFile;
import com.intellij.psi.*;
import com.intellij.util.Processor;
import com.intellij.util.containers.HashSet;
import com.intellij.util.messages.MessageBusConnection;
import gnu.trove.*;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.*;
import java.lang.reflect.Method;
import java.util.*;

/**
 * @by maxim, yole
 */
public final class JavaScriptIndex implements ProjectComponent {
  private Project myProject;
  private final FileTypeManager myFileTypeManager;
  private THashMap<String, JSIndexEntry> myOldJavaScriptFiles;
  private THashMap<String, JSIndexEntry> myJavaScriptFiles = new THashMap<String, JSIndexEntry>();
  private THashMap<String, JSIndexEntry> myPredefinedJavaScriptFiles = new THashMap<String, JSIndexEntry>();

  private final JSPackage myRootPackage = new JSPackage();
  private static Key<JSIndexEntry> ourEntryKey = Key.create("js.indexentry");

  private JSTreeChangeListener myTreeChangeListener;
  private final Set<VirtualFile> setOfExternalDefsRoots = new java.util.HashSet<VirtualFile>();
  private VirtualFileListener myFileListener;

  private Runnable myUpdateRunnable;
  private boolean myLoadingProject;
  private boolean myDoingFilesRescan;

  private TObjectIntHashMap<String> myNames2Index = new TObjectIntHashMap<String>(50);
  private TIntObjectHashMap<String> myIndex2Names = new TIntObjectHashMap<String>(50);
  private THashSet<JSIndexEntry> myFilesToUpdate = new THashSet<JSIndexEntry>(50);

  @NonNls private static final String JS_CACHES_DIR_NAME = "js_caches";
  private static final byte CURRENT_VERSION = 91;
  static final Logger LOG = Logger.getInstance("#com.intellij.lang.javascript.index.JavaScriptIndex");

  @NonNls static final String DHTML_XML_FILE_NAME = "DHTML.xml";
  private static @NonNls Set<String> ourPredefinedFileNames = new LinkedHashSet<String>(Arrays.asList( "ECMAScript.js2", "DOMCore.xml",
                                                                                                 DHTML_XML_FILE_NAME, "AJAX.xml",
      "DOMEvents.xml", "DOMTraversalAndRange.xml", "DOMXPath.xml", "E4X.js2"));
  @NonNls static final String PREDEFINES_PREFIX = "predefines.";
  @NonNls private static final String SWC_EXTENSION = "swc";
  private MessageBusConnection myConnection;
  static final @NonNls String PREDEFINED_SCRIPTS_FILE_EXTENSION = ".js";
  public static final Key<String> READONLY_JS_FILE_KEY = Key.create("ReadOnly.JavaScript.File");
  public static final Key<String> PREDEFINED_JS_FILE_KEY = Key.create("Predefined.JavaScript.File");

  public JavaScriptIndex(final Project project, final FileTypeManager fileTypeManager) {
    myProject = project;
    myFileTypeManager = fileTypeManager;
    myTreeChangeListener = new JSTreeChangeListener();
    PsiManager.getInstance(myProject).addPsiTreeChangeListener(myTreeChangeListener);
  }

  public void projectOpened() {
    myLoadingProject = true;
    myUpdateRunnable = new Runnable() {
      public void run() {
        try {
          final ProgressIndicator progress = ProgressManager.getInstance().getProgressIndicator();
          myDoingFilesRescan = true;

          if (progress != null) {
            progress.pushState();
            progress.setIndeterminate(true);
            progress.setText(JSBundle.message("building.index.message"));
          }

          setOfExternalDefsRoots.clear();
          processModulesThatContainExternalJSDefinitions(
              new Processor<VirtualFile>() {
              public boolean process(final VirtualFile home) {
                setOfExternalDefsRoots.add(home);
                return true;
              }
            }
          );

          if (myLoadingProject) loadCaches(progress);

          final ProjectFileIndex fileIndex = ProjectRootManager.getInstance(myProject).getFileIndex();
          final List<VirtualFile> filesToProcess = new ArrayList<VirtualFile>(5);

          fileIndex.iterateContent(new ContentIterator() {
            public boolean processFile(VirtualFile fileOrDir) {
              if (( myFileTypeManager.getFileTypeByFile(fileOrDir) == JavaScriptSupportLoader.JAVASCRIPT ||
                    (isAcceptableFile(fileOrDir) &&
                     ( ApplicationManager.getApplication().isUnitTestMode() || isPlaceWhereSwcImportedUnderProjectRoots(fileOrDir)
                     )
                    )
                  ) &&
                  myJavaScriptFiles.get(fileOrDir.getPath()) == null &&
                  !fileOrDir.isDirectory()
                 ) {
                filesToProcess.add(fileOrDir);
              }
              return true;
            }
          });

          processModulesThatContainExternalJSDefinitions(new Processor<VirtualFile>() {
            public boolean process(final VirtualFile home) {
              collectFilesUnderDirectory(home, filesToProcess, !ApplicationManager.getApplication().isUnitTestMode());
              return true;
            }
          });

          if (progress != null) {
            progress.setIndeterminate(false);
          }

          int processed = 0;

          for(VirtualFile f:filesToProcess) {
            fileAdded(f);
            ++processed;
            if(progress != null) {
              progress.setFraction((double)processed/filesToProcess.size());
              ProgressManager.getInstance().checkCanceled();
            }
          }

          if (progress != null) {
            progress.setFraction(1.0);
            progress.setText("");
            progress.setText2("");
            progress.popState();
          }
        }
        finally {
          myLoadingProject = false;
          myDoingFilesRescan = false;
        }
      }
    };

    if (ApplicationManager.getApplication().isUnitTestMode()) {
      if (myProject.isOpen()) {
        StartupManager.getInstance(myProject).registerStartupActivity(myUpdateRunnable);
      }
      else {
        clear();
        myUpdateRunnable.run();
      }
    } else {
      StartupManager.getInstance(myProject).registerStartupActivity(myUpdateRunnable);
    }

    myFileListener = new VirtualFileAdapter() {
      final Method fileAddedCallback;
      final Method fileChangedCallback;
      final Method fileRemovedCallback;
      final ProjectFileIndex fileIndex = ProjectRootManager.getInstance(myProject).getFileIndex();
      final boolean unitTestMode = ApplicationManager.getApplication().isUnitTestMode();

      {
        try {
          fileAddedCallback = JavaScriptIndex.class.getDeclaredMethod("fileAdded",VirtualFile.class);
          fileAddedCallback.setAccessible(true);
          fileRemovedCallback = JavaScriptIndex.class.getDeclaredMethod("fileRemoved",VirtualFile.class);
          fileRemovedCallback.setAccessible(true);

          fileChangedCallback = JavaScriptIndex.class.getDeclaredMethod("fileChanged",VirtualFile.class);
          fileChangedCallback.setAccessible(true);
        }
        catch (Exception e) {
          throw new RuntimeException(e);
        }
      }

      public void fileCreated(VirtualFileEvent event) {
        if (this != myFileListener) return; // disposed
        propagateEvent(event.getFile(), fileAddedCallback, false);
      }

      private void propagateEvent(final VirtualFile file, Method callback, boolean propagateViaCachedChildren) {
        if (!file.isInLocalFileSystem() || myProject.isDisposed() || ( !unitTestMode && !myProject.isInitialized() ) || fileIndex.isIgnored(file)) return;
        final VirtualFile contentRoot = fileIndex.getContentRootForFile(file);

        if (contentRoot == null) {
          if (callback == fileAddedCallback) return;
          if (!isAcceptableFile(file) && !file.isDirectory()) return;
          if (!ApplicationManager.getApplication().isUnitTestMode()) {
            boolean hasSdkAncestor = false;

            for(VirtualFile root:setOfExternalDefsRoots) {
              if (VfsUtil.isAncestor(root, file, true)) {
                hasSdkAncestor = true;
                break;
              }
            }

            if (!hasSdkAncestor) {
              return;
            }
          }
        }

        if (file.isDirectory()) {
          if (propagateViaCachedChildren && file instanceof NewVirtualFile) {
            for(VirtualFile child:((NewVirtualFile)file).getCachedChildren()) propagateEvent(child, callback, propagateViaCachedChildren);
          } else {
            for(VirtualFile child:file.getChildren()) propagateEvent(child, callback, propagateViaCachedChildren);
          }
        } else {
          try {
            callback.invoke(JavaScriptIndex.this,file);
          }
          catch (Exception e) {
            throw new RuntimeException(e);
          }
        }
      }

      public void beforeFileDeletion(VirtualFileEvent event) {
        if (this != myFileListener) return; // disposed
        final VirtualFile fileOrDir = event.getFile();
        propagateEvent(fileOrDir,fileRemovedCallback, true);
      }

      public void beforeContentsChange(final VirtualFileEvent event) {
        if (this != myFileListener) return; // disposed
        propagateEvent(event.getFile(), fileChangedCallback, false);
      }

      public void beforePropertyChange(final VirtualFilePropertyEvent event) {
        if (this != myFileListener) return; // disposed
        if (VirtualFile.PROP_NAME.equals(event.getPropertyName())) {
          propagateEvent(event.getFile(), fileRemovedCallback, false);
        }
      }

      public void propertyChanged(final VirtualFilePropertyEvent event) {
        if (this != myFileListener) return; // disposed
        if (VirtualFile.PROP_NAME.equals(event.getPropertyName())) {
          propagateEvent(event.getFile(), fileAddedCallback, false);
        }
      }

      public void beforeFileMovement(final VirtualFileMoveEvent event) {
        if (this != myFileListener) return; // disposed
        propagateEvent(event.getFile(), fileRemovedCallback, false);
      }

      public void fileMoved(final VirtualFileMoveEvent event) {
        if (this != myFileListener) return; // disposed
        propagateEvent(event.getFile(), fileAddedCallback, false);
      }
    };

    myConnection = myProject.getMessageBus().connect();

    VirtualFileManager.getInstance().addVirtualFileListener( myFileListener );

    myConnection.subscribe(ProjectTopics.PROJECT_ROOTS, new ModuleRootListener() {
      public void beforeRootsChange(ModuleRootEvent event) {
      }

      public void rootsChanged(ModuleRootEvent event) {
        requestUpdateCaches();
      }
    });
  }

  private static boolean isPlaceWhereSwcImportedUnderProjectRoots(final VirtualFile fileOrDir) {
    final String parentDirName = fileOrDir.getParent().getName();
    return "libs".equals(parentDirName) || "lib".equals(parentDirName);
  }

  private boolean isAcceptableFile(final VirtualFile fileOrDir) {
      return myFileTypeManager.getFileTypeByFile(fileOrDir) == JavaScriptSupportLoader.JAVASCRIPT ||
        (SWC_EXTENSION.equals(fileOrDir.getExtension()) &&
         fileOrDir.getFileType() == StdFileTypes.ARCHIVE &&
         !fileOrDir.getNameWithoutExtension().equals("airglobal")
        );
    }

  private void requestUpdateCaches() {
    Runnable runnable = new Runnable() {
      public void run() {
        if (myProject.isDisposed()) return; // we are already removed

        myOldJavaScriptFiles = myJavaScriptFiles;
        myJavaScriptFiles = new THashMap<String, JSIndexEntry>(myOldJavaScriptFiles != null ? myOldJavaScriptFiles.size():10);

        if (ApplicationManager.getApplication().isUnitTestMode()) {
          myUpdateRunnable.run();
        }
        else {
          ProgressManager.getInstance()
            .runProcessWithProgressSynchronously(myUpdateRunnable, JSBundle.message("building.index.message"), false, myProject);
        }

        if (myOldJavaScriptFiles != null) {
          for(JSIndexEntry entry:myOldJavaScriptFiles.values()) {
            entry.invalidate();
          }
          myOldJavaScriptFiles = null;
        }
      }
    };
    ApplicationManager.getApplication().invokeLater(runnable, ModalityState.NON_MODAL);
  }

  private void processModulesThatContainExternalJSDefinitions(Processor<VirtualFile> processor) {
    Set<VirtualFile> processed = new java.util.HashSet<VirtualFile>();

    for(Module module: ModuleManager.getInstance(myProject).getModules()) {
      final FlexFacet facet = FacetManager.getInstance(module).getFacetByType(FlexFacet.ID);

      if (facet != null) {
        VirtualFile file = facet.getConfiguration().getFlexPath();
        if (file != null && !processed.contains(file)) {
          processed.add(file);
          processor.process(file);
        }
      }
    }
  }

  private void initPredefines(ProgressIndicator progress) {
    for(String name:ourPredefinedFileNames) {
      initPredefinedFile(progress, name);
    }
  }

  private void initPredefinedFile(final ProgressIndicator progress, final String name) {
    PsiFile file;
    final JSIndexEntry indexEntry = myPredefinedJavaScriptFiles.get(name);

    if (indexEntry == null) {
      if (progress != null) progress.setText2(name);
      file = createPredefinesFromModel(name);
    } else {
      file = indexEntry.getFile();
    }
  }

  public synchronized void loadCaches(final ProgressIndicator progress) {
    DataInputStream input = null;
    final File cacheFile = getCacheLocation(JS_CACHES_DIR_NAME);

    boolean rebuildCachesRequested = true;
    boolean loadingCachesStarted = false;

    try {
      if (!cacheFile.exists()) return; // should be in try to ensure 'predefines' initialized

      input = new DataInputStream(new BufferedInputStream(new FileInputStream(cacheFile)));
      int version = input.readByte();
      if (version != CURRENT_VERSION) {
        return;
      }

      if (progress != null) {
        progress.pushState();
        progress.setText(JSBundle.message("loading.index.message"));
        loadingCachesStarted = true;
      }

      final int fileCount = input.readInt();
      final PsiManager manager = PsiManager.getInstance(myProject);
      final int namesCount = input.readInt();
      DeserializationContext context = new DeserializationContext(input, manager, myIndex2Names);

      myIndex2Names.ensureCapacity( namesCount );
      myNames2Index.ensureCapacity( namesCount );

      for(int i = 0; i < namesCount; ++i) {
        final String name = input.readUTF();
        final int index = input.readInt();
        myIndex2Names.put(index, name);
        myNames2Index.put(name, index);
      }

      myRootPackage.deserialize(context);

      List<JSIndexEntry> indexEntriesToInvalidate = null;

      for (int i = 0; i < fileCount; i++) {
        final String url = input.readUTF();
        final long stamp = input.readLong();

        if (progress != null) {
          progress.setText2(url);
          progress.setFraction(((double)i) / fileCount);
        }

        boolean predefined = ourPredefinedFileNames.contains(url);
        boolean outdated = false;
        final JSIndexEntry value;

        if (!predefined) {
          VirtualFile relativeFile = VfsUtil.findRelativeFile(url, null);

          if (relativeFile == null || stamp != relativeFile.getTimeStamp()) {
            outdated = true;
          }

          PsiFile psiFile = relativeFile != null ? manager.findFile(relativeFile):null;
          if (!(psiFile instanceof PsiFile)) {
            outdated = true;
          }

          if (relativeFile != null && !outdated) {
            Module module = ProjectRootManager.getInstance(myProject).getFileIndex().getModuleForFile(relativeFile);

            if (module == null) {
              boolean ancestorOfUsedJdk = false;

              for(VirtualFile file:setOfExternalDefsRoots) {
                if (VfsUtil.isAncestor(file, relativeFile,true)) {
                  ancestorOfUsedJdk = true;
                }
              }

              outdated = !ancestorOfUsedJdk;
            }
          }

          final VirtualFile effectiveVirtualFile = outdated ? null : relativeFile;
          value = relativeFile != null && SWC_EXTENSION.equals(relativeFile.getExtension())?
                  new SwcJSIndexEntry(context, effectiveVirtualFile) :
                  new JSIndexEntry(context, effectiveVirtualFile);
        } else {
          value = new PredefinedJSIndexEntry(context, url);
        }

        if (!outdated) {
          ((predefined)?myPredefinedJavaScriptFiles:myJavaScriptFiles).put(url, value);
        } else {
          if (indexEntriesToInvalidate == null) indexEntriesToInvalidate = new ArrayList<JSIndexEntry>(5);
          indexEntriesToInvalidate.add(value); // we delay invalidation since it might cause package structure corruption
        }
      }

      if (indexEntriesToInvalidate != null) {
        for(JSIndexEntry entry:indexEntriesToInvalidate) entry.invalidate(myProject);
      }
      rebuildCachesRequested = false;
    } 
    catch (IOException e) {
      
    } finally {
      if (input != null) {
        try {
          input.close();
        }
        catch (IOException e1) {}
      }

      if (rebuildCachesRequested) {
        cacheFile.delete();
        clear();
      }

      if (progress != null && loadingCachesStarted) {
        progress.popState();
      }
      
      initPredefines(progress);
    }
  }

  private File getCacheLocation(final String dirName) {
    final String cacheFileName = myProject.getName() + "." + myProject.getLocationHash();
    return new File(PathManager.getSystemPath() + File.separator + dirName + File.separator + cacheFileName);
  }

  public synchronized void saveCaches() {
    final File cacheFile = getCacheLocation(JS_CACHES_DIR_NAME);
    FileUtil.createParentDirs(cacheFile);
    DataOutputStream output = null;

    try {
      output = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(cacheFile)));
      SerializationContext context = new SerializationContext(output, myProject, myJavaScriptFiles.size());

      enumerateNames(myPredefinedJavaScriptFiles, context);
      enumerateNames(myJavaScriptFiles, context);
      myRootPackage.enumerateNames(context); // we need to enumerate packages AFTER passing all entries since revalidation of old files cause package update

      output.writeByte(CURRENT_VERSION);
      output.writeInt(context.getFilesCount() + myPredefinedJavaScriptFiles.size());

      int namesCount = context.myNames.size();
      output.writeInt(namesCount);

      TObjectIntIterator<String> iterator = context.myNames.iterator();
      while(iterator.hasNext()) {
        iterator.advance();
        output.writeUTF(iterator.key());
        output.writeInt(iterator.value());
        --namesCount;
      }

      assert namesCount == 0;

      myRootPackage.serialize(context);
      writeEntries(myPredefinedJavaScriptFiles, output, context);
      writeEntries(myJavaScriptFiles, output, context);
      output.close();
    }
    catch (IOException e) {
      LOG.debug(e);
      if (output != null) {
        try {
          output.close();
          output = null;
        }
        catch (IOException e1) {}
      }
      cacheFile.delete();
    } finally {
      if (output != null) {
        try {
          output.close();
        }
        catch (IOException e1) {}
      }
    }
  }

  private static void writeEntries(final Map<String, JSIndexEntry> entries, final DataOutputStream output, final SerializationContext context)
    throws IOException {
    for (final String key : entries.keySet()) {
      final JSIndexEntry value = entries.get(key);
      if (!value.isUpToDate()) continue;

      output.writeUTF(key);
      output.writeLong(value.getTimeStamp());

      value.write(context);
    }
  }

  private void enumerateNames(final Map<String, JSIndexEntry> entries, final SerializationContext context) {
    for (Iterator<JSIndexEntry> i = entries.values().iterator(); i.hasNext();) {
      JSIndexEntry value = i.next();

      if (!value.isUpToDate()) {
        value.invalidate();
        myFilesToUpdate.remove(value);
        context.decFileCount();
        i.remove();
        continue;
      }
      value.enumerateNames(context);
    }
  }

  private PsiFile createPredefinesFromModel(final String fileName) {
    final JSIndexEntry value = new PredefinedJSIndexEntry(fileName, myProject, false);
    myPredefinedJavaScriptFiles.put(fileName, value);
    value.initTypesAndBrowserSpecifics();
    return value.getFile();
  }

  private void fileAdded(final VirtualFile fileOrDir) {
    if (isAcceptableFile(fileOrDir) && !myProject.isDisposed()) {
      processFileAdded(fileOrDir);
    }
  }

  // invoked via reflection
  private void fileRemoved(final VirtualFile fileOrDir) {
    if (isAcceptableFile(fileOrDir)) {
      if (!myProject.isDisposed()) processFileRemoved(fileOrDir);
    }
  }

  // invoked via reflection
  private void fileChanged(final VirtualFile fileOrDir) {
    if (isAcceptableFile(fileOrDir) && !myProject.isDisposed()) {
      processFileChanged(fileOrDir);
    }
  }

  public void projectClosed() {
    if (myFileListener != null) {
      VirtualFileManager.getInstance().removeVirtualFileListener( myFileListener );
      PsiManager.getInstance(myProject).removePsiTreeChangeListener(myTreeChangeListener);

      myConnection.disconnect();

      if (!ApplicationManager.getApplication().isUnitTestMode()) {
        saveCaches();
      }

      myFileListener = null;
    }
    clear();
  }

  public synchronized void processFileAdded(final VirtualFile file) {
    final String url = file.getPath();

    if (myOldJavaScriptFiles != null) {
      final JSIndexEntry jsIndexEntry = myOldJavaScriptFiles.get(url);

      if (jsIndexEntry != null) {
        myJavaScriptFiles.put(url,jsIndexEntry);
        myOldJavaScriptFiles.remove(url);
        return;
      }
    }

    final ProgressIndicator progress = ProgressManager.getInstance().getProgressIndicator();
    if (progress != null) {
      progress.setText2(file.getPresentableUrl());
    }

    if (!myJavaScriptFiles.contains(url)) {
      final JSIndexEntry value = SWC_EXTENSION.equals(file.getExtension()) ?
                                 new SwcJSIndexEntry(file, myProject, !myDoingFilesRescan) :
                                 new JSIndexEntry(file, myProject, !myDoingFilesRescan);
      final JSIndexEntry indexEntry = myJavaScriptFiles.put(url, value);  // psi file event child (file) created after virtual file event file created might cause duplication of index entries 
      if (!myDoingFilesRescan && indexEntry == null) myFilesToUpdate.add(value);
    }
  }

  private synchronized void processFileChanged(final VirtualFile file) {
    final JSIndexEntry indexEntry = myJavaScriptFiles.get(file.getPath());

    if (indexEntry == null) {
      processFileAdded(file);
    } else {
      myFilesToUpdate.add(indexEntry);
    }
  }

  private synchronized void processFileRemoved(final @NotNull VirtualFile file) {
    final JSIndexEntry jsIndexEntry = myJavaScriptFiles.remove(file.getPath());
    if (jsIndexEntry != null) {
      jsIndexEntry.invalidate();
      myFilesToUpdate.remove(jsIndexEntry);
    }
  }

  @NonNls
  public String getComponentName() {
    return "JavaScriptIndex";
  }

  public void initComponent() {
  }

  public void disposeComponent() {
  }

  public static JavaScriptIndex getInstance(final Project project) {
    return project.getComponent(JavaScriptIndex.class);
  }

  public synchronized String[] getSymbolNames() {
    updateDirtyFiles();
    final Set<String> symbolNames = new HashSet<String>();
    for(JSIndexEntry entry: myPredefinedJavaScriptFiles.values()) {
      entry.fillSymbolNames(symbolNames);
    }
    for(JSIndexEntry entry: myJavaScriptFiles.values()) {
      entry.fillSymbolNames(symbolNames);
    }
    return symbolNames.toArray(new String[symbolNames.size()]);
  }

  public synchronized NavigationItem[] getSymbolsByName(final String name) {
    final Set<NavigationItem> symbolNavItems = new HashSet<NavigationItem>();
    for(JSIndexEntry entry: myJavaScriptFiles.values()) {
      entry.fillSymbolsByName(name, symbolNavItems);
    }
    return symbolNavItems.toArray(new NavigationItem[symbolNavItems.size()]);
  }

  public synchronized void clear() {
    myJavaScriptFiles.clear();
    myPredefinedJavaScriptFiles.clear();
    JSTypeEvaluateManager.getInstance(myProject).clear();
    BrowserSupportManager.getInstance(myProject).clear();

    myIndex2Names.clear();
    myNames2Index.clear();
    myRootPackage.clear();
    myFilesToUpdate.clear();
    myQNameResolveResult.clear();
  }

  public synchronized void processAllSymbols(JavaScriptSymbolProcessor processor) {
    assert processor.getBaseFile() != null;
    boolean ecmaL4 = processor.getBaseFile().getLanguageDialect() == JavaScriptSupportLoader.ECMA_SCRIPT_L4;

    for(Map.Entry<String,JSIndexEntry> entry: myPredefinedJavaScriptFiles.entrySet()) {
      if (ecmaL4 && entry.getValue().getFile().getLanguageDialect() != JavaScriptSupportLoader.ECMA_SCRIPT_L4 ) continue;
      entry.getValue().processSymbolsNoLock(processor);
    }

    final PsiFile psiFile = processor.getBaseFile();
    VirtualFile virtualFile = psiFile.getVirtualFile();
    if (virtualFile == null && psiFile.getOriginalFile() != null) {
      virtualFile = psiFile.getOriginalFile().getVirtualFile();
    }

    if (virtualFile == null) return;
    final ProjectFileIndex fileIndex = ProjectRootManager.getInstance(myProject).getFileIndex();

    final Module moduleForFile = fileIndex.getModuleForFile(virtualFile);
    boolean seenEntryForFile = moduleForFile != null;

    if (moduleForFile != null) {
      final Module[] dependencies = ModuleRootManager.getInstance(moduleForFile).getDependencies();
      final Set<Module> modules = new java.util.HashSet<Module>(dependencies.length + 1);
      modules.addAll(Arrays.asList(dependencies));
      modules.add(moduleForFile);

      FlexFacet flexFacet = ecmaL4 ? FacetManager.getInstance(moduleForFile).getFacetByType(FlexFacet.ID):null;
      VirtualFile flexPath = null;

      if (flexFacet != null && (flexPath = flexFacet.getConfiguration().getFlexPath()) == null) {
        flexFacet = null;
      }

      for(JSIndexEntry entry: myJavaScriptFiles.values()) {
        final VirtualFile file = entry.getVirtualFile();
        final Module moduleForEntryFile = fileIndex.getModuleForFile(file);

        if (moduleForEntryFile == null) {
          if (flexFacet != null && VfsUtil.isAncestor(flexPath, file, true)) {
            entry.processSymbolsNoLock(processor);
          }
        } else if (modules.contains(moduleForEntryFile)) {
          entry.processSymbolsNoLock(processor);
        }
      }
    } else {
      for(JSIndexEntry entry: myJavaScriptFiles.values()) {
        final VirtualFile file = entry.getVirtualFile();
        final Module moduleForEntryFile = fileIndex.getModuleForFile(file);

        if (moduleForEntryFile == null) { // TODO: this is not correct when more than one SDK defined
          entry.processSymbolsNoLock(processor);
          if (file == virtualFile) seenEntryForFile = true;
        }
      }
    }

    // JS files out of module contents (except sdks) + files that have js embedded / injected (htl / jsp) 
    if (( (!(psiFile instanceof JSFile) || (psiFile.getContext() != null && !ecmaL4)) && !isAcceptableFile(psiFile.getViewProvider().getVirtualFile())) ||
        (moduleForFile == null && !seenEntryForFile)) {
      getEntryForNonJavaScriptFile(psiFile).processSymbolsNoLock(processor);
    }
  }

  private void collectFilesUnderDirectory(final VirtualFile homeDirectory, final Collection<VirtualFile> additionalFiles, final boolean searchForSourceDir) {
    if (searchForSourceDir) {
      for(VirtualFile f:homeDirectory.getChildren()) {
        if (f.isDirectory()) {
          final String nameWOExtension = f.getNameWithoutExtension();
          if ("source".equals(nameWOExtension) ||
              "src".equals(nameWOExtension) ||
              "libs".equals(nameWOExtension)
             ) {
            collectFilesUnderDirectory(f, additionalFiles, false);
          } else {
            collectFilesUnderDirectory(f, additionalFiles, true);
          }
        }
      }
    } else {
      for(VirtualFile f:homeDirectory.getChildren()) {
        if (f.isDirectory()) {
          collectFilesUnderDirectory(f, additionalFiles, false);
        } else if (( isAcceptableFile(f) &&
                     myJavaScriptFiles.get(f.getPath()) == null
                   )
                  ) {
          additionalFiles.add(f);
        }
      }
    }
  }

  private static JSIndexEntry getEntryForNonJavaScriptFile(final PsiFile psiFile) {
    JSIndexEntry ourEntry = psiFile.getUserData(ourEntryKey);

    if (ourEntry == null) {
      ourEntry = new JSIndexEntry(psiFile, psiFile.getProject(), false);
      psiFile.putUserData(ourEntryKey, ourEntry);
      ourEntry.setContentBelongsOnlyToMyFile();
    }
    return ourEntry;
  }

  public static boolean isFromPredefinedFile(final PsiFile containingFile) {
    return !containingFile.isPhysical() && containingFile.getUserData(JavaScriptIndex.PREDEFINED_JS_FILE_KEY) != null;
  }

  public JSPackage getDefaultPackage() {
    updateDirtyFiles();
    return myRootPackage;
  }

  private synchronized void updateDirtyFiles() {
    if (myFilesToUpdate != null) {
      THashSet<JSIndexEntry> entries = myFilesToUpdate;
      myFilesToUpdate = null;

      try {
        for(JSIndexEntry entry:entries) {
          final VirtualFile virtualfile = entry.getVirtualFile();
          if (!virtualfile.isValid()) continue; // may happen when js sources accessed from jar which was invalidated
          entry.getTopLevelNsNoLock();
        }
        entries.clear();
      }
      finally {
        myFilesToUpdate = entries;
      }
    }
  }

  public synchronized boolean inUpdateState() {
    return myFilesToUpdate == null;
  }

  public synchronized PsiElement findSymbolByFileAndNameAndOffset(final String fileName, final String name, final int offset) {
    JSIndexEntry indexEntry = myJavaScriptFiles.get(fileName);
    if (indexEntry == null) {
      String s = fileName;
      if (s.startsWith(PREDEFINES_PREFIX)) {
        s = fileName.substring(PREDEFINES_PREFIX.length());
        s = s.substring(0, s.length() - PREDEFINED_SCRIPTS_FILE_EXTENSION.length() + 1) + "xml";
      }
      indexEntry = myPredefinedJavaScriptFiles.get(s);
    }
    return findSymbolWithNameAndOffsetInEntryNoLock(getIndexOf(name), offset, indexEntry);
  }

  public synchronized PsiElement findSymbolWithNameAndOffsetInEntry(final int nameId, final int offset, final JSIndexEntry indexEntry) {
    return findSymbolWithNameAndOffsetInEntryNoLock(nameId, offset, indexEntry);
  }

  private PsiElement findSymbolWithNameAndOffsetInEntryNoLock(final int nameId, final int offset, final JSIndexEntry indexEntry) {
    if (indexEntry == null) return null;

    final PsiElement[] result = new PsiElement[1];

    indexEntry.processSymbolsNoLock(new JavaScriptSymbolProcessor.DefaultSymbolProcessor() {
      public PsiFile getBaseFile() {
        return indexEntry.getFile();
      }

      public int getRequiredNameId() {
        return nameId;
      }

      public final boolean process(PsiElement element, JSNamespace ns) {
        if (element.getTextOffset() == offset) {
          result[0] = element;
          return false;
        }
        return true;
      }
    });
    return result[0];
  }

  public synchronized JSIndexEntry getEntryForFile(final PsiFile file) {
    final VirtualFile vfile = file.getViewProvider().getVirtualFile();
    if (isAcceptableFile(vfile)) {
      final JSIndexEntry indexEntry = myJavaScriptFiles.get(vfile.getPath());
      if (indexEntry != null) return indexEntry;
    }
    return getEntryForNonJavaScriptFile(file);
  }

  public Project getProject() {
    return myProject;
  }

  private class JSTreeChangeListener extends PsiTreeChangeAdapter {
    public void childAdded(PsiTreeChangeEvent event) {
      final PsiElement child = event.getChild();
      if (child instanceof JSFile && child.isPhysical()) {
        processFileAdded(((JSFile)child).getVirtualFile());
      }
      else {
        process(event);
      }
    }

    public void childrenChanged(PsiTreeChangeEvent event) {
      process(event);
    }

    public void childRemoved(PsiTreeChangeEvent event) {
      if (event.getChild() instanceof JSFile) {
        processFileRemoved(((JSFile)event.getChild()).getVirtualFile());
      }
      else {
        process(event);
      }
    }

    public void childReplaced(PsiTreeChangeEvent event) {
      process(event);
    }

    private void process(final PsiTreeChangeEvent event) {
      final PsiElement psiElement = event.getParent();

      if (psiElement != null && psiElement.isValid()) {
        final PsiFile psiFile = psiElement.getContainingFile();

        if (psiFile instanceof JSFile && psiFile.isPhysical()) {
          final VirtualFile file = psiFile.getVirtualFile();
          if (file.isValid()) processFileChanged(file);
        }
      }
    }
  }

  public int getIndexOf(String s) {
    if (s == null) {
      return -1;
    }
    synchronized(this) {
      final int i = myNames2Index.get(s);
      if (i > 0) return i;
      final int value = myNames2Index.size() + 1;
      myNames2Index.put(s, value);
      myIndex2Names.put(value,s);
      return value;
    }
  }

  public String getStringByIndex(int i) {
    if (i == -1) return null;
    synchronized(this) {
      final String s = myIndex2Names.get(i);
      if (s != null) return s;
      throw new NoSuchElementException(""+i);
    }
  }

  private Map<String, PsiElement> myQNameResolveResult = new THashMap<String, PsiElement>();
  private long modificationStamp;

  public synchronized void setCachedClassByQName(final String link, final @NotNull PsiElement psiElement) {
    myQNameResolveResult.put(link, psiElement);
  }

  public synchronized @Nullable PsiElement getCachedClassByQName(final String link) {
    final long count = PsiManager.getInstance(myProject).getModificationTracker().getModificationCount();
    if (count != modificationStamp) {
      modificationStamp = count;
      myQNameResolveResult.clear();
      return null;
    }
    return myQNameResolveResult.get(link);
  }

}
