package com.intellij.lang.javascript.index;

import com.intellij.lang.javascript.psi.*;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiNamedElement;
import com.intellij.psi.xml.XmlAttributeValue;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NonNls;

/**
 * Created by IntelliJ IDEA.
 * User: yole
 * Date: 04.10.2005
 * Time: 20:37:40
 * To change this template use File | Settings | File Templates.
 */
public interface JavaScriptSymbolProcessor {
  void processFunction(JSNamespace namespace, final int nameId, JSNamedElement function);
  void processVariable(JSNamespace namespace, final int nameId, JSNamedElement variable);
  boolean acceptsFile(PsiFile file);
  PsiFile getBaseFile();

  void processProperty(final JSNamespace namespace, final int nameId, final JSNamedElement property);
  void processDefinition(final JSNamespace namespace, final int nameId, final JSNamedElement refExpr);

  int getRequiredNameId();
  void processTag(JSNamespace namespace, final int nameId, PsiNamedElement namedElement, @NonNls final String attrName);
}
