package com.intellij.lang.javascript.flex;

import com.intellij.facet.FacetConfiguration;
import com.intellij.facet.ui.*;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.fileChooser.FileChooserDialog;
import com.intellij.openapi.fileChooser.FileChooserFactory;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.TextFieldWithBrowseButton;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VfsUtil;
import com.intellij.util.Processor;
import com.intellij.lang.javascript.JSBundle;
import org.jdom.Element;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FlexFacetConfiguration implements FacetConfiguration {
  private VirtualFile flexPath;
  private static final String HOME_ATTR_NAME = "home";

  public FacetEditorTab[] createEditorTabs(final FacetEditorContext editorContext, final FacetValidatorsManager validatorsManager) {
    return new FacetEditorTab[] {new MyFlexFacetEditorTab(editorContext, validatorsManager)};
  }

  public void readExternal(final Element element) throws InvalidDataException {
    final String s = element.getAttributeValue(HOME_ATTR_NAME);
    flexPath = s != null ? LocalFileSystem.getInstance().findFileByPath(s) :null;
  }

  private static final String MXMLC_FILE_NAME = "mxmlc";

  public void writeExternal(final Element element) throws WriteExternalException {
    if (flexPath != null) element.setAttribute(HOME_ATTR_NAME, flexPath.getPath());
  }

  private static void processFilesUnderFlexRoot(VirtualFile file, final Processor<VirtualFile> processor) {

    if (file != null && file.isValid() && file.isDirectory()) {
      final VirtualFile child = file.findChild("bin");

      if (child != null && child.isDirectory()) {
        for(VirtualFile grandChild:child.getChildren()) {
          if (MXMLC_FILE_NAME.equals(grandChild.getNameWithoutExtension())) {
            if (!processor.process(grandChild)) return;
          }
        }
      }
    }
  }

  public void setFlexPath(@NotNull VirtualFile _flexPath) {
    flexPath = _flexPath;
  }

  public static void configureEditFieldForFlexSDKPath(final TextFieldWithBrowseButton editField, final Project project, final VirtualFile initial) {
    editField.getButton().addActionListener(new ActionListener() {
        public void actionPerformed(final ActionEvent e) {
          final FileChooserDescriptor descriptor = new FileChooserDescriptor(false, true, false, false,false,false) {
            public boolean isFileSelectable(final VirtualFile file) {
              if(super.isFileSelectable(file)) {
                final boolean[] result = new boolean[1];
                processFilesUnderFlexRoot(file, new Processor<VirtualFile>() {
                  public boolean process(final VirtualFile virtualFile) {
                    result[0] = true;
                    return false;
                  }
                });
                return result[0];
              }
              return false;
            }
          };
          final FileChooserDialog fileChooserDialog = FileChooserFactory.getInstance().createFileChooser(descriptor, project);

          final VirtualFile[] files = fileChooserDialog.choose(initial, project);
          if (files.length > 0) {
            editField.setText(files[0].getPath());
          }
        }
      });
  }

  public static abstract class FlexFacetEditorTab extends FacetEditorTab {
    protected TextFieldWithBrowseButton myPathToFlex;
    private JPanel myPanel;
    private JLabel myPathToFlexSDKLabel;

    public FlexFacetEditorTab(Project project, boolean sdkLabelVisible) {
      if (!sdkLabelVisible) myPathToFlexSDKLabel.setVisible(false);
      reset();

      configureEditFieldForFlexSDKPath(myPathToFlex, project, getFile());
    }

    public abstract VirtualFile getFile();
    public abstract void setFile(VirtualFile file);

    @Nls public String getDisplayName() {
      return "Flex !";
    }

    public JComponent createComponent() {
      return myPanel;
    }

    public boolean isModified() {
      final String s = myPathToFlex.getText();
      return getFile() != null ? !s.equals(getFile().getPath()):s.length() > 0;
    }

    public void apply() throws ConfigurationException {
      setFile(LocalFileSystem.getInstance().findFileByPath(myPathToFlex.getText()));
    }

    public void reset() {
      myPathToFlex.setText(getFile() != null ? getFile().getPath():"");
    }

    public void disposeUIResources() {
      myPanel = null;
      myPathToFlex = null;
    }

    public String getFlexUrl() {
      return myPathToFlex.getTextField().getText();
    }
  }

  public VirtualFile getFlexPath() {
    return flexPath;
  }

  public static boolean isFlexHome(final VirtualFile file) {
    final boolean[] result = new boolean[1];
    processFilesUnderFlexRoot(file, new Processor<VirtualFile>() {
      public boolean process(final VirtualFile virtualFile) {
        result[0] = true;
        return false;
      }
    });
    return result[0];
  }

  private class MyFlexFacetEditorTab extends FlexFacetEditorTab {
    public MyFlexFacetEditorTab(final FacetEditorContext editorContext, FacetValidatorsManager validatorsManager) {
      super(editorContext.getProject(), true);

      validatorsManager.registerValidator(new FacetEditorValidator() {
          public ValidationResult check() {
            final Object o = myPathToFlex.getTextField().getText();
            if (o != null) {
              final VirtualFile relativeFile = VfsUtil.findRelativeFile(o.toString(), null);
              if (relativeFile != null && isFlexHome(relativeFile)) return ValidationResult.OK;
            }
            return new ValidationResult(JSBundle.message("invalid.flex.sdk.path.message"));
          }
        }, myPathToFlex);
    }

    public VirtualFile getFile() {
        return flexPath;
      }

    public void setFile(final VirtualFile file) {
        flexPath = file;
      }
  }
}