/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi.resolve;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.index.*;
import com.intellij.lang.javascript.psi.*;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.Key;
import com.intellij.psi.*;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.psi.util.CachedValue;
import com.intellij.psi.util.CachedValueProvider;
import com.intellij.psi.util.PsiModificationTracker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * @author max
 */
public class JSResolveUtil {
  private JSResolveUtil() {}

  private static final Key<CachedValue<PsiElement[]>> ourFileElementsValueKey = Key.create("file.elements");

  @Nullable
  public static JSElement treeWalkUp(PsiScopeProcessor processor, PsiElement elt, PsiElement lastParent, PsiElement place) {
    return treeWalkUp(processor, elt, lastParent, place, null);
  }

  @Nullable
  public static JSElement treeWalkUp(PsiScopeProcessor processor, PsiElement elt, PsiElement lastParent, PsiElement place, PsiElement terminatingParent) {
    if (elt == null) return null;

    PsiElement parentElement = elt.getContext();
    if (parentElement instanceof JSDefinitionExpression) {
      parentElement = parentElement.getParent().getParent(); // when walking a| = b, start from enclosing statement
    } else if (parentElement instanceof JSVariable && !(elt instanceof JSFunctionExpression) && !(elt instanceof JSObjectLiteralExpression)) {
      // when walking from variable init start from enclosing statement (function expr / object literal could reference that could reference
      // var in this case, better to check for any scope change)
      parentElement = parentElement.getParent();
    }

    int index = -1;
    PsiElement[] children = PsiElement.EMPTY_ARRAY;

    if (parentElement instanceof JSFile) {
      children = getChildren(parentElement);
      index = 0;
      for(PsiElement el:children) {
        if (el == elt) break;
        ++index;
      }
    }

    PsiElement cur = elt;
    do {
      if (!cur.processDeclarations(processor, PsiSubstitutor.EMPTY, cur == elt ? lastParent : null, place)) {
        if (processor instanceof ResolveProcessor) {
          return ((ResolveProcessor)processor).getResult();
        }
      }
      if(cur instanceof PsiFile) break;
      if (terminatingParent == cur) {
        return null;
      }
      if (cur instanceof JSStatement && parentElement instanceof JSIfStatement) {
        // Do not try to resolve variables from then branch in else branch. 
        break;
      }

      if (index == -1) cur = cur.getPrevSibling();
      else {
        if (index != 0) cur = children[--index];
        else cur = null;
      }
    } while (cur != null);

    final JSElement func = processFunctionDeclarations(processor, parentElement);
    if (func != null) return func;

    if (parentElement instanceof JSFile) return null;

    return treeWalkUp(processor, parentElement, elt, place, terminatingParent);
  }

  private static PsiElement[] getChildren(final PsiElement element) {
    CachedValue<PsiElement[]> value = element.getUserData(ourFileElementsValueKey);

    if (value == null) {
      value = element.getManager().getCachedValuesManager().createCachedValue(new CachedValueProvider<PsiElement[]>() {
        public Result<PsiElement[]> compute() {
          return new Result<PsiElement[]>(element.getChildren(),element);
        }
      }, false);
      element.putUserData(ourFileElementsValueKey, value);
    }

    return value.getValue();
  }

  @Nullable
  private static JSElement processFunctionDeclarations(final @NotNull PsiScopeProcessor processor, final @Nullable PsiElement context) {
    PsiElement[] children = context instanceof JSFile ? getChildren(context) : null;

    if (context != null) {
      int index = children != null ? children.length - 1:-1;
      PsiElement cur = index >= 0 ? children[index]:context.getLastChild();

      while (cur != null) {
        if (cur instanceof JSFunction) {
          if (!processor.execute(cur, PsiSubstitutor.EMPTY)) {
            if (processor instanceof ResolveProcessor) {
              return ((ResolveProcessor)processor).getResult();
            }
          }
        }

        if (index == -1) {
          cur = cur.getPrevSibling();
        } else {
          if (index != 0) cur = children[--index];
          else cur = null;
        }
      }
    }
    return null;
  }

  public static boolean isReferenceTo(final PsiPolyVariantReference reference,
                                      final String referencedName, PsiElement _element) {
    String elementName = null;
    if (_element instanceof PsiNamedElement) elementName = ((PsiNamedElement)_element).getName();
    else if (_element instanceof XmlAttributeValue) elementName = ((XmlAttributeValue)_element).getValue();

    if (Comparing.equal(referencedName, elementName)) {
      PsiElement element = _element;
      if (element instanceof JSNamedElementProxy) element =((JSNamedElementProxy)element).getElement();
      final ResolveResult[] resolveResults = reference.multiResolve(true);

      for (ResolveResult r:resolveResults) {
        PsiElement psiElement = r.getElement();
        if (psiElement instanceof JSNamedElementProxy) psiElement = ((JSNamedElementProxy)psiElement).getElement();

        if (psiElement == element ||
            ((element instanceof JSProperty || element instanceof XmlAttributeValue) &&
             psiElement != null &&
             psiElement.getParent() == element)
           ) {
          return true;
        }

        if (psiElement instanceof JSFunctionExpression) {
          final ASTNode nameIdentifier = ((JSFunctionExpression)psiElement).getFunction().findNameIdentifier();
          if (nameIdentifier != null && nameIdentifier.getTreeParent().getPsi() == element) return true;
        }
      }
    }
    return false;
  }

  private static final Key<CachedValue<HashMap<String,ResolveResult[]>>> MY_RESOLVED_CACHED_KEY = Key.create("AllResolvedKey");

  public static ResolveResult[] resolve(final PsiFile file, WalkUpResolveProcessor processor) {
    if (file == null) return ResolveResult.EMPTY_ARRAY;

    CachedValue<HashMap<String,ResolveResult[]>> cache = file.getUserData(MY_RESOLVED_CACHED_KEY);
    if (cache == null) {
      cache = file.getManager().getCachedValuesManager().createCachedValue(
        new CachedValueProvider<HashMap<String,ResolveResult[]>>() {
          public Result<HashMap<String, ResolveResult[]>> compute() {
            return new Result<HashMap<String,ResolveResult[]>>(
              new HashMap<String, ResolveResult[]>(),
              PsiModificationTracker.MODIFICATION_COUNT
            );
          }
        }, false
      );
      file.putUserData(MY_RESOLVED_CACHED_KEY,cache);
    }

    final HashMap<String, ResolveResult[]> resultsMap = cache.getValue();
    final String text = processor.getText();
    ResolveResult[] results = resultsMap.get(text);
    if (results != null) return results;

    JavaScriptIndex.getInstance(file.getProject()).processAllSymbols( processor );

    results = processor.getResults();
    resultsMap.put(text,results);
    return results;
  }

  public static void clearResolveCaches(final PsiFile file) {
    file.putUserData(MY_RESOLVED_CACHED_KEY, null);
  }

  public static class MyResolveResult implements ResolveResult {
    private final PsiElement myFunction;

    public MyResolveResult(final PsiElement function) {
      myFunction = function;
    }

    public PsiElement getElement() {
      //if (myFunction instanceof JSNamedElementProxy) return ((JSNamedElementProxy)myFunction).getElement();
      return myFunction;
    }

    public boolean isValidResult() { return true; }
  }
}
