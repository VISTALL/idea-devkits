/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi.resolve;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.flex.FlexImportSupport;
import com.intellij.lang.javascript.flex.XmlBackedJSClassImpl;
import com.intellij.lang.javascript.index.*;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.impl.JSClassBase;
import com.intellij.lang.javascript.psi.impl.JSChangeUtil;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ProjectFileIndex;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.UserDataCache;
import com.intellij.openapi.vfs.VfsUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.*;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.psi.util.*;
import com.intellij.psi.xml.*;
import com.intellij.testFramework.LightVirtualFile;
import com.intellij.util.IncorrectOperationException;
import com.intellij.util.containers.ConcurrentHashMap;
import com.intellij.util.text.StringTokenizer;
import com.intellij.xml.XmlElementDescriptor;
import gnu.trove.THashMap;
import gnu.trove.TIntObjectHashMap;
import gnu.trove.TIntObjectIterator;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author max, maxim.mossienko
 */
public class JSResolveUtil {
  private static final Key<CachedValue<TIntObjectHashMap<Object>>> MY_CACHED_STATEMENTS = Key.create("JS.RelevantStatements");
  private static UserDataCache<CachedValue<TIntObjectHashMap<Object>>, JSElement, Object> ourCachedDefsCache = new RelevantDefsUserDataCache();
  @NonNls private static final String PROTOTYPE_FIELD_NAME = "prototype";

  public static final Key<CachedValue<Map<String, Object>>> ourImportListCache = Key.create("js.import.list.cache");

  public static final UserDataCache<CachedValue<Map<String, Object>>,PsiElement, Object> myImportListCache =
    new ImportListDataCache();

  public static final Key<CachedValue<Map<String, PsiElement>>> ourImportResolveCache = Key.create("js.import.resolve");

  public static final UserDataCache<CachedValue<Map<String, PsiElement>>,PsiElement, Object> myImportResolveCache =
    new UserDataCache<CachedValue<Map<String, PsiElement>>, PsiElement, Object>() {
      protected CachedValue<Map<String, PsiElement>> compute(final PsiElement psiElement, final Object p) {
        return psiElement.getManager().getCachedValuesManager().createCachedValue(new CachedValueProvider<Map<String, PsiElement>>() {
          public Result<Map<String, PsiElement>> compute() {
            return new Result<Map<String, PsiElement>>(new ConcurrentHashMap<String, PsiElement>(), psiElement);
          }
        }, false);
      }
    };

  @NonNls public static final String PROTOTYPE = "prototype";

  public static void processInjectedFileForTag(final @NotNull XmlTag tag, @NotNull JSInjectedFilesVisitor visitor) {
    for(XmlTagChild child:tag.getValue().getChildren()) {
      if (child instanceof XmlText) {
        ((PsiLanguageInjectionHost)child).processInjectedPsi(visitor);
      }
    }
  }

  public static String findPackageForMxml(final PsiElement expression) {
    String s = null;
    final PsiFile containingFile = expression.getContainingFile();

    if (containingFile.getLanguageDialect() == JavaScriptSupportLoader.ECMA_SCRIPT_L4 && containingFile.getContext() != null) {
      final PsiFile contextContainigFile = containingFile.getContext().getContainingFile();
      VirtualFile file = contextContainigFile.getVirtualFile();
      if (file == null && contextContainigFile.getOriginalFile() != null) file = contextContainigFile.getOriginalFile().getVirtualFile();

      s = getExpectedPackageNameFromFile(file, containingFile.getProject(), true);
    }
    return s;
  }

  public static String getExpectedPackageNameFromFile(final VirtualFile file, Project project, boolean allowEvaluationFromContextRoot) {
    final ProjectFileIndex projectFileIndex = ProjectRootManager.getInstance(project).getFileIndex();
    final Module moduleForFile = file != null ? projectFileIndex.getModuleForFile(file):null;

    if (moduleForFile != null) {
      VirtualFile rootForFile = projectFileIndex.getSourceRootForFile(file);
      if (rootForFile == null && allowEvaluationFromContextRoot) rootForFile = projectFileIndex.getContentRootForFile(file);

      if (rootForFile != null) {
        return VfsUtil.getRelativePath(file.getParent(), rootForFile, '.');
      }
    }
    return null;
  }

  public static String getExpressionType(final JSExpression expression, final PsiFile containingFile) {
    String type = null;

    if (expression != null) {
      final BaseJSSymbolProcessor.SimpleTypeProcessor processor = new BaseJSSymbolProcessor.SimpleTypeProcessor(true);
      BaseJSSymbolProcessor.doEvalForExpr(expression, containingFile, processor);
      type = processor.getType();
    }

    if (type == null) type = "*";
    else {
      String shortName = type.substring(type.lastIndexOf('.') + 1);
      final JSReferenceExpression expr = resolveTypeNameUsingImports(shortName, containingFile);
      if (expr != null) {
        type = shortName;
      }
    }
    return type;
  }

  public static boolean tryResolveImports(final PsiScopeProcessor processor, PsiNamedElement parent, @NotNull PsiElement place) {
    if (!isAdequatePlaceForImport(parent, place)) return true;

    return !importClass(processor, parent);
  }

  public static boolean importClass(final PsiScopeProcessor processor, final PsiNamedElement file) {
    if(processor instanceof ResolveProcessor && ((ResolveProcessor)processor).isLocalResolve()) return false;
    final String s = ((ResolveProcessor)processor).getName();

    if (s != null) {
      final JSReferenceExpression expression = resolveTypeNameUsingImports(s, file);
      if (expression != null) {
        final PsiElement element = JSClassBase.findClassFromNamespace(expression.getText(), JavaScriptIndex.getInstance(file.getProject()));
        if (element != null) return !processor.execute(element,PsiSubstitutor.UNKNOWN);
      }
    } else {
      final String packageQualifierText = findPackageStatementQualifier(file);
      final FlexImportSupport.MxmlFilesProcessor filesProcessor = new FlexImportSupport.MxmlFilesProcessor() {
        final PsiManager manager = PsiManager.getInstance(file.getProject());

        public void addDependency(final PsiDirectory directory) {
        }

        public boolean processFile(final VirtualFile file) {
          final PsiFile xmlFile = manager.findFile(file);
          if (!(xmlFile instanceof XmlFile)) return true;
          return processor.execute(XmlBackedJSClassImpl.getXmlBackedClass((XmlFile)xmlFile), PsiSubstitutor.EMPTY);
        }
      };

      if (packageQualifierText != null && packageQualifierText.length() > 0) {
        FlexImportSupport.processMxmlFilesInPackage(null, file.getProject(), packageQualifierText, filesProcessor);
      }

      FlexImportSupport.processMxmlFilesInPackage(null, file.getProject(), "", filesProcessor);
    }

    return false;
  }

  public static boolean isAdequatePlaceForImport(final PsiNamedElement parent, @NotNull PsiElement place) {
    if (parent instanceof JSFile && ((JSFile)parent).getLanguageDialect() != JavaScriptSupportLoader.ECMA_SCRIPT_L4) {
      return false;
    }

    final PsiElement placeParent = place.getParent();
    PsiElement grandParent;

    if (!(place instanceof JSReferenceExpression) ||
        (placeParent instanceof JSReferenceExpression &&
         !((grandParent = placeParent.getParent()) instanceof JSCallExpression) &&
         !(grandParent instanceof JSDefinitionExpression)
        )) {
      if (!(place instanceof JSFile)) return false;
    }
    return true;
  }

  public static PsiElement getClassReferenceForXmlFromContext(PsiElement parent) {
    final PsiElement context = parent.getContext();
    if(context != null) {
      final PsiFile containingFile = context.getContainingFile();
      if (containingFile instanceof XmlFile) parent = XmlBackedJSClassImpl.getXmlBackedClass((XmlFile)containingFile);
    }
    return parent;
  }

  public static abstract class JSInjectedFilesVisitor implements PsiLanguageInjectionHost.InjectedPsiVisitor {
    public void visit(@NotNull final PsiFile injectedPsi, @NotNull final List<PsiLanguageInjectionHost.Shred> places) {
      if (injectedPsi instanceof JSFile) {
        process((JSFile)injectedPsi);
      }
    }

    protected abstract void process(JSFile file);
  }

  @NonNls public static final String OBJECT_CLASS_NAME = "Object";

  private JSResolveUtil() {}

  private static final Key<CachedValue<PsiElement[]>> ourFileElementsValueKey = Key.create("file.elements");

  @Nullable
  public static void treeWalkUp(PsiScopeProcessor processor, PsiElement elt, PsiElement lastParent, PsiElement place) {
    treeWalkUp(processor, elt, lastParent, place, null, null);
  }

  @Nullable
  public static void treeWalkUp(PsiScopeProcessor processor, PsiElement elt, PsiElement lastParent, PsiElement place,
                                     PsiElement terminatingParent) {
    treeWalkUp(processor, elt, lastParent, place, terminatingParent, null);
  }

  @Nullable
  private static void treeWalkUp(final PsiScopeProcessor processor, PsiElement elt, PsiElement lastParent, PsiElement place,
                                     PsiElement terminatingParent, PsiElement currentScope) {
    if (elt == null) return;

    PsiElement parentElement = elt.getContext();
    if (elt instanceof JSFunction || elt instanceof JSObjectLiteralExpression) {
      currentScope = elt;
    }
    
    if (parentElement instanceof JSDefinitionExpression ||
        (parentElement instanceof JSAssignmentExpression && !(elt instanceof JSFunctionExpression))) {
      if (elt == terminatingParent) {
        return;
      }
      elt = parentElement.getParent();
      parentElement = elt.getParent(); // when walking a| = b, start from enclosing statement
      if (parentElement instanceof JSExpressionStatement) {
        elt = parentElement;
        parentElement = parentElement.getParent();
      }
      currentScope = elt;
    } else if (parentElement instanceof JSVariable && currentScope == null) {
      // when walking from variable init start from enclosing statement (function expr / object literal could reference that could reference
      // var in this case, better to check for any scope change)
      currentScope = parentElement;
      parentElement = parentElement.getParent();
    }

    final boolean parentIsClass = parentElement instanceof JSClass;
    int index = -1;
    PsiElement[] children = getChildren(parentElement);

    if (children != null && children.length > 0) {
      index = 0;
      for(PsiElement el:children) {
        if (el == elt) break;
        ++index;
      }
    }

    PsiElement cur = elt;
    do {
      if (!cur.processDeclarations(processor, PsiSubstitutor.EMPTY, cur == elt ? lastParent : null, place)) {
        if (processor instanceof ResolveProcessor) {
          return;
        }
      }
      if (terminatingParent == cur) {
        return;
      }
      if(cur instanceof PsiFile || parentIsClass) break;
      if (cur instanceof JSStatement && parentElement instanceof JSIfStatement) {
        // Do not try to resolve variables from then branch in else branch. 
        break;
      }

      if (index == -1) cur = cur.getPrevSibling();
      else {
        if (index != 0) cur = children[--index];
        else cur = null;
      }
    } while (cur != null);

    final JSElement func = parentIsClass ? null:processFunctionDeclarations(processor, parentElement);
    if (func != null) return;

    if (elt instanceof PsiFile) {
      if (elt instanceof XmlFile) {
        final XmlFile xmlFile = (XmlFile)elt;
        final XmlDocument document = xmlFile.getDocument();
        final XmlTag rootTag = document != null ? document.getRootTag():null;
        final String rootNs = rootTag != null ? rootTag.getNamespace():null;

        if (JavaScriptSupportLoader.MXML_URI.equals(rootNs) ||
            JavaScriptSupportLoader.MXML_URI2.equals(rootNs)
           ) {
          processAllGlobals(processor, xmlFile, place);
        } else {
          if (rootTag != null && xmlFile.getFileType() == StdFileTypes.XML) { // TODO this is bindows specific
            processAllGlobals(processor, xmlFile, place);
          }
        }
      } else if (elt instanceof JSFile && parentElement != null) {
        parentElement = parentElement.getContainingFile();
      }

      if (parentElement == null) return;
    }

    treeWalkUp(processor, parentElement, elt, place, terminatingParent, currentScope);
  }

  public static boolean processAllGlobals(final PsiScopeProcessor processor, final XmlFile xmlFile, final PsiElement place) {
    JSClass clazz = XmlBackedJSClassImpl.getXmlBackedClass(xmlFile);
    if (!clazz.processDeclarations(processor, PsiSubstitutor.EMPTY, clazz, place)) return false;
    return true;
  }

  private static PsiElement[] getChildren(final PsiElement element) {
    if (!(element instanceof JSFile) &&
        (!(element instanceof JSBlockStatement) || !(element.getParent() instanceof JSNamedElement))) return null;
    CachedValue<PsiElement[]> value = element.getUserData(ourFileElementsValueKey);

    if (value == null) {
      value = element.getManager().getCachedValuesManager().createCachedValue(new CachedValueProvider<PsiElement[]>() {
        public Result<PsiElement[]> compute() {
          return new Result<PsiElement[]>(element.getChildren(),element);
        }
      }, false);
      element.putUserData(ourFileElementsValueKey, value);
    }

    return value.getValue();
  }

  @Nullable
  private static JSElement processFunctionDeclarations(final @NotNull PsiScopeProcessor processor, final @Nullable PsiElement context) {
    if (!(context instanceof JSElement)) return null;
    PsiElement[] children = getChildren(context);

    if (context != null) {
      int index = children != null ? children.length - 1:-1;
      PsiElement cur = index >= 0 ? children[index]:context.getLastChild();

      while (cur != null) {
        if (cur instanceof JSFunction || cur instanceof JSClass) {
          if (!processor.execute(cur, PsiSubstitutor.EMPTY)) {
            if (processor instanceof ResolveProcessor) {
              return ((ResolveProcessor)processor).getResult();
            }
          }
        }

        if (index == -1) {
          cur = cur.getPrevSibling();
        } else {
          if (index != 0) cur = children[--index];
          else cur = null;
        }
      }
    }
    return null;
  }

  public static boolean isReferenceTo(final PsiPolyVariantReference reference,
                                      final String referencedName, PsiElement _element) {
    String elementName = null;
    if (_element instanceof JSNamedElement) elementName = ((PsiNamedElement)_element).getName();
    else if (_element instanceof XmlAttributeValue) elementName = ((XmlAttributeValue)_element).getValue();
    else if (_element instanceof XmlFile) elementName = ((XmlFile)_element).getVirtualFile().getNameWithoutExtension();
    else return false;

    if (Comparing.equal(referencedName, elementName)) {
      PsiElement element = _element;
      if (element instanceof JSNamedElementProxy) element =((JSNamedElementProxy)element).getElement();
      final ResolveResult[] resolveResults = reference.multiResolve(true);

      for (ResolveResult r:resolveResults) {
        PsiElement psiElement = r.getElement();
        if (psiElement instanceof JSNamedElementProxy) psiElement = ((JSNamedElementProxy)psiElement).getElement();

        if (psiElement == element ||
            ((element instanceof JSProperty || element instanceof XmlAttributeValue) &&
             psiElement != null &&
             psiElement.getParent() == element)
           ) {
          if (reference instanceof JSReferenceExpression &&
              ( (((JSReferenceExpression)reference).getParent() == psiElement && psiElement instanceof JSDefinitionExpression) ||
                psiElement instanceof JSFunctionExpression &&
                ((JSFunctionExpression)psiElement).getFunction().findNameIdentifier().getTreeParent().getPsi() == reference
              )
            ) {
            return false; // do not include self to usages
          }

          return true;
        }

        if (psiElement instanceof JSFunctionExpression) {
          final ASTNode nameIdentifier = ((JSFunctionExpression)psiElement).getFunction().findNameIdentifier();
          if (nameIdentifier != null && nameIdentifier.getTreeParent().getPsi() == element) return true;
        } else if (psiElement instanceof JSFunction && element instanceof JSClass && psiElement.getParent() == element) {
          return true;
        } else if (psiElement instanceof JSClass && element instanceof JSFunction && element.getParent() == psiElement) {
          return true;
        } else if (psiElement instanceof JSClass && element instanceof XmlFile && psiElement.getParent() == element) {
          return true;
        }
      }
    }
    return false;
  }

  private static final Key<CachedValue<Map<PsiPolyVariantReference,ResolveResult[]>>> MY_RESOLVED_CACHED_KEY = Key.create("JS.AllResolvedKey");
  private static UserDataCache<CachedValue<Map<PsiPolyVariantReference,ResolveResult[]>>, PsiFile, Object> ourCachedResolveCache =
    new UserDataCache<CachedValue<Map<PsiPolyVariantReference,ResolveResult[]>>, PsiFile, Object>() {

      protected CachedValue<Map<PsiPolyVariantReference, ResolveResult[]>> compute(PsiFile file, Object o) {
        return file.getManager().getCachedValuesManager().createCachedValue(
          new CachedValueProvider<Map<PsiPolyVariantReference,ResolveResult[]>>() {
            public Result<Map<PsiPolyVariantReference, ResolveResult[]>> compute() {
              return new Result<Map<PsiPolyVariantReference,ResolveResult[]>>(
                Collections.synchronizedMap(new HashMap<PsiPolyVariantReference, ResolveResult[]>()),
                PsiModificationTracker.MODIFICATION_COUNT
              );
            }
          }, false
        );
      }
    };

  public static @Nullable JSExpression getRealRefExprQualifier(final JSReferenceExpression expr) {
    final JSExpression qualifier = expr.getQualifier();
    if (qualifier != null) return qualifier;

    if (isExprInTypeContext(expr)) {
      final JSReferenceExpression resolved = resolveTypeNameUsingImports(expr);
      return resolved.getQualifier();
    }
    return qualifier;
  }

  public static String findPackageStatementQualifier(final PsiElement context) {
    if (context instanceof JSClass) {
      final String s = ((JSClass)context).getQualifiedName();
      if (s != null) {
        final int i = s.lastIndexOf('.');
        if (i != -1) return s.substring(0, i);
        else return null;
      }
    }

    ASTNode packageNameNode = null;
    final JSPackageStatement packageStatement = PsiTreeUtil.getNonStrictParentOfType(context, JSPackageStatement.class);

    if (packageStatement != null) {
      packageNameNode = packageStatement.findNameIdentifier();
    }

    if (packageNameNode == null) return null;

    return packageNameNode.getText();
  }

  public static boolean isExprInTypeContext(final JSReferenceExpression expr) {
    final PsiElement parent = expr.getParent();
    boolean parentIsVar;

    return ( ( (parentIsVar = (parent instanceof JSVariable)) ||
               parent instanceof JSFunction
             ) && parent.getNode().findChildByType(JSTokenTypes.COLON) != null &&
             (!parentIsVar || ((JSVariable)parent).getInitializer() != expr)
           ) ||
           parent instanceof JSNewExpression ||
           parent instanceof JSAttributeList ||
           parent instanceof JSUseNamespaceDirective ||
           (parent instanceof JSBinaryExpression &&
            ((JSBinaryExpression)parent).getROperand() == expr &&
            ( ((JSBinaryExpression)parent).getOperationSign() == JSTokenTypes.IS_KEYWORD ||
              ((JSBinaryExpression)parent).getOperationSign() == JSTokenTypes.AS_KEYWORD
            )   
           ) ||
        parent instanceof JSReferenceList
      ;
  }

  public static PsiElement findClassByQName(final String link, final JavaScriptIndex index) {
    JSPackage jsPackage;
    
    synchronized (index) {
      PsiElement element = index.getCachedClassByQName(link);
      if (element != null) return element == PsiUtil.NULL_PSI_ELEMENT ? null:element;

      jsPackage = index.getDefaultPackage();
      StringTokenizer tokenizer = new StringTokenizer(link, ".");
      String className = null;

      while(tokenizer.hasMoreElements()) {
        String nextElement = tokenizer.nextElement();
        if (className != null) jsPackage = jsPackage.findPackageWithNameId(index.getIndexOf(className));
        if (jsPackage == null) return null;
        className = nextElement;
      }

      final int classNameIndex = index.getIndexOf(className);
      final PsiElement[] result = new PsiElement[1];

      jsPackage.processDeclarations(new JavaScriptSymbolProcessor.DefaultSymbolProcessor() {
        protected boolean process(final PsiElement namedElement, final JSNamespace namespace) {
          result[0] = namedElement;
          return namedElement.getContainingFile().getVirtualFile() == null;
        }

        public PsiFile getBaseFile() {
          return null;
        }

        public int getRequiredNameId() {
          return classNameIndex;
        }
      });

      if (result[0] == null) {
        final String className1 = className;
        final int index1 = link.indexOf(className) - 1;
        FlexImportSupport.processMxmlFilesInPackage(
          null,
          index.getProject(),
          index1 > 0? link.substring(0, index1):"",
          new FlexImportSupport.MxmlFilesProcessor() {
            public void addDependency(final PsiDirectory directory) {
            }

            public boolean processFile(final VirtualFile file) {
              if (file.getNameWithoutExtension().equals(className1)) {
                result[0] = XmlBackedJSClassImpl.getXmlBackedClass((XmlFile)PsiManager.getInstance(index.getProject()).findFile(file));
                return false;
              }
              return true;
            }
          }
        );
      }
      final PsiElement psiElement = result[0];
      index.setCachedClassByQName(link, psiElement != null ? psiElement : PsiUtil.NULL_PSI_ELEMENT);
      return psiElement;
    }
  }

  public static JSPackage findPackageByReference(final JSReferenceExpression referenceExpression, JavaScriptIndex index) {
    final String str = referenceExpression.getText();
    return findPackageByText(index, str);
  }

  public static JSPackage findPackageByText(final JavaScriptIndex index, final String str) {
    JSPackage jsPackage;

    synchronized (index) {
      jsPackage = index.getDefaultPackage();
      StringTokenizer tokenizer = new StringTokenizer(str,".");

      while(tokenizer.hasMoreElements()) {
        String nextElement = tokenizer.nextElement();
        if (nextElement != null) jsPackage = jsPackage.findPackageWithNameId(index.getIndexOf(nextElement));

        if (jsPackage == null || nextElement == null) return null;
      }
    }

    return jsPackage;
  }

  public static int[] buildNameIdsForQualifier(final JSExpression qualifier, final JavaScriptIndex index) {
    int[] nameIds = null;

    if (qualifier == null) {
      nameIds = JSSymbolUtil.buildNameIndexArray(qualifier, null, index);
    } else {
      ContextResolver resolver = new ContextResolver(qualifier);
      nameIds = resolver.getQualifierAsNameIndex(index);

      if (nameIds== null) nameIds = new int[] { index.getIndexOf( "" ) };
    }

    return nameIds;
  }

  public static JSExpression findClassIdentifier(JSExpression _qualifier) {
    JSExpression qualifier = _qualifier;
    if (qualifier instanceof JSReferenceExpression &&
        PROTOTYPE.equals(((JSReferenceExpression)qualifier).getReferencedName())
      ) {
      qualifier = ((JSReferenceExpression)qualifier).getQualifier();
      if (qualifier == null) qualifier = _qualifier;
    }

    if (qualifier instanceof JSReferenceExpression && ((JSReferenceExpression)qualifier).getQualifier() == null) {
      qualifier = JSSymbolUtil.findReferenceExpressionUsedForClassExtending((JSReferenceExpression)qualifier);
    }
    return qualifier;
  }

  public static boolean iterateType(final JSFunction node, final PsiElement jsClass, final String typeName, final OverrideHandler handler) {
    final Project project = jsClass.getProject();

    if (jsClass instanceof JSClass) {
      JSClass clazz = (JSClass)jsClass;
      final ResolveProcessor resolveProcessor = new ResolveProcessor(node.getName(), node) {{setToProcessHierarchy(true); }

        @Override
        public boolean execute(final PsiElement element, final PsiSubstitutor state) {
          if (!(element instanceof JSFunction)) return true;
          JSFunction fun = (JSFunction)element;
          final JSAttributeList attributeList = fun.getAttributeList();
          if (attributeList != null && attributeList.getAccessType() == JSAttributeList.AccessType.PRIVATE) return false;
          return super.execute(element, state);
        }
      };

      boolean found = false;
      for(JSClass superClazz:clazz.getSuperClasses()) {
        if (superClazz == clazz) break;
        final String superName = superClazz.getQualifiedName();
        final boolean b = superClazz.processDeclarations(resolveProcessor, PsiSubstitutor.EMPTY, superClazz, node);

        if (!b) {
          final JSElement element = resolveProcessor.getResult();
          if (element == null) continue;
          handler.process(resolveProcessor, superClazz, ((JSClass)element.getParent()).getQualifiedName(), superName );
          found = true;
        }
      }

      return !found;
    }

    JSTypeEvaluateManager.getInstance(project).iterateTypeHierarchy(typeName,
        new JSTypeEvaluateManager.NamespaceProcessor() {
        final JavaScriptIndex index = JavaScriptIndex.getInstance(project);
        final ResolveProcessor processor = new ResolveProcessor(node.getName());

        public boolean process(final JSNamespace jsNamespace) {
          String className = null;
          String overrideKey = null;

          if (jsClass instanceof JSClass) {
            final String baseQName = jsNamespace.getQualifiedName(index);
            final PsiElement clazzProxy = findClassByQName(baseQName, index);

            if (clazzProxy != null) {
              JSNamedElement clazz = (JSNamedElement)((JSNamedElementProxy)clazzProxy).getElement();
              className = clazz.getName();

              if (clazz instanceof JSClass) {
                clazz.processDeclarations(processor, PsiSubstitutor.EMPTY, clazz, node);
                overrideKey = typeName + "." + node.getName() + (node.isGetProperty() ? "_get":node.isSetProperty() ? "_set":"");
              }
            } else {
              return false;
            }
          } else if (jsNamespace.getPackage() != null) {
            className = jsNamespace.getQualifiedName(index);
            overrideKey = typeName + "." + node.getName();
            jsNamespace.processDeclarations(new JavaScriptSymbolProcessor.DefaultSymbolProcessor() {
              protected boolean process(final PsiElement namedElement, final JSNamespace namespace) {
                return processor.execute(namedElement, PsiSubstitutor.EMPTY);
              }

              public PsiFile getBaseFile() {
                return null;
              }

              public int getRequiredNameId() {
                return index.getIndexOf(node.getName());
              }
            });
          }

          if (processor.getResult() != null) {
            final JSElement result = processor.getResult();
            if (result instanceof JSFunction) {
              final JSAttributeList attributeList = ((JSFunction)result).getAttributeList();
              if (attributeList != null && attributeList.getAccessType() == JSAttributeList.AccessType.PRIVATE) return false;
            }
            handler.process(processor, jsClass, className, overrideKey);
            return false;
          }
          return true;
        }
      }
    );
    return true;
  }

  public static String getQNameToStartHierarchySearch(final JSFunction node) {
    PsiElement parentNode = node.getParent();
    parentNode = JSResolveUtil.getClassReferenceForXmlFromContext(parentNode);

    if (parentNode instanceof JSClass) {
      final JSAttributeList attributeList = node.getAttributeList();

      if (attributeList == null ||
          !attributeList.hasModifier(JSAttributeList.ModifierType.OVERRIDE) ||
          attributeList.hasModifier(JSAttributeList.ModifierType.STATIC) ||
          attributeList.getAccessType() == JSAttributeList.AccessType.PRIVATE) {
        return null;
      }

      if (parentNode instanceof JSClass) return ((JSClass)parentNode).getQualifiedName();
    } else if (node instanceof JSFunctionExpression) {
      final ContextResolver resolver = new ContextResolver(node.getFirstChild());
      return resolver.getQualifierAsString();
    }
    return null;
  }

  public static boolean isInPlaceWhereTypeCanBeDuringCompletion(PsiElement expr) {
    final PsiElement parent = expr.getParent();
    if (parent instanceof JSArgumentList || (parent instanceof JSVariable && ((JSVariable)parent).getInitializer() == expr)) return true;
    return ( parent instanceof JSExpressionStatement );
  }

  public static boolean isPlaceWhereNsCanBe(final PsiElement parent) {
    final PsiElement grandParent = parent.getParent();
    return grandParent instanceof JSClass || grandParent instanceof JSPackageStatement || (grandParent instanceof JSFile && grandParent.getContext() == null);
  }

  public static @Nullable String getTypeFromTagNameInMxml(final @Nullable PsiElement psiElement) {
    JSClass clazz = getClassFromTagNameInMxml(psiElement);
    return clazz != null ? clazz.getQualifiedName():null;
  }

  public static PsiNamedElement getClassOrFileFromTagNameInMxml(final PsiElement psiElement) {
    XmlTag tag = psiElement != null ? PsiTreeUtil.getNonStrictParentOfType(psiElement, XmlTag.class):null;
    if (tag != null && (tag.getNamespacePrefix().length() > 0 || JavaScriptSupportLoader.isFlexMxmFile(tag.getContainingFile()))) {
      if (isScriptContextTag(tag)) {
        tag = ((XmlFile)tag.getContainingFile()).getDocument().getRootTag();
      }
      final XmlElementDescriptor descriptor = tag.getDescriptor();

      if (descriptor != null) {
        PsiElement decl = descriptor.getDeclaration();
        if (decl instanceof JSNamedElementProxy) decl = ((JSNamedElementProxy)decl).getElement();
        if (decl instanceof JSClass) return ((JSClass)decl);
        else if (decl instanceof XmlFile) return (PsiNamedElement)decl;
      }
    }
    return null;
  }

  public static JSClass getClassFromTagNameInMxml(final PsiElement psiElement) {
    final PsiNamedElement psiNamedElement = getClassOrFileFromTagNameInMxml(psiElement);
    if (psiNamedElement instanceof JSClass) return (JSClass)psiNamedElement;
    return null;
  }

  private static boolean isScriptContextTag(final XmlTag tag) {
    final String localName = tag.getLocalName();
    return "Script".equals(localName) || (localName.length() > 0 && Character.isLowerCase(localName.charAt(0)));
  }

  public static boolean processMetaAttributesForClass(final JSNamedElement jsClass, final MetaDataProcessor processor) {
    return doProcessMetaAttributesForClass(unwrapProxy(jsClass), processor, null, true);
  }

  private static boolean doProcessMetaAttributesForClass(final PsiElement jsClass, final MetaDataProcessor processor, PsiElement lastParent, boolean forward) {
    if (jsClass instanceof JSClass) {
      if (OBJECT_CLASS_NAME.equals((((JSClass)jsClass).getQualifiedName()))) return true;
        PsiElement current = jsClass.getPrevSibling();

        while(true) {
          while(current instanceof PsiWhiteSpace ||
                current instanceof PsiComment) {
            current = current.getPrevSibling();
          }

          if (current instanceof JSIncludeDirective) {
            if (!processIncludeDirective(processor, jsClass, current, false)) return false;
            current = current.getPrevSibling();
          } else {
            break;
          }
        }

        final JSAttributeList attributeList = ((JSClass)jsClass).getAttributeList();
        if (attributeList != null) {
          if (!processAttributeList(processor, jsClass, attributeList, true)) return false;
        }
    }

    final PsiElement[] elements = jsClass.getChildren();
    for(int i = forward ?  0 : elements.length - 1; i < elements.length && i >= 0; i += (forward ? 1:-1)) {
      PsiElement el = elements[i];

      if (el instanceof JSIncludeDirective) {
        if (!processIncludeDirective(processor, lastParent, el, forward)) return false;
      } else if (el instanceof JSAttributeList && lastParent != null) {
        if (!processAttributeList(processor, lastParent, (JSAttributeList)el, forward)) return false;
      }
    }
    return true;
  }

  public static boolean processAttributeList(final MetaDataProcessor processor, final PsiElement el,
                                              final JSAttributeList attributeList, boolean forward) {
    final PsiElement[] elements = attributeList.getChildren();
    for(int i = forward ?  0 : elements.length - 1; i < elements.length && i >= 0; i += (forward ? 1:-1)) {
      final PsiElement cur = elements[i];

      if (cur instanceof JSIncludeDirective) {
        if (!processIncludeDirective(processor, el, cur, forward)) return false;
      } else if (cur instanceof JSAttribute) {
        if (!processor.process((JSAttribute)cur)) return false;
      } else if (cur instanceof JSNamedElement) {
        break;
      }
    }

    return true;
  }

  private static boolean processIncludeDirective(final MetaDataProcessor processor, final PsiElement lastParent,
                                                 final PsiElement el, boolean forward) {
    PsiReference[] references = el.getReferences();
    if (references != null && references.length > 0) {
      PsiElement element = references[references.length - 1].resolve();
      if (element instanceof JSFile) {
        if(!doProcessMetaAttributesForClass(element, processor, lastParent, forward)) return false;
      }
    }
    return true;
  }

  public static PsiElement unwrapProxy(PsiElement jsClass) {
    if (jsClass instanceof JSNamedElementProxy) jsClass = ((JSNamedElementProxy)jsClass).getElement();
    return jsClass;
  }

  public static interface Resolver<T extends PsiPolyVariantReference> {
    ResolveResult[] doResolve(T t, PsiFile contextFile);
  }

  public static <T extends PsiPolyVariantReference> ResolveResult[] resolve(final PsiFile file, T instance, Resolver<T> resolver) {
    if (file == null) return ResolveResult.EMPTY_ARRAY;

    final Map<PsiPolyVariantReference, ResolveResult[]> resultsMap = ourCachedResolveCache.get(MY_RESOLVED_CACHED_KEY, file, null).getValue();
    ResolveResult[] results = resultsMap.get(instance);
    if (results != null) return results;

    results = resolver.doResolve(instance, file);
    resultsMap.put(instance,results);

    return results;
  }

  public static void clearResolveCaches(final PsiFile file) {
    file.putUserData(MY_RESOLVED_CACHED_KEY, null);
  }

  private static @Nullable JSReferenceExpression resolveTypeNameUsingImports2(final @NotNull String referencedName, @NotNull PsiElement context) {
    PsiNamedElement parent = PsiTreeUtil.getNonStrictParentOfType(context, JSPackageStatement.class, PsiFile.class);

    while(parent != null) {
      final JSReferenceExpression resolved = resolveTypeNameUsingImports(referencedName, parent);
      if (resolved != null) return resolved;
      if (parent instanceof PsiFile) break;
      parent = PsiTreeUtil.getParentOfType(parent, PsiFile.class);
    }

    return null;
  }

  public static String resolveTypeName(String str, @NotNull PsiElement context) {
    // TODO: Generics .<>!
    if (str == null || str.indexOf('.') != -1) return str;
    final JSReferenceExpression expression1 = resolveTypeNameUsingImports2(str, context);

    return expression1 != null ? expression1.getText() : str;
  }

  private static JSClass resolveTypeNameInTheSamePackage(final String str, final PsiElement context) {
    final String packageQualifierText = findPackageStatementQualifier(context);

    final JavaScriptIndex index = JavaScriptIndex.getInstance(context.getProject());
    final String candidateText = packageQualifierText != null ? packageQualifierText + "." + str : str;

    PsiElement byQName = JSClassBase.findClassFromNamespace(candidateText, index);
    if (byQName instanceof JSClass) {
      return (JSClass)byQName;
    }

    if (packageQualifierText != null) {
      byQName = JSClassBase.findClassFromNamespace(str, index);
      if (byQName instanceof JSClass) {
        return (JSClass)byQName;
      }
    }

    return null;
  }

  public static JSDefinitionExpression getDefinitionExpr(JSExpressionStatement exprStatement) {
    final JSExpression expression = exprStatement.getExpression();

    if (expression instanceof JSAssignmentExpression) {
      return (JSDefinitionExpression)((JSAssignmentExpression)expression).getLOperand();
    }
    return null;
  }

  public static boolean processDeclarationsInScope(final JSElement scope, final PsiScopeProcessor processor, final PsiSubstitutor substitutor,
                                                   final PsiElement lastParent, final PsiElement place) {
    String requiredName = null;

    if (processor instanceof ResolveProcessor) {
      requiredName = ((ResolveProcessor)processor).getName();
    }

    boolean result = true;
    final TIntObjectHashMap<Object> defsMap = ourCachedDefsCache.get(MY_CACHED_STATEMENTS, scope, null).getValue();

    if (requiredName == null) {
      TIntObjectIterator<Object> iterator = defsMap.iterator();
      while(iterator.hasNext()) {
        iterator.advance();
        result = dispatchResolve(processor, substitutor, place, result, iterator.value());
      }
    } else {
      final Object defs = defsMap.get(requiredName.hashCode());
      if (defs != null) {
        result = dispatchResolve(processor, substitutor, place, result, defs);
      }
    }

    return result;
  }

  private static boolean dispatchResolve(final PsiScopeProcessor processor, final PsiSubstitutor substitutor, final PsiElement place,
                                        boolean result,
                                        final Object o) {
    if (o instanceof JSElement[]) {
      for(JSElement s: (JSElement[])o) {
        result &=s.processDeclarations(processor, substitutor, null, place);
      }
    } else {
      JSElement s = (JSElement)o;
      result &=s.processDeclarations(processor, substitutor, null, place);
    }
    return result;
  }

  public static PsiElement getLocalVariableRef(JSFunction function, final JSReferenceExpression expr) {
    final ResolveProcessor processor = new ResolveProcessor(expr.getReferencedName(), true);

    while(function != null) {
      final boolean val = function.processDeclarations(processor, PsiSubstitutor.EMPTY, function.getParameterList(), function);
      if (!val) return processor.getResult();
      function = PsiTreeUtil.getParentOfType(function, JSFunction.class);
      if (function == null) break;
    }
    return null;
  }

  public static @Nullable JSReferenceExpression resolveTypeNameUsingImports(@NotNull final JSReferenceExpression expr) {
    if (expr.getQualifier() != null) return expr;
    if (JavaScriptIndex.getInstance(expr.getProject()).inUpdateState()) {
      return expr;
    }
    return resolveTypeNameUsingImports(expr.getReferencedName(), expr);
  }

  public static @Nullable JSReferenceExpression resolveTypeNameUsingImports(final @NotNull String referencedName, PsiNamedElement parent) {
    final Map<String, PsiElement> map = myImportResolveCache.get(ourImportResolveCache, parent, null).getValue();
    PsiElement result = map.get(referencedName);
    if (result == null) {
      result = resolveTypeNameUsingImportsInner(referencedName, parent);
      if (result != null || parent instanceof PsiFile) {
        map.put(referencedName, result != null ? result:PsiUtil.NULL_PSI_ELEMENT);
      }
    }

    return result != PsiUtil.NULL_PSI_ELEMENT ? (JSReferenceExpression)result:null;
  }

  private static JSReferenceExpression resolveTypeNameUsingImportsInner(final String referencedName, final PsiNamedElement parent) {
    final Map<String, Object> value = myImportListCache.get(ourImportListCache, parent, null).getValue();
    final Object o = value.get(referencedName);

    if (o instanceof JSReferenceExpression) {
      return (JSReferenceExpression)o;
    } else {
      if (o instanceof JSReferenceExpression[]) {
        return ((JSReferenceExpression[])o)[0];
      }
      final Object anyImport = value.get("*");

      if (anyImport instanceof JSReferenceExpression[]) {
        for(JSReferenceExpression expr:(JSReferenceExpression[])anyImport) {
          final JSReferenceExpression expression = tryFindClass(referencedName, parent, expr);
          if (expression != null) return expression;
        }
      } else if (anyImport instanceof JSReferenceExpression) {
        final JSReferenceExpression expression = tryFindClass(referencedName, parent, (JSReferenceExpression)anyImport);
        if (expression != null) return expression;
      }
    }

    if (parent instanceof JSPackageStatement || parent instanceof JSClass) {
      return checkTheSamePackage(referencedName, parent);
    } else if (parent instanceof JSFile &&
        ((JSFile)parent).getLanguageDialect() == JavaScriptSupportLoader.ECMA_SCRIPT_L4
       ) {
      JSReferenceExpression expression = FlexImportSupport.resolveTypeNameUsingImplicitImports(referencedName, (JSFile)parent);
      if (expression != null) return expression;

      final PsiElement element = getClassReferenceForXmlFromContext(parent);

      if (element instanceof XmlBackedJSClassImpl) {
        final ResolveProcessor processor = new ResolveProcessor(referencedName);
        final boolean b = ((XmlBackedJSClassImpl)element).doImportFromScripts(processor, parent);

        if (!b) {
          return (JSReferenceExpression)JSChangeUtil.createExpressionFromText(element.getProject(), ((JSClass)processor.getResult()).getQualifiedName()).getPsi();
        }

        JSClass jsClass = resolveTypeNameInTheSamePackage(referencedName, element);

        if (jsClass == null) {
          final JSClass parentClass = (JSClass)element;
          final JSClass[] classes = parentClass.getSuperClasses();

          if (classes != null && classes.length > 0 && referencedName.equals(classes[0].getName())) {
            jsClass = classes[0];
          }
        }

        if (jsClass != null) {
          return (JSReferenceExpression)JSChangeUtil.createExpressionFromText(parent.getProject(), jsClass.getQualifiedName()).getPsi();
        }
      } else {
        return checkTheSamePackage(referencedName, parent);
      }
    }

    return null;
  }

  private static JSReferenceExpression checkTheSamePackage(final String referencedName, final PsiNamedElement parent) {
    final JSClass jsClass = resolveTypeNameInTheSamePackage(referencedName, parent);

    if (jsClass != null) {
      return (JSReferenceExpression)JSChangeUtil.createExpressionFromText(parent.getProject(), jsClass.getQualifiedName()).getPsi();
    }
    return null;
  }

  public static JSReferenceExpression tryFindClass(final String referencedName, final PsiNamedElement parent,
                                                    final JSReferenceExpression expr) {
    final PsiElement byQName =
        findClassByQName(expr.getText().replace("*", referencedName), JavaScriptIndex.getInstance(parent.getProject()));
    if (byQName != null) {
      JSReferenceExpression copy = (JSReferenceExpression)expr.copy();
      try {
        return (JSReferenceExpression)copy.handleElementRename(referencedName);
      } catch (IncorrectOperationException ex) {
        ex.printStackTrace();
      }
    }
    return null;
  }

  public static @Nullable JSReferenceExpression resolveTypeNameUsingImports(final @Nullable String referencedName, @NotNull JSReferenceExpression expr) {
    if (referencedName == null) return expr;
    PsiNamedElement parent = PsiTreeUtil.getParentOfType(expr, JSPackageStatement.class, PsiFile.class);

    while(parent != null) {
      final JSReferenceExpression resolved = resolveTypeNameUsingImports(referencedName, parent);
      if (resolved != null) return resolved;
      if (parent instanceof PsiFile) break;
      parent = PsiTreeUtil.getParentOfType(parent, PsiFile.class);
    }

    return expr;
  }

  public static class MyResolveResult implements ResolveResult {
    private final PsiElement myFunction;
    private boolean myValidResult;

    public MyResolveResult(final PsiElement function) {
      this(function, true);
    }

    public MyResolveResult(final PsiElement function, boolean validResult) {
      myFunction = function;
      myValidResult = validResult;
    }

    public PsiElement getElement() {
      //if (myFunction instanceof JSNamedElementProxy) return ((JSNamedElementProxy)myFunction).getElement();
      return myFunction;
    }

    public boolean isValidResult() { return myValidResult; }

    public void setValid(final boolean b) {
      myValidResult = b;
    }
  }

  public static class RelevantDefsUserDataCache extends UserDataCache<CachedValue<TIntObjectHashMap<Object>>, JSElement, Object> {
    protected CachedValue<TIntObjectHashMap<Object>> compute(final JSElement jsElement, final Object o) {
      return jsElement.getManager().getCachedValuesManager().createCachedValue(
        new CachedValueProvider<TIntObjectHashMap<Object>>() {
          public Result<TIntObjectHashMap<Object>> compute() {
            final TIntObjectHashMap<Object> relevantDefs = new TIntObjectHashMap<Object>();

            final JSElementVisitor elementVisitor = new MyJSElementVisitor(jsElement,relevantDefs);
            PsiElement first = null;

            if (jsElement instanceof JSFunction) {
              final JSSourceElement[] body = ((JSFunction)jsElement).getBody();
              if (body.length > 0 && body[0] instanceof JSBlockStatement) {
                final ASTNode node = body[0].getNode().findChildByType(JSElementTypes.STATEMENTS);
                first = node != null ? node.getPsi() : null;
              }
            } else if (jsElement instanceof JSFile || jsElement instanceof JSClass) {
              first = jsElement.getFirstChild();
            }

            for(PsiElement e = first; e != null; e = e.getNextSibling()) {
              if (e instanceof JSSourceElement) {
                e.accept(elementVisitor);
              }
            }

            return new Result<TIntObjectHashMap<Object>> (relevantDefs, jsElement);
          }
        },
        false
      );
    }

    private static class MyJSElementVisitor extends JSElementVisitor {
      private HashMap<String,Boolean> checkedVarsToOurStatus;
      private final TIntObjectHashMap<Object> myRelevantDefs;
      private final JSElement myBase;

      public MyJSElementVisitor(JSElement base,final TIntObjectHashMap<Object> relevantDefs) {
        myRelevantDefs = relevantDefs;
        myBase = base;
      }

      public void visitJSDefinitionExpression(final JSDefinitionExpression node) {
        final JSExpression definedExpr = node.getExpression();
        if (definedExpr instanceof JSReferenceExpression && ((JSReferenceExpression)definedExpr).getQualifier() == null && false) {
          final String s = definedExpr.getText();
          if (checkedVarsToOurStatus == null) checkedVarsToOurStatus = new HashMap<String, Boolean>(3);
          Boolean aBoolean = checkedVarsToOurStatus.get(s);

          if (aBoolean == null) {
            final boolean isInjectedFile = isInjectedFile(myBase);
            JSElement element = null;

            if (myBase instanceof JSFunction || isInjectedFile) {
              final ResolveProcessor processor = new ResolveProcessor(s);
              final PsiElement baseParent = myBase.getParent();
              treeWalkUp(processor, baseParent, baseParent, baseParent);
              element = processor.getResult();
            }
            
            aBoolean = (element == null)? Boolean.TRUE : Boolean.FALSE;
            checkedVarsToOurStatus.put(s, aBoolean);
          }

          if (aBoolean == Boolean.TRUE) addRelevantDef(node);
        }
      }

      public void visitJSVariable(JSVariable node) {
        addRelevantDef(node);
      }

      public void visitJSParameter(JSParameter node) {}

      public void visitJSFunctionExpression(final JSFunctionExpression node) {
        // do not go inside other funcs
      }

      public void visitJSObjectLiteralExpression(final JSObjectLiteralExpression node) {
        // do not go inside other funcs
      }

      public void visitJSClass(final JSClass aClass) {
        // do not go inside other funcs
      }

      public void visitJSFunctionDeclaration(final JSFunction node) {
        addRelevantDef(node);
      }

      private void addRelevantDef(final JSNamedElement node) {
        final ASTNode nameIdentifier = node.findNameIdentifier();

        if (nameIdentifier != null) {
          final int key = nameIdentifier.getText().hashCode();
          final Object o = myRelevantDefs.get(key);

          if (o == null) {
            myRelevantDefs.put(key, node);
          } else if (o instanceof JSElement) {
            final JSElement[] newO = new JSElement[] { (JSElement)o, node};
            myRelevantDefs.put(key, newO);
          } else {
            final JSElement[] oldO = (JSElement[]) o;
            final JSElement[] newO = new JSElement[oldO.length + 1];
            System.arraycopy(oldO,0,newO,0,oldO.length);
            newO[oldO.length] = node;
            myRelevantDefs.put(key, newO);
          }
        }
      }

      public void visitElement(final PsiElement element) {
        element.acceptChildren(this);
      }
    }
  }

  public static class ContextResolver {
    private JSElement qualifyingExpression;
    private JSNamedElement parentContainer;
    private String typeName;

    public ContextResolver(JSExpression expr) {
      if (expr instanceof JSThisExpression ||
          expr instanceof JSSuperExpression
         ) {
        // We need to resolve ns mapping for 'this', which function was the constructor of the object
        resolveContext(expr);
      } else {
        qualifyingExpression = expr instanceof JSReferenceExpression ?
          JSSymbolUtil.findReferenceExpressionUsedForClassExtending(
            (JSReferenceExpression)expr
          ):
          expr;
      }
    }

    public ContextResolver(PsiElement element) {
      resolveContext(element);
    }

    private void resolveContext(final PsiElement context) {
      parentContainer = PsiTreeUtil.getParentOfType(context, JSFunction.class, JSClass.class);

      if (parentContainer instanceof JSFunctionExpression) {
        boolean changedFunctionScope = false;

        while(parentContainer instanceof JSFunctionExpression) {
          final PsiElement parentContainerParent = parentContainer.getParent();

          if (parentContainerParent instanceof JSAssignmentExpression) {
            final JSElement functionExpressionName = ((JSDefinitionExpression)((JSAssignmentExpression)parentContainerParent).getLOperand()).getExpression();
            qualifyingExpression = functionExpressionName;

            if (functionExpressionName instanceof JSReferenceExpression) {
              final JSExpression functionExpressionNameQualifier = ((JSReferenceExpression)functionExpressionName).getQualifier();

              if (functionExpressionNameQualifier instanceof JSThisExpression) {
                parentContainer = PsiTreeUtil.getParentOfType(functionExpressionName, JSFunction.class);
                qualifyingExpression = null;
                changedFunctionScope = true;
                continue;
              } else if (functionExpressionNameQualifier instanceof JSReferenceExpression) {
                final String functionExpressionNameQualifierText = ((JSReferenceExpression)functionExpressionNameQualifier).getReferencedName();

                if (PROTOTYPE_FIELD_NAME.equals(functionExpressionNameQualifierText)) {
                  qualifyingExpression = ((JSReferenceExpression)functionExpressionNameQualifier).getQualifier();
                } else if (!changedFunctionScope) {
                  String referencedName;

                  if (((JSReferenceExpression)functionExpressionNameQualifier).getQualifier() == null &&
                      ( ( referencedName = ((JSReferenceExpression)functionExpressionName).getReferencedName() ) == null ||
                        referencedName.length() == 0 ||
                        !Character.isUpperCase(referencedName.charAt(0))
                      )
                     ) {
                    qualifyingExpression = functionExpressionNameQualifier;
                  }
                }
              }
            }
          } else if (parentContainerParent instanceof JSProperty) {
            final JSElement element =
              PsiTreeUtil.getParentOfType(parentContainerParent, JSVariable.class, JSAssignmentExpression.class, JSArgumentList.class);
            if (element instanceof JSVariable) {
              qualifyingExpression = element;
            } else if (element instanceof JSAssignmentExpression) {
              qualifyingExpression = ((JSDefinitionExpression)((JSAssignmentExpression)element).getLOperand()).getExpression();
            } else if (element instanceof JSArgumentList) {
              qualifyingExpression = JSSymbolUtil.findQualifyingExpressionFromArgumentList((JSArgumentList)element);
            }
          } else if (parentContainerParent instanceof JSNewExpression) {
            final JSElement element =
              PsiTreeUtil.getParentOfType(parentContainerParent, JSVariable.class, JSAssignmentExpression.class, JSArgumentList.class);

            if (element instanceof JSVariable) {
              qualifyingExpression = element;
            } else if (element instanceof JSAssignmentExpression) {
              qualifyingExpression = ((JSDefinitionExpression)((JSAssignmentExpression)element).getLOperand()).getExpression();
            }
          } else if (parentContainerParent instanceof JSReferenceExpression) {
            parentContainer = PsiTreeUtil.getParentOfType(parentContainerParent, JSFunction.class);
            continue;
          } else if (parentContainer.getName() == null) {
            parentContainer = PsiTreeUtil.getParentOfType(parentContainerParent, JSFunction.class);
            continue;
          }

          break;
        }

        if (qualifyingExpression instanceof JSReferenceExpression) {
          final JSReferenceExpression qualifyingReferenceExpression = ((JSReferenceExpression)qualifyingExpression);
          final String functionExpressionNameQualifierText = qualifyingReferenceExpression.getReferencedName();

          if (PROTOTYPE_FIELD_NAME.equals(functionExpressionNameQualifierText)) {
            qualifyingExpression = qualifyingReferenceExpression.getQualifier();
          } else {

            qualifyingExpression = JSSymbolUtil.findReferenceExpressionUsedForClassExtending(
              qualifyingReferenceExpression
            );
          }
        }
      }

      PsiElement parentContainerParent = parentContainer != null ? parentContainer.getParent():null;

      if (parentContainerParent instanceof JSFile) {
        parentContainerParent = JSResolveUtil.getClassReferenceForXmlFromContext(parentContainerParent);
      }

      if (parentContainerParent instanceof JSClass) {
        parentContainer = (JSNamedElement)parentContainerParent;
      }

      $aaa = 1;
    }

    int $aaa;

    public @Nullable String getQualifierAsString() {
      if (qualifyingExpression instanceof JSReferenceExpression) {
        return qualifyingExpression.getText();
      } else if (qualifyingExpression instanceof JSNamedElement) {
        return ((JSNamedElement)qualifyingExpression).getName();
      } else if (parentContainer != null) {
        return parentContainer.getName();
      }

      return typeName;
    }

    public @Nullable int[] getQualifierAsNameIndex(@NotNull JavaScriptIndex index) {
      if (qualifyingExpression != null) {
        return JSSymbolUtil.buildNameIndexArray(qualifyingExpression, null, index);
      } else if (parentContainer != null) {
        String name = typeName != null ? typeName:parentContainer instanceof JSClass ? ((JSClass)parentContainer).getQualifiedName(): parentContainer.getName();

        if (name != null) return new int[] { index.getIndexOf(name) };
      }

      return null;
    }

    public JSElement getQualifyingExpression() {
      return qualifyingExpression;
    }
  }

  private static boolean isInjectedFile(PsiElement element) {
    return element instanceof PsiFile && (
      ((PsiFile)element).getVirtualFile() instanceof LightVirtualFile
    );
  }

  private static class ImportListDataCache extends UserDataCache<CachedValue<Map<String, Object>>,PsiElement, Object> {
    protected final CachedValue<Map<String, Object>> compute(final PsiElement owner, Object o) {
      return owner.getManager().getCachedValuesManager().createCachedValue(new CachedValueProvider<Map<String, Object>>() {
        public Result<Map<String, Object>> compute() {
          final Map<String,Object> result = new THashMap<String, Object>();

          for(PsiElement c = owner.getFirstChild(); c != null; c = c.getNextSibling()) {
            if (c instanceof JSImportStatement) {
              final ASTNode node = ((JSImportStatement)c).findNameIdentifier();

              if (node != null) {
                JSReferenceExpression importedTypeExpr = (JSReferenceExpression)node.getPsi();
                final String referencedName = importedTypeExpr.getReferencedName();

                if (referencedName != null) {
                  final Object last = result.get(referencedName);

                  if (last == null) {
                    result.put(referencedName, importedTypeExpr);
                  } else if (last instanceof JSReferenceExpression) {
                    final JSReferenceExpression[] val = new JSReferenceExpression[] {importedTypeExpr, (JSReferenceExpression)last};
                    result.put(referencedName, val);
                  } else {
                    JSReferenceExpression[] old = (JSReferenceExpression[])last;
                    final JSReferenceExpression[] val = new JSReferenceExpression[old.length + 1];
                    System.arraycopy(old, 0, val, 1, old.length);
                    val[0] = importedTypeExpr;
                    result.put(referencedName, val);
                  }
                }
              }
            }
          }
          return new Result<Map<String,Object>>(result,owner);
        }
      }, false);
    }
  }

  public interface OverrideHandler {
    void process(ResolveProcessor processor, final PsiElement scope, String className, String overrideKey);
  }

  public interface MetaDataProcessor {
    boolean process(final @NotNull JSAttribute jsAttribute);
  }
}
