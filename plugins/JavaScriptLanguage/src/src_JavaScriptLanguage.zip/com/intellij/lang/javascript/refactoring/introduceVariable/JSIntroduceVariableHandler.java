package com.intellij.lang.javascript.refactoring.introduceVariable;

import com.intellij.codeInsight.PsiEquivalenceUtil;
import com.intellij.codeInsight.highlighting.HighlightManager;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.impl.JSChangeUtil;
import com.intellij.lang.javascript.psi.impl.JSEmbeddedContentImpl;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.command.CommandProcessor;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.editor.colors.EditorColors;
import com.intellij.openapi.editor.colors.EditorColorsManager;
import com.intellij.openapi.editor.markup.RangeHighlighter;
import com.intellij.openapi.editor.markup.TextAttributes;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.wm.WindowManager;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.*;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.refactoring.RefactoringActionHandler;
import com.intellij.refactoring.RefactoringBundle;
import com.intellij.refactoring.util.CommonRefactoringUtil;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * @author ven
 */
public class JSIntroduceVariableHandler implements RefactoringActionHandler {
  private static final Logger LOG = Logger.getInstance("#com.intellij.lang.javascript.refactoring.introduceVariable.JSIntroduceVariableHandler");

  static final String REFACTORING_NAME = JSBundle.message("javascript.introduce.variable.title");
  private static JSExpression findExpressionInRange(PsiFile file, int startOffset, int endOffset) {
    PsiElement element1 = file.findElementAt(startOffset);
    PsiElement element2 = file.findElementAt(endOffset - 1);
    if (element1 instanceof PsiWhiteSpace) {
      startOffset = element1.getTextRange().getEndOffset();
    }
    if (element2 instanceof PsiWhiteSpace) {
      endOffset = element2.getTextRange().getStartOffset();
    }
    JSExpression expression = PsiTreeUtil.findElementOfClassAtRange(file, startOffset, endOffset, JSExpression.class);
    if (expression == null || expression.getTextRange().getEndOffset() != endOffset) return null;
    if (expression instanceof JSReferenceExpression && expression.getParent() instanceof JSCallExpression) return null;
    return expression;
  }

  private static JSExpression unparenthesize(JSExpression expression) {
    while(expression instanceof JSParenthesizedExpression) {
      expression = ((JSParenthesizedExpression)expression).getInnerExpression();
    }

    return expression;
  }

  public static JSExpression[] findExpressionOccurrences(JSElement scope, JSExpression expr) {
    List<JSExpression> array = new ArrayList<JSExpression>();
    addExpressionOccurrences(unparenthesize(expr), array, scope);
    return array.toArray(new JSExpression[array.size()]);
  }

  private static void addExpressionOccurrences(JSExpression expr, List<JSExpression> array, PsiElement scope) {
    PsiElement[] children = scope.getChildren();
    for (PsiElement child : children) {
      if (child instanceof JSExpression) {
        if (PsiEquivalenceUtil.areElementsEquivalent(unparenthesize((JSExpression)child), expr)) {
          array.add((JSExpression)child);
          continue;
        }
      }
      if (!(child instanceof JSFunction)) {
        addExpressionOccurrences(expr, array, child);
      }
    }
  }

  public void invoke(final Project project, final Editor editor, PsiFile file, DataContext dataContext) {
    if (!editor.getSelectionModel().hasSelection()) editor.getSelectionModel().selectLineAtCaret();
    int start = editor.getSelectionModel().getSelectionStart();
    int end = editor.getSelectionModel().getSelectionEnd();

    final JSExpression expression = findExpressionInRange(file, start, end);
    if (expression == null) {
      CommonRefactoringUtil.showErrorMessage(REFACTORING_NAME, JSBundle.message(
        "javascript.introduce.variable.error.no.expression.selected"), null, project);
      return;
    }

    if (!CommonRefactoringUtil.checkReadOnlyStatus(project, file)) return;

    editor.getSelectionModel().removeSelection();
    JSElement scope = PsiTreeUtil.getParentOfType(expression, JSFunction.class, JSFile.class, JSEmbeddedContentImpl.class);
    LOG.assertTrue(scope != null);
    final JSExpression[] occurrences = findExpressionOccurrences(scope, expression);
    final Settings settings = getSettings(project, editor, expression, occurrences);
    if (settings == null) return;

    CommandProcessor.getInstance().executeCommand(project, new Runnable() {
      public void run() {
        ApplicationManager.getApplication().runWriteAction(
          new Runnable() {
            public void run() {
              doRefactoring(project, editor, expression, occurrences, settings.isReplaceAllOccurences(), settings.getVariableName());
            }
          }
        );
      }
    }, REFACTORING_NAME, null);
  }

  @Nullable
  protected Settings getSettings(Project project, Editor editor, JSExpression expression, final JSExpression[] occurrences) {
    ArrayList<RangeHighlighter> highlighters = null;
    if (occurrences.length > 1) {
      highlighters = highlightOccurences(project, editor, occurrences);
    }

    final JSIntroduceVariableDialog dialog = new JSIntroduceVariableDialog(project, occurrences, expression);
    dialog.show();
    if (highlighters != null) {
      for (RangeHighlighter highlighter : highlighters) {
        HighlightManager.getInstance(project).removeSegmentHighlighter(editor, highlighter);
      }
    }

    if (dialog.getExitCode() != DialogWrapper.OK_EXIT_CODE) return null;

    return new Settings() {
      public String getVariableName() {
        return dialog.getName();
      }

      public boolean isReplaceAllOccurences() {
        return dialog.isReplaceAllOccurences();
      }
    };
  }

  private static void doRefactoring(final Project project,
                             final Editor editor,
                             JSExpression expression,
                             final JSExpression[] occurrences,
                             final boolean replaceAllOccurences, final String localName) {
    JSVarStatement declaration = (JSVarStatement)JSChangeUtil.createStatementFromText(project, "var " + localName + " = 0;").getPsi();
    declaration.getVariables()[0].getInitializer().replace(expression);
    JSStatement anchorStatement = replaceAllOccurences ?
                                  getAnchorToInsert(occurrences) :
                                  PsiTreeUtil.getParentOfType(expression, JSStatement.class);
    if (anchorStatement instanceof JSVarStatement &&
        anchorStatement.getParent() instanceof JSStatement &&
        !(anchorStatement.getParent() instanceof JSBlockStatement)
       ) {
      anchorStatement = (JSStatement) anchorStatement.getParent();
    }

    LOG.assertTrue(anchorStatement != null);
    try {
      boolean replacedOriginal = false;

      if (anchorStatement == expression.getParent() && anchorStatement instanceof JSExpressionStatement) {
        declaration = (JSVarStatement)anchorStatement.replace(declaration);
        editor.getCaretModel().moveToOffset(declaration.getTextRange().getEndOffset());
        replacedOriginal = true;
      } else {
        JSExpression oldExpression = expression;
        final TextRange expressionTextRange = expression.getTextRange();
        final TextRange statementTextRange = anchorStatement.getTextRange();

        int offsetOfExprRelativeToAnchor = expressionTextRange.getStartOffset() - statementTextRange.getStartOffset();
        final JSStatement jsStatement = anchorStatement.addStatementBefore(declaration);
        final JSStatement newAnchorStatement = PsiTreeUtil.getNextSiblingOfType(jsStatement, anchorStatement.getClass());
        JSExpression newExpression = PsiTreeUtil.getParentOfType(newAnchorStatement.findElementAt(offsetOfExprRelativeToAnchor),oldExpression.getClass());

        assert newExpression != null;

        while(newExpression.getTextRange().getLength() != expressionTextRange.getLength()) {
          JSExpression candidateExpression = PsiTreeUtil.getParentOfType(newExpression,oldExpression.getClass());
          if (candidateExpression == null) break;
          if (candidateExpression.getTextRange().getStartOffset() - newAnchorStatement.getTextRange().getStartOffset() != offsetOfExprRelativeToAnchor) break;
          newExpression = candidateExpression;
        }

        for(int i = 0; i < occurrences.length; ++i) {
          if (occurrences[i] == oldExpression) {
            occurrences[i] = newExpression;
            break;
          }
        }

        expression = newExpression;
      }

      final JSExpression refExpr = (JSExpression)JSChangeUtil.createExpressionFromText(project, localName).getPsi();
      if (replaceAllOccurences) {
        List<JSExpression> toHighight = new ArrayList<JSExpression>();
        for (JSExpression occurence : occurrences) {
          if (occurence != expression || !replacedOriginal) toHighight.add(occurence.replace(refExpr));
          else toHighight.add( declaration.getVariables()[0].getInitializer() );
        }

        highlightOccurences(project, editor, toHighight.toArray(new JSExpression[toHighight.size()]));
      } else if (!replacedOriginal) {
        expression.replace(refExpr);
      }
    }
    catch (IncorrectOperationException e) {
      LOG.error(e);
    }
  }

  private static ArrayList<RangeHighlighter> highlightOccurences(Project project, Editor editor, JSExpression[] occurences) {
    HighlightManager highlightManager = HighlightManager.getInstance(project);
    EditorColorsManager colorsManager = EditorColorsManager.getInstance();
    TextAttributes attributes = colorsManager.getGlobalScheme().getAttributes(EditorColors.SEARCH_RESULT_ATTRIBUTES);
    ArrayList<RangeHighlighter> result = new ArrayList<RangeHighlighter>();
    highlightManager.addOccurrenceHighlights(editor, occurences, attributes, true, result);
    WindowManager.getInstance().getStatusBar(project).setInfo(RefactoringBundle.message("press.escape.to.remove.the.highlighting"));
    return result;
  }

  private static JSStatement getAnchorToInsert(final JSExpression[] expressions) {
    JSElement place = expressions[0];
    next:
    do {
      JSStatement statement = PsiTreeUtil.getParentOfType(place, JSStatement.class); //this is the first expression textually
      LOG.assertTrue(statement != null);

      final PsiElement parent = statement.getParent();
      for (JSExpression expression : expressions) {
        if (!PsiTreeUtil.isAncestor(parent, expression, true)) {
          place = statement;
          continue next;
        }
      }

      return statement;
    } while (true);
  }

  public void invoke(Project project, PsiElement[] elements, DataContext dataContext) {
    throw new RuntimeException("Not implemented");
  }
}
