package com.intellij.lang.javascript.psi.impl;

import com.intellij.codeInsight.daemon.EmptyResolveMessageProvider;
import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.index.JavaScriptIndex;
import com.intellij.lang.javascript.index.JSPackage;
import com.intellij.lang.javascript.psi.JSLiteralExpression;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.VariantsProcessor;
import com.intellij.lang.javascript.psi.resolve.WalkUpResolveProcessor;
import com.intellij.openapi.util.TextRange;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.*;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.util.IncorrectOperationException;
import gnu.trove.TIntArrayList;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Maxim.Mossienko
*/
public class JSReferenceSet {
  private String myReferenceText;
  private PsiReference[] myReferences;
  private final PsiElement element;
  private boolean isSoft = true;

  public JSReferenceSet(final PsiElement element, String text, int offset, boolean soft) {
    this.element = element;
    isSoft = soft;
    myReferenceText = text;
    myReferences = reparse(text, offset);
  }

  public JSReferenceSet(final PsiElement element) {
    this.element = element;
  }

  public PsiReference[] getReferences() {
    return myReferences;
  }

  public void update(String text, int offset) {
    if (myReferences != null &&
        myReferenceText != null &&
        myReferenceText.equals(text)) {
      return;
    }

    if (!StringUtil.startsWithChar(text,'"') && !StringUtil.startsWithChar(text,'\'')) {
      myReferenceText = text;
      myReferences = PsiReference.EMPTY_ARRAY;
    } else {
      final PsiReference[] list = reparse(StringUtil.stripQuotesAroundValue(text), offset + 1);
      myReferenceText = text;
      myReferences = list;
    }
  }

  private PsiReference[] reparse(final String value, final int offset) {
    List<PsiReference> refs = new ArrayList<PsiReference>(1);
    int lastPos = 0;
    int dotPos = value.indexOf('.');

    while(dotPos != -1) {
      final String s = value.substring(lastPos,dotPos).trim();

      if (s.length() > 0) {
        refs.add( new MyPsiReference(s,offset + lastPos) );
      }

      lastPos = dotPos + 1;
      dotPos = value.indexOf('.',lastPos);
    }

    final String s = value.substring(lastPos).trim();

    if (s.length() > 0) {
      refs.add( new MyPsiReference(s,offset + lastPos) );
    }

    return refs.toArray(new PsiReference[refs.size()]);
  }

  public boolean isSoft() {
    return isSoft;
  }

  private class MyPsiReference implements PsiPolyVariantReference, EmptyResolveMessageProvider {
    private @NonNls String myText;
    private int myOffset;

    MyPsiReference(final String s, final int i) {
      myText = s;
      myOffset = i;
    }

    public PsiElement getElement() {
      return element;
    }

    public TextRange getRangeInElement() {
      return new TextRange(myOffset,myOffset + myText.length());
    }

    @Nullable
    public PsiElement resolve() {
      final ResolveResult[] resolveResults = multiResolve(false);
      return resolveResults.length == 1 ? resolveResults[0].getElement():null;
    }

    public String getCanonicalText() {
      return myText;
    }

    public PsiElement handleElementRename(String newElementName) throws IncorrectOperationException {
      int sizeChange = newElementName.length() - myText.length();
      boolean found = false;
      String newLiteralText = myReferenceText.substring(0,myOffset) + newElementName + myReferenceText.substring(myOffset + myText.length());
      final ASTNode expressionFromText = JSChangeUtil.createExpressionFromText(element.getProject(), newLiteralText);

      if (expressionFromText.getPsi() instanceof JSLiteralExpression) {
        final ASTNode astNode = element.getNode();
        astNode.replaceChild(
          astNode.getFirstChildNode(),
          expressionFromText.getFirstChildNode()
        );
      }
      myText = newElementName;

      for (final PsiReference reference : myReferences) {
        if (reference == this) {
          found = true;
        }
        else if (found) {
          ((MyPsiReference)reference).myOffset += sizeChange;
        }
      }
      return null;
    }

    public PsiElement bindToElement(@NotNull PsiElement element) throws IncorrectOperationException {
      return null;
    }

    public boolean isReferenceTo(PsiElement element) {
      if (element instanceof PsiNamedElement || element instanceof XmlAttributeValue)
        return JSResolveUtil.isReferenceTo(this, myText, element);
      return false;
    }

    public Object[] getVariants() {
      TIntArrayList contextIds = null;
      final PsiReference[] references = myReferences;
      final JavaScriptIndex index = JavaScriptIndex.getInstance(element.getProject());

      for (final PsiReference ref : references) {
        if (ref == this) break;
        if (contextIds == null) contextIds = new TIntArrayList(3);
        contextIds.add(index.getIndexOf(ref.getCanonicalText()));
      }

      final PsiFile containingFile = element.getContainingFile();

      final VariantsProcessor processor = new VariantsProcessor(
        contextIds != null ? contextIds.toNativeArray():null, containingFile,
        false,
        element
      );
      index.processAllSymbols(processor);

      final PsiElement context = containingFile.getContext();
      if (context != null) {
        JSResolveUtil.treeWalkUp(processor, containingFile, containingFile, element);
      }

      return processor.getResult();
    }

    public boolean isSoft() {
      return JSReferenceSet.this.isSoft();
    }

    @NotNull
    public ResolveResult[] multiResolve(final boolean incompleteCode) {
      return JSResolveUtil.resolve(element.getContainingFile(), this, MyResolver.INSTANCE);
    }

    private ResolveResult[] doResolve(PsiFile psiFile) {
      if ("int".equals(myText) || "uint".equals(myText)) {
        return new ResolveResult[] { new JSResolveUtil.MyResolveResult(element)};
      }

      final JavaScriptIndex index = JavaScriptIndex.getInstance(psiFile.getProject());

      TIntArrayList contextIds = null;
      final PsiReference[] references = myReferences;

      for (final PsiReference ref : references) {
        if (ref == this) break;
        if (contextIds == null) contextIds = new TIntArrayList(3);
        contextIds.add(index.getIndexOf(ref.getCanonicalText()));
      }

      final WalkUpResolveProcessor processor = new WalkUpResolveProcessor(
        index.getIndexOf( myText),
        contextIds != null ? contextIds.toNativeArray() : null,
        psiFile,
        false,
        element
      );

      index.processAllSymbols(processor);
      final StringBuilder b = new StringBuilder();

      for (final PsiReference ref : references) {
        if(b.length() > 0) b.append('.');
        b.append(ref.getCanonicalText());
        if (ref == this) break;
      }
      final String str = b.toString();

      final PsiElement context = psiFile.getContext();
      if (context != null && str.indexOf('.') == -1) {
        JSResolveUtil.treeWalkUp(processor, psiFile, psiFile, element);
      }

      if (processor.getResults().length == 0) {
        final JSPackage aPackage = JSResolveUtil.findPackageByText(index, str);
        if (aPackage != null) { processor.execute(getElement(), PsiSubstitutor.EMPTY); };
      }

      return processor.getResults();
    }

    public String getUnresolvedMessagePattern() {
      return JSBundle.message("javascript.unresolved.variable.or.type.name.message2",getCanonicalText());
    }
  }

  static class MyResolver implements JSResolveUtil.Resolver<MyPsiReference> {
    private static final MyResolver INSTANCE = new MyResolver();

    public ResolveResult[] doResolve(final MyPsiReference literalExpression, PsiFile psiFile) {
      return literalExpression.doResolve(psiFile);
    }
  }
}
