/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.psi.impl;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.lang.javascript.psi.JSBinaryExpression;
import com.intellij.lang.javascript.psi.JSElementVisitor;
import com.intellij.lang.javascript.psi.JSExpression;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.psi.PsiElementVisitor;
import com.intellij.psi.tree.IElementType;
import com.intellij.psi.tree.TokenSet;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 30, 2005
 * Time: 11:41:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSBinaryExpressionImpl extends JSExpressionImpl implements JSBinaryExpression {
  private static final Logger LOG = Logger.getInstance("#com.intellij.lang.javascript.psi.impl.JSBinaryExpressionImpl");
  private static final TokenSet BINARY_OPERATIONS = TokenSet.orSet(JSTokenTypes.OPERATIONS, JSTokenTypes.RELATIONAL_OPERATIONS);

  public JSBinaryExpressionImpl(final ASTNode node) {
    super(node);
  }

  public JSExpression getLOperand() {
    final ASTNode[] nodes = getNode().getChildren(JSElementTypes.EXPRESSIONS);
    LOG.assertTrue(nodes.length >= 1);
    return (JSExpression)nodes[0].getPsi();
  }

  public JSExpression getROperand() {
    final ASTNode[] nodes = getNode().getChildren(JSElementTypes.EXPRESSIONS);
    return nodes.length == 2 ? (JSExpression)nodes[1].getPsi() : null;
  }

  public IElementType getOperationSign() {
    final ASTNode operationASTNode = getOperationASTNode();
    return operationASTNode != null ? operationASTNode.getElementType():null;
  }

  private ASTNode getOperationASTNode() {
    final ASTNode[] nodes = getNode().getChildren(BINARY_OPERATIONS);
    return nodes.length == 1 ? nodes[0]:null;
  }

  public void accept(PsiElementVisitor visitor) {
    if (visitor instanceof JSElementVisitor) {
      ((JSElementVisitor)visitor).visitJSBinaryExpression(this);
    }
    else {
      visitor.visitElement(this);
    }
  }
}
