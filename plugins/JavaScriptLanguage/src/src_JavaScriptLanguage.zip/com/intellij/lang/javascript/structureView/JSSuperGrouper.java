package com.intellij.lang.javascript.structureView;

import com.intellij.ide.IdeBundle;
import com.intellij.ide.util.treeView.AbstractTreeNode;
import com.intellij.ide.util.treeView.smartTree.*;
import com.intellij.lang.javascript.index.JSNamedElementProxy;
import com.intellij.lang.javascript.index.JSNamespace;
import com.intellij.lang.javascript.index.JavaScriptIndex;
import com.intellij.lang.javascript.psi.JSClass;
import com.intellij.lang.javascript.psi.JSFunction;
import com.intellij.lang.javascript.psi.JSVariable;
import com.intellij.lang.javascript.psi.JSVarStatement;
import com.intellij.openapi.util.IconLoader;
import com.intellij.psi.PsiElement;
import gnu.trove.THashMap;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;

/**
 * @author Maxim.Mossienko
*/
class JSSuperGrouper implements Grouper {
  @NonNls private static final String SHOW_CLASSES = "SHOW_CLASSES";

  @NotNull
  public Collection<Group> group(final AbstractTreeNode parent, final Collection<TreeElement> children) {
    if (isParentGrouped(parent)) return Collections.emptyList();
    final Map<String, Group> groups = new THashMap<String, Group>();
    JavaScriptIndex index = JavaScriptIndex.getInstance(((JSStructureViewElement)parent.getValue()).getValue().getProject());

    for (TreeElement _child : children) {
      JSStructureViewElement child = (JSStructureViewElement)_child;
      if (!child.isInherited()) continue;
      final PsiElement value = child.getValue();

      if (value instanceof JSNamedElementProxy) {
        final JSNamespace ns = ((JSNamedElementProxy)value).getNamespace();
        if (ns.getNameId()== -1) continue;

        addGroup(groups, _child, ns.getQualifiedName(index));
      } else if (value instanceof JSVariable || value instanceof JSFunction) {
        PsiElement parentElement = value.getParent();
        if (parentElement instanceof JSVarStatement) parentElement = parentElement.getParent();
        if (parentElement instanceof JSClass) {
          addGroup(groups, _child, ((JSClass)parentElement).getQualifiedName());
        }
      }
    }
    return groups.values();
  }

  private static void addGroup(final Map<String, Group> groups, final TreeElement _child, final String qName) {
    JSSuperGroup group;
    if ((group = ((JSSuperGroup)groups.get(qName))) == null) {
      groups.put(qName, group = new JSSuperGroup(qName));
    }

    group.addChild(_child);
  }

  @NotNull
  public ActionPresentation getPresentation() {
    return new ActionPresentationData(IdeBundle.message("action.structureview.group.methods.by.defining.type"), null,
                                    IconLoader.getIcon("/general/implementingMethod.png"));
  }

  @NotNull
  public String getName() {
    return SHOW_CLASSES;
  }

  private static boolean isParentGrouped(AbstractTreeNode parent) {
    while (parent != null) {
      if (parent.getValue() instanceof JSSuperGroup) return true;
      parent = parent.getParent();
    }
    return false;
  }
}
