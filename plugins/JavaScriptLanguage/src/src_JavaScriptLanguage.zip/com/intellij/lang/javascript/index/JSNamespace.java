package com.intellij.lang.javascript.index;

import gnu.trove.TIntObjectHashMap;
import gnu.trove.TIntObjectIterator;
import gnu.trove.TIntHashSet;

import java.io.IOException;
import java.util.HashSet;

import com.intellij.util.Processor;

/**
 * Created by IntelliJ IDEA.
 * User: yole
 * Date: 05.10.2005
 * Time: 18:51:13
 * To change this template use File | Settings | File Templates.
 */
public class JSNamespace {
  private JSNamespace myParent;
  private int myNameId;
  private TIntObjectHashMap<JSNamespace> myChildNamespaces;

  public JSNamespace() {
    myParent = null;
    myNameId = -1;
  }

  public JSNamespace(final JSNamespace parent, final int nameId) {
    myParent = parent;
    myNameId = nameId;
  }

  public void clear() {
    if (myChildNamespaces != null) myChildNamespaces.clear();
  }

  public JSNamespace getChildNamespace(final int nameId) {
    if (myChildNamespaces == null) {
      myChildNamespaces = new TIntObjectHashMap<JSNamespace>();
    }
    JSNamespace ns = myChildNamespaces.get(nameId);
    if (ns == null) {
      ns = new JSNamespace(this, nameId);
      myChildNamespaces.put(nameId, ns);
    }
    return ns;
  }

  public int getNameId() {
    return myNameId;
  }

  public JSNamespace getParent() {
    return myParent;
  }

  public void enumerateNames(final SerializationContext context) {
    if (myNameId != -1) context.addName( context.myIndex.getStringByIndex( myNameId ) );
    final String superType = context.typeEvaluateManager.getBaseType(this);
    context.addName(superType != null ? superType:"");

    if (myChildNamespaces != null) {
      final TIntObjectIterator<JSNamespace> iterator = myChildNamespaces.iterator();

      while(iterator.hasNext()) {
        iterator.advance();
        iterator.value().enumerateNames(context);
      }
    }
  }

  public void write(SerializationContext context) throws IOException {
    context.outputStream.writeInt( doEnumerateNS(this,context) );
    context.outputStream.writeInt( myNameId != -1 ? context.myNames.get( context.myIndex.getStringByIndex(myNameId)): myNameId );

    String superType = context.typeEvaluateManager.getBaseType(this);
    if (superType != null) {
      final JSNamespace[] parent = new JSNamespace[1];
      JSNamespace myRootNs = this;
      while(myRootNs.getParent() != null) myRootNs = myRootNs.getParent();

      final JSNamespace myRootNs1 = myRootNs;
      context.typeEvaluateManager.doIterateType(
        this,
        new Processor<JSNamespace>() {
          public boolean process(final JSNamespace t) {
            JSNamespace tRootNs = t;
            while(tRootNs.getParent() != null) tRootNs = tRootNs.getParent();

            if (tRootNs == myRootNs1) {
              parent [0] = t;
              return false;
            }
            return true;
          }
        });

      context.outputStream.writeInt( doEnumerateNS(parent[0], context) );
      context.outputStream.writeInt( context.myNames.get(superType) );
    } else {
      context.outputStream.writeInt( -1 );
    }

    if (myChildNamespaces != null) {
      context.outputStream.writeInt(myChildNamespaces.size());
      final TIntObjectIterator<JSNamespace> iterator = myChildNamespaces.iterator();

      while(iterator.hasNext()) {
        iterator.advance();
        iterator.value().write(context);
      }
    } else {
      context.outputStream.writeInt(0);
    }
  }

  private static int doEnumerateNS(JSNamespace ns, final SerializationContext context) {
    int i = context.myNameSpaces.get(ns);
    if (i == 0) context.myNameSpaces.put(ns, i = context.myNameSpaces.size() + 1 );
    return i;
  }

  public JSNamespace read(final DeserializationContext context, JSNamespace parent) throws IOException {
    final int nsIndex = context.inputStream.readInt();
    final JSNamespace ns = context.myNameSpaces.get(nsIndex);
    final JSNamespace result = ns != null ? ns:this;

    context.myNameSpaces.put(nsIndex, result);
    result.doRead(context, parent);
    return result;
  }

  private void doRead(final DeserializationContext context, JSNamespace parent) throws IOException {
    myParent = parent;
    myNameId = context.inputStream.readInt();

    final int superNsId = context.inputStream.readInt();

    if (superNsId > 0) {
      JSNamespace superNs = context.myNameSpaces.get(superNsId);
      if (superNs == null) {
        superNs = new JSNamespace();
        context.myNameSpaces.put(superNsId, superNs);
      }

      final int superNsType = context.inputStream.readInt();

      context.typeEvaluateManager.setBaseType(
        this,
        getQualifiedName(JavaScriptIndex.getInstance(context.manager.getProject())),
        superNs,
        context.myNames.get(superNsType)
      );
    }

    int childCount = context.inputStream.readInt();

    while(childCount > 0) {
      JSNamespace item = new JSNamespace();
      item = item.read(context, this);
      if (myChildNamespaces == null) myChildNamespaces = new TIntObjectHashMap<JSNamespace>(childCount);
      myChildNamespaces.put(item.getNameId(), item);
      --childCount;
    }
  }

  public int[] getIndices() {
    int count = 0;

    for(JSNamespace ns = this; ns.getParent() != null; ns = ns.getParent()) {
      ++count;
    }

    final int[] result = new int[count];
    for(JSNamespace ns = this; ns.getParent() != null; ns = ns.getParent()) {
      result[--count] = ns.getNameId();
    }

    return result;
  }

  public String getQualifiedName(JavaScriptIndex index) {
    StringBuffer buf = new StringBuffer();

    for(JSNamespace ns = this; ns.getParent() != null; ns = ns.getParent()) {
      if (buf.length() > 0) buf.insert(0, '.');
      buf.insert(0, index.getStringByIndex( ns.getNameId()) );
    }

    return buf.toString();
  }

  public void invalidate(final JSTypeEvaluateManager typeEvaluateManager) {
    typeEvaluateManager.removeNSInfo(this);

    if (myChildNamespaces != null) {
      final TIntObjectIterator<JSNamespace> iterator = myChildNamespaces.iterator();

      while(iterator.hasNext()) {
        iterator.advance();
        iterator.value().invalidate(typeEvaluateManager);
      }
    }
  }
}
