/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript;

import com.intellij.lexer.Lexer;
import com.intellij.openapi.editor.HighlighterColors;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.editor.markup.TextAttributes;
import com.intellij.openapi.fileTypes.SyntaxHighlighterBase;
import com.intellij.psi.StringEscapesTokenTypes;
import com.intellij.psi.JavaDocTokenType;
import com.intellij.psi.tree.IElementType;
import com.intellij.psi.tree.java.IJavaDocElementType;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;

import org.jetbrains.annotations.NotNull;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 27, 2005
 * Time: 11:22:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSHighlighter extends SyntaxHighlighterBase {
  private static Map<IElementType, TextAttributesKey> keys1;
  private static Map<IElementType, TextAttributesKey> keys2;

  @NotNull
  public Lexer getHighlightingLexer() {
    return new JavaScriptHighlightingLexer();
  }

  static final TextAttributesKey JS_KEYWORD = TextAttributesKey.createTextAttributesKey(
                                                "JS.KEYWORD",
                                                HighlighterColors.JAVA_KEYWORD.getDefaultAttributes()
                                              );

  static final TextAttributesKey JS_STRING = TextAttributesKey.createTextAttributesKey(
                                               "JS.STRING",
                                               HighlighterColors.JAVA_STRING.getDefaultAttributes()
                                             );

  static final TextAttributesKey JS_NUMBER = TextAttributesKey.createTextAttributesKey(
                                               "JS.NUMBER",
                                               HighlighterColors.JAVA_NUMBER.getDefaultAttributes()
                                             );

  static final TextAttributesKey JS_REGEXP = TextAttributesKey.createTextAttributesKey(
                                               "JS.REGEXP",
                                               new TextAttributes(Color.blue.brighter(), null, null, null, Font.PLAIN)
                                             );

  static final TextAttributesKey JS_LINE_COMMENT = TextAttributesKey.createTextAttributesKey(
                                                     "JS.LINE_COMMENT",
                                                     HighlighterColors.JAVA_LINE_COMMENT.getDefaultAttributes()
                                                   );

  static final TextAttributesKey JS_BLOCK_COMMENT = TextAttributesKey.createTextAttributesKey(
                                                      "JS.BLOCK_COMMENT",
                                                      HighlighterColors.JAVA_BLOCK_COMMENT.getDefaultAttributes()
                                                    );

  static final TextAttributesKey JS_DOC_COMMENT = TextAttributesKey.createTextAttributesKey(
                                                    "JS.DOC_COMMENT",
                                                    HighlighterColors.JAVA_DOC_COMMENT.getDefaultAttributes()
                                                  );

  static final TextAttributesKey JS_OPERATION_SIGN = TextAttributesKey.createTextAttributesKey(
                                                       "JS.OPERATION_SIGN",
                                                       HighlighterColors.JAVA_OPERATION_SIGN.getDefaultAttributes()
                                                     );

  static final TextAttributesKey JS_PARENTHS = TextAttributesKey.createTextAttributesKey(
                                                 "JS.PARENTHS",
                                                 HighlighterColors.JAVA_PARENTHS.getDefaultAttributes()
                                               );

  static final TextAttributesKey JS_BRACKETS = TextAttributesKey.createTextAttributesKey(
                                                 "JS.BRACKETS",
                                                 HighlighterColors.JAVA_BRACKETS.getDefaultAttributes()
                                               );

  static final TextAttributesKey JS_BRACES = TextAttributesKey.createTextAttributesKey(
                                               "JS.BRACES",
                                               HighlighterColors.JAVA_BRACES.getDefaultAttributes()
                                             );

  static final TextAttributesKey JS_COMMA = TextAttributesKey.createTextAttributesKey(
                                              "JS.COMMA",
                                              HighlighterColors.JAVA_COMMA.getDefaultAttributes()
                                            );

  static final TextAttributesKey JS_DOT = TextAttributesKey.createTextAttributesKey(
                                            "JS.DOT",
                                            HighlighterColors.JAVA_DOT.getDefaultAttributes()
                                          );

  static final TextAttributesKey JS_SEMICOLON = TextAttributesKey.createTextAttributesKey(
                                                  "JS.SEMICOLON",
                                                  HighlighterColors.JAVA_SEMICOLON.getDefaultAttributes()
                                                );

  static final TextAttributesKey JS_BAD_CHARACTER = TextAttributesKey.createTextAttributesKey(
                                                  "JS.BADCHARACTER",
                                                  HighlighterColors.BAD_CHARACTER.getDefaultAttributes()
                                                );
  static final TextAttributesKey JS_DOC_TAG = TextAttributesKey.createTextAttributesKey(
                                                    "JS.DOC_TAG",
                                                    HighlighterColors.JAVA_DOC_TAG.getDefaultAttributes()
                                                  );
  static final TextAttributesKey JS_DOC_MARKUP = TextAttributesKey.createTextAttributesKey(
                                                    "JS.DOC_MARKUP",
                                                    HighlighterColors.JAVA_DOC_MARKUP.getDefaultAttributes()
                                                  );
  static final TextAttributesKey JS_VALID_STRING_ESCAPE = TextAttributesKey.createTextAttributesKey(
                                                    "JS.VALID_STRING_ESCAPE",
                                                    HighlighterColors.JAVA_VALID_STRING_ESCAPE.getDefaultAttributes()
                                                  );
  static final TextAttributesKey JS_INVALID_STRING_ESCAPE = TextAttributesKey.createTextAttributesKey(
                                                    "JS.INVALID_STRING_ESCAPE",
                                                    HighlighterColors.JAVA_INVALID_STRING_ESCAPE.getDefaultAttributes()
                                                  );

  static {
    keys1 = new HashMap<IElementType, TextAttributesKey>();
    keys2 = new HashMap<IElementType, TextAttributesKey>();

    fillMap(keys1, JSTokenTypes.KEYWORDS, JS_KEYWORD);
    fillMap(keys1, JSTokenTypes.OPERATIONS, JS_OPERATION_SIGN);

    keys1.put(StringEscapesTokenTypes.VALID_STRING_ESCAPE_TOKEN, JS_VALID_STRING_ESCAPE);
    keys1.put(StringEscapesTokenTypes.INVALID_CHARACTER_ESCAPE_TOKEN, JS_INVALID_STRING_ESCAPE);
    keys1.put(StringEscapesTokenTypes.INVALID_UNICODE_ESCAPE_TOKEN, JS_INVALID_STRING_ESCAPE);

    keys1.put(JSTokenTypes.NUMERIC_LITERAL, JS_NUMBER);
    keys1.put(JSTokenTypes.STRING_LITERAL, JS_STRING);
    keys1.put(JSTokenTypes.SINGLE_QUOTE_STRING_LITERAL, JS_STRING);
    keys1.put(JSTokenTypes.REGEXP_LITERAL, JS_REGEXP);

    keys1.put(JSTokenTypes.LPAR, JS_PARENTHS);
    keys1.put(JSTokenTypes.RPAR, JS_PARENTHS);

    keys1.put(JSTokenTypes.LBRACE, JS_BRACES);
    keys1.put(JSTokenTypes.RBRACE, JS_BRACES);

    keys1.put(JSTokenTypes.LBRACKET, JS_BRACKETS);
    keys1.put(JSTokenTypes.RBRACKET, JS_BRACKETS);

    keys1.put(JSTokenTypes.COMMA, JS_COMMA);
    keys1.put(JSTokenTypes.DOT, JS_DOT);
    keys1.put(JSTokenTypes.SEMICOLON, JS_SEMICOLON);

    keys1.put(JSTokenTypes.C_STYLE_COMMENT, JS_BLOCK_COMMENT);
    keys1.put(JSTokenTypes.XML_STYLE_COMMENT, JS_BLOCK_COMMENT);
    keys1.put(JSTokenTypes.DOC_COMMENT, JS_DOC_COMMENT);
    keys1.put(JSTokenTypes.END_OF_LINE_COMMENT, JS_LINE_COMMENT);
    keys1.put(JSTokenTypes.BAD_CHARACTER, JS_BAD_CHARACTER);

    keys1.put(JavaDocTokenType.DOC_TAG_NAME, JS_DOC_COMMENT);
    keys2.put(JavaDocTokenType.DOC_TAG_NAME, JS_DOC_TAG);

    IElementType[] javadoc = IElementType.enumerate(new IElementType.Predicate() {
      public boolean matches(IElementType type) {
        return type instanceof IJavaDocElementType;
      }
    });

    for (IElementType type : javadoc) {
      keys1.put(type, JS_DOC_COMMENT);
    }
  }

  @NotNull
  public TextAttributesKey[] getTokenHighlights(IElementType tokenType) {
    return pack(keys1.get(tokenType), keys2.get(tokenType));
  }

  public Map<IElementType, TextAttributesKey> getKeys1() {
    return (Map<IElementType, TextAttributesKey>)((HashMap)keys1).clone();
  }

  public Map<IElementType, TextAttributesKey> getKeys2() {
    return (Map<IElementType, TextAttributesKey>)((HashMap)keys2).clone();
  }

  public static void registerHtmlMarkup(IElementType[] htmlTokens, IElementType[] htmlTokens2) {
    for (IElementType idx : htmlTokens) {
      keys1.put(idx, JS_DOC_COMMENT);
      keys2.put(idx, JS_DOC_MARKUP);
    }

    for (IElementType idx : htmlTokens2) {
      keys1.put(idx, JS_DOC_COMMENT);
    }
  }
}
