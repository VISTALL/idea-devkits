/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript.inspections;

import com.intellij.codeInspection.ex.BaseLocalInspectionTool;
import com.intellij.codeInspection.InspectionManager;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.codeInspection.ProblemsHolder;
import com.intellij.codeInspection.LocalInspectionTool;
import com.intellij.psi.PsiRecursiveElementVisitor;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiElementVisitor;
import com.intellij.psi.css.CssFile;
import com.intellij.psi.jsp.JspFile;
import com.intellij.lang.javascript.psi.JSElementVisitor;
import com.intellij.lang.javascript.psi.JSElement;
import com.intellij.lang.javascript.psi.JSFile;import com.intellij.lang.javascript.psi.JSReferenceExpression;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.fileTypes.FileType;
import com.intellij.codeHighlighting.HighlightDisplayLevel;

import java.util.List;
import java.util.ArrayList;

import org.jetbrains.annotations.Nullable;

/**
 * Created by IntelliJ IDEA.
 * User: Maxim.Mossienko
 * Date: Apr 18, 2006
 * Time: 7:34:46 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class JSInspection extends LocalInspectionTool {
  protected boolean myOnTheFly;
  protected abstract BasePsiElementVisitor createVisitor(final ProblemsHolder holder);

  @Nullable
  public PsiElementVisitor buildVisitor(ProblemsHolder holder, boolean isOnTheFly) {
    myOnTheFly = isOnTheFly;
    return createVisitor(holder);
  }

  public boolean isEnabledByDefault() {
    return true;
  }

  public HighlightDisplayLevel getDefaultLevel() {
    return HighlightDisplayLevel.INFO;
  }

  static abstract class BasePsiElementVisitor extends JSElementVisitor {
    public void visitJSReferenceExpression(final JSReferenceExpression node) {}
  }
}
