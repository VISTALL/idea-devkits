/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript.formatter.blocks;

import com.intellij.formatting.*;
import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.lang.javascript.formatter.JSSpacingProcessor;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiErrorElement;
import com.intellij.psi.PsiWhiteSpace;
import com.intellij.psi.tree.IElementType;
import com.intellij.psi.codeStyle.CodeStyleSettings;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * @author ven
 */
public class JSBlock implements Block {
  private ASTNode myNode;

  private final CodeStyleSettings mySettings;

  private Alignment myAlignment;
  private Indent myIndent;
  private Wrap myWrap;
  private List<Block> mySubBlocks = null;

  public JSBlock(final ASTNode node, final Alignment alignment, final Indent indent, final Wrap wrap, final CodeStyleSettings settings) {
    myAlignment = alignment;
    myIndent = indent;
    myNode = node;
    myWrap = wrap;
    mySettings = settings;
  }

  public ASTNode getNode() {
    return myNode;
  }

  @NotNull
  public TextRange getTextRange() {
    return myNode.getTextRange();
  }

  @NotNull
  public List<Block> getSubBlocks() {
    if (mySubBlocks == null) {
      SubBlockVisitor visitor = new SubBlockVisitor(getSettings());
      visitor.visit(myNode);
      mySubBlocks = visitor.getBlocks();
    }
    return mySubBlocks;
  }

  @Nullable
  public Wrap getWrap() {
    return myWrap;
  }

  @Nullable
  public Indent getIndent() {
    return myIndent;
  }

  @Nullable
  public Alignment getAlignment() {
    return myAlignment;
  }

  @Nullable
  public Spacing getSpacing(Block child1, Block child2) {
    if (child1 instanceof JSDocCommentBlock || child2 instanceof JSDocCommentBlock) {
      return null;
    }
    return new JSSpacingProcessor(getNode(), ((JSBlock)child1).getNode(), ((JSBlock)child2).getNode(), mySettings).getResult();
  }

  @NotNull
  public ChildAttributes getChildAttributes(final int newChildIndex) {
    Indent indent = null;
    final IElementType blockElementType = myNode.getElementType();

    if (blockElementType == JSElementTypes.BLOCK ||
        blockElementType == JSElementTypes.OBJECT_LITERAL_EXPRESSION
       ) {
      indent = Indent.getNormalIndent();
    }
    else if (blockElementType == JSElementTypes.FILE) {
      indent = Indent.getNoneIndent();
    }
    else if (JSElementTypes.SOURCE_ELEMENTS.contains(blockElementType)) {
      indent = Indent.getNoneIndent();
    }

    Alignment alignment = null;
    final List<Block> subBlocks = getSubBlocks();
    for (int i = 0; i < newChildIndex; i++) {
      final Alignment childAlignment = subBlocks.get(i).getAlignment();
      if (childAlignment != null) {
        alignment = childAlignment;
        break;
      }
    }

    // in for loops, alignment is required only for items within parentheses 
    if (blockElementType == JSElementTypes.FOR_STATEMENT ||
        blockElementType == JSElementTypes.FOR_IN_STATEMENT) {
      for(int i=0; i < newChildIndex; i++) {
        if (((JSBlock) subBlocks.get(i)).getNode().getElementType() == JSTokenTypes.RPAR) {
          alignment = null;
          break;
        }
      }
    }

    return new ChildAttributes(indent, alignment);
  }

  public boolean isIncomplete() {
    return isIncomplete(myNode);
  }

  private boolean isIncomplete(ASTNode node) {
    ASTNode lastChild = node.getLastChildNode();
    while (lastChild != null && lastChild.getPsi() instanceof PsiWhiteSpace) {
      lastChild = lastChild.getTreePrev();
    }
    if (lastChild == null) return false;
    if (lastChild.getPsi() instanceof PsiErrorElement) return true;
    return isIncomplete(lastChild);
  }

  public CodeStyleSettings getSettings() {
    return mySettings;
  }

  public boolean isLeaf() {
    if (myNode.getElementType() == JSTokenTypes.DOC_COMMENT) {
      return false;
    }
    return myNode.getFirstChildNode() == null;
  }
}
