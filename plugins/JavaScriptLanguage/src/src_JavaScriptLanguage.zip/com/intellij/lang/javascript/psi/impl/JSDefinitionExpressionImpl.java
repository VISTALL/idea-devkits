package com.intellij.lang.javascript.psi.impl;

import com.intellij.lang.ASTNode;
import com.intellij.lang.javascript.JSElementTypes;
import com.intellij.lang.javascript.psi.*;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiElementVisitor;
import com.intellij.psi.PsiStatement;
import com.intellij.psi.PsiSubstitutor;
import com.intellij.psi.scope.PsiScopeProcessor;
import com.intellij.util.Icons;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

/**
 * Created by IntelliJ IDEA.
 * User: maxim.mossienko
 * Date: Dec 14, 2005
 * Time: 6:40:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSDefinitionExpressionImpl extends JSExpressionImpl implements JSDefinitionExpression {
  public JSDefinitionExpressionImpl(final ASTNode node) {
    super(node);
  }

  public JSExpression getExpression() {
    final ASTNode expressionNode = getNode().findChildByType(JSElementTypes.EXPRESSIONS);
    return expressionNode != null ? (JSExpression)expressionNode.getPsi() : null;
  }

  public String getName() {
    final JSExpression expression = getExpression();
    if (expression instanceof JSReferenceExpression) {
      return ((JSReferenceExpression)expression).getReferencedName();
    }
    return null;
  }

  public PsiElement setName(@NotNull String name) throws IncorrectOperationException {
    final JSExpression expression = getExpression();
    if (expression instanceof JSReferenceExpression) {
      return ((JSReferenceExpression)expression).handleElementRename(name);
    }
    return null;
  }

  public void accept(@NotNull PsiElementVisitor visitor) {
    if (visitor instanceof JSElementVisitor) {
      ((JSElementVisitor)visitor).visitJSDefinitionExpression(this);
    }
    else {
      visitor.visitElement(this);
    }
  }

  public Icon getIcon(int flags) {
    return Icons.VARIABLE_ICON;
  }

  public boolean processDeclarations(@NotNull PsiScopeProcessor processor, @NotNull PsiSubstitutor substitutor, PsiElement lastParent, @NotNull PsiElement place) {
    if (lastParent == null) return processor.execute(this, substitutor);
    return true;
  }

  public void delete() throws IncorrectOperationException {
    final PsiElement parent = getParent();

    if (parent instanceof JSAssignmentExpression) {
      final PsiElement grandParent = parent.getParent();

      if (grandParent instanceof PsiStatement) {
        grandParent.delete();
        return;
      } else if (grandParent instanceof JSBinaryExpression) {
        ((JSBinaryExpression)grandParent).getROperand().replace(((JSAssignmentExpression)parent).getROperand());
        return;
      } else if (grandParent instanceof JSVariable) {
        final JSExpression initializerExpression = ((JSVariable)grandParent).getInitializer();
        initializerExpression.replace(((JSAssignmentExpression)parent).getROperand());
        return;
      }
    }
    super.delete();
  }

  @Nullable
  public ASTNode findNameIdentifier() {
    return null;
  }
}
