package com.intellij.lang.javascript.refactoring.introduceVariable;

import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.ResolveProcessor;
import com.intellij.lang.javascript.psi.impl.JSEmbeddedContentImpl;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.Ref;
import com.intellij.openapi.application.ModalityState;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiManager;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.refactoring.ui.ConflictsDialog;
import com.intellij.refactoring.util.CommonRefactoringUtil;
import com.intellij.util.Alarm;

import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * @author ven
 */
public class JSIntroduceVariableDialog extends DialogWrapper {
  private JCheckBox myReplaceAllCheckBox;
  private JTextField myNameField;
  private JPanel myPanel;
  private final Project myProject;
  private final JSExpression[] myOccurences;
  private final JSExpression myMainOccurence;
  private JLabel myNamePrompt;
  private Alarm myAlarm = new Alarm(Alarm.ThreadToUse.SWING_THREAD);

  protected JSIntroduceVariableDialog(final Project project,
                                      final JSExpression[] occurences,
                                      final JSExpression mainOccurence) {
    super(project, false);
    myProject = project;
    myOccurences = occurences;
    myMainOccurence = mainOccurence;
    if (occurences.length > 1) {
      myReplaceAllCheckBox.setText(JSBundle.message("javascript.introduce.variable.replace.all.occurrences", occurences.length));
    }
    else {
      myReplaceAllCheckBox.setVisible(false);
    }

    myNameField.addKeyListener(new KeyAdapter() {
      public void keyPressed(KeyEvent e) {
        initiateValidation();
      }
    });

    myReplaceAllCheckBox.setFocusable(false);

    myNamePrompt.setLabelFor(myNameField);
    setTitle(JSIntroduceVariableHandler.REFACTORING_NAME);
    init();

    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        initiateValidation();
      }
    });
  }

  private void initiateValidation() {
    myAlarm.cancelAllRequests();
    myAlarm.addRequest(
      new Runnable() {
        public void run() {
          final String nameCandidate = myNameField.getText();
          setOKActionEnabled(nameCandidate.length() != 0 && isValidName(nameCandidate));
        }
      },
      300,
      ModalityState.current()
    );
  }

  public JComponent getPreferredFocusedComponent() {
    return myNameField;
  }

  protected JComponent createCenterPanel() {
    return myPanel;
  }

  public String getName() {
    return myNameField.getText().trim();
  }

  protected void doOKAction() {
    final String name = getName();
    if (name.length() == 0 || !isValidName(name)) {
      Messages.showErrorDialog(myProject, JSBundle.message("javascript.introduce.variable.invalid.name"), JSIntroduceVariableHandler.REFACTORING_NAME);
      myNameField.requestFocus();
      return;
    }

    if (!checkConflicts(name)) return;

    super.doOKAction();
  }

  private boolean checkConflicts(final String name) {
    PsiElement tmp = isReplaceAllOccurences() ?
                       PsiTreeUtil.findCommonParent(myOccurences) :
                       myMainOccurence;
    assert tmp != null;
    JSElement scope = PsiTreeUtil.getNonStrictParentOfType(tmp, JSBlockStatement.class, JSFile.class, JSEmbeddedContentImpl.class);
    assert scope != null;

    final Ref<JSNamedElement> existing = new Ref<JSNamedElement>();
    scope.accept(new JSElementVisitor() {
      public void visitJSElement(final JSElement node) {
        if (existing.isNull()) {
          node.acceptChildren(this);
        }
      }

      public void visitJSVariable(final JSVariable node) {
        if (name.equals(node.getName())) existing.set(node);
        super.visitJSVariable(node);
      }
      public void visitJSFunctionDeclaration(final JSFunction node) {
        if (name.equals(node.getName())) existing.set(node);
        super.visitJSFunctionDeclaration(node);
      }
    });

    if (existing.isNull()) {
      final JSElement resolved = JSResolveUtil.treeWalkUp(new ResolveProcessor(name), scope, null, scope);
      if (resolved instanceof JSNamedElement) {
        existing.set((JSNamedElement)resolved);
      }
    }

    if (!existing.isNull()) {
      return showConflictsDialog(existing.get(), name);
    }

    return true;
  }

  private boolean showConflictsDialog(final JSNamedElement existing, final String name) {
    final String message = existing instanceof JSFunction ?
                           JSBundle.message("javascript.introduce.variable.function.already.exists", CommonRefactoringUtil.htmlEmphasize(name)) :
                           JSBundle.message("javascript.introduce.variable.variable.already.exists", CommonRefactoringUtil.htmlEmphasize(name));
    final ConflictsDialog conflictsDialog = new ConflictsDialog(myProject, message);
    conflictsDialog.show();
    return conflictsDialog.isOK();
  }

  public boolean isReplaceAllOccurences() {
    return myReplaceAllCheckBox.isSelected();
  }

  private boolean isValidName(final String name) {
    return JavaScriptSupportLoader.JAVASCRIPT.getLanguage().getNamesValidator().isIdentifier(name, myProject);
  }
}
