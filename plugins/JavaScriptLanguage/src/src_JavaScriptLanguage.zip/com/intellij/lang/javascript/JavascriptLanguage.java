/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript;

import com.intellij.formatting.FormattingModel;
import com.intellij.formatting.FormattingModelBuilder;
import com.intellij.ide.structureView.StructureViewBuilder;
import com.intellij.ide.structureView.StructureViewModel;
import com.intellij.ide.structureView.TreeBasedStructureViewBuilder;
import com.intellij.lang.*;
import com.intellij.lang.refactoring.RefactoringSupportProvider;
import com.intellij.lang.refactoring.DefaultRefactoringSupportProvider;
import com.intellij.lang.refactoring.NamesValidator;
import com.intellij.lang.annotation.Annotator;
import com.intellij.lang.findUsages.FindUsagesProvider;
import com.intellij.lang.folding.FoldingBuilder;
import com.intellij.lang.javascript.findUsages.JavaScriptFindUsagesProvider;
import com.intellij.lang.javascript.folding.JavaScriptFoldingBuilder;
import com.intellij.lang.javascript.formatter.JSFormattingModel;
import com.intellij.lang.javascript.formatter.blocks.JSBlock;
import com.intellij.lang.javascript.psi.JSElement;
import com.intellij.lang.javascript.psi.JSFile;
import com.intellij.lang.javascript.structureView.JSStructureViewModel;
import com.intellij.lang.javascript.surroundWith.JSExpressionSurroundDescriptor;
import com.intellij.lang.javascript.surroundWith.JSStatementsSurroundDescriptor;
import com.intellij.lang.javascript.validation.JSAnnotatingVisitor;
import com.intellij.lang.javascript.refactoring.introduceVariable.JSIntroduceVariableHandler;
import com.intellij.lang.surroundWith.SurroundDescriptor;
import com.intellij.openapi.fileTypes.SyntaxHighlighter;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.codeStyle.CodeStyleSettings;
import com.intellij.refactoring.RefactoringActionHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 27, 2005
 * Time: 6:03:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class JavascriptLanguage extends Language {
  private ParserDefinition myParserDefinition;
  
  private static final JSAnnotatingVisitor ANNOTATOR = new JSAnnotatingVisitor();
  private final static SurroundDescriptor[] SURROUND_DESCRIPTORS = new SurroundDescriptor[] {
    new JSExpressionSurroundDescriptor(),
    new JSStatementsSurroundDescriptor()
  };
  private JavaScriptFindUsagesProvider myJavaScriptFindUsagesProvider;
  private NamesValidator myNamesValidator;

  public JavascriptLanguage() {
    super("JavaScript", "text/javascript", "application/javascript");
  }

  public ParserDefinition getParserDefinition() {
    if (myParserDefinition == null) myParserDefinition = new JavascriptParserDefinition();
    return myParserDefinition;
  }

  @NotNull
  public SyntaxHighlighter getSyntaxHighlighter(Project project, final VirtualFile virtualFile) {
    return new JSHighlighter();
  }

  public FoldingBuilder getFoldingBuilder() {
    return new JavaScriptFoldingBuilder();
  }

  public PairedBraceMatcher getPairedBraceMatcher() {
    return new JSBraceMatcher();
  }

  public Annotator getAnnotator() {
    return ANNOTATOR;
  }

  public StructureViewBuilder getStructureViewBuilder(final PsiFile psiFile) {
    return new TreeBasedStructureViewBuilder() {
      public StructureViewModel createStructureViewModel() {
        return new JSStructureViewModel((JSElement)psiFile);
      }
    };
  }

  @NotNull
  public FindUsagesProvider getFindUsagesProvider() {
    if (myJavaScriptFindUsagesProvider == null) {
      myJavaScriptFindUsagesProvider = new JavaScriptFindUsagesProvider();
    }
    return myJavaScriptFindUsagesProvider;
  }

  @NotNull
  public NamesValidator getNamesValidator() {
    if (myNamesValidator == null) myNamesValidator = new JSNamesValidator();
    return myNamesValidator;
  }

  public Commenter getCommenter() {
    return new JavascriptCommenter();
  }

  public FormattingModelBuilder getFormattingModelBuilder() {
    return new FormattingModelBuilder() {
      @NotNull
      public FormattingModel createModel(final PsiElement element, final CodeStyleSettings settings) {
        final PsiFile psiFile = element.getContainingFile();
        
        return new JSFormattingModel(
          psiFile,
          settings,
          new JSBlock(
            psiFile instanceof JSFile ? psiFile.getNode() : element.getNode(),
            null,
            null,
            null,
            settings
          )
        );
      }
    };
  }

  @NotNull
  public SurroundDescriptor[] getSurroundDescriptors() {
    return SURROUND_DESCRIPTORS;
  }

  @NotNull
  public RefactoringSupportProvider getRefactoringSupportProvider() {
    return new DefaultRefactoringSupportProvider() {
      @Nullable
      public RefactoringActionHandler getIntroduceVariableHandler() {
        return new JSIntroduceVariableHandler();
      }
    };
  }

}
