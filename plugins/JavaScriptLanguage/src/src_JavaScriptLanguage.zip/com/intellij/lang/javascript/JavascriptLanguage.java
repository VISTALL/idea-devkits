/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.lang.javascript;

import com.intellij.codeInsight.navigation.NavigationUtil;
import com.intellij.formatting.FormattingModel;
import com.intellij.formatting.FormattingModelBuilder;
import com.intellij.ide.structureView.StructureViewBuilder;
import com.intellij.ide.structureView.StructureViewModel;
import com.intellij.ide.structureView.TreeBasedStructureViewBuilder;
import com.intellij.javascript.JSParameterInfoHandler;
import com.intellij.lang.*;
import com.intellij.lang.annotation.Annotator;
import com.intellij.lang.documentation.DocumentationProvider;
import com.intellij.lang.findUsages.FindUsagesProvider;
import com.intellij.lang.folding.FoldingBuilder;
import com.intellij.lang.javascript.findUsages.JavaScriptFindUsagesProvider;
import com.intellij.lang.javascript.folding.JavaScriptFoldingBuilder;
import com.intellij.lang.javascript.formatter.JSFormattingModel;
import com.intellij.lang.javascript.formatter.blocks.JSBlock;
import com.intellij.lang.javascript.index.JSNamedElementProxy;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.resolve.ResolveProcessor;
import com.intellij.lang.javascript.refactoring.introduceVariable.JSIntroduceVariableHandler;
import com.intellij.lang.javascript.structureView.JSStructureViewModel;
import com.intellij.lang.javascript.surroundWith.JSExpressionSurroundDescriptor;
import com.intellij.lang.javascript.surroundWith.JSStatementsSurroundDescriptor;
import com.intellij.lang.javascript.validation.JSAnnotatingVisitor;
import com.intellij.lang.parameterInfo.ParameterInfoHandler;
import com.intellij.lang.refactoring.DefaultRefactoringSupportProvider;
import com.intellij.lang.refactoring.NamesValidator;
import com.intellij.lang.refactoring.RefactoringSupportProvider;
import com.intellij.lang.surroundWith.SurroundDescriptor;
import com.intellij.navigation.NavigationItem;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileTypes.SyntaxHighlighter;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.codeStyle.CodeStyleSettings;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.refactoring.RefactoringActionHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Created by IntelliJ IDEA.
 * User: max
 * Date: Jan 27, 2005
 * Time: 6:03:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class JavascriptLanguage extends Language {
  private ParserDefinition myParserDefinition;

  private static final JSAnnotatingVisitor ANNOTATOR = new JSAnnotatingVisitor();

  private final static SurroundDescriptor[] SURROUND_DESCRIPTORS = new SurroundDescriptor[] {
    new JSExpressionSurroundDescriptor(),
    new JSStatementsSurroundDescriptor()
  };
  private JavaScriptFindUsagesProvider myJavaScriptFindUsagesProvider;
  private NamesValidator myNamesValidator;
  private LanguageDialect[] ourLanguageDialects;
  public static final DialectOptionHolder DIALECT_OPTION_HOLDER = new DialectOptionHolder(false, false);

  public JavascriptLanguage() {
    super("JavaScript", "text/javascript", "application/javascript");
  }

  public ParserDefinition getParserDefinition() {
    if (myParserDefinition == null) myParserDefinition = new JavascriptParserDefinition();
    return myParserDefinition;
  }

  @NotNull
  public SyntaxHighlighter getSyntaxHighlighter(Project project, final VirtualFile virtualFile) {
    return new JSHighlighter(DIALECT_OPTION_HOLDER);
  }

  public FoldingBuilder getFoldingBuilder() {
    return new JavaScriptFoldingBuilder();
  }

  public PairedBraceMatcher getPairedBraceMatcher() {
    return new JSBraceMatcher();
  }

  public Annotator getAnnotator() {
    return ANNOTATOR;
  }

  public StructureViewBuilder getStructureViewBuilder(final PsiFile psiFile) {
    return new TreeBasedStructureViewBuilder() {
      @NotNull
      public StructureViewModel createStructureViewModel() {
        return new JSStructureViewModel(psiFile);
      }
    };
  }

  @NotNull
  public FindUsagesProvider getFindUsagesProvider() {
    if (myJavaScriptFindUsagesProvider == null) {
      myJavaScriptFindUsagesProvider = new JavaScriptFindUsagesProvider();
    }
    return myJavaScriptFindUsagesProvider;
  }

  @NotNull
  public NamesValidator getNamesValidator() {
    if (myNamesValidator == null) myNamesValidator = new JSNamesValidator(DIALECT_OPTION_HOLDER);
    return myNamesValidator;
  }

  public Commenter getCommenter() {
    return new JavascriptCommenter();
  }

  public FormattingModelBuilder getFormattingModelBuilder() {
    return new FormattingModelBuilder() {
      @NotNull
      public FormattingModel createModel(final PsiElement element, final CodeStyleSettings settings) {
        final PsiFile psiFile = element.getContainingFile();
        
        return new JSFormattingModel(
          psiFile,
          settings,
          new JSBlock(
            psiFile instanceof JSFile ? psiFile.getNode() : element.getNode(),
            null,
            null,
            null,
            settings
          )
        );
      }
    };
  }

  @NotNull
  public SurroundDescriptor[] getSurroundDescriptors() {
    return SURROUND_DESCRIPTORS;
  }

  @NotNull
  public RefactoringSupportProvider getRefactoringSupportProvider() {
    return new DefaultRefactoringSupportProvider() {
      public boolean isSafeDeleteAvailable(PsiElement element) {
        boolean simpleElement =
          element instanceof JSFunction || element instanceof JSVariable || element instanceof JSDefinitionExpression ||
          element instanceof JSProperty || element instanceof JSClass;

        if (element instanceof JSNamedElementProxy) {
          final JSNamedElementProxy.NamedItemType namedItemType = ((JSNamedElementProxy)element).getType();

          simpleElement = namedItemType != JSNamedElementProxy.NamedItemType.AttributeValue;
        }
        
        return simpleElement && ((JSNamedElement)element).getName() != null;
      }

      @Nullable
      public RefactoringActionHandler getIntroduceVariableHandler() {
        return new JSIntroduceVariableHandler();
      }
    };
  }

  protected DocumentationProvider createDocumentationProvider() {
    return ourDocumentationProvider;
  }

  private static DocumentationProvider ourDocumentationProvider;

  public static void installDocumentationProvider(final DocumentationProvider documentationProvider) {
    ourDocumentationProvider = documentationProvider;
  }

  public @Nullable LanguageDialect[] getAvailableLanguageDialects() {
    if (ourLanguageDialects == null) {
      ourLanguageDialects = new LanguageDialect[] {
        JavaScriptSupportLoader.ECMA_SCRIPT_L4, JavaScriptSupportLoader.JSON, JavaScriptSupportLoader.GWT_DIALECT
      };
    }
    return ourLanguageDialects;
  }

  public @Nullable
  ParameterInfoHandler[] getParameterInfoHandlers() {
    return new ParameterInfoHandler[] { new JSParameterInfoHandler() };
  }

  @Nullable
  public LanguageCodeInsightActionHandler getGotoSuperHandler() {
    return new LanguageCodeInsightActionHandler() {
      public void invoke(final Project project, final Editor editor, final PsiFile file) {
        final PsiElement at = file.findElementAt(editor.getCaretModel().getOffset());
        if (at == null) return;
        JSNamedElement namedElement = PsiTreeUtil.getParentOfType(at, JSNamedElement.class);
        final PsiElement parent = namedElement != null ? namedElement.getParent():null;

        if (namedElement instanceof JSDefinitionExpression) {
          if (parent instanceof JSAssignmentExpression) {
            PsiElement rOperand = ((JSAssignmentExpression)parent).getROperand();
            if (rOperand instanceof JSFunctionExpression) {
              namedElement = (JSNamedElement)rOperand;
            }
          }
        }

        if (namedElement instanceof JSFunction) {
          final String qName = JSResolveUtil.getQNameToStartHierarchySearch((JSFunction)namedElement);

          if (qName != null) {
            JSResolveUtil.iterateType(
              (JSFunction)namedElement,
              parent instanceof JSClass ? parent:parent.getContainingFile(),
              qName,
              new JSResolveUtil.OverrideHandler() {
                public void process(final ResolveProcessor processor, final PsiElement scope, final String className, final String overrideKey) {
                  ((NavigationItem)processor.getResult()).navigate(true);
                }
              }
            );
          }
        } else if (namedElement instanceof JSClass) {
          final JSClass clazz = (JSClass)namedElement;
          final JSClass[] classes = clazz.getSupers();

          if (classes.length == 0) return;
          if (classes.length == 1) classes[0].navigate(true);
          else {
            NavigationUtil.getPsiElementPopup(classes, "Choose super class or interface").showInBestPositionFor(editor);
          }
        }
      }

      public boolean startInWriteAction() {
        return false;
      }

      public boolean isValidFor(final Editor editor, final PsiFile file) {
        return true;
      }
    };
  }
}
