package com.intellij.lang.javascript.psi.impl;

import com.intellij.lang.ASTNode;

/**
 * @author ven
 */
public class JSStatementImpl extends JSStubbedStatementImpl {
  public JSStatementImpl(final ASTNode node) {
    super(node);
  }
}
