package com.intellij.lang.javascript.index;

import com.intellij.lang.javascript.psi.*;
import com.intellij.navigation.NavigationItem;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.psi.*;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.psi.xml.XmlAttribute;
import com.intellij.psi.util.CachedValue;
import com.intellij.psi.util.CachedValueProvider;
import com.intellij.psi.util.PsiTreeUtil;
import org.jetbrains.annotations.Nullable;
import static com.intellij.lang.javascript.index.JSNamedElementProxy.NamedItemType;

import java.util.*;
import java.io.IOException;

import gnu.trove.TIntObjectHashMap;
import gnu.trove.TIntObjectIterator;
import gnu.trove.THashMap;

/**
 * Created by IntelliJ IDEA.
 * User: yole
 * Date: 03.10.2005
 * Time: 15:20:37
 * To change this template use File | Settings | File Templates.
 */
public final class JSIndexEntry {
  private PsiFile myPsiFile;

  public void initTypesAndBrowserSpecifics() {
    final BrowserSupportManager browserSupportManager = BrowserSupportManager.getInstance(myPsiFile.getProject());
    final JSTypeEvaluateManager typeEvaluateManager = JSTypeEvaluateManager.getInstance(myPsiFile.getProject());

    for(JSNamedElement el:myIndexValue.getValue().mySymbolNameComponents.keySet()) {
      JSElement realElement = PsiTreeUtil.getParentOfType(((JSNamedElementProxy)el).getElement(), JSStatement.class);
      final PsiElement lastChild = realElement.getNextSibling();

      if (lastChild instanceof PsiComment) {
        final String s = lastChild.getText().substring(2);
        final int typeIndex = s.indexOf(',');
        final String browserType = typeIndex != -1 ? s.substring(0, typeIndex).toLowerCase():"";

        if (browserType.equals("ie")) {
          browserSupportManager.addIESpecificSymbol(el);
        } else if (browserType.equals("gecko")) {
          browserSupportManager.addGeckoSpecificSymbol(el);
        }

        typeEvaluateManager.setElementType(el, s.substring(typeIndex + 1));
      }
    }
  }

  public static void encodeBrowserSpecificsAndType(StringBuilder builder, String browserSpecific, String type) {
    if (type == null) type = "Object";
    builder.append( "//" );
    final int length = builder.length();

    if (browserSpecific != null) {
      builder.append(browserSpecific);
    }
    if (type != null) {
      if (length != builder.length()) builder.append(',');
      builder.append(type);
    }
  }

  final PsiFile getFile() {
    return myPsiFile;
  }

  public void write(final SerializationContext context) throws IOException {
    final IndexEntryContent indexEntryContent = myIndexValue.getValue();
    indexEntryContent.myNamespace.write(context);

    final Map<JSNamedElement, JSNamespace> components = indexEntryContent.mySymbolNameComponents;
    context.outputStream.writeInt(components.size());

    for(JSNamedElement key: components.keySet()) {
      ((JSNamedElementProxy)key).write(context);
      context.outputStream.writeInt(context.myNameSpaces.get( components.get(key) ));
    }
  }

  public void enumerateNames(final SerializationContext context) {
    final IndexEntryContent indexEntryContent = myIndexValue.getValue();
    for(JSNamedElement item: indexEntryContent.mySymbolNameComponents.keySet()) {
      ((JSNamedElementProxy)item).enumerateNames(context);
    }
    indexEntryContent.myNamespace.enumerateNames(context);
  }

  JSNamespace getNamespace(final JSNamedElement myJSNamedItem) {
    return myIndexValue.getValue().mySymbolNameComponents.get(myJSNamedItem);
  }

  void invalidate() {
    final JSTypeEvaluateManager typeEvaluateManager = JSTypeEvaluateManager.getInstance(myPsiFile.getProject());
    for(Map.Entry<JSNamedElement,JSNamespace> entry:myContent.mySymbolNameComponents.entrySet()) {
      typeEvaluateManager.removeElementInfo(entry.getKey());
    }
    myContent.myNamespace.invalidate(typeEvaluateManager);
  }

  static class IndexEntryContent {
    private final TIntObjectHashMap<Object> mySymbols = new TIntObjectHashMap<Object>();
    private Map<JSNamedElement,JSNamespace> mySymbolNameComponents = new THashMap<JSNamedElement,JSNamespace>();
    private final JSNamespace myNamespace = new JSNamespace();
  }

  private CachedValue<IndexEntryContent> myIndexValue;
  private IndexEntryContent myContent;

  public JSIndexEntry(final DeserializationContext context, @Nullable JSFile file) throws IOException {
    final IndexEntryContent indexEntryContent = new IndexEntryContent();
    indexEntryContent.myNamespace.read(context, null);

    int mySymbolNameComponentsSize = context.inputStream.readInt();

    for(int i = 0; i < mySymbolNameComponentsSize; ++i) {
      JSNamedElementProxy proxy = new MyJSNamedItem(this, context);

      final JSNamespace namespace = context.myNameSpaces.get(context.inputStream.readInt());
      doAddNamedItemProxy(proxy.getNameId(), proxy, false, namespace, indexEntryContent);
    }

    doInitFor(file, context.manager, indexEntryContent);
  }

  public JSIndexEntry(final PsiFile psiFile) {
    doInitFor(psiFile, psiFile.getManager(), null);
    myIndexValue.getValue();
  }

  private static void doAddNamedItemProxy(final int nameId, final JSNamedElement myElement,
                                              final boolean toCheckUniqueness,final JSNamespace namespace,
                                              IndexEntryContent myContent) {
    final Object o = myContent.mySymbols.get(nameId);
    if (o == null) {
      myContent.mySymbols.put(nameId,myElement);
    }
    else if (o instanceof JSNamedElement) {
      if (toCheckUniqueness && myContent.mySymbolNameComponents.get((JSNamedElement)o) == namespace) {
        if (((MyJSNamedItem)o).getType() == NamedItemType.Definition) return;
      }
      myContent.mySymbols.put(nameId,new Object[] { o, myElement });
    } else {
      final Object[] oArray = (Object[])o;

      if (toCheckUniqueness) {
        for(Object oE:oArray) {
          if (myContent.mySymbolNameComponents.get((JSNamedElement)oE) == namespace) {
            if (((MyJSNamedItem)oE).getType() == NamedItemType.Definition) return;
          }
        }
      }

      Object[] newArray = new Object[oArray.length + 1];
      System.arraycopy(oArray,0,newArray,0,oArray.length);
      newArray[oArray.length] = myElement;
      myContent.mySymbols.put(nameId,newArray);
    }

    myContent.mySymbolNameComponents.put(myElement, namespace);
  }

  private void doInitFor(final PsiFile psiFile, PsiManager manager, final IndexEntryContent content) {
    myPsiFile = psiFile;
    myIndexValue = manager.getCachedValuesManager().createCachedValue(new CachedValueProvider<IndexEntryContent>() {
      boolean computeFirstTime = true;

      public Result<IndexEntryContent> compute() {
        myContent = content != null ? content : new IndexEntryContent();

        if (computeFirstTime) {
          computeFirstTime = false;

          if (content != null) { // loaded from disk
            return new Result<IndexEntryContent>(myContent,psiFile);
          }
        }

        invalidate();
        myContent.mySymbolNameComponents.clear();
        myContent.mySymbols.clear();

        updateFromTree();

        return new Result<IndexEntryContent>(myContent,psiFile);
      }

      private void updateFromTree() {
        JSSymbolUtil.visitSymbols(myPsiFile, myContent.myNamespace, new JavaScriptSymbolProcessor() {
          public void processFunction(JSNamespace namespace, final int nameId, JSNamedElement function) {
            addSymbol(
              nameId,
              function,
              function instanceof JSFunctionExpression ?
              (function.getParent() instanceof JSProperty ?
                 NamedItemType.FunctionProperty :
                 NamedItemType.FunctionExpression) :
              NamedItemType.Function,
              namespace
            );
          }

          private final void addSymbol(final int nameId, final PsiElement element,
                                 NamedItemType type, JSNamespace namespace) {
            if (nameId == -1) return;

            final JSNamedElement myElement = new MyJSNamedItem(JSIndexEntry.this, element.getTextOffset(), nameId, type );
            boolean toCheckUniqueness = element instanceof JSDefinitionExpression;

            if (toCheckUniqueness) {
              JSExpression expression = ((JSDefinitionExpression)element).getExpression();
              while(expression instanceof JSReferenceExpression) {
                expression = ((JSReferenceExpression)expression).getQualifier();
              }

              toCheckUniqueness = expression instanceof JSThisExpression;
            }

            doAddNamedItemProxy(nameId, myElement, toCheckUniqueness, namespace,myContent);
          }

          public void processVariable(JSNamespace namespace, final int nameId, JSNamedElement variable) {
            addSymbol(nameId, variable, NamedItemType.Variable, namespace);
          }

          public boolean acceptsFile(PsiFile file) {
            return true;
          }

          public PsiFile getBaseFile() {
            return null;
          }

          public void processProperty(final JSNamespace namespace, final int nameId, final JSNamedElement property) {
            addSymbol(nameId, property, NamedItemType.Property, namespace);
          }

          public void processDefinition(final JSNamespace namespace, final int nameId, final JSNamedElement expression) {
            //if (namespace.length > 0) {
              final JSDefinitionExpression element = (JSDefinitionExpression)expression;
              addSymbol(
                nameId,
                element,
                NamedItemType.Definition,
                namespace
              );
            //}
          }

          @Nullable
          public int getRequiredNameId() {
            return -1;
          }

          public void processTag(JSNamespace namespace, final int nameId, PsiNamedElement namedElement, final String attrName) {
            if (myPsiFile instanceof XmlFile) {
              final XmlAttribute attribute = ((XmlTag)namedElement).getAttribute(attrName, null);
              final XmlAttributeValue xmlAttributeValue = attribute != null ? attribute.getValueElement():null;
              final PsiElement[] chidren = xmlAttributeValue != null ? xmlAttributeValue.getChildren(): PsiElement.EMPTY_ARRAY;

              if (chidren.length == 3) {
                addSymbol(
                  nameId,
                  chidren[1],
                  NamedItemType.AttributeValue,
                  namespace
                );
              }
            }
          }
        });
      }
    }, false);
  }

  public void fillSymbolNames(final Set<String> symbolNames) {
    synchronized(this) {
      final TIntObjectIterator<Object> symbolsIterator = myIndexValue.getValue().mySymbols.iterator();
      final JavaScriptIndex index = JavaScriptIndex.getInstance(myPsiFile.getProject());

      while(symbolsIterator.hasNext()) {
        symbolsIterator.advance();
        symbolNames.add(index.getStringByIndex(symbolsIterator.key()));
      }
    }
  }

  public void fillSymbolsByName(final String name, final Set<NavigationItem> symbolNavItems) {
    synchronized(this) {
      if (JavaScriptIndex.isFromPredefinedFile(myPsiFile) && !ApplicationManager.getApplication().isUnitTestMode()) {
        return; // predefined
      }

      final IndexEntryContent index = myIndexValue.getValue();

      final Object value = index.mySymbols.get( JavaScriptIndex.getInstance( myPsiFile.getProject() ).getIndexOf( name ) );
      if (value instanceof Object[]) {
        for(Object o:(Object[])value) {
          symbolNavItems.add( (NavigationItem)o );
        }
      } else if (value != null) {
        symbolNavItems.add( (NavigationItem)value );
      }
    }
  }

  public void processSymbols(JavaScriptSymbolProcessor processor) {
    ProgressManager.getInstance().checkCanceled();

    synchronized(this) {
      if (!myPsiFile.isValid()) return;
      final JSIndexEntry.IndexEntryContent index = myIndexValue.getValue();

      if (!processor.acceptsFile(myPsiFile)) return;

      final int requiredNameId = processor.getRequiredNameId();
      if (requiredNameId != -1) {
        final Object value = index.mySymbols.get(requiredNameId);

        if (value instanceof Object[]) {
          for(Object item:(Object[])value) {
            dispatchProcessorCall(index, (JSNamedElementProxy)item, processor);
          }
        } else if (value != null) {
          dispatchProcessorCall(index, (JSNamedElementProxy)value, processor);
        }
      } else { // full scan
        final TIntObjectIterator<Object> iterator = index.mySymbols.iterator();
        while(iterator.hasNext()) {
          iterator.advance();
          final Object value = iterator.value();

          if (value instanceof Object[]) {
            for(Object item:(Object[])value) {
              dispatchProcessorCall(index, (JSNamedElementProxy)item, processor);
            }
          } else {
            dispatchProcessorCall(index, (JSNamedElementProxy)value, processor);
          }
        }
      }
    }
  }

  private static void dispatchProcessorCall(final IndexEntryContent index,
                                            final JSNamedElementProxy item,
                                            final JavaScriptSymbolProcessor processor) {
    final JSNamespace namespace = index.mySymbolNameComponents.get(item);

    final NamedItemType itemType = item.getType();
    final int nameId = item.getNameId();

    if (itemType == NamedItemType.Variable) {
      processor.processVariable(namespace, nameId, item);
    }
    else if (itemType == NamedItemType.Function ||
             itemType == NamedItemType.FunctionExpression ||
             itemType == NamedItemType.FunctionProperty
             ) {
      processor.processFunction(namespace, nameId, item);
    }
    else if (itemType == NamedItemType.Property) {
      processor.processProperty(namespace, nameId, item);
    }
    else if (itemType == NamedItemType.Definition) {
      processor.processDefinition(namespace, nameId, item);
    } else if (itemType == NamedItemType.AttributeValue) {
      processor.processTag(namespace, nameId, item, null);
    }
  }
}
