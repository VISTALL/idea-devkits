package com.intellij.lang.javascript.psi;

/**
 * @author ven
 */
public interface JSQualifiedNamedElement extends JSNamedElement {
  String getQualifiedName();
}