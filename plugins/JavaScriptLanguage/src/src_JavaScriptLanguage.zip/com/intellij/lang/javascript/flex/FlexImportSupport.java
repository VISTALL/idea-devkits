package com.intellij.lang.javascript.flex;

import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.index.JavaScriptIndex;
import com.intellij.lang.javascript.psi.JSFile;
import com.intellij.lang.javascript.psi.JSReferenceExpression;
import com.intellij.lang.javascript.psi.impl.JSChangeUtil;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.vfs.VfsUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.*;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.util.ArrayUtil;
import gnu.trove.THashMap;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.Map;

/**
 * @author Maxim.Mossienko
 */
public class FlexImportSupport {
  // flex2.compiler.mxml.lang.StandardDefs
  private static @NonNls String[] standardMxmlImports = new String[]{"mx.styles.*", "mx.binding.*", "mx.core.mx_internal",
    "mx.core.IDeferredInstance", "mx.core.IFactory", "mx.core.IPropertyChangeNotifier", "mx.core.ClassFactory",
    "mx.core.DeferredInstanceFromClass", "mx.core.DeferredInstanceFromFunction",};

  private static @NonNls String[] airOnlyImplicitImports =
    new String[]{"flash.data.*", "flash.desktop.*", "flash.filesystem.*", "flash.html.*", "flash.html.script.*"};

  private static @NonNls String[] implicitImports = new String[]{"flash.accessibility.*", "flash.debugger.*", "flash.display.*", "flash.errors.*",
    "flash.events.*", "flash.external.*", "flash.filters.*", "flash.geom.*", "flash.media.*", "flash.net.*", "flash.printing.*",
    "flash.profiler.*", "flash.system.*", "flash.text.*", "flash.ui.*", "flash.utils.*", "flash.xml.*"};

  public static final Map<String,Object> implicitImportListMap = new THashMap<String, Object>();
  public static final Map<String,Object> mxmlImportListMap = new THashMap<String, Object>();
  static {
    fillMapFromImportsArray(implicitImports, implicitImportListMap);
    fillMapFromImportsArray(standardMxmlImports, mxmlImportListMap);
  }

  private static void fillMapFromImportsArray(final String[] strings, final Map<String, Object> map) {
    for(String s: strings) {
      final int index = s.lastIndexOf('.');
      final String key = s.substring(index + 1);
      final String value = s.substring(0, index);
      final Object o = map.get(key);

      if (o == null) {
        map.put(key, value);
      } else if (o instanceof String) {
        map.put(key, new String[] {value, (String)o});
      } else {
        map.put(key, ArrayUtil.append((String[])o, value));
      }
    }
  }

  public static JSReferenceExpression resolveTypeNameUsingImplicitImports(@NotNull String referenceName, @NotNull JSFile file) {
    final PsiElement context = file.getContext();

    if (context != null) {
      JSReferenceExpression expression = tryFindInMap(referenceName, file, implicitImportListMap);
      if (expression != null) return expression;
      expression = tryFindInMap(referenceName, file, mxmlImportListMap);
      if (expression != null) return expression;
    }
    return null;
  }

  private static JSReferenceExpression tryFindInMap(final String referenceName, final JSFile file, final Map<String, Object> map) {
    Object o = map.get(referenceName);
    String s = null;

    if (o instanceof String) {
      s = (String)o;
    } else if (o instanceof String[]) {
      s = ((String[])o)[0];
    } else {
      o = map.get("*");

      if (o instanceof String) {
        JSReferenceExpression expression = tryFindClass(referenceName, file, (String)o);
        if (expression != null) return expression;
      } else if (o instanceof String[]) {
        for(String s2:(String[])o) {
          JSReferenceExpression expression = tryFindClass(referenceName, file, s2);
          if (expression != null) return expression;
        }
      }
    }

    if (s != null) {
      JSReferenceExpression expression = tryFindClass(referenceName, file, s);
      if (expression != null) return expression;
    }

    return null;
  }

  private static JSReferenceExpression tryFindClass(final String referenceName, final JSFile file, final String o) {
    String nameToTry = o + "." + referenceName;
    Project project = file.getProject();
    PsiElement element = JSResolveUtil.findClassByQName(nameToTry, JavaScriptIndex.getInstance(project));

    if (element != null) {
      return (JSReferenceExpression)JSChangeUtil.createExpressionFromText(project, nameToTry).getPsi();
    }

    return null;
  }

  public static boolean processMxmlFilesInPackage(final Module module, Project project, final String packageName, MxmlFilesProcessor processor) {
    PsiPackage aPackage = PsiManager.getInstance(project).findPackage(packageName);
    PsiDirectory[] directories =
      aPackage != null ? aPackage.getDirectories(module != null ? GlobalSearchScope.moduleRuntimeScope(module, false) : GlobalSearchScope.projectScope(project)): PsiDirectory.EMPTY_ARRAY;

    for (PsiDirectory dir : directories) {
      processor.addDependency(dir);

      for (PsiFile file : dir.getFiles()) {
        if (JavaScriptSupportLoader.isFlexMxmFile(file)) {
          if (!processor.processFile(file.getVirtualFile())) return false;
        }
      }
    }

    final VirtualFile[] files = module != null
                                ? ModuleRootManager.getInstance(module).getContentRoots()
                                : ProjectRootManager.getInstance(project).getContentRoots();
    if (processMxmlFilesWithPackageName(packageName, processor, files)) return false;

    if (module != null) {
      for(Module depedent:ModuleRootManager.getInstance(module).getDependencies()) {
        if (processMxmlFilesWithPackageName(packageName, processor, ModuleRootManager.getInstance(depedent).getContentRoots())) return false;
      }
    }

    return true;
  }

  private static boolean processMxmlFilesWithPackageName(final String packageName, final MxmlFilesProcessor processor, final VirtualFile[] files) {
    for(VirtualFile file: files) {
      final VirtualFile relativeFile = VfsUtil.findRelativeFile(packageName.replace('.', '/'), file);

      if (relativeFile != null && relativeFile.isDirectory()) {
        for (VirtualFile vfile : relativeFile.getChildren()) {
          if (JavaScriptSupportLoader.isFlexMxmFile(vfile)) {
            if (!processor.processFile(vfile)) return true;
          }
        }
      }
    }
    return false;
  }

  public interface MxmlFilesProcessor {
    void addDependency(PsiDirectory directory);
    boolean processFile(VirtualFile file);
  }
}
