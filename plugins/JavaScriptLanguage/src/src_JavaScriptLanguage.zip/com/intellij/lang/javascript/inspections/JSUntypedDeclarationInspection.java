/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript.inspections;

import com.intellij.codeInsight.CodeInsightUtil;
import com.intellij.codeInsight.template.Template;
import com.intellij.codeInsight.template.TemplateManager;
import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.codeInspection.ProblemHighlightType;
import com.intellij.codeInspection.ProblemsHolder;
import com.intellij.javascript.documentation.JSDocumentationUtils;
import com.intellij.lang.ASTNode;
import com.intellij.lang.LanguageDialect;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.psi.*;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.fileEditor.OpenFileDescriptor;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

/**
 * @author Maxim.Mossienko
 */
public class JSUntypedDeclarationInspection extends JSInspection {
  @NonNls public static final String SHORT_NAME = "JSUntypedDeclaration";

  @NotNull
  public String getGroupDisplayName() {
    return JSBundle.message("js.inspection.group.name");
  }

  @NotNull
  public String getDisplayName() {
    return JSBundle.message("js.untyped.declaration.inspection.name");
  }

  @NotNull
  @NonNls
  public String getShortName() {
    return SHORT_NAME;
  }

  protected BasePsiElementVisitor createVisitor(final ProblemsHolder holder) {
    return new BasePsiElementVisitor() {
      public void visitJSVariable(final JSVariable node) {
        process(node, holder);
      }

      public void visitJSFunctionExpression(final JSFunctionExpression node) {
        process(node.getFunction(), holder);
      }

      public void visitJSFunctionDeclaration(final JSFunction node) {
        if (node.isConstructor()) return;
        process(node, holder);
      }
    };
  }

  private static void process(final JSNamedElement node, final ProblemsHolder holder) {
    LanguageDialect languageDialect = node.getContainingFile().getLanguageDialect();
    if (languageDialect != JavaScriptSupportLoader.ECMA_SCRIPT_L4) return;
    ASTNode nameIdentifier = node.findNameIdentifier();
    
    if (nameIdentifier != null &&
        JSDocumentationUtils.tryGetTypeFromDeclaration(node) == null &&
        (!(node instanceof JSParameter) || !((JSParameter)node).isRest())
      ) {
      holder.registerProblem(
        nameIdentifier.getPsi(),
        JSBundle.message(node instanceof JSFunction ? "js.untyped.function.problem":"js.untyped.variable.problem", nameIdentifier.getText()),
        ProblemHighlightType.GENERIC_ERROR_OR_WARNING,
        new AddTypeToDclFix()
      );
    }
  }

  private static class AddTypeToDclFix implements LocalQuickFix {

    @NotNull
    public String getName() {
      return JSBundle.message("js.untyped.declaration.problem.addtype.fix");
    }

    @NotNull
    public String getFamilyName() {
      return getName();
    }

    public void applyFix(@NotNull final Project project, @NotNull final ProblemDescriptor descriptor) {
      PsiElement anchor = descriptor.getPsiElement();
      PsiFile containingFile = anchor.getContainingFile();
      if (!CodeInsightUtil.prepareFileForWrite(containingFile)) return;

      if (anchor.getParent() instanceof JSFunction) {
        anchor = ((JSFunction)anchor.getParent()).getParameterList();
      }

      OpenFileDescriptor openDescriptor = new OpenFileDescriptor(project, containingFile.getVirtualFile(), anchor.getTextRange().getEndOffset());
      openDescriptor.navigate(true);
      Editor textEditor = FileEditorManager.getInstance(project).getSelectedTextEditor();
      TemplateManager templateManager = TemplateManager.getInstance(project);

      Template t = templateManager.createTemplate("","",":$a$");
      t.addVariable("a","complete()", "uint", true);
      
      templateManager.startTemplate(textEditor, t);
    }
  }
}