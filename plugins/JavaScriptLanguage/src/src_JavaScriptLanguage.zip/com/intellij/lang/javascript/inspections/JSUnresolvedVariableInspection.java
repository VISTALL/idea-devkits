/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript.inspections;

import com.intellij.codeHighlighting.HighlightDisplayLevel;
import com.intellij.codeInsight.CodeInsightUtil;
import com.intellij.codeInsight.template.Expression;
import com.intellij.codeInsight.template.Template;
import com.intellij.codeInsight.template.TemplateManager;
import com.intellij.codeInsight.template.impl.MacroCallNode;
import com.intellij.codeInsight.template.macro.MacroFactory;
import com.intellij.codeInspection.*;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.util.JSUtils;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.fileEditor.OpenFileDescriptor;
import com.intellij.openapi.project.Project;
import com.intellij.psi.*;
import org.jetbrains.annotations.NonNls;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: Maxim.Mossienko
 * Date: Apr 17, 2006
 * Time: 9:53:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class JSUnresolvedVariableInspection extends JSInspection {
  @NonNls public static final String SHORT_NAME = "JSUnresolvedVariable";

  public String getGroupDisplayName() {
    return JSBundle.message("js.inspection.group.name");
  }

  public String getDisplayName() {
    return JSBundle.message("js.unresolved.variable.inspection.name");
  }

  @NonNls
  public String getShortName() {
    return SHORT_NAME;
  }

  protected BasePsiElementVisitor createVisitor(final ProblemsHolder holder) {
    return new BasePsiElementVisitor() {
      public void visitJSReferenceExpression(final JSReferenceExpression node) {
        final PsiElement parentElement = node.getParent();

        if (!(parentElement instanceof JSCallExpression) &&
            !(parentElement instanceof JSDefinitionExpression)
           ) {
          final ResolveResult[] resolveResults = node.multiResolve(false);
          final boolean emptyResolve = resolveResults.length == 0;

          if (emptyResolve) {
            final PsiElement nameIdentifier = node.getReferenceNameElement();

            if (nameIdentifier != null) {
              final List<LocalQuickFix> fixes = new LinkedList<LocalQuickFix>();

              if (myOnTheFly) {
                final JSExpression qualifier = node.getQualifier();

                if (qualifier == null || JSUtils.isLHSExpression(qualifier)) {
                  fixes.add( new CreateJSVariableIntentionAction(node) );
                }
              }

              holder.registerProblem(
                nameIdentifier,
                JSBundle.message("javascript.unresolved.variable.name.message",node.getReferencedName()),
                ProblemHighlightType.GENERIC_ERROR_OR_WARNING,
                fixes.size() > 0 ? fixes.toArray(new LocalQuickFix[fixes.size()]):null
              );
            }
          }
        }
        super.visitJSReferenceExpression(node);
      }
    };
  }

  private static class CreateJSVariableIntentionAction implements LocalQuickFix {
    private final JSReferenceExpression myReferenceExpression;
    @NonNls private static final String VAR_STATEMENT_START = "var ";
    private final PsiFile file;

    CreateJSVariableIntentionAction(JSReferenceExpression expression) {
      myReferenceExpression = expression;
      file = expression.getContainingFile();
    }

    public String getName() {
      return JSBundle.message(
        myReferenceExpression.getQualifier() == null ?
        "javascript.create.variable.intention.name":
        "javascript.create.property.intention.name",
        myReferenceExpression.getReferencedName()
      );
    }

    public String getFamilyName() {
      return JSBundle.message("javascript.create.variable.intention.family");
    }

    public void applyFix(Project project, ProblemDescriptor descriptor) {
      if ( !CodeInsightUtil.prepareFileForWrite(file)) return;

      Editor editor = FileEditorManager.getInstance(project).openTextEditor(
        new OpenFileDescriptor(project, file.getVirtualFile()), false
      );

      PsiElement anchor = JSUtils.findStatementAnchor(myReferenceExpression, file);

      if (anchor != null) {
        final int startOffset = anchor.getTextRange().getStartOffset();

        final TemplateManager templateManager = TemplateManager.getInstance(project);
        Template template = templateManager.createTemplate("","");

        if (myReferenceExpression.getQualifier() == null) template.addTextSegment(VAR_STATEMENT_START);
        template.addTextSegment(myReferenceExpression.getText() + " = ");
        Expression expression = new MacroCallNode(MacroFactory.createMacro("complete"));

        template.addVariable("value",expression,expression,true);
        template.addTextSegment(";");
        template.addEndVariable();
        template.addTextSegment("\n");
        editor.getCaretModel().moveToOffset(startOffset);
        templateManager.startTemplate(editor, template);
      }
    }
  }
}
