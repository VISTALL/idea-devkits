/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript.inspections;

import com.intellij.codeInsight.template.Expression;
import com.intellij.codeInsight.template.Template;
import com.intellij.codeInsight.template.impl.MacroCallNode;
import com.intellij.codeInsight.template.macro.MacroFactory;
import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.codeInspection.ProblemHighlightType;
import com.intellij.codeInspection.ProblemsHolder;
import com.intellij.lang.javascript.JSBundle;
import com.intellij.lang.javascript.JavaScriptSupportLoader;
import com.intellij.lang.javascript.psi.*;
import com.intellij.lang.javascript.psi.impl.JSGwtReferenceExpressionImpl;
import com.intellij.lang.javascript.psi.resolve.JSResolveUtil;
import com.intellij.lang.javascript.psi.util.JSUtils;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.ResolveResult;
import com.intellij.psi.util.PsiTreeUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedList;
import java.util.List;

/**
 * @by Maxim.Mossienko
 */
public class JSUnresolvedVariableInspection extends JSInspection {
  @NonNls private static final String SHORT_NAME = "JSUnresolvedVariable";

  @NotNull
  public String getGroupDisplayName() {
    return JSBundle.message("js.inspection.group.name");
  }

  @NotNull
  public String getDisplayName() {
    return JSBundle.message("js.unresolved.variable.inspection.name");
  }

  @NotNull
  @NonNls
  public String getShortName() {
    return SHORT_NAME;
  }

  protected BasePsiElementVisitor createVisitor(final ProblemsHolder holder) {
    return new BasePsiElementVisitor() {
      public void visitJSReferenceExpression(final JSReferenceExpression node) {
        final PsiElement parentElement = node.getParent();

        if (!(node instanceof JSGwtReferenceExpressionImpl)
            && !(parentElement instanceof JSCallExpression) ) {
          final ResolveResult[] resolveResults = node.multiResolve(false);
          boolean emptyResolve = resolveResults.length == 0;
          boolean noCompleteResolve = true;

          for(ResolveResult r:resolveResults) {
            if (r.isValidResult()) {
              noCompleteResolve = false;
              break;
            }
          }

          if (emptyResolve || noCompleteResolve) {
            final PsiElement nameIdentifier = node.getReferenceNameElement();

            if (nameIdentifier != null) {
              final List<LocalQuickFix> fixes = new LinkedList<LocalQuickFix>();

              if (myOnTheFly) {
                final JSExpression qualifier = node.getQualifier();
                final PsiFile containingFile = node.getContainingFile();
                final boolean ecma = containingFile.getLanguageDialect() == JavaScriptSupportLoader.ECMA_SCRIPT_L4;

                if ((qualifier == null || JSUtils.isLHSExpression(qualifier)) &&
                    (!(parentElement instanceof JSDefinitionExpression) || ecma
                    )) {
                  final String referencedName = node.getReferencedName();
                  boolean isField = qualifier != null;

                  if (!isField && ecma) {
                    if(PsiTreeUtil.getParentOfType(node,  JSClass.class) != null) {
                      isField = true;
                    } else {
                      final PsiElement context = JSResolveUtil.getClassReferenceForXmlFromContext(containingFile);
                      if (context instanceof JSClass) {
                        isField = true;
                      }
                    }
                  }

                  fixes.add(
                    new CreateJSVariableIntentionAction( referencedName, isField )
                  );
                  if (qualifier != null && !ecma) fixes.add(new CreateJSNamespaceIntentionAction(referencedName) );
                }
              }

              final String key = node.getQualifier() == null ?
                                 JSResolveUtil.isExprInTypeContext(node) ?
                                   "javascript.unresolved.type.name.message":
                                   "javascript.unresolved.variable.or.type.name.message":
                                 "javascript.unresolved.variable.name.message";
              
              holder.registerProblem(
                nameIdentifier,
                JSBundle.message(key,node.getReferencedName()),
                ProblemHighlightType.GENERIC_ERROR_OR_WARNING,
                fixes.size() > 0 ? fixes.toArray(new LocalQuickFix[fixes.size()]):null
              );
            }
          }
        }
        super.visitJSReferenceExpression(node);
      }
    };
  }

  private abstract static class BaseCreateJSVariableIntentionAction extends BaseCreateFix {
    protected final String myReferencedName;

    BaseCreateJSVariableIntentionAction(String referencedName) {
      myReferencedName = referencedName;
    }
    @NotNull
    public String getFamilyName() {
      return JSBundle.message("javascript.create.variable.intention.family");
    }
  }
  
  private static class CreateJSNamespaceIntentionAction extends BaseCreateJSVariableIntentionAction {
    CreateJSNamespaceIntentionAction(String referencedName) {
      super(referencedName);
    }

    @NotNull
    public String getName() {
      return JSBundle.message(
        "javascript.create.namespace.intention.name",
        myReferencedName
      );
    }

    protected void buildTemplate(final Template template, final JSReferenceExpression referenceExpression, final boolean ecma, final PsiFile file,
                                 final PsiElement anchorParent) {
      template.addTextSegment("/** @namespace ");
      template.addTextSegment(referenceExpression.getText() + " */");
      template.addEndVariable();
    }
  }

  private static class CreateJSVariableIntentionAction extends BaseCreateJSVariableIntentionAction {
    @NonNls private static final String VAR_STATEMENT_START = "var ";
    private boolean isField;

    CreateJSVariableIntentionAction(String referencedName, boolean isField) {
      super(referencedName);
      this.isField = isField;
    }

    @NotNull
    public String getName() {
      return JSBundle.message(
        isField ?
        "javascript.create.property.intention.name":
        "javascript.create.variable.intention.name",
        myReferencedName
      );
    }

    protected void buildTemplate(final Template template, final JSReferenceExpression referenceExpression, final boolean ecma, final PsiFile file,
                                 final PsiElement anchorParent) {
      if (referenceExpression.getQualifier() == null || ecma) template.addTextSegment(VAR_STATEMENT_START);
      template.addTextSegment(ecma ? referenceExpression.getReferencedName():referenceExpression.getText());
      if (ecma) {
        template.addTextSegment(":");
      } else {
        template.addTextSegment(" = ");
      }
      Expression expression = new MacroCallNode(MacroFactory.createMacro("complete"));

      template.addVariable("value",expression,expression,true);
      template.addTextSegment(";");
      template.addEndVariable();
    }
  }
}
