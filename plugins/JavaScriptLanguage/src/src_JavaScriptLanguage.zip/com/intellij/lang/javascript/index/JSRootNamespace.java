package com.intellij.lang.javascript.index;

import gnu.trove.TIntObjectHashMap;
import org.jetbrains.annotations.NotNull;

/**
 * @by maxim
 */
class JSRootNamespace extends JSNamespace {
  final JSIndexEntry myEntry;
  final TIntObjectHashMap<JSNamespace> importedCache = new TIntObjectHashMap<JSNamespace>();

  public JSRootNamespace(JSPackage _package, @NotNull JSIndexEntry entry) {
    super(_package);
    myEntry = entry;
  }

  public int getQualifiedNameId(final JavaScriptIndex index) {
    return -1;
  }

  void validate() {
    getPackage().addInstance(this);
  }

  public void invalidate(final JSTypeEvaluateManager typeEvaluateManager) {
    importedCache.clear();
    super.invalidate(typeEvaluateManager);
  }
}