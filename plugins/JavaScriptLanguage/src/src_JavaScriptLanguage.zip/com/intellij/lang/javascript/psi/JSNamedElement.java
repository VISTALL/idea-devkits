package com.intellij.lang.javascript.psi;

import com.intellij.psi.PsiNamedElement;
import com.intellij.lang.ASTNode;
import org.jetbrains.annotations.Nullable;

/**
 * @author ven
 */
public interface JSNamedElement extends PsiNamedElement, JSElement {
  @Nullable
  ASTNode findNameIdentifier();
}
