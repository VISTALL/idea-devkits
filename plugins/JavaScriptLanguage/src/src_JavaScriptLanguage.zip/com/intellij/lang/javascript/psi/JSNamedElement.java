package com.intellij.lang.javascript.psi;

import com.intellij.psi.PsiNamedElement;

/**
 * @author ven
 */
public interface JSNamedElement extends PsiNamedElement, JSElement {
}
