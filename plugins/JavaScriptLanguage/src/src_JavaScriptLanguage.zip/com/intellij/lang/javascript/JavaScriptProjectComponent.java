/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.lang.javascript;

import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiManager;
import com.intellij.psi.AbstractElementManipulator;
import com.intellij.lang.javascript.psi.impl.JSGwtReferenceExpressionImpl;
import com.intellij.lang.javascript.psi.impl.JSChangeUtil;
import com.intellij.lang.ASTNode;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.NonNls;

/**
 * @author nik
 */
public class JavaScriptProjectComponent implements ProjectComponent {
  private PsiManager myPsiManager;

  public JavaScriptProjectComponent(final PsiManager psiManager) {
    myPsiManager = psiManager;
  }

  public void projectOpened() {
  }

  public void projectClosed() {
  }

  @NotNull
  @NonNls
  public String getComponentName() {
    return "JavaScriptProjectComponent";
  }

  public void initComponent() {
    myPsiManager.getElementManipulatorsRegistry().registerManipulator(JSGwtReferenceExpressionImpl.class, new AbstractElementManipulator<JSGwtReferenceExpressionImpl>() {
      public JSGwtReferenceExpressionImpl handleContentChange(final JSGwtReferenceExpressionImpl element,
                                                              final TextRange range, final String newContent)
        throws IncorrectOperationException {
        String newText = range.replace(element.getText(), newContent);
        ASTNode newExpression = JSChangeUtil.createExpressionFromText(element.getProject(), newText, JavaScriptSupportLoader.GWT_DIALECT);
        return (JSGwtReferenceExpressionImpl)element.replace(newExpression.getPsi());
      }

      public TextRange getRangeInElement(final JSGwtReferenceExpressionImpl element) {
        String text = element.getText();
        int start = text.indexOf('@');
        if (start == -1) start = 0;
        int end = text.indexOf("::");
        if (end == -1) end = text.length();
        return new TextRange(start, end);
      }
    });
  }

  public void disposeComponent() {
  }
}
