/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.webSphere.client;

/**
 * @author nik
 */
public interface ServerNotificationListener {

  void handleNotification(String message);

}
