/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.webSphere.client;

import java.util.Properties;

/**
 * @author nik
 */
public interface AppManagementNotificationListener {
  void handleNotification(String taskName, String taskStatus, String message, Properties properties);
}
