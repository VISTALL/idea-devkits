/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.applicationServer;

import com.intellij.j2ee.webSphere.WebSphereBundle;
import com.intellij.j2ee.webSphere.configuration.WebSphereVersionUtil;
import com.intellij.javaee.appServerIntegrations.ApplicationServerPersistentDataEditor;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.ui.TextFieldWithBrowseButton;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.util.IconLoader;
import com.intellij.ui.DocumentAdapter;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import java.io.File;

/**
 * @author nik
 */
public class WebSpherePersistentDataEditor extends ApplicationServerPersistentDataEditor<WebSpherePersistentData> {
  private JPanel myMainPanel;
  private TextFieldWithBrowseButton myWebSphereHomeField;
  private JLabel myInfoLabel;

  public WebSpherePersistentDataEditor() {
    updateInfo(true);
    myWebSphereHomeField.addBrowseFolderListener(WebSphereBundle.message("chooser.title.websphere.home.directory"),
                                                 WebSphereBundle.message("chooser.description.websphere.home.directory"),
                                                 null, new FileChooserDescriptor(false, true, false, false, false, false));
    myWebSphereHomeField.getTextField().getDocument().addDocumentListener(new DocumentAdapter() {
      @Override
      protected void textChanged(final DocumentEvent e) {
        check();
      }
    });
  }

  private void updateInfo(final boolean valid) {
    myInfoLabel.setIcon(valid ? null : IconLoader.getIcon("/runConfigurations/configurationWarning.png"));
  }

  private void check() {
    final File webSphereHome = getHome();
    boolean valid = true;
    if (!webSphereHome.isDirectory()) {
      valid = false;
      myInfoLabel.setText(WebSphereBundle.message("message.text.cant.find.directory", webSphereHome.getAbsolutePath()));
    }
    else {
      WebSphereVersionUtil.Version version = WebSphereVersionUtil.getVersion(webSphereHome);
      if (version == null) {
        valid = false;
        myInfoLabel.setText(WebSphereBundle.message("message.text.0.is.not.valid.websphere.home", webSphereHome.getAbsolutePath()));
      }
      else {
        myInfoLabel.setText(WebSphereBundle.message("message.text.websphere.version.0", version.getPresentableName()));
      }
    }
    updateInfo(valid);
  }

  private File getHome() {
    return new File(myWebSphereHomeField.getText());
  }

  protected void resetEditorFrom(final WebSpherePersistentData data) {
    myWebSphereHomeField.setText(FileUtil.toSystemDependentName(data.WEBSPHERE_APPSERVER_HOME));
    check();
  }

  protected void applyEditorTo(final WebSpherePersistentData data) throws ConfigurationException {
    data.WEBSPHERE_APPSERVER_HOME = FileUtil.toSystemIndependentName(getHome().getAbsolutePath());
  }

  @NotNull
  protected JComponent createEditor() {
    return myMainPanel;
  }

  protected void disposeEditor() {
  }
}
