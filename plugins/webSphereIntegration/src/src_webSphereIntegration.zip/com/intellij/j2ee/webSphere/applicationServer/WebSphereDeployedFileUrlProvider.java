/*
 * Copyright (c) 2000-2006 JetBrains s.r.o. All Rights Reserved.
 */

package com.intellij.j2ee.webSphere.applicationServer;

import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.appServerIntegrations.AppServerDeployedFileUrlProvider;
import com.intellij.javaee.deployment.DeploymentManager;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.make.MakeUtil;
import com.intellij.javaee.model.JavaeeApplicationModel;
import com.intellij.javaee.model.xml.application.JavaeeApplication;
import com.intellij.javaee.model.xml.application.JavaeeModule;
import com.intellij.javaee.module.ModuleLink;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.openapi.module.Module;
import org.jetbrains.annotations.Nullable;

/**
 * @author nik
 */
public class WebSphereDeployedFileUrlProvider implements AppServerDeployedFileUrlProvider {
  public static final WebSphereDeployedFileUrlProvider INSTANCE = new WebSphereDeployedFileUrlProvider();

  private WebSphereDeployedFileUrlProvider() {
  }

  @Nullable
  public String getUrlForDeployedFile(J2EEServerInstance serverInstance, DeploymentModel deploymentModel, String relativePath) {
    final CommonModel commonModel = serverInstance.getCommonModel();
    final DeploymentManager deploymentManager = DeploymentManager.getInstance(commonModel.getProject());
    final DeploymentModel deployed = deploymentManager.getModelForDeployedModuleContainingModule(deploymentModel);
    if (deployed == null) return null;

    final JavaeeModuleProperties properties = deployed.getModuleProperties();
    if (!(properties instanceof JavaeeApplicationModel)) return null;

    final JavaeeApplication application = ((JavaeeApplicationModel)properties).getRoot();
    if (application == null) return null;

    final JavaeeModule moduleLink = findModuleLink(application, deploymentModel);
    if (moduleLink == null) return null;

    final String contextRoot = moduleLink.getWeb().getContextRoot().getValue();
    if (contextRoot == null) return null;

    return MakeUtil.concatPaths(commonModel.getServerModel().getDefaultUrlForBrowser(), contextRoot, relativePath);
  }

  private @Nullable static JavaeeModule findModuleLink(final JavaeeApplication application, final DeploymentModel deploymentModel) {
    final Module module = deploymentModel.getModuleProperties().getModule();
    for (JavaeeModule moduleLink : application.getModules()) {
      if (ModuleLink.hasId(module, moduleLink.getId().getValue())) {
        return moduleLink;
      }
    }
    return null;
  }
}
