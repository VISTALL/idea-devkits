/*
 * Copyright (c) 2000-2006 JetBrains s.r.o. All Rights Reserved.
 */

package com.intellij.j2ee.webSphere.applicationServer;

import com.intellij.javaee.appServerIntegrations.AppServerDeployedFileUrlProvider;
import com.intellij.javaee.application.facet.JavaeeApplicationFacet;
import com.intellij.javaee.deployment.DeploymentManager;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.model.xml.application.JavaeeApplication;
import com.intellij.javaee.model.xml.application.JavaeeModule;
import com.intellij.javaee.module.JavaeeFacetLink;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.openapi.deployment.DeploymentUtil;
import org.jetbrains.annotations.Nullable;

/**
 * @author nik
 */
public class WebSphereDeployedFileUrlProvider implements AppServerDeployedFileUrlProvider {
  public static final WebSphereDeployedFileUrlProvider INSTANCE = new WebSphereDeployedFileUrlProvider();

  private WebSphereDeployedFileUrlProvider() {
  }

  @Nullable
  public String getUrlForDeployedFile(J2EEServerInstance serverInstance, DeploymentModel deploymentModel, String relativePath) {
    final CommonModel commonModel = serverInstance.getCommonModel();
    final DeploymentManager deploymentManager = DeploymentManager.getInstance(commonModel.getProject());
    final DeploymentModel deployed = deploymentManager.getModelForDeployedModuleContainingModule(deploymentModel);
    if (deployed == null) return null;

    final JavaeeFacet facet = deployed.getFacet();
    if (!(facet instanceof JavaeeApplicationFacet)) return null;

    final JavaeeApplication application = ((JavaeeApplicationFacet)facet).getRoot();
    if (application == null) return null;

    final JavaeeModule moduleLink = findModuleLink(application, deploymentModel);
    if (moduleLink == null) return null;

    final String contextRoot = moduleLink.getWeb().getContextRoot().getValue();
    if (contextRoot == null) return null;

    return DeploymentUtil.concatPaths(commonModel.getServerModel().getDefaultUrlForBrowser(), contextRoot, relativePath);
  }

  private @Nullable static JavaeeModule findModuleLink(final JavaeeApplication application, final DeploymentModel deploymentModel) {
    final JavaeeFacet facet = deploymentModel.getFacet();
    for (JavaeeModule moduleLink : application.getModules()) {
      if (JavaeeFacetLink.hasId(facet, moduleLink.getId().getValue())) {
        return moduleLink;
      }
    }
    return null;
  }
}
