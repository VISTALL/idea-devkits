/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.webSphere.configuration;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.util.JDOMUtil;
import org.jdom.Document;
import org.jdom.JDOMException;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;

/**
 * @author nik
 */
public class WebSphereCell {
  private static final Logger LOG = Logger.getInstance("#com.intellij.j2ee.webSphere.configuration.WebSphereCell");
  public static final WebSphereCell[] EMPTY_ARRAY = new WebSphereCell[0];
  @NonNls private static final String ENABLED_SECURITY_ATTRIBUTE = "enabled";
  private final WebSphereProfile myProfile;
  private final File myCellDirectory;
  private final String myCellName;
  private boolean mySecurityEnabled;

  public WebSphereCell(final @NotNull WebSphereProfile profile, final @NotNull File cellDir, final @NotNull String cellName) {
    myProfile = profile;
    myCellDirectory = cellDir;
    myCellName = cellName;
    try {
      Document document = JDOMUtil.loadDocument(new File(cellDir, "security.xml"));
      String enabled = document.getRootElement().getAttributeValue(ENABLED_SECURITY_ATTRIBUTE);
      mySecurityEnabled = Boolean.parseBoolean(enabled);
    }
    catch (JDOMException e) {
      LOG.info(e);
    }
    catch (IOException e) {
      LOG.info(e);
    }
  }


  public File getCellDirectory() {
    return myCellDirectory;
  }

  public WebSphereProfile getProfile() {
    return myProfile;
  }

  public String getCellName() {
    return myCellName;
  }

  public WebSphereNode[] getNodes() {
    return WebSphereProfileUtil.getNodes(this);
  }


  public boolean equals(final Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    final WebSphereCell that = (WebSphereCell)o;
    return myCellDirectory.equals(that.myCellDirectory) && myProfile.equals(that.myProfile);
  }

  public int hashCode() {
    int result;
    result = myProfile.hashCode();
    result = 29 * result + myCellDirectory.hashCode();
    return result;
  }

  public String toString() {
    return myCellName;
  }

  public boolean isSecurityEnabled() {
    return mySecurityEnabled;
  }
}
