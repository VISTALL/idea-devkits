/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.configuration;

import java.io.File;
import java.util.Map;

/**
 * @author nik
 */
public class WebSphereProfile {
  public static final WebSphereProfile[] EMPTY_ARRAY = new WebSphereProfile[0];
  private final WebSphereVersion myVersion;
  private final File myLocation;
  private final String myName;
  private final File myStartupScriptFile;
  private final File myShutdownScriptFile;
  private Map<String, String> myProperties;

  public WebSphereProfile(final WebSphereVersion version,
                          final File location,
                          final String name,
                          final File startupScriptFile,
                          final File shutdownScriptFile, final Map<String, String> properties) {
    myVersion = version;
    myLocation = location;
    myName = name;
    myStartupScriptFile = startupScriptFile;
    myShutdownScriptFile = shutdownScriptFile;
    myProperties = properties;
  }

  public Map<String, String> getProperties() {
    return myProperties;
  }

  public File getLocation() {
    return myLocation;
  }

  public String getName() {
    return myName;
  }

  public File getStartupScriptFile() {
    return myStartupScriptFile;
  }

  public File getShutdownScriptFile() {
    return myShutdownScriptFile;
  }

  public WebSphereVersion getVersion() {
    return myVersion;
  }

  public String toString() {
    return getName();
  }

  public WebSphereCell[] getCells() {
    return WebSphereProfileUtil.getCells(this);
  }


  public boolean equals(final Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    final WebSphereProfile that = (WebSphereProfile)o;

    return myLocation.equals(that.myLocation) && myVersion.equals(that.myVersion);

  }

  public int hashCode() {
    int result;
    result = myVersion.hashCode();
    result = 29 * result + myLocation.hashCode();
    return result;
  }
}
