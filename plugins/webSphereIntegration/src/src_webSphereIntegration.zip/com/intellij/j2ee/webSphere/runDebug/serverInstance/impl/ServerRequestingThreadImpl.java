/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.runDebug.serverInstance.impl;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.j2ee.webSphere.runDebug.serverInstance.WebSphereServerRequest;
import com.intellij.j2ee.webSphere.runDebug.serverInstance.ServerRequestingThread;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedList;

/**
 * @author nik
 */
public class ServerRequestingThreadImpl extends Thread implements ServerRequestingThread {
  private static final Logger LOG = Logger.getInstance("#com.intellij.j2ee.webSphere.runDebug.serverInstance.impl.ServerRequestingThreadImpl");
  @NonNls private static final String THREAD_NAME = "WebSphere Thread";
  private final LinkedList<WebSphereServerRequest> myRequests = new LinkedList<WebSphereServerRequest>();
  private final ServerExceptionHandler myExceptionHandler;
  private final WebSphereServerRequest myRefreshAction;
  private boolean myStopRequested = false;
  private @Nullable Runnable myActionAfterStop;

  public ServerRequestingThreadImpl(final ServerExceptionHandler exceptionHandler, final WebSphereServerRequest refreshAction) {
    super(THREAD_NAME);
    myExceptionHandler = exceptionHandler;
    myRefreshAction = refreshAction;
  }

  private @Nullable WebSphereServerRequest getNextRequest() {
    synchronized(myRequests) {
      if (myRequests.isEmpty()) return null;
      return myRequests.getFirst();
    }
  }

  public void stopThread(final @Nullable Runnable actionAfterStop) {
    LOG.debug("stop requested");
    myStopRequested = true;
    myActionAfterStop = actionAfterStop;
  }

  public void queueRequest(@NotNull WebSphereServerRequest request) {
    if (myStopRequested) return;
    LOG.debug("queue <== " + request.getDebugDescription());
    synchronized(myRequests) {
      myRequests.addLast(request);
      myRequests.notifyAll();
    }
  }

  public void queueRequestAndWait(@NotNull WebSphereServerRequest request) {
    if (Thread.currentThread() == this) {
      runRequest(request);
      return;
    }
    if (myStopRequested) return;

    queueRequest(request);
    while (true) {
      synchronized (myRequests) {
        if (myRequests.indexOf(request) == -1) break;
      }
      synchronized (request) {
        try {
          request.wait(1000);
        }
        catch (InterruptedException e) {
        }
      }
    }
  }

  public void run() {
    while (true) {
      WebSphereServerRequest request = getNextRequest();
      if (request == null) {
        if (myStopRequested) {
          break;
        }
        request = myRefreshAction;
      }

      if (request != null) {
        runRequest(request);
      }

      synchronized(myRequests) {
        myRequests.remove(request);
      }
      synchronized(myRequests) {
        try {
          myRequests.wait(1000);
        }
        catch (InterruptedException e) {
        }
      }
    }
    if (myActionAfterStop != null) {
      myActionAfterStop.run();
    }
    LOG.debug("thread stopped");
  }

  private void runRequest(@NotNull final WebSphereServerRequest request) {
    if (myStopRequested) return;

    LOG.debug("queue ==> " + request.getDebugDescription());
    try {
      request.run();
    }
    catch (Throwable t) {
      if (myStopRequested) return;

      try {
        myExceptionHandler.process(t);
      }
      catch (Exception e) {
        LOG.error(e);
      }
    }
  }

  public abstract class WaitingOnConditionRequest extends WebSphereServerRequest {
    private int myInterval;

    protected WaitingOnConditionRequest(@NonNls String conditionDebugDescription, final int interval) {
      super("waiting for " + conditionDebugDescription);
      myInterval = interval;
    }

    public final void run() throws Throwable {
      while (!myStopRequested && !isReady()) {
        Thread.sleep(myInterval);
      }
    }

    public abstract boolean isReady();
  }
}
