/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.applicationServer;

import com.intellij.facet.FacetTypeId;
import com.intellij.j2ee.webSphere.WebSphereBundle;
import com.intellij.j2ee.webSphere.deployment.WebSphereDeploymentProvider;
import com.intellij.javaee.appServerIntegrations.AppServerDeployedFileUrlProvider;
import com.intellij.javaee.appServerIntegrations.ApplicationServerHelper;
import com.intellij.javaee.application.facet.JavaeeApplicationFacet;
import com.intellij.javaee.deployment.DeploymentProvider;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.facet.JavaeeFacetUtil;
import com.intellij.openapi.util.IconLoader;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.util.Collection;

/**
 * @author nik
 */
public class WebSphereIntegrationImpl extends WebSphereIntegration {
  public static final Icon ICON_WEBSPHERE = IconLoader.getIcon("/runConfigurations/web_app.png");
  private final WebSphereApplicationServerHelper myApplicationServerHelper = new WebSphereApplicationServerHelper();
  private final WebSphereDeploymentProvider myDeploymentProvider = new WebSphereDeploymentProvider();

  public String getPresentableName() {
    return WebSphereBundle.message("websphere.integration.presentable.name");
  }

  @NotNull @NonNls
  public String getComponentName() {
    return "WebSphereIntegration";
  }

  public ApplicationServerHelper getApplicationServerHelper() {
    return myApplicationServerHelper;
  }

  @NotNull
  public Collection<FacetTypeId<? extends JavaeeFacet>> getSupportedFacetTypes() {
    return JavaeeFacetUtil.getInstance().getSingletonCollection(JavaeeApplicationFacet.ID);
  }

  @NotNull
  public AppServerDeployedFileUrlProvider getDeployedFileUrlProvider() {
    return WebSphereDeployedFileUrlProvider.INSTANCE;
  }

  public DeploymentProvider getDeploymentProvider() {
    return myDeploymentProvider;
  }

  public Icon getIcon() {
    return ICON_WEBSPHERE;
  }
}
