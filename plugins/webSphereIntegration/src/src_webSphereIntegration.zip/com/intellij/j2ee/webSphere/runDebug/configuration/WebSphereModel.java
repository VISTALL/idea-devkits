/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.runDebug.configuration;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.configurations.LogFileOptions;
import com.intellij.execution.configurations.PredefinedLogFile;
import com.intellij.execution.configurations.RuntimeConfigurationError;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.j2ee.webSphere.WebSphereBundle;
import com.intellij.j2ee.webSphere.applicationServer.WebSphereIntegration;
import com.intellij.j2ee.webSphere.applicationServer.WebSpherePersistentData;
import com.intellij.j2ee.webSphere.configuration.WebSphereProfileUtil;
import com.intellij.j2ee.webSphere.configuration.WebSphereServerConfiguration;
import com.intellij.j2ee.webSphere.configuration.WebSphereVersion;
import com.intellij.j2ee.webSphere.configuration.WebSphereVersionUtil;
import com.intellij.j2ee.webSphere.runDebug.serverInstance.WebSphereInstance;
import com.intellij.j2ee.webSphere.runDebug.serverInstance.impl.WebSphereLocalInstance;
import com.intellij.j2ee.webSphere.runDebug.serverInstance.impl.WebSphereRemoteInstance;
import com.intellij.javaee.appServerIntegrations.ApplicationServer;
import com.intellij.javaee.deployment.DeploymentProvider;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.run.configuration.PredefinedLogFilesProvider;
import com.intellij.javaee.run.configuration.ServerModel;
import com.intellij.javaee.run.execution.OutputProcessor;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.util.DefaultJDOMExternalizer;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.WriteExternalException;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author nik
 */
public class WebSphereModel implements ServerModel, PredefinedLogFilesProvider {
  private CommonModel myCommonModel;
  public String PROFILE_PATH = "";
  public int SOAP_PORT = WebSphereVersionUtil.V6_DEFAULT_SOAP_PORT;
  @NonNls public String USERNAME = "";
  @NonNls public String PASSWORD = "";
  @NonNls public String CELL_NAME = "DefaultNode";
  @NonNls public String NODE_NAME = "DefaultNode";
  @NonNls public String SERVER_NAME = "server1";
  @NonNls public String CLIENT_TRUST_FILE_PATH;
  @NonNls private static final String WEB_SPHERE_OUTPUT_FILE_ID = "WEB_SPHERE_OUTPUT_FILE";

  public J2EEServerInstance createServerInstance() throws ExecutionException {
    if (myCommonModel.isLocal()) {
      return new WebSphereLocalInstance(myCommonModel);
    }
    else {
      return new WebSphereRemoteInstance(myCommonModel);
    }
  }

  public DeploymentProvider getDeploymentProvider() {
    return WebSphereIntegration.getInstance().getDeploymentProvider();
  }

  @NonNls
  public String getDefaultUrlForBrowser() {
    return "http://" + myCommonModel.getHost() + ":" + myCommonModel.getPort();
  }

  public SettingsEditor<CommonModel> getEditor() {
    if (myCommonModel.isLocal()) {
      return new WebSphereLocalRunConfigurationEditor();
    }
    else {
      return new WebSphereRemoteRunConfigurationEditor(myCommonModel.getProject());
    }
  }

  public OutputProcessor createOutputProcessor(ProcessHandler j2EEOSProcessHandlerWrapper, J2EEServerInstance serverInstance) {
    return new WebSphereOutputProcessor(j2EEOSProcessHandlerWrapper, (WebSphereInstance) serverInstance);
  }

  public List<Pair<String, Integer>> getAddressesToCheck() {
    List<Pair<String, Integer>> result = new ArrayList<Pair<String, Integer>>();
    result.add(new Pair<String, Integer>(myCommonModel.getHost(), myCommonModel.getPort()));
    return result;
  }

  public @Nullable WebSphereServerConfiguration getServerConfiguration() {
    try {
      return checkAndCreateValidConfiguration();
    }
    catch (RuntimeConfigurationException e) {
      return null;
    }
  }

  private @NotNull WebSphereServerConfiguration checkAndCreateValidConfiguration() throws RuntimeConfigurationException {
    final WebSphereVersion version = getWebSphereVersion();
    if (version == null) {
      throw new RuntimeConfigurationError(WebSphereBundle.message("error.websphere.server.is.not.specified")) ;
    }
    return WebSphereProfileUtil.createValidServerConfiguration(version, new File(PROFILE_PATH), CELL_NAME, NODE_NAME, SERVER_NAME);
  }

  private @Nullable WebSphereVersion getWebSphereVersion() {
    final ApplicationServer applicationServer = myCommonModel.getApplicationServer();
    if (applicationServer == null) return null;

    return ((WebSpherePersistentData)applicationServer.getPersistentData()).getVersion();
  }

  public void checkConfiguration() throws RuntimeConfigurationException {
    if (myCommonModel.isLocal()) {
      checkAndCreateValidConfiguration();
    }
  }

  public int getDefaultPort() {
    final WebSphereVersion version = getWebSphereVersion();
    if (version != null) {
      return version.getDefaultSOAPPort();
    }
    return WebSphereVersionUtil.V6_DEFAULT_HTTP_PORT;
  }

  public void setCommonModel(CommonModel comminModel) {
    myCommonModel = comminModel;
  }

  public Object clone() throws CloneNotSupportedException {
    return super.clone();
  }

  public int getLocalPort() {
    final WebSphereServerConfiguration configuration = getServerConfiguration();
    return configuration != null ? configuration.getHttpPort() : getDefaultPort();
  }

  @NotNull
  public PredefinedLogFile[] getPredefinedLogFiles() {
    return new PredefinedLogFile[] {
      new PredefinedLogFile(WEB_SPHERE_OUTPUT_FILE_ID, true)
    };
  }

  @Nullable
  public LogFileOptions getOptionsForPredefinedLogFile(PredefinedLogFile predefinedLogFile) {
    if (WEB_SPHERE_OUTPUT_FILE_ID.equals(predefinedLogFile.getId())) {
      final WebSphereServerConfiguration serverConfiguration = getServerConfiguration();
      if (serverConfiguration != null) {
        final File systemOutLogFile = serverConfiguration.getSystemOutLogFile();
        if (systemOutLogFile.exists()) {
          final String alias = WebSphereBundle.message("websphere.output.log.file.alias");
          return new LogFileOptions(alias, systemOutLogFile.getAbsolutePath(), predefinedLogFile.isEnabled(), true, false);
        }
      }
    }
    return null;
  }

  public void readExternal(Element element) throws InvalidDataException {
    DefaultJDOMExternalizer.readExternal(this, element);
  }

  public void writeExternal(Element element) throws WriteExternalException {
    DefaultJDOMExternalizer.writeExternal(this, element);
  }
}
