/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.webSphere.runDebug.serverInstance.impl;

import com.intellij.execution.ExecutionException;
import com.intellij.j2ee.webSphere.WebSphereBundle;
import com.intellij.j2ee.webSphere.applicationServer.WebSpherePersistentData;
import com.intellij.j2ee.webSphere.client.ServerWrapper;
import com.intellij.j2ee.webSphere.configuration.WebSphereVersion;
import com.intellij.j2ee.webSphere.runDebug.configuration.WebSphereModel;
import com.intellij.j2ee.webSphere.runDebug.serverInstance.WebSphereServerRequest;
import com.intellij.javaee.appServerIntegrations.ApplicationServer;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.openapi.util.io.FileUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @author nik
 */
public class WebSphereRemoteInstance extends WebSphereInstanceImpl {
  private static final int MAX_CONNECTION_ATTEMPTS = 10;
  private static final int CONNECTION_ATTEMPTS_INVERVAL = 300;
  private List<Throwable> myConnectionErrors;

  public WebSphereRemoteInstance(final CommonModel commonModel) throws ExecutionException {
    super(commonModel, true);
  }

  protected String getNodeName() {
    return getServerModel().NODE_NAME;
  }

  protected String getCellName() {
    return getServerModel().CELL_NAME;
  }

  protected String getServerName() {
    return getServerModel().SERVER_NAME;
  }

  protected String getClientTrustFilePath() {
    String path = getServerModel().CLIENT_TRUST_FILE_PATH;
    return path != null ? FileUtil.toSystemDependentName(path) : null;
  }

  public WebSphereModel getServerModel() {
    return (WebSphereModel)getCommonModel().getServerModel();
  }

  protected int getSOAPPort() {
    return getServerModel().SOAP_PORT;
  }

  protected boolean isDeploymentSupported() {
    final ApplicationServer server = getCommonModel().getApplicationServer();
    if (server != null) {
      final WebSphereVersion version = ((WebSpherePersistentData)server.getPersistentData()).getVersion();
      return version == null || version.hasAutoUpload();
    }
    return true;
  }

  public boolean connect() throws Exception {
    myServerRequestingThread.queueRequestAndWait(new WebSphereServerRequest("connect to remote instance") {
      public void run() throws Throwable {
        refresh();
      }
    });
    return isConnected();
  }

  public void testConnectionAndDispose() throws Exception {
    myConnectionErrors = new ArrayList<Throwable>();
    waitForConnection();
    if (!myConnectionErrors.isEmpty()) {
      final Throwable cause = myConnectionErrors.get(0);
      throw new Exception(WebSphereBundle.message("error.cannot.connect.with.reason.text", cause.getLocalizedMessage()));
    }
    if (!isConnected()) {
      throw new Exception(WebSphereBundle.message("error.cannot.connect.text"));
    }
    final String[] errorMessage = new String[]{null};
    myServerRequestingThread.queueRequestAndWait(new WebSphereServerRequest("retrieve server info") {
      public void run() throws Throwable {
        final ServerWrapper server = getServer();
        if (server == null) {
          errorMessage[0] = WebSphereBundle.message("error.cannot.find.remote.server.text", getServerName());
        }
      }
    });

    shutdown();
    if (errorMessage[0] != null) {
      throw new Exception(errorMessage[0]);
    }
  }

  private void waitForConnection() {
    myServerRequestingThread.queueRequestAndWait(myServerRequestingThread.new WaitingOnConditionRequest("test connection", CONNECTION_ATTEMPTS_INVERVAL) {
      private int myAttempt = 0;

      public boolean isReady() {
        refresh();
        ++myAttempt;
        return myAttempt > MAX_CONNECTION_ATTEMPTS || isConnected();
      }
    });
  }

  public void registerServerError(Throwable t) {
    if (myConnectionErrors != null) {
      myConnectionErrors.add(t);
    }
    super.registerServerError(t);
  }
}
