/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.webSphere.runDebug.serverInstance.impl;

import com.intellij.debugger.DebuggerManager;
import com.intellij.debugger.PositionManager;
import com.intellij.debugger.engine.DebugProcess;
import com.intellij.debugger.engine.DebugProcessAdapter;
import com.intellij.debugger.engine.PositionManagersFactory;
import com.intellij.execution.ExecutionException;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.j2ee.webSphere.applicationServer.WebSpherePersistentData;
import com.intellij.j2ee.webSphere.client.*;
import com.intellij.j2ee.webSphere.configuration.WebSphereVersion;
import com.intellij.j2ee.webSphere.runDebug.WebSphereServerOutputListener;
import com.intellij.j2ee.webSphere.runDebug.configuration.WebSphereModel;
import com.intellij.j2ee.webSphere.runDebug.serverInstance.WebSphereInstance;
import com.intellij.j2ee.webSphere.runDebug.serverInstance.WebSphereServerRequest;
import com.intellij.javaee.deployment.DeploymentManager;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentStatus;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.serverInstances.DefaultJ2EEServerEvent;
import com.intellij.javaee.serverInstances.DefaultServerInstance;
import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.facet.pointers.FacetPointer;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.Socket;
import java.security.Provider;
import java.security.Security;
import java.util.*;

/**
 * @author nik
 */
public abstract class WebSphereInstanceImpl extends DefaultServerInstance implements WebSphereInstance {
  protected static final Logger LOG = Logger.getInstance("#com.intellij.j2ee.webSphere.runDebug.serverInstance.impl.WebSphereInstanceImpl");
  private final List<WebSphereServerOutputListener> myServerOutputListeners = new LinkedList<WebSphereServerOutputListener>();
  private boolean myIsStarting = true;
  private static final String CLIENT_IMPL_CLASS_NAME = "com.intellij.j2ee.webSphere.client.WebSphereClientFactoryImpl";
  private final WebSphereClientFactory myClientFactory;
  protected final ServerRequestingThreadImpl myServerRequestingThread;
  private AdminClientWrapper myAdminClient;
  private final Project myProject;
  private boolean myConnectionInitialized = false;
  private final boolean myUploadEARBeforeDeploy;
  private ServerWrapper myServer;
  private final WebSphereVersion myVersion;
  private List<String> myAddedSecurityProviders = new ArrayList<String>();

  protected WebSphereInstanceImpl(final CommonModel commonModel, final boolean uploadEARBeforeDeploy) throws ExecutionException {
    super(commonModel);
    myUploadEARBeforeDeploy = uploadEARBeforeDeploy;
    myProject = getCommonModel().getProject();
    final ClassLoader clientClassLoader;
    try {
      final WebSpherePersistentData persistentData = (WebSpherePersistentData)getCommonModel().getApplicationServer().getPersistentData();
      myVersion = persistentData.getVersion();
      LOG.assertTrue(myVersion != null);
      clientClassLoader = persistentData.getClientClassLoader(getClass().getClassLoader());
      LOG.assertTrue(clientClassLoader != null);
      final Class<?> clientImplClass = Class.forName(CLIENT_IMPL_CLASS_NAME, true, clientClassLoader);
      myClientFactory = (WebSphereClientFactory)clientImplClass.newInstance();
    }
    catch (MalformedURLException e) {
      throw new ExecutionException(e.getLocalizedMessage(), e);
    }
    catch (IllegalAccessException e) {
      throw new ExecutionException(e.getLocalizedMessage(), e);
    }
    catch (InstantiationException e) {
      throw new ExecutionException(e.getLocalizedMessage(), e);
    }
    catch (ClassNotFoundException e) {
      throw new ExecutionException(e.getLocalizedMessage(), e);
    }
    myServerRequestingThread = new ServerRequestingThreadImpl(new MyServerExceptionHandler(), null);
    myServerRequestingThread.setContextClassLoader(clientClassLoader);
    myServerRequestingThread.queueRequest(new WebSphereServerRequest("register security providers") {
      public void run() throws Throwable {
        for (String className : myVersion.getSecurityProviders()) {
          final Class<?> aClass = Class.forName(className, true, clientClassLoader);
          final Provider provider = (Provider)aClass.newInstance();
          Security.addProvider(provider);
          myAddedSecurityProviders.add(provider.getName());
        }
      }
    });
    ApplicationManager.getApplication().executeOnPooledThread(myServerRequestingThread);
  }

  public void start(ProcessHandler processHandler) {
    DebuggerManager.getInstance(myProject).addDebugProcessListener(processHandler, new DebugProcessAdapter() {
      public void processAttached(DebugProcess process) {
        process.appendPositionManager(createPositionManager(process));
      }
    });
  }

  private PositionManager createPositionManager(final DebugProcess process) {
    JavaeeFacet[] facets = DefaultServerInstance.getScopeFacetsWithIncluded(getCommonModel());
    if (myVersion.isJspLineMappingCorrectionNeeded()) {
      return PositionManagersFactory.getInstance().createWebSphereSpecificPositionManager(process, facets, myVersion.getJspPackage());
    }
    else {
      return PositionManagersFactory.getInstance().createJSR45PositionManager(process, facets, myVersion.getJspPackage());
    }
  }

  public boolean isStopped() {
    return !myIsStarting && !isConnected();
  }

  public boolean isStarting() {
    return myIsStarting;
  }

  public boolean isConnected() {
    return myAdminClient != null;
  }

  public void shutdown() {
    myServerRequestingThread.stopThread(new Runnable() {
      public void run() {
        myAdminClient = null;
        for (String provider : myAddedSecurityProviders) {
          Security.removeProvider(provider);
        }
        fireServerListeners(new DefaultJ2EEServerEvent(false, true));
      }
    });
  }

  public boolean connect() throws Exception {
    myServerRequestingThread.queueRequest(createWaitingForConnectionRequest());
    return isConnected();
  }

  private WebSphereServerRequest createWaitingForConnectionRequest() {
    return myServerRequestingThread.new WaitingOnConditionRequest("connection", 500) {
      public boolean isReady() {
        refresh();
        return myConnectionInitialized;
      }
    };
  }

  public void registerServerError(Throwable t) {
    WebSphereServerOutputListener[] listeners = myServerOutputListeners.toArray(new WebSphereServerOutputListener[myServerOutputListeners.size()]);
    for (WebSphereServerOutputListener listener : listeners) {
      listener.serverException(t);
    }
  }

  public void startDeploy(final DeploymentModel model) {
    if (!isDeploymentSupported()) {
      return;
    }

    myServerRequestingThread.queueRequest(myServerRequestingThread.new WaitingOnConditionRequest("server started", 300) {
      public boolean isReady() {
        try {
          return checkServer();
        }
        catch (Exception e) {
          return false;
        }
      }
    });

    final boolean deployEJBs = containsEjbFacet(model);
    final File deploymentSource = DeploymentManager.getInstance(myProject).getDeploymentSource(model);
    final String appName = getApplicationName(model);
    myServerRequestingThread.queueRequest(new WebSphereServerRequest("install '" + appName + "'") {
      public void run() throws Throwable {
        setDeploymentStatus(model, DeploymentStatus.ACTIVATING);
        myAdminClient.createAppManagement().installApplication(deploymentSource.getAbsolutePath(), appName,
                                                               getCellName(), getNodeName(), getServerName(), myUploadEARBeforeDeploy, deployEJBs);
      }
    });
    myServerRequestingThread.queueRequest(myServerRequestingThread.new WaitingOnConditionRequest("'" + appName + "' installed", 500) {
      public boolean isReady() {
        try {
          return myAdminClient.createAppManagement().checkIfAppExists(appName);
        }
        catch (Exception e) {
          return false;
        }
      }
    });
    myServerRequestingThread.queueRequest(new WebSphereServerRequest("start '" + appName + "'") {
      public void run() throws Throwable {
        myAdminClient.createAppManagement().startApplication(appName);
      }
    });
  }

  private static boolean containsEjbFacet(final DeploymentModel model) {
    Set<JavaeeFacet> facets = getAllIncludedFacets(model.getFacet(), new HashSet<JavaeeFacet>());
    for (JavaeeFacet facet : facets) {
      if (facet instanceof EjbFacet) {
        return true;
      }
    }
    return false;
  }

  private static Set<JavaeeFacet> getAllIncludedFacets(final @Nullable JavaeeFacet facet, final HashSet<JavaeeFacet> facets) {
    if (facet != null && facets.add(facet)) {
      JavaeeFacet[] javaeeFacets = facet.getPackagingConfiguration().getContainingFacets();
      for (JavaeeFacet javaeeFacet : javaeeFacets) {
        getAllIncludedFacets(javaeeFacet, facets);
      }
    }
    return facets;
  }

  protected boolean isDeploymentSupported() {
    return true;
  }

  private boolean checkServer() throws ConnectorExceptionWrapper, JMXExceptionWrapper {
    final ServerWrapper server = getServer();
    return server != null && server.isStarted();
  }

  protected abstract String getNodeName();

  protected abstract String getCellName();

  protected abstract String getServerName();

  public void startUndeploy(DeploymentModel model) {
    if (!isDeploymentSupported()) {
      return;
    }

    final String moduleName = getApplicationName(model);
    myServerRequestingThread.queueRequest(new WebSphereServerRequest("uninstall '" + moduleName + "'") {
      public void run() throws Throwable {
        myAdminClient.createAppManagement().uninstallApplication(moduleName);
      }
    });
  }

  protected void beforeConnecting() {
  }

  protected void refresh() {
    final boolean connected;

    connected = myConnectionInitialized || isPortOpened();

    if (!myConnectionInitialized && connected) {
      try {
        beforeConnecting();
        /*
        try {
          Class.forName("javax.net.ssl.SSLSocketFactory", true, myClientFactory.getClass().getClassLoader());
          Class.forName("com.ibm.websphere.ssl.protocol.SSLSocketFactory", true, myClientFactory.getClass().getClassLoader()).getMethod("getDefault").invoke(null);
        }
        catch (Exception e) {
          LOG.error(e);
        }
        */
        final WebSphereModel webSphereModel = (WebSphereModel)getCommonModel().getServerModel();
        myAdminClient = myClientFactory.createAdminClient(getHost(), getSOAPPort(), myVersion.hasAutoUpload(),
                                                          webSphereModel.USERNAME, webSphereModel.PASSWORD);
        try {
          myAdminClient.registerNotificationListener(new AppManagementNotificationListener() {
            public void handleNotification(String taskName, String taskStatus, String message, Properties properties) {
              LOG.debug("Notification: task '" + taskName + "' " + taskStatus + ". " + message);
              fireUpdateDeploymentStatus(null);
            }
          });
        }
        catch (JMXExceptionWrapper e) {
          LOG.error(e);
        }
      }
      catch (ConnectorExceptionWrapper e) {
        LOG.debug(e);
      }
      if (!isConnected()) return;
      myIsStarting = false;
      LOG.debug("server started");
    }

    if (myConnectionInitialized != connected) {
      fireUpdateDeploymentStatus(connected);
    }
    myConnectionInitialized = connected;
  }

  private void fireUpdateDeploymentStatus(final @Nullable Boolean connected) {
    ApplicationManager.getApplication().invokeLater(new Runnable() {
      public void run() {
        if (!myProject.isOpen()) return;

        if (connected != null) {
          fireServerListeners(new DefaultJ2EEServerEvent(connected, !connected));
        }
        DeploymentManager.getInstance(myProject).updateAllDeploymentStatus(WebSphereInstanceImpl.this, getCommonModel());
      }
    });
  }

  private boolean isPortOpened() {
    Socket socket = null;
    try {
      socket = new Socket(getHost(), getSOAPPort());
    }
    catch (IOException e) {
      LOG.debug(e);
    }
    finally {
      if (socket != null) {
        try {
          socket.close();
        }
        catch (IOException e) {
        }
      }
    }
    return socket != null && socket.isConnected();
  }

  protected abstract int getSOAPPort();

  public void updateDeploymentStatus(final DeploymentModel model) {
    if (isConnected()) {
      myServerRequestingThread.queueRequest(new WebSphereServerRequest("check deployment status") {
        public void run() throws Throwable {
          final DeploymentStatus deploymentStatus = getDeploymentStatus(model);
          setDeploymentStatus(model, deploymentStatus);
        }
      });
    }
    else {
      setDeploymentStatus(model, DeploymentStatus.DISCONNECTED);
    }
  }

  private void setDeploymentStatus(final DeploymentModel model, final DeploymentStatus status) {
    DeploymentManager.getInstance(myProject).setDeploymentStatus(model.getFacet(), status, getCommonModel(), this);
  }

  private DeploymentStatus getDeploymentStatus(final DeploymentModel model) {
    try {
      final ServerWrapper server = getServer();
      if (server == null || !server.isStarted()) return DeploymentStatus.DISCONNECTED;
      LOG.debug("WebSphereInstanceImpl.getDeploymentStatus");
      LOG.debug("server state = " + server.getState());
      final String appName = getApplicationName(model);
      final ApplicationWrapper application = myAdminClient.findApplication(appName);
      if (application == null) {
        LOG.debug("application '" + appName + "' not found");
        return DeploymentStatus.NOT_DEPLOYED;
      }
      final String[] modules = application.getModules();
      LOG.debug("modules = " + Arrays.asList(modules));

      return DeploymentStatus.DEPLOYED;
    }
    catch (ConnectorExceptionWrapper connectorExceptionWrapper) {
      return DeploymentStatus.UNKNOWN;
    }
    catch (JMXExceptionWrapper e) {
      LOG.debug(e);
      return DeploymentStatus.FAILED;
    }
  }

  private static String getApplicationName(final DeploymentModel model) {
    FacetPointer<JavaeeFacet> facetPointer = model.getFacetPointer();
    return facetPointer.getModuleName() + facetPointer.getFacetName();
  }

  public void addServerOutputListener(WebSphereServerOutputListener listener) {
    myServerOutputListeners.add(listener);
  }

  public void removeServerOutputListener(WebSphereServerOutputListener listener) {
    myServerOutputListeners.remove(listener);
  }

  protected @Nullable ServerWrapper getServer() throws ConnectorExceptionWrapper, JMXExceptionWrapper {
    if (myServer != null) {
      return myServer;
    }
    myServer = myAdminClient.createServer(getCellName(), getNodeName(), getServerName());
    if (myServer != null) {
      myServer.addListener(new ServerNotificationListener() {
        public void handleNotification(String message) {
          fireUpdateDeploymentStatus(null);
        }
      });
    }
    return myServer;
  }

  protected class MyServerExceptionHandler implements ServerRequestingThreadImpl.ServerExceptionHandler {
    public void process(Throwable t) {
      registerServerError(t);
    }
  }

}
