/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.webSphere.configuration;

import org.jetbrains.annotations.NotNull;

import java.io.File;

/**
 * @author nik
 */
public class WebSphereNode {
  private final WebSphereCell myCell;
  private final File myNodeDirectory;
  private final String myNodeName;

  public WebSphereNode(final @NotNull WebSphereCell cell, final @NotNull File nodeDir, final @NotNull String name) {
    myCell = cell;
    myNodeDirectory = nodeDir;
    myNodeName = name;
  }

  public File getNodeDirectory() {
    return myNodeDirectory;
  }

  public WebSphereCell getCell() {
    return myCell;
  }

  public WebSphereServerConfiguration[] getServers() {
    return WebSphereProfileUtil.getServerConfigurations(this);
  }

  public String getNodeName() {
    return myNodeName;
  }

  public String toString() {
    return myNodeName;
  }


  public boolean equals(final Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    final WebSphereNode that = (WebSphereNode)o;

    return myCell.equals(that.myCell) && myNodeDirectory.equals(that.myNodeDirectory);

  }

  public int hashCode() {
    int result;
    result = myCell.hashCode();
    result = 29 * result + myNodeDirectory.hashCode();
    return result;
  }
}
