/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.runDebug.configuration;

import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.run.localRun.*;
import com.intellij.j2ee.webSphere.configuration.WebSphereServerConfiguration;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.execution.runners.ProgramRunner;
import org.jetbrains.annotations.NonNls;

/**
 * @author nik
 */
public class WebSphereStartupPolicy implements ExecutableObjectStartupPolicy {
  public static final @NonNls String DEBUG_ENV_VARIABLE = "DEBUG";

  public ScriptHelper createStartupScriptHelper(final ProgramRunner runner) {
    return new ScriptHelper() {
      public ExecutableObject getDefaultScript(CommonModel model) {
        final WebSphereModel webSphereModel = (WebSphereModel)model.getServerModel();
        final WebSphereServerConfiguration configuration = webSphereModel.getServerConfiguration();
        if (configuration == null) return null;

        return new WebSphereStartupExecutable(configuration);
      }
    };
  }

  public ScriptHelper createShutdownScriptHelper(final ProgramRunner runner) {
    return new ScriptHelper() {
      public ExecutableObject getDefaultScript(CommonModel commonModel) {
        final WebSphereModel model = (WebSphereModel)commonModel.getServerModel();
        final WebSphereServerConfiguration configuration = model.getServerConfiguration();
        if (configuration == null) return null;

        final String path = configuration.getProfile().getShutdownScriptFile().getAbsolutePath();
        final String serverName = configuration.getServerName();
        final @NonNls String[] parameters;
        if (!StringUtil.isEmpty(model.USERNAME) && !StringUtil.isEmpty(model.PASSWORD)) {
          parameters = new String[]{path, serverName, "-username", model.USERNAME, "-password", model.PASSWORD};
        }
        else {
          parameters = new String[]{path, serverName};
        }
        return new CommandLineExecutableObject(parameters, "");
      }
    };
  }

  public EnvironmentHelper getEnvironmentHelper() {
    return new EnvironmentHelper() {
      @NonNls public String getDefaultJavaVmEnvVariableName(CommonModel model) {
        return DEBUG_ENV_VARIABLE;
      }
    };
  }

  public ScriptsHelper getStartupHelper() {
    return null;
  }

  public ScriptsHelper getShutdownHelper() {
    return null;
  }
}
