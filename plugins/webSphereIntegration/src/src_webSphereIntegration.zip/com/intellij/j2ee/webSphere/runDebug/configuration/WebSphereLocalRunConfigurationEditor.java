/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.runDebug.configuration;

import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VfsUtil;
import com.intellij.openapi.fileChooser.FileChooser;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.run.configuration.ApplicationServerSelectionListener;
import com.intellij.javaee.run.configuration.PredefinedLogFilesProviderEditor;
import com.intellij.javaee.run.configuration.PredefinedLogFilesListener;
import com.intellij.j2ee.webSphere.applicationServer.WebSpherePersistentData;
import com.intellij.j2ee.webSphere.configuration.*;
import com.intellij.javaee.appServerIntegrations.ApplicationServer;
import com.intellij.ui.ComboBoxFieldPanel;
import com.intellij.util.EventDispatcher;

import javax.swing.*;
import java.io.File;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collections;

import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

/**
 * @author nik
 */
public class WebSphereLocalRunConfigurationEditor extends SettingsEditor<CommonModel> implements ApplicationServerSelectionListener,
                                                                                                 PredefinedLogFilesProviderEditor {
  private EventDispatcher<PredefinedLogFilesListener> myDispatcher = EventDispatcher.create(PredefinedLogFilesListener.class);
  private JPanel myMainPanel;
  private JPanel myProfilePathPanel;
  private ComboBoxFieldPanel myProfilePath;
  private JLabel myProfilePathLabel;
  private JComboBox myCellBox;
  private JComboBox myNodeBox;
  private JComboBox myServerBox;
  private JTextField myUsernameField;
  private JPasswordField myPasswordField;
  private WebSphereVersion myVersion;
  private WebSphereCell mySelectedCell;
  private WebSphereNode mySelectedNode;
  private String mySelectedProfilePath;

  public WebSphereLocalRunConfigurationEditor() {
    myProfilePath = new ComboBoxFieldPanel();
    myProfilePath.setBrowseButtonActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        final VirtualFile[] files = FileChooser.chooseFiles(myMainPanel, new FileChooserDescriptor(false, true, false, false, false, false));
        if (files != null && files.length == 1) {
          final File file = VfsUtil.virtualToIoFile(files[0]);
          myProfilePath.setText(file.getAbsolutePath());
          onProfileChanged();
        }
      }
    });
    myProfilePath.createComponent();
    myProfilePathLabel.setLabelFor(myProfilePath.getComboBox());
    myProfilePathPanel.setLayout(new BorderLayout());
    myProfilePathPanel.add(myProfilePath, BorderLayout.CENTER);

    myProfilePath.getComboBox().addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        onProfileChanged();
      }
    });
    myCellBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        onCellChanged();
      }
    });
    myNodeBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        onNodeChanged();
      }
    });
    myServerBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        refreshLogFiles();
      }
    });
  }

  private void refreshLogFiles() {
    try {
      myDispatcher.getMulticaster().predefinedLogFilesChanged(getSnapshot());
    }
    catch (ConfigurationException e) {
    }
  }

  protected void resetEditorFrom(final CommonModel commonModel) {
    final ApplicationServer applicationServer = commonModel.getApplicationServer();
    final WebSphereModel model = (WebSphereModel)commonModel.getServerModel();
    myProfilePath.setText(model.PROFILE_PATH);
    myUsernameField.setText(model.USERNAME);
    myPasswordField.setText(model.PASSWORD);
    onServerChanged(applicationServer);
    selectByName(myCellBox, model.CELL_NAME);
    selectByName(myNodeBox, model.NODE_NAME);
    selectByName(myServerBox, model.SERVER_NAME);
  }

  private static void selectByName(final JComboBox comboBox, final String name) {
    for (int i = 0; i < comboBox.getItemCount(); i++) {
      final Object item = comboBox.getItemAt(i);
      if (item != null && item.toString().equals(name)) {
        comboBox.setSelectedIndex(i);
        return;
      }
    }
  }

  public void serverSelected(@Nullable ApplicationServer server) {
    onServerChanged(server);
  }

  private void onServerChanged(final @Nullable ApplicationServer server) {
    WebSphereVersion version = null;
    if (server != null) {
      final WebSpherePersistentData persistentData = (WebSpherePersistentData)server.getPersistentData();
      version = persistentData.getVersion();
    }

    if (myVersion != null && myVersion.equals(version)) {
      return;
    }

    myVersion = version;
    final JComboBox comboBox = myProfilePath.getComboBox();
    comboBox.removeAllItems();

    if (version != null) {
      final WebSphereProfile[] profiles = WebSphereProfileUtil.getProfiles(version);
      ArrayList<String> profilePaths = new ArrayList<String>();
      for (WebSphereProfile profile : profiles) {
        profilePaths.add(profile.getLocation().getAbsolutePath());
      }
      Collections.sort(profilePaths);
      for (String profilePath : profilePaths) {
        comboBox.addItem(profilePath);
      }
      setSelectedItemIfSingle(comboBox);

      final boolean profilesSupported = version.isProfilesSupported();
      myProfilePath.setVisible(profilesSupported);
      myProfilePathLabel.setVisible(profilesSupported);
      if ((!profilesSupported || "".equals(myProfilePath.getText())) && profilePaths.size() == 1) {
        myProfilePath.setText(profilePaths.get(0));
      }
    }
  }

  private static void setSelectedItemIfSingle(final JComboBox comboBox) {
    if (comboBox.getItemCount() == 1) {
      comboBox.setSelectedItem(comboBox.getItemAt(0));
    }
  }

  private void onProfileChanged() {
    final String profilePath = myProfilePath.getText();
    if (mySelectedProfilePath != null && mySelectedProfilePath.equals(profilePath)) {
      return;
    }
    mySelectedProfilePath = profilePath;

    myCellBox.removeAllItems();
    if (myVersion != null) {
      final WebSphereProfile profile = WebSphereProfileUtil.createProfile(myVersion, new File(profilePath));
      if (profile != null) {
        final WebSphereCell[] cells = profile.getCells();
        for (WebSphereCell cell : cells) {
          myCellBox.addItem(cell);
        }
        setSelectedItemIfSingle(myCellBox);
      }
    }
  }

  private void onCellChanged() {
    WebSphereCell cell = (WebSphereCell)myCellBox.getSelectedItem();
    if (mySelectedCell != null && mySelectedCell.equals(cell)) {
      return;
    }
    mySelectedCell = cell;

    myNodeBox.removeAllItems();
    if (cell != null) {
      final WebSphereNode[] nodes = cell.getNodes();
      for (WebSphereNode node : nodes) {
        myNodeBox.addItem(node);
      }
      setSelectedItemIfSingle(myNodeBox);
    }
  }

  private void onNodeChanged() {
    final WebSphereNode node = (WebSphereNode)myNodeBox.getSelectedItem();
    if (mySelectedNode != null && mySelectedNode.equals(node)) {
      return;
    }
    mySelectedNode = node;

    myServerBox.removeAllItems();
    if (node != null) {
      final WebSphereServerConfiguration[] servers = node.getServers();
      for (WebSphereServerConfiguration serverConfiguration : servers) {
        myServerBox.addItem(serverConfiguration);
      }
      setSelectedItemIfSingle(myServerBox);
    }
  }

  protected void applyEditorTo(final CommonModel commonModel) throws ConfigurationException {
    final WebSphereModel webSphereModel = (WebSphereModel)commonModel.getServerModel();
    webSphereModel.PROFILE_PATH = myProfilePath.getText();
    webSphereModel.CELL_NAME = getSelectedItem(myCellBox);
    webSphereModel.NODE_NAME = getSelectedItem(myNodeBox);
    webSphereModel.SERVER_NAME = getSelectedItem(myServerBox);
    webSphereModel.USERNAME = myUsernameField.getText();
    webSphereModel.PASSWORD = new String(myPasswordField.getPassword());
  }

  private static String getSelectedItem(final JComboBox cellBox) {
    final Object selectedItem = cellBox.getSelectedItem();
    return selectedItem == null ? "" : selectedItem.toString();
  }

  protected @NotNull JComponent createEditor() {
    return myMainPanel;
  }


  public void addListener(PredefinedLogFilesListener listener) {
    myDispatcher.addListener(listener);
  }

  public void removeListener(PredefinedLogFilesListener listener) {
    myDispatcher.addListener(listener);
  }

  protected void disposeEditor() {
  }
}
