/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.configuration;

import com.intellij.openapi.util.JDOMUtil;
import com.intellij.openapi.util.SystemInfo;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.execution.configurations.RuntimeConfigurationError;
import com.intellij.j2ee.webSphere.WebSphereBundle;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.JDOMException;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.net.MalformedURLException;

/**
 * @author nik
 */
public class WebSphereProfileUtil {
  private static final Logger LOG = Logger.getInstance("#com.intellij.j2ee.webSphere.configuration.WebSphereProfileUtil");
  @NonNls private static final String CONFIG_DIR = "config";
  @NonNls private static final String CELLS_DIR = "cells";
  @NonNls private static final String NODES_DIR = "nodes";
  @NonNls private static final String LOGS_DIR = "logs";
  @NonNls private static final String SERVER_INDEX_XML = "serverindex.xml";
  @NonNls private static final String START_SERVER_FILE_NAME_BAT = "startServer.bat";
  @NonNls private static final String STOP_SERVER_FILE_NAME_BAT = "stopServer.bat";
  @NonNls private static final String START_SERVER_FILE_NAME_SH = "startServer.sh";
  @NonNls private static final String STOP_SERVER_FILE_NAME_SH = "stopServer.sh";
  @NonNls private static final String SYSTEM_OUT_LOG_NAME = "SystemOut.log";

  @NonNls private static final String SPECIAL_ENDPOINTS_ELEMENT_NAME = "specialEndpoints";
  @NonNls private static final String SERVER_ENTRIES_ELEMENT_NAME = "serverEntries";
  @NonNls private static final String SERVER_NAME_ATTRIBUTE_NAME = "serverName";
  @NonNls private static final String DEFAULT_HOST_ENDPOINT = "WC_defaulthost";
  @NonNls private static final String SOAP_PORT_ENDPOINT = "SOAP_CONNECTOR_ADDRESS";
  @NonNls private static final String ENDPOINT_ATTRIBUTE_NAME = "endPointName";
  @NonNls private static final String ENDPOINT_ELEMENT_NAME = "endPoint";
  @NonNls private static final String PORT_ATTRIBUTE_NAME = "port";

  @NonNls private static final String CELL_NAMESPACE_URI = "http://www.ibm.com/websphere/appserver/schemas/5.0/topology.cell.xmi";
  @NonNls private static final String CELL_XML_FILE = "cell.xml";
  @NonNls private static final String CELL_ELEMENT_NAME = "Cell";
  @NonNls private static final String CELL_NAME_ATTRIBUTE = "name";
  private static final Namespace CELL_NAMESPACE = Namespace.getNamespace(CELL_NAMESPACE_URI);

  @NonNls private static final String DEFAULT_PROFILE_NAME = "default";
  private static final FileFilter DIRECTORY_FILTER = new FileFilter() {
    public boolean accept(File file) {
      return file.isDirectory();
    }
  };
  @NonNls private static final String NODE_XML_FILE = "node.xml";
  @NonNls private static final String NODE_NAMESPACE_URI = "http://www.ibm.com/websphere/appserver/schemas/5.0/topology.node.xmi";
  private static final Namespace NODE_NAMESPACE = Namespace.getNamespace(NODE_NAMESPACE_URI);
  @NonNls private static final String NODE_NAME_ATTRIBUTE = "name";
  @NonNls private static final String NODE_ELEMENT_NAME = "Node";

  @NonNls private static final String VIRTUALHOSTS_FILE_NAME = "virtualhosts.xml";
  @NonNls private static final String HOST_NAMESPACE_URI = "http://www.ibm.com/websphere/appserver/schemas/5.0/host.xmi";
  private static final Namespace HOST_NAMESPACE = Namespace.getNamespace(HOST_NAMESPACE_URI);
  @NonNls private static final String VIRTUAL_HOST_ELEMENT_NAME = "VirtualHost";
  @NonNls private static final String HOST_NAME_ATTRIBUTE = "name";
  @NonNls private static final String DEFAULT_HOST_NAME = "default_host";
  @NonNls private static final String ALIASES_ELEMENT_NAME = "aliases";
  @NonNls private static final String VIRTUAL_HOST_PORT_ATTRIBUTE = "port";

  @NonNls public static final String SSL_CONFIG_URL_PROPERTY = "com.ibm.SSL.ConfigURL";
  @NonNls private static final String SSL_PROPERTIES_PATH = "properties" + File.separator + "ssl.client.props";

  public static @NotNull WebSphereProfile[] getProfiles(WebSphereVersion version) {
    if (version.isProfilesSupported()) {
      final File profilesDir = version.getProfilesDir();
      List<WebSphereProfile> profiles = new ArrayList<WebSphereProfile>();
      final File[] dirs = getChildDirectories(profilesDir);
      for (File profileDir : dirs) {
        WebSphereProfile profile = createProfile(version, profileDir);
        if (profile != null) {
          profiles.add(profile);
        }
      }
      return profiles.toArray(new WebSphereProfile[profiles.size()]);
    }

    WebSphereProfile profile = createProfile(version, version.getServerHome());
    if (profile != null) {
      return new WebSphereProfile[] {profile};
    }
    return WebSphereProfile.EMPTY_ARRAY;
  }

  private static final String BIN_DIR = "bin";

  public static @Nullable WebSphereProfile createProfile(final WebSphereVersion version, final File profileDir) {
    if (!profileDir.exists()) return null;

    final File startupScript = new File(profileDir, BIN_DIR + File.separator + getStartServerScriptFile());
    final File shutdownScriptFile = new File(profileDir, BIN_DIR + File.separator + getStopServerScriptFile());
    //todo[nik] extract profile name from config files
    final String profileName = version.isProfilesSupported() ? profileDir.getName() : DEFAULT_PROFILE_NAME;
    final Map<String, String> properties = new HashMap<String, String>();
    if (version.getPresentableName().startsWith("6.1")) {
      try {
        properties.put(SSL_CONFIG_URL_PROPERTY, new File(profileDir, SSL_PROPERTIES_PATH).toURL().toString());
      }
      catch (MalformedURLException e) {
        LOG.error(e);
      }
    }

    return new WebSphereProfile(version, profileDir, profileName, startupScript, shutdownScriptFile, properties);
  }

  private static String getStopServerScriptFile() {
    return SystemInfo.isWindows ? STOP_SERVER_FILE_NAME_BAT : STOP_SERVER_FILE_NAME_SH;
  }

  private static String getStartServerScriptFile() {
    return SystemInfo.isWindows ? START_SERVER_FILE_NAME_BAT : START_SERVER_FILE_NAME_SH;
  }

  private static @NotNull String getNodeName(final File nodeDir) {
    return getCellOrNodeName(nodeDir, NODE_XML_FILE, NODE_NAMESPACE, NODE_ELEMENT_NAME, NODE_NAME_ATTRIBUTE);
  }

  private static @NotNull String getCellName(final File cellDir) {
    return getCellOrNodeName(cellDir, CELL_XML_FILE, CELL_NAMESPACE, CELL_ELEMENT_NAME, CELL_NAME_ATTRIBUTE);
  }

  private static @NotNull String getCellOrNodeName(final File dir, final String xmlFile,
                                          final Namespace namespace, final String elementName,
                                          final String nameAttribute) {
    String name = dir.getName();
    try {
      final Document document = JDOMUtil.loadDocument(new File(dir, xmlFile));
      final Element root = document.getRootElement();
      name = root.getChild(elementName, namespace).getAttributeValue(nameAttribute);
    }
    catch (Exception e) {
    }
    return name;
  }

  private static @NotNull File[] getChildDirectories(File dir) {
    final File[] dirs = dir.listFiles(DIRECTORY_FILTER);
    if (dirs == null) {
      return new File[0];
    }
    return dirs;
  }

  public static WebSphereServerConfiguration[] getServerConfigurations(final WebSphereNode node) {
    final WebSphereCell cell = node.getCell();
    final WebSphereVersion version = cell.getProfile().getVersion();
    final File serverIndex = new File(node.getNodeDirectory(), SERVER_INDEX_XML);
    final List<WebSphereServerConfiguration> servers = new ArrayList<WebSphereServerConfiguration>();

    try {
      final Document document = JDOMUtil.loadDocument(serverIndex);
      final Element root = document.getRootElement();
      final List<Element> serverEntries = root.getChildren(SERVER_ENTRIES_ELEMENT_NAME);
      for (Element serverEntry : serverEntries) {
        String serverName = serverEntry.getAttributeValue(SERVER_NAME_ATTRIBUTE_NAME);
        if (serverName == null) continue;

        int soapPort = version.getDefaultSOAPPort();
        int httpPort = getDefaultHttpPort(cell);
        final List<Element> endpoints = serverEntry.getChildren(SPECIAL_ENDPOINTS_ELEMENT_NAME);
        for (Element specialEndpoint : endpoints) {
          if (DEFAULT_HOST_ENDPOINT.equals(specialEndpoint.getAttributeValue(ENDPOINT_ATTRIBUTE_NAME))) {
            final Element endpoint = specialEndpoint.getChild(ENDPOINT_ELEMENT_NAME);
            httpPort = Integer.parseInt(endpoint.getAttributeValue(PORT_ATTRIBUTE_NAME));
          }
          else if (SOAP_PORT_ENDPOINT.equals(specialEndpoint.getAttributeValue(ENDPOINT_ATTRIBUTE_NAME))) {
            final Element endpoint = specialEndpoint.getChild(ENDPOINT_ELEMENT_NAME);
            soapPort = Integer.parseInt(endpoint.getAttributeValue(PORT_ATTRIBUTE_NAME));
          }
        }

        final File systemOutLogFile = new File(cell.getProfile().getLocation(), LOGS_DIR + File.separator + serverName + File.separator + SYSTEM_OUT_LOG_NAME);
        servers.add(new WebSphereServerConfiguration(node, serverName, httpPort, soapPort, systemOutLogFile));
      }
    }
    catch (Exception e) {
    }

    return servers.toArray(new WebSphereServerConfiguration[servers.size()]);
  }

  private static int getDefaultHttpPort(final WebSphereCell cell) {
    int port = cell.getProfile().getVersion().getDefaultHttpPort();
    final File hostsFile = new File(cell.getCellDirectory(), VIRTUALHOSTS_FILE_NAME);
    try {
      final Document document = JDOMUtil.loadDocument(hostsFile);
      final Element root = document.getRootElement();
      final List<Element> hostsList = root.getChildren(VIRTUAL_HOST_ELEMENT_NAME, HOST_NAMESPACE);
      for (Element hostElement : hostsList) {
        if (DEFAULT_HOST_NAME.equals(hostElement.getAttributeValue(HOST_NAME_ATTRIBUTE))) {
          final Element alias = hostElement.getChild(ALIASES_ELEMENT_NAME);
          if (alias != null) {
            try {
              port = Integer.parseInt(alias.getAttributeValue(VIRTUAL_HOST_PORT_ATTRIBUTE));
            }
            catch (NumberFormatException e) {
            }
          }
          break;
        }
      }
    }
    catch (Exception e) {
    }
    return port;
  }

  public static WebSphereNode[] getNodes(final WebSphereCell cell) {
    final File nodesDir = new File(cell.getCellDirectory(), NODES_DIR);
    final File[] nodeDirs = getChildDirectories(nodesDir);
    List<WebSphereNode> nodes = new ArrayList<WebSphereNode>();
    for (File nodeDir : nodeDirs) {
      String nodeName = getNodeName(nodeDir);
      nodes.add(new WebSphereNode(cell, nodeDir, nodeName));
    }
    return nodes.toArray(new WebSphereNode[nodes.size()]);
  }

  public static WebSphereCell[] getCells(final WebSphereProfile profile) {
    final File configDir = new File(profile.getLocation(), CONFIG_DIR);
    if (!configDir.exists()) return WebSphereCell.EMPTY_ARRAY;

    final File cellsDir = new File(configDir, CELLS_DIR);
    File[] cellDirs = getChildDirectories(cellsDir);
    List<WebSphereCell> cells = new ArrayList<WebSphereCell>();
    for (File cellDir : cellDirs) {
      String cellName = getCellName(cellDir);
      cells.add(new WebSphereCell(profile, cellDir, cellName));
    }
    return cells.toArray(new WebSphereCell[cells.size()]);
  }

  public static @NotNull WebSphereServerConfiguration createValidServerConfiguration(final WebSphereVersion version, final File profileDir,
                                                                                     final String cellName, final String nodeName,
                                                                                     final String serverName) throws RuntimeConfigurationException {
    final WebSphereProfile profile = createProfile(version, profileDir);
    if (profile == null) {
      throw new RuntimeConfigurationError(WebSphereBundle.message("error.profile.is.not.correct.text")) ;
    }

    final WebSphereCell cell = getCellByName(profile, cellName);
    if (cell == null) {
      throw new RuntimeConfigurationError(WebSphereBundle.message("error.cannot.find.cell.in.profile.text", cellName, profile.getName()));
    }

    final WebSphereNode node = getNodeByName(cell, nodeName);
    if (node == null) {
      throw new RuntimeConfigurationError(WebSphereBundle.message("error.cannot.find.node.in.cell.text", nodeName, cell.getCellName()));
    }

    final WebSphereServerConfiguration server = getServerByName(node, serverName);
    if (server == null) {
      throw new RuntimeConfigurationError(WebSphereBundle.message("error.cannot.find.server.in.node.text", serverName, node.getNodeName()));
    }
    return server;
  }

  public static @Nullable WebSphereCell getCellByName(WebSphereProfile profile, String cellName) {
    final WebSphereCell[] cells = profile.getCells();
    for (WebSphereCell cell : cells) {
      if (cell.getCellName().equals(cellName)) {
        return cell;
      }
    }
    return null;
  }

  public static @Nullable WebSphereNode getNodeByName(WebSphereCell cell, String nodeName) {
    final WebSphereNode[] nodes = cell.getNodes();
    for (WebSphereNode node : nodes) {
      if (node.getNodeName().equals(nodeName)) {
        return node;
      }
    }
    return null;
  }

  public static @Nullable WebSphereServerConfiguration getServerByName(WebSphereNode node, String serverName) {
    final WebSphereServerConfiguration[] servers = node.getServers();
    for (WebSphereServerConfiguration server : servers) {
      if (server.getServerName().equals(serverName)) {
        return server;
      }
    }
    return null;
  }
}
