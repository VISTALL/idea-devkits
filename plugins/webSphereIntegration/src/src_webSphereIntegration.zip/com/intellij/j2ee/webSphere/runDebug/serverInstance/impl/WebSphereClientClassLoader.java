/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.runDebug.serverInstance.impl;

import org.jetbrains.annotations.NonNls;

import java.net.URLClassLoader;
import java.net.URL;
import java.util.jar.Manifest;

import com.intellij.openapi.diagnostic.Logger;

/**
 * @author nik
 */
public class WebSphereClientClassLoader extends URLClassLoader {
  @NonNls private static final String JAVAX_MANAGEMENT_PACKAGE = "javax.management";
  @NonNls private static final String SUN_SECURITY_PACKAGE = "sun.security.";
  @NonNls private static final String JAVAX_SECURITY_AUTH_PACKAGE = "javax.security.auth.";
  private boolean myJavaxManagementPackageLoaded = false;

  public WebSphereClientClassLoader(URL[] urls, ClassLoader parent) {
    super(urls, parent);
  }

  public WebSphereClientClassLoader(URL[] urls) {
    super(urls);
  }

  protected synchronized Class loadClass(String name, boolean resolve) throws ClassNotFoundException {
    if (mustDelegate(name)) {
      return super.loadClass(name, resolve);
    }
    Class<?> c = findLoadedClass(name);
    if (c == null) {
      try {
        c = findClass(name);
        return c;
      }
      catch (ClassNotFoundException e) {
        return super.loadClass(name, resolve);
      }
    }
    if (resolve) {
      resolveClass(c);
    }
    return c;
  }

  private static boolean mustDelegate(final String name) {
    return name.startsWith(SUN_SECURITY_PACKAGE) || name.startsWith(JAVAX_SECURITY_AUTH_PACKAGE);
  }

  protected Package getPackage(String name) {
    if (JAVAX_MANAGEMENT_PACKAGE.equals(name) && !myJavaxManagementPackageLoaded) {
      return null;
    }
    return super.getPackage(name);
  }

  protected Package definePackage(String name, Manifest man, URL url) throws IllegalArgumentException {
    final Package aPackage = super.definePackage(name, man, url);
    if (JAVAX_MANAGEMENT_PACKAGE.equals(name)) {
      myJavaxManagementPackageLoaded = true;
    }
    return aPackage;
  }
}
