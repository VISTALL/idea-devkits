/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.runDebug.serverInstance.impl;

import com.intellij.openapi.diagnostic.Logger;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.net.URL;
import java.net.URLClassLoader;
import java.util.Arrays;
import java.util.List;
import java.util.jar.Manifest;

/**
 * @author nik
 */
public class WebSphereClientClassLoader extends URLClassLoader {
  private static final Logger LOG = Logger.getInstance("#com.intellij.j2ee.webSphere.runDebug.serverInstance.impl.WebSphereClientClassLoader");
  @NonNls private static final String JAVAX_MANAGEMENT_PACKAGE = "javax.management";
  @NonNls private static final String SUN_SECURITY_PACKAGE = "sun.security.";
  @NonNls private static final String JAVAX_SECURITY_AUTH_PACKAGE = "javax.security.auth.";
  @NonNls private static final String JAVAX_XML_PACKAGE = "javax.xml.";
  @NonNls private static final String ORG_XML_PACKAGE = "org.xml.sax.";
  @NonNls private static final String ORG_W3C_DOM_PACKAGE = "org.w3c.dom.";
  @NonNls private static final List<String> WATCHED_CLASSES = Arrays.asList("javax.xml.parsers.DocumentBuilderFactory", "javax.xml.parsers.FactoryFinder",
                                                                            "org.xml.sax.InputSource", "org.w3c.dom.Document");
  private boolean myJavaxManagementPackageLoaded = false;

  public WebSphereClientClassLoader(URL[] urls, ClassLoader parent) {
    super(urls, parent);
  }

  public WebSphereClientClassLoader(URL[] urls) {
    super(urls);
  }

  protected synchronized Class loadClass(String name, boolean resolve) throws ClassNotFoundException {
    boolean log = LOG.isDebugEnabled() && WATCHED_CLASSES.contains(name);
    if (log) {
      LOG.debug("Loading " + name);
    }
    if (mustDelegate(name)) {
      if (log) {
        LOG.debug("Delegating to super: " + getParent());
      }
      Class<?> c = super.loadClass(name, resolve);
      if (log) {
        LOG.debug("Loaded: " + getDescription(c));
      }
      return c;
    }

    Class<?> c = findLoadedClass(name);
    if (c == null) {
      try {
        c = findClass(name);
        if (log) {
          LOG.debug("Found in classpath: " + getDescription(c));
          LOG.debug("Classpath:");
          for (URL url : getURLs()) {
            LOG.debug(String.valueOf(url));
          }
        }
        return c;
      }
      catch (ClassNotFoundException e) {
        if (log) {
          LOG.debug("Not found, delegating to super");
        }
        Class<?> aClass = super.loadClass(name, resolve);
        if (log) {
          LOG.debug("Loaded: " + getDescription(aClass));
        }
        return aClass;
      }
    }
    else if (log) {
      LOG.debug("Found loaded class: " + getDescription(c));
    }
    if (resolve) {
      resolveClass(c);
    }
    return c;
  }

  @NonNls
  private static String getDescription(final @Nullable Class<?> c) {
    if (c == null) {
      return "null";
    }
    return c.getName() + " from " + c.getResource(c.getSimpleName() + ".class");
  }

  private static boolean mustDelegate(final String name) {
    return name.startsWith(SUN_SECURITY_PACKAGE) || name.startsWith(JAVAX_SECURITY_AUTH_PACKAGE)
           || name.startsWith(JAVAX_XML_PACKAGE) || name.startsWith(ORG_XML_PACKAGE) || name.startsWith(ORG_W3C_DOM_PACKAGE);
  }

  protected Package getPackage(String name) {
    if (JAVAX_MANAGEMENT_PACKAGE.equals(name) && !myJavaxManagementPackageLoaded) {
      return null;
    }
    return super.getPackage(name);
  }

  protected Package definePackage(String name, Manifest man, URL url) throws IllegalArgumentException {
    final Package aPackage = super.definePackage(name, man, url);
    if (JAVAX_MANAGEMENT_PACKAGE.equals(name)) {
      myJavaxManagementPackageLoaded = true;
    }
    return aPackage;
  }
}
