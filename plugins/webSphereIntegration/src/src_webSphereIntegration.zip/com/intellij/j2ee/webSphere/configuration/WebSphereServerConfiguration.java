/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.webSphere.configuration;

import java.io.File;

/**
 * @author nik
 */
public class WebSphereServerConfiguration {
  private final WebSphereNode myNode;
  private final String myServerName;
  private final int myHttpPort;
  private final int mySOAPPort;
  private final File mySystemOutLogFile;

  public WebSphereServerConfiguration(final WebSphereNode node, final String serverName, final int httpPort, final int SOAPPort, final File systemOutLogFile) {
    myNode = node;
    myServerName = serverName;
    myHttpPort = httpPort;
    mySOAPPort = SOAPPort;
    mySystemOutLogFile = systemOutLogFile;
  }

  public WebSphereNode getNode() {
    return myNode;
  }

  public String getServerName() {
    return myServerName;
  }

  public int getHttpPort() {
    return myHttpPort;
  }

  public int getSOAPPort() {
    return mySOAPPort;
  }

  public String toString() {
    return myServerName;
  }

  public File getSystemOutLogFile() {
    return mySystemOutLogFile;
  }

  public WebSphereProfile getProfile() {
    return getNode().getCell().getProfile();
  }


  public boolean equals(final Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    final WebSphereServerConfiguration that = (WebSphereServerConfiguration)o;

    return myNode.equals(that.myNode) && myServerName.equals(that.myServerName);

  }

  public int hashCode() {
    int result;
    result = myNode.hashCode();
    result = 29 * result + myServerName.hashCode();
    return result;
  }
}
