/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.runDebug.serverInstance.impl;

import com.intellij.execution.ExecutionException;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.j2ee.webSphere.configuration.WebSphereServerConfiguration;
import com.intellij.j2ee.webSphere.runDebug.configuration.WebSphereModel;

import java.util.Map;

/**
 * @author nik
 */
public class WebSphereLocalInstance extends WebSphereInstanceImpl {
  private WebSphereServerConfiguration myConfiguration;

  public WebSphereLocalInstance(final CommonModel commonModel) throws ExecutionException {
    super(commonModel, false);
    myConfiguration = ((WebSphereModel)getCommonModel().getServerModel()).getServerConfiguration();
    LOG.assertTrue(myConfiguration != null);
  }

  protected void beforeConnecting() {
    final Map<String,String> properties = myConfiguration.getProfile().getProperties();
    for (Map.Entry<String, String> entry : properties.entrySet()) {
      System.setProperty(entry.getKey(), entry.getValue());
    }
  }

  protected String getNodeName() {
    return myConfiguration.getNode().getNodeName();
  }

  protected String getCellName() {
    return myConfiguration.getNode().getCell().getCellName();
  }

  protected String getServerName() {
    return myConfiguration.getServerName();
  }

  protected int getSOAPPort() {
    return myConfiguration.getSOAPPort();
  }

}
