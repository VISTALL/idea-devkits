/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.webSphere.runDebug.configuration;

import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.ui.Messages;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.j2ee.webSphere.WebSphereBundle;
import com.intellij.j2ee.webSphere.runDebug.serverInstance.impl.WebSphereRemoteInstance;
import com.intellij.execution.configurations.RuntimeConfigurationError;
import com.intellij.execution.configurations.RuntimeConfigurationWarning;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * @author nik
 */
public class WebSphereRemoteRunConfigurationEditor extends SettingsEditor<CommonModel> {
  private JPanel myMainPanel;
  private JTextField mySOAPPortField;
  private JTextField myServerNameField;
  private JButton myTestConnectionButton;
  private JTextField myCellNameField;
  private JTextField myNodeNameField;
  private JTextField myUsernameField;
  private JPasswordField myPasswordField;

  public WebSphereRemoteRunConfigurationEditor() {
    myTestConnectionButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        testConnection();
      }
    });
  }

  private void testConnection() {
    final String title = WebSphereBundle.message("message.text.connection.title");
    try {
      final CommonModel model = getSnapshot();
      try {
        model.checkConfiguration();
      }
      catch (RuntimeConfigurationError e) {
        Messages.showErrorDialog(e.getLocalizedMessage(), title);
      }
      catch (RuntimeConfigurationWarning e) {
      }

      try {
        final WebSphereRemoteInstance instance = new WebSphereRemoteInstance(model);
        instance.testConnectionAndDispose();
        Messages.showInfoMessage(WebSphereBundle.message("message.text.connection.successful"), title);
      }
      catch (Exception e) {
        Messages.showErrorDialog(e.getLocalizedMessage(), title);
      }
    }
    catch (ConfigurationException e) {
      Messages.showErrorDialog(e.getLocalizedMessage(), title);
    }
  }
  
  protected void resetEditorFrom(final CommonModel commonModel) {
    final WebSphereModel webSphereModel = (WebSphereModel)commonModel.getServerModel();
    mySOAPPortField.setText(String.valueOf(webSphereModel.SOAP_PORT));
    myCellNameField.setText(webSphereModel.CELL_NAME);
    myNodeNameField.setText(webSphereModel.NODE_NAME);
    myServerNameField.setText(webSphereModel.SERVER_NAME);
    myUsernameField.setText(webSphereModel.USERNAME);
    myPasswordField.setText(webSphereModel.PASSWORD);
  }

  protected void applyEditorTo(final CommonModel commonModel) throws ConfigurationException {
    final WebSphereModel webSphereModel = (WebSphereModel)commonModel.getServerModel();
    try {
      webSphereModel.SOAP_PORT = Integer.parseInt(mySOAPPortField.getText());
      webSphereModel.CELL_NAME = myCellNameField.getText();
      webSphereModel.NODE_NAME = myNodeNameField.getText();
      webSphereModel.SERVER_NAME = myServerNameField.getText();
      webSphereModel.USERNAME = myUsernameField.getText();
      webSphereModel.PASSWORD = new String(myPasswordField.getPassword());
    }
    catch (NumberFormatException e) {
      throw new ConfigurationException(e.getLocalizedMessage());
    }
  }

  protected JComponent createEditor() {
    return myMainPanel;
  }

  protected void disposeEditor() {
  }
}
