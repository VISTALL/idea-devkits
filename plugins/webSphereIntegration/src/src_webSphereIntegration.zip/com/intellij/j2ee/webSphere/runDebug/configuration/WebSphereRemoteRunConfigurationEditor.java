/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.webSphere.runDebug.configuration;

import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.ui.TextFieldWithBrowseButton;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.j2ee.webSphere.WebSphereBundle;
import com.intellij.j2ee.webSphere.runDebug.serverInstance.impl.WebSphereRemoteInstance;
import com.intellij.execution.configurations.RuntimeConfigurationError;
import com.intellij.execution.configurations.RuntimeConfigurationWarning;
import com.intellij.util.ui.UIUtil;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * @author nik
 */
public class WebSphereRemoteRunConfigurationEditor extends SettingsEditor<CommonModel> {
  private JPanel myMainPanel;
  private JTextField mySOAPPortField;
  private JTextField myServerNameField;
  private JButton myTestConnectionButton;
  private JTextField myCellNameField;
  private JTextField myNodeNameField;
  private JTextField myUsernameField;
  private JPasswordField myPasswordField;
  private JCheckBox myUseSSLCheckBox;
  private TextFieldWithBrowseButton myClientTrustFileField;
  private JPanel myClientTrustFilePanel;

  public WebSphereRemoteRunConfigurationEditor(final Project project) {
    myUseSSLCheckBox.addActionListener(new ActionListener() {
      public void actionPerformed(final ActionEvent e) {
        UIUtil.setEnabled(myClientTrustFilePanel, myUseSSLCheckBox.isSelected(), true);
      }
    });
    myTestConnectionButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        testConnection();
      }
    });
    myClientTrustFileField.addBrowseFolderListener(null, null, project, new FileChooserDescriptor(true, false, false, false, false, false) {
      public boolean isFileVisible(final VirtualFile file, final boolean showHiddenFiles) {
        return super.isFileVisible(file, showHiddenFiles) && (file.isDirectory() || "jks".equals(file.getExtension()));
      }
    });
  }

  private void testConnection() {
    final String title = WebSphereBundle.message("message.text.connection.title");
    try {
      final CommonModel model = getSnapshot();
      try {
        model.checkConfiguration();
      }
      catch (RuntimeConfigurationError e) {
        Messages.showErrorDialog(e.getLocalizedMessage(), title);
      }
      catch (RuntimeConfigurationWarning e) {
      }

      try {
        final WebSphereRemoteInstance instance = new WebSphereRemoteInstance(model);
        instance.testConnectionAndDispose();
        Messages.showInfoMessage(WebSphereBundle.message("message.text.connection.successful"), title);
      }
      catch (Exception e) {
        Messages.showErrorDialog(e.getLocalizedMessage(), title);
      }
    }
    catch (ConfigurationException e) {
      Messages.showErrorDialog(e.getLocalizedMessage(), title);
    }
  }
  
  protected void resetEditorFrom(final CommonModel commonModel) {
    final WebSphereModel model = (WebSphereModel)commonModel.getServerModel();
    mySOAPPortField.setText(String.valueOf(model.SOAP_PORT));
    myCellNameField.setText(model.CELL_NAME);
    myNodeNameField.setText(model.NODE_NAME);
    myServerNameField.setText(model.SERVER_NAME);
    myUsernameField.setText(model.USERNAME);
    myPasswordField.setText(model.PASSWORD);
    myUseSSLCheckBox.setSelected(model.CLIENT_TRUST_FILE_PATH != null);
    UIUtil.setEnabled(myClientTrustFilePanel, model.CLIENT_TRUST_FILE_PATH != null, true);
    if (model.CLIENT_TRUST_FILE_PATH != null) {
      myClientTrustFileField.setText(FileUtil.toSystemDependentName(model.CLIENT_TRUST_FILE_PATH));
    }
  }

  protected void applyEditorTo(final CommonModel commonModel) throws ConfigurationException {
    final WebSphereModel model = (WebSphereModel)commonModel.getServerModel();
    try {
      model.SOAP_PORT = Integer.parseInt(mySOAPPortField.getText());
      model.CELL_NAME = myCellNameField.getText();
      model.NODE_NAME = myNodeNameField.getText();
      model.SERVER_NAME = myServerNameField.getText();
      model.USERNAME = myUsernameField.getText();
      model.PASSWORD = new String(myPasswordField.getPassword());
      model.CLIENT_TRUST_FILE_PATH =
        myUseSSLCheckBox.isSelected() ? FileUtil.toSystemIndependentName(myClientTrustFileField.getText()) : null;
    }
    catch (NumberFormatException e) {
      throw new ConfigurationException(e.getLocalizedMessage());
    }
  }

  protected JComponent createEditor() {
    return myMainPanel;
  }

  protected void disposeEditor() {
  }
}
