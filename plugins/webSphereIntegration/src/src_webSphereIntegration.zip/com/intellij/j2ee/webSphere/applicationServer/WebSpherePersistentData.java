/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.applicationServer;

import com.intellij.j2ee.webSphere.configuration.WebSphereVersion;
import com.intellij.j2ee.webSphere.configuration.WebSphereVersionUtil;
import com.intellij.j2ee.webSphere.runDebug.serverInstance.impl.WebSphereClientClassLoader;
import com.intellij.javaee.appServerIntegrations.DefaultPersistentData;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.util.ArrayUtil;
import com.intellij.util.PathUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author nik
 */
public class WebSpherePersistentData extends DefaultPersistentData {
  private static final Logger LOG = Logger.getInstance("#com.intellij.j2ee.webSphere.applicationServer.WebSpherePersistentData");
  @NonNls private static final String CLIENT_IMPL_JAR_NAME = "webSphereClientImpl.jar";
  @NonNls private static final String CLIENT_IMPL_DIR = "webSphereClientImpl";

  public String WEBSPHERE_APPSERVER_HOME = "";
  private ClassLoader myCachedLoader;
  private File[] myCachedPaths;
  private static File ourClientImplClassesRoot;

  public @Nullable WebSphereVersion getVersion() {
    return WebSphereVersionUtil.createVersion(new File(FileUtil.toSystemDependentName(WEBSPHERE_APPSERVER_HOME)));
  }

  public @Nullable ClassLoader getClientClassLoader(ClassLoader parent) throws MalformedURLException {
    final WebSphereVersion version = getVersion();
    if (version == null) return null;

    final File[] clientClasspath = getClientClasspath(version);
    if (LOG.isDebugEnabled()) {
      LOG.debug("WebSphere version: " + version.getPresentableName());
      LOG.debug("WebSphere client classpath:");
      for (File file : clientClasspath) {
        LOG.debug(file.getAbsolutePath());
      }
    }
    if (myCachedLoader == null || !Comparing.equal(clientClasspath, myCachedPaths)) {
      myCachedPaths = clientClasspath;
      final URL[] jarUrls = new URL[clientClasspath.length];
      for (int i = 0; i < clientClasspath.length; i++) {
        jarUrls[i] = clientClasspath[i].toURL();
      }

      myCachedLoader = new WebSphereClientClassLoader(jarUrls, parent);
    }
    return myCachedLoader;
  }

  private static File[] getClientClasspath(final WebSphereVersion version) {
    final File[] clientJars = version.getClientJars();
    return ArrayUtil.append(clientJars, getWebSphereClientLocation());
  }

  private static File getWebSphereClientLocation() {
    if (ourClientImplClassesRoot == null) {
      File classesRoot = new File(PathUtil.getJarPathForClass(WebSpherePersistentData.class));
      if (classesRoot.isFile()) {
        final File clientImplDir = new File(classesRoot.getParent(), CLIENT_IMPL_DIR);
        ourClientImplClassesRoot = new File(clientImplDir, CLIENT_IMPL_JAR_NAME);
      }
      else {
        ourClientImplClassesRoot = new File(classesRoot.getParent(), CLIENT_IMPL_DIR);
      }
    }

    return ourClientImplClassesRoot;
  }
}
