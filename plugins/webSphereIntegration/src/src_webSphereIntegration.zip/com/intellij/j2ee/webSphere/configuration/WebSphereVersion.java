/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.configuration;

import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.Map;

/**
 * @author nik
 */
public class WebSphereVersion {
  private final File myServerHome;
  private final String myPresentableName;
  private final boolean myProfilesSupported;
  private final int myDefaultSOAPPort;
  private final int myDefaultHttpPort;
  private final File myProfilesDir;
  private final File myJ2EEJar;
  private final File[] myClientJars;
  private final boolean myHasAutoUpload;
  private final boolean myStartingAsServiceImplemented;
  private final String myJspPackage;
  private final boolean myJspLineMappingCorrectionNeeded;
  private String[] mySecurityProviders;

  public WebSphereVersion(final File serverHome,
                          final String presentableName,
                          final boolean profilesSupported,
                          final int defaultSOAPPort,
                          final int defaultHttpPort,
                          final File profilesDir,
                          final File j2EEJar,
                          final File[] clientJars,
                          final boolean hasAutoUpload,
                          final boolean startingAsServiceImplemented,
                          final String jspPackage,
                          final boolean jspLineMappingCorrectionNeeded,
                          final String[] securityProviders) {
    myServerHome = serverHome;
    myPresentableName = presentableName;
    myProfilesSupported = profilesSupported;
    myDefaultSOAPPort = defaultSOAPPort;
    myDefaultHttpPort = defaultHttpPort;
    myProfilesDir = profilesDir;
    myJ2EEJar = j2EEJar;
    myClientJars = clientJars;
    myHasAutoUpload = hasAutoUpload;
    myStartingAsServiceImplemented = startingAsServiceImplemented;
    myJspPackage = jspPackage;
    myJspLineMappingCorrectionNeeded = jspLineMappingCorrectionNeeded;
    mySecurityProviders = securityProviders;
  }

  public String[] getSecurityProviders() {
    return mySecurityProviders;
  }

  public String getPresentableName() {
    return myPresentableName;
  }

  public File[] getClientJars() {
    return myClientJars;
  }

  public File getProfilesDir() {
    return myProfilesDir;
  }

  public File getServerHome() {
    return myServerHome;
  }

  public boolean isProfilesSupported() {
    return myProfilesSupported;
  }

  public File getJ2EEJar() {
    return myJ2EEJar;
  }

  public int getDefaultSOAPPort() {
    return myDefaultSOAPPort;
  }

  public int getDefaultHttpPort() {
    return myDefaultHttpPort;
  }

  public boolean hasAutoUpload() {
    return myHasAutoUpload;
  }

  public boolean isStartingAsServiceImplemented() {
    return myStartingAsServiceImplemented;
  }

  public String getJspPackage() {
    return myJspPackage;
  }

  public boolean isJspLineMappingCorrectionNeeded() {
    return myJspLineMappingCorrectionNeeded;
  }


  public boolean equals(final Object obj) {
    if (!(obj instanceof WebSphereVersion)) return false;
    return myServerHome.equals(((WebSphereVersion)obj).myServerHome);
  }

  public int hashCode() {
    return myServerHome.hashCode();
  }
}
