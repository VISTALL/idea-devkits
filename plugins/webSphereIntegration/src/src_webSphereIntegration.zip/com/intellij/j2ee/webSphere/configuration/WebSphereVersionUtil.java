/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.configuration;

import com.intellij.openapi.util.JDOMUtil;
import org.jdom.Document;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * @author nik
 */
public class WebSphereVersionUtil {
  public static final int V6_DEFAULT_SOAP_PORT = 8880;
  public static final int V5_DEFAULT_SOAP_PORT = 7880;
  public static final int V6_DEFAULT_HTTP_PORT = 9080;
  public static final int V5_DEFAULT_HTTP_PORT = 7080;

  @NonNls private static final String[] V61_SECURITY_PROVIDERS = {
    "com.ibm.jsse2.IBMJSSEProvider2",
    "com.ibm.crypto.provider.IBMJCE",
  };


  @NonNls private static final String[] V6_1_CLIENT_JARS = new String[]{
    "plugins/com.ibm.ws.runtime_6.1.0.jar",
    //"java/jre/lib/core.jar",
    "java/jre/lib/security.jar",
    "java/jre/lib/ibmcfw.jar",
    "plugins/com.ibm.ws.security.crypto_6.1.0.jar",
    "runtimes/com.ibm.ws.admin.client_6.1.0.jar",
    "java/jre/lib/ext/ibmjceprovider.jar",
    "java/jre/lib/ibmjsseprovider2.jar",
    "java/jre/lib/ibmpkcs.jar",
  };

  @NonNls private static final String[] V6_0_CLIENT_JARS = new String[]{
    "lib/mail-impl.jar",
    "lib/admin.jar",
    "lib/wsexception.jar",
    "lib/wssec.jar",
    "lib/utils.jar",
    "lib/ras.jar",
    "lib/bootstrap.jar",
    "lib/emf.jar",
    "lib/sas.jar",
    "lib/ffdc.jar",
    "lib/wasjmx.jar",
    "lib/soap.jar",
    "java/jre/lib/ibmcertpathprovider.jar",
    "java/jre/lib/ext/ibmjceprovider.jar",
    "java/jre/lib/ibmjsseprovider.jar",
    "lib/j2ee.jar",
    "lib/classloader.jar",
    "lib/wasproduct.jar",
    "lib/wjmxapp.jar",
    "lib/runtime.jar",
    "lib/security.jar",
    "lib/iwsorb.jar",
    "lib/runtime.jar",
    "lib/filetransfer.jar"
  };

  @NonNls private static final String[] V5_CLIENT_JARS = new String[]{
    "lib/admin.jar",
    "lib/wsexception.jar",
    "lib/wasjmx.jar",
    "lib/jmxc.jar",
    "java/jre/lib/security.jar",
    "java/jre/lib/ibmjsseprovider.jar",
    "java/jre/lib/ext/mail.jar",
    "java/jre/lib/ext/log.jar",
    "lib/filetransfer.jar",
    "properties"
  };

  private static enum Version {
    V5x("5.x", V5_DEFAULT_SOAP_PORT, V5_DEFAULT_HTTP_PORT, "org.apache.jsp", V5_CLIENT_JARS),
    V6_0("6.0", V6_DEFAULT_SOAP_PORT, V6_DEFAULT_HTTP_PORT, "com.ibm._jsp", V6_0_CLIENT_JARS),
    V6_1("6.1", V6_DEFAULT_SOAP_PORT, V6_DEFAULT_HTTP_PORT, "com.ibm._jsp", V6_1_CLIENT_JARS);

    private String myPresentableName;
    private int myDefaultSOAPPort;
    private int myDefaultHttpPort;
    private String myJspPackage;
    private String[] myClientClasspath;

    Version(final @NonNls String presentableName,
            final int defaultSOAPPort,
            final int defaultHttpPort,
            final @NonNls String jspPackage,
            final @NonNls String[] clientClasspath) {
     myPresentableName = presentableName;
     myDefaultSOAPPort = defaultSOAPPort;
     myDefaultHttpPort = defaultHttpPort;
     myJspPackage = jspPackage;
     myClientClasspath = clientClasspath;
   }
  }

  @NonNls private static final String VERSION_ATTRIBUTE_NAME = "version";

  @NonNls private static final String PROFILES_DIR = "profiles";
  @NonNls private static final String LIB_DIR = "lib";
  @NonNls private static final String J2EE_JAR_NAME = "j2ee.jar";
  @NonNls private static final String PLATFORM_WEBSPHERE_FILE_PATH =
    "properties" + File.separator + VERSION_ATTRIBUTE_NAME + File.separator + "platform.websphere";

  public static @Nullable WebSphereVersion createVersion(File serverHome) {
    if (!serverHome.exists()) return null;
    final Version version = getVersion(serverHome);
    if (version == null) return null;

    final boolean isV6 = version == Version.V6_0 || version == Version.V6_1;
    final File profilesDir = new File(serverHome, WebSphereVersionUtil.PROFILES_DIR);
    final File j2eeJar = new File(new File(serverHome, LIB_DIR), WebSphereVersionUtil.J2EE_JAR_NAME);

    final File[] clientJars = getClientJars(serverHome, version);
    final String[] securityProviders = version == Version.V6_1 ? V61_SECURITY_PROVIDERS : new String[0];
    return new WebSphereVersion(serverHome, version.myPresentableName, isV6, version.myDefaultSOAPPort,
                                version.myDefaultHttpPort, profilesDir, j2eeJar, clientJars, isV6, isV6, version.myJspPackage, !isV6,
                                securityProviders);
  }

  private static File[] getClientJars(final File serverHome, final Version version) {
    String[] relativePaths = version.myClientClasspath;
    final File[] jars = new File[relativePaths.length];
    for (int i = 0; i < relativePaths.length; i++) {
      String relativePath = relativePaths[i];
      jars[i] = new File(serverHome, relativePath.replace('/', File.separatorChar));
    }
    return jars;
  }

  private static @Nullable Version getVersion(File serverHome) {
    final File platformPropertiesFile = new File(serverHome, PLATFORM_WEBSPHERE_FILE_PATH);
    if (!platformPropertiesFile.exists()) return null;

    try {
      final Document document = JDOMUtil.loadDocument(platformPropertiesFile);
      final String version = document.getRootElement().getAttributeValue(VERSION_ATTRIBUTE_NAME);
      if (version.startsWith("6.1")) return Version.V6_1;
      if (version.startsWith("6.0")) return Version.V6_0;
      if (version.startsWith("5.")) return Version.V5x;
    }
    catch (Exception e) {
    }
    return null;
  }
}
