/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.webSphere.runDebug.configuration;

import com.intellij.javaee.run.localRun.ExecutableObject;
import com.intellij.javaee.run.localRun.ScriptUtil;
import com.intellij.javaee.run.localRun.CommandLineExecutableObject;
import com.intellij.j2ee.webSphere.configuration.WebSphereProfile;
import com.intellij.j2ee.webSphere.configuration.WebSphereServerConfiguration;
import com.intellij.j2ee.webSphere.WebSphereBundle;
import com.intellij.execution.process.OSProcessHandler;
import com.intellij.execution.process.ProcessAdapter;
import com.intellij.execution.process.ProcessEvent;
import com.intellij.execution.ExecutionException;
import com.intellij.execution.configurations.GeneralCommandLine;
import com.intellij.util.ArrayUtil;
import org.jetbrains.annotations.NonNls;

import java.util.Map;
import java.io.*;

/**
 * @author nik
 */
public class WebSphereStartupExecutable implements ExecutableObject {
  @NonNls private static final String GENERATED_WEBSPHERE_SERVER_START_SCRIPT_NAME = "generated_websphere_server_start_script";
  @NonNls private static final String GENERATE_SCRIPT_ARG = "-script";
  @NonNls private static final String FROM_WIN_SERVICE_ARG = "-fromWinService";
  @NonNls private static final String SET_DEBUG_MODE_PORPERTY = "-Dwas.debug.mode=true";
  private WebSphereServerConfiguration myConfiguration;
  private WebSphereProfile myProfile;

  public WebSphereStartupExecutable(final WebSphereServerConfiguration configuration) {
    myConfiguration = configuration;
    myProfile = myConfiguration.getProfile();
  }

  public String getDisplayString() {
    return WebSphereBundle.message("generated.server.startup.script.disaplay.text");
  }

  public OSProcessHandler createProcessHandler(String workingDirectory, Map<String, String> envVariables) throws ExecutionException {
    try {
      final File scriptDir = myProfile.getStartupScriptFile().getParentFile();
      final File scriptFile = new File(scriptDir, GENERATED_WEBSPHERE_SERVER_START_SCRIPT_NAME + "." + ScriptUtil.getScriptExtension());
      scriptFile.delete();

      final GeneralCommandLine commandLine = ScriptUtil.createCommandLine(getScriptGenerationCommandLine(scriptFile));
      commandLine.setWorkingDirectory(scriptDir);
      final Process process = commandLine.createProcess();
      try {
        process.waitFor();
      }
      catch (InterruptedException e) {
      }

      if (!scriptFile.exists()) {
        String message = readLine(process.getErrorStream());
        if (message == null) {
          message = readLine(process.getInputStream());
        }
        throw new IOException(message);
      }
      ScriptUtil.makeExecutable(scriptFile);
      scriptFile.deleteOnExit();

      final String debug = envVariables.get(WebSphereStartupPolicy.DEBUG_ENV_VARIABLE);
      if (debug != null) {
        envVariables.put(WebSphereStartupPolicy.DEBUG_ENV_VARIABLE, debug + " " + SET_DEBUG_MODE_PORPERTY);
      }

      final CommandLineExecutableObject executableObject = new CommandLineExecutableObject(new String[]{
        scriptFile.getAbsolutePath()
      }, "");
      final OSProcessHandler processHandler = executableObject.createProcessHandler(myProfile.getStartupScriptFile().getParent(), envVariables);
      processHandler.addProcessListener(new ProcessAdapter() {
        public void processTerminated(final ProcessEvent event) {
          scriptFile.delete();
        }
      });
      return processHandler;
    }
    catch (IOException e) {
      throw new ExecutionException(WebSphereBundle.message("error.while.creating.server.start.script.file.text", e.getLocalizedMessage()));
    }
  }

  private static String readLine(final InputStream errorStream) throws IOException {
    final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(errorStream));
    return bufferedReader.readLine();
  }

  private String[] getScriptGenerationCommandLine(final File scriptFile) {
    final String[] base = new String[]{
      myProfile.getStartupScriptFile().getName(),
      myConfiguration.getServerName(),
      GENERATE_SCRIPT_ARG, scriptFile.getName(),
    };
    if (!myProfile.getVersion().isStartingAsServiceImplemented()) {
      return base;
    }
    return ArrayUtil.mergeArrays(base, new String[] {
      FROM_WIN_SERVICE_ARG, scriptFile.getParentFile().getAbsolutePath()
    }, String.class);
  }
}
