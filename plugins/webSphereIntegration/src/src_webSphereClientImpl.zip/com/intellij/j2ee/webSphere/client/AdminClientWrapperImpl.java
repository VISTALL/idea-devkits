/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.client;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.NotificationConstants;
import com.ibm.websphere.management.exception.ConnectorException;
import com.ibm.websphere.management.application.AppManagementProxy;
import com.ibm.websphere.management.application.AppNotification;

import javax.management.*;
import java.util.Set;

/**
 * @author nik
 */
public class AdminClientWrapperImpl implements AdminClientWrapper {
  private AdminClient myAdminClient;
  private boolean myHasAutoUpload;

  public AdminClientWrapperImpl(final AdminClient adminClient, final boolean clientHasAutoUpload) {
    myAdminClient = adminClient;
    myHasAutoUpload = clientHasAutoUpload;
  }

  public AppManagementWrapper createAppManagement() throws Exception {
    return new AppManagementWrapperImpl(myAdminClient, AppManagementProxy.getJMXProxyForClient(myAdminClient), myHasAutoUpload);
  }

  public ServerWrapper createServer(final String cellName, final String nodeName, final String serverName) throws ConnectorExceptionWrapper, JMXExceptionWrapper {
    try {
      final Set set = myAdminClient.queryNames(new ObjectName("*:type=Server,cell=" + cellName + ",node=" + nodeName + ",name=" + serverName + ",*"), null);
      if (set.isEmpty()) return null;
      final ObjectName serverObjectName = (ObjectName)set.iterator().next();
      return new ServerWrapperImpl(myAdminClient, serverObjectName);
    }
    catch (ConnectorException e) {
      throw new ConnectorExceptionWrapper(e);
    }
    catch (MalformedObjectNameException e) {
      throw new JMXExceptionWrapper(e);
    }
  }

  public ApplicationWrapper findApplication(final String appName) throws ConnectorExceptionWrapper, JMXExceptionWrapper {
    try {
      final Set set = myAdminClient.queryNames(new ObjectName("*:type=Application,name=" + appName + ",*"), null);
      if (set.isEmpty()) return null;
      final ObjectName objectName = (ObjectName)set.iterator().next();
      return new ApplicationWrapperImpl(myAdminClient, objectName);
    }
    catch (ConnectorException e) {
      throw new ConnectorExceptionWrapper(e);
    }
    catch (MalformedObjectNameException e) {
      throw new JMXExceptionWrapper(e);
    }
  }

  public void registerNotificationListener(final AppManagementNotificationListener listener) throws ConnectorExceptionWrapper, JMXExceptionWrapper {
    try {
      final Set set = myAdminClient.queryNames(new ObjectName("*:type=AppManagement,*"), null);
      if (set.isEmpty()) return;
      ObjectName appManagement = (ObjectName)set.iterator().next();
      final NotificationFilterSupport filter = new NotificationFilterSupport();
      filter.enableType(NotificationConstants.TYPE_APPMANAGEMENT);
      myAdminClient.addNotificationListener(appManagement, new NotificationListener() {
        public void handleNotification(Notification notification, Object handback) {
          AppNotification appNotification = (AppNotification)notification.getUserData();
          listener.handleNotification(appNotification.taskName, appNotification.taskStatus, appNotification.message, appNotification.props);
        }
      }, filter, null);
    }
    catch (ConnectorException e) {
      throw new ConnectorExceptionWrapper(e);
    }
    catch (JMException e) {
      throw new JMXExceptionWrapper(e);
    }
  }
}
