/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.client;

import com.ibm.websphere.management.exception.ConnectorException;
import com.ibm.websphere.management.AdminClient;

import javax.management.*;

/**
 * @author nik
 */
public abstract class MBeanWrapperImpl {
  private AdminClient myAdminClient;
  private ObjectName myObjectName;

  protected MBeanWrapperImpl(final AdminClient adminClient, final ObjectName objectName) {
    myAdminClient = adminClient;
    myObjectName = objectName;
  }

  protected Object getAttribute(final String name) throws JMXExceptionWrapper, ConnectorExceptionWrapper {
    try {
      return myAdminClient.getAttribute(myObjectName, name);
    }
    catch (MBeanException e) {
      throw new JMXExceptionWrapper(e);
    }
    catch (AttributeNotFoundException e) {
      throw new JMXExceptionWrapper(e);
    }
    catch (InstanceNotFoundException e) {
      throw new JMXExceptionWrapper(e);
    }
    catch (ReflectionException e) {
      throw new JMXExceptionWrapper(e);
    }
    catch (ConnectorException e) {
      throw new ConnectorExceptionWrapper(e);
    }
  }

  public AdminClient getAdminClient() {
    return myAdminClient;
  }

  public ObjectName getObjectName() {
    return myObjectName;
  }
}
