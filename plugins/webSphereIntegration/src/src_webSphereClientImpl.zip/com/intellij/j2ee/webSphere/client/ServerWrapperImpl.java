/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.client;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.exception.ConnectorException;

import javax.management.*;
import java.util.List;
import java.util.ArrayList;

/**
 * @author nik
 */
public class ServerWrapperImpl extends MBeanWrapperImpl implements ServerWrapper {
  private static final String SERVER_STARTED_STATE = "STARTED";

  public ServerWrapperImpl(final AdminClient adminClient, final ObjectName serverObjectName) {
    super(adminClient, serverObjectName);
  }

  public String getState() throws ConnectorExceptionWrapper, JMXExceptionWrapper {
    return (String)getAttribute("state");
  }

  public boolean isStarted() throws ConnectorExceptionWrapper, JMXExceptionWrapper {
    return SERVER_STARTED_STATE.equals(getState());
  }

  public void addListener(final ServerNotificationListener listener) throws JMXExceptionWrapper, ConnectorExceptionWrapper {
    try {
      getAdminClient().addNotificationListener(getObjectName(), new NotificationListener() {
        public void handleNotification(Notification notification, Object handback) {
          listener.handleNotification(notification.getMessage());
        }
      }, null, null);
    }
    catch (InstanceNotFoundException e) {
      throw new JMXExceptionWrapper(e);
    }
    catch (ConnectorException e) {
      throw new ConnectorExceptionWrapper(e);
    }
  }

  public DeployedModuleWrapper[] getDeployedModules() throws ConnectorExceptionWrapper, JMXExceptionWrapper {
    final String[] strings = (String[])getAttribute("deployedObjects");
    List modules = new ArrayList();
    try {
      for (String s : strings) {
        final ObjectName objectName = new ObjectName(s);
        final String type = objectName.getKeyProperty("type");
        if (getAdminClient().isRegistered(objectName)) {
          if ("WebModule".equals(type) || "EJBModule".equals(type)) {
            modules.add(new DeployedModuleWrapperImpl(getAdminClient(), objectName));
          }
        }
      }
    }
    catch (MalformedObjectNameException e) {
      throw new JMXExceptionWrapper(e);
    }
    catch (ConnectorException e) {
      throw new ConnectorExceptionWrapper(e);
    }
    return (DeployedModuleWrapper[])modules.toArray(new DeployedModuleWrapper[modules.size()]);
  }

  public String getNodeName() throws JMXExceptionWrapper, ConnectorExceptionWrapper {
    return (String)getAttribute("nodeName");
  }

  public String getCellName() throws JMXExceptionWrapper, ConnectorExceptionWrapper {
    return (String)getAttribute("cellName");
  }
}
