/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.client;

import com.ibm.websphere.management.application.AppManagement;
import com.ibm.websphere.management.application.AppConstants;
import com.ibm.websphere.management.exception.AdminException;
import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.filetransfer.client.FileTransferClient;
import com.ibm.websphere.management.filetransfer.client.TransferFailedException;
import com.ibm.ws.management.fileservice.FileTransferFactory;

import java.util.Hashtable;
import java.util.List;
import java.io.File;

/**
 * @author nik
 */
public class AppManagementWrapperImpl implements AppManagementWrapper {
  private AdminClient myClient;
  private AppManagement myAppManagement;
  private boolean myHasAutoUpload;

  public AppManagementWrapperImpl(final AdminClient client, final AppManagement appManagement, final boolean hasAutoUpload) {
    myClient = client;
    myAppManagement = appManagement;
    myHasAutoUpload = hasAutoUpload;
  }

  public void installApplication(final String localEarPath, final String appName,
                                 final String cellName, final String nodeName,
                                 final String serverName, final boolean uploadEar, final boolean deployEJBs) throws AdminExceptionWrapper {
    try {
      final Hashtable properties = createProperties(cellName, nodeName, serverName, deployEJBs);
      final String earPath;
      if (myHasAutoUpload || !uploadEar) {
        properties.put(AppConstants.APPDEPL_ARCHIVE_UPLOAD, Boolean.valueOf(uploadEar));
        earPath = localEarPath;
      }
      else {
        properties.put(AppConstants.APPDEPL_DELETE_SRC_EAR, Boolean.TRUE);
        earPath = uploadEar(localEarPath);
      }

      if (checkIfAppExists(appName)) {
        myAppManagement.redeployApplication(earPath, appName, properties, null);
      }
      else {
        myAppManagement.installApplication(earPath, appName, properties, null);
      }
    }
    catch (AdminException e) {
      throw new AdminExceptionWrapper(e);
    }
  }

  private String uploadEar(final String localEarPath) throws AdminException {
    final FileTransferClient fileTransferClient = FileTransferFactory.getFileTransferClient(myClient);
    File ear = new File(localEarPath);
    String fileName = ear.getName();
    try {
      fileTransferClient.uploadFile(ear, fileName);
    }
    catch (TransferFailedException e) {
      throw new AdminException(e);
    }
    return fileTransferClient.getServerStagingLocation() + "/" + fileName;
  }

  private Hashtable createProperties(final String cellName, final String nodeName, final String serverName, final boolean deployEJBs) {
    final Hashtable module2Server = new Hashtable();
    module2Server.put("*", "WebSphere:cell=" + cellName + ",node=" + nodeName + ",server=" + serverName);

    final Hashtable properties = new Hashtable();
    properties.put(AppConstants.APPDEPL_CELL, cellName);
    properties.put(AppConstants.APPDEPL_MODULE_TO_SERVER, module2Server);
    if (deployEJBs) {
      properties.put(AppConstants.APPDEPL_DEPLOYEJB_CMDARG, Boolean.TRUE);
      Hashtable deployOptions = new Hashtable();
      deployOptions.put(AppConstants.APPDEPL_DEPLOYEJB_VALIDATE_OPTION, Boolean.TRUE);
      properties.put(AppConstants.APPDEPL_DEPLOYEJB_OPTIONS, deployOptions);
    }
    return properties;
  }

  public void startApplication(final String appName) throws AdminExceptionWrapper {
    try {
      myAppManagement.startApplication(appName, new Hashtable(), null);
    }
    catch (AdminException e) {
      throw new AdminExceptionWrapper(e);
    }
  }

  public void uninstallApplication(final String appName) throws AdminExceptionWrapper {
    try {
      myAppManagement.uninstallApplication(appName, new Hashtable(), null);
    }
    catch (AdminException e) {
      throw new AdminExceptionWrapper(e);
    }
  }

  public List getApplicationInfo(final String appName) throws AdminExceptionWrapper {
    try {
      return myAppManagement.getApplicationInfo(appName, new Hashtable(), null);
    }
    catch (AdminException e) {
      throw new AdminExceptionWrapper(e);
    }
  }

  public boolean checkIfAppExists(final String appName) throws AdminExceptionWrapper {
    try {
      return myAppManagement.checkIfAppExists(appName, new Hashtable(), null);
    }
    catch (AdminException e) {
      throw new AdminExceptionWrapper(e);
    }
  }
}
