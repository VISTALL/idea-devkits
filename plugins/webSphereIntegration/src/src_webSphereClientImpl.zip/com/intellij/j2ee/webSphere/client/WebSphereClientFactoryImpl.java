/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.webSphere.client;

import com.ibm.websphere.management.AdminClient;
import com.ibm.websphere.management.AdminClientFactory;
import com.ibm.websphere.management.exception.ConnectorException;

import java.security.Security;
import java.util.Properties;

/**
 * @author nik
 */
public class WebSphereClientFactoryImpl implements WebSphereClientFactory {

  public AdminClientWrapper createAdminClient(String host, int port, final boolean clientHasAutoUpload,
                                              String username, String password, String clientTrustFilePath, final boolean useIbmAlgorithm) throws ConnectorExceptionWrapper {
    try {
      final Properties properties = new Properties();
      properties.setProperty(AdminClient.CONNECTOR_TYPE, AdminClient.CONNECTOR_TYPE_SOAP);
      properties.setProperty(AdminClient.CONNECTOR_HOST, host);
      properties.setProperty(AdminClient.CONNECTOR_PORT, String.valueOf(port));
      properties.setProperty(AdminClient.USERNAME, username);
      properties.setProperty(AdminClient.PASSWORD, password);
      if (clientTrustFilePath != null) {
        properties.setProperty(AdminClient.CONNECTOR_SECURITY_ENABLED, Boolean.TRUE.toString());
        properties.setProperty("javax.net.ssl.trustStore", clientTrustFilePath);
        properties.setProperty("javax.net.ssl.trustStorePassword", "WebAS");
        if (useIbmAlgorithm) {
          Security.setProperty("ssl.KeyManagerFactory.algorithm", "IbmX509");
        }
      }
      return new AdminClientWrapperImpl(AdminClientFactory.createAdminClient(properties), clientHasAutoUpload);
    }
    catch (ConnectorException e) {
      throw new ConnectorExceptionWrapper(e);
    }
  }
}
