/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import javax.enterprise.deploy.spi.factories.DeploymentFactory;
import com.fuhrer.idea.glassfish.model.GlassfishAppRoot;
import com.fuhrer.idea.glassfish.model.GlassfishWebModule;
import com.fuhrer.idea.glassfish.model.GlassfishWebRoot;
import com.fuhrer.idea.javaee.server.JavaeeServerImpl;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.model.xml.application.JavaeeModule;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.text.StringUtil;
import com.sun.enterprise.deployapi.SunDeploymentFactory;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

class GlassfishServer extends JavaeeServerImpl {

    @Override
    protected boolean isConnected(String host, int port) {
        try {
            ((HttpURLConnection) new URL("http", host, port, "").openConnection()).getResponseCode();
            return true;
        } catch (IOException e) {
            // ignore...
        }
        return false;
    }

    @Override
    protected DeploymentFactory getDeploymentFactory() {
        return new SunDeploymentFactory();
    }

    @Override
    @NonNls
    protected String getDeployerUrl(String host, int port) {
        return "deployer:Sun:AppServer::" + host + ':' + port;
    }

    @Override
    @Nullable
    @NonNls
    protected String getDeploymentId(DeploymentModel deployment) throws Exception {
        String name = getDeploymentSource(deployment).getName();
        return (name.indexOf('.') > 0) ? name.substring(0, name.lastIndexOf('.')) : name;
    }

    @Override
    @Nullable
    protected String getContextRoot(Module module) {
        GlassfishWebRoot web = GlassfishDescriptors.getWebRoot(module);
        return (web != null) ? web.getContextRoot().getValue() : null;
    }

    @Override
    protected void getContextRoots(Module module, Map<String, String> roots) {
        GlassfishAppRoot app = GlassfishDescriptors.getAppRoot(module);
        if (app != null) {
            for (GlassfishWebModule web : app.getWebs()) {
                JavaeeModule source = web.getWebUri().getValue();
                if ((source != null) && !StringUtil.isEmpty(web.getContextRoot().getValue())) {
                    roots.put(source.getId().getValue(), web.getContextRoot().getValue());
                }
            }
        }
    }
}
