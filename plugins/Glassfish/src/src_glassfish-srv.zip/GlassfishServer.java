/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.enterprise.deploy.spi.TargetModuleID;
import javax.management.MBeanException;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import com.fuhrer.idea.glassfish.GlassfishUtil;
import com.fuhrer.idea.glassfish.model.GlassfishAppRoot;
import com.fuhrer.idea.glassfish.model.GlassfishWebModule;
import com.fuhrer.idea.glassfish.model.GlassfishWebRoot;
import com.fuhrer.idea.javaee.server.JavaeeServer;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentStatus;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.model.xml.application.JavaeeModule;
import com.intellij.openapi.util.text.StringUtil;
import com.sun.enterprise.deployment.client.DeploymentFacility;
import com.sun.enterprise.deployment.client.DeploymentFacilityFactory;
import com.sun.enterprise.deployment.client.ServerConnectionIdentifier;
import com.sun.enterprise.deployment.deploy.shared.AbstractArchive;
import com.sun.enterprise.deployment.deploy.shared.ArchiveFactory;
import com.sun.enterprise.deployment.util.DeploymentProperties;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class GlassfishServer extends JavaeeServer {

    @NonNls
    private static final String SERVER = "amx:j2eeType=J2EEServer,name=server";

    @NonNls
    private static final String[] TARGETS = {"server"};

    @NonNls
    private MBeanServerConnection server;

    @Override
    protected boolean isConnected() throws Exception {
        try {
            return getServer().getAttribute(new ObjectName(SERVER), "state") instanceof Integer;
        } catch (MBeanException e) {
            throw e.getTargetException();
        }
    }

    @Override
    @NotNull
    protected DeploymentStatus handleDeployment(DeploymentModel deployment, File source, boolean deploy, boolean undeploy) throws Exception {
        DeploymentFacility facility = getDeploymentFacility();
        try {
            String name = source.getName();
            if (name.indexOf('.') > 0) {
                name = name.substring(0, name.lastIndexOf('.'));
            }
            if (undeploy && !deploy) {
                facility.waitFor(facility.undeploy(facility.createTargets(TARGETS), name));
            }
            if (deploy) {
                @NonNls String prefix = (source.isDirectory()) ? "file" : "jar";
                URI uri = new URI(prefix, "", source.toURI().getSchemeSpecificPart(), null, null);
                AbstractArchive archive = new ArchiveFactory().openArchive(uri);
                Properties options = new Properties();
                options.setProperty(DeploymentProperties.TARGET, TARGETS[0]);
                options.setProperty(DeploymentProperties.ARCHIVE_NAME, source.getAbsolutePath());
                options.setProperty(DeploymentProperties.NAME, name);
                facility.waitFor(facility.deploy(facility.createTargets(TARGETS), archive, null, options));
            }
            return getDeploymentStatus(facility, name);
        } finally {
            facility.disconnect();
        }
    }

    @Override
    @Nullable
    protected String getContextRoot(JavaeeFacet facet) {
        GlassfishWebRoot web = GlassfishUtil.getWebRoot(facet);
        return (web != null) ? web.getContextRoot().getValue() : null;
    }

    @Override
    protected void getContextRoots(JavaeeFacet facet, Map<String, String> roots) {
        GlassfishAppRoot app = GlassfishUtil.getAppRoot(facet);
        if (app != null) {
            for (GlassfishWebModule web : app.getWebs()) {
                JavaeeModule source = web.getWebUri().getValue();
                if ((source != null) && !StringUtil.isEmpty(web.getContextRoot().getValue())) {
                    roots.put(source.getId().getValue(), web.getContextRoot().getValue());
                }
            }
        }
    }

    @Override
    protected boolean isStartupScriptTerminating() {
        return true;
    }

    @SuppressWarnings({"CallToNativeMethodWhileLocked"})
    private synchronized MBeanServerConnection getServer() throws IOException {
        if (server == null) {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            try {
                Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
                @NonNls JMXServiceURL url = new JMXServiceURL("s1ashttp", getHost(), getPort());
                @NonNls Map<String, Object> env = new HashMap<String, Object>();
                env.put(JMXConnector.CREDENTIALS, new String[]{getUsername(), getPassword()});
                env.put("com.sun.enterprise.as.http.auth", "BASIC");
                env.put("USER", getUsername());
                env.put("PASSWORD", getPassword());
                env.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES, "com.sun.enterprise.admin.jmx.remote.protocol");
                server = JMXConnectorFactory.connect(url, env).getMBeanServerConnection();
            } finally {
                Thread.currentThread().setContextClassLoader(loader);
            }
        }
        return server;
    }

    private DeploymentFacility getDeploymentFacility() {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        try {
            Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
            DeploymentFacility facility = DeploymentFacilityFactory.getDeploymentFacility();
            ServerConnectionIdentifier identifier = new ServerConnectionIdentifier();
            identifier.setHostName(getHost());
            identifier.setHostPort(getPort());
            identifier.setUserName(getUsername());
            identifier.setPassword(getPassword());
            identifier.setSecure(false); // todo: should we support secure connections?
            facility.connect(identifier);
            return facility;
        } finally {
            Thread.currentThread().setContextClassLoader(loader);
        }
    }

    private DeploymentStatus getDeploymentStatus(DeploymentFacility facility, String name) {
        DeploymentStatus status = DeploymentStatus.NOT_DEPLOYED;
        try {
            TargetModuleID[] modules = facility.listAppRefs(TARGETS);
            for (TargetModuleID module : modules) {
                if (name.equals(module.getModuleID())) {
                    status = DeploymentStatus.DEPLOYED;
                }
            }
        } catch (IOException e) {
            status = DeploymentStatus.UNKNOWN;
        }
        return status;
    }
}
