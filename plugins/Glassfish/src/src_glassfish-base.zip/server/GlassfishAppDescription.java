/*
 * Copyright (c) 2007 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import com.fuhrer.idea.glassfish.model.GlassfishAppRoot;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptorType;
import com.fuhrer.idea.javaee.descriptor.JavaeeFileDescription;

class GlassfishAppDescription extends JavaeeFileDescription<GlassfishAppRoot> {

    GlassfishAppDescription() {
        super(GlassfishAppRoot.class, JavaeeDescriptorType.APP);
    }
}
