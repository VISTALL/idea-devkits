/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import java.io.File;
import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import com.fuhrer.idea.glassfish.GlassfishBundle;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptorType;
import com.fuhrer.idea.javaee.server.JavaeeFile;
import com.fuhrer.idea.javaee.server.JavaeeInspection;
import com.fuhrer.idea.javaee.server.JavaeeIntegration;
import com.fuhrer.idea.javaee.util.IconLoader;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class GlassfishIntegration extends JavaeeIntegration {

    @Override
    @NotNull
    public String getName() {
        return GlassfishBundle.get("GlassfishIntegration.name");
    }

    @Override
    @NotNull
    public Icon getIcon() {
        return IconLoader.get("/resources/glassfish.png");
    }

    @Override
    @NotNull
    public Icon getBigIcon() {
        return IconLoader.get("/resources/glassfishbig.png");
    }

    @Override
    @NotNull
    @NonNls
    protected String getResourceUri(JavaeeFile file) {
        return "http://www.sun.com/software/dtd/appserver/" + file.getName();
    }

    @Override
    @Nullable
    @NonNls
    protected String getNameFromTemplate(String template) {
        return template.split("_")[0];
    }

    @Override
    @Nullable
    @NonNls
    protected String getVersionFromTemplate(String template) {
        return template.replaceAll("[\\w-]+_(\\d)_(\\d(-\\d)?)\\.xml", "$1.$2").replace('-', '.');
    }

    @Override
    protected void registerDescriptorTypes(Map<String, JavaeeDescriptorType> types) {
        types.put("sun-application.xml", JavaeeDescriptorType.APP);
        types.put("sun-ejb-jar.xml", JavaeeDescriptorType.EJB);
        types.put("sun-cmp-mapping.xml", JavaeeDescriptorType.CMP);
        types.put("sun-web.xml", JavaeeDescriptorType.WEB);
    }

    @Override
    @NotNull
    protected String getServerVersion(String home) throws Exception {
        URL url = new File(home, "lib/appserv-rt.jar").toURI().toURL();
        ClassLoader loader = new URLClassLoader(new URL[]{url}, getClass().getClassLoader());
        Class<?> type = loader.loadClass("com.sun.appserv.server.util.Version");
        Field field = type.getDeclaredField("full_version");
        field.setAccessible(true);
        return (String) field.get(null);
    }

    @Override
    protected void checkValidServerHome(String home) throws Exception {
        checkFile(home, "lib/appserv-deployment-client.jar");
        checkFile(home, "lib/appserv-ext.jar");
    }

    @Override
    protected void addLibraryLocations(String home, List<File> locations) {
        locations.add(new File(home, "lib"));
    }

    @Override
    @NotNull
    protected Class<? extends JavaeeInspection> getInspectionClass() {
        return GlassfishInspection.class;
    }
}
