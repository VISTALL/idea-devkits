/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import com.fuhrer.idea.glassfish.model.GlassfishAppRoot;
import com.fuhrer.idea.glassfish.model.GlassfishCmpRoot;
import com.fuhrer.idea.glassfish.model.GlassfishEjbRoot;
import com.fuhrer.idea.glassfish.model.GlassfishWebRoot;
import com.fuhrer.idea.javaee.server.JavaeeInspection;

class GlassfishInspection extends JavaeeInspection {

    @SuppressWarnings({"unchecked"})
    GlassfishInspection() {
        super(GlassfishAppRoot.class, GlassfishEjbRoot.class, GlassfishCmpRoot.class, GlassfishWebRoot.class);
    }
}
