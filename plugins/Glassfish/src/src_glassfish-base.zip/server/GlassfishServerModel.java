/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import java.io.File;
import java.util.List;
import com.fuhrer.idea.glassfish.model.GlassfishAppRoot;
import com.fuhrer.idea.glassfish.model.GlassfishWebModule;
import com.fuhrer.idea.glassfish.model.GlassfishWebRoot;
import com.fuhrer.idea.javaee.server.JavaeeServerModel;
import com.intellij.javaee.deployment.DeploymentSource;
import org.jetbrains.annotations.NonNls;

abstract class GlassfishServerModel extends JavaeeServerModel {

    @Override
    @NonNls
    protected String getDefaultUsername() {
        return "admin";
    }

    @Override
    @NonNls
    protected String getDefaultPassword() {
        return "adminadmin";
    }

    @Override
    @NonNls
    protected String getServerName() {
        return "com.fuhrer.idea.glassfish.server.GlassfishServer";
    }

    @Override
    protected boolean isDeploymentSourceSupported(DeploymentSource source) {
        return DeploymentSource.FROM_JAR.equals(source);
    }

    @Override
    protected List<File> getLibraries() {
        List<File> libraries = super.getLibraries();
        libraries.add(new File(getHome(), "lib/appserv-deployment-client.jar"));
        libraries.add(new File(getHome(), "lib/appserv-ext.jar"));
        return libraries;
    }

    @Override
    protected List<String> getExcludes() {
        List<String> excludes = super.getExcludes();
        excludes.add(GlassfishDescriptors.class.getName());
        excludes.add(GlassfishAppRoot.class.getName());
        excludes.add(GlassfishWebRoot.class.getName());
        excludes.add(GlassfishWebModule.class.getName());
        return excludes;
    }
}
