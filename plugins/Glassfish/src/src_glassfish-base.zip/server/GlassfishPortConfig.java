/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import java.io.File;
import com.fuhrer.idea.javaee.server.JavaeePortConfig;
import com.fuhrer.idea.javaee.server.JavaeeServerModel;
import com.intellij.openapi.util.JDOMUtil;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

class GlassfishPortConfig extends JavaeePortConfig {

    private static final Factory<GlassfishLocalModel> LOCAL = factory("http-listener-1");

    private static final Factory<GlassfishLocalModel> ADMIN = factory("admin-listener");

    private final File file;

    private final String id;

    private GlassfishPortConfig(String home, String domain, String id) {
        file = new File(new File(new File(home, "domains"), domain), "config/domain.xml");
        this.id = id;
    }

    @Override
    protected long getStamp(JavaeeServerModel model) {
        return getStamp(file);
    }

    @Override
    protected int findPort(JavaeeServerModel model) {
        if (file.exists()) {
            try {
                Element root = JDOMUtil.loadDocument(file).getRootElement();
                @NonNls Element cfg = findElement(root.getChild("configs"), "config", "name", "server-config");
                if (cfg != null) {
                    @NonNls Element listener = findElement(cfg.getChild("http-service"), "http-listener", "id", id);
                    if (listener != null) {
                        return Integer.parseInt(listener.getAttributeValue("port"));
                    }
                }
            } catch (Exception ignore) {
            }
        }
        return 0;
    }

    static int getLocal(GlassfishLocalModel model) {
        return get(LOCAL, model, model.getDefaultPort());
    }

    static int getAdmin(GlassfishLocalModel model) {
        return get(ADMIN, model, 0);
    }

    private static Factory<GlassfishLocalModel> factory(@NonNls final String id) {
        return new Factory<GlassfishLocalModel>() {
            @NotNull
            public Key createKey(GlassfishLocalModel model) {
                return new Key(model.getHome(), model.DOMAIN, id);
            }

            @NotNull
            public JavaeePortConfig createConfig(GlassfishLocalModel model) {
                return new GlassfishPortConfig(model.getHome(), model.DOMAIN, id);
            }
        };
    }
}
