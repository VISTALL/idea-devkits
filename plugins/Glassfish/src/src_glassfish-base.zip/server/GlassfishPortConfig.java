/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import java.io.File;
import com.fuhrer.idea.javaee.server.JavaeePortConfig;
import com.intellij.openapi.util.JDOMUtil;
import org.jdom.Document;
import org.jdom.Element;

class GlassfishPortConfig extends JavaeePortConfig {

    private final File config;

    GlassfishPortConfig(String home, String domain) {
        config = new File(new File(new File(home, "domains"), domain), "config/domain.xml");
    }

    @Override
    protected long getStamp() {
        return getStamp(config);
    }

    @Override
    protected int findPort() {
        try {
            Document doc = JDOMUtil.loadDocument(config);
            Element cfg = findElement(doc.getRootElement().getChild("configs"), "config", "name", "server-config");
            if (cfg != null) {
                Element listener = findElement(cfg.getChild("http-service"), "http-listener", "id", "admin-listener");
                if (listener != null) {
                    return Integer.parseInt(listener.getAttributeValue("port"));
                }
            }
        } catch (Exception e) {
            // ignore...
        }
        return 0;
    }
}
