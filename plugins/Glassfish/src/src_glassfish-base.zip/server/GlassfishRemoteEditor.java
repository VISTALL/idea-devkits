/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import javax.swing.*;
import com.fuhrer.idea.javaee.server.JavaeeRunSettingsEditor;
import com.intellij.openapi.options.ConfigurationException;
import org.jetbrains.annotations.NotNull;

class GlassfishRemoteEditor extends JavaeeRunSettingsEditor<GlassfishRemoteModel> {

    private JPanel panel;

    private JTextField port;

    @Override
    @NotNull
    protected JComponent createAdditionalEditor() {
        return panel;
    }

    @Override
    protected void resetEditorFrom(GlassfishRemoteModel model) {
        super.resetEditorFrom(model);
        port.setText(String.valueOf(model.ADMIN_PORT));
    }

    @Override
    protected void applyEditorTo(GlassfishRemoteModel model) throws ConfigurationException {
        super.applyEditorTo(model);
        try {
            model.ADMIN_PORT = Integer.parseInt(port.getText());
        } catch (Exception e) {
            model.ADMIN_PORT = 0;
        }
    }
}
