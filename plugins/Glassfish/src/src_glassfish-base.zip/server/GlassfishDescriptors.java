/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import com.fuhrer.idea.glassfish.model.GlassfishAppRoot;
import com.fuhrer.idea.glassfish.model.GlassfishCmpRoot;
import com.fuhrer.idea.glassfish.model.GlassfishEjbRoot;
import com.fuhrer.idea.glassfish.model.GlassfishWebRoot;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptorType;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptors;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.module.Module;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

public class GlassfishDescriptors extends JavaeeDescriptors {

    GlassfishDescriptors(Project project) {
        super(project);
    }

    @Nullable
    public static GlassfishAppRoot getAppRoot(@Nullable Module module) {
        return (module != null) ? getInstance(module).getAppRoot(module, GlassfishAppRoot.class) : null;
    }

    @Nullable
    public static GlassfishEjbRoot getEjbRoot(@Nullable Module module) {
        return (module != null) ? getInstance(module).getEjbRoot(module, GlassfishEjbRoot.class) : null;
    }

    @Nullable
    public static GlassfishCmpRoot getCmpRoot(@Nullable Module module) {
        return (module != null) ? getInstance(module).getCmpRoot(module, GlassfishCmpRoot.class) : null;
    }

    @Nullable
    public static GlassfishWebRoot getWebRoot(@Nullable Module module) {
        return (module != null) ? getInstance(module).getWebRoot(module, GlassfishWebRoot.class) : null;
    }

    @NotNull
    private static GlassfishDescriptors getInstance(@NotNull Module module) {
        return module.getProject().getComponent(GlassfishDescriptors.class);
    }

    @Override
    protected void registerFileDescriptions() {
        register(GlassfishAppRoot.class, JavaeeDescriptorType.APP);
        register(GlassfishEjbRoot.class, JavaeeDescriptorType.EJB);
        register(GlassfishCmpRoot.class, JavaeeDescriptorType.CMP);
        register(GlassfishWebRoot.class, JavaeeDescriptorType.WEB);
    }
}
