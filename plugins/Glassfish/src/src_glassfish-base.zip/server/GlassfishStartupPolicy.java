/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import java.io.File;
import com.fuhrer.idea.javaee.server.JavaeeParameters;
import com.fuhrer.idea.javaee.server.JavaeeStartupPolicy;
import com.intellij.openapi.util.SystemInfo;
import org.jetbrains.annotations.NonNls;

class GlassfishStartupPolicy extends JavaeeStartupPolicy<GlassfishLocalModel> {

    @Override
    protected void getStartupParameters(JavaeeParameters params, GlassfishLocalModel model) {
        params.add(getScript(model));
        params.add("start-domain", model.DOMAIN);
    }

    @Override
    protected void getShutdownParameters(JavaeeParameters params, GlassfishLocalModel model) {
        params.add(getScript(model));
        params.add("stop-domain", model.DOMAIN);
    }

    @NonNls
    private File getScript(GlassfishLocalModel model) {
        File bin = new File(model.getHome(), "bin");
        @NonNls String script = SystemInfo.isWindows ? "asadmin.bat" : "asadmin";
        return new File(bin, script);
    }
}
