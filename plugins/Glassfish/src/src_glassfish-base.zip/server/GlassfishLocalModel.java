/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import java.util.HashMap;
import java.util.Map;
import com.fuhrer.idea.glassfish.GlassfishBundle;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.text.StringUtil;

class GlassfishLocalModel extends GlassfishServerModel {

    private static final Map<Pair<String, String>, GlassfishPortConfig> config = new HashMap<Pair<String, String>, GlassfishPortConfig>();

    @SuppressWarnings({"PublicField", "InstanceVariableNamingConvention", "NonConstantFieldWithUpperCaseName"})
    public String DOMAIN = "";

    public SettingsEditor<CommonModel> getEditor() {
        return new GlassfishLocalEditor();
    }

    @Override
    public void checkConfiguration() throws RuntimeConfigurationException {
        if (StringUtil.isEmpty(DOMAIN)) {
            throw new RuntimeConfigurationException(GlassfishBundle.get("GlassfishLocalModel.error.missing"));
        }
        if (getServerPort() <= 0) {
            throw new RuntimeConfigurationException(GlassfishBundle.get("GlassfishLocalModel.error.invalid"));
        }
    }

    @Override
    protected int getServerPort() {
        int port = 0;
        String home = getHome();
        if (StringUtil.isNotEmpty(home) && StringUtil.isNotEmpty(DOMAIN)) {
            Pair<String, String> key = new Pair<String, String>(home, DOMAIN);
            GlassfishPortConfig entry = config.get(key);
            if (entry == null) {
                entry = new GlassfishPortConfig(home, DOMAIN);
                config.put(key, entry);
            }
            port = entry.getPort();
        }
        return port;
    }
}
