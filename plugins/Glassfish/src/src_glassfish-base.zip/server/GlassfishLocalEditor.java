/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.server;

import java.io.File;
import javax.swing.*;
import com.intellij.openapi.options.ConfigurationException;
import com.fuhrer.idea.javaee.server.JavaeeRunSettingsEditor;
import org.jetbrains.annotations.NotNull;

class GlassfishLocalEditor extends JavaeeRunSettingsEditor<GlassfishLocalModel> {

    private JPanel panel;

    private JComboBox domain;

    @Override
    @NotNull
    protected JComponent createAdditionalEditor() {
        return panel;
    }

    @Override
    protected void resetEditorFrom(GlassfishLocalModel model) {
        super.resetEditorFrom(model);
        domain.removeAllItems();
        File[] files = new File(model.getHome(), "domains").listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    domain.addItem(file.getName());
                }
            }
        }
        domain.setSelectedItem(null);
        domain.setSelectedItem(model.DOMAIN);
    }

    @Override
    protected void applyEditorTo(GlassfishLocalModel model) throws ConfigurationException {
        super.applyEditorTo(model);
        model.DOMAIN = (String) domain.getSelectedItem();
    }
}
