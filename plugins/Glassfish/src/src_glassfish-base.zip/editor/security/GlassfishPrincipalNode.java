/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.editor.security;

import javax.swing.*;
import com.fuhrer.idea.glassfish.model.GlassfishPrincipal;
import com.fuhrer.idea.javaee.util.IconLoader;
import com.intellij.javaee.module.view.nodes.JavaeeObjectDescriptor;

class GlassfishPrincipalNode extends JavaeeObjectDescriptor<GlassfishPrincipal> {

    GlassfishPrincipalNode(GlassfishSecurityRoleNode parent, GlassfishPrincipal element) {
        super(element, parent, null);
    }

    @Override
    protected String getNewNodeText() {
        return getElement().getValue();
    }

    @Override
    protected Icon getNewOpenIcon() {
        return IconLoader.get("/fileTypes/custom.png");
    }

    @Override
    protected Icon getNewClosedIcon() {
        return getNewOpenIcon();
    }
}
