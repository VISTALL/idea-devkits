/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.editor;

import com.fuhrer.idea.glassfish.model.GlassfishWebRoot;
import com.fuhrer.idea.glassfish.server.GlassfishDescriptors;
import com.fuhrer.idea.javaee.editor.JavaeeEditorProvider;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.util.xml.ui.PerspectiveFileEditor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class GlassfishEditorProvider extends JavaeeEditorProvider {

    @Override
    public double getWeight() {
        return 102;
    }

    //@Override
    //protected boolean acceptAppRoot(@NotNull JavaeeModuleProperties properties, @NotNull JavaeeApplicationModel model) {
    //    return getAppRoot(properties.getModule()) != null;
    //}

    //@Override
    //protected boolean acceptEjbRoot(@NotNull JavaeeModuleProperties properties, @NotNull EjbModuleProperties model) {
    //    return getEjbRoot(properties.getModule()) != null;
    //}

    @Override
    protected boolean acceptWebRoot(@NotNull JavaeeModuleProperties properties, @NotNull WebModuleProperties model) {
        return GlassfishDescriptors.getWebRoot(properties.getModule()) != null;
    }

    //@Override
    //protected boolean acceptEntityBean(@NotNull EntityBean bean) {
    //    return (getEjbRoot(bean.getModule()) != null) && (getCmpRoot(bean.getModule()) != null);
    //}

    //@Override
    //protected boolean acceptSessionBean(@NotNull SessionBean bean) {
    //    return getEjbRoot(bean.getModule()) != null;
    //}

    //@Override
    //protected boolean acceptMessageBean(@NotNull MessageDrivenBean bean) {
    //    return getEjbRoot(bean.getModule()) != null;
    //}

    //@Override
    //@Nullable
    //protected PerspectiveFileEditor createAppRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeModuleProperties properties, @NotNull JavaeeApplicationModel model) {
    //    GlassfishAppRoot root = getAppRoot(properties.getModule());
    //    return createEditor(root, new GlassfishAppRootEditor(model.getRoot(), root));
    //}

    @Override
    @Nullable
    protected PerspectiveFileEditor createWebRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeModuleProperties properties, @NotNull WebModuleProperties model) {
        GlassfishWebRoot root = GlassfishDescriptors.getWebRoot(properties.getModule());
        return (root != null) ? createEditor(root, new GlassfishWebRootEditor(model.getRoot(), root)) : null;
    }
}
