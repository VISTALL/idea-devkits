/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.editor;

import com.fuhrer.idea.glassfish.GlassfishUtil;
import com.fuhrer.idea.glassfish.model.GlassfishWebRoot;
import com.fuhrer.idea.javaee.editor.JavaeeEditorProvider;
import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.xml.ui.PerspectiveFileEditor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class GlassfishEditorProvider extends JavaeeEditorProvider {

    @Override
    public double getWeight() {
        return 102;
    }

    @Override
    protected boolean acceptWebRoot(@NotNull WebFacet facet) {
        return GlassfishUtil.getWebRoot(facet) != null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createWebRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull WebFacet facet) {
        GlassfishWebRoot root = GlassfishUtil.getWebRoot(facet);
        return (root != null) ? createEditor(root, new GlassfishWebRootEditor(facet.getRoot(), root)) : null;
    }
}
