/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.model;

import java.util.List;
import com.intellij.javaee.model.xml.JavaeeDomModelElement;

@SuppressWarnings({"InterfaceNeverImplemented"})
public interface GlassfishSecurityRoleHolder extends JavaeeDomModelElement {

    List<GlassfishSecurityRole> getSecurityRoleMappings();

    GlassfishSecurityRole addSecurityRoleMapping();
}
