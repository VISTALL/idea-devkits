/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.glassfish.model;

import java.util.List;
import com.fuhrer.idea.javaee.converter.SecurityRoleConverter;
import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.javaee.model.xml.SecurityRole;
import com.intellij.util.xml.Convert;
import com.intellij.util.xml.GenericDomValue;

@SuppressWarnings({"InterfaceNeverImplemented"})
public interface GlassfishSecurityRole extends JavaeeDomModelElement {

    @Convert(value = SecurityRoleConverter.class)
    GenericDomValue<SecurityRole> getRoleName();

    List<GlassfishPrincipal> getPrincipalNames();

    GlassfishPrincipal addPrincipalName();
}
