/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import com.intellij.openapi.util.JDOMUtil;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.util.PathUtil;
import com.fuhrer.idea.javaee.server.JavaeeLogger;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class JavaeePlugin {

    private static final JavaeePlugin instance = new JavaeePlugin();

    @NonNls
    private final String id;

    private JavaeePlugin() {
        Element element = loadPluginDescriptor();
        if (element == null) {
            id = "<unknown>";
        } else if (StringUtil.isEmpty(element.getChildTextTrim("id"))) {
            id = element.getChildTextTrim("name");
        } else {
            id = element.getChildTextTrim("id");
        }
    }

    public static JavaeePlugin getInstance() {
        return instance;
    }

    public String getId() {
        return id;
    }

    @Nullable
    private static Element loadPluginDescriptor() {
        try {
            Document document = null;
            File base = getPluginBase();
            if (!base.isDirectory()) {
                document = getFromJar(base);
            } else if (new File(base, "META-INF/plugin.xml").exists()) {
                document = getFromFile(new File(base, "META-INF/plugin.xml"));
            } else if (new File(base, "lib").isDirectory()) {
                document = getFromDir(new File(base, "lib"));
            }
            if (document != null) {
                return document.getRootElement();
            }
        } catch (Exception e) {
            // ignore...
        }
        return null;
    }

    @NotNull
    private static File getPluginBase() {
        File base = new File(PathUtil.getJarPathForClass(JavaeeLogger.class));
        if (base.isDirectory()) {
            base = base.getParentFile();
        } else if ("lib".equals(base.getParentFile().getName())) {
            base = base.getParentFile().getParentFile();
        }
        return base;
    }

    @Nullable
    private static Document getFromJar(File file) throws IOException, JDOMException {
        Document document = null;
        ZipFile zip = new ZipFile(file);
        ZipEntry entry = zip.getEntry("META-INF/plugin.xml");
        if (entry != null) {
            InputStream in = zip.getInputStream(entry);
            document = JDOMUtil.loadDocument(in);
            in.close();
        }
        zip.close();
        return document;
    }

    @Nullable
    private static Document getFromFile(File file) throws IOException, JDOMException {
        return JDOMUtil.loadDocument(file);
    }

    @Nullable
    private static Document getFromDir(File dir) throws IOException, JDOMException {
        for (File file : dir.listFiles()) {
            if (file.getName().endsWith(".jar") || file.getName().endsWith(".zip")) {
                Document document = getFromJar(file);
                if (document != null) {
                    return document;
                }
            }
        }
        return null;
    }
}
