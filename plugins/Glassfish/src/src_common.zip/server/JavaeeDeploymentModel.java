/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentSource;
import com.intellij.javaee.run.configuration.CommonModel;

class JavaeeDeploymentModel extends DeploymentModel {

    JavaeeDeploymentModel(CommonModel config, JavaeeModuleProperties properties) {
        super(config, properties);
    }

    @Override
    public boolean isDeploymentSourceSupported(DeploymentSource source) {
        return ((JavaeeServerModel) getCommonModel().getServerModel()).isDeploymentSourceSupported(source);
    }
}
