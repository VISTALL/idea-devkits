/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.fuhrer.idea.javaee.JavaeeBundle;
import com.intellij.debugger.DebuggerManager;
import com.intellij.debugger.PositionManager;
import com.intellij.debugger.engine.DebugProcess;
import com.intellij.debugger.engine.DebugProcessAdapter;
import com.intellij.debugger.engine.DefaultJSPPositionManager;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.execution.process.ProcessOutputTypes;
import com.intellij.javaee.deployment.DeploymentManager;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentStatus;
import com.intellij.javaee.model.JavaeeApplicationModel;
import com.intellij.javaee.model.xml.application.JavaeeApplication;
import com.intellij.javaee.model.xml.application.JavaeeModule;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.serverInstances.DefaultJ2EEServerEvent;
import com.intellij.javaee.serverInstances.DefaultServerInstance;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleType;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.application.ApplicationManager;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

class JavaeeServerInstance extends DefaultServerInstance {

    private final Map<String, String> roots = new HashMap<String, String>();

    @NotNull
    private final JavaeeServer server;

    private boolean connected;

    protected JavaeeServerInstance(@NotNull CommonModel config, @NotNull JavaeeServer server) {
        super(config);
        this.server = server;
    }

    @Override
    public void start(ProcessHandler handler) {
        super.start(handler);
        DebuggerManager.getInstance(getCommonModel().getProject()).addDebugProcessListener(handler, new DebugProcessAdapter() {
            @Override
            public void processAttached(DebugProcess process) {
                process.appendPositionManager(createPositionManager(process));
            }
        });
    }

    @Override
    public boolean connect() throws Exception {
        return isConnected(true);
    }

    @Override
    public boolean isConnected() {
        return isConnected(false);
    }

    @Override
    public void shutdown() {
    }

    @Override
    public void registerServerError(Throwable t) {
        ByteArrayOutputStream text = new ByteArrayOutputStream();
        t.printStackTrace(new PrintStream(text));
        getProcessHandler().notifyTextAvailable(text.toString(), ProcessOutputTypes.STDERR);
    }

    void deploy(final DeploymentModel deployment) {
        if (isConnected() && checkDeploymentSource(deployment)) {
            execute("JavaeeDeployThread", new Runnable() {
                public void run() {
                    try {
                        setDeploymentStatus(deployment, DeploymentStatus.ACTIVATING);
                        setDeploymentStatus(deployment, server.handleDeployment(deployment, true, true));
                    } catch (Throwable t) {
                        registerServerError(t);
                        setDeploymentStatus(deployment, DeploymentStatus.FAILED);
                    }
                }
            });
        }
    }

    void undeploy(final DeploymentModel deployment) {
        if (isConnected() && checkDeploymentSource(deployment)) {
            execute("JavaeeUndeployThread", new Runnable() {
                public void run() {
                    try {
                        setDeploymentStatus(deployment, DeploymentStatus.DEACTIVATING);
                        setDeploymentStatus(deployment, server.handleDeployment(deployment, false, true));
                    } catch (Throwable t) {
                        registerServerError(t);
                        setDeploymentStatus(deployment, DeploymentStatus.UNKNOWN);
                    }
                }
            });
        }
    }

    void updateDeploymentStatus(DeploymentModel deployment) {
        if (isConnected() && checkDeploymentSource(deployment)) {
            try {
                setDeploymentStatus(deployment, server.handleDeployment(deployment, false, false));
            } catch (Throwable t) {
                registerServerError(t);
                setDeploymentStatus(deployment, DeploymentStatus.UNKNOWN);
            }
        }
    }

    String getContextRoot(DeploymentModel deployment) {
        return roots.get(deployment.MODULE_NAME);
    }

    private PositionManager createPositionManager(DebugProcess process) {
        return new DefaultJSPPositionManager(process, getScopeModulesWithIncluded(getCommonModel())) {
            @Override
            @NonNls
            protected String getGeneratedClassesPackage() {
                return "org.apache.jsp";
            }
        };
    }

    private boolean isConnected(boolean force) {
        if (force || !EventQueue.isDispatchThread()) {
            boolean previous = connected;
            try {
                connected = server.isConnected();
            } catch (Exception e) {
                connected = false;
            }
            if (connected && !previous) {
                fireServerListeners(new DefaultJ2EEServerEvent(true, false));
            } else if (!connected && previous) {
                fireServerListeners(new DefaultJ2EEServerEvent(false, true));
            }
        }
        return connected;
    }

    private boolean checkDeploymentSource(DeploymentModel deployment) {
        boolean success = true;
        if (DeploymentManager.getInstance(getCommonModel().getProject()).getDeploymentSource(deployment) == null) {
            String text = JavaeeBundle.get("ServerInstance.nosource", deployment.MODULE_NAME);
            getProcessHandler().notifyTextAvailable(text, ProcessOutputTypes.STDERR);
            setDeploymentStatus(deployment, DeploymentStatus.FAILED);
            success = false;
        }
        return success;
    }

    private void setDeploymentStatus(final DeploymentModel deployment, final DeploymentStatus status) {
        DeploymentManager manager = DeploymentManager.getInstance(getCommonModel().getProject());
        manager.setDeploymentStatus(deployment.getModuleProperties(), status, getCommonModel(), this);
        String text = JavaeeBundle.get("ServerInstance.status", new Date(), deployment.MODULE_NAME, status.getDescription());
        getProcessHandler().notifyTextAvailable(text, ProcessOutputTypes.SYSTEM);
        ApplicationManager.getApplication().runReadAction(new Runnable() {
            public void run() {
                setContextRoot(deployment, DeploymentStatus.DEPLOYED.equals(status));
            }
        });
    }

    @SuppressWarnings({"CastToIncompatibleInterface"})
    private void setContextRoot(DeploymentModel deployment, boolean deployed) {
        Module module = deployment.getModuleProperties().getModule();
        if (ModuleType.J2EE_APPLICATION.equals(module.getModuleType())) {
            setContextRoot(((JavaeeApplicationModel) deployment.getModuleProperties()).getRoot(), deployed);
        } else if (ModuleType.WEB.equals(module.getModuleType())) {
            setContextRoot(module.getName(), deployment, deployed);
        }
    }

    private void setContextRoot(JavaeeApplication application, boolean deployed) {
        if (application != null) {
            for (JavaeeModule module : application.getModules()) {
                if (module.getWeb().getXmlTag() != null) {
                    if (deployed) {
                        roots.put(module.getId().getValue(), module.getWeb().getContextRoot().getValue());
                        server.getContextRoots(application.getModule(), roots);
                    } else {
                        roots.remove(module.getId().getValue());
                    }
                }
            }
        }
    }

    private void setContextRoot(String name, DeploymentModel deployment, boolean deployed) {
        if (deployed) {
            String root = server.getContextRoot(deployment.getModuleProperties().getModule());
            if (root == null) {
                root = StringUtil.trimEnd(server.getDeploymentSource(deployment).getName(), ".war");
            }
            roots.put(name, root);
        } else {
            roots.remove(name);
        }
    }

    private void execute(@NonNls String name, Runnable target) {
        Thread thread = new Thread(target, name);
        thread.setPriority(Thread.NORM_PRIORITY);
        thread.start();
    }
}
