/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.zip.ZipFile;
import com.fuhrer.idea.javaee.JavaeeBundle;
import com.intellij.javaee.appServerIntegrations.*;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import org.jetbrains.annotations.NonNls;

class JavaeeServerHelper implements ApplicationServerHelper {

    @NonNls
    private static final String[] CLASSES = {
            "javax/servlet/Servlet.class",
            "javax/servlet/jsp/JspPage.class",
            "javax/ejb/EntityBean.class"
    };

    public ApplicationServerPersistentDataEditor<JavaeePersistentData> createConfigurable() {
        return new JavaeePersistentDataEditor();
    }

    public ApplicationServerPersistentData createPersistentDataEmptyInstance() {
        return new JavaeePersistentData();
    }

    @SuppressWarnings({"unchecked"})
    public ApplicationServerInfo getApplicationServerInfo(final ApplicationServerPersistentData data) throws CantFindApplicationServerJarsException {
        final List<File> libs = new ArrayList<File>();
        ProgressManager.getInstance().runProcessWithProgressSynchronously(new Runnable() {
            public void run() {
                getLibraries(libs, ((JavaeePersistentData) data).HOME);
            }
        }, JavaeeBundle.get("ServerHelper.libraries.title"), true, null);
        if (libs.isEmpty()) {
            throw new CantFindApplicationServerJarsException(JavaeeBundle.get("ServerHelper.libraries.error"));
        }
        String name = JavaeeIntegration.getInstance().getName() + ' ' + ((JavaeePersistentData) data).VERSION;
        return new ApplicationServerInfo(libs.toArray(new File[libs.size()]), name);
    }

    private void getLibraries(List<File> libraries, String home) {
        ProgressIndicator indicator = ProgressManager.getInstance().getProgressIndicator();
        indicator.setIndeterminate(true);
        List<File> candidates = getCandidates(home, indicator);
        Collection<String> classes = new ArrayList<String>(Arrays.asList(CLASSES));
        indicator.setIndeterminate(false);
        for (File file : candidates) {
            if (!indicator.isCanceled()) {
                indicator.setText(file.getAbsolutePath());
                indicator.setFraction((double) candidates.indexOf(file) / (double) candidates.size());
                try {
                    ZipFile zip = new ZipFile(file);
                    for (Iterator<String> iter = classes.iterator(); iter.hasNext();) {
                        String name = iter.next();
                        if (zip.getEntry(name) != null) {
                            libraries.add(file);
                            iter.remove();
                        }
                    }
                } catch (IOException e) {
                    JavaeeLogger.error(e);
                }
            }
        }
        if (indicator.isCanceled()) {
            libraries.clear();
        }
    }

    private List<File> getCandidates(String home, ProgressIndicator indicator) {
        List<File> locations = new ArrayList<File>();
        List<File> candidates = new ArrayList<File>();
        Set<File> visited = new HashSet<File>();
        JavaeeIntegration.getInstance().addLibraryLocations(home, locations);
        for (File file : locations) {
            getCandidates(file, candidates, visited, indicator);
        }
        return candidates;
    }

    private void getCandidates(File base, List<File> candidates, Set<File> visited, ProgressIndicator indicator) {
        if (base.isDirectory() && visited.add(base) && !indicator.isCanceled()) {
            for (File file : base.listFiles()) {
                if (file.isDirectory()) {
                    getCandidates(file, candidates, visited, indicator);
                } else if (file.getName().endsWith(".jar")) {
                    candidates.add(file);
                }
            }
        }
    }
}
