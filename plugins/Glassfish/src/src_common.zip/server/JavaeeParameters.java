/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.util.List;
import java.util.ArrayList;
import java.io.File;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NonNls;

public class JavaeeParameters {

    private final List<String> list = new ArrayList<String>();

    public void add(@NonNls String... parameters) {
        for (String parameter : parameters) {
            if (StringUtil.isEmpty(parameter)) {
                return;
            }
        }
        for (String parameter : parameters) {
            list.add(parameter);
        }
    }

    public void add(File file) {
        list.add(file.getAbsolutePath());
    }

    public String[] get() {
        return list.toArray(new String[list.size()]);
    }
}
