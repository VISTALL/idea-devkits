/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import com.intellij.util.PathUtil;
import org.jetbrains.annotations.NonNls;

abstract class JavaeeFileScanner {

    private final Pattern pattern;

    protected JavaeeFileScanner(@NonNls String pattern) {
        this.pattern = (pattern != null) ? Pattern.compile(pattern) : null;
    }

    public void scan(@NonNls String dir) throws IOException {
        scan(dir, getClass());
    }

    public void scan(@NonNls String dir, Class<?> ref) {
        try {
            File base = new File(PathUtil.getJarPathForClass(ref));
            if (base.isDirectory()) {
                scanDirectory(base, dir);
            } else {
                scanArchive(base, dir);
            }
        } catch (Throwable t) {
            JavaeeLogger.error(t);
        }
    }

    private void scanDirectory(File base, String dir) {
        for (File file : new File(base, dir).listFiles()) {
            if ((pattern == null) || pattern.matcher(file.getName()).matches()) {
                try {
                    handle(new RegularFile(dir, file));
                } catch (Throwable t) {
                    JavaeeLogger.error(t);
                }
            }
        }
    }

    private void scanArchive(File base, String dir) throws IOException {
        ZipFile zip = new ZipFile(base);
        for (Enumeration<? extends ZipEntry> e = zip.entries(); e.hasMoreElements();) {
            ZipEntry entry = e.nextElement();
            String name = entry.getName();
            if (name.startsWith(dir)) {
                name = entry.getName().substring(name.lastIndexOf('/') + 1);
                if ((pattern == null) || pattern.matcher(name).matches()) {
                    try {
                        handle(new ArchiveFile(zip, entry));
                    } catch (Throwable t) {
                        JavaeeLogger.error(t);
                    }
                }
            }
        }
    }

    protected abstract void handle(JavaeeFile file) throws Exception;

    private static class RegularFile extends JavaeeFile {

        private final File file;

        private RegularFile(String path, File file) {
            super(file.getName(), '/' + path + '/' + file.getName());
            this.file = file;
        }

        @Override
        public InputStream getStream() throws IOException {
            return new FileInputStream(file);
        }
    }

    private static class ArchiveFile extends JavaeeFile {

        private final ZipFile zip;

        private final ZipEntry entry;

        private ArchiveFile(ZipFile zip, ZipEntry entry) {
            super(entry.getName().replaceFirst("(?:.*/)?(.*)", "$1"), '/' + entry.getName());
            this.zip = zip;
            this.entry = entry;
        }

        @Override
        public InputStream getStream() throws IOException {
            return zip.getInputStream(entry);
        }
    }
}
