/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.awt.*;
import javax.swing.*;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.options.SettingsEditor;
import com.fuhrer.idea.javaee.JavaeeBundle;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

public class JavaeeRunSettingsEditor<T extends JavaeeServerModel> extends SettingsEditor<CommonModel> {

    private JPanel panel;

    private JPanel content;

    private JTextField username;

    private JPasswordField password;

    public JavaeeRunSettingsEditor() {
        String name = JavaeeIntegration.getInstance().getName();
        panel.setBorder(BorderFactory.createTitledBorder(JavaeeBundle.get("RunEditor.title", name)));
    }

    @Override
    @SuppressWarnings({"unchecked"})
    protected void resetEditorFrom(CommonModel config) {
        resetEditorFrom((T) config.getServerModel());
    }

    @Override
    @SuppressWarnings({"unchecked"})
    protected void applyEditorTo(CommonModel config) throws ConfigurationException {
        applyEditorTo((T) config.getServerModel());
    }

    @Override
    @NotNull
    protected JComponent createEditor() {
        JComponent editor = createAdditionalEditor();
        if (editor != null) {
            content.setLayout(new BorderLayout());
            content.add(editor, BorderLayout.CENTER);
        }
        return panel;
    }

    @Override
    protected void disposeEditor() {
    }

    @Nullable
    protected JComponent createAdditionalEditor() {
        return null;
    }

    protected void resetEditorFrom(T model) {
        username.setText(model.USERNAME);
        password.setText(model.PASSWORD);
    }

    protected void applyEditorTo(T model) throws ConfigurationException {
        model.USERNAME = username.getText();
        model.PASSWORD = new String(password.getPassword());
    }
}
