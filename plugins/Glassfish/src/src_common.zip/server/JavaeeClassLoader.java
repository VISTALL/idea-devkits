/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import com.intellij.util.Function;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.Nullable;

class JavaeeClassLoader extends URLClassLoader {

    private static final URL[] EMPTY = {};

    private final Set<String> excludes = new HashSet<String>();

    JavaeeClassLoader(Collection<File> libraries, Collection<String> excludes) {
        super(EMPTY, null);
        for (File library : libraries) {
            addFile(library);
            if (library.isDirectory()) {
                addLibraries(library);
            }
        }
        this.excludes.addAll(excludes);
    }

    @Override
    @SuppressWarnings({"NonSynchronizedMethodOverridesSynchronizedMethod"})
    protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
        return isExcluded(name) ? getClass().getClassLoader().loadClass(name) : super.loadClass(name, resolve);
    }

    private boolean isExcluded(String name) {
        return name.startsWith("com.intellij.") || excludes.contains(name);
    }

    private void addLibraries(File dir) {
        for (File file : dir.listFiles()) {
            if (file.isDirectory()) {
                addLibraries(file);
            } else if (file.getName().endsWith(".jar")) {
                addFile(file);
            }
        }
    }

    private void addFile(File file) {
        try {
            addURL(file.toURI().toURL());
        } catch (MalformedURLException e) {
            // ignore...
        }
    }
}
