/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.io.File;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptorType;
import com.intellij.execution.ExecutionException;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.javaee.appServerIntegrations.ApplicationServer;
import com.intellij.javaee.deployment.DeploymentProvider;
import com.intellij.javaee.deployment.DeploymentSource;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.run.configuration.ServerModel;
import com.intellij.javaee.run.execution.DefaultOutputProcessor;
import com.intellij.javaee.run.execution.OutputProcessor;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.openapi.roots.OrderRootType;
import com.intellij.openapi.util.DefaultJDOMExternalizer;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.PathUtil;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

public abstract class JavaeeServerModel implements ServerModel {

    @NonNls
    @SuppressWarnings({"PublicField", "InstanceVariableNamingConvention", "NonConstantFieldWithUpperCaseName"})
    public String USERNAME = getDefaultUsername();

    @NonNls
    @SuppressWarnings({"PublicField", "InstanceVariableNamingConvention", "NonConstantFieldWithUpperCaseName"})
    public String PASSWORD = getDefaultPassword();

    private CommonModel config;

    public void setCommonModel(CommonModel config) {
        this.config = config;
    }

    public J2EEServerInstance createServerInstance() throws ExecutionException {
        try {
            ClassLoader loader = new JavaeeClassLoader(getLibraries(), getExcludes());
            Constructor<?> constructor = loader.loadClass(getServerName()).getDeclaredConstructor();
            constructor.setAccessible(true);
            JavaeeServer server = JavaeeServer.class.cast(constructor.newInstance());
            server.setHost(getServerHost());
            server.setPort(getServerPort());
            server.setUsername(USERNAME);
            server.setPassword(PASSWORD);
            return new JavaeeServerInstance(config, server);
        } catch (Exception e) {
            throw new ExecutionException(e.getMessage(), e);
        }
    }

    public DeploymentProvider getDeploymentProvider() {
        return new JavaeeDeploymentProvider();
    }

    public int getDefaultPort() {
        return 8080;
    }

    public int getLocalPort() {
        return getDefaultPort();
    }

    @NonNls
    public String getDefaultUrlForBrowser() {
        return "http://" + config.getHost() + ':' + config.getPort();
    }

    public OutputProcessor createOutputProcessor(ProcessHandler handler, J2EEServerInstance instance) {
        return new DefaultOutputProcessor(handler);
    }

    @Nullable
    public List<Pair<String, Integer>> getAddressesToCheck() {
        return config.isLocal() ? Collections.singletonList(new Pair<String, Integer>(getServerHost(), getServerPort())) : null;
    }

    public void checkConfiguration() throws RuntimeConfigurationException {
    }

    public void readExternal(Element element) throws InvalidDataException {
        DefaultJDOMExternalizer.readExternal(this, element);
    }

    public void writeExternal(Element element) throws WriteExternalException {
        DefaultJDOMExternalizer.writeExternal(this, element);
    }

    @Override
    public final Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public String getHome() {
        ApplicationServer server = config.getApplicationServer();
        return (server != null) ? ((JavaeePersistentData) server.getPersistentData()).HOME : "";
    }

    public String getVersion() {
        ApplicationServer server = config.getApplicationServer();
        return (server != null) ? ((JavaeePersistentData) server.getPersistentData()).VERSION : "";
    }

    protected abstract boolean isDeploymentSourceSupported(DeploymentSource source);

    @NonNls
    protected abstract String getDefaultUsername();

    @NonNls
    protected abstract String getDefaultPassword();

    @NonNls
    protected abstract String getServerName();

    protected abstract int getServerPort();

    protected String getServerHost() {
        return config.getHost();
    }

    protected CommonModel getCommonModel() {
        return config;
    }

    protected List<File> getLibraries() {
        List<File> libraries = new ArrayList<File>();
        libraries.add(new File(PathUtil.getJarPathForClass(getClass())));
        for (VirtualFile file : config.getApplicationServer().getLibrary().getFiles(OrderRootType.CLASSES)) {
            libraries.add(new File(file.getPresentableUrl()));
        }
        return libraries;
    }

    protected List<String> getExcludes() {
        List<String> excludes = new ArrayList<String>();
        excludes.add(JavaeeServer.class.getName());
        excludes.add(JavaeeDescriptorType.class.getName());
        return excludes;
    }
}
