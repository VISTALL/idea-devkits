/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.io.File;
import java.util.Map;
import com.intellij.javaee.deployment.DeploymentManager;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentStatus;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleType;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class JavaeeServer {

    private String host;

    private int port;

    private String username;

    private String password;

    protected abstract boolean isConnected() throws Exception;

    @NotNull
    protected abstract DeploymentStatus handleDeployment(DeploymentModel deployment, boolean deploy, boolean undeploy) throws Exception;

    @Nullable
    protected abstract String getContextRoot(Module module);

    protected void getContextRoots(Module module, Map<String, String> roots) {
    }

    protected String getHost() {
        return host;
    }

    protected int getPort() {
        return port;
    }

    protected String getUsername() {
        return username;
    }

    protected String getPassword() {
        return password;
    }

    protected boolean isAppModule(DeploymentModel deployment) {
        return ModuleType.J2EE_APPLICATION.equals(deployment.getModuleProperties().getModule().getModuleType());
    }

    protected boolean isEjbModule(DeploymentModel deployment) {
        return ModuleType.EJB.equals(deployment.getModuleProperties().getModule().getModuleType());
    }

    protected boolean isWebModule(DeploymentModel deployment) {
        return ModuleType.WEB.equals(deployment.getModuleProperties().getModule().getModuleType());
    }

    protected File getDeploymentSource(DeploymentModel deployment) {
        Project project = deployment.getModuleProperties().getModule().getProject();
        return DeploymentManager.getInstance(project).getDeploymentSource(deployment);
    }

    void setHost(String host) {
        this.host = host;
    }

    void setPort(int port) {
        this.port = port;
    }

    void setUsername(String username) {
        this.username = username;
    }

    void setPassword(String password) {
        this.password = password;
    }
}
