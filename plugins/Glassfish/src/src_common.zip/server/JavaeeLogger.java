/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import com.intellij.openapi.diagnostic.Logger;
import com.fuhrer.idea.javaee.JavaeePlugin;

public class JavaeeLogger {

    private static final Logger logger = Logger.getInstance("com.fuhrer.plugin." + JavaeePlugin.getInstance().getId());

    private JavaeeLogger() {
    }

    public static void error(Throwable t) {
        logger.error(t);
    }
}
