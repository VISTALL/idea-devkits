/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.io.File;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

public abstract class JavaeePortConfig {

    private long stamp;

    private int port;

    public int getPort() {
        if (stamp != getStamp()) {
            port = findPort();
            stamp = getStamp();
        }
        return port;
    }

    @Nullable
    protected Element findElement(Element parent, @NonNls String tag, @NonNls String name, @NonNls String value) {
        for (Object o : parent.getChildren(tag, parent.getNamespace())) {
            Element element = (Element) o;
            if (element.getAttributeValue(name).matches(value)) {
                return element;
            }
        }
        return null;
    }

    protected long getStamp(File file) {
        return ((file != null) && file.exists()) ? (file.lastModified() ^ file.length()) : 0;
    }

    protected abstract long getStamp();

    protected abstract int findPort();
}
