/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.editor;

import java.util.List;
import com.intellij.javaee.model.xml.JavaeeDomModelElement;

public interface JavaeeSection<T extends JavaeeDomModelElement> {

    List<JavaeeSectionInfo<T>> getColumnInfos();

    List<T> getValues();
}
