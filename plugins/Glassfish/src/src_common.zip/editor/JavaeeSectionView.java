/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.editor;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import com.intellij.openapi.project.Project;
import com.intellij.util.Icons;
import com.intellij.util.ui.ColumnInfo;
import com.intellij.util.ui.UIUtil;
import com.intellij.util.xml.ui.CommittablePanel;
import com.intellij.util.xml.ui.DomTableView;
import com.intellij.util.xml.ui.StripeTableCellRenderer;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

public class JavaeeSectionView implements CommittablePanel {

    @NonNls
    private static final String LABEL = "LABEL";

    private final JavaeeSection<?>[] sections;

    private final SectionTableView view;

    private final JTableHeader header;

    private final List<Object> items = new ArrayList<Object>();

    private final Set<JavaeeSection<?>> expanded = new HashSet<JavaeeSection<?>>();

    private final Map<JavaeeSection<?>, List<? extends JavaeeSectionInfo<?>>> mapped = new HashMap<JavaeeSection<?>, List<? extends JavaeeSectionInfo<?>>>();

    private final ColumnInfo<?, ?>[] columns;

    private static final ColumnInfo<Object, String> EMPTY_COLUMN = new ColumnInfo<Object, String>(null) {
        private final DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();

        @Override
        public String valueOf(Object item) {
            return "";
        }

        @Override
        public TableCellRenderer getRenderer(Object item) {
            return renderer;
        }
    };

    public JavaeeSectionView(Project project, String empty, JavaeeSection<?>... sections) {
        this.sections = sections.clone();
        view = new SectionTableView(project, empty);
        final JTable table = view.getTable();
        table.setRowHeight(Icons.CLASS_ICON.getIconHeight());
        table.setShowVerticalLines(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent event) {
                Point point = new Point(event.getPoint());
                int row = table.rowAtPoint(point);
                int col = table.columnAtPoint(point);
                if ((row >= 0) && (col >= 0)) {
                    JComponent component = (JComponent) table.prepareRenderer(table.getCellRenderer(row, col), row, col);
                    Rectangle rect = table.getCellRect(row, col, true);
                    component.setSize(rect.getSize());
                    component.doLayout();
                    point.translate(-rect.x, -rect.y);
                    if (isLabel(component.findComponentAt(point))) {
                        Object item = items.get(row);
                        if (item instanceof JavaeeSection) {
                            toggleExpanded(item);
                        }
                    } else if (event.getClickCount() >= 2) {
                        toggleExpanded(items.get(row));
                    }
                }
            }
        });
        table.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent keyevent) {
                int k = table.getSelectedRow();
                if (k < 0) {
                    return;
                }
                Object item = items.get(k);
                if (item instanceof JavaeeSection) {
                    JavaeeSection<?> section = (JavaeeSection<?>) item;
                    if ((keyevent.getKeyCode() == KeyEvent.VK_LEFT) && isExpanded(section)) {
                        toggleExpanded(section);
                    } else if ((keyevent.getKeyCode() == KeyEvent.VK_RIGHT) && !isExpanded(section)) {
                        toggleExpanded(section);
                    }
                }
            }
        });
        header = table.getTableHeader();
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focus, int row, int col) {
                super.getTableCellRendererComponent(table, value, selected, focus, row, col);
                setBorder(null);
                return this;
            }
        });
        expanded.addAll(Arrays.asList(sections));
        columns = getColumnInfos();
        view.initialize();
        reset();
    }

    public void dispose() {
    }

    public void commit() {
    }

    public void reset() {
        items.clear();
        for (JavaeeSection<?> section : sections) {
            List<?> values = section.getValues();
            if (!values.isEmpty()) {
                items.add(section);
                if (isExpanded(section)) {
                    items.addAll(values);
                }
            }
        }
        view.reset(columns, items);
    }

    public JComponent getComponent() {
        return view;
    }

    private ColumnInfo<?, ?>[] getColumnInfos() {
        mapped.clear();
        int num = 0;
        for (JavaeeSection<?> section : sections) {
            List<? extends JavaeeSectionInfo<?>> infos = section.getColumnInfos();
            mapped.put(section, infos);
            num = Math.max(num, infos.size());
        }
        List<ColumnInfo<?, ?>> list = new ArrayList<ColumnInfo<?, ?>>();
        list.add(getColumn());
        for (int i = 0; i < num; i++) {
            list.add(getColumn(i));
        }
        return list.toArray(new ColumnInfo[list.size()]);
    }

    private ColumnInfo<?, ?> getColumn() {
        return new ColumnInfo<Object, Object>(null) {
            @Override
            @Nullable
            public Object valueOf(Object item) {
                return (item instanceof JavaeeSection) ? item : null;
            }

            @Override
            public TableCellRenderer getRenderer(Object item) {
                return new DefaultTableCellRenderer() {
                    @Override
                    public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focus, int row, int col) {
                        if (value instanceof JavaeeSection) {
                            JPanel panel = new JPanel(new BorderLayout());
                            panel.add(createLabel(isExpanded((JavaeeSection<?>) value) ? UIUtil.getTreeExpandedIcon() : UIUtil.getTreeCollapsedIcon()));
                            return panel;
                        } else {
                            return super.getTableCellRendererComponent(table, value, selected, focus, row, col);
                        }
                    }
                };
            }
        };
    }

    private ColumnInfo<?, ?> getColumn(final int index) {
        return new ColumnInfo(null) {
            @Override
            @Nullable
            public Object valueOf(Object item) {
                if (item instanceof JavaeeSection) {
                    return ((index == 0) || isExpanded((JavaeeSection<?>) item)) ? getColumn(item, index).getName() : null;
                } else {
                    return getColumn(item, index).valueOf(item);
                }
            }

            @Override
            public void setValue(Object item, Object value) {
                getColumn(item, index).setValue(item, value);
            }

            @Override
            public boolean isCellEditable(Object item) {
                return !(item instanceof JavaeeSection) && getColumn(item, index).isCellEditable(item);
            }

            @Override
            @Nullable
            public TableCellRenderer getRenderer(Object item) {
                return !(item instanceof JavaeeSection) ? getColumn(item, index).getRenderer(item) : null;
            }

            @Override
            public TableCellEditor getEditor(Object item) {
                return getColumn(item, index).getEditor(item);
            }
        };
    }

    private JavaeeSection<?> getSection(Object item) {
        int index = items.indexOf(item);
        while (!(item instanceof JavaeeSection)) {
            item = items.get(--index);
        }
        return (JavaeeSection<?>) item;
    }

    private ColumnInfo<Object, Object> getColumn(Object item, int index) {
        List<? extends ColumnInfo> infos = mapped.get(getSection(item));
        return (index < infos.size()) ? infos.get(index) : EMPTY_COLUMN;
    }

    private boolean isExpanded(JavaeeSection<?> section) {
        return expanded.contains(section);
    }

    private void toggleExpanded(Object obj) {
        if (obj instanceof JavaeeSection) {
            JavaeeSection<?> section = (JavaeeSection<?>) obj;
            if (isExpanded(section)) {
                expanded.remove(section);
            } else {
                expanded.add(section);
            }
            reset();
        }
    }

    private JComponent customize(Object value, JComponent component, JTable table, int col, boolean selected) {
        Border border = BorderFactory.createEmptyBorder(0, 5, 0, (col != 0) && (col != 2) ? 0 : 5);
        if (value instanceof JavaeeSection) {
            Color color = selected ? StripeTableCellRenderer.darken(table.getSelectionBackground()) : new Color(header.getBackground().getRGB());
            component.setBackground(color);
            border = BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, color.darker()), border);
            if (isExpanded((JavaeeSection<?>) value)) {
                if (col > 1) {
                    border = BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, color.brighter()), border);
                }
                if (col > 0) {
                    border = BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, table.getGridColor()), border);
                }
            }
            component.setFont(component.getFont().deriveFont(Font.BOLD));
        } else if (col > 0) {
            border = BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, table.getGridColor()), border);
        }
        component.setBorder(border);
        return component;
    }

    private class SectionTableView extends DomTableView {

        SectionTableView(Project project, String empty) {
            super(project, empty, null);
        }

        @Override
        protected void adjustColumnWidths() {
            super.adjustColumnWidths();
            TableColumnModel model = getTable().getColumnModel();
            if (model.getColumnCount() > 0) {
                TableColumn column = model.getColumn(0);
                column.setMinWidth(column.getPreferredWidth());
                column.setMaxWidth(column.getPreferredWidth());
            }
        }

        @Override
        protected TableCellRenderer getTableCellRenderer(int row, int col, final TableCellRenderer renderer, Object value) {
            return new TableCellRenderer() {
                public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focus, int row, int col) {
                    Component component = renderer.getTableCellRendererComponent(table, value, selected, focus, row, col);
                    return customize(items.get(row), (JComponent) component, table, col, selected);
                }
            };
        }

        void initialize() {
            initializeTable();
        }
    }

    private boolean isLabel(Component component) {
        return (component instanceof JLabel) && (((JLabel) component).getClientProperty(LABEL) != null);
    }

    private JLabel createLabel(Icon icon) {
        JLabel label = new JLabel(icon);
        label.putClientProperty(LABEL, LABEL);
        return label;
    }
}
