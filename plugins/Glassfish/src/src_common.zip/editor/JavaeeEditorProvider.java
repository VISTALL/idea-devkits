/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.editor;

import com.fuhrer.idea.javaee.server.JavaeeIntegration;
import com.intellij.javaee.JavaeeManager;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.model.JavaeeApplicationModel;
import com.intellij.javaee.model.xml.ejb.EjbBase;
import com.intellij.javaee.model.xml.ejb.EntityBean;
import com.intellij.javaee.model.xml.ejb.MessageDrivenBean;
import com.intellij.javaee.model.xml.ejb.SessionBean;
import com.intellij.javaee.model.xml.web.Servlet;
import com.intellij.javaee.module.components.EjbModuleProperties;
import com.intellij.javaee.module.view.common.editor.JavaeeModuleAsVirtualFile;
import com.intellij.javaee.module.view.ejb.editor.EjbAsVirtualFile;
import com.intellij.javaee.module.view.web.editor.ServletAsVirtualFile;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.ui.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class JavaeeEditorProvider extends PerspectiveFileEditorProvider {

    @SuppressWarnings({"ChainOfInstanceofChecks", "InstanceofIncompatibleInterface", "CastToIncompatibleInterface"})
    public final boolean accept(@NotNull Project project, @NotNull VirtualFile file) {
        boolean accept = false;
        if (file instanceof JavaeeModuleAsVirtualFile) {
            JavaeeModuleProperties properties = ((JavaeeModuleAsVirtualFile) file).findElement(project);
            if (properties != null) {
                accept = acceptModule(properties);
            }
        } else if (file instanceof EjbAsVirtualFile) {
            EjbBase bean = JavaeeManager.getInstance().getDomElement(((EjbAsVirtualFile) file).findElement(project));
            if (bean != null) {
                accept = acceptEjbBean(bean);
            }
        } else if (file instanceof ServletAsVirtualFile) {
            Servlet servlet = ((ServletAsVirtualFile) file).findElement(project);
            if (servlet != null) {
                accept = acceptServlet(servlet);
            }
        }
        return accept;
    }

    @Override
    @NotNull
    @SuppressWarnings({"ChainOfInstanceofChecks", "InstanceofIncompatibleInterface", "CastToIncompatibleInterface"})
    public final PerspectiveFileEditor createEditor(@NotNull Project project, @NotNull VirtualFile file) {
        PerspectiveFileEditor editor = null;
        if (file instanceof JavaeeModuleAsVirtualFile) {
            JavaeeModuleProperties properties = ((JavaeeModuleAsVirtualFile) file).findElement(project);
            if (properties != null) {
                editor = createModuleEditor(project, file, properties);
            }
        } else if (file instanceof EjbAsVirtualFile) {
            EjbBase bean = JavaeeManager.getInstance().getDomElement(((EjbAsVirtualFile) file).findElement(project));
            if (bean != null) {
                editor = createEjbBeanEditor(project, file, bean);
            }
        } else if (file instanceof ServletAsVirtualFile) {
            Servlet servlet = ((ServletAsVirtualFile) file).findElement(project);
            if (servlet != null) {
                editor = createServletEditor(project, file, servlet);
            }
        }
        if (editor == null) {
            editor = createEmptyEditor(project, file);
        }
        return editor;
    }

    @SuppressWarnings({"InstanceofIncompatibleInterface", "CastToIncompatibleInterface"})
    protected boolean acceptModule(@NotNull JavaeeModuleProperties properties) {
        boolean accept = false;
        if (properties instanceof JavaeeApplicationModel) {
            accept = acceptAppRoot(properties, (JavaeeApplicationModel) properties);
        } else if (properties instanceof EjbModuleProperties) {
            accept = acceptEjbRoot(properties, (EjbModuleProperties) properties);
        } else if (properties instanceof WebModuleProperties) {
            accept = acceptWebRoot(properties, (WebModuleProperties) properties);
        }
        return accept;
    }

    protected boolean acceptAppRoot(@NotNull JavaeeModuleProperties properties, @NotNull JavaeeApplicationModel model) {
        return false;
    }

    protected boolean acceptEjbRoot(@NotNull JavaeeModuleProperties properties, @NotNull EjbModuleProperties model) {
        return false;
    }

    protected boolean acceptWebRoot(@NotNull JavaeeModuleProperties properties, @NotNull WebModuleProperties model) {
        return false;
    }

    protected boolean acceptEjbBean(@NotNull EjbBase bean) {
        boolean accept = false;
        if (bean instanceof SessionBean) {
            accept = acceptSessionBean((SessionBean) bean);
        } else if (bean instanceof EntityBean) {
            accept = acceptEntityBean((EntityBean) bean);
        } else if (bean instanceof MessageDrivenBean) {
            accept = acceptMessageBean((MessageDrivenBean) bean);
        }
        return accept;
    }

    protected boolean acceptEntityBean(@NotNull EntityBean bean) {
        return false;
    }

    protected boolean acceptSessionBean(@NotNull SessionBean bean) {
        return false;
    }

    protected boolean acceptMessageBean(@NotNull MessageDrivenBean bean) {
        return false;
    }

    protected boolean acceptServlet(@NotNull Servlet servlet) {
        return false;
    }

    @Nullable
    @SuppressWarnings({"InstanceofIncompatibleInterface", "CastToIncompatibleInterface"})
    protected PerspectiveFileEditor createModuleEditor(Project project, VirtualFile file, JavaeeModuleProperties properties) {
        PerspectiveFileEditor editor;
        if (properties instanceof JavaeeApplicationModel) {
            editor = createAppRootEditor(project, file, properties, (JavaeeApplicationModel) properties);
        } else if (properties instanceof EjbModuleProperties) {
            editor = createEjbRootEditor(project, file, properties, (EjbModuleProperties) properties);
        } else if (properties instanceof WebModuleProperties) {
            editor = createWebRootEditor(project, file, properties, (WebModuleProperties) properties);
        } else {
            editor = createEmptyEditor(project, file);
        }
        return editor;
    }

    @Nullable
    protected PerspectiveFileEditor createAppRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeModuleProperties properties, @NotNull JavaeeApplicationModel model) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    protected PerspectiveFileEditor createEjbRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeModuleProperties properties, @NotNull EjbModuleProperties model) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    protected PerspectiveFileEditor createWebRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeModuleProperties properties, @NotNull WebModuleProperties model) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    protected PerspectiveFileEditor createEjbBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull EjbBase bean) {
        PerspectiveFileEditor editor;
        if (bean instanceof SessionBean) {
            editor = createSessionBeanEditor(project, file, (SessionBean) bean);
        } else if (bean instanceof EntityBean) {
            editor = createEntityBeanEditor(project, file, (EntityBean) bean);
        } else if (bean instanceof MessageDrivenBean) {
            editor = createMessageBeanEditor(project, file, (MessageDrivenBean) bean);
        } else {
            editor = createEmptyEditor(project, file);
        }
        return editor;
    }

    @Nullable
    protected PerspectiveFileEditor createEntityBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull EntityBean bean) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    protected PerspectiveFileEditor createSessionBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull SessionBean bean) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    protected PerspectiveFileEditor createMessageBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull MessageDrivenBean bean) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    protected PerspectiveFileEditor createServletEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull Servlet servlet) {
        return createEmptyEditor(project, file);
    }

    @NotNull
    protected PerspectiveFileEditor createEditor(@NotNull DomElement element, @NotNull CommittablePanel panel) {
        JavaeeIntegration integration = JavaeeIntegration.getInstance();
        CaptionComponent caption = new CaptionComponent(integration.getPresentableName(), integration.getBigIcon());
        caption = DomUIFactory.getDomUIFactory().addErrorPanel(caption, element);
        return DomFileEditor.createDomFileEditor(caption.getText(), element, caption, panel);
    }

    @NotNull
    private PerspectiveFileEditor createEmptyEditor(@NotNull Project project, @NotNull VirtualFile file) {
        JavaeeIntegration integration = JavaeeIntegration.getInstance();
        return new JavaeeEmptyEditor(project, file, integration.getPresentableName(), integration.getBigIcon());
    }
}
