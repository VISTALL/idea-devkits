/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.editor;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.openapi.application.Result;
import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.project.Project;

public abstract class JavaeeSectionInfoEditable<T extends JavaeeDomModelElement> extends JavaeeSectionInfo<T> {

    private final Project project;

    protected JavaeeSectionInfoEditable(String name, JavaeeDomModelElement element) {
        super(name);
        project = element.getManager().getProject();
    }

    @Override
    public void setValue(final T item, final String value) {
        new WriteCommandAction<Object>(project) {
            @Override
            protected void run(Result<Object> result) throws Throwable {
                write(item, value);
            }
        }.execute();
    }

    @Override
    public boolean isCellEditable(T item) {
        return true;
    }

    protected abstract void write(T item, String value);
}
