/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.converter;

import java.util.Collection;
import java.util.Collections;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.model.JavaeeApplicationModel;
import com.intellij.javaee.model.xml.SecurityRole;
import com.intellij.javaee.model.xml.application.JavaeeApplication;
import com.intellij.javaee.model.xml.ejb.EjbJar;
import com.intellij.javaee.model.xml.web.WebApp;
import com.intellij.javaee.module.components.EjbModuleProperties;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.util.xml.ConvertContext;
import com.intellij.util.xml.ElementPresentationManager;
import com.intellij.util.xml.ResolvingConverter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class SecurityRoleConverter extends ResolvingConverter<SecurityRole> {

    @Override
    @Nullable
    public SecurityRole fromString(String value, ConvertContext context) {
        return ElementPresentationManager.findByName(getVariants(context), value);
    }

    @Override
    @Nullable
    public String toString(SecurityRole value, ConvertContext context) {
        return (value != null) ? value.getRoleName().getValue() : null;
    }

    @Override
    @NotNull
    @SuppressWarnings({"InstanceofIncompatibleInterface", "CastToIncompatibleInterface"})
    public Collection<SecurityRole> getVariants(ConvertContext context) {
        Collection<SecurityRole> variants = Collections.emptyList();
        JavaeeModuleProperties properties = JavaeeModuleProperties.getInstance(context.getModule());
        if (properties instanceof JavaeeApplicationModel) {
            JavaeeApplication root = ((JavaeeApplicationModel) properties).getRoot();
            if (root != null) {
                variants = root.getSecurityRoles();
            }
        } else if (properties instanceof EjbModuleProperties) {
            EjbJar root = ((EjbModuleProperties) properties).getXmlRoot();
            if (root != null) {
                variants = root.getAssemblyDescriptor().getSecurityRoles();
            }
        } else if (properties instanceof WebModuleProperties) {
            WebApp root = ((WebModuleProperties) properties).getRoot();
            if (root != null) {
                variants = root.getSecurityRoles();
            }
        }
        return variants;
    }
}
