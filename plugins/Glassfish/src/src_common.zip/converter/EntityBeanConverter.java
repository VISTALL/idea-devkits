/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.converter;

import java.util.Collection;
import java.util.Collections;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.model.xml.ejb.EjbJar;
import com.intellij.javaee.model.xml.ejb.EntityBean;
import com.intellij.javaee.module.components.EjbModuleProperties;
import com.intellij.util.xml.ConvertContext;
import com.intellij.util.xml.ElementPresentationManager;
import com.intellij.util.xml.ResolvingConverter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class EntityBeanConverter extends ResolvingConverter<EntityBean> {

    @Override
    @Nullable
    public EntityBean fromString(String value, ConvertContext context) {
        return ElementPresentationManager.findByName(getVariants(context), value);
    }

    @Override
    @Nullable
    public String toString(EntityBean value, ConvertContext context) {
        return (value != null) ? value.getEjbName().getValue() : null;
    }

    @Override
    @NotNull
    @SuppressWarnings({"InstanceofIncompatibleInterface", "CastToIncompatibleInterface"})
    public Collection<EntityBean> getVariants(ConvertContext context) {
        JavaeeModuleProperties properties = JavaeeModuleProperties.getInstance(context.getModule());
        if (properties instanceof EjbModuleProperties) {
            EjbJar root = ((EjbModuleProperties) properties).getXmlRoot();
            if (root != null) {
                return root.getEnterpriseBeans().getEntities();
            }
        }
        return Collections.emptyList();
    }
}
