/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.descriptor;

import com.fuhrer.idea.javaee.JavaeeBundle;
import com.fuhrer.idea.javaee.util.IconLoader;
import com.intellij.openapi.module.ModuleType;

class JavaeeEjbDescriptor extends JavaeeDescriptorType {

    JavaeeEjbDescriptor() {
        super(IconLoader.get("/resources/ejb.png"));
    }

    @Override
    protected String getTitle(String name) {
        return JavaeeBundle.get("EjbDescriptor.title", name);
    }

    @Override
    protected ModuleType<?> getSuitableType() {
        return ModuleType.EJB;
    }
}
