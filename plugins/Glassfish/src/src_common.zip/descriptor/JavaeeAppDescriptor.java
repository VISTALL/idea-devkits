/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.descriptor;

import com.fuhrer.idea.javaee.JavaeeBundle;
import com.fuhrer.idea.javaee.util.IconLoader;
import com.intellij.openapi.module.ModuleType;

class JavaeeAppDescriptor extends JavaeeDescriptorType {

    JavaeeAppDescriptor() {
        super(IconLoader.get("/resources/app.png"));
    }

    @Override
    protected String getTitle(String name) {
        return JavaeeBundle.get("AppDescriptor.title", name);
    }

    @Override
    protected ModuleType<?> getSuitableType() {
        return ModuleType.J2EE_APPLICATION;
    }
}
