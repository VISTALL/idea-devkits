/*
* Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
*/

package com.fuhrer.idea.javaee.descriptor;

import com.intellij.javaee.JavaeeDeploymentDescriptor;
import com.intellij.javaee.JavaeeDeploymentItem;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.psi.xml.XmlFile;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.DomFileElement;
import com.intellij.util.xml.DomManager;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class JavaeeDescriptors implements ProjectComponent {

    private final Project project;

    protected JavaeeDescriptors(Project project) {
        this.project = project;
    }

    @NonNls
    @NotNull
    public String getComponentName() {
        return getClass().getSimpleName();
    }

    public void initComponent() {
        registerFileDescriptions();
    }

    public void disposeComponent() {
    }

    public void projectOpened() {
    }

    public void projectClosed() {
    }

    protected abstract void registerFileDescriptions();

    protected <T> void register(Class<T> type, JavaeeDescriptorType meta) {
        JavaeeFileDescription<T> description = new JavaeeFileDescription<T>(type, meta);
        DomManager.getDomManager(project).registerFileDescription(description);
    }

    @Nullable
    protected <T extends DomElement> T getAppRoot(Module module, Class<T> type) {
        return getRoot(module, JavaeeDescriptorType.APP, type);
    }

    @Nullable
    protected <T extends DomElement> T getEjbRoot(Module module, Class<T> type) {
        return getRoot(module, JavaeeDescriptorType.EJB, type);
    }

    @Nullable
    protected <T extends DomElement> T getCmpRoot(Module module, Class<T> type) {
        return getRoot(module, JavaeeDescriptorType.CMP, type);
    }

    @Nullable
    protected <T extends DomElement> T getWebRoot(Module module, Class<T> type) {
        return getRoot(module, JavaeeDescriptorType.WEB, type);
    }

    @Nullable
    protected <T extends DomElement> T getRoot(Module module, JavaeeDescriptorType meta, Class<T> type) {
        JavaeeModuleProperties properties = JavaeeModuleProperties.getInstance(module);
        if (properties != null) {
            JavaeeDeploymentItem item = properties.findDeploymentDescriptor(meta);
            if (item instanceof JavaeeDeploymentDescriptor) {
                XmlFile xml = ((JavaeeDeploymentDescriptor) item).getXmlFile();
                if (xml != null) {
                    DomFileElement<T> element = DomManager.getDomManager(module.getProject()).getFileElement(xml, type);
                    if (element != null) {
                        return element.getRootElement();
                    }
                }
            }
        }
        return null;
    }
}
