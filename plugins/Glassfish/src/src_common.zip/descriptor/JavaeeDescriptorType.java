/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.descriptor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.*;
import com.intellij.javaee.DeploymentDescriptorMetaData;
import com.intellij.openapi.module.ModuleType;
import com.intellij.openapi.util.Pair;
import org.jetbrains.annotations.NonNls;

public abstract class JavaeeDescriptorType implements DeploymentDescriptorMetaData {

    @SuppressWarnings({"ClassReferencesSubclass"})
    public static final JavaeeDescriptorType APP = new JavaeeAppDescriptor();

    @SuppressWarnings({"ClassReferencesSubclass"})
    public static final JavaeeDescriptorType EJB = new JavaeeEjbDescriptor();

    @SuppressWarnings({"ClassReferencesSubclass"})
    public static final JavaeeDescriptorType CMP = new JavaeeCmpDescriptor();

    @SuppressWarnings({"ClassReferencesSubclass"})
    public static final JavaeeDescriptorType WEB = new JavaeeWebDescriptor();

    @SuppressWarnings({"PublicStaticArrayField"})
    public static final JavaeeDescriptorType[] ALL = {APP, EJB, CMP, WEB};

    private final Icon icon;

    private String integrationName;

    @NonNls
    private String defaultFileName;

    @NonNls
    private String rootTagName;

    private final List<Pair<String, String>> versions = new ArrayList<Pair<String, String>>();

    private final Set<String> namespaces = new HashSet<String>();

    protected JavaeeDescriptorType(Icon icon) {
        this.icon = icon;
    }

    public Icon getIcon() {
        return icon;
    }

    public String getTitle() {
        return getTitle(integrationName);
    }

    public String[] getAvailableVersions() {
        String[] tmp = new String[versions.size()];
        for (int i = 0; i < versions.size(); i++) {
            tmp[i] = versions.get(i).getFirst();
        }
        return tmp;
    }

    @NonNls
    public String getTemplateNameAccordingToVersion(String version) {
        for (Pair<String, String> pair : versions) {
            if (version.equals(pair.getFirst())) {
                return pair.getSecond();
            }
        }
        return versions.get(0).getSecond();
    }

    @NonNls
    public String getDefaultVersion() {
        return versions.get(0).getFirst();
    }

    @NonNls
    public String getDefaultFileName() {
        return defaultFileName;
    }

    @NonNls
    public String getDefaultDirectoryName() {
        return "META-INF";
    }

    public ModuleType<?>[] getSuitableTypes() {
        return new ModuleType[]{getSuitableType()};
    }

    public boolean isDescriptorOptional() {
        return false;
    }

    public String getRootTagName() {
        return rootTagName;
    }

    public boolean hasNamespace(String namespace) {
        return namespaces.contains(namespace);
    }

    @SuppressWarnings({"ParameterHidesMemberVariable"})
    public void init(String integrationName, @NonNls String defaultFileName, @NonNls String rootTagName) {
        this.integrationName = integrationName;
        this.defaultFileName = defaultFileName;
        this.rootTagName = rootTagName;
    }

    public void addVersion(@NonNls String version, @NonNls String template, @NonNls String namespace) {
        versions.add(new Pair<String, String>(version, template));
        namespaces.add(namespace);
    }

    protected abstract String getTitle(String name);

    protected abstract ModuleType<?> getSuitableType();
}
