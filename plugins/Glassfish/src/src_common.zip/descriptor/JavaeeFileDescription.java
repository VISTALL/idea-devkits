/*
* Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
*/

package com.fuhrer.idea.javaee.descriptor;

import com.intellij.openapi.module.Module;
import com.intellij.psi.xml.XmlDocument;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import com.intellij.util.xml.DomFileDescription;

class JavaeeFileDescription<T> extends DomFileDescription<T> {

    private final JavaeeDescriptorType meta;

    JavaeeFileDescription(Class<T> type, JavaeeDescriptorType meta) {
        super(type, meta.getRootTagName());
        this.meta = meta;
    }

    @Override
    protected void initializeFileDescription() {
    }

    @Override
    public boolean isMyFile(XmlFile file, Module module) {
        XmlDocument document = file.getDocument();
        if (document != null) {
            XmlTag tag = document.getRootTag();
            if (tag != null) {
                return meta.getRootTagName().equals(tag.getName()) && meta.hasNamespace(tag.getNamespace());
            }
        }
        return false;
    }
}
