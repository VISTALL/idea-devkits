/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.util;

import javax.swing.*;
import com.intellij.openapi.actionSystem.AnActionEvent;

public class TreeSourceAction extends OpenSourceAction {

    private final JTree tree;

    public TreeSourceAction(JTree tree) {
        super(tree);
        this.tree = tree;
    }

    @Override
    public void update(AnActionEvent event) {
        event.getPresentation().setEnabled(tree.getSelectionCount() > 0);
    }
}
