/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.util;

import javax.swing.*;
import com.fuhrer.idea.javaee.JavaeeBundle;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.util.ui.tree.TreeUtil;

public class TreeCollapseAction extends AnAction {

    private final JTree tree;

    public TreeCollapseAction(JTree tree) {
        super(JavaeeBundle.get("TreeActions.collapse"), null, IconLoader.get("/actions/collapseall.png"));
        this.tree = tree;
    }

    @Override
    public void actionPerformed(AnActionEvent event) {
        TreeUtil.collapseAll(tree, 0);
    }

    @Override
    public void update(AnActionEvent event) {
        event.getPresentation().setEnabled(tree.getRowCount() > 0);
    }
}
