/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.util;

import javax.swing.*;
import com.intellij.openapi.actionSystem.AnActionEvent;

public class TableSourceAction extends OpenSourceAction {

    private final JTable table;

    public TableSourceAction(JTable table) {
        super(table);
        this.table = table;
    }

    @Override
    public void update(AnActionEvent event) {
        event.getPresentation().setEnabled(table.getSelectedRowCount() > 0);
    }
}
