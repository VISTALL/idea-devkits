/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.util;

import java.awt.*;
import javax.swing.*;

public class RowIcon implements Icon {

    private Icon[] icons;

    private int width;

    private int height;

    public RowIcon(Icon... icons) {
        this.icons = icons.clone();
        calculateSize();
    }

    public void paintIcon(Component component, Graphics g, int x, int y) {
        for (Icon icon : icons) {
            if (icon != null) {
                icon.paintIcon(component, g, x, y);
                x += icon.getIconWidth();
            }
        }
    }

    public int getIconWidth() {
        return width;
    }

    public int getIconHeight() {
        return height;
    }

    private void calculateSize() {
        width = 0;
        height = 0;
        for (Icon icon : icons) {
            if (icon != null) {
                width += icon.getIconWidth();
                height = Math.max(height, icon.getIconHeight());
            }
        }
    }
}
