/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.util;

import java.awt.event.*;
import java.util.Enumeration;
import javax.swing.*;
import com.intellij.util.xml.ui.BaseControl;
import com.intellij.util.xml.ui.DomWrapper;
import org.jetbrains.annotations.Nullable;

public class ButtonGroupControl extends BaseControl<JComponent, String> {

    private final JComponent parent;

    private final ButtonGroup group;

    public ButtonGroupControl(DomWrapper<String> wrapper, AbstractButton... buttons) {
        super(wrapper);
        parent = (JComponent) buttons[0].getParent();
        group = new ButtonGroup();
        for (AbstractButton button : buttons) {
            group.add(button);
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    commit();
                }
            });
        }
    }

    @Override
    protected JComponent createMainComponent(JComponent component) {
        return (component != null) ? component : parent;
    }

    @Override
    @Nullable
    protected String getValue() {
        return parent.isEnabled() ? group.getSelection().getActionCommand() : null;
    }

    @Override
    protected void setValue(@Nullable String value) {
        for (Enumeration<AbstractButton> e = group.getElements(); e.hasMoreElements();) {
            ButtonModel model = e.nextElement().getModel();
            String cmd = model.getActionCommand();
            group.setSelected(model, (value == null) ? ((cmd == null) || (cmd.length() == 0)) : value.equals(cmd));
        }
    }
}
