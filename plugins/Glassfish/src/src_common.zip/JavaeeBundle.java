/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee;

import java.util.ListResourceBundle;
import java.util.ResourceBundle;
import com.intellij.CommonBundle;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.PropertyKey;

public abstract class JavaeeBundle extends ListResourceBundle {

    @NonNls
    private static final String PATH = "resources.javaee";

    private static final ResourceBundle BUNDLE = ResourceBundle.getBundle(PATH);

    public static String get(@PropertyKey(resourceBundle = PATH)String key, Object... params) {
        return CommonBundle.message(BUNDLE, key, params);
    }

    @Override
    protected Object[][] getContents() {
        @NonNls String key = "plugin." + JavaeePlugin.getInstance().getId() + ".description";
        String value = get("Integration.description", getName());
        return new Object[][]{{key, value}};
    }

    @NotNull
    protected abstract String getName();
}
