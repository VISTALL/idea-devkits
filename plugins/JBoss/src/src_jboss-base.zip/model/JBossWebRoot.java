/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.model;

import java.util.List;
import com.intellij.util.xml.GenericDomValue;

@SuppressWarnings({"InterfaceNeverImplemented"})
public interface JBossWebRoot extends JBossReferenceHolder, JBossSecurityRoleHolder {

    GenericDomValue<String> getContextRoot();

    GenericDomValue<String> getSecurityDomain();

    List<GenericDomValue<String>> getVirtualHosts();

    GenericDomValue<Boolean> getUseSessionCookies();
}
