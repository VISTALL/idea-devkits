/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.model;

import java.util.List;
import com.intellij.javaee.model.xml.JavaeeDomModelElement;

@SuppressWarnings({"InterfaceNeverImplemented"})
public interface JBossReferenceHolder extends JavaeeDomModelElement {

    List<JBossEjbRef> getEjbRefs();

    JBossEjbRef addEjbRef();

    List<JBossEjbLocalRef> getEjbLocalRefs();

    JBossEjbLocalRef addEjbLocalRef();

    List<JBossResourceRef> getResourceRefs();

    JBossResourceRef addResourceRef();

    List<JBossResourceEnvRef> getResourceEnvRefs();

    JBossResourceEnvRef addResourceEnvRef();

    List<JBossMessageDestinationRef> getMessageDestinationRefs();

    JBossMessageDestinationRef addMessageDestinationRef();
}
