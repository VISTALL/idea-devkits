/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.model;

@SuppressWarnings({"InterfaceNeverImplemented", "MarkerInterface"})
public interface JBossEjbBean extends JBossReferenceHolder {

}
