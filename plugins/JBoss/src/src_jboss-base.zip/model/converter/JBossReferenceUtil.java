/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.model.converter;

import com.fuhrer.idea.jboss.model.JBossEntityBean;
import com.fuhrer.idea.jboss.model.JBossMessageBean;
import com.fuhrer.idea.jboss.model.JBossSessionBean;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.model.xml.JndiEnvironmentRefsGroup;
import com.intellij.javaee.module.components.EjbModuleProperties;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.util.xml.ConvertContext;
import com.intellij.util.xml.DomElement;
import org.jetbrains.annotations.Nullable;

class JBossReferenceUtil {

    private JBossReferenceUtil() {
    }

    @Nullable
    @SuppressWarnings({"InstanceofIncompatibleInterface", "CastToIncompatibleInterface"})
    static JndiEnvironmentRefsGroup getReferenceHolder(ConvertContext context) {
        JndiEnvironmentRefsGroup holder = null;
        JavaeeModuleProperties properties = JavaeeModuleProperties.getInstance(context.getModule());
        if (properties instanceof WebModuleProperties) {
            holder = ((WebModuleProperties) properties).getRoot();
        } else if (properties instanceof EjbModuleProperties) {
            DomElement parent = context.getInvocationElement().getParent();
            if (parent != null) {
                DomElement element = parent.getParent();
                if (element instanceof JBossEntityBean) {
                    holder = ((JBossEntityBean) element).getEjbName().getValue();
                } else if (element instanceof JBossSessionBean) {
                    holder = ((JBossSessionBean) element).getEjbName().getValue();
                } else if (element instanceof JBossMessageBean) {
                    holder = ((JBossMessageBean) element).getEjbName().getValue();
                }
            }
        }
        return holder;
    }
}
