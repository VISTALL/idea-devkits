/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.model;

import java.util.List;
import com.intellij.javaee.model.xml.JavaeeDomModelElement;

@SuppressWarnings({"InterfaceNeverImplemented"})
public interface JBossPropertyHolder extends JavaeeDomModelElement {

    List<JBossProperty> getProperties();

    JBossProperty addProperty();
}
