/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor;

import com.fuhrer.idea.javaee.editor.JavaeeEditorProvider;
import com.fuhrer.idea.jboss.JBossUtil;
import com.fuhrer.idea.jboss.model.JBossAppRoot;
import com.fuhrer.idea.jboss.model.JBossCmpRoot;
import com.fuhrer.idea.jboss.model.JBossEjbRoot;
import com.fuhrer.idea.jboss.model.JBossWebRoot;
import com.intellij.javaee.application.facet.JavaeeApplicationFacet;
import com.intellij.javaee.ejb.EjbModuleUtil;
import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.javaee.model.xml.ejb.EjbJar;
import com.intellij.javaee.model.xml.ejb.EntityBean;
import com.intellij.javaee.model.xml.ejb.MessageDrivenBean;
import com.intellij.javaee.model.xml.ejb.SessionBean;
import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.xml.ui.PerspectiveFileEditor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class JBossEditorProvider extends JavaeeEditorProvider {

    @Override
    public double getWeight() {
        return 100;
    }

    @Override
    protected boolean acceptAppRoot(@NotNull JavaeeApplicationFacet facet) {
        return JBossUtil.getAppRoot(facet) != null;
    }

    @Override
    protected boolean acceptEjbRoot(@NotNull EjbFacet facet) {
        return (JBossUtil.getEjbRoot(facet) != null) && (JBossUtil.getCmpRoot(facet) != null);
    }

    @Override
    protected boolean acceptWebRoot(@NotNull WebFacet facet) {
        return JBossUtil.getWebRoot(facet) != null;
    }

    @Override
    protected boolean acceptEntityBean(@NotNull EntityBean bean) {
        EjbFacet facet = EjbModuleUtil.getEjbFacet(bean);
        return (JBossUtil.getEjbRoot(facet) != null) && (JBossUtil.getCmpRoot(facet) != null);
    }

    @Override
    protected boolean acceptSessionBean(@NotNull SessionBean bean) {
        return JBossUtil.getEjbRoot(EjbModuleUtil.getEjbFacet(bean)) != null;
    }

    @Override
    protected boolean acceptMessageBean(@NotNull MessageDrivenBean bean) {
        return JBossUtil.getEjbRoot(EjbModuleUtil.getEjbFacet(bean)) != null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createAppRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeApplicationFacet facet) {
        JBossAppRoot root = JBossUtil.getAppRoot(facet);
        return (root != null) ? createEditor(root, new JBossAppRootEditor(facet.getRoot(), root)) : null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createEjbRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull EjbFacet facet) {
        EjbJar xml = facet.getXmlRoot();
        if (xml != null) {
            JBossEjbRoot ejb = JBossUtil.getEjbRoot(facet);
            JBossCmpRoot cmp = JBossUtil.getCmpRoot(facet);
            if ((ejb != null) && (cmp != null)) {
                return new JBossEjbModuleEditor(xml, ejb, cmp).getFileEditor();
            }
        }
        return null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createWebRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull WebFacet facet) {
        JBossWebRoot root = JBossUtil.getWebRoot(facet);
        return (root != null) ? createEditor(root, new JBossWebRootEditor(facet.getRoot(), root)) : null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createEntityBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull EntityBean bean) {
        return new JBossEntityEditor(bean).getFileEditor();
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createSessionBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull SessionBean bean) {
        return new JBossSessionEditor(bean).getFileEditor();
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createMessageBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull MessageDrivenBean bean) {
        return new JBossMessageEditor(bean).getFileEditor();
    }
}
