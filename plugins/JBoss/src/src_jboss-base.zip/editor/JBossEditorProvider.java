/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor;

import com.fuhrer.idea.javaee.editor.JavaeeEditorProvider;
import com.fuhrer.idea.jboss.model.JBossAppRoot;
import com.fuhrer.idea.jboss.model.JBossWebRoot;
import com.fuhrer.idea.jboss.model.JBossEjbRoot;
import com.fuhrer.idea.jboss.model.JBossCmpRoot;
import com.fuhrer.idea.jboss.server.JBossDescriptors;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.model.JavaeeApplicationModel;
import com.intellij.javaee.model.xml.ejb.EntityBean;
import com.intellij.javaee.model.xml.ejb.MessageDrivenBean;
import com.intellij.javaee.model.xml.ejb.SessionBean;
import com.intellij.javaee.model.xml.ejb.EjbJar;
import com.intellij.javaee.module.components.EjbModuleProperties;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.xml.ui.PerspectiveFileEditor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class JBossEditorProvider extends JavaeeEditorProvider {

    @Override
    public double getWeight() {
        return 100;
    }

    @Override
    protected boolean acceptAppRoot(@NotNull JavaeeModuleProperties properties, @NotNull JavaeeApplicationModel model) {
        return JBossDescriptors.getAppRoot(properties.getModule()) != null;
    }

    @Override
    protected boolean acceptEjbRoot(@NotNull JavaeeModuleProperties properties, @NotNull EjbModuleProperties model) {
        Module module = properties.getModule();
        return (JBossDescriptors.getEjbRoot(module) != null) && (JBossDescriptors.getCmpRoot(module) != null);
    }

    @Override
    protected boolean acceptWebRoot(@NotNull JavaeeModuleProperties properties, @NotNull WebModuleProperties model) {
        return JBossDescriptors.getWebRoot(properties.getModule()) != null;
    }

    @Override
    protected boolean acceptEntityBean(@NotNull EntityBean bean) {
        return (JBossDescriptors.getEjbRoot(bean.getModule()) != null) && (JBossDescriptors.getCmpRoot(bean.getModule()) != null);
    }

    @Override
    protected boolean acceptSessionBean(@NotNull SessionBean bean) {
        return JBossDescriptors.getEjbRoot(bean.getModule()) != null;
    }

    @Override
    protected boolean acceptMessageBean(@NotNull MessageDrivenBean bean) {
        return JBossDescriptors.getEjbRoot(bean.getModule()) != null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createAppRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeModuleProperties properties, @NotNull JavaeeApplicationModel model) {
        JBossAppRoot root = JBossDescriptors.getAppRoot(properties.getModule());
        return (root != null) ? createEditor(root, new JBossAppRootEditor(model.getRoot(), root)) : null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createEjbRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeModuleProperties properties, @NotNull EjbModuleProperties model) {
        EjbJar xml = model.getXmlRoot();
        if (xml != null) {
            JBossEjbRoot ejb = JBossDescriptors.getEjbRoot(xml.getModule());
            JBossCmpRoot cmp = JBossDescriptors.getCmpRoot(xml.getModule());
            if ((ejb != null) && (cmp != null)) {
                return new JBossEjbModuleEditor(xml, ejb, cmp).getFileEditor();
            }
        }
        return null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createWebRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeModuleProperties properties, @NotNull WebModuleProperties model) {
        JBossWebRoot root = JBossDescriptors.getWebRoot(properties.getModule());
        return (root != null) ? createEditor(root, new JBossWebRootEditor(model.getRoot(), root)) : null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createEntityBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull EntityBean bean) {
        return new JBossEntityEditor(bean).getFileEditor();
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createSessionBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull SessionBean bean) {
        return new JBossSessionEditor(bean).getFileEditor();
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createMessageBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull MessageDrivenBean bean) {
        return new JBossMessageEditor(bean).getFileEditor();
    }
}
