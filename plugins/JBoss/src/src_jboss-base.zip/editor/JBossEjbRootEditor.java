/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor;

import javax.swing.*;
import com.fuhrer.idea.javaee.editor.JavaeeBaseEditor;
import com.fuhrer.idea.jboss.JBossBundle;
import com.fuhrer.idea.jboss.editor.security.JBossSecurityRolesEditor;
import com.fuhrer.idea.jboss.editor.valueclass.JBossValueClassesEditor;
import com.fuhrer.idea.jboss.model.JBossCmpRoot;
import com.fuhrer.idea.jboss.model.JBossEjbRoot;
import com.intellij.javaee.model.xml.ejb.EjbJar;
import com.intellij.openapi.ui.Splitter;
import org.jetbrains.annotations.NotNull;

class JBossEjbRootEditor extends JavaeeBaseEditor {

    private final Splitter splitter;

    JBossEjbRootEditor(@NotNull EjbJar xml, @NotNull JBossEjbRoot ejb, @NotNull JBossCmpRoot cmp) {
        JTabbedPane pane = new JTabbedPane();
        pane.setBorder(BorderFactory.createTitledBorder(JBossBundle.get("JBossEjbRootEditor.title")));
        addContent(pane, new JBossEjbSettingsEditor(ejb), JBossBundle.get("JBossEjbSettingsEditor.title"));
        addContent(pane, new JBossCmpDefaultsEditor(cmp), JBossBundle.get("JBossCmpDefaultsEditor.title"));
        Splitter right = createSplitter(new JBossValueClassesEditor(cmp), JBossSecurityRolesEditor.get(xml, ejb.getAssemblyDescriptor()), true);
        splitter = createSplitter(pane, right, false);
        setHelpId(splitter, "reference.jbosssettings");
    }

    public JComponent getComponent() {
        return splitter;
    }
}
