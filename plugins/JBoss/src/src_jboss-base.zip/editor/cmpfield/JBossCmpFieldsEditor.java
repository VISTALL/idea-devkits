/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor.cmpfield;

import java.awt.*;
import com.fuhrer.idea.javaee.util.BooleanRenderer;
import com.fuhrer.idea.javaee.util.TreeExpanderImpl;
import com.fuhrer.idea.jboss.JBossBundle;
import com.fuhrer.idea.jboss.model.JBossCmpBean;
import com.intellij.ide.CommonActionsManager;
import com.intellij.javaee.model.xml.ejb.EntityBean;
import com.intellij.javaee.module.view.common.attributes.JavaeeTreeTableView;
import com.intellij.openapi.actionSystem.ActionGroup;
import com.intellij.openapi.actionSystem.DefaultActionGroup;
import com.intellij.util.ui.ColumnInfo;
import com.intellij.util.ui.treetable.TreeColumnInfo;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class JBossCmpFieldsEditor extends JavaeeTreeTableView {

    private final EntityBean bean;

    public JBossCmpFieldsEditor(EntityBean bean, JBossCmpBean cmp) {
        super(cmp.getManager().getProject(), new JBossCmpFieldsNode(bean, cmp));
        this.bean = bean;
        getTreeTableView().setShowVerticalLines(true);
        getTreeTableView().setIntercellSpacing(new Dimension(1, 0));
        getTreeTableView().setDefaultRenderer(Boolean.class, new BooleanRenderer(getTreeTableView()));
        init();
    }

    @Override
    protected boolean isShowTree() {
        return !bean.getCmpFields().isEmpty();
    }

    @Override
    @NotNull
    protected String getEmptyPaneText() {
        return JBossBundle.get("JBossCmpFieldsEditor.empty");
    }

    @Override
    protected ColumnInfo<?, ?>[] createColumnInfos() {
        return new ColumnInfo<?, ?>[]{new TreeColumnInfo(" "), new JBossTableColumn()};
    }

    @Override
    @Nullable
    protected ActionGroup createToolbarActions() {
        DefaultActionGroup actions = new DefaultActionGroup();
        actions.add(CommonActionsManager.getInstance().createExpandAllAction(new TreeExpanderImpl(getTree()), getTree()));
        actions.add(CommonActionsManager.getInstance().createCollapseAllAction(new TreeExpanderImpl(getTree()), getTree()));
        return actions;
    }
}
