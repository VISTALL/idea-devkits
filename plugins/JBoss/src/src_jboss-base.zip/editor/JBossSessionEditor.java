/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor;

import com.fuhrer.idea.javaee.editor.JavaeeMockEditor;
import com.fuhrer.idea.jboss.model.JBossEjbRoot;
import com.fuhrer.idea.jboss.model.JBossSessionBean;
import com.fuhrer.idea.jboss.server.JBossDescriptors;
import com.intellij.javaee.model.xml.ejb.SessionBean;
import com.intellij.util.xml.ui.DomFileEditor;
import com.intellij.util.xml.ui.EditedElementDescription;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class JBossSessionEditor extends JavaeeMockEditor {

    JBossSessionEditor(@NotNull final SessionBean bean) {
        super(bean.getModule());
        JBossSessionBean ejb = addEditedElement(JBossSessionBean.class, new EditedElementDescription<JBossSessionBean>() {
            @Override
            public JBossSessionBean find() {
                return JBossEjbUtil.findSessionBean(JBossDescriptors.getEjbRoot(bean.getModule()), bean);
            }

            @Override
            public void initialize(JBossSessionBean element) {
                element.getEjbName().setValue(bean);
            }

            @Override
            @Nullable
            public JBossSessionBean addElement() {
                JBossEjbRoot root = JBossDescriptors.getEjbRoot(bean.getModule());
                return (root != null) ? root.getEnterpriseBeans().addSessionBean() : null;
            }
        });
        DomFileEditor<?> editor = initEditor(new JBossSessionBeanEditor(bean, ejb), bean);
        editor.addWatchedElement(JBossDescriptors.getEjbRoot(bean.getModule()));
    }
}
