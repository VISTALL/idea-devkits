/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor.valueclass;

import javax.swing.*;
import com.fuhrer.idea.javaee.util.IconLoader;
import com.fuhrer.idea.javaee.util.RowIcon;
import com.intellij.javaee.module.view.nodes.JavaeeNodeDescriptor;
import com.intellij.psi.PsiMethod;
import com.intellij.psi.util.PsiUtil;

class JBossPropertyNode extends JavaeeNodeDescriptor<JBossPropertyDescriptor> {

    private static final int HAS_GETTER = 0x01;

    private static final int HAS_SETTER = 0x02;

    private static final Icon[] PROPERTY_ICONS = createPropertyIcons();

    private static final Icon[] ACCESS_ICONS = createAccessIcons();

    JBossPropertyNode(JBossValueClassNode parent, JBossPropertyDescriptor element) {
        super(parent.getProject(), parent, null, element);
    }

    @Override
    protected String getNewNodeText() {
        return getElement().getName();
    }

    @Override
    protected Icon getNewOpenIcon() {
        PsiMethod getter = getElement().getGetter();
        PsiMethod setter = getElement().getSetter();
        int index = 0;
        int level = 0;
        if (getter != null) {
            index |= HAS_GETTER;
            level = Math.max(level, PsiUtil.getAccessLevel(getter.getModifierList()));
        }
        if (setter != null) {
            index |= HAS_SETTER;
            level = Math.max(level, PsiUtil.getAccessLevel(setter.getModifierList()));
        }
        return (index > 0) ? new RowIcon(PROPERTY_ICONS[index], ACCESS_ICONS[level]) : PROPERTY_ICONS[index];
    }

    @Override
    protected Icon getNewClosedIcon() {
        return getNewOpenIcon();
    }

    private static Icon[] createPropertyIcons() {
        Icon[] icons = new Icon[(HAS_GETTER | HAS_SETTER) + 1];
        icons[0] = IconLoader.get("/nodes/property.png");
        icons[HAS_GETTER] = IconLoader.get("/nodes/propertyRead.png");
        icons[HAS_SETTER] = IconLoader.get("/nodes/propertyWrite.png");
        icons[HAS_GETTER | HAS_SETTER] = IconLoader.get("/nodes/propertyReadWrite.png");
        return icons;
    }

    private static Icon[] createAccessIcons() {
        Icon[] icons = new Icon[PsiUtil.ACCESS_LEVEL_PUBLIC + 1];
        icons[PsiUtil.ACCESS_LEVEL_PRIVATE] = IconLoader.get("/nodes/c_private.png");
        icons[PsiUtil.ACCESS_LEVEL_PACKAGE_LOCAL] = IconLoader.get("/nodes/c_plocal.png");
        icons[PsiUtil.ACCESS_LEVEL_PROTECTED] = IconLoader.get("/nodes/c_protected.png");
        icons[PsiUtil.ACCESS_LEVEL_PUBLIC] = IconLoader.get("/nodes/c_public.png");
        return icons;
    }
}
