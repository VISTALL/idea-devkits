/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor.valueclass;

import javax.swing.*;
import com.fuhrer.idea.javaee.util.IconLoader;
import com.intellij.javaee.module.view.nodes.JavaeeNodeDescriptor;
import com.intellij.psi.PsiMethod;
import com.intellij.ui.RowIcon;
import com.intellij.util.IconUtil;

class JBossPropertyNode extends JavaeeNodeDescriptor<JBossPropertyDescriptor> {

    JBossPropertyNode(JBossValueClassNode parent, JBossPropertyDescriptor element) {
        super(parent.getProject(), parent, null, element);
    }

    @Override
    protected String getNewNodeText() {
        return getElement().getName();
    }

    @Override
    protected Icon getNewOpenIcon() {
        RowIcon icon = new RowIcon(2);
        PsiMethod getter = getElement().getGetter();
        PsiMethod setter = getElement().getSetter();
        if ((getter != null) && (setter != null)) {
            icon.setIcon(IconLoader.get("/nodes/propertyReadWrite.png"), 0);
            IconUtil.setVisibilityIcon(getter.getModifierList(), icon);
        } else if (getter != null) {
            icon.setIcon(IconLoader.get("/nodes/propertyRead.png"), 0);
            IconUtil.setVisibilityIcon(getter.getModifierList(), icon);
        } else if (setter != null) {
            icon.setIcon(IconLoader.get("/nodes/propertyWrite.png"), 0);
            IconUtil.setVisibilityIcon(setter.getModifierList(), icon);
        } else {
            icon.setIcon(IconLoader.getTransparent("/nodes/property.png"), 0);
            IconUtil.setVisibilityIcon(null, icon);
        }
        return icon;
    }

    @Override
    protected Icon getNewClosedIcon() {
        return getNewOpenIcon();
    }
}
