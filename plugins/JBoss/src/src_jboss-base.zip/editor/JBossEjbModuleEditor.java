/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor;

import com.fuhrer.idea.javaee.editor.JavaeeMockEditor;
import com.fuhrer.idea.jboss.model.JBossCmpRoot;
import com.fuhrer.idea.jboss.model.JBossEjbRoot;
import com.intellij.javaee.model.xml.ejb.EjbJar;
import com.intellij.util.xml.ui.DomFileEditor;
import org.jetbrains.annotations.NotNull;

class JBossEjbModuleEditor extends JavaeeMockEditor {

    JBossEjbModuleEditor(@NotNull EjbJar xml, @NotNull JBossEjbRoot ejb, @NotNull JBossCmpRoot cmp) {
        super(xml.getModule());
        DomFileEditor<?> editor = initEditor(new JBossEjbRootEditor(xml, ejb, cmp), ejb);
        editor.addWatchedElement(ejb);
        editor.addWatchedElement(cmp);
    }
}
