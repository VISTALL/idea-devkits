/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor;

import com.fuhrer.idea.javaee.editor.JavaeeMockEditor;
import com.fuhrer.idea.jboss.model.JBossEjbRoot;
import com.fuhrer.idea.jboss.model.JBossMessageBean;
import com.fuhrer.idea.jboss.server.JBossDescriptors;
import com.intellij.javaee.model.xml.ejb.MessageDrivenBean;
import com.intellij.util.xml.ui.DomFileEditor;
import com.intellij.util.xml.ui.EditedElementDescription;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class JBossMessageEditor extends JavaeeMockEditor {

    JBossMessageEditor(@NotNull final MessageDrivenBean bean) {
        super(bean.getModule());
        JBossMessageBean ejb = addEditedElement(JBossMessageBean.class, new EditedElementDescription<JBossMessageBean>() {
            @Override
            public JBossMessageBean find() {
                return JBossEjbUtil.findMessageBean(JBossDescriptors.getEjbRoot(bean.getModule()), bean);
            }

            @Override
            public void initialize(JBossMessageBean element) {
                element.getEjbName().setValue(bean);
            }

            @Override
            @Nullable
            public JBossMessageBean addElement() {
                JBossEjbRoot root = JBossDescriptors.getEjbRoot(bean.getModule());
                return (root != null) ? root.getEnterpriseBeans().addMessageBean() : null;
            }
        });
        DomFileEditor<?> editor = initEditor(new JBossMessageBeanEditor(bean, ejb), bean);
        editor.addWatchedElement(JBossDescriptors.getEjbRoot(bean.getModule()));
        editor.addWatchedElement(JBossDescriptors.getCmpRoot(bean.getModule()));
    }
}
