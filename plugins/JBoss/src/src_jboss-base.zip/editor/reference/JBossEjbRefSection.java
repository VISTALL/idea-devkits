/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor.reference;

import java.util.ArrayList;
import java.util.List;
import com.fuhrer.idea.javaee.editor.JavaeeSection;
import com.fuhrer.idea.javaee.editor.JavaeeSectionInfo;
import com.fuhrer.idea.javaee.editor.JavaeeSectionInfoEditable;
import com.fuhrer.idea.jboss.model.JBossEjbRef;
import com.fuhrer.idea.jboss.model.JBossReferenceHolder;
import com.fuhrer.idea.jboss.JBossBundle;
import com.intellij.javaee.model.xml.EjbRef;
import com.intellij.javaee.model.xml.JndiEnvironmentRefsGroup;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.Nullable;

class JBossEjbRefSection implements JavaeeSection<EjbRef> {

    private final JndiEnvironmentRefsGroup group;

    private final JBossReferenceHolder holder;

    JBossEjbRefSection(JndiEnvironmentRefsGroup group, JBossReferenceHolder holder) {
        this.group = group;
        this.holder = holder;
    }

    public List<JavaeeSectionInfo<EjbRef>> getColumnInfos() {
        List<JavaeeSectionInfo<EjbRef>> columns = new ArrayList<JavaeeSectionInfo<EjbRef>>();
        columns.add(new JavaeeSectionInfo<EjbRef>(JBossBundle.get("JBossReferenceEditor.ejb.remote")) {
            @Override
            public String valueOf(EjbRef source) {
                return source.getEjbRefName().getValue();
            }
        });
        columns.add(new JavaeeSectionInfoEditable<EjbRef>(JBossBundle.get("JBossReferenceEditor.jndi.name"), holder) {
            @Override
            @Nullable
            public String valueOf(EjbRef source) {
                JBossEjbRef target = JBossReferenceUtil.findEjbRef(holder, source);
                return (target == null) ? null : target.getJndiName().getValue();
            }

            @Override
            protected void write(EjbRef source, String value) {
                JBossEjbRef target = JBossReferenceUtil.findEjbRef(holder, source);
                if (!StringUtil.isEmpty(value)) {
                    if (target == null) {
                        target = holder.addEjbRef();
                        target.getEjbRefName().setValue(source);
                    }
                    target.getJndiName().setValue(value);
                } else if (target != null) {
                    target.undefine();
                }
            }
        });
        return columns;
    }

    public List<EjbRef> getValues() {
        return group.getEjbRefs();
    }
}
