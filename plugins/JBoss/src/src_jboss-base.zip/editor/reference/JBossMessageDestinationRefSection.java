/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor.reference;

import java.util.ArrayList;
import java.util.List;
import com.fuhrer.idea.javaee.editor.JavaeeSection;
import com.fuhrer.idea.javaee.editor.JavaeeSectionInfo;
import com.fuhrer.idea.javaee.editor.JavaeeSectionInfoEditable;
import com.fuhrer.idea.jboss.model.JBossMessageDestinationRef;
import com.fuhrer.idea.jboss.model.JBossReferenceHolder;
import com.fuhrer.idea.jboss.JBossBundle;
import com.intellij.javaee.model.xml.JndiEnvironmentRefsGroup;
import com.intellij.javaee.model.xml.MessageDestinationRef;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.Nullable;

class JBossMessageDestinationRefSection implements JavaeeSection<MessageDestinationRef> {

    private final JndiEnvironmentRefsGroup group;

    private final JBossReferenceHolder holder;

    JBossMessageDestinationRefSection(JndiEnvironmentRefsGroup group, JBossReferenceHolder holder) {
        this.group = group;
        this.holder = holder;
    }

    public List<JavaeeSectionInfo<MessageDestinationRef>> getColumnInfos() {
        List<JavaeeSectionInfo<MessageDestinationRef>> columns = new ArrayList<JavaeeSectionInfo<MessageDestinationRef>>();
        columns.add(new JavaeeSectionInfo<MessageDestinationRef>(JBossBundle.get("JBossReferenceEditor.message.destination")) {
            @Override
            public String valueOf(MessageDestinationRef source) {
                return source.getMessageDestinationRefName().getValue();
            }
        });
        columns.add(new JavaeeSectionInfoEditable<MessageDestinationRef>(JBossBundle.get("JBossReferenceEditor.jndi.name"), holder) {
            @Override
            @Nullable
            public String valueOf(MessageDestinationRef source) {
                JBossMessageDestinationRef target = JBossReferenceUtil.findMessageDestinationRef(holder, source);
                return (target == null) ? null : target.getJndiName().getValue();
            }

            @Override
            protected void write(MessageDestinationRef source, String value) {
                JBossMessageDestinationRef target = JBossReferenceUtil.findMessageDestinationRef(holder, source);
                if (!StringUtil.isEmpty(value)) {
                    if (target == null) {
                        target = holder.addMessageDestinationRef();
                        target.getMessageDestinationRefName().setValue(source);
                    }
                    target.getJndiName().setValue(value);
                } else if (target != null) {
                    target.undefine();
                }
            }
        });
        return columns;
    }

    public List<MessageDestinationRef> getValues() {
        return group.getMessageDestinationRefs();
    }
}
