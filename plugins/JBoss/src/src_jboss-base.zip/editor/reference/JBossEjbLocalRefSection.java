/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor.reference;

import java.util.ArrayList;
import java.util.List;
import com.fuhrer.idea.javaee.editor.JavaeeSection;
import com.fuhrer.idea.javaee.editor.JavaeeSectionInfo;
import com.fuhrer.idea.javaee.editor.JavaeeSectionInfoEditable;
import com.fuhrer.idea.jboss.model.JBossEjbLocalRef;
import com.fuhrer.idea.jboss.model.JBossReferenceHolder;
import com.fuhrer.idea.jboss.JBossBundle;
import com.intellij.javaee.model.xml.EjbLocalRef;
import com.intellij.javaee.model.xml.JndiEnvironmentRefsGroup;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.Nullable;

class JBossEjbLocalRefSection implements JavaeeSection<EjbLocalRef> {

    private final JndiEnvironmentRefsGroup group;

    private final JBossReferenceHolder holder;

    JBossEjbLocalRefSection(JndiEnvironmentRefsGroup group, JBossReferenceHolder holder) {
        this.group = group;
        this.holder = holder;
    }

    public List<JavaeeSectionInfo<EjbLocalRef>> getColumnInfos() {
        List<JavaeeSectionInfo<EjbLocalRef>> columns = new ArrayList<JavaeeSectionInfo<EjbLocalRef>>();
        columns.add(new JavaeeSectionInfo<EjbLocalRef>(JBossBundle.get("JBossReferenceEditor.ejb.local")) {
            @Override
            public String valueOf(EjbLocalRef source) {
                return source.getEjbRefName().getValue();
            }
        });
        columns.add(new JavaeeSectionInfoEditable<EjbLocalRef>(JBossBundle.get("JBossReferenceEditor.jndi.name"), holder) {
            @Override
            @Nullable
            public String valueOf(EjbLocalRef source) {
                JBossEjbLocalRef target = JBossReferenceUtil.findEjbLocalRef(holder, source);
                return (target == null) ? null : target.getLocalJndiName().getValue();
            }

            @Override
            protected void write(EjbLocalRef source, String value) {
                JBossEjbLocalRef target = JBossReferenceUtil.findEjbLocalRef(holder, source);
                if (!StringUtil.isEmpty(value)) {
                    if (target == null) {
                        target = holder.addEjbLocalRef();
                        target.getEjbRefName().setValue(source);
                    }
                    target.getLocalJndiName().setValue(value);
                } else if (target != null) {
                    target.undefine();
                }
            }
        });
        return columns;
    }

    public List<EjbLocalRef> getValues() {
        return group.getEjbLocalRefs();
    }
}
