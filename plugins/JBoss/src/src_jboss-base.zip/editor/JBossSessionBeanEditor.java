/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor;

import javax.swing.*;
import com.fuhrer.idea.javaee.editor.JavaeeBaseEditor;
import com.fuhrer.idea.jboss.editor.reference.JBossReferenceEditor;
import com.fuhrer.idea.jboss.model.JBossSessionBean;
import com.intellij.javaee.model.xml.ejb.SessionBean;
import com.intellij.openapi.ui.Splitter;

class JBossSessionBeanEditor extends JavaeeBaseEditor {

    private final Splitter splitter;

    JBossSessionBeanEditor(SessionBean bean, JBossSessionBean ejb) {
        splitter = createSplitter(new JBossBeanSettingsEditor(ejb), new JBossReferenceEditor(bean, ejb), false);
        setHelpId(splitter, "reference.jbosssettings");
    }

    public JComponent getComponent() {
        return splitter;
    }
}
