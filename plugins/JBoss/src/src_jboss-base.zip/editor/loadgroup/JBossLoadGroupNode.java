/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor.loadgroup;

import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import com.fuhrer.idea.javaee.util.IconLoader;
import com.fuhrer.idea.jboss.model.JBossLoadGroup;
import com.intellij.javaee.model.xml.ejb.CmpField;
import com.intellij.javaee.model.xml.ejb.EntityBean;
import com.intellij.javaee.module.view.nodes.JavaeeNodeDescriptor;
import com.intellij.javaee.module.view.nodes.JavaeeObjectDescriptor;

class JBossLoadGroupNode extends JavaeeObjectDescriptor<JBossLoadGroup> {

    private final EntityBean bean;

    JBossLoadGroupNode(JavaeeNodeDescriptor<?> parent, EntityBean bean, JBossLoadGroup group) {
        super(group, parent, null);
        this.bean = bean;
    }

    @Override
    protected String getNewNodeText() {
        return getElement().getLoadGroupName().getValue();
    }

    @Override
    protected Icon getNewOpenIcon() {
        return IconLoader.get("/javaee/persistenceEntity.png");
    }

    @Override
    protected Icon getNewClosedIcon() {
        return getNewOpenIcon();
    }

    @Override
    public JavaeeNodeDescriptor<?>[] getChildren() {
        List<JavaeeNodeDescriptor<?>> list = new ArrayList<JavaeeNodeDescriptor<?>>();
        for (CmpField field : bean.getCmpFields()) {
            list.add(new JBossCmpFieldNode(this, field));
        }
        return list.toArray(new JavaeeNodeDescriptor[list.size()]);
    }

    @Override
    public boolean expandOnDoubleClick() {
        return false;
    }
}
