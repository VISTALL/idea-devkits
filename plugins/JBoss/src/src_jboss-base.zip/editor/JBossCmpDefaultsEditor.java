/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.editor;

import javax.swing.*;
import com.fuhrer.idea.javaee.editor.JavaeeEnableEditor;
import com.fuhrer.idea.jboss.JBossBundle;
import com.fuhrer.idea.jboss.model.JBossCmpRoot;
import com.fuhrer.idea.jboss.model.JBossDbDefaults;
import org.jetbrains.annotations.NotNull;

class JBossCmpDefaultsEditor extends JavaeeEnableEditor<JBossDbDefaults, JBossCmpRoot> {

    JBossCmpDefaultsEditor(@NotNull JBossCmpRoot root) {
        super(JBossBundle.get("JBossCmpDefaultsEditor.title"), root);
        JTabbedPane pane = new JTabbedPane();
        addContent(pane, new JBossDbDefaultsEditor(getElement()), JBossBundle.get("JBossDbDefaultsEditor.title"));
        addContent(pane, new JBossUnknownPkEditor(getElement()), JBossBundle.get("JBossUnknownPkEditor.title"));
        addContent(pane, new JBossDbReadAheadEditor(getElement()), JBossBundle.get("JBossDbReadAheadEditor.title"));
        setContent(pane);
    }

    @Override
    protected JBossDbDefaults createElement(@NotNull JBossCmpRoot parent) {
        return parent.getDefaults();
    }
}
