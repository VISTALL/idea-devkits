/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.server;

import java.io.File;
import java.util.List;
import com.fuhrer.idea.javaee.server.JavaeeServerModel;
import com.fuhrer.idea.jboss.JBossBundle;
import com.fuhrer.idea.jboss.model.JBossWebRoot;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.execution.configurations.RuntimeConfigurationError;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.deployment.DeploymentManager;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentSource;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NonNls;

abstract class JBossServerModel extends JavaeeServerModel {

    @Override
    public void checkConfiguration() throws RuntimeConfigurationException {
        if (StringUtil.isNotEmpty(USERNAME) && StringUtil.isEmpty(PASSWORD)) {
            throw new RuntimeConfigurationError(JBossBundle.get("JBossServerModel.error.password"));
        }
        for (Module module : getCommonModel().getModules()) {
            DeploymentModel deployment = getCommonModel().getDeploymentModel(JavaeeModuleProperties.getInstance(module));
            File source = DeploymentManager.getInstance(getCommonModel().getProject()).getDeploymentSource(deployment);
            if ((source != null) && !JBossExtensions.getInstance().isValidExtension(module, source)) {
                throw new RuntimeConfigurationException(JBossBundle.get("JBossServerModel.error.extension", module.getName()));
            }
        }
    }

    @Override
    protected boolean isDeploymentSourceSupported(DeploymentSource source) {
        return true;
    }

    @Override
    @NonNls
    protected String getDefaultUsername() {
        return "";
    }

    @Override
    @NonNls
    protected String getDefaultPassword() {
        return "";
    }

    @Override
    @NonNls
    protected String getServerName() {
        return "com.fuhrer.idea.jboss.server.JBossServer";
    }

    @Override
    protected List<File> getLibraries() {
        List<File> libraries = super.getLibraries();
        libraries.add(new File(getHome(), "client/jbossall-client.jar"));
        return libraries;
    }

    @Override
    protected List<String> getExcludes() {
        List<String> excludes = super.getExcludes();
        excludes.add(JBossDescriptors.class.getName());
        excludes.add(JBossWebRoot.class.getName());
        return excludes;
    }
}
