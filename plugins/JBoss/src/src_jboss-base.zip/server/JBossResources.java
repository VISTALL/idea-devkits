/*
 * Copyright (c) 2008 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.server;

import com.fuhrer.idea.javaee.descriptor.JavaeeResources;
import com.fuhrer.idea.javaee.util.FileWrapper;
import org.jetbrains.annotations.NotNull;

class JBossResources extends JavaeeResources {

    @Override
    @NotNull
    protected String getResourceUri(FileWrapper file) throws Exception {
        return "http://www.jboss.org/j2ee/dtd/" + file.getName();
    }
}
