/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.server;

import java.io.File;
import javax.swing.*;
import com.intellij.openapi.options.ConfigurationException;
import com.fuhrer.idea.javaee.server.JavaeeRunSettingsEditor;
import org.jetbrains.annotations.NotNull;

class JBossLocalEditor extends JavaeeRunSettingsEditor<JBossLocalModel> {

    private JPanel panel;

    private JComboBox server;

    @Override
    @NotNull
    protected JComponent createAdditionalEditor() {
        return panel;
    }

    @Override
    protected void resetEditorFrom(JBossLocalModel model) {
        super.resetEditorFrom(model);
        server.removeAllItems();
        File[] files = new File(model.getHome(), "server").listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    server.addItem(file.getName());
                }
            }
        }
        server.setSelectedItem(null);
        server.setSelectedItem(model.SERVER);
    }

    @Override
    protected void applyEditorTo(JBossLocalModel model) throws ConfigurationException {
        super.applyEditorTo(model);
        model.SERVER = (String) server.getSelectedItem();
    }
}
