/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.server;

import java.io.File;
import java.util.*;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleType;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.NamedJDOMExternalizable;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.openapi.util.io.FileUtil;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

class JBossExtensions implements ApplicationComponent, NamedJDOMExternalizable {

    private final Map<ModuleType<?>, String> types = new HashMap<ModuleType<?>, String>();

    private final Map<String, Set<String>> extensions = new HashMap<String, Set<String>>();

    static JBossExtensions getInstance() {
        return ApplicationManager.getApplication().getComponent(JBossExtensions.class);
    }

    @NonNls
    @NotNull
    public String getComponentName() {
        return getClass().getSimpleName();
    }

    public void initComponent() {
        initialize("app", ModuleType.J2EE_APPLICATION, "ear");
        initialize("ejb", ModuleType.EJB, "jar", "sar", "har", "beans", "spring");
        initialize("web", ModuleType.WEB, "war");
    }

    public void disposeComponent() {
    }

    @NonNls
    public String getExternalFileName() {
        return "jboss.extensions";
    }

    public void readExternal(Element element) throws InvalidDataException {
        for (Element child : (Iterable<? extends Element>) element.getChildren("entry")) {
            String id = child.getAttributeValue("type");
            if (!extensions.containsKey(id)) {
                extensions.put(id, new HashSet<String>());
            }
            extensions.get(id).add(child.getAttributeValue("extension"));
        }
    }

    public void writeExternal(Element element) throws WriteExternalException {
        for (Map.Entry<String, Set<String>> entry : extensions.entrySet()) {
            for (String extension : entry.getValue()) {
                Element child = new Element("entry");
                child.setAttribute("type", entry.getKey());
                child.setAttribute("extension", extension);
                element.addContent(child);
            }
        }
    }

    boolean isValidExtension(Module module, File file) {
        Set<String> set = extensions.get(types.get(module.getModuleType()));
        return (set != null) && set.contains(FileUtil.getExtension(file.getName()));
    }

    private void initialize(@NonNls String id, ModuleType<?> type, @NonNls String... extension) {
        types.put(type, id);
        if (!extensions.containsKey(id)) {
            extensions.put(id, new HashSet<String>(Arrays.asList(extension)));
        }
    }
}
