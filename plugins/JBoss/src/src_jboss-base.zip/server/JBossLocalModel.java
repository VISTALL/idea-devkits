/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.server;

import java.util.HashMap;
import java.util.Map;
import com.fuhrer.idea.jboss.JBossBundle;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NonNls;

class JBossLocalModel extends JBossServerModel {

    private static final Map<Pair<String, String>, JBossPortConfig> config = new HashMap<Pair<String, String>, JBossPortConfig>();

    @NonNls
    @SuppressWarnings({"PublicField", "InstanceVariableNamingConvention", "NonConstantFieldWithUpperCaseName"})
    public String SERVER = "";

    public SettingsEditor<CommonModel> getEditor() {
        return new JBossLocalEditor();
    }

    @Override
    public void checkConfiguration() throws RuntimeConfigurationException {
        if (StringUtil.isEmpty(SERVER)) {
            throw new RuntimeConfigurationException(JBossBundle.get("JBossLocalModel.error.missing"));
        }
        if (getServerPort() <= 0) {
            throw new RuntimeConfigurationException(JBossBundle.get("JBossLocalModel.error.invalid"));
        }
        super.checkConfiguration();
    }

    @Override
    protected int getServerPort() {
        int port = 0;
        String home = getHome();
        if (StringUtil.isNotEmpty(home) && StringUtil.isNotEmpty(SERVER)) {
            Pair<String, String> key = new Pair<String, String>(home, SERVER);
            JBossPortConfig entry = config.get(key);
            if (entry == null) {
                entry = new JBossPortConfig(home, SERVER);
                config.put(key, entry);
            }
            port = entry.getPort();
        }
        return port;
    }
}
