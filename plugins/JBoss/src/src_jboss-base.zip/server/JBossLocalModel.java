/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.server;

import java.io.File;
import com.fuhrer.idea.jboss.JBossBundle;
import com.intellij.execution.configurations.RuntimeConfigurationError;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

class JBossLocalModel extends JBossServerModel {

    @NonNls
    @SuppressWarnings({"PublicField", "InstanceVariableNamingConvention", "NonConstantFieldWithUpperCaseName"})
    public String SERVER = "";

    public SettingsEditor<CommonModel> getEditor() {
        return new JBossLocalEditor();
    }

    @Override
    public void checkConfiguration() throws RuntimeConfigurationException {
        if (StringUtil.isEmpty(SERVER)) {
            throw new RuntimeConfigurationError(JBossBundle.get("JBossLocalModel.error.missing"));
        }
        if (getServerPort() <= 0) {
            throw new RuntimeConfigurationError(JBossBundle.get("JBossLocalModel.error.invalid"));
        }
        super.checkConfiguration();
    }

    @Override
    protected int getServerPort() {
        return JBossPortConfig.get(this);
    }

    @Nullable
    protected String getLogFilePath(String home) {
        return new File(home, "server/" + SERVER + "/log/server.log").getAbsolutePath();
    }
}
