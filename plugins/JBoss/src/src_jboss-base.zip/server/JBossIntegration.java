/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.server;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import javax.swing.*;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptorType;
import com.fuhrer.idea.javaee.server.JavaeeFile;
import com.fuhrer.idea.javaee.server.JavaeeIntegration;
import com.fuhrer.idea.javaee.server.JavaeeInspection;
import com.fuhrer.idea.javaee.util.IconLoader;
import com.fuhrer.idea.jboss.JBossBundle;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class JBossIntegration extends JavaeeIntegration {

    @Override
    @NotNull
    public String getName() {
        return JBossBundle.get("JBossIntegration.name");
    }

    @Override
    @NotNull
    public Icon getIcon() {
        return IconLoader.get("/resources/jboss.png");
    }

    @Override
    @NotNull
    public Icon getBigIcon() {
        return IconLoader.get("/resources/jbossbig.png");
    }

    @Override
    @NotNull
    @NonNls
    protected String getResourceUri(JavaeeFile file) {
        return "http://www.jboss.org/j2ee/dtd/" + file.getName();
    }

    @Override
    @Nullable
    @NonNls
    protected String getNameFromTemplate(String template) {
        return template.split("_")[0];
    }

    @Override
    @Nullable
    @NonNls
    protected String getVersionFromTemplate(String template) {
        return template.replaceAll("[\\w-]+_(\\d)_(\\d)\\.xml", "$1.$2");
    }

    @Override
    protected void registerDescriptorTypes(Map<String, JavaeeDescriptorType> types) {
        types.put("jboss-app.xml", JavaeeDescriptorType.APP);
        types.put("jboss.xml", JavaeeDescriptorType.EJB);
        types.put("jbosscmp-jdbc.xml", JavaeeDescriptorType.CMP);
        types.put("jboss-web.xml", JavaeeDescriptorType.WEB);
    }

    @Override
    @NotNull
    protected String getServerVersion(String home) throws Exception {
        File file = new File(new File(home, "bin"), "run.jar");
        Attributes attributes = new JarFile(file).getManifest().getMainAttributes();
        return attributes.getValue(Attributes.Name.IMPLEMENTATION_VERSION).split(" ")[0];
    }

    @Override
    protected void addLibraryLocations(String home, List<File> locations) {
        File[] files = new File(home, "server").listFiles();
        if (files != null) {
            for (File server : files) {
                locations.add(new File(server, "lib"));
                locations.add(new File(server, "deploy"));
            }
        }
    }

    @Override
    @NotNull
    protected Class<? extends JavaeeInspection> getInspectionClass() {
        return JBossInspection.class;
    }
}
