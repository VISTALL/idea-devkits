/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.server;

import java.io.File;
import com.fuhrer.idea.javaee.server.JavaeePortConfig;
import com.intellij.openapi.util.JDOMUtil;
import org.jdom.Document;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;

class JBossPortConfig extends JavaeePortConfig {

    private final String home;

    private final File config;

    private final File naming1;

    private final File naming2;

    private final File binding;

    private File bindings;

    JBossPortConfig(String home, String server) {
        this.home = home;
        File base = new File(new File(home, "server"), server);
        config = new File(base, "conf/jboss-service.xml");
        naming1 = new File(base, "deploy/naming-service.xml");
        naming2 = new File(base, "deploy/naming.sar/META-INF/jboss-service.xml");
        binding = new File(base, "deploy/binding-service.xml");
    }

    @Override
    protected long getStamp() {
        return getStamp(config) ^ getStamp(naming1) ^ getStamp(naming2) ^ getStamp(binding) ^ getStamp(bindings);
    }

    @Override
    protected int findPort() {
        int port = findPort1(config);
        if (port <= 0) {
            port = findPort2(config);
            if (port <= 0) {
                port = findPort1(binding);
                if (port <= 0) {
                    port = findPort2(naming1);
                    if (port <= 0) {
                        port = findPort2(naming2);
                    }
                }
            }
        }
        return port;
    }

    private int findPort1(File file) {
        try {
            Document doc = JDOMUtil.loadDocument(file);
            Element bean = findElement(doc.getRootElement(), "mbean", "name", "jboss.system:service=ServiceBindingManager");
            if (bean != null) {
                Element attribute = findElement(bean, "attribute", "name", "StoreURL");
                if (attribute != null) {
                    bindings = new File(attribute.getTextTrim().replace("${jboss.home.url}", home));
                    Element name = findElement(bean, "attribute", "name", "ServerName");
                    if (bindings.exists() && (name != null)) {
                        return findPort3(bindings, name.getTextTrim());
                    }
                }
            }
        } catch (Exception e) {
            // ignore...
        }
        return 0;
    }

    private int findPort2(File file) {
        try {
            Document doc = JDOMUtil.loadDocument(file);
            Element bean = findElement(doc.getRootElement(), "mbean", "name", "jboss:service=Naming");
            if (bean != null) {
                Element attribute = findElement(bean, "attribute", "name", "Port");
                if (attribute != null) {
                    return Integer.parseInt(attribute.getTextTrim());
                }
            }
        } catch (Exception e) {
            // ignore...
        }
        return 0;
    }

    private int findPort3(File file, @NonNls String name) {
        try {
            Document doc = JDOMUtil.loadDocument(file);
            Element server = findElement(doc.getRootElement(), "server", "name", name);
            if (server != null) {
                Element service = findElement(server, "service-config", "name", "jboss:service=Naming");
                if (service != null) {
                    return Integer.parseInt(service.getChild("binding").getAttributeValue("port"));
                }
            }
        } catch (Exception e) {
            // ignore...
        }
        return 0;
    }
}
