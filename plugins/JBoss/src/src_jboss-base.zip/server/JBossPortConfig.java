/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.server;

import java.awt.*;
import java.io.File;
import com.fuhrer.idea.javaee.server.JavaeePortConfig;
import com.fuhrer.idea.javaee.server.JavaeeServerModel;
import com.intellij.openapi.util.JDOMUtil;
import org.jdom.Document;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

class JBossPortConfig extends JavaeePortConfig {

    private static final Factory<JBossLocalModel> FACTORY = factory();

    private final String home;

    private final File config;

    private final File naming1;

    private final File naming2;

    private final File binding;

    private File bindings;

    private boolean argsUsed;

    private JBossPortConfig(String home, String server) {
        this.home = home;
        File base = new File(new File(home, "server"), server);
        config = new File(base, "conf/jboss-service.xml");
        naming1 = new File(base, "deploy/naming-service.xml");
        naming2 = new File(base, "deploy/naming.sar/META-INF/jboss-service.xml");
        binding = new File(base, "deploy/binding-service.xml");
    }

    @Override
    protected long getStamp(JavaeeServerModel model) {
        long stamp = getStamp(config) ^ getStamp(naming1) ^ getStamp(naming2) ^ getStamp(binding) ^ getStamp(bindings);
        if (argsUsed) {
            stamp ^= getStamp(model.getVmArguments());
        }
        return stamp;
    }

    @Override
    protected int findPort(JavaeeServerModel model) {
        Toolkit.getDefaultToolkit().beep();
        int port = findPort1(config, model);
        if (port <= 0) {
            port = findPort2(config, model);
            if (port <= 0) {
                port = findPort1(binding, model);
                if (port <= 0) {
                    port = findPort2(naming1, model);
                    if (port <= 0) {
                        port = findPort2(naming2, model);
                    }
                }
            }
        }
        return port;
    }

    private int findPort1(File file, JavaeeServerModel model) {
        if (file.exists()) {
            try {
                Document doc = JDOMUtil.loadDocument(file);
                Element bean = findElement(doc.getRootElement(), "mbean", "name", "jboss.system:service=ServiceBindingManager");
                if (bean != null) {
                    Element attribute = findElement(bean, "attribute", "name", "StoreURL");
                    if (attribute != null) {
                        bindings = new File(attribute.getTextTrim().replace("${jboss.home.url}", home));
                        Element name = findElement(bean, "attribute", "name", "ServerName");
                        if (bindings.exists() && (name != null)) {
                            return findPort3(bindings, name.getTextTrim(), model);
                        }
                    }
                }
            } catch (Exception ignore) {
            }
        }
        return 0;
    }

    private int findPort2(File file, JavaeeServerModel model) {
        if (file.exists()) {
            try {
                Document doc = JDOMUtil.loadDocument(file);
                Element bean = findElement(doc.getRootElement(), "mbean", "name", "jboss:service=Naming");
                if (bean != null) {
                    Element attribute = findElement(bean, "attribute", "name", "Port");
                    if (attribute != null) {
                        return parse(attribute.getTextTrim(), model);
                    }
                }
            } catch (Exception ignore) {
            }
        }
        return 0;
    }

    private int findPort3(File file, @NonNls String name, JavaeeServerModel model) {
        if (file.exists()) {
            try {
                Document doc = JDOMUtil.loadDocument(file);
                Element server = findElement(doc.getRootElement(), "server", "name", name);
                if (server != null) {
                    Element service = findElement(server, "service-config", "name", "jboss:service=Naming");
                    if (service != null) {
                        return parse(service.getChild("binding").getAttributeValue("port"), model);
                    }
                }
            } catch (Exception ignore) {
            }
        }
        return 0;
    }

    private int parse(String value, JavaeeServerModel model) {
        int port = 0;
        try {
            port = Integer.parseInt(value);
            argsUsed = false;
        } catch (NumberFormatException e) {
            if (value.startsWith("${") && value.endsWith("}")) {
                argsUsed = true;
                @NonNls String prefix = "-D" + value.substring(2, value.length() - 1) + '=';
                for (String arg : model.getVmArguments().split("\\s+")) {
                    if (arg.startsWith(prefix)) {
                        port = Integer.parseInt(arg.substring(prefix.length()));
                    }
                }
            }
        }
        return port;
    }

    static int get(JBossLocalModel model) {
        return get(FACTORY, model, 0);
    }

    private static Factory<JBossLocalModel> factory() {
        return new Factory<JBossLocalModel>() {
            @NotNull
            public Key createKey(JBossLocalModel model) {
                return new Key(model.getHome(), model.SERVER);
            }

            @NotNull
            public JavaeePortConfig createConfig(JBossLocalModel model) {
                return new JBossPortConfig(model.getHome(), model.SERVER);
            }
        };
    }
}
