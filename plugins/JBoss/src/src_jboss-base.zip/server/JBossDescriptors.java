/*
* Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
*/

package com.fuhrer.idea.jboss.server;

import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptorType;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptors;
import com.fuhrer.idea.jboss.model.JBossAppRoot;
import com.fuhrer.idea.jboss.model.JBossCmpRoot;
import com.fuhrer.idea.jboss.model.JBossEjbRoot;
import com.fuhrer.idea.jboss.model.JBossWebRoot;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

public class JBossDescriptors extends JavaeeDescriptors {

    JBossDescriptors(Project project) {
        super(project);
    }

    @Nullable
    public static JBossAppRoot getAppRoot(@Nullable Module module) {
        return (module != null) ? getInstance(module).getAppRoot(module, JBossAppRoot.class) : null;
    }

    @Nullable
    public static JBossEjbRoot getEjbRoot(@Nullable Module module) {
        return (module != null) ? getInstance(module).getEjbRoot(module, JBossEjbRoot.class) : null;
    }

    @Nullable
    public static JBossCmpRoot getCmpRoot(@Nullable Module module) {
        return (module != null) ? getInstance(module).getCmpRoot(module, JBossCmpRoot.class) : null;
    }

    @Nullable
    public static JBossWebRoot getWebRoot(@Nullable Module module) {
        return (module != null) ? getInstance(module).getWebRoot(module, JBossWebRoot.class) : null;
    }

    @NotNull
    private static JBossDescriptors getInstance(@NotNull Module module) {
        return module.getProject().getComponent(JBossDescriptors.class);
    }

    @Override
    protected void registerFileDescriptions() {
        register(JBossAppRoot.class, JavaeeDescriptorType.APP);
        register(JBossEjbRoot.class, JavaeeDescriptorType.EJB);
        register(JBossCmpRoot.class, JavaeeDescriptorType.CMP);
        register(JBossWebRoot.class, JavaeeDescriptorType.WEB);
    }
}
