/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.server;

import com.fuhrer.idea.javaee.server.JavaeeInspection;
import com.fuhrer.idea.jboss.model.JBossAppRoot;
import com.fuhrer.idea.jboss.model.JBossCmpRoot;
import com.fuhrer.idea.jboss.model.JBossEjbRoot;
import com.fuhrer.idea.jboss.model.JBossWebRoot;

class JBossInspection extends JavaeeInspection {

    JBossInspection() {
        super(JBossAppRoot.class, JBossEjbRoot.class, JBossCmpRoot.class, JBossWebRoot.class);
    }
}
