/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.jboss.server;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.util.Hashtable;
import javax.management.MBeanException;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import com.fuhrer.idea.javaee.server.JavaeeServer;
import com.fuhrer.idea.jboss.model.JBossWebRoot;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentStatus;
import com.intellij.openapi.module.Module;
import org.jboss.security.SecurityAssociation;
import org.jboss.security.SimplePrincipal;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jnp.interfaces.NamingContextFactory;

class JBossServer extends JavaeeServer {

    @NonNls
    private static final String SERVER = "jboss.system:type=Server";

    @NonNls
    private static final String ADAPTOR = "jmx/invoker/RMIAdaptor";

    @NonNls
    private static final String DEPLOYER = "jboss.system:service=MainDeployer";

    private MBeanServerConnection server;

    private boolean connected;

    @Override
    protected boolean isConnected() throws Exception {
        try {
            return Boolean.TRUE.equals(getServer().getAttribute(new ObjectName(SERVER), "Started"));
        } catch (MBeanException e) {
            throw e.getTargetException();
        }
    }

    @Override
    @NotNull
    protected DeploymentStatus handleDeployment(DeploymentModel deployment, boolean deploy, boolean undeploy) throws Exception {
        try {
            Object[] target = new Object[]{getDeploymentSource(deployment).toURL()};
            String[] signature = new String[]{URL.class.getName()};
            if (undeploy) {
                getServer().invoke(new ObjectName(DEPLOYER), "undeploy", target, signature);
            }
            if (deploy) {
                getServer().invoke(new ObjectName(DEPLOYER), "deploy", target, signature);
            }
            DeploymentStatus status = DeploymentStatus.UNKNOWN;
            Object result = getServer().invoke(new ObjectName(DEPLOYER), "isDeployed", target, signature);
            if (Boolean.TRUE.equals(result)) {
                status = DeploymentStatus.DEPLOYED;
            } else if (Boolean.FALSE.equals(result)) {
                status = DeploymentStatus.NOT_DEPLOYED;
            }
            return status;
        } catch (MBeanException e) {
            throw e.getTargetException();
        }
    }

    @Override
    @Nullable
    protected String getContextRoot(Module module) {
        JBossWebRoot web = JBossDescriptors.getWebRoot(module);
        return (web != null) ? web.getContextRoot().getValue() : null;
    }

    @NotNull
    private MBeanServerConnection getServer() throws Exception {
        if (server == null) {
            ensureConnected();
            server = (MBeanServerConnection) getInitialContext().lookup(ADAPTOR);
        }
        return server;
    }

    private void ensureConnected() throws IOException {
        if (!connected) {
            Socket socket = new Socket(getHost(), getPort());
            InputStream in = socket.getInputStream();
            while (in.read() >= 0) {
            }
            in.close();
            socket.close();
            connected = true;
        }
    }

    @NotNull
    private Context getInitialContext() throws NamingException {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        try {
            Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
            SecurityAssociation.setPrincipal(new SimplePrincipal(getUsername()));
            SecurityAssociation.setCredential(getPassword());
            Hashtable<String, String> env = new Hashtable<String, String>();
            env.put(Context.INITIAL_CONTEXT_FACTORY, NamingContextFactory.class.getName());
            env.put(Context.PROVIDER_URL, "jnp://" + getHost() + ':' + getPort());
            return new InitialContext(env);
        } finally {
            Thread.currentThread().setContextClassLoader(loader);
        }
    }
}
