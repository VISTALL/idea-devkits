/*
 * Created by IntelliJ IDEA.
 * User: mike
 * Date: Oct 23, 2002
 * Time: 3:08:34 PM
 * To change template for new class use
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package com.intellij.vcs.starteam;

import com.intellij.openapi.application.ApplicationNamesInfo;
import com.intellij.openapi.application.PathManager;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.localVcs.LocalVcsServices;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.options.Configurable;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMExternalizable;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.openapi.vcs.*;
import com.intellij.openapi.vcs.history.VcsHistoryProvider;
import com.intellij.openapi.vcs.changes.ChangeProvider;
import com.intellij.openapi.vcs.checkin.CheckinEnvironment;
import com.intellij.openapi.vcs.update.UpdateEnvironment;
import com.intellij.util.ArrayUtil;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.List;

public class StarteamVcsAdapter extends AbstractVcs implements ProjectComponent, JDOMExternalizable {

  @NonNls private static final String PERSISTENCY_REMOVED_TAG = "StarbasePersistencyRemovedFile";
  @NonNls private static final String PERSISTENCY_RENAMED_TAG = "SourceSafePersistencyRenamedFile";
  @NonNls private static final String PATH_DELIMITER = "%%%";

  private StarteamVcs myStarteamVcs;

  public StarteamVcsAdapter(Project project, LocalVcsServices localVcsServices, StarteamConfiguration starteamConfiguration) {
    super(project);
    try {
      Class.forName("com.starbase.starteam.Project");
      myStarteamVcs = new StarteamVcs(project, localVcsServices, starteamConfiguration);
    }
    catch (Throwable e) {
    }

    if (getStarteamVcs() != null) {
      getStarteamVcs().initComponent();
    }
  }

  public StarteamVcs getStarteamVcs() {
    return myStarteamVcs;
  }

  public String getName() {
    return "StarTeam";
  }

  public String getDisplayName() {
    return "StarTeam";
  }

  public void projectClosed() {
    if (getStarteamVcs() != null) {
      getStarteamVcs().projectClosed();
    }
  }

  public void projectOpened() {
    if (getStarteamVcs() != null) {
      getStarteamVcs().projectOpened();
    }
  }

  public void disposeComponent() {
    if (getStarteamVcs() != null) {
      getStarteamVcs().disposeComponent();
    }
  }

  public void initComponent() {
  }

  public void start() throws VcsException {
    super.start();
    if (getStarteamVcs() != null) {
      getStarteamVcs().start();
    }
    else {
      throw new VcsException(StarteamBundle.message("exception.text.configuration.cant.start.classes.not.found",
                                                    ApplicationNamesInfo.getInstance().getProductName()));
    }
  }

  public void shutdown() throws VcsException {
    if (getStarteamVcs() != null) {
      getStarteamVcs().shutdown();
    }
    super.shutdown();
  }

  public boolean checkoutFile(String path) throws VcsException {
    if (getStarteamVcs() != null) {
      return getStarteamVcs().checkoutFile(path);
    }
    else {
      return false;
    }
  }

  public byte[] getFileContent(String path) throws VcsException {
    if (getStarteamVcs() != null) {
      return getStarteamVcs().getFileContent(path);
    }
    else {
      return ArrayUtil.EMPTY_BYTE_ARRAY;
    }
  }

  public void lockFile(String path) throws VcsException {
    if (getStarteamVcs() != null) {
      getStarteamVcs().lockFile(path);
    }
    else {
    }
  }

  public void unlockFile(String path) throws VcsException {
    if (getStarteamVcs() != null) {
      getStarteamVcs().unlockFile(path);
    }
  }

  @Nullable
  public FileRenameProvider getFileRenamer() {
    return getStarteamVcs() != null ? getStarteamVcs().getFileRenamer() : null;
  }

  @Nullable
  public DirectoryRenameProvider getDirectoryRenamer() {
    return getStarteamVcs() != null ? getStarteamVcs().getDirectoryRenamer() : null;
  }

  @Nullable
  public FileMoveProvider getFileMover() {
    return getStarteamVcs() != null ? getStarteamVcs().getFileMover() : null;
  }

  @Nullable
  public DirectoryMoveProvider getDirectoryMover() {
    return getStarteamVcs() != null ? getStarteamVcs().getDirectoryMover() : null;
  }

  @Nullable
  public TransactionProvider getTransactionProvider() {
    return getStarteamVcs() != null ? getStarteamVcs().getTransactionProvider() : null;
  }

  public void refresh() throws VcsException {
    if (getStarteamVcs() != null) {
      getStarteamVcs().refresh();
    }
  }

  public String getComponentName() {
    return "StarteamVcsAdapter";
  }

  public Configurable getConfigurable() {
    if (getStarteamVcs() != null) {
      return getStarteamVcs().getConfigurable();
    }
    else {
      return new MyConfigurable();
    }
  }

  public static StarteamVcsAdapter getInstance(Project project) {
    return project.getComponent(StarteamVcsAdapter.class);
  }

  private static class MyConfigurable implements Configurable
  {
    public String getDisplayName() {  return null;  }
    public Icon   getIcon()        {  return null;  }
    public String getHelpTopic()   {  return null;  }

    public JComponent createComponent() {
      final JPanel result = new JPanel(new BorderLayout());
      result.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
      result.add(new JLabel(StarteamBundle.message("label.configuration.starteam.jar.not.found", File.separator,
                                                   PathManager.getLibPath().replace('/', File.separatorChar),
                                                   ApplicationNamesInfo.getInstance().getProductName())), BorderLayout.NORTH);
      return result;
    }

    public boolean isModified() {
      return false;
    }

    public void apply() throws ConfigurationException {
    }

    public void reset() {
    }

    public void disposeUIResources() {
    }
  }

  public UpToDateRevisionProvider getUpToDateRevisionProvider() {
    if (getStarteamVcs() != null) {
      return getStarteamVcs().getUpToDateRevisionProvider();
    }
    else {
      return null;
    }
  }

  public void doActivateActions(Module module) {
    if (getStarteamVcs() != null) {
      getStarteamVcs().doActivateActions(module);
    }
  }

  public boolean markExternalChangesAsUpToDate() {
    return true;
  }

  public boolean supportsMarkSourcesAsCurrent() {
    return true;
  }

  public String getMenuItemText() {
    return StarteamBundle.message("starteam.menu.group.text");
  }

  public CheckinEnvironment getCheckinEnvironment() {
    if (getStarteamVcs() != null) {
      return getStarteamVcs().getCheckinEnvironment();
    }
    else {
      return null;
    }
  }

  public UpdateEnvironment getUpdateEnvironment()
  {
    if (getStarteamVcs() != null) {
      return getStarteamVcs().getUpdateEnvironment();
    }
    else {
      return null;
    }
  }

  public UpdateEnvironment getStatusEnvironment()
  {
    if (getStarteamVcs() != null) {
      return getStarteamVcs().getStatusEnvironment();
    }
    else {
      return null;
    }
  }

  public ChangeProvider getChangeProvider() {
    if (getStarteamVcs() != null) {
      return getStarteamVcs().getChangeProvider();
    }
    else {
      return null;
    }
  }

  @Nullable
  public VcsHistoryProvider getVcsHistoryProvider(){
    return (getStarteamVcs() != null) ? getStarteamVcs().getVcsHistoryProvider() : null;
  }

  public void loadSettings() {
    super.loadSettings();
    if (getStarteamVcs() != null) {
      getStarteamVcs().loadSettings();
    }
  }

  //
  // JDOMExternalizable methods
  //

  public void readExternal(final Element element) throws InvalidDataException
  {
    if( getStarteamVcs() != null )
    {
      List files = element.getChildren( PERSISTENCY_REMOVED_TAG );
      for (Object cclObj : files)
      {
        if (cclObj instanceof Element)
        {
          final Element currentCLElement = ((Element)cclObj);
          final String path = currentCLElement.getValue();

          // Safety check - file can be added again between IDE sessions.
          if( ! new File( path ).exists() )
            myStarteamVcs.removedFiles.add( path );
        }
      }

      files = element.getChildren( PERSISTENCY_RENAMED_TAG );
      for (Object cclObj : files)
      {
        if (cclObj instanceof Element)
        {
          final Element currentCLElement = ((Element)cclObj);
          final String pathPair = currentCLElement.getValue();
          int delimIndex = pathPair.indexOf( PATH_DELIMITER );
          if( delimIndex != -1 )
          {
            final String newName = pathPair.substring( 0, delimIndex );
            final String oldName = pathPair.substring( delimIndex + PATH_DELIMITER.length() );

            // Safety check - file can be deleted or changed between IDE sessions.
            if( new File( newName ).exists() )
              myStarteamVcs.renamedFiles.put( newName, oldName );
          }
        }
      }
    }
  }

  public void writeExternal(final Element element) throws WriteExternalException
  {
    if( getStarteamVcs() != null )
    {
      for( String file : myStarteamVcs.removedFiles )
      {
        final Element listElement = new Element(PERSISTENCY_REMOVED_TAG);
        listElement.addContent( file );
        element.addContent( listElement );
      }

      for( String file : myStarteamVcs.renamedFiles.keySet() )
      {
        final Element listElement = new Element( PERSISTENCY_RENAMED_TAG );
        final String pathPair = file.concat( PATH_DELIMITER ).concat( myStarteamVcs.renamedFiles.get( file ) );

        listElement.addContent( pathPair );
        element.addContent( listElement );
      }
    }
  }
}
