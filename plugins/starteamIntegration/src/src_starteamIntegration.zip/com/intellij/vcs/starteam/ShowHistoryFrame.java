package com.intellij.vcs.starteam;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.diff.BinaryContent;
import com.intellij.openapi.diff.DiffManager;
import com.intellij.openapi.diff.DiffTool;
import com.intellij.openapi.diff.SimpleDiffRequest;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.editor.EditorFactory;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.WindowManager;
import com.intellij.openapi.vfs.CharsetSettings;
import com.intellij.util.ui.UIUtil;
import com.starbase.starteam.File;
import com.starbase.starteam.Item;
import com.starbase.starteam.Server;
import org.jetbrains.annotations.NonNls;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;

/**
 * Created by IntelliJ IDEA.
 * User: ddmoore
 * Date: Jan 6, 2003
 * Time: 2:35:02 PM
 */
public class ShowHistoryFrame extends JFrame implements ListSelectionListener {
  private static final Logger LOG = Logger.getInstance("#com.intellij.vcs.starteam.StarteamVcs");

  private File myFile;
  private Item[] myItems;
  private JTable myTable;
  private Server myServer;
  private JPopupMenu myPopupMenu;
  private JMenuItem myCompareMenuItem;
  private JMenuItem myViewRevisionMenuItem;
  private Project myProj;

  private static final int REVISION = 0;
  private static final int AUTHOR = 1;
  private static final int TIME = 2;
  private static final int COMMENT = 3;

  // number of characters allowed in comment tooltip before starting a new line
  private static final int TOOLTIP_BREAK = 100;

  private static final String VIEW_REV_CONTENT = StarteamBundle.message("action.name.history.view.revision.content");
  private static final String COMPARE_CONTENTS = StarteamBundle.message("action.name.history.compare.contents");
  @NonNls private static final String JAVA_IO_TMPDIR_PROPERTY = "java.io.tmpdir";

  public ShowHistoryFrame(File f, Server server, Project proj) {
    if (f == null || server == null || proj == null) return;

    setTitle(StarteamBundle.message("dialog.title.file.history", f.getFullName()));

    Window w = WindowManager.getInstance().suggestParentWindow(proj);
    if (w instanceof Frame){
      setIconImage(((Frame)w).getIconImage());
    }

    myFile = f;
    myItems = myFile.getHistory();
    myServer = server;
    myProj = proj;

    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    initLayout();
  }

  private void initLayout() {
    JPanel panel;
    JScrollPane jsp;

    setSize(640, 480);
    setLocation(100, 100);

    myTable = new HistoryTable(new HistoryTableModel());
    myTable.setShowGrid(false);
    myTable.setColumnSelectionAllowed(false);
    myTable.setOpaque(true);
    //myTable.setCellSelectionEnabled(false);
    myTable.addMouseListener(new PopupManager());
    myTable.getSelectionModel().addListSelectionListener(this);

    ToolTipManager.sharedInstance().registerComponent(myTable);

    // set column widths
    myTable.getColumnModel().getColumn(REVISION).setMaxWidth(60);
    myTable.getColumnModel().getColumn(AUTHOR).setMaxWidth(100);
    myTable.getColumnModel().getColumn(TIME).setMaxWidth(170);

    myPopupMenu = new JPopupMenu();
    myCompareMenuItem = new JMenuItem(COMPARE_CONTENTS);
    myCompareMenuItem.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        try{
          int[] rows = myTable.getSelectedRows();
          if (rows.length == 2){
            Item rev1 = myItems[rows[1]];
            Item rev2 = myItems[rows[0]];

            if ((rev1 instanceof File) && (rev2 instanceof File)){
              File stFile1 = (File)rev1;
              File stFile2 = (File)rev2;

              ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
              ByteArrayOutputStream baos2 = new ByteArrayOutputStream();

              stFile1.checkoutToStream(baos1, Item.LockType.UNCHANGED, false);
              stFile2.checkoutToStream(baos2, Item.LockType.UNCHANGED, false);

              BinaryContent contents1 = createDiffContent(baos1.toByteArray());
              BinaryContent contents2 = createDiffContent(baos2.toByteArray());

              SimpleDiffRequest request = new SimpleDiffRequest(myProj, StarteamBundle.message("diff.title.history.diff.for.file",
                                                                                               stFile1.getFullName()));
              request.setContents(contents1, contents2);
              request.setContentTitles(
                StarteamBundle.message("diff.content.title.revision", Integer.toString(stFile1.getRevisionNumber() + 1)),
                StarteamBundle.message("diff.content.title.revision", Integer.toString(stFile2.getRevisionNumber() + 1)));
              DiffTool diffTool = DiffManager.getInstance().getDiffTool();
              request.addHint(DiffTool.HINT_SHOW_FRAME);
              if (diffTool.canShow(request)) diffTool.show(request);
            }
          }
        }
        catch(Exception ex){
          LOG.debug("Error comparing file revisions");
        }
      }
    });
    myPopupMenu.add(myCompareMenuItem);

    myViewRevisionMenuItem = new JMenuItem(VIEW_REV_CONTENT);
    myViewRevisionMenuItem.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        java.io.File file = null;
        try{
          int row = myTable.getSelectedRow();
          if (row > 0){
            Item rev = myItems[row];
            if (rev instanceof File){
              File stFile = (File)rev;

              //ByteArrayOutputStream baos = new ByteArrayOutputStream();
              //stFile.checkoutToStream(baos, Item.LockType.UNCHANGED, false);
              //String contents = new String(baos.toByteArray());
              file = new java.io.File(System.getProperty(JAVA_IO_TMPDIR_PROPERTY) + java.io.File.separator + Long.toString(System.currentTimeMillis()) + stFile.getName());
              stFile.checkoutTo(file, Item.LockType.UNCHANGED, true, true, false);
              StringBuffer contents = new StringBuffer();
              FileReader fr = new FileReader(file);
              BufferedReader br = new BufferedReader(fr);
              String line = null;
              while((line = br.readLine()) != null){
                contents.append(line);
                //contents.append(System.getProperty("line.separator"));
                contents.append("\n");
              }

              EditorFactory ef = EditorFactory.getInstance();

              //LocalFileSystem lfs = LocalFileSystem.getInstance();
              //VirtualFile vf = lfs.findFileByPath(file.getAbsolutePath());
              //FileEditorManager fem = FileEditorManager.getInstance(myProj);
              //Document doc = fem.fileToDocument(vf);
              Document doc = ef.createDocument(contents.toString());

              ef.createViewer(doc);

              //todo figure out how to open file viewer with arbitrary content with OpenAPI
            }
          }
        }
        catch(Exception ex){
          LOG.debug("Error showing revision");
        }
        finally{
          if (file != null){
            try{
              file.delete();
            }
            catch(Exception e2){
              LOG.debug("Error deleting temporary file");
            }
          }
        }
      }
    });
    //myPopupMenu.add(myViewRevisionMenuItem);

    panel = new JPanel();
    jsp = new FilledScrollPane(myTable);
    jsp.setOpaque(false);
    jsp.getViewport().setOpaque(false);

    panel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    panel.setLayout(new BorderLayout());
    panel.add(jsp, BorderLayout.CENTER);

    getContentPane().add(panel);
  }

  private BinaryContent createDiffContent(byte[] bytes) {
    // todo may need to use proper ST encoding when converting retrieved byte array to String
    return new BinaryContent(bytes, CharsetSettings.getInstance().getCharsetName(),
                             FileTypeManager.getInstance().getFileTypeByFileName(myFile.getName()));
  }

  public void valueChanged(ListSelectionEvent e) {
    myCompareMenuItem.setEnabled(myTable.getSelectedRows().length == 2);
    myViewRevisionMenuItem.setEnabled(myTable.getSelectedRows().length == 1);
  }

  private class PopupManager extends MouseAdapter {
    public void mouseClicked(MouseEvent e) {
      showPopup(e);
    }

    public void mousePressed(MouseEvent e) {
      showPopup(e);
    }

    public void mouseReleased(MouseEvent e) {
      showPopup(e);
    }

    private void showPopup(MouseEvent me) {
      if (me.isPopupTrigger()){
        myPopupMenu.show(me.getComponent(), me.getX(), me.getY());
      }
    }
  }

  private class FilledScrollPane extends JScrollPane {

    public FilledScrollPane(Component view) {
      super(view);
    }

    public void paint(Graphics g) {
      g.setColor(UIUtil.getWindowColor());
      g.fillRect(0, 0, getSize().width, getSize().height);
      super.paint(g);
    }
  }

  private class HistoryTable extends JTable {
    public HistoryTable(TableModel model) {
      super(model); // ha!
    }

    @NonNls
    public String getToolTipText(MouseEvent event) {
      int row = rowAtPoint(event.getPoint());
      int column = columnAtPoint(event.getPoint());
      @NonNls String comment = getModel().getValueAt(row, column).toString();

      for(int i = 0; i < comment.length();){
        int brake = comment.indexOf(' ', i + TOOLTIP_BREAK);
        if (brake > 0){
          comment = comment.substring(0, brake) + "<br>" + comment.substring(brake);
          i = brake + 4;
        }
        else{
          i += TOOLTIP_BREAK;
        }
      }

      return "<html><p>" + comment + "</p></html>";
    }
  }

  private class HistoryTableModel implements TableModel {
    private String[] COLUMN_NAMES = {
      StarteamBundle.message("column.name.file.history.revision"),
      StarteamBundle.message("column.name.file.history.author"),
      StarteamBundle.message("column.name.file.history.time"),
      StarteamBundle.message("column.name.file.history.comment")
    };

    private Class[] COLUMN_CLASSES = {
      Integer.class, String.class, String.class, String.class
    };

    public HistoryTableModel() {
    }

    public int getRowCount() {
      return myItems.length;
    }

    public int getColumnCount() {
      return 4;
    }

    public String getColumnName(int columnIndex) {
      return COLUMN_NAMES[columnIndex];
    }

    public Class getColumnClass(int columnIndex) {
      return COLUMN_CLASSES[columnIndex];
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
      return false;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
      Item item = myItems[rowIndex];
      Object obj = null;

      switch(columnIndex){
        case REVISION:
          obj = new Integer(item.getRevisionNumber() + 1);
          break;
        case AUTHOR:
          obj = myServer.getUser(item.getModifiedBy()).getName();
          break;
        case TIME:
          obj = (new java.util.Date(item.getModifiedTime().getLongValue())).toString();
          break;
        case COMMENT:
          obj = item.getComment();
          break;
      }

      return obj;
    }

    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    }

    public void addTableModelListener(TableModelListener l) {
    }

    public void removeTableModelListener(TableModelListener l) {
    }
  }
}
