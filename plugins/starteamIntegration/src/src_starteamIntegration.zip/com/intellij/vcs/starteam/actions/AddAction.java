package com.intellij.vcs.starteam.actions;

import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.vcs.*;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.project.Project;
import com.intellij.vcs.starteam.StarteamVcs;
import com.intellij.vcs.starteam.StarteamBundle;

/**
 * @author mike
 */
public class AddAction extends BasicAction {
  protected void perform(Project project, StarteamVcs vcs, VirtualFile file, DataContext context) throws VcsException
  {
    String url = file.getParent().getPresentableUrl();
    if (!file.isDirectory()){
      vcs.addFile( url, file.getName(), null, null);
    }
    else{
      vcs.addDirectory( url, file.getName(), null, null);
    }

    AbstractVcsHelper.getInstance(project).markFileAsUpToDate(file);
  }

  protected boolean isEnabled(Project project, AbstractVcs vcs, VirtualFile file)
  {
    FileStatus current = FileStatusManager.getInstance(project).getStatus( file );
    return current == FileStatus.ADDED || current == FileStatus.UNKNOWN;
  }

  protected String getActionName() {
    return StarteamBundle.message("action.name.adding.files");
  }
}
