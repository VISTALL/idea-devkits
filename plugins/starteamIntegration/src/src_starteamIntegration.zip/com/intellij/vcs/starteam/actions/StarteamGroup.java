package com.intellij.vcs.starteam.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DefaultActionGroup;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.vcs.actions.StandardVcsGroup;
import com.intellij.openapi.vcs.AbstractVcs;
import com.intellij.openapi.project.Project;
import com.intellij.vcs.starteam.StarteamVcsAdapter;

public class StarteamGroup extends StandardVcsGroup{
  public AbstractVcs getVcs(Project project) {
    return StarteamVcsAdapter.getInstance(project);
  }
}
