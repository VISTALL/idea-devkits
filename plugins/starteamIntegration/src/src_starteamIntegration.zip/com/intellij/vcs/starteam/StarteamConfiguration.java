package com.intellij.vcs.starteam;

import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.util.DefaultJDOMExternalizer;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMExternalizable;
import com.intellij.openapi.util.WriteExternalException;
import org.jdom.Element;

public class StarteamConfiguration implements ProjectComponent, JDOMExternalizable
{
  public String SERVER = "";
  public int PORT = 49201;
  public String USER = "";
  public String PASSWORD = "";
  public String PROJECT = "";
  public String VIEW = "";
  public String ALTERNATIVE_WORKING_PATH = "";
  public boolean LOCK_ON_CHECKOUT = false;
  public boolean UNLOCK_ON_CHECKIN = false;

  public void projectClosed()   {}
  public void projectOpened()   {}
  public void initComponent()   {}
  public void disposeComponent(){}

  public String getComponentName() { return "StarteamConfiguration"; }

  public void readExternal(Element element) throws InvalidDataException {
    DefaultJDOMExternalizer.readExternal(this,  element);
  }

  public void writeExternal(Element element) throws WriteExternalException {
    DefaultJDOMExternalizer.writeExternal(this,  element);
  }
}
