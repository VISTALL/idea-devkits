package com.intellij.vcs.starteam.actions;

import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ContentIterator;
import com.intellij.openapi.roots.ProjectFileIndex;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.vcs.*;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vcs.starteam.StarteamVcs;
import com.intellij.vcs.starteam.StarteamVcsAdapter;

import java.util.Arrays;
import java.util.List;

/**
 * @author mike
 */
public abstract class BasicAction extends AnAction {
  private static final Logger LOG = Logger.getInstance("#com.intellij.openapi.vcs.actions.VcsAction");

  public void actionPerformed(AnActionEvent event) {
    if (LOG.isDebugEnabled()) {
      LOG.debug("enter: actionPerformed(id='" + ActionManager.getInstance().getId(this) + "')");
    }
    final DataContext dataContext = event.getDataContext();
    final Project project = (Project)dataContext.getData(DataConstants.PROJECT);

    final VirtualFile[] files = (VirtualFile[])dataContext.getData(DataConstants.VIRTUAL_FILE_ARRAY);
    if (LOG.isDebugEnabled()) {
      LOG.debug("files='" + Arrays.asList(files) + "'");
    }
    if (files == null || files.length == 0) return;

    final AbstractVcs starteamVcs = StarteamVcs.getInstance(project);
    if (!ProjectLevelVcsManager.getInstance(project).checkAllFilesAreUnder(starteamVcs, files)) {
      FileDocumentManager.getInstance().saveAllDocuments();
    }

    final String actionName = getActionName();

    AbstractVcsHelper helper = AbstractVcsHelper.getInstance(project);
    com.intellij.openapi.localVcs.LvcsAction action = helper.startVcsAction(actionName);

    try {
      List exceptions = helper.runTransactionRunnable(starteamVcs, new TransactionRunnable() {
        public void run(List exceptions) {
          for (int i = 0; i < files.length; i++) {
            VirtualFile file = files[i];
            try {
              execute(project, starteamVcs, file, dataContext);
            }
            catch (VcsException ex) {
              ex.setVirtualFile(file);
              exceptions.add(ex);
            }
          }
        }
      }, null);

      helper.showErrors(exceptions, actionName != null ? actionName : starteamVcs.getDisplayName());
    }
    finally {
      if (actionName != null) {
        helper.finishVcsAction(action);
      }
    }
  }

  public void update(AnActionEvent e) {
    super.update(e);
    updateStarteamAction(e, this);
  }

  public static void updateStarteamAction(AnActionEvent e, BasicAction action) {
    Presentation presentation = e.getPresentation();
    final DataContext dataContext = e.getDataContext();

    Project project = (Project)dataContext.getData(DataConstants.PROJECT);
    if (project == null) {
      presentation.setEnabled(false);
      presentation.setVisible(false);
      return;
    }

    VirtualFile[] files = (VirtualFile[])dataContext.getData(DataConstants.VIRTUAL_FILE_ARRAY);
    if (files == null || files.length == 0) {
      presentation.setEnabled(false);
      presentation.setVisible(true);
      return;
    }

    for (VirtualFile file : files) {
      final AbstractVcs activeVcs = ProjectLevelVcsManager.getInstance(project).getVcsFor(file);
      if (activeVcs == null || !(activeVcs instanceof StarteamVcsAdapter)) {
        presentation.setEnabled(false);
        presentation.setVisible(false);
        return;
      }

      if (action != null) {
        if (!action.isEnabled(project, activeVcs, file)) {
          presentation.setEnabled(false);
          return;
        }
      }
    }
  }


  private void execute( final Project project, final AbstractVcs activeVcs, final VirtualFile file, final DataContext context ) throws VcsException
  {
    final VcsException[] e = new VcsException[ 1 ];

    try {  performOnItem( project, activeVcs, file, context ); }
    catch( VcsException exc) {  e[ 0 ] = exc;  }

    if( file.isDirectory() && e[ 0 ] != null )
    {
      //  Iterate over only those files which are actually the part of the
      //  project structure. Do not touch the whole underlying directory
      //  structure since there can be numerous auxiliary folders like ".sbas"
      //  which should be skipped.

      final ProjectFileIndex fileIndex = ProjectRootManager.getInstance( project ).getFileIndex();
      fileIndex.iterateContentUnderDirectory( file, new ContentIterator() {
          public boolean processFile( VirtualFile itFile )
          {
            //  Perverse way to store the exception from the anonymous ContentIterator
            //  implementor.
            try { performOnItem( project, activeVcs, file, context ); }
            catch( VcsException exc )
            {
              //  Store only the first exception to keep track the earliet problem.
              //  But try to iterate over the whole subproject tree, e.g. to eliminate
              //  possible single mistake.
              if( e[ 0 ] == null ) e[ 0 ] = exc;
            }

            return true;
          }
        });
    }

    //  Rethrow the accumulated exception.
    if( e[ 0 ] != null )
      throw e[ 0 ];
  }

  private void performOnItem( final Project project, final AbstractVcs activeVcs,
                              final VirtualFile file, final DataContext context ) throws VcsException
  {
    perform( project, ((StarteamVcsAdapter)activeVcs).getStarteamVcs(), file, context );
    ApplicationManager.getApplication().runWriteAction( new Runnable() { public void run() {  file.refresh(false, true);  } });
    FileStatusManager.getInstance( project ).fileStatusChanged( file );
    VcsDirtyScopeManager.getInstance( project ).fileDirty( file );
  }
  
  protected abstract String getActionName();

  protected abstract boolean isEnabled(Project project, AbstractVcs vcs, VirtualFile file);

  protected abstract void perform(Project project, final StarteamVcs activeVcs, VirtualFile file, DataContext context) throws VcsException;
}
