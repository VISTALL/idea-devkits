package com.intellij.vcs.starteam;

import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vfs.*;

import java.util.HashMap;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 * Date: Jul 31, 2006
 */
public class VFSListener implements VirtualFileListener
{
  private StarteamVcs host;

  public VFSListener( StarteamVcs host ) { this.host = host; }

  public void beforeContentsChange(VirtualFileEvent event) {}
  public void contentsChanged(VirtualFileEvent event) {}
  public void fileMoved(VirtualFileMoveEvent event) {}
  public void fileDeleted(VirtualFileEvent event)   {}

  public void propertyChanged(VirtualFilePropertyEvent event)
  {
    //  Trace renamed files only if we really working with Starteam.
    if( host.getProject() != null && event.getPropertyName() == VirtualFile.PROP_NAME )
    {
      VirtualFile file = event.getFile();
      //  After any rename/move takes place, mark the affected items as dirty
      //  so that their status is refreshed after the operation.
      if( file.isDirectory() )
        VcsDirtyScopeManager.getInstance( host.getProject() ).dirDirtyRecursively( file, true );
      else
        VcsDirtyScopeManager.getInstance( host.getProject() ).fileDirty( file );
    }
  }

  public void beforeFileMovement(VirtualFileMoveEvent event)
  {
    if( host.getProject() != null && !event.getFile().isDirectory() )
    {
      String oldName = event.getFile().getPath();
      String newName = event.getNewParent().getPath() + "/" + event.getFile().getName();

      String prevName = host.renamedFiles.get( oldName );
      if( host.existsFile( oldName ) || prevName != null )
      {
        //  Newer name must refer to the oldest one in the chain of movements
        if( prevName == null )
          prevName = oldName;

        //  Check whether we are trying to rename the file back -
        //  if so, just delete the old key-value pair
        if( !prevName.equals( newName ) )
          host.renamedFiles.put( newName, prevName );

        host.renamedFiles.remove( oldName );
      }
    }
  }

  public void beforePropertyChange(VirtualFilePropertyEvent event)
  {
    //  Trace deleted files only if we really working with Starteam.
    if( host.getProject() != null )
    {
      if( event.getPropertyName() == VirtualFile.PROP_NAME )
      {
        String parentDir = event.getFile().getParent().getPath() + "/";
        String currentName = parentDir + event.getOldValue();
        String newName = parentDir + event.getNewValue();

        String prevName = event.getFile().isDirectory() ? host.renamedDirs.get( currentName ) :
                                                          host.renamedFiles.get( currentName );
        if( event.getFile().isDirectory() )
        {
          if( host.existsFolder( currentName ) || prevName != null )
            processRename( host.renamedDirs, prevName, currentName, newName );
        }
        else
        {
          if( host.existsFile( currentName ) || prevName != null )
            processRename( host.renamedFiles, prevName, currentName, newName );
        }
      }
    }
  }

  private static void processRename( HashMap<String, String> renamedItems, String prevName, String currName, String newName )
  {
    //  Newer name must refer to the oldest one in the chain of renamings
    if( prevName == null )
      prevName = currName;

    //  Check whether we are trying to rename the file back -
    //  if so, just delete the old key-value pair
    if( !prevName.equals( newName ) )
      renamedItems.put( newName, prevName );

    renamedItems.remove( currName );
  }

  public void fileCreated(VirtualFileEvent event)
  {
    if( host.getProject() != null )
    {
      //  In the case when the project content is synchronized over the
      //  occasionally removed files.
      String path = event.getFile().getPath();
      host.removedFiles.remove( path );

      if( host.removedFolders.contains( path ) )
      {
        host.removedFolders.remove( path );
//        StarteamVcs.deleteIgnoredFolder( path );
      }
    }
  }
  public void beforeFileDeletion( VirtualFileEvent event )
  {
    //  Trace deleted files only if we really working with Starteam.
    if( host.getProject() != null )
    {
      VirtualFile file = event.getFile();
      String path = file.getPath();

      //  Trace only those files which are really reside in the
      //  repository and are needed in commands to the Starteam server.
      if( event.getFile().isDirectory() && host.existsFolder( path ) )
      {
        host.removedFoldersNameMap.put( file, path );
        markSubfolderStructure( path );
        host.removedFolders.add( path );
      }
      else
      if( host.existsFile( path ) )
        host.removedFiles.add( path );
    }
  }

  /**
   * When adding new path into the list of the removed folders, remove from
   * that list all files/folders which were removed previously locating under
   * the given one (including it).
   */
  private void  markSubfolderStructure( String path )
  {
    for( Iterator<String> it = host.removedFiles.iterator(); it.hasNext(); )
    {
      String strFile = it.next();
      if( strFile.startsWith( path ) )
       it.remove();
    }
    for( Iterator<String> it = host.removedFolders.iterator(); it.hasNext(); )
    {
      String strFile = it.next();
      if( strFile.startsWith( path ) )
       it.remove();
    }
  }
}
