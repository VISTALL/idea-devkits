package com.intellij.vcs.starteam;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.FileStatus;
import com.intellij.openapi.vcs.ProjectLevelVcsManager;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.changes.*;
import com.intellij.openapi.vcs.history.VcsRevisionNumber;
import com.intellij.openapi.vcs.update.FileGroup;
import com.intellij.openapi.vcs.update.UpdatedFiles;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vcsUtil.VcsUtil;
import com.starbase.starteam.Folder;
import com.starbase.starteam.ServerException;
import com.starbase.starteam.Status;
import com.starbase.starteam.vts.comm.CommandException;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 */

public class StarteamChangeProvider implements ChangeProvider
{
  private Project     project;
  private StarteamVcs host;

  public StarteamChangeProvider( Project project, StarteamVcs host )
  {
    this.project = project;
    this.host = host;
  }

  public boolean isModifiedDocumentTrackingRequired() {  return false;  }

  public void getChanges(final VcsDirtyScope dirtyScope, final ChangelistBuilder builder, final ProgressIndicator progress)
  {
    try
    {
      for( FilePath path : dirtyScope.getRecursivelyDirtyDirectories() )
      {
        //  Exclude folders which are not modules under VCS.
        //  NB: Need a classic "\\"-delimiters convention
        VirtualFile vfDir = VcsUtil.getVirtualFile( path.getPath() );
        if( vfDir != null && VcsUtil.isPathUnderProject( project, vfDir ) )
        {
          processFolder( path, builder );
          iterateOverDirectories( path.getPath(), builder );
        }
      }

      for( FilePath path : dirtyScope.getDirtyFiles() )
      {
        if( path.isDirectory() )
        {
          processFolder( path, builder );
          iterateOverDirectories( path.getPath(), builder );
        }
        else
          processFile( path, builder );
      }

      for( String removedFile : host.removedFiles )
        builder.processLocallyDeletedFile( VcsUtil.getFilePath(removedFile, false) );

      for( String removedFolder : host.removedFolders )
        builder.processLocallyDeletedFile( VcsUtil.getFilePath(removedFolder, true) );
    }
    //  User description: When we are not connected to the network. We get the following error.
    //  Error message: Connection reset by peer: socket write error
    catch( final CommandException e )
    {
      ApplicationManager.getApplication().invokeLater( new Runnable() {
         public void run() {  Messages.showErrorDialog( StarteamBundle.message("message.text.lost.connection"),
                                                        StarteamBundle.message("message.title.configuration.error") );  }
       });
    }
    //  Error message: The server does not recognize the client.
    //  The client may have been automatically logged off due to inactivity.
    catch( ServerException e ) {
      ApplicationManager.getApplication().invokeLater( new Runnable() {
         public void run() {  Messages.showErrorDialog( StarteamBundle.message("message.text.lost.connection"),
                                                        StarteamBundle.message("message.title.configuration.error") );  }
       });
    }
  }

  private void iterateOverDirectories( String path, final ChangelistBuilder builder )
  {
    VirtualFile vfDir = VcsUtil.getVirtualFile( path );
    if( vfDir != null )
    {
      VirtualFile[] childs = vfDir.getChildren();
      for( VirtualFile vf : childs )
      {
        if( !vf.isDirectory() && VcsUtil.isPathUnderProject( project, vf ) )
        {
          final FilePath fp = VcsUtil.getFilePath( vf.getPath() );
          processFile( fp, builder );
        }
      }

      for( VirtualFile vf : childs )
      {
        if( vf.isDirectory() && VcsUtil.isPathUnderProject( project, vf ) )
        {
          final FilePath fp = VcsUtil.getFilePath( vf.getPath() );
          processFolder( fp, builder );

          iterateOverDirectories( vf.getPath(), builder );
        }
      }
    }
  }

  //---------------------------------------------------------------------------
  //  Get information on files that differ from the Starteam project location:
  //  - different content
  //  - not present in Starteam repository (added locally)
  //  - absent in local directory (this information is not used currently).
  //---------------------------------------------------------------------------
  private void processFile(final FilePath filePath, final ChangelistBuilder builder)
  {
    if( !host.isPathUnderRepository( filePath ) )
      return;
    
    com.starbase.starteam.File file = host.findFile( getSTCanonicPath( filePath ) );

    try
    {
      if( file == null )
      {
        if( !isFileUnderRenamedDir( filePath.getPath() ))
        {
          if( isProperNotification( filePath ) )
          {
            String oldPath = host.renamedFiles.get( filePath.getPath() );
            if( oldPath != null )
            {
              //  For the renamed file we receive two change requests: one for
              //  the old file and one for the new one. Ignore the first request.
                FilePath oldName = VcsUtil.getFilePath( oldPath );
                builder.processChange( new Change( new STContentRevision( oldName ), new STContentRevision( filePath )));
            }
            else
            {
              builder.processChange( new Change( null, new STContentRevision( filePath )));
            }
          }
        }
      }
      else
      {
        //  In certain cases we still get status "UNKNOWN" (int 6) after the
        //  particular amount of time (even after full resync). Try to refresh.
        try { file.updateStatus(false, true); }
        catch( Exception e ){
          //  Nothing to do - if <updateStatus> throws an exception then most
          //  probably we deal with latest version
        }

        int status = file.getStatus();
        if( status == Status.NEW )
          builder.processChange( new Change( null, new CurrentContentRevision( filePath )));
        else
        if( status == Status.MERGE )
          builder.processChange( new Change( new STContentRevision( filePath ), new CurrentContentRevision( filePath ), FileStatus.MERGE ));
        else
        if( status == Status.MODIFIED )
          builder.processChange( new Change( new STContentRevision( filePath ), new CurrentContentRevision( filePath )));
        else
        if( status == Status.MISSING )
        {
          //  We have two source of information on locally deleted files:
          //  - one is stored in StarteamVcs host as a list controllable by VFS listener
          //  - here, on folder traverse.
          //  So do not duplicate files in the dirty lists.

          String normPath = filePath.getPath().replace( File.separatorChar, '/');
          if( !host.removedFiles.contains( normPath ))
            builder.processLocallyDeletedFile( filePath );
        }
      }
    }
    catch( Exception e )
    {
      //  By default if any exception happens, we consider file status to be
      // "unknown" and do not indicate any change.
    }
  }

  /**
   * For the renamed or moved file we receive two change requests: one for
   * the old file and one for the new one. For renamed file old request differs
   * in filename, for the moved one - in parent path name. This request must be
   * ignored since all preliminary information is already accumulated. 
   */
  private static boolean isProperNotification( final FilePath filePath )
  {
    String oldName = filePath.getName();
    String newName = (filePath.getVirtualFile() == null) ? "" : filePath.getVirtualFile().getName();
    String oldParent = filePath.getVirtualFileParent().getPath();
    String newParent = filePath.getPath().substring( 0, filePath.getPath().length() - oldName.length() - 1 );
    return (newParent.equals( oldParent ) && newName.equals( oldName ) );
  }

  private void processFolder( final FilePath filePath, final ChangelistBuilder builder )
  {
    if( !isProperNotification( filePath ) )
      return;
    
    if( !host.isPathUnderRepository( filePath ) )
      return;

    Folder stFolder = host.findFolder( getSTCanonicPath( filePath ) );
    try
    {
      //  Process two cases:
      //  - directory is added locally
      //  - directory is renamed locally
      if( stFolder == null )
      {
          String oldPath = host.renamedDirs.get( filePath.getPath() );
          if( oldPath != null )
          {
            //  For the renamed file we receive two change requests: one for
            //  the old dir and one for the new one. Ignore the first request.

            FilePath oldName = VcsUtil.getFilePath( oldPath );

            //  Check whether we perform "undo" of the rename. This is easily
            //  done if we want to undo the refactoring of the package rename.
            builder.processChange( new Change( new STContentRevision( oldName ), new STContentRevision( filePath )));
            /*
            else
            {
              host.renamedDirs.remove( filePath.getPath() );
            }
            */
//            host.setWorkingFolderName( oldName.getIOFile().getPath(), filePath.getVirtualFile().getName() );
            host.setWorkingFolderName( oldName.getIOFile().getPath(), filePath.getName() );
          }
          else
          {
            builder.processChange( new Change( null, new STContentRevision( filePath )));
          }
      }
      //  Check for the folder can come from either singular calls (when
      //  dirtyRecursive is empty) or from batch call when we need to observe
      //  the whole project.
      //  This case (Folder != null) comes from the batch mode.
      else
      {
        String oldPath = host.renamedDirs.get( filePath.getPath() );
        if( oldPath != null )
        {
          FilePath oldName = VcsUtil.getFilePath( oldPath );
          builder.processChange( new Change( new STContentRevision( oldName ), new STContentRevision( filePath )));
        }
      }
    }
    catch( Exception e )
    {
      //  By default if any exception happens, we consider file status to be
      // "unknown" and do not indicate any change.
    }
  }

  public List<VcsException> commit( List<Change> changes, String preparedComment )
  {
    HashSet<FilePath> processedFiles = new HashSet<FilePath>();
    List<VcsException> errors = new ArrayList<VcsException>();
    List<String> mergeFiles = new ArrayList<String>();

    commitNew( changes, preparedComment, processedFiles, errors );
    commitChanged( changes, preparedComment, processedFiles, errors, mergeFiles );
    commitRenamed( changes, preparedComment, processedFiles, errors );

    for( final FilePath path : processedFiles )
      VcsUtil.markFileAsDirty( project, path );

    if( mergeFiles.size() > 0)
    {
      final UpdatedFiles updatedFiles = UpdatedFiles.create();

      for( String file : mergeFiles )
        updatedFiles.getGroupById( FileGroup.MERGED_WITH_CONFLICT_ID ).add( file );

      ApplicationManager.getApplication().invokeLater( new Runnable() {
        public void run(){
          ProjectLevelVcsManager.getInstance( project ).showProjectOperationInfo(
              updatedFiles, StarteamBundle.message( "local.vcs.action.name.checkin.files" ) );
        }
      });
    }
    return errors;
  }

  private void commitNew( List<Change> changes, String preparedComment,
                          HashSet<FilePath> processedFiles, List<VcsException> errors )
  {
    List<FilePath> folders = new ArrayList<FilePath>();
    List<FilePath> files = new ArrayList<FilePath>();

    //  Split new items into two sets - folders and files. Since "Changes" may
    //  come in arbitrary order, first add the folders into the repository, and
    //  only then the files (possibly) under these folder.

    for( Change change : changes )
    {
      if( VcsUtil.isChangeForNew( change ) )
      {
        FilePath file = change.getAfterRevision().getFile();
        if( file.isDirectory() )
          folders.add( file );
        else
          files.add( file );
        processedFiles.add( file );
      }
    }

    //  Sort file folders in the ascending order so that parent folders are
    //  always added before child ones.
    
    FilePath[] folderPathsSorted = folders.toArray( new FilePath[ folders.size() ] );
    Arrays.sort( folderPathsSorted, new Comparator<FilePath>() {
      public int compare(FilePath o1, FilePath o2) { return -o1.getPath().compareTo( o2.getPath() ); }
    });

    for( FilePath file : folders )
    {
      try
      {
        String parentPath = getSTCanonicPath( file.getVirtualFileParent().getPath() );
        host.addDirectory( parentPath, file.getName(), preparedComment, null );
      }
      catch( VcsException e ) { errors.add( e );  }
    }

    for( FilePath file : files )
    {
      try
      {
        String parentPath = getSTCanonicPath( file.getVirtualFileParent().getPath() );
        host.addFile( parentPath, file.getName(), preparedComment, null );
      }
      catch( VcsException e ) { errors.add( e );  }
    }
  }

  private void commitChanged( List<Change> changes, String preparedComment,
                              HashSet<FilePath> processedFiles, List<VcsException> errors,
                              List<String> mergeFiles )
  {
    for( Change change : changes )
    {
      try
      {
        //noinspection ConstantConditions
        FilePath file = change.getAfterRevision().getFile();
        if( !VcsUtil.isRenameChange( change ) && ( change.getBeforeRevision() != null ))
        {
          String starteamFilePath = StarteamChangeProvider.getSTCanonicPath( file );
          boolean success = host.checkinFile( starteamFilePath, preparedComment, null );
          if( !success )
            mergeFiles.add( starteamFilePath );
        }
        processedFiles.add( file );
      }
      catch( VcsException e )
      {
        errors.add( e );
      }
    }
  }

  private void commitRenamed( List<Change> changes, String preparedComment,
                              HashSet<FilePath> processedFiles, List<VcsException> errors )
  {
    for( Change change : changes )
    {
      try
      {
        if( VcsUtil.isRenameChange( change ) )
        {
          FilePath file = change.getAfterRevision().getFile();
          String newPath = file.getPath();
          String oldPath = getSTCanonicPath( change.getBeforeRevision().getFile() );
          if( file.isDirectory() )
          {
            host.renameDirectoryNew( getSTCanonicPath( newPath ), file.getName() );
            host.renamedDirs.remove( newPath );
          }
          else
          {
            //  If parent folders' names of the revisions coinside, then we
            //  deal with the simple rename, otherwise we process full-scaled
            //  file movement across folders (packages).

            FilePath oldfile = change.getBeforeRevision().getFile();
            if( oldfile.getVirtualFileParent().getPath().equals( file.getVirtualFileParent().getPath() ))
              host.renameAndCheckInFile( oldPath, file.getName(), preparedComment );
            else
            {
              String newFolder = getSTCanonicPath( file.getVirtualFileParent().getPath() );
              host.moveRenameAndCheckInFile( oldPath, newFolder, file.getName(), preparedComment );
            }

            host.renamedFiles.remove( newPath );
            processedFiles.add( file );
          }
        }
      }
      catch( VcsException e )
      {
        errors.add( e );
      }
    }
  }

  /**
   * Rollback of changes made is performed by simple override of the
   * current files with "CheckOut" command with keeping the file r/w
   * status.
   */
  public List<VcsException> rollbackChanges( List<Change> changes )
  {
    List<VcsException> errors = new ArrayList<VcsException>();

    rollbackNew( changes );
    rollbackChanged( changes, errors );

    return errors;
  }

  /**
   * Rolling back new files or folders means just deleting local files.
   */
  private static void rollbackNew( List<Change> changes )
  {
    for( Change change : changes )
    {
      if( VcsUtil.isChangeForNew( change ) )
      {
        new File( change.getAfterRevision().getFile().getPath() ).delete();
      }
    }
  }

  /**
   * Rolling back modified files is a getting out the latest copy of them
   * from the repository. The only difference in the processing is made for
   * renamed files - we must get out file with the original name. 
   */
  private void rollbackChanged( List<Change> changes, List<VcsException> errors )
  {
    for( Change change : changes )
    {
      FilePath newFile = change.getAfterRevision().getFile();
      String newPath = getSTCanonicPath( newFile );
      try
      {
        if( VcsUtil.isRenameChange( change ) )
        {
          FilePath oldFile = change.getBeforeRevision().getFile();
          String oldPath = getSTCanonicPath( oldFile );

          if( newFile.isDirectory() )
          {
            new File( newPath ).renameTo( new File( oldPath ) );
//            host.setWorkingFolderName( oldPath, oldFile.getName() );
            host.setWorkingFolderName( newPath, oldFile.getName() );
            host.renamedDirs.remove( newFile.getPath() );
          }
          else
          {
            host.checkoutFile( oldPath, false );
            host.renamedFiles.remove( newFile.getPath() );

            FileUtil.delete( new File( newPath ) );
          }
        }
        else
        if( !VcsUtil.isChangeForNew( change ) )
        {
          host.checkoutFile( newPath, false );
        }
      }
      catch( VcsException e )
      {
        errors.add( e );
      }
    }
  }

  public List<VcsException> scheduleMissingFileForDeletion( List<FilePath> files )
  {
    List<File> ioFiles = ChangesUtil.filePathsToFiles(files);
    //  First, remove all ordinary files and only then folders in order not to
    //  deal with mutual subordering.
    removeItems( ioFiles, false );
    removeItems( ioFiles, true );
    return new ArrayList<VcsException>();
  }

  private void  removeItems( List<File> files, boolean isDir )
  {
    for( File file : files )
    {
      String starteamPath = getSTCanonicPath( file.getPath() );
      Folder folder = host.findFolder( starteamPath );
      if( (folder != null) == isDir )
      {
        if( folder != null )
        {
          folder.remove();

          String ignoredPath = starteamPath.substring( 0, file.getParentFile().getPath().length() ) +
                               File.separatorChar + StarteamVcs.RENAMED_FOLDER_PREFIX + file.getName();
          FileUtil.delete( new File( ignoredPath ) );
        }
        else
        {
          com.starbase.starteam.File starteamFile = host.findFile( starteamPath );
          if( starteamFile != null )
            starteamFile.remove();
        }

        String canonicPath = file.getPath().replace( File.separatorChar, '/');
        host.removedFolders.remove( canonicPath );
        host.removedFiles.remove( canonicPath );
      }
    }
  }

  public List<VcsException> rollbackMissingFileDeletion(List<FilePath> files)
  {
    List<File> ioFiles = ChangesUtil.filePathsToFiles(files);
    List<VcsException> errors = new ArrayList<VcsException>();
    //  First, unremove all folders and only then files
    unremoveItems( ioFiles, true, errors );
    unremoveItems( ioFiles, false, errors );
    return errors;
  }

  private void  unremoveItems( List<File> files, boolean isDir, List<VcsException> errors )
  {
    for( File file : files )
    {
      try
      {
        String starteamPath = getSTCanonicPath( file.getPath() );
        String canonicPath = file.getPath().replace( File.separatorChar, '/');

        Folder folder = host.findFolder( starteamPath );
        if( (folder != null) == isDir )
        {
          if( folder != null )
          {
            String ignoredPath = starteamPath.substring( 0, file.getParentFile().getPath().length() ) +
                                 File.separatorChar + StarteamVcs.RENAMED_FOLDER_PREFIX + file.getName();
            host.removedFolders.remove( canonicPath );
            FileUtil.rename( new File( ignoredPath ), file );
          }
          else
          {
            com.starbase.starteam.File starteamFile = host.findFile( starteamPath );
            if( starteamFile != null )
              host.checkoutFile( starteamFile, false );

            host.removedFiles.remove( canonicPath );
          }
        }
      }
      catch( VcsException e ) {  errors.add( e );    }
      catch( IOException e )  {  errors.add( new VcsException( e ) );  }
    }
  }

  public List<VcsException> scheduleUnversionedFilesForAddition(List<VirtualFile> files)
  {
    List<VcsException> errors = new ArrayList<VcsException>();
    for( VirtualFile file : files )
    {
      try
      {
        String parent = getSTCanonicPath( file.getParent().getPath() );
        if( file.isDirectory())
          host.addDirectory( parent, file.getName(), null, null );
        else
          host.addFile( parent, file.getName(), null, null );
      }
      catch( VcsException e )         {   errors.add( e );   }
      catch( NullPointerException e ) {   errors.add( new VcsException( e ) );   }
    }
    return errors;
  }

  private boolean isFileUnderRenamedDir( String path )
  {
    for( String newPath : host.renamedDirs.keySet() )
    {
      if( path.startsWith( newPath ) && !path.equalsIgnoreCase( newPath ) )
        return true;
    }
    return false;
  }

  public static String getSTCanonicPath( String path )
  {
    return path.replace('/', File.separatorChar);
  }

  public static String getSTCanonicPath( FilePath file )
  {
    return file.getPath().replace('/', File.separatorChar);
  }

  private class STContentRevision implements ContentRevision
  {
    private FilePath  revisionPath;

    public STContentRevision( FilePath path )   {  revisionPath = path;  }

    public String getContent()
    {
      String content = null;
      try
      {
        byte[] byteContent = host.getFileContent( getSTCanonicPath( revisionPath.getPath() ) );
        content = new String( byteContent );
      }
      catch( VcsException e ) {}

      return content;
    }

    @NotNull public VcsRevisionNumber getRevisionNumber(){  return VcsRevisionNumber.NULL;  }
    @NotNull public FilePath getFile()                   {  return revisionPath; }
  }
}
