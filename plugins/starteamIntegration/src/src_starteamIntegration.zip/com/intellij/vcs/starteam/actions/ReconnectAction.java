package com.intellij.vcs.starteam.actions;

import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.AbstractVcs;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.module.Module;
import com.intellij.vcs.starteam.StarteamVcs;
import com.intellij.vcs.starteam.StarteamBundle;

/**
 * @author ddmoore
 */
public class ReconnectAction extends BasicAction {
  protected boolean isEnabled(Project project, AbstractVcs vcs, VirtualFile file) {
    return true;
  }

  protected String getActionName() {
    return StarteamBundle.message("local.vcs.action.name.reconnecting");
  }

  protected void perform(Project project, StarteamVcs activeVcs, VirtualFile file, DataContext context) throws VcsException {
    activeVcs.shutdown();
    activeVcs.start();
  }
}
