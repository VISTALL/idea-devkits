/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.actions;

import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.*;
import com.intellij.openapi.vcs.actions.VcsContext;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VirtualFileManager;
import com.intellij.peer.PeerFactory;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.application.PerforceVcs;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;

import java.util.*;

class ActionContext {
  VcsContext context;
  Collection<VirtualFile> files;

  public ActionContext(final VcsContext context, final Collection<VirtualFile> files) {
    this.context = context;
    this.files = files;
  }
}

public class RevertAllUnchangedFilesAction extends AsyncUpdateAction<ActionContext> {
  protected ActionContext prepareDataFromContext(final AnActionEvent e) {
    return new ActionContext(PeerFactory.getInstance().getVcsContextFactory().createCachedContextOn(e), getSelectedFiles(e));
  }

  protected void performUpdate(final Presentation presentation, final ActionContext context) {
    final Project project = context.context.getProject();
    if (project == null) {
      presentation.setVisible(false);
      return;
    }

    presentation.setVisible(hasFilesUnderPerforce(context.files, project));
  }


  @Override
  protected boolean forceSyncUpdate(final AnActionEvent e) {
    return true;
  }

  private static Collection<VirtualFile> getSelectedFiles(final AnActionEvent e) {
    final Object panel = e.getDataContext().getData(CheckinProjectPanel.PANEL);
    final Collection<VirtualFile> files;
    if (panel instanceof CheckinProjectPanel) {
      files = ((CheckinProjectPanel)panel).getRoots();
    }
    else {
      VirtualFile[] filesarray = (VirtualFile[])e.getDataContext().getData(DataConstants.VIRTUAL_FILE_ARRAY);
      if (filesarray != null) {
        files = Arrays.asList(filesarray);
      }
      else {
        e.getPresentation().setVisible(false);
        files = Collections.emptyList();
      }
    }
    return files;
  }

  private static boolean hasFilesUnderPerforce(final Collection<VirtualFile> roots, Project project) {
    final ProjectLevelVcsManager vcsManager = ProjectLevelVcsManager.getInstance(project);
    final PerforceVcs vcs = PerforceVcs.getInstance(project);

    for (VirtualFile file : roots) {
      if (vcsManager.getVcsFor(file) == vcs) {
        return true;
      }
    }

    return false;
  }

  public void actionPerformed(final AnActionEvent e) {
    final VcsContext context = PeerFactory.getInstance().getVcsContextFactory().createCachedContextOn(e);
    final CheckinProjectPanel panel = (CheckinProjectPanel)e.getDataContext().getData(CheckinProjectPanel.PANEL);
    final Collection<VirtualFile> roots = getSelectedFiles(e);
    final Project project = context.getProject();
    final ProjectLevelVcsManager vcsManager = ProjectLevelVcsManager.getInstance(project);
    final PerforceVcs vcs = PerforceVcs.getInstance(project);

    final List<VcsException> exceptions = new ArrayList<VcsException>();

    ApplicationManager.getApplication().runWriteAction(new Runnable() {
      public void run() {
        FileDocumentManager.getInstance().saveAllDocuments();
      }
    });

    final boolean[] containsDir = new boolean[]{false};

    final PerforceSettings perfSettings = PerforceSettings.getSettings(project);
    ProgressManager.getInstance().runProcessWithProgressSynchronously(new Runnable() {
      public void run() {
        for (VirtualFile file : roots) {
          if (vcsManager.getVcsFor(file) == vcs) {
            try {
              if (ActionPlaces.CHANGES_VIEW_TOOLBAR.equals(e.getPlace())) {
                if (file.isDirectory()) containsDir[0] = true;
                PerfCommands.p4revertUnchangedFile(file.getPath(), perfSettings);
              }
              else {
                if (file.isDirectory()) {
                  PerfCommands.p4revertUnchangedUnder(file.getPath(), perfSettings);
                  containsDir[0] = true;
                }
                else {
                  PerfCommands.p4revertUnchangedFile(file.getPath(), perfSettings);
                }
              }
            }
            catch (VcsException e1) {
              exceptions.add(e1);
            }
          }
        }
      }
    }, PerforceBundle.message("message.title.revert.unchanged"), false, project);

    if (containsDir[0]) {
      VirtualFileManager.getInstance().refresh(true, new Runnable() {
        public void run() {
          P4File.invalidateFstat(project);
          FileStatusManager.getInstance(project).fileStatusesChanged();
        }
      });
    }
    else {
      for (final VirtualFile vFile : roots) {
        ApplicationManager.getApplication().runWriteAction(new Runnable() {
          public void run() {
            vFile.refresh(false, false);
          }
        });
        P4File.invalidateFstat(vFile);
        FileStatusManager.getInstance(project).fileStatusChanged(vFile);
        VcsDirtyScopeManager.getInstance(project).fileDirty(vFile);
      }
    }

    if (panel != null) {
      panel.refresh();
    }

    if (!exceptions.isEmpty()) {
      AbstractVcsHelper.getInstance(project).showErrors(exceptions, PerforceBundle.message("message.title.revert.unchanged.files"));
    }
  }
}
