package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.FileStatus;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.changes.Change;
import com.intellij.openapi.vcs.changes.ChangeList;
import com.intellij.openapi.vcs.changes.*;
import com.intellij.openapi.vcs.history.VcsRevisionNumber;
import com.intellij.openapi.vfs.CharsetToolkit;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.peer.PeerFactory;
import com.intellij.util.Processor;
import com.intellij.util.text.FilePathHashingStrategy;
import com.intellij.vcsUtil.VcsUtil;
import gnu.trove.THashSet;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.perforce.*;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.*;

/**
 * @author max
 */
public class PerforceChangeProvider implements ChangeProvider {
  private static final Logger LOG = Logger.getInstance("#org.jetbrains.idea.perforce.application.PerforceChangeProvider");

  private Project myProject;

  public PerforceChangeProvider(final PerforceVcs vcs) {
    myProject = vcs.getProject();
  }

  public void getChanges(final VcsDirtyScope dirtyScope, final ChangelistBuilder builder, final ProgressIndicator progress) {
    LOG.debug("getting changes for scope " + dirtyScope);

    if (dirtyScope.getRecursivelyDirtyDirectories().size() == 0) {
      getChangesForFiles(dirtyScope.getDirtyFiles(), builder);
      return;
    }

    Set<String> filesInPerforce = new THashSet<String>(new FilePathHashingStrategy());
    Set<String> reportedChanges = new THashSet<String>(new FilePathHashingStrategy());

    final PerforceSettings settings = PerforceSettings.getSettings(myProject);

    Set<P4Connection> connections = new THashSet<P4Connection>();
    final Collection<VirtualFile> roots = dirtyScope.getAffectedContentRoots();
    for (VirtualFile root : roots) {
      connections.add(PerforceConnectionManager.getInstance(myProject).getConnectionForFile(root));
    }

    for (P4Connection connection : connections) {
      processConnection(connection, dirtyScope, settings, builder, filesInPerforce, reportedChanges);
    }

    if (builder.isUpdatingUnversionedFiles()) {
      final Set<String> localFiles = new THashSet<String>(new FilePathHashingStrategy());
      ApplicationManager.getApplication().runReadAction(new Runnable() {
        public void run() {
          dirtyScope.iterate(new Processor<FilePath>() {
            public boolean process(FilePath fileOrDir) {
              if (!fileOrDir.isDirectory()) {
                localFiles.add(fileOrDir.getPath());
              }
              return true;
            }
          });
        }
      });

      final Set<String> unversionedFiles = new THashSet<String>(localFiles, new FilePathHashingStrategy());
      unversionedFiles.removeAll(filesInPerforce);
      unversionedFiles.removeAll(reportedChanges);

      final Set<String> missingFiles = new THashSet<String>(filesInPerforce, new FilePathHashingStrategy());
      missingFiles.removeAll(localFiles);
      missingFiles.removeAll(reportedChanges);

      final LocalFileSystem fs = LocalFileSystem.getInstance();
      ApplicationManager.getApplication().runReadAction(new Runnable() {
        public void run() {
          for (String path : unversionedFiles) {
            final VirtualFile file = fs.findFileByPath(path);
            if (file != null) {
              builder.processUnversionedFile(file);
            }
          }
          for (String path : missingFiles) {
            builder.processLocallyDeletedFile(VcsUtil.getFilePathForDeletedFile(path, false));
          }
        }
      });
    }
  }

  private void getChangesForFiles(final Set<FilePath> dirtyFiles, final ChangelistBuilder builder) {
    PerforceSettings settings = PerforceSettings.getSettings(myProject);
    for(final FilePath filePath: dirtyFiles) {
      if (filePath.isDirectory()) continue;
      P4Connection connection = ApplicationManager.getApplication().runReadAction(new Computable<P4Connection>() {
        public P4Connection compute() {
          return PerforceConnectionManager.getInstance(myProject).getConnectionForFile(filePath.getIOFile());
        }
      });
      P4File file = P4File.create(filePath);
      FStat fStat;
      try {
        fStat = file.getFstat(settings, connection, true);
      }
      catch (VcsException e) {
        final String message = e.getMessage();
        if (message != null && (message.indexOf(PerfCommands.NOT_UNDER_CLIENT_ROOT_MESSAGE) >= 0 ||
                                message.indexOf(PerfCommands.NOT_IN_CLIENT_VIEW_MESSAGE) >= 0)) {
          builder.processUnversionedFile(filePath.getVirtualFile());
        }
        // ignore error (too many weird cases possible to handle)
        continue;
      }
      LOG.debug("getChangesForFiles() filePath=" + filePath + " fStat=" + fStat);
      if (fStat.status == FStat.STATUS_NOT_ADDED) {
        LOG.debug("unversioned");
        builder.processUnversionedFile(filePath.getVirtualFile());
      }
      else if (fStat.local == FStat.LOCAL_DELETING) {
        LOG.debug("deleted");
        builder.processChange(createDeletedFileChange(filePath, connection, fStat));
      }
      else if (!filePath.getIOFile().exists() && fStat.status != FStat.STATUS_DELETED) {
        LOG.debug("locally deleted");
        builder.processLocallyDeletedFile(filePath);
      }
      else if (fStat.local == FStat.LOCAL_ADDING || fStat.local == FStat.LOCAL_BRANCHING) {
        LOG.debug("adding");
        builder.processChange(createAddedFileChange(filePath, fStat));
      }
      else if (fStat.local == FStat.LOCAL_CHECKED_OUT || fStat.local == FStat.LOCAL_INTEGRATING) {
        LOG.debug("edit");
        builder.processChange(createEditedFileChange(filePath, connection, fStat));
      }
      else {
        LOG.debug("Unknown status");
      }
    }
  }

  private void processConnection(final P4Connection connection,
                                 final VcsDirtyScope dirtyScope,
                                 final PerforceSettings settings,
                                 final ChangelistBuilder builder,
                                 final Set<String> filesInPerforce,
                                 final Set<String> reportedChanges) {
    try {

      collectFilesInPerforce(filesInPerforce, dirtyScope, settings, connection);

      final List<org.jetbrains.idea.perforce.perforce.Change> abstractChanges = PerfCommands.p4ChangesForConnection(settings, connection);
      final ChangeListSynchronizer changeListSynchronizer = ChangeListSynchronizer.getInstance(myProject);
      for (PerforceAbstractChange perforceChange : abstractChanges) {
        LOG.debug("retrieved change " + perforceChange);
        final Change change = createChange(perforceChange, connection, settings, dirtyScope);
        if (change != null) {
          if (change.getType() == Change.Type.MODIFICATION) {
            ContentRevision revision = change.getAfterRevision();
            if (revision != null && !revision.getFile().getIOFile().exists()) {
              // let the file be reported as locally deleted (IDEADEV-10306)
              continue;
            }
          }

          if (perforceChange instanceof org.jetbrains.idea.perforce.perforce.Change) {
            long changeListNumber = ((org.jetbrains.idea.perforce.perforce.Change) perforceChange).getChangeListNum();
            String changeListDescription = ((org.jetbrains.idea.perforce.perforce.Change) perforceChange).getChangeListDescription();
            ChangeList changeList = changeListSynchronizer.findOrCreateChangeList(connection, changeListNumber, changeListDescription);
            LOG.debug("processing in list " + changeList);
            builder.processChangeInList(change, changeList);
          }
          else {
            LOG.debug("processing in default list");
            builder.processChange(change);
          }
          final ContentRevision afterRevision = change.getAfterRevision();
          if (afterRevision != null) {
            reportedChanges.add(afterRevision.getFile().getPath());
          }
          final ContentRevision beforeRevision = change.getBeforeRevision();
          if (beforeRevision != null) {
            reportedChanges.add(beforeRevision.getFile().getPath());
          }
        }
      }
    }
    catch (VcsException e) {
      // TODO: handle gracefully.
      new RuntimeException(e);
    }
  }

  static <T extends PerforceAbstractChange> List<T> collectChanges(List<T> changes, List<FilePath> paths) {
    ArrayList<T> result = new ArrayList<T>();
    for (FilePath file : paths) {
      T change = findChange(changes, file);
      if (change != null) {
        result.add(change);
      }
    }
    return result;
  }

  @Nullable
  private static <T extends PerforceAbstractChange> T findChange(List<T> changes, FilePath file) {
    for (T change : changes) {
      if (change.getFile().equals(file.getIOFile())) return change;
    }
    return null;
  }

  public List<VcsException> commit(List<Change> incomingChanges, String preparedComment) {
    ArrayList<VcsException> vcsExceptions = new ArrayList<VcsException>();
    try {
      final PerforceSettings settings = PerforceSettings.getSettings(myProject);

      List<org.jetbrains.idea.perforce.perforce.Change> changes = null;

      final ChangeList list = ChangesUtil.getChangeListIfOnlyOne(myProject, incomingChanges.toArray(new Change[incomingChanges.size()]));
      if (list != null) {
        final List<P4Connection> allConnections = settings.getAllConnections();
        if (allConnections.size() == 1) {
          final P4Connection connection = allConnections.get(0);
          Long changeListNumber = ChangeListSynchronizer.getInstance(myProject).getChangeListNumber(connection, list);
          if (changeListNumber != null) {
            final PerforceClient client = PerforceManager.getInstance(myProject).getClient(connection);
            changes = PerfCommands.p4change(settings, changeListNumber.longValue(), connection, client);
          }
        }
      }
      if (changes == null) {
        changes = PerfCommands.p4AllChanges(settings);
      }

      List<org.jetbrains.idea.perforce.perforce.Change> actualChanges = collectChanges(changes, ChangesUtil.getPaths(incomingChanges));
      if (!actualChanges.isEmpty()){
        try {
          PerfCommands.p4submit(settings, preparedComment, actualChanges);
        }
        catch (VcsException e) {
          vcsExceptions.add(e);
        }

      } else {
        vcsExceptions.add(new VcsException(PerforceBundle.message("exception.text.nothing.found.to.submit")));
      }

      LOG.info("updating opened files after commit");
      ChangeListSynchronizer.getInstance(myProject).updateOpenedFiles();
    }
    catch (VcsException e) {
      vcsExceptions.add(e);
    } finally{
      ApplicationManager.getApplication().runReadAction(new Runnable() {
        public void run() {
          PerforceManager.getInstance(myProject).clearCache();
        }
      });
    }
    return vcsExceptions;
  }

  public List<VcsException> rollbackChanges(List<Change> changes) {
    List<VcsException> exceptions = new ArrayList<VcsException>();

    boolean haveAddedFiles = false;
    for(Change change: changes) {
      if (change.getType() == Change.Type.NEW) {
        haveAddedFiles = true;
        break;
      }
    }

    Set<File> resolvedFiles = null;
    if (haveAddedFiles) {
      resolvedFiles = new HashSet<File>();
      final PerforceSettings settings = PerforceSettings.getSettings(myProject);
      for(P4Connection connection: settings.getAllConnections()) {
        try {
          resolvedFiles.addAll(PerfCommands. getResolvedFiles(settings, connection));
        }
        catch (VcsException e) {
          exceptions.add(e);
        }
      }
    }

    for (Change change : changes) {
      try {
        revertChange(change, resolvedFiles);
      }
      catch (VcsException e) {
        exceptions.add(e);
      }
    }

    return exceptions;
  }

  public List<VcsException> scheduleMissingFileForDeletion(List<FilePath> files) {
    return processMissingFiles(files, true);
  }

  public List<VcsException> rollbackMissingFileDeletion(List<FilePath> files) {
    return processMissingFiles(files, false);
  }

  private List<VcsException> processMissingFiles(final List<FilePath> files, final boolean delete) {
    final List<VcsException> exceptions = new ArrayList<VcsException>();
    final PerforceSettings settings = PerforceSettings.getSettings(myProject);
    for (FilePath file : files) {
      P4Connection connection = PerforceConnectionManager.getInstance(myProject).getConnectionForFile(file.getIOFile());
      try {
        if (delete) {
          PerfCommands.assureDel(P4File.create(file), settings, true, connection);
        }
        else {
          P4File p4file = P4File.create(file);
          FStat fStat;
          try {
            fStat = p4file.getFstat(settings, connection, true);
          }
          catch (VcsException e) {
            continue;
          }
          if (fStat.local == FStat.LOCAL_CHECKED_OUT || fStat.local == FStat.LOCAL_INTEGRATING) {
            PerfCommands.p4revertFile(p4file, settings, false, connection);
          }
          else {
            PerfCommands.p4syncFile(p4file, settings, true, connection);
          }
        }
      }
      catch (VcsException e) {
        exceptions.add(e);
      }
    }

    return exceptions;
  }

  public List<VcsException> scheduleUnversionedFilesForAddition(List<VirtualFile> files) {
    final List<VcsException> exceptions = new ArrayList<VcsException>();
    final PerforceSettings settings = PerforceSettings.getSettings(myProject);
    for (VirtualFile file : files) {
      P4Connection connection = PerforceConnectionManager.getInstance(myProject).getConnectionForFile(file);
      final P4File p4File = P4File.create(file);
      try {
        String complaint = PerfCommands.getFileNameComplaint(p4File);
        if (complaint != null) {
          exceptions.add(new VcsException(complaint));
          continue;
        }
        PerfCommands.p4addFile(p4File, settings, connection);
      }
      catch (VcsException e) {
        exceptions.add(e);
      }
    }

    return exceptions;
  }

  public boolean isModifiedDocumentTrackingRequired() {
    return false;
  }

  private void revertChange(final Change change, final Set<File> resolvedFiles) throws VcsException {
    final File ioFile = ChangesUtil.getFilePath(change).getIOFile();
    boolean deleteLocalCopy = (change.getType() == Change.Type.NEW && resolvedFiles.contains(ioFile));
    P4Connection connection = PerforceConnectionManager.getInstance(myProject).getConnectionForFile(ioFile);
    PerfCommands.p4revertFile(P4File.create(ioFile),
                              PerforceSettings.getSettings(myProject), true,
                              connection);
    if (deleteLocalCopy) {
      FileUtil.delete(ioFile);
    }
  }

  private static void collectFilesInPerforce(Set<String> paths, VcsDirtyScope scope, PerforceSettings settings, P4Connection connection) throws VcsException {
    for (FilePath root : scope.getRecursivelyDirtyDirectories()) {
      paths.addAll(PerfCommands.getAllVersionedFilesIn(root.getVirtualFile(), settings, connection, true));
    }

    for (FilePath path : scope.getDirtyFiles()) {
      if (path.isDirectory()) {
        paths.addAll(PerfCommands.getAllVersionedFilesIn(path.getVirtualFile(), settings, connection, false));
      }
      else {
        final P4File p4File = P4File.create(path);
        final FStat fStat = p4File.getFstat(settings, connection, false);
        if (fStat.status != FStat.STATUS_NOT_ADDED) {
          paths.add(path.getPath());
        }
      }
    }
  }

  private Change createChange(PerforceAbstractChange perforceChange,
                              P4Connection connection,
                              final PerforceSettings settings,
                              final VcsDirtyScope dirtyScope)
    throws VcsException
  {
    final FilePath path = PeerFactory.getInstance().getVcsContextFactory().createFilePathOn(perforceChange.getFile());
    if (path == null || !dirtyScope.belongsTo(path)) return null;

    P4File p4File = P4File.create(path);
    final FStat fStat = p4File.getFstat(settings, connection, false);

    if (perforceChange.getType() == PerforceAbstractChange.ADD || perforceChange.getType() == PerforceAbstractChange.BRANCH) {
      return createAddedFileChange(path, fStat);
    }
    else if (perforceChange.getType() == PerforceAbstractChange.DELETE) {
      return createDeletedFileChange(path, connection, fStat);
    }
    else if (perforceChange.getType() == PerforceAbstractChange.EDIT || perforceChange.getType() == PerforceAbstractChange.INTEGRATE) {
      return createEditedFileChange(path, connection, fStat);
    }

    //TODO: UNKNOWN
    return null;
  }

  private Change createEditedFileChange(final FilePath path, final P4Connection connection, final FStat fStat) {
    return new Change(new PerforceUpToDateRevision(path, connection, fStat.haveRev), new CurrentContentRevision(path), fStat.unresolved != null ? FileStatus.MERGE : FileStatus.MODIFIED);
  }

  private static Change createAddedFileChange(final FilePath path, final FStat fStat) {
    return new Change(null, new CurrentContentRevision(path), fStat.unresolved != null ? FileStatus.MERGE : FileStatus.ADDED);
  }

  private Change createDeletedFileChange(final FilePath path, final P4Connection connection, final FStat fStat) {
    return new Change(new PerforceUpToDateRevision(path, connection, fStat.haveRev), null, fStat.unresolved != null ? FileStatus.MERGE : FileStatus.DELETED);
  }

  private class PerforceUpToDateRevision implements ContentRevision {
    private FilePath myFile;
    private final P4Connection myConnection;
    private String myContent = null;
    private VcsRevisionNumber myRevNumber;

    public PerforceUpToDateRevision(FilePath file, P4Connection connection, String revNumber) {
      myFile = file;
      myConnection = connection;
      try {
        myRevNumber = new VcsRevisionNumber.Long(Long.parseLong(revNumber));
      }
      catch (NumberFormatException e) {
        myRevNumber = VcsRevisionNumber.NULL;
      }
    }

    @Nullable
    public String getContent() {
      if (myContent != null) return myContent;

      try {
        final P4File p4File = P4File.create(myFile);
        final PerforceSettings settings = PerforceSettings.getSettings(myProject);
        if (!settings.ENABLED) return null;
        final FStat fstat = p4File.getFstat(settings, myConnection, false);
        final byte[] bytes = PerfCommands.p4getByteContent(p4File.getAnyPath(), fstat.haveRev, settings, myConnection);
        if (bytes != null) {
          myContent = new String(bytes, CharsetToolkit.getIDEOptionsCharset().name());
          return myContent;
        }
      }
      catch (VcsException e) {
        return e.getLocalizedMessage();
      }
      catch (UnsupportedEncodingException e) {
        return e.getLocalizedMessage();
      }

      return null;
    }

    @NotNull
    public FilePath getFile() {
      return myFile;
    }

    @NotNull
    public VcsRevisionNumber getRevisionNumber() {
      return myRevNumber;
    }
  }
}
