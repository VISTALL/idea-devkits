/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.perforce;

import com.intellij.CommonBundle;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.progress.ProcessCanceledException;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.text.LineTokenizer;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.wm.StatusBar;
import com.intellij.openapi.wm.WindowManager;
import com.intellij.util.text.SyncDateFormat;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.idea.perforce.CancelActionException;
import org.jetbrains.idea.perforce.ChangeListData;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.ServerVersion;
import org.jetbrains.idea.perforce.actions.MessageManager;
import org.jetbrains.idea.perforce.application.ActionWithTempFile;
import org.jetbrains.idea.perforce.application.PerforceClient;
import org.jetbrains.idea.perforce.application.PerforceManager;
import org.jetbrains.idea.perforce.changesBrowser.FileChange;
import org.jetbrains.idea.perforce.merge.BaseRevision;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

@SuppressWarnings({"NonConstantStringShouldBeStringBuffer", "IOResourceOpenedButNotSafelyClosed"})
public final class PerfCommands {
  @NonNls private static final String NO_FILES_TO_RESILVE_MESSAGE = "no file(s) to resolve";
  @NonNls private static final String MERGING_MESSAGE = "- merging";
  @NonNls private static final String USING_BASE_MESSAGE = "using base";
  @NonNls public static final String NOT_UNDER_CLIENT_ROOT_MESSAGE = "is not under client's root";
  @NonNls public static final String NOT_IN_CLIENT_VIEW_MESSAGE = "file(s) not in client view";
  @NonNls private static final String MUST_REFER_TO_CLIENT_MESSAGE = "must refer to client";
  @NonNls private static final String NO_SUCH_FILE_MESSAGE = "no such file(s)";
  @NonNls private static final String CLIENT_FILE_STATUS_FIELD = "clientFile ";
  @NonNls private static final String DEPOT_FILE_STATUS_FIELD = "depotFile ";
  @NonNls private static final String HEAD_ACTION_STATUS_FIELD = "headAction ";
  @NonNls private static final String HEAD_CHANGE_STATUS_FIELD = "headChange ";
  @NonNls private static final String HEAD_REV_STATUS_FIELD = "headRev ";
  @NonNls private static final String HEAD_TYPE_STATUS_FIELD = "headType ";
  @NonNls private static final String HEAD_TIME_STATUS_FIELD = "headTime ";
  @NonNls private static final String HAVE_REV_STATUS_FIELD = "haveRev ";
  @NonNls private static final String ACTION_STATUS_FIELD = "action ";
  @NonNls private static final String ACTION_OWNER_STATUS_FIELD = "actionOwner ";
  @NonNls private static final String CHANGE_STATUS_FIELD = "change ";
  @NonNls private static final String UNRESOLVED_STATUS_FIELD = "unresolved ";
  @NonNls private static final String PASSWORD_INVALID_MESSAGE = "Perforce password (P4PASSWD) invalid or unset";
  @NonNls private static final String SESSION_EXPIRED_MESSAGE = "Your session has expired";
  @NonNls private static final String PASSWORD_NOT_ALLOWED_MESSAGE = "Password not allowed at this server security level";
  @NonNls private static final String LOGGED_IN_MESSAGE = "logged in";
  @NonNls private static final String NO_FILES_TO_RESOLVE_MESSAGE = "No file(s) to resolve";
  @NonNls private static final String MERGING2_MESSAGE = " - merging //";
  @NonNls private static final String PUTPUT_FILE_NAME = "p4.output";
  @NonNls private static final String LINE_SEPARATOR_PROPERTY = "line.separator";
  @NonNls public static final String OWNER = "Owner:";
  @NonNls public static final String USER_NAME = "User name:";
  @NonNls public static final String CLIENT_NAME = "Client name:";
  @NonNls public static final String CLIENT_HOST = "Client host:";
  @NonNls public static final String CLIENT_ROOT = "Client root:";
  @NonNls public static final String ALT_CLIENT_ROOT = "AltRoots:";
  @NonNls public static final String CURRENT_DIRECTORY = "Current directory:";
  @NonNls public static final String CLIENT_ADDRESS = "Client address:";
  @NonNls public static final String SERVER_ADDRESS = "Server address:";
  @NonNls public static final String SERVER_ROOT = "Server root:";
  @NonNls public static final String SERVER_DATE = "Server date:";
  @NonNls public static final String SERVER_LICENSE = "Server license:";
  @NonNls public static final String SERVER_VERSION = "Server version:";
  @NonNls public static final String FILES = "Files:";
  @NonNls public static final String DESCRIPTION = "Description:";
  @NonNls public static final String CHANGE = "Change:";
  @NonNls public static final String CLIENT = "Client:";
  @NonNls public static final String USER = "User:";
  @NonNls public static final String DATE = "Date:";
  @NonNls public static final String STATUS = "Status:";
  @NonNls public static final String JOBS = "Jobs:";
  public static final String[] CHANGE_FORM_FIELDS = new String[]{CHANGE,
    DATE,
    CLIENT,
    USER,
    STATUS,
    DESCRIPTION,
    JOBS,
    FILES};
  @NonNls private static final String FILES_UP_TO_DATE = "file(s) up-to-date.";
  @NonNls public static final String VIEW = "View:";
  @NonNls public static final String CLIENT_FILE_PREFIX = "... clientFile ";
  private static final int MAX_LOG_LENGTH = 1000000;
  @NonNls private static final String STANDARD_REVERT_UNCHANGED_ERROR_MESSAGE = "file(s) not opened on this client";
  @NonNls private static final String YET_ANOTHER_STANDARD_REVERT_UNCHANGED_ERROR_MESSAGE = "file(s) not opened for edit.";
  @NonNls private static final SyncDateFormat DATESPEC_DATE_FORMAT = new SyncDateFormat(new SimpleDateFormat("yyyy/MM/dd:hh:mm:ss", Locale.US));
  @NonNls private static final String NOW = "now";

  private PerfCommands() {
  }

  public static class CommandArguments {
    private final List<String> myArguments = new ArrayList<String>();

    public CommandArguments(List<String> arguments) {
      myArguments.addAll(arguments);
    }

    public CommandArguments() {
    }

    public String[] getArguments() {
      return myArguments.toArray(new String[myArguments.size()]);
    }

    public CommandArguments append(@NonNls @NotNull String argument) {
      myArguments.add(argument);
      return this;
    }

    public CommandArguments append(long argument) {
      myArguments.add(String.valueOf(argument));
      return this;
    }

    public static CommandArguments createOn(@NonNls String argument) {
      final CommandArguments result = new CommandArguments();
      return result.append(argument);
    }

    public CommandArguments createCopy() {
      return new CommandArguments(myArguments);
    }
  }

  private static final Logger LOG = Logger.getInstance("#org.jetbrains.idea.perforce.perforce.PerfCommands");

  private static final String[] AVAILABLE_INFO = new String[]{USER_NAME,
    CLIENT_NAME,
    CLIENT_HOST,
    CLIENT_ROOT,
    ALT_CLIENT_ROOT,
    CURRENT_DIRECTORY,
    CLIENT_ADDRESS,
    SERVER_ADDRESS,
    SERVER_ROOT,
    SERVER_DATE,
    SERVER_LICENSE,
    SERVER_VERSION};

  @Nullable
  static public String getFileNameComplaint(P4File file) throws VcsException {
    String filename = file.getLocalPath();
    if (filename == null) {
      return null;
    }
    if (filename.indexOf('#') >= 0 || filename.indexOf('@') >= 0) {
      return PerforceBundle.message("message.text.invalid.character.in.file.name", filename);
    }
    return null;
  }

  public static void p4reopenFilesInSingleConnection(PerforceSettings settings, P4Connection connection, List<Change> paths, long targetChangeListNumber)
    throws VcsException {
    final CommandArguments arguments = CommandArguments.createOn("reopen");
    arguments.append("-c");
    if (targetChangeListNumber > 0) {
      arguments.append(String.valueOf(targetChangeListNumber));
    }
    else {
      arguments.append("default");
    }

    for (Change change : paths) {
      arguments.append(change.getFile().getPath());
    }

    final ExecResult execResult = executeP4Command(settings, arguments.getArguments(), connection);
    checkError(execResult);
  }

  public static void p4reopenFiles(final PerforceSettings settings, final File[] selectedFiles, final long changeListNumber)
    throws VcsException {
    final CommandArguments arguments = CommandArguments.createOn("reopen");
    arguments.append("-c");
    if (changeListNumber > 0) {
      arguments.append(String.valueOf(changeListNumber));
    }
    else {
      arguments.append("default");
    }

    Map<P4Connection, List<File>> connectionToFile = settings.chooseConnectionForFile(Arrays.asList(selectedFiles));

    executeFileCommands(settings, arguments, connectionToFile);
  }

  private static void executeFileCommands(final PerforceSettings settings,
                                          final CommandArguments arguments,
                                          final Map<P4Connection, List<File>> connectionToFile) throws VcsException {
    for (P4Connection connection : connectionToFile.keySet()) {
      final List<File> files = connectionToFile.get(connection);
      CommandArguments connectionArguments = arguments.createCopy();
      for (File selectedFile : files) {
        connectionArguments.append(selectedFile.getPath());
      }
      final ExecResult execResult = executeP4Command(settings, connectionArguments.getArguments(), connection);
      checkError(execResult);
    }

  }

  public static List<String> p4getClients(final PerforceSettings settings, P4Connection connection) throws VcsException {
    final ExecResult execResult = executeP4Command(settings, new String[]{"clients"}, connection);
    checkError(execResult);
    try {
      return OutputMessageParser.processClientsOutput(execResult.getStdout());
    }
    catch (IOException e) {
      throw new VcsException(e);
    }
  }

  public static List<String> p4getUsers(final PerforceSettings settings, P4Connection connection) throws VcsException {
    final ExecResult execResult = executeP4Command(settings, new String[]{"users"}, connection);
    checkError(execResult);
    try {
      return OutputMessageParser.processUsersOutput(execResult.getStdout());
    }
    catch (IOException e) {
      throw new VcsException(e);
    }
  }

  public static List<PerforceAbstractChange> p4getChangedFiles(final PerforceSettings settings,
                                                               final long number,
                                                               final P4Connection connection) throws VcsException {
    final ExecResult execResult = executeP4Command(settings, new String[]{"describe",
      "-s",
      String.valueOf(number)}, connection);
    checkError(execResult);
    final ProgressIndicator progressIndicator = ProgressManager.getInstance().getProgressIndicator();
    if (progressIndicator != null && progressIndicator.isCanceled()) {
      throw new ProcessCanceledException();
    }
    try {
      return OutputMessageParser.processDescriptionOutput(execResult.getStdout());
    }
    catch (IOException e) {
      throw new VcsException(e);
    }
  }


  public static long p4createChangeList(final PerforceSettings settings, String description, final P4Connection connection,
                                        final List<String> files)
    throws VcsException {
    final String changeListForm = createChangeListForm(settings, description, -1, connection, files);
    if (settings.showCmds()) {
      logMessage(changeListForm);
    }
    final ExecResult execResult = executeP4Command(settings, new String[]{"change",
      "-i"}, connection, new StringBuffer(changeListForm));
    checkError(execResult);
    String output = execResult.getStdout();
    @NonNls final String prefix = "Change";
    if (output.startsWith(prefix)) {
      output = output.substring(prefix.length()).trim();
    }
    int wsPos = output.indexOf(' ');
    if (wsPos >= 0) {
      output = output.substring(0, wsPos).trim();
    }
    try {
      return Long.parseLong(output);
    }
    catch (NumberFormatException e) {
      return -1;
    }
  }

  public static void p4renameChangeList(final PerforceSettings settings, long number, String description,
                                        P4Connection connection) throws VcsException {
    final StringBuffer changeListForm = new StringBuffer(createChangeListForm(settings, description, number, connection, null));
    final ExecResult execResult = executeP4Command(settings,  new String[]{"change", "-i"}, connection, changeListForm);
    checkError(execResult);
  }

  private static String createChangeListForm(final PerforceSettings settings, final String description,
                                             final long changeListNumber, final P4Connection connection,
                                             final List<String> files) throws VcsException {
    @NonNls final StringBuffer result = new StringBuffer();
    result.append("Change:\t");
    if (changeListNumber == -1) {
      result.append("new");
    }
    else {
      result.append(changeListNumber);
    }
    result.append("\n\nClient:\t");
    result.append(PerforceManager.getInstance(settings.getProject()).getClient(connection).getName());
    result.append("\n\nUser:\t");
    result.append(PerforceManager.getInstance(settings.getProject()).getClient(connection).getUserName());
    result.append("\n\nStatus:\t");
    if (changeListNumber == -1) {
      result.append("new");
    }
    else {
      result.append("pending");
    }
    result.append("\n\nDescription:\n\t");
    String[] lines = StringUtil.convertLineSeparators(description).split("\n");
    if (lines.length == 0) {
      lines = new String[] { "<none>" };
    }
    for(String line: lines) {
      result.append("\n\t").append(line);
    }

    if (changeListNumber != -1 || files != null) {
      result.append("\n\nFiles:\n");
      if (files != null) {
        for(String file: files) {
          result.append("\t").append(file).append("\n");
        }
      }
      else {
        final List<Pair<FileChange, Long>> list = p4Opened(settings, connection);
        for(Pair<FileChange, Long> openedFile: list) {
          if (openedFile.second != null && openedFile.second.longValue() == changeListNumber) {
            result.append("\t").append(openedFile.first.getDepotPath()).append("\n");
          }
        }
      }
    }
    
    return result.toString();
  }

  static public void p4editFile(final P4File p4File, final PerforceSettings settings, final P4Connection connection) throws VcsException {
    p4File.invalidateFstat();
    final CommandArguments arguments = CommandArguments.createOn("edit");
    appendChangeList(arguments, settings, connection);
    arguments.append(p4File.getAnyPath());

    final ExecResult execResult = executeP4Command(settings, arguments.getArguments(), connection);
    checkError(execResult);
  }

  private static void appendChangeList(final CommandArguments arguments, final PerforceSettings settings, P4Connection connecton) {
    appendChangeList(arguments, settings.getCurrentChangeListNumber(connecton));
  }

  private static void appendChangeList(final CommandArguments arguments, final long changeListNumber) {
    if (changeListNumber > 0) {
      arguments.append("-c").append(String.valueOf(changeListNumber));
    }
  }

  public static void p4editDir(final P4File p4File, final PerforceSettings settings, final P4Connection connection) throws VcsException {
    p4File.invalidateFstat();
    final CommandArguments arguments = CommandArguments.createOn("edit");
    appendChangeList(arguments, settings, connection);
    arguments.append(p4File.getAnyPath() + "/...");

    final ExecResult execResult = executeP4Command(settings, arguments.getArguments(), connection);
    checkError(execResult);
  }

  static public ExecResult p4syncFile(final P4File p4File, final PerforceSettings settings, boolean sync_force, final P4Connection connection)
    throws VcsException {
    p4File.invalidateFstat();
    final CommandArguments arguments = CommandArguments.createOn("sync");
    if (sync_force) {
      arguments.append("-f");
    }
    arguments.append(p4File.getAnyPath());

    return executeP4Command(settings, arguments.getArguments(), connection);
  }

  public static ExecResult p4integrateBranchSpec(final PerforceSettings settings,
                                             final String branchName,
                                             final String path,
                                             final long changeListNum,
                                             @Nullable final String integrateChangeListNum,
                                             final boolean isReverse,
                                             final P4Connection connection) throws VcsException {
    final CommandArguments arguments = CommandArguments.createOn("integrate");
    if (changeListNum >= 0) {
      arguments.append("-c").append(changeListNum);
    }
    arguments.append("-b").append(branchName);

    if (isReverse) {
      arguments.append("-r");
    }

    if (integrateChangeListNum == null) {
      arguments.append(path + "/...");
    }
    else {
      arguments.append(path + "/...@" + integrateChangeListNum + ",@" + integrateChangeListNum);
    }

    return executeP4Command(settings, arguments.getArguments(), connection);
  }

  public static ExecResult p4syncDir(final P4File p4File, final PerforceSettings settings, boolean force, final P4Connection connection)
    throws VcsException {
    p4File.invalidateFstat();
    final CommandArguments arguments = CommandArguments.createOn("sync");
    if (force) {
      arguments.append("-f");
    }
    arguments.append(p4File.getAnyPath() + "/...");

    return executeP4Command(settings, arguments.getArguments(), connection);
  }

  public static void p4ResolveAutomatically(final VirtualFile p4Dir, final PerforceSettings settings) throws VcsException {
    @NonNls final String[] p4args = new String[]{"resolve",
      "-am",
      p4Dir.getPath() + "/..."};
    final ExecResult execResult = executeP4Command(settings, p4args, settings.getConnectionForFile(p4Dir));
    if (execResult.getStderr().indexOf(NO_FILES_TO_RESILVE_MESSAGE) >= 0) {
      return;
    }
    checkError(execResult);
  }


  static public void p4addFile(final P4File p4File, final PerforceSettings settings, final P4Connection connection) throws VcsException {
    p4File.invalidateFstat();
    final CommandArguments arguments = CommandArguments.createOn("add");
    appendChangeList(arguments, settings, connection);
    arguments.append(p4File.getAnyPath());
    final ExecResult execResult = executeP4Command(settings, arguments.getArguments(), connection);
    checkError(execResult);
  }

  static public void p4integrate(final P4File oldP4File,
                                 final P4File newP4File,
                                 final PerforceSettings settings,
                                 final P4Connection connection) throws VcsException {
    oldP4File.invalidateFstat();
    newP4File.invalidateFstat();
    final CommandArguments arguments = CommandArguments.createOn("integrate");
    appendChangeList(arguments, settings, connection);
    arguments.append("-d");
    arguments.append(oldP4File.getAnyPath()).append(newP4File.getAnyPath());

    final ExecResult execResult = executeP4Command(settings, arguments.getArguments(), connection);
    checkError(execResult);
  }

  static public void p4revertFile(final P4File p4File,
                                  final PerforceSettings settings,
                                  final boolean justTry,
                                  final P4Connection connection) throws VcsException {
    p4File.invalidateFstat();
    final CommandArguments arguments = CommandArguments.createOn("revert");
    final FStat fStat = p4File.getFstat(settings, connection, false);
    if (fStat != null && fStat.depotFile != null) {
      arguments.append(fStat.depotFile);
    }
    else {
      arguments.append(p4File.getAnyPath());
    }

    final ExecResult execResult = executeP4Command(settings, arguments.getArguments(), connection);
    if (!justTry) {
      checkError(execResult);
    }
  }

  static public void p4deleteFile(final P4File p4File, final PerforceSettings settings, final P4Connection connection) throws VcsException {
    p4File.invalidateFstat();
    final CommandArguments arguments = CommandArguments.createOn("delete");
    appendChangeList(arguments, settings, connection);
    arguments.append(p4File.getAnyPath());
    final ExecResult execResult = executeP4Command(settings, arguments.getArguments(), connection);
    checkError(execResult);
  }

  static public List<PerforceAbstractChange> p4changeList(final PerforceSettings settings, Map<P4Connection, ChangeList> currentChangeLists)
    throws VcsException {

    ArrayList<PerforceAbstractChange> result = new ArrayList<PerforceAbstractChange>();

    final List<P4Connection> allConnections = settings.getAllConnections();
    for (P4Connection connection : allConnections) {
      final PerforceClient client = PerforceManager.getInstance(settings.getProject()).getClient(connection);

      final ChangeList changeList;

      if (currentChangeLists.containsKey(connection)) {
        changeList = currentChangeLists.get(connection);
      }
      else {
        changeList = null;
      }

      result.addAll(p4change(settings, changeList, connection, client));
    }

    return result;
  }

  public static List<Change> p4AllChanges(final PerforceSettings settings) throws VcsException {
    ArrayList<Change> result = new ArrayList<Change>();

    final List<P4Connection> allConnections = settings.getAllConnections();
    for (P4Connection connection : allConnections) {
      result.addAll(p4ChangesForConnection(settings, connection));
    }

    return result;
  }

  public static List<Change> p4ChangesForConnection(final PerforceSettings settings, final P4Connection connection)
    throws VcsException {
    List<Change> connectionChanges = new ArrayList<Change>();

    final PerforceClient client = PerforceManager.getInstance(settings.getProject()).getClient(connection);

    final List<ChangeList> changeLists = p4getPendingChangeLists(settings, connection);
    for (ChangeList changeList : changeLists) {
      connectionChanges.addAll(p4change(settings, changeList, connection, client));
    }
    connectionChanges.addAll(p4change(settings, null, connection, client));
    return connectionChanges;
  }

  private static List<Change> p4change(final PerforceSettings settings,
                                       @Nullable final ChangeList changeList,
                                       final P4Connection connection,
                                       final PerforceClient client) throws VcsException {
    final List<Change> result = new ArrayList<Change>();
    long changeListNumber = changeList == null ? -1 : changeList.getNumber();
    Map<String, List<String>> form = p4change(settings, changeListNumber, connection);

    List<String> strings = form.get(FILES);
    if (strings != null) {
      for (String s : strings) {
        final Change change = Change.createOn(s, client, connection, changeList);
        if (change != null) {
          result.add(change);
        }
      }
    }

    return result;
  }

  public static List<Change> p4change(final PerforceSettings settings, final long changeListNumber,
                                      final P4Connection connection, final PerforceClient client) throws VcsException {
    if (changeListNumber == -1) {
      return p4change(settings, null, connection, client);
    }
    final List<ChangeList> list = p4getPendingChangeLists(settings, connection);
    for(ChangeList changeList: list) {
      if (changeList.getNumber() == changeListNumber) {
        return p4change(settings, changeList, connection, client);
      }
    }
    throw new VcsException("Unknown changelist number " + changeListNumber);
  }

  private static Map<String, List<String>> p4change(final PerforceSettings settings, long changeListNumber, P4Connection connection)
    throws VcsException {
    final CommandArguments arguments = CommandArguments.createOn("change");
    arguments.append("-o");
    if (changeListNumber > 0) {
      arguments.append(String.valueOf(changeListNumber));
    }
    final ExecResult execResult = executeP4Command(settings, arguments.getArguments(), connection);
    checkError(execResult);
    return FormParser.execute(execResult.getStdout(), CHANGE_FORM_FIELDS);
  }

  public static void p4submit(PerforceSettings settings, String preparedComment, List<Change> actualChanges) throws VcsException {
    if (preparedComment == null) {
      preparedComment = PerforceBundle.message("default.non.empty.comment");
    }

    for (SubmitJob job : createJobs(actualChanges)) {
      job.submit(settings, preparedComment);
    }
  }

  private static Collection<SubmitJob> createJobs(List<Change> changes) {
    Map<P4Connection, SubmitJob> factoredJobs = new HashMap<P4Connection, SubmitJob>();
    for (Change change : changes) {
      P4Connection connection = change.getConnection();
      SubmitJob job = factoredJobs.get(connection);
      if (job == null) {
        job = new SubmitJob(connection);
        factoredJobs.put(connection, job);
      }
      job.addChange(change);
    }

    return factoredJobs.values();
  }

  private static class SubmitJob {
    private final P4Connection myConnection;
    private final List<Change> myChanges = new ArrayList<Change>();

    public SubmitJob(final P4Connection connection) {
      myConnection = connection;
    }

    public void addChange(final Change change) {
      myChanges.add(change);
    }

    public void submit(PerforceSettings settings, String comment) throws VcsException {
      if (myChanges.size() == 0) return;
      long changeListID = createSingleChangeListForConnection(settings);
      submitForConnection(settings, myConnection, myChanges, changeListID, comment);
    }

    private long createSingleChangeListForConnection(PerforceSettings settings)
      throws VcsException {
      ArrayList<ChangeList> changelists = new ArrayList<ChangeList>();
      HashMap<ChangeList, List<Change>> changesByList = new HashMap<ChangeList, List<Change>>();
      for (Change change : myChanges) {
        final ChangeList changeList = change.getChangeList();
        if (!changelists.contains(changeList)) {
          changelists.add(changeList);
        }
        List<Change> listChanges = changesByList.get(changeList);
        if (listChanges == null) {
          listChanges = new ArrayList<Change>();
          changesByList.put(changeList, listChanges);
        }
        listChanges.add(change);
      }

      if (changelists.size() == 0) return -1;
      if (changelists.size() == 1) {
        ChangeList list = changelists.get(0);
        if (list == null) return -1;
        return list.getNumber();
      }

      final PerforceClient client = PerforceManager.getInstance(settings.getProject()).getClient(myConnection);

      boolean[] full = new boolean[changelists.size()];
      int fullListsCount = 0;
      long targetListID = -1;
      for (int i = 0; i < full.length; i++) {
        ChangeList changeList = changelists.get(i);
        final List<Change> allListChanges = p4change(settings, changeList, myConnection, client);
        full[i] = myChanges.containsAll(allListChanges);
        if (full[i]) {
          targetListID = changeList != null ? changeList.getNumber() : -1;
          fullListsCount++;
        }
      }

      if (fullListsCount != 1) {
        targetListID = -1;
      }

      for (int i = 0; i < changelists.size(); i++) {
        ChangeList changeList = changelists.get(i);
        long victim = changeList == null ? -1 : changeList.getNumber();
        if (victim != targetListID) {
          p4reopenFilesInSingleConnection(settings, myConnection, changesByList.get(changeList), targetListID);
          if (full[i]) {
            deleteEmptyChangeList(settings, myConnection, victim);
          }
        }
      }

      return targetListID;
    }

  }

  public static void deleteEmptyChangeList(final PerforceSettings settings, final P4Connection connection, long listNumber)
    throws VcsException {
    if (listNumber > 0) {
      final CommandArguments arguments = CommandArguments.createOn("change");
      arguments.append("-d");
      arguments.append(String.valueOf(listNumber));
      final ExecResult result = executeP4Command(settings, arguments.getArguments(), connection);
      checkError(result);
    }
  }

  public static void submitForConnection(final PerforceSettings settings,
                                         final P4Connection connection,
                                         final List<Change> changesForConnection,
                                         final long changeListNumber,
                                         final String preparedComment) throws VcsException {
    List<String> excludedChanges = new ArrayList<String>();
    Map<String, List<String>> changeForm = p4change(settings, changeListNumber, connection);
    String originalDescription = getDescription(changeForm);
    final StringBuffer changeData = createChangeData(preparedComment, changesForConnection, changeForm, excludedChanges);
    long newNumber = -1;
    if (changeListNumber == -1) {
      final CommandArguments arguments = CommandArguments.createOn("submit");
      appendChangeList(arguments, changeListNumber);
      arguments.append("-i");
      final ExecResult execResult = executeP4Command(settings, arguments.getArguments(), connection, changeData);
      checkError(execResult);
    }
    else {
      CommandArguments arguments = CommandArguments.createOn("change");
      arguments.append("-i");
      checkError(connection.runP4CommandLine(settings, arguments.getArguments(), changeData));
      arguments = CommandArguments.createOn("submit");
      appendChangeList(arguments, changeListNumber);
      checkError(executeP4Command(settings, arguments.getArguments(), connection));

      if (excludedChanges.size() > 0) {
        LOG.debug("Reopening excluded changes in new changelist");
        newNumber = p4createChangeList(settings, originalDescription, connection, excludedChanges);
      }
    }
    settings.notifyChangeListSubmitted(connection, changeListNumber, newNumber);
  }

  private static String getDescription(final Map<String, List<String>> changeForm) {
    final List<String> strings = changeForm.get(DESCRIPTION);
    if (strings == null) return "";
    return StringUtil.join(strings, "\n");
  }

  private static StringBuffer createChangeData(String preparedComment,
                                               List<Change> actualChanges,
                                               Map<String, List<String>> changeForm,
                                               List<String> excludedChanges) throws VcsException {
    setDescriptionToForm(changeForm, preparedComment);

    List<String> changes = changeForm.get(FILES);

    if (changes != null) {
      String[] changesArray = changes.toArray(new String[changes.size()]);

      for (String changeString : changesArray) {
        if (findChangeByString(actualChanges, changeString) == null) {
          changes.remove(changeString);
          excludedChanges.add(changeString);
        }
      }
    }

    return createStringFormRepresentation(changeForm);

  }

  public static void setDescriptionToForm(Map<String, List<String>> changeForm, String preparedComment) {
    List<String> description = changeForm.get(DESCRIPTION);
    if (description != null) {
      description.clear();
      description.addAll(getAllLines(preparedComment));
    }
    else {
      changeForm.put(DESCRIPTION, getAllLines(preparedComment));
    }
  }

  private static List<String> getAllLines(String preparedComment) {
    List<String> result = new ArrayList<String>();
    String[] lines = LineTokenizer.tokenize(preparedComment, false);
    for (String line1 : lines) {
      String line = line1.trim();
      if (line.length() > 0) {
        result.add(line);
      }
    }

    return result;
  }

  @Nullable
  private static Change findChangeByString(List<Change> actualChanges, String changeString) {
    for (Change change : actualChanges) {
      if (change.getSourceStirng().equals(changeString)) {
        return change;
      }
    }
    return null;
  }

  private static StringBuffer createStringFormRepresentation(Map<String, List<String>> changeForm) {
    StringBuffer result = new StringBuffer();
    for (String field : changeForm.keySet()) {
      result.append("\n");
      result.append(field);

      List<String> values = changeForm.get(field);
      result.append("\n");
      for (String value : values) {
        result.append("\t");
        result.append(value);
        result.append("\n");
      }
    }

    return result;
  }

  public static Map<File, BaseRevision> p4getBaseRevision(final PerforceSettings settings, final P4Connection connection)
    throws VcsException {
    final ExecResult execResult = executeP4Command(settings, new String[]{"resolve",
      "-n",
      "-o"}, connection);
    checkError(execResult);
    try {
      return processResolveOutput(execResult.getStdout());
    }
    catch (IOException e) {
      throw new VcsException(e);
    }
  }

  public static Map<File, BaseRevision> processResolveOutput(final String output) throws IOException {

    final HashMap<File, BaseRevision> result = new HashMap<File, BaseRevision>();

    BufferedReader reader = null;
    try {
      reader = new BufferedReader(new StringReader(output));

      String line;
      while ((line = reader.readLine()) != null) {
        processResolveLine(line, result);
      }
    }
    finally {
      if (reader != null) {
        reader.close();
      }
    }
    return result;
  }

  private static void processResolveLine(final String line, final HashMap<File, BaseRevision> result) {
    int mergingPosition = line.indexOf(MERGING_MESSAGE);
    if (mergingPosition < 0) return;
    File file = new File(line.substring(0, mergingPosition).trim());
    int usingBasePosition = line.indexOf(USING_BASE_MESSAGE);
    if (usingBasePosition < 0) return;
    int revPosition = line.indexOf("#", usingBasePosition);

    String basePath = line.substring(usingBasePosition + USING_BASE_MESSAGE.length(), revPosition).trim();

    if (revPosition < 0) return;
    final String revision = line.substring(revPosition + 1).trim();
    try {
      final long revisionNum = Long.parseLong(revision);
      result.put(file, new BaseRevision(revisionNum, basePath));
    }
    catch (NumberFormatException e) {
      //igore
    }
  }

  public static P4Revision[] p4getRevisions(final VirtualFile file, final PerforceSettings settings) throws VcsException {
    final P4Connection connection = settings.getConnectionForFile(file);
    final CommandArguments arguments = createFilelogArgs(settings, true, connection);
    arguments.append(file.getPath());
    final ExecResult execResult = executeP4Command(settings, arguments.getArguments(), connection);
    checkError(execResult);

    return parseLogOutput(execResult, isNewFormat(settings, connection));
  }

  private static CommandArguments createFilelogArgs(final PerforceSettings settings, boolean showBranches, final P4Connection connection) {
    final CommandArguments arguments = CommandArguments.createOn("filelog");
    if (showBranches) {
      arguments.append("-i");
    }
    arguments.append("-l");
    if (isFilelogNewDateVersion(settings, connection)) {
      arguments.append("-t");
    }
    return arguments;
  }

  private static void appendTArg(final PerforceSettings settings, final CommandArguments arguments, final P4Connection connection) {
    if (isNewFormat(settings, connection)) {
      arguments.append("-t");
    }
  }

  private static boolean isFilelogNewDateVersion(final PerforceSettings settings, final P4Connection connection) {
    final ServerVersion serverVersion = settings.getServerFullVersion(connection);
    if (serverVersion == null) return false;
    return serverVersion.getVersionYear() >= 2003 || (serverVersion.getVersionYear() == 2002 && serverVersion.getVersionNum() > 1);
  }

  private static boolean isNewFormat(final PerforceSettings settings, final P4Connection connection) {
    return settings.getServerVersion(connection) >= 2003;
  }

  static public P4Revision[] p4getRevisions(final P4File p4File, final PerforceSettings settings, final P4Connection connection)
    throws VcsException {
    final CommandArguments args = createFilelogArgs(settings, settings.SHOW_BRANCHES_HISTORY, connection);
    args.append(p4File.getAnyPath());

    final ExecResult execResult = executeP4Command(settings, args.getArguments(), connection);
    checkError(execResult);

    return parseLogOutput(execResult, isNewFormat(settings, connection));

  }

  private static P4Revision[] parseLogOutput(final ExecResult execResult, boolean newDateFormat) throws VcsException {
    try {
      final List<P4Revision> p4Revisions = OutputMessageParser.processLogOutput(execResult.getStdout(), newDateFormat);
      return p4Revisions.toArray(new P4Revision[p4Revisions.size()]);
    }
    catch (IOException e) {
      throw new VcsException(e);
    }
  }

  static public String p4getContents(final P4Revision rev, final PerforceSettings settings, final P4Connection connection)
    throws VcsException {
    return p4getContents(rev.getDepotPath(), String.valueOf(rev.getRevisionNumber()), settings, connection);

  }

  static public byte[] p4getByteContents(final P4Revision rev, final PerforceSettings settings, final P4Connection connection)
    throws VcsException {
    return p4getByteContent(rev.getDepotPath(), String.valueOf(rev.getRevisionNumber()), settings, connection);

  }

  public static String p4getContents(final String depotPath,
                                     final String revisionNumber,
                                     final PerforceSettings settings,
                                     final P4Connection connection) throws VcsException {

    @NonNls final String[] p4args = revisionNumber != null
                                    ? new String[]{"print",
      "-q",
      depotPath + "#" + revisionNumber}
                                    : new String[]{"print",
                                      "-q",
                                      depotPath};
    final ExecResult execResult = executeP4Command(settings, p4args, connection);
    checkError(execResult);

    final StringBuffer ret = new StringBuffer();
    final BufferedReader rdr = new BufferedReader(new StringReader(execResult.getStdout()));
    String s;
    try {
      while ((s = rdr.readLine()) != null) {
        ret.append(s).append(System.getProperty(LINE_SEPARATOR_PROPERTY));
      }
    }
    catch (IOException ex) {
      LOG.info(ex);
    }
    return ret.toString();
  }

  public static byte[] p4getByteContent(final String depotPath,
                                        final String revisionNumber,
                                        final PerforceSettings settings,
                                        P4Connection connection) throws VcsException {

    @NonNls final String[] p4args = revisionNumber != null
                                    ? new String[]{"print",
      "-q",
      depotPath + "#" + revisionNumber}
                                    : new String[]{"print",
                                      "-q",
                                      depotPath};
    final ExecResult execResult = executeP4Command(settings, p4args, connection);
    checkError(execResult);

    return execResult.getByteOut();
  }

  static public void p4resolve(final P4File file, final PerforceSettings settings, final P4Connection connection) throws VcsException {
    @NonNls String[] p4args = {"resolve",
      "-ay",
      file.getAnyPath()};
    final ExecResult execResult = executeP4Command(settings, p4args, connection);
    checkError(execResult);
  }

  public static BranchSpec p4loadBranchSpec(final PerforceSettings settings, final String branchName, final P4Connection connection)
    throws VcsException {
    @NonNls final String[] p4args = {"branch",
      "-o",
      branchName};
    final ExecResult execResult = executeP4Command(settings, p4args, connection);
    checkError(execResult);
    final Map<String, List<String>> branchSpecForm = FormParser.execute(execResult.getStdout(), new String[]{OWNER,
      DESCRIPTION,
      VIEW});
    return new BranchSpec(branchSpecForm);

  }


  static public Map<String, List<String>> p4info(final PerforceSettings settings, final P4Connection connection) throws VcsException {
    @NonNls final String[] p4args = {"info"};
    final ExecResult execResult = executeP4Command(settings, p4args, connection);
    checkError(execResult);
    return FormParser.execute(execResult.getStdout(), AVAILABLE_INFO);
  }

  @Nullable
  static public String p4client(final PerforceSettings settings, final P4Connection connection) throws VcsException {
    List<String> clientNames = p4info(settings, connection).get(CLIENT_NAME);
    if (clientNames == null) {
      return null;
    }
    else {
      return clientNames.get(0);
    }
  }

  static public List<View> p4clientViews(final PerforceSettings settings, final String clientName, final P4Connection connection)
    throws VcsException {
    @NonNls final String[] p4args = {"client",
      "-o",
      clientName};
    final ExecResult execResult = executeP4Command(settings, p4args, connection);
    checkError(execResult);

    final Map<String, List<String>> resultForm = FormParser.execute(execResult.getStdout(), new String[]{"Client:",
      "Owner:",
      "Update:",
      "Access:",
      "Host:",
      "Description:",
      "Root:",
      "AltRoots:",
      "Options:",
      "LineEnd:",
      VIEW});
    final List<String> list = resultForm.get(VIEW);

    final ArrayList<View> result = new ArrayList<View>();
    if (list != null) {
      for (final String aList : list) {
        final View view = View.create(aList);
        if (view != null) {
          result.add(view);
        }

      }
    }
    return result;
  }

  public static List<String> p4loadBranchSpecs(final PerforceSettings settings, final P4Connection connection) throws VcsException {
    final ExecResult result = executeP4Command(settings, new String[]{"branches"}, connection);
    checkError(result);
    try {
      return OutputMessageParser.processBranchesOutput(result.getStdout());
    }
    catch (IOException e) {
      throw new VcsException(e);
    }
  }

  static public void p4where(final P4File p4File, final PerforceSettings settings, final P4Connection connection) throws VcsException {
    @NonNls final String[] p4args = {"where",
      p4File.getAnyPath() + "\\..."};
    ExecResult execResult = executeP4Command(settings, p4args, connection);
    String stderr = execResult.getStderr();
    if (stderr.indexOf(NOT_UNDER_CLIENT_ROOT_MESSAGE) >= 0) {
      throw new VcsException(stderr);
    }

    if (stderr.indexOf(MUST_REFER_TO_CLIENT_MESSAGE) >= 0) {
      throw new VcsException(stderr);
    }

    checkError(execResult);
  }

  private static List<VirtualFile> getFilesFromOutput(final String out, final String separator) throws VcsException {
    final BufferedReader rdr = new BufferedReader(new StringReader(out));
    List<VirtualFile> result = new ArrayList<VirtualFile>();
    String s;
    try {
      while ((s = rdr.readLine()) != null) {

        final int endOfFileName = s.indexOf(separator);
        if (endOfFileName >= 0) {
          final String fileName = s.substring(0, endOfFileName).trim();
          final VirtualFile virtualFile = ApplicationManager.getApplication().runReadAction(new Computable<VirtualFile>() {
            @Nullable public VirtualFile compute() {
              return LocalFileSystem.getInstance().findFileByIoFile(new File(fileName));
          }});
          if (virtualFile != null) result.add(virtualFile);
        }
      }
    }
    catch (IOException e) {
      throw new VcsException(e);
    }

    return result;
  }

  public static Collection<String> getAllVersionedFilesIn(VirtualFile dir,
                                                          PerforceSettings settings,
                                                          P4Connection connection,
                                                          boolean recursively)
    throws VcsException {
    List<String> result = new ArrayList<String>();
    if (dir != null && connection.handlesFile(dir)) {
      // See http://www.perforce.com/perforce/doc.052/manuals/cmdref/have.html#1040665
      // According to Perforce docs output will be presented patterned like: depot-file#revision-number - local-path
      // One line per file

      final ExecResult execResult = executeP4Command(settings, new String[] {"have", dir.getPresentableUrl() + File.separator + (recursively ? "..." : "*")}, connection);
      try {
        BufferedReader reader = new BufferedReader(new StringReader(execResult.getStdout()));
        do {
          String haveline = reader.readLine();
          if (haveline == null || haveline.length() == 0) break;
          result.add(extractLocalPathFromHaveOutput(haveline));
        }
        while (true);
      }
      catch (IOException e) {
        throw new VcsException(e);
      }
    }

    return result;
  }

  private static final String HAVE_DELIM = " - ";
  private static String extractLocalPathFromHaveOutput(final String haveline) {
    final int hashIndex = haveline.indexOf('#');
    final int idx = haveline.indexOf(HAVE_DELIM, hashIndex);
    return haveline.substring(idx + HAVE_DELIM.length());
  }

  public static Map<File, String> splitOutputForEachFile(final String stdOut) throws IOException {
    final BufferedReader reader = new BufferedReader(new StringReader(stdOut));
    String line;
    File file = null;
    StringBuffer currentBuffer = new StringBuffer();
    final HashMap<File, String> result = new HashMap<File, String>();
    while ((line = reader.readLine()) != null) {
      if (line.length() == 0) {
        if (file != null) {
          result.put(file, currentBuffer.toString());
          currentBuffer = new StringBuffer();
          file = null;
        }
      }
      else {
        if (line.startsWith(CLIENT_FILE_PREFIX)) {
          file = new File(line.substring(CLIENT_FILE_PREFIX.length()).trim());
        }
        currentBuffer.append(line);
        currentBuffer.append("\n");
      }
    }

    if (file != null) {
      result.put(file, currentBuffer.toString());
    }

    return result;
  }

  static public FStat p4fstat(final P4File p4File, final PerforceSettings settings, final P4Connection connection) throws VcsException {
    final FStat retVal = new FStat();
    @NonNls final String[] p4args = {"fstat",
      p4File.getEscapedPath()};
    ExecResult execResult = executeP4Command(settings, p4args, connection);
    String stderr = execResult.getStderr();
    if (stderr.indexOf(NO_SUCH_FILE_MESSAGE) >= 0) {
      retVal.status = FStat.STATUS_NOT_ADDED;
      return retVal;
    }
    checkError(execResult);

    parseFStat(execResult.getStdout(), retVal);

    return retVal;
  }

  private static void parseFStat(String stdOut, final FStat retVal) throws VcsException {
    final BufferedReader rdr = new BufferedReader(new StringReader(stdOut));
    String s;
    try {
      while ((s = rdr.readLine()) != null) {
        // ignore empty lines
        if (s.length() == 0) {
          continue;
        }
        // check first "... "
        if (s.indexOf("... ") != 0) {
          throw new VcsException(PerforceBundle.message("exception.text.unexpected.fstat.line.syntax", s));
        }
        final String line = s.substring(4);

        if (line.startsWith(CLIENT_FILE_STATUS_FIELD)) {
          retVal.clientFile = line.substring(11);
        }
        else if (line.startsWith(DEPOT_FILE_STATUS_FIELD)) {
          retVal.depotFile = line.substring(10);
        }
        else if (line.startsWith(HEAD_ACTION_STATUS_FIELD)) {
          retVal.headAction = line.substring(11);
        }
        else if (line.startsWith(HEAD_CHANGE_STATUS_FIELD)) {
          retVal.headChange = line.substring(11);
        }
        else if (line.startsWith(HEAD_REV_STATUS_FIELD)) {
          retVal.headRev = line.substring(8);
        }
        else if (line.startsWith(HEAD_TYPE_STATUS_FIELD)) {
          retVal.headType = line.substring(9);
        }
        else if (line.startsWith(HEAD_TIME_STATUS_FIELD)) {
          retVal.headTime = line.substring(9);
        }
        else if (line.startsWith(HAVE_REV_STATUS_FIELD)) {
          retVal.haveRev = line.substring(8);
        }
        else if (line.startsWith(ACTION_STATUS_FIELD)) {
          retVal.action = line.substring(7);
        }
        else if (line.startsWith(ACTION_OWNER_STATUS_FIELD)) {
          retVal.actionOwner = line.substring(12);
        }
        else if (line.startsWith(CHANGE_STATUS_FIELD)) {
          retVal.change = line.substring(7);
        }
        else if (line.startsWith(UNRESOLVED_STATUS_FIELD)) {
          retVal.unresolved = line.substring(11);
        }
        else {
          if (LOG.isDebugEnabled()) {
            LOG.debug("Unparsed fstat field: \"" + s + "\"");
          }
        }
      }
    }
    catch (IOException ex) {
      throw new VcsException(PerforceBundle.message("exception.text.cannot.parse.fstat.stdout"));
    }

    retVal.resolveStatus();
  }

  static public void assureDel(final P4File p4File,
                               final PerforceSettings settings,
                               final boolean removeLocal,
                               final P4Connection connection) throws VcsException {

    // remove from P4

    final FStat fstat = p4File.getFstat(settings, connection, false);

    if (fstat.status == FStat.STATUS_NOT_ADDED || fstat.status == FStat.STATUS_NOT_IN_CLIENTSPEC || fstat.local == FStat.LOCAL_DELETING) {
      // this is OK, that's what we want
    }
    else {
      // we have to do something about it

      // first, if revert is enough
      if (fstat.local == FStat.LOCAL_ADDING) {
        p4revertFile(p4File, settings, false, connection);
      }
      else if (fstat.local == FStat.LOCAL_CHECKED_IN) {
        p4deleteFile(p4File, settings, connection);
      }
      else {
        p4revertFile(p4File, settings, false, connection);
        try {
          p4deleteFile(p4File, settings, connection);
        }
        catch (Exception ex) {
          // TODO: now we ignore, but we should really check the status after revert
        }
      }
    }

    // remove file
    if (removeLocal) {
      final File file = new File(p4File.getLocalPath());
      if (file.exists()) {
        final boolean res = file.delete();
        if (!res) {
          throw new VcsException(PerforceBundle.message("exception.text.cannot.delete.local.file", p4File));
        }
      }
    }
  }

  static public void assureNoFile(final P4File p4File,
                                  final PerforceSettings settings,
                                  final boolean canBeEdit, final boolean canBeDeleting, final P4Connection connection) throws VcsException {
    // in P4
    final FStat fstat = p4File.getFstat(settings, connection, false);
    if (fstat.status == FStat.STATUS_NOT_ADDED || fstat.status == FStat.STATUS_NOT_IN_CLIENTSPEC || fstat.status == FStat.STATUS_DELETED) {
      // this is OK, that's what we want
    }
    else {
      if (fstat.status == FStat.STATUS_ONLY_LOCAL) {
        p4revertFile(p4File, settings, false, connection);
      }
      else if (canBeDeleting && fstat.local == FStat.LOCAL_DELETING) {
        p4revertFile(p4File, settings, canBeEdit, connection);
        p4editFile(p4File, settings, connection);
      }
      else {
        if (canBeEdit) {
          p4revertFile(p4File, settings, true, connection);
          p4editFile(p4File, settings, connection);
        }
        else {
          throw new VcsException(PerforceBundle.message("exception.text.cannot.assure.no.file.being.on.server", p4File));
        }
      }
    }
  }

  static public void assureAdd(final P4File p4File, final PerforceSettings settings, final P4Connection connection) throws VcsException {
    final FStat fstat = p4File.getFstat(settings, connection, false);
    if (fstat.status == FStat.STATUS_NOT_IN_CLIENTSPEC) {
      // this is not OK, that's what we DON'T want
      throw new VcsException(PerforceBundle.message("exception.text.cannot.add.file.not.under.any.spec", p4File));
    }
    else if (fstat.status == FStat.STATUS_NOT_ADDED || fstat.status == FStat.STATUS_DELETED) {
      p4addFile(p4File, settings, connection);
    }
    else if (fstat.status == FStat.STATUS_ONLY_LOCAL) {
      // I hope this means it is being added
    }
    else {
      // here it EXISTS on server
      if (fstat.local == FStat.LOCAL_DELETING) {
        final String localPath = p4File.getLocalPath();
        final File file = new File(localPath);
        new ActionWithTempFile(file) {
          protected void executeInternal() throws VcsException {
            p4revertFile(p4File, settings, false, connection);
            p4editFile(p4File, settings, connection);
          }
        }.execute();
      }
      else if (fstat.local == FStat.LOCAL_CHECKED_IN) {
        final String localPath = p4File.getLocalPath();
        final File file = new File(localPath);
        new ActionWithTempFile(file) {
          protected void executeInternal() throws VcsException {
            p4syncFile(p4File, settings, false, connection);
            p4editFile(p4File, settings, connection);
          }
        }.execute();

      }
      else {
        // we hope this means the file is being edited, added, etc.
      }
    }
  }

  public static void p4revertUnchangedUnder(String filePath, PerforceSettings settings) throws VcsException {
    p4revertUnchanged(settings, filePath + "/...");
  }

  public static void p4revertUnchangedFile(String filePath, PerforceSettings settings) throws VcsException {
    p4revertUnchanged(settings, filePath);
  }

  private static void p4revertUnchanged(final PerforceSettings settings, final String pattern) throws VcsException {
    final List<P4Connection> allConnections = settings.getAllConnections();
    for (P4Connection connection : allConnections) {
      final ExecResult execResult = PerfCommands.executeP4Command(settings, new String[]{"revert",
        "-a",
        pattern}, connection);
      if (execResult.getStderr().indexOf(STANDARD_REVERT_UNCHANGED_ERROR_MESSAGE) < 0 &&
          execResult.getStderr().indexOf(YET_ANOTHER_STANDARD_REVERT_UNCHANGED_ERROR_MESSAGE) < 0) {
        checkError(execResult);
      }
    }
  }

  static public ExecResult executeP4Command(final PerforceSettings settings, @NonNls final String[] p4args, final P4Connection connection) {
    return executeP4Command(settings, p4args, connection, null);
  }

  static public ExecResult executeP4Command(final PerforceSettings settings, @NonNls final String[] p4args, final P4Connection connection,
                                            @Nullable final StringBuffer inputStream) {
    // construct the command-line
    final ExecResult retVal = new ExecResult();
    if (!settings.ENABLED) {
      retVal.setException(new VcsException(PerforceBundle.message("exception.text.perforce.integration.is.disabled")));
      retVal.setStderr(PerforceBundle.message("exception.text.perforce.integration.is.disabled"));
      return retVal;
    }
    try {
      final StringBuffer status = new StringBuffer();
      for (String p4arg : p4args) {
        status.append(p4arg).append(' ');
      }

      final ProgressIndicator progressIndicator = ProgressManager.getInstance().getProgressIndicator();
      if (progressIndicator != null) {
        progressIndicator.setText2(PerforceBundle.message("progress.text2.p4.status", status));
        progressIndicator.setText(PerforceBundle.message("progress.text.perforce.command"));
      }


      if (settings.showCmds()) {
        logMessage(commandsToString(p4args));
      }

      connection.runP4Command(settings, p4args, retVal, inputStream);

    }
    catch (CancelActionException e) {
      throw e;
    }
    catch (PerforceTimeoutException e) {
      retVal.setException(e);
      retVal.setStderr(PerforceBundle.message("exception.text.perforce.integration.disconnected"));
    }
    catch (IOException e) {
      retVal.setException(e);
    }
    catch (InterruptedException e) {
      retVal.setException(e);
    }
    catch (VcsException e) {
      retVal.setException(e);
    }

    if (settings.showCmds()) {
      logMessage(retVal.toString());
    }


    if (retVal.getStderr().indexOf(SESSION_EXPIRED_MESSAGE) >= 0) {
      boolean loggedIn = tryToLogin(retVal.getStderr(), settings, connection);
      if (loggedIn) {
        return executeP4Command(settings, p4args, connection);
      }
    }

    if (settings.USE_LOGIN && (retVal.getStderr().indexOf(PASSWORD_INVALID_MESSAGE) >= 0)) {
      boolean loggedIn = tryToLogin(retVal.getStderr(), settings, connection);
      if (loggedIn) {
        return executeP4Command(settings, p4args, connection);
      }

    }
    else {
      if ((retVal.getStderr().indexOf(PASSWORD_INVALID_MESSAGE) >= 0)) {
        final WindowManager windowManager = WindowManager.getInstance();
        final StatusBar statusBar = windowManager.getStatusBar(settings.getProject());
        if (statusBar != null) {
          statusBar.setInfo(PerforceBundle.message("p4.login.error.status.text", retVal.getStderr()));
        }

      }
    }

    if (!settings.USE_LOGIN && retVal.getStderr().indexOf(PASSWORD_NOT_ALLOWED_MESSAGE) >= 0) {
      if (MessageManager.showDialog(settings.getProject(), PerforceBundle.message("confirmation.text.password.not.allowed.enable.login"),
                                    PerforceBundle.message("dialog.title.perforce"), new String[]{CommonBundle.getYesButtonText(),
        PerforceBundle.message("button.text.disable.integration")}, 0, Messages.getQuestionIcon()) == 0) {
        settings.USE_LOGIN = true;
        PerforceConnectionManager.getInstance(settings.getProject()).refreshConnections(settings);

        ApplicationManager.getApplication().invokeLater(new Runnable() {
          public void run() {
            PerforceManager.getInstance(settings.getProject()).configurationChanged();
          }
        });
        return executeP4Command(settings, p4args, connection);
      }
      else {
        settings.disable();
        return retVal;
      }
    }

    else {
      return retVal;
    }
  }

  private static void performLogin(String password, PerforceSettings settings, final P4Connection connection) throws VcsException {
    final StringBuffer data = new StringBuffer();
    data.append(password);
    final ExecResult loginResult = connection.runP4CommandLine(settings, new String[]{"login"}, data);
    if (loginResult.getStderr().length() > 0 || loginResult.getStdout().indexOf(LOGGED_IN_MESSAGE) < 0) {
      throw new VcsException(loginResult.getStderr());
    }

    if (loginResult.getException() != null) {
      throw new VcsException(loginResult.getException());
    }
  }

  private static boolean login(String message, final PerforceSettings settings, boolean trySilently, final P4Connection connection) {

    if (trySilently) {
      try {
        performLogin(settings.getPasswd(), settings, connection);
        return true;
      }
      catch (VcsException e) {
        //ignore
      }
    }

    String password = requestForPassword(settings.getProject(), message, settings.getPasswd());
    if (password != null) {
      try {
        performLogin(password, settings, connection);
        settings.setPasswd(password);
        return true;
      }
      catch (VcsException e) {
        return login(e.getLocalizedMessage(), settings, false, connection);
      }
    }
    else {
      settings.disable();
      return false;
    }

  }

  @Nullable
  private static String requestForPassword(Project project, final String message, String defaultValue) {
    final PerforceLoginDialog pwdDialog = new PerforceLoginDialog(project, PerforceBundle.message(
      "message.text.perforce.command.failed.enter.password", message), defaultValue);
    pwdDialog.show();
    if (pwdDialog.isOK()) {
      return pwdDialog.getPassword();
    }
    else {
      return null;
    }
  }

  private static boolean tryToLogin(final String errMessage, final PerforceSettings settings, final P4Connection connection) {
    try {
      final boolean[] result = new boolean[]{false};
      MessageManager.runShowAction(new Runnable() {
        public void run() {
          result[0] = login(errMessage, settings, settings.LOGIN_SILENTLY, connection);
        }
      });

      return result[0];
    }
    finally {
      PerforceConnectionManager.getInstance(settings.getProject()).refreshConnections(settings);
    }
  }

  private static void logMessage(final String message) {
    logMessage(message, getDumpFile(), MAX_LOG_LENGTH);
  }

  public static void logMessage(final String message, File file, long maxFileLength) {
    try {
      if (file.length() > maxFileLength) {
        file.delete();
      }
      final OutputStream output = new BufferedOutputStream(new FileOutputStream(file, true));
      try {

        output.write(message.getBytes());
      }
      catch (Exception e) {
        //ignore
      }
      finally {
        output.close();
      }
    }
    catch (IOException e) {
      //ignore
    }
  }

  private static String commandsToString(final String[] p4args) {
    final StringBuffer result = new StringBuffer();
    for (int i = 0; i < p4args.length; i++) {
      String p4arg = p4args[i];
      if (i != 0) result.append(" ");
      result.append(p4arg);
    }
    return result.toString();
  }


  public static void checkError(final ExecResult result) throws VcsException {
    final boolean error = (result.getExitCode() < 0) || (result.getException() != null) || (containsErrorOutput(result));
    if (error) {
      if (result.getException() != null) {
        throw new VcsException(result.getException());
      }
      else {
        throw new VcsException(result.getStderr());
      }
    }
  }

  public static VcsException[] checkErrors(final ExecResult result) {
    final boolean error = (result.getExitCode() < 0) || (result.getException() != null) || (containsErrorOutput(result));
    if (error) {
      if (result.getException() != null) {
        return new VcsException[] { new VcsException(result.getException()) };
      }
      else {
        String[] lines = result.getStderr().split("\n");
        VcsException[] errors = new VcsException[lines.length];
        for(int i=0; i<lines.length; i++) {
          errors [i] = new VcsException(lines [i]);
        }
        return errors;
      }
    }
    return VcsException.EMPTY_ARRAY;        
  }

  private static boolean containsErrorOutput(final ExecResult result) {
    String errorOutput = result.getStderr();
    if (errorOutput.indexOf(FILES_UP_TO_DATE) >= 0) return false;
    return errorOutput.length() > 2;
  }

  public static VirtualFile[] p4getResolvedWithConflicts(final PerforceSettings settings) throws VcsException {

    List<VirtualFile> result = new ArrayList<VirtualFile>();

    List<P4Connection> allConnections = settings.getAllConnections();

    for (P4Connection p4Connection : allConnections) {
      final ExecResult execResult = executeP4Command(settings, new String[]{"resolve",
        "-n"}, p4Connection);
      if (execResult.getStderr().indexOf(NO_FILES_TO_RESOLVE_MESSAGE) >= 0) return new VirtualFile[0];

      result.addAll(getFilesFromOutput(execResult.getStdout(), MERGING2_MESSAGE));
    }

    return result.toArray(new VirtualFile[result.size()]);
  }

  public static File getDumpFile() {
    return new File(PUTPUT_FILE_NAME);
  }

  private static CommandArguments appendUserName(final PerforceSettings settings, CommandArguments args, final P4Connection connection) {
    final String userName = PerforceManager.getInstance(settings.getProject()).getClient(connection).getUserName();
    if (userName != null) {
      return args.append("-u").append(userName);
    }
    else {
      return args;
    }
  }

  private static CommandArguments appendClientName(final PerforceSettings settings, CommandArguments args, final P4Connection connection) {
    final String userName = PerforceManager.getInstance(settings.getProject()).getClient(connection).getName();
    if (userName != null) {
      return args.append("-c").append(userName);
    }
    else {
      return args;
    }
  }

  public static List<ChangeList> p4getPendingChangeLists(final PerforceSettings settings, final P4Connection connection)
    throws VcsException {
    final CommandArguments args = CommandArguments.createOn("changes");
    args.append("-i");
    appendTArg(settings, args, connection);
    args.append("-l")
      .append("-s").append("pending");

    appendUserName(settings, args, connection);
    appendClientName(settings, args, connection);
    final ExecResult execResult = executeP4Command(settings, args.getArguments(), connection);
    checkError(execResult);
    return parseChangeLists(execResult.getStdout(), settings.getProject(), connection);
  }


  public static List<Pair<FileChange, Long>> p4Opened(final PerforceSettings settings, final P4Connection connection) throws VcsException {
    final CommandArguments args = CommandArguments.createOn("opened");
    final ExecResult execResult = executeP4Command(settings, args.getArguments(), connection);
    if (execResult.getStderr().toLowerCase().indexOf(STANDARD_REVERT_UNCHANGED_ERROR_MESSAGE) >= 0) {
      // no files opened
      return new ArrayList<Pair<FileChange, Long>>();
    }
    checkError(execResult);
    try {
      return OutputMessageParser.processOpenedOutput(execResult.getStdout());
    }
    catch (IOException e) {
      throw new VcsException(e);
    }
  }

  public static List<ChangeList> p4getSubmittedChangeLists(final PerforceSettings settings,
                                                           String client,
                                                           String user,
                                                           final P4File rootP4File,
                                                           Date after,
                                                           Date before,
                                                           Long afterChange,
                                                           Long beforeChange,
                                                           final P4Connection connection) throws VcsException {
    final CommandArguments arguments = CommandArguments.createOn("changes");
    arguments.append("-s").append("submitted").append("-i");
    appendTArg(settings, arguments, connection);
    arguments.append("-l");

    if (client != null && client.length() > 0) {
      arguments.append("-c").append(client);
    }
    if (user != null && user.length() > 0) {
      arguments.append("-u").append(user);
    }

    if (rootP4File != null) {
      arguments.append(rootP4File.getAnyPath() + "/..." + dateSpec(after, before, afterChange, beforeChange));
    }
    else {
      arguments.append("//..." + dateSpec(after, before, afterChange, beforeChange));
    }

    final ExecResult execResult = executeP4Command(settings, arguments.getArguments(), connection);
    checkError(execResult);
    return parseChangeLists(execResult.getStdout(), settings.getProject(), connection);
  }

  private static String dateSpec(final Date after, final Date before, final Long afterChange, final Long beforeChange) {

    if (after == null && before == null && afterChange == null && beforeChange == null) {
      return "";
    }

    final StringBuffer result = new StringBuffer();
    result.append('@');
    if (after != null) {
      result.append(DATESPEC_DATE_FORMAT.format(after));
    }
    else if (afterChange != null) {
      result.append(afterChange.longValue());
    }
    else {
      result.append(DATESPEC_DATE_FORMAT.format(new Date(0)));
    }
    result.append(',');
    result.append('@');
    if (before != null) {
      result.append(DATESPEC_DATE_FORMAT.format(before));
    }
    else if (beforeChange != null) {
      result.append(beforeChange.longValue());
    }
    else {
      result.append(NOW);
    }

    return result.toString();
  }

  private static List<ChangeList> parseChangeLists(final String m_stdout, Project project, P4Connection connection) throws VcsException {
    try {
      final List<ChangeListData> datas = OutputMessageParser.processChangesOutput(m_stdout);
      final ArrayList<ChangeList> result = new ArrayList<ChangeList>();
      for (ChangeListData data : datas) {
        result.add(new ChangeList(data, project, connection));
      }
      return result;
    }
    catch (IOException e) {
      throw new VcsException(e);
    }
  }

  public static Set<File> getResolvedFiles(final PerforceSettings settings, final P4Connection connection) throws VcsException {
    Set<File> result = new HashSet<File>();
    final CommandArguments args = CommandArguments.createOn("resolved");
    final ExecResult execResult = executeP4Command(settings, args.getArguments(), connection);
    checkError(execResult);
    for(String line: execResult.getStdout().split("\n")) {
      int pos = line.indexOf(" - ");
      if (pos >= 0) {
        result.add(new File(line.substring(0, pos)));
      }
    }
    return result;
  }
}
