/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.VcsShowConfirmationOption;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.ui.ConfirmationDialog;
import org.jetbrains.idea.perforce.CancelActionException;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.actions.ActionAdd;
import org.jetbrains.idea.perforce.actions.ActionBaseFile;
import org.jetbrains.idea.perforce.actions.MessageManager;
import org.jetbrains.idea.perforce.perforce.FStat;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

import java.util.ArrayList;
import java.util.List;

public class AddHandler extends BaseAddDeleteHandler {
  private final List<VirtualFile> myAddedFiles = new ArrayList<VirtualFile>();
  private final ActionBaseFile.TemporarySettings myTempSettings = new ActionBaseFile.TemporarySettings(1);

  public AddHandler(Project project) {
    super(project);
  }

  protected void processFile(VirtualFile file) {
    myAddedFiles.add(file);
  }

  public void execute() throws VcsException {
    if (myAddedFiles.isEmpty()) return;
    if (PerforceVcs.getInstance(myProject).getAddOption().getValue() == VcsShowConfirmationOption.Value.DO_NOTHING_SILENTLY) return;
    if (PerforceVcs.getInstance(myProject).getAddOption().getValue() == VcsShowConfirmationOption.Value.DO_ACTION_SILENTLY) {
      performAdding();
    }
    else {
      if (!requestForConfirmation(composeMesasge())) {
        return;
      }
      performAdding();
    }
  }

  private String composeMesasge() {
    final StringBuffer files = new StringBuffer();
    for (VirtualFile file : myAddedFiles) {
      final String path = file.getPath();
      files.append("\n");
      files.append(path);
    }
    return PerforceBundle.message("confirmation.text.add.files", files.toString());
  }

  private boolean requestForConfirmation(final String msg) {
    final boolean[] result = new boolean[1];
    Runnable runnable = new Runnable() {
      public void run() {
        result[0] = ConfirmationDialog.requestForConfirmation(PerforceVcs.getInstance(myProject).getAddOption(),
                                                              myProject,
                                                              msg,
                                                              PerforceBundle.message("confirmation.title.add.files"),
                                                              Messages.getQuestionIcon());
      }
    };
    MessageManager.runShowAction(runnable);
    return result[0];
  }

  private void performAdding() throws VcsException {
    for (VirtualFile file : myAddedFiles) {
      createdVFile(file, PerforceSettings.getSettings(myProject), myTempSettings);
    }
  }

  private static void createdVFile(final VirtualFile vFile,
                                   PerforceSettings settings,
                                   final ActionBaseFile.TemporarySettings tempSettings) throws CancelActionException, VcsException {
    if (vFile.isDirectory()) {
      return;
    }
    final Project project = settings.getProject();

    final P4File p4File = P4File.create(vFile);


    // check whether it will be under any clientspec
    final P4Connection connection = PerforceConnectionManager.getInstance(settings.getProject()).getConnectionForFile(vFile);
    final FStat p4FStat = p4File.getFstat(settings, connection, true);
    if (p4FStat.status == FStat.STATUS_NOT_IN_CLIENTSPEC ||
        p4FStat.status == FStat.STATUS_UNKNOWN) {
      return;
    }
    // already being added or edited or something
    if (p4FStat.local == FStat.LOCAL_ADDING ||
        p4FStat.local == FStat.LOCAL_BRANCHING ||
        p4FStat.local == FStat.LOCAL_CHECKED_OUT ||
        p4FStat.local == FStat.LOCAL_INTEGRATING) {
      return;
    }

    final ActionAdd actionAdd = new ActionAdd();

    actionAdd.performAction(vFile, settings, project, true, true, tempSettings);
  }

}
