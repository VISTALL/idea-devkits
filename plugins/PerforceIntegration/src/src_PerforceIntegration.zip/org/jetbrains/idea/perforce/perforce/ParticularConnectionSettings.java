package org.jetbrains.idea.perforce.perforce;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.DefaultJDOMExternalizer;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMExternalizable;
import com.intellij.openapi.util.WriteExternalException;
import org.jdom.Element;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

public class ParticularConnectionSettings implements JDOMExternalizable {
  public String INTEGRATED_CHANGE_LIST_NUMBER = "";
  public boolean INTEGRATE_CHANGE_LIST = false;
  public boolean INTEGRATE_REVERSE= false;
  public String INTEGRATE_BRANCH_NAME = null;
  public long INTEGRATE_TO_CHANGELIST_NUM = -1;

  public ParticularConnectionSettings(final Project project, P4Connection connection) {
  }

  public void readExternal(Element element) throws InvalidDataException {
    DefaultJDOMExternalizer.readExternal(this, element);
  }

  public void writeExternal(Element element) throws WriteExternalException {
    DefaultJDOMExternalizer.writeExternal(this, element);
  }
}
