/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.merge;

import com.intellij.openapi.vcs.merge.MergeProvider;
import com.intellij.openapi.vcs.merge.MergeData;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.project.Project;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.annotations.NotNull;

public class PerforceMergeProvider implements MergeProvider {
  private final Project myProject;

  public PerforceMergeProvider(final Project project) {
    myProject = project;
  }

  @NotNull
  public MergeData loadRevisions(final VirtualFile file) throws VcsException {
    final MergeData mergeData = new MergeData();
    final PerforceSettings settings = PerforceSettings.getSettings(myProject);
    final P4Connection connection = settings.getConnectionForFile(file);
    final Map<File, BaseRevision> revisions = PerfCommands.p4getBaseRevision(settings, connection);
    BaseRevision baseRevision = revisions.get(new File(file.getPath()));
    if (baseRevision == null) throw new VcsException(
      PerforceBundle.message("message.text.cannot.find.merge.info.for.file", file.getPresentableUrl()));
    mergeData.ORIGINAL = PerfCommands.p4getContents(baseRevision.getDepotPath(),
                                                    String.valueOf(baseRevision.getRevisionNum()),
                                                    settings,
                                                    settings.getConnectionForFile(file)).getBytes();

    mergeData.LAST = PerfCommands.p4getContents(file.getPath(),
                                                null,
                                                settings,
                                                settings.getConnectionForFile(file)).getBytes();
    try {
      mergeData.CURRENT = file.contentsToByteArray();
    }
    catch (IOException e) {
      throw new VcsException(e);
    }
    return mergeData;

  }

  public void conflictResolvedForFile(VirtualFile file) {
    try {
      PerfCommands.p4resolve(P4File.create(file), PerforceSettings.getSettings(myProject),
                             PerforceConnectionManager.getInstance(myProject).getConnectionForFile(file));
    }
    catch (VcsException e) {
      //ignore
    }
  }
}
