package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.Task;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.changes.Change;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vcs.rollback.RollbackEnvironment;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.operations.P4RevertOperation;
import org.jetbrains.idea.perforce.perforce.FStat;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerforceRunner;

import java.util.ArrayList;
import java.util.List;

/**
 * @author yole
 */
public class PerforceRollbackEnvironment implements RollbackEnvironment {
  private static final Logger LOG = Logger.getInstance("#org.jetbrains.idea.perforce.application.PerforceRollbackEnvironment");

  private final Project myProject;
  private final PerforceRunner myRunner;

  public PerforceRollbackEnvironment(final Project project) {
    myProject = project;
    myRunner = PerforceRunner.getInstance(project);
  }

  public String getRollbackOperationName() {
    return PerforceBundle.message("operation.name.revert");
  }

  public List<VcsException> rollbackChanges(List<Change> changes) {
    List<VcsException> exceptions = new ArrayList<VcsException>();

    for (Change change : changes) {
      try {
        new P4RevertOperation(change).execute(myProject);
      }
      catch (VcsException e) {
        exceptions.add(e);
      }
    }

    return exceptions;
  }

  public List<VcsException> rollbackMissingFileDeletion(List<FilePath> files) {
    final List<VcsException> exceptions = new ArrayList<VcsException>();
    for (FilePath file : files) {
      try {
        P4File p4file = P4File.create(file);
        FStat fStat;
        try {
          fStat = p4file.getFstat(myProject, true);
        }
        catch (VcsException e) {
          continue;
        }
        if (fStat.local == FStat.LOCAL_CHECKED_OUT || fStat.local == FStat.LOCAL_INTEGRATING) {
          myRunner.revert(p4file, false);
        }
        else {
          myRunner.sync(p4file, true);
        }
      }
      catch (VcsException e) {
        exceptions.add(e);
      }
    }

    return exceptions;
  }

  public List<VcsException> rollbackModifiedWithoutCheckout(final List<VirtualFile> files) {
    List<VcsException> exceptions = new ArrayList<VcsException>();
    for(VirtualFile file: files) {
      P4File p4File = P4File.create(file);
      try {
        myRunner.edit(p4File);
        myRunner.revert(p4File, false);
      }
      catch (VcsException e) {
        exceptions.add(e);
      }
    }
    return exceptions;
  }

  public void rollbackIfUnchanged(final VirtualFile file) {
    Task.Backgroundable rollbackTask =
      new Task.Backgroundable(myProject, PerforceBundle.message("progress.title.reverting.unmodified.file")) {
        public void run(final ProgressIndicator indicator) {
          try {
            final boolean reverted = PerforceRunner.getInstance(myProject).revertUnchanged(P4File.create(file));
            if (reverted) {
              file.refresh(true, false, new Runnable() {
                public void run() {
                  VcsDirtyScopeManager.getInstance(myProject).fileDirty(file);
                }
              });
            }
          }
          catch (VcsException e) {
            // ignore
            LOG.debug(e);
          }
        }
      };
    PerforceVcs.getInstance(myProject).runTask(rollbackTask);
  }

}
