package org.jetbrains.idea.perforce.perforce.jobs;

public enum PerforceJobFieldType {
  word,
  date,
  select,
  line,
  text;
}
