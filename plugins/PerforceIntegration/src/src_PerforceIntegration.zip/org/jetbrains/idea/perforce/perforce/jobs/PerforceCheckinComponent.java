package org.jetbrains.idea.perforce.perforce.jobs;

import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.changes.LocalChangeList;
import com.intellij.openapi.vcs.checkin.CheckinChangeListSpecificComponent;
import com.intellij.util.Consumer;
import com.intellij.util.Icons;
import org.jetbrains.idea.perforce.application.ConnectionKey;
import org.jetbrains.idea.perforce.application.PerforceVcs;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class PerforceCheckinComponent implements CheckinChangeListSpecificComponent, JobsTablePresentation {
  private final Project myProject;
  private JPanel myPanel;

  private LocalChangeList myCurrent;
  private Map<LocalChangeList, Map<ConnectionKey, java.util.List<PerforceJob>>> myCache;
  private final PerforceVcs myVcs;
  private Map<ConnectionKey, P4JobsLogicConn> myConnMap;
  private AdderRemover myAdderRemover;

  private final JobsMasterDetails myDetails;

  public PerforceCheckinComponent(final Project project) {
    myProject = project;
    myVcs = PerforceVcs.getInstance(myProject);
    myConnMap = new HashMap<ConnectionKey, P4JobsLogicConn>();
    myCache = new HashMap<LocalChangeList, Map<ConnectionKey, java.util.List<PerforceJob>>>();

    myDetails = new JobsMasterDetails(myProject) {
      @Override
      protected Dimension getPanelPrefferedSize() {
        return new Dimension(200, 70);
      }
    };
    myDetails.onlyMain();

    initUI();
    myAdderRemover = new WiseAdderRemover(myProject, this);
  }

  public void refreshJobs(PerforceJob job) throws VcsException {
    if (! myCurrent.hasDefaultName()) {
      final Map<ConnectionKey, List<PerforceJob>> data = loadOnSelect(myCurrent);
      myCache.put(myCurrent, data);
      ApplicationManager.getApplication().invokeLater(new Runnable() {
        public void run() {
          setItems(flattenList(data.values()));
        }
      });
    }
  }

  public void addJob(PerforceJob job) {
    // todo todo 2
    final Map<ConnectionKey, List<PerforceJob>> data = getCurrentListJobs();
    if (data != null) {
      List<PerforceJob> jobs = data.get(job.getConnectionKey());
      if (jobs == null) {
        jobs = new ArrayList<PerforceJob>();
        data.put(job.getConnectionKey(), jobs);
      }
      jobs.add(job);
      saveJobsInCache(data);
      setItems(flattenList(data.values()));
    }
  }

  private Map<ConnectionKey, List<PerforceJob>> getCurrentListJobs() {
    final Map<ConnectionKey, List<PerforceJob>> data;
    if (myCurrent.hasDefaultName()) {
      data = myVcs.getDefaultAssociated();
    } else {
      data = myCache.get(myCurrent);
    }
    return data;
  }

  public void removeSelectedJob() {
    final PerforceJob job = myDetails.getSelectedJob();
    if (job == null) return;
    myDetails.removeSelectedJob();

    final Map<ConnectionKey, List<PerforceJob>> data = getCurrentListJobs();
    if (data != null) {
      data.get(job.getConnectionKey()).remove(job);
      setItems(flattenList(data.values()));
    }
  }

  public void selectDefault() {
    // todo
  }

  private JComponent createToolbar() {
    final DefaultActionGroup group = new DefaultActionGroup();
    group.add(new AnAction("Unlink selected job", "Unlink selected job", Icons.DELETE_ICON) {
      public void actionPerformed(AnActionEvent e) {
        final PerforceJob job = myDetails.getSelectedJob();
        if (job != null) {
          final VcsException vcsException = myAdderRemover.remove(job, myCurrent, myProject);
          if (vcsException != null) {
            new ErrorReporter("removing job from changelist").report(myProject, vcsException);
          }
        }
      }

      @Override
      public void update(AnActionEvent e) {
        final PerforceJob job = myDetails.getSelectedJob();
        e.getPresentation().setEnabled(job != null);
      }
    });

    group.add(new AnAction("Edit Associated Jobs", "Edit Associated Jobs", IconLoader.getIcon("/actions/editSource.png")) {
      @Override
      public void actionPerformed(AnActionEvent e) {
        final Map<ConnectionKey, java.util.List<PerforceJob>> data = getCurrentListJobs();
        if (data == null) {
          return;
        }
        ensureDefaultConnections();

        final EditChangelistJobsDialog dialog =
          new EditChangelistJobsDialog(myProject, myCurrent, myCurrent.hasDefaultName(), myConnMap, data);
        dialog.show();
        final Map<ConnectionKey, List<PerforceJob>> jobs = dialog.getJobs();
        saveJobsInCache(jobs);
        setItems(flattenList(jobs.values()));
      }
    });

    group.add(new TextFieldAction("Find and link job matching pattern", "Find and link job matching pattern", IconLoader.getIcon("/actions/include.png")) {
      public void actionPerformed(AnActionEvent e) {
        final String text = myField.getText().trim();
        if (text.length() > 0) {
          ensureDefaultConnections();

          if (myCurrent != null) {
            final ConnectionSelector selector = new ConnectionSelector(myProject, myCurrent);
            final Map<ConnectionKey, P4Connection> p4ConnectionMap = selector.getConnections();
            if (p4ConnectionMap.isEmpty()) return;
            if (p4ConnectionMap.size() == 1) {
              final ConnectionKey key = p4ConnectionMap.keySet().iterator().next();
              final Pair<ConnectionKey,P4Connection> pair = new Pair<ConnectionKey, P4Connection>(key, p4ConnectionMap.get(key));
              if(addImpl(text, pair)) {
                myField.setText("");
              }
            } else {
              ConnectionSelector.selectConnection(p4ConnectionMap, new Consumer<ConnectionKey>() {
                public void consume(ConnectionKey connectionKey) {
                  if (connectionKey != null) {
                    if (addImpl(text, new Pair<ConnectionKey, P4Connection>(connectionKey, p4ConnectionMap.get(connectionKey)))) {
                      myField.setText("");
                    }
                  }
                }
              });
            }
          }
        }
      }
    });

    final ActionToolbar actionToolbar = ActionManager.getInstance().createActionToolbar(ActionPlaces.UNKNOWN, group, true);
    return actionToolbar.getComponent();
  }

  private void initUI() {
    myPanel = new JPanel(new GridBagLayout());

    final GridBagConstraints gb = DefaultGb.create();
    gb.insets = new Insets(0,0,0,0);
    gb.anchor = GridBagConstraints.WEST;

    // todo prompt message when jobs ought to exist for CL
    final JLabel jobsPrompt = new JLabel("Jobs:");
    gb.gridwidth = 3;
    myPanel.add(jobsPrompt, gb);

    ++ gb.gridy;
    gb.fill = GridBagConstraints.HORIZONTAL;
    myPanel.add(createToolbar(), gb);

    ++ gb.gridy;
    gb.fill = GridBagConstraints.BOTH;
    final JComponent comp = myDetails.createComponent();
    myPanel.add(comp, gb);
  }

  private void saveJobsInCache(Map<ConnectionKey, List<PerforceJob>> jobs) {
    if (myCurrent.hasDefaultName()) {
      myVcs.setDefaultAssociated(jobs);
    } else {
      myCache.put(myCurrent, jobs);
    }
  }

  private boolean addImpl(String text, Pair<ConnectionKey, P4Connection> pair) {
    if (pair != null) {
      final P4JobsLogicConn connMap = myConnMap.get(pair.getFirst());
      if (connMap != null) {
        final PerforceJob job = new JobDetailsLoader(myProject).searchForJobByPattern(text, connMap.getSpec(), pair.getFirst(), pair.getSecond());
        if (job != null) {
          myAdderRemover.add(job, myCurrent, myProject);
          return true;
        }
      }
    }
    return false;
  }

  private void ensureDefaultConnections() {
    if (myCurrent.hasDefaultName()) {
      final JobDetailsLoader loader = new JobDetailsLoader(myProject);
      loader.fillConnections(myCurrent, myConnMap);
    }
  }

  public JComponent getComponent() {
    return myPanel;
  }

  public void refresh() {

  }

  public void saveState() {
    if (myCurrent != null && myCurrent.hasDefaultName()) {
      keepDefaultListJobs();
    }
  }

  public void restoreState() {
    
  }

  public void onChangeListSelected(final LocalChangeList list) {
    if (! Comparing.equal(list, myCurrent)) {
      if (list != null && (! list.hasDefaultName()) && (myCurrent != null) && (myCurrent.hasDefaultName())) {
        keepDefaultListJobs();
      }
      myCurrent = list;

      if (myCurrent == null) {
        setItems(Collections.<PerforceJob>emptyList());
      } else if (myCurrent.hasDefaultName()) {
        correctDefaultAssociated(list);
        final Map<ConnectionKey, List<PerforceJob>> data = myVcs.getDefaultAssociated();

        final List<PerforceJob> filtered = new ArrayList<PerforceJob>();
        for (Map.Entry<ConnectionKey, List<PerforceJob>> entry : data.entrySet()) {
          filtered.addAll(entry.getValue());
        }

        setItems(filtered);
      } else {
        Map<ConnectionKey, java.util.List<PerforceJob>> data = myCache.get(myCurrent);
        if (data == null) {
          data = loadOnSelect(myCurrent);
          myCache.put(list, data);
        }
        setItems(flattenList(data.values()));
      }
    }
  }

  private void correctDefaultAssociated(final LocalChangeList defaultList) {
    final Map<ConnectionKey, List<PerforceJob>> data = myVcs.getDefaultAssociated();

    final ConnectionSelector connectionSelector = new ConnectionSelector(myProject, defaultList);
    final Map<ConnectionKey,P4Connection> map = connectionSelector.getConnections();

    final Map<ConnectionKey, List<PerforceJob>> filtered = new HashMap<ConnectionKey, List<PerforceJob>>();
    for (Map.Entry<ConnectionKey, List<PerforceJob>> entry : data.entrySet()) {
      if (map.containsKey(entry.getKey())) {
        filtered.put(entry.getKey(), entry.getValue());
      }
    }

    myVcs.setDefaultAssociated(filtered);
  }

  private void keepDefaultListJobs() {
    final List<PerforceJob> perforceJobs = myDetails.getJobs();
    final Map<ConnectionKey, List<PerforceJob>> jobs = new HashMap<ConnectionKey, List<PerforceJob>>();
    for (PerforceJob job : perforceJobs) {
      List<PerforceJob> oldList = jobs.get(job.getConnectionKey());
      if (oldList == null) {
        oldList = new ArrayList<PerforceJob>();
        jobs.put(job.getConnectionKey(), oldList);
      }
      oldList.add(job);
    }
    myVcs.setDefaultAssociated(jobs);
  }

  private List<PerforceJob> flattenList(final Collection<List<PerforceJob>> collList) {
    final List<PerforceJob> result = new ArrayList<PerforceJob>();
    for (List<PerforceJob> jobList : collList) {
      result.addAll(jobList);
    }
    return result;
  }

  private Map<ConnectionKey, java.util.List<PerforceJob>> loadOnSelect(final LocalChangeList list) {
    final JobDetailsLoader loader = new JobDetailsLoader(myProject);
    final Map<ConnectionKey, java.util.List<PerforceJob>> perforceJobs = new HashMap<ConnectionKey, java.util.List<PerforceJob>>();
    loader.loadJobsForList(list, myConnMap, perforceJobs);
    return perforceJobs;
  }

  private void setItems(final List<PerforceJob> items) {
    myDetails.fillTree(items, items.isEmpty() ? null : items.get(0));
  }

  public Object getDataForCommit() {
    final Map<ConnectionKey, java.util.List<PerforceJob>> data = myCurrent.hasDefaultName() ? myVcs.getDefaultAssociated() : myCache.get(myCurrent);
    return data == null ? null : flattenList(data.values());
  }
}
