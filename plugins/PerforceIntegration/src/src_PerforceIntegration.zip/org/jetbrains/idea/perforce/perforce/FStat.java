/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.perforce;

import com.intellij.openapi.vcs.VcsException;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.idea.perforce.changesBrowser.FileChange;


public final class FStat
{
    public int status = STATUS_UNKNOWN;
    public int local = LOCAL_NOT_LOCAL;

    // status values
    public static final int STATUS_UNKNOWN = 0;
    public static final int STATUS_NOT_IN_CLIENTSPEC = 1;
    public static final int STATUS_NOT_ADDED = 2;
    public static final int STATUS_ONLY_ON_SERVER = 3;
    public static final int STATUS_ON_SERVER_AND_LOCAL = 4;
    public static final int STATUS_ONLY_LOCAL = 5;
    public static final int STATUS_DELETED = 6;

  // local status
  public static final int LOCAL_NOT_LOCAL = 0;
    public static final int LOCAL_CHECKED_IN = 1;
    public static final int LOCAL_CHECKED_OUT = 2;
    public static final int LOCAL_ADDING = 3;
    public static final int LOCAL_BRANCHING = 4;
    public static final int LOCAL_DELETING = 5;
    public static final int LOCAL_INTEGRATING = 6;


  public long statTime = System.currentTimeMillis();
  @NonNls public String clientFile = "";
  @NonNls public String depotFile = "";
  @NonNls public String headAction = "";
  @NonNls public String headChange = "";
  @NonNls public String headRev = "";
  @NonNls public String headType = "";
  @NonNls public String headTime = "";
  @NonNls public String haveRev = "";
  @NonNls public String action = "";
  @NonNls public String actionOwner = "";
  @NonNls public String change = "";
  @NonNls public String unresolved = null;
  public P4File fromFile = null;

  @NonNls public final String toString()
  {
      return "org.jetbrains.idea.perforce.perforce.FStat{" +
             "status=" + status +
             ", local=" + local +
             ", statTime=" + statTime +
             ", \nclientFile='" + clientFile + "'" +
             ", \ndepotFile='" + depotFile + "'" +
             ", \nheadAction='" + headAction + "'" +
             ", headChange='" + headChange + "'" +
             ", headRev='" + headRev + "'" +
             ", headType='" + headType + "'" +
             ", headTime='" + headTime + "'" +
             ", haveRev='" + haveRev + "'" +
             ", \naction='" + action + "'" +
             ", actionOwner='" + actionOwner + "'" +
             ", change='" + change + "'" +
             ", unresolved='" + unresolved + "'" +
             ", branchedFrom='" + fromFile + "'" +
             "}";
  }


    public void resolveStatus() throws VcsException {
      //
      // resolve the status and local
      //
      if (headRev.length() > 0 && haveRev.length() == 0) {
        local = FStat.LOCAL_NOT_LOCAL;
        if (headAction.equals(FileChange.DELETE_ACTION)) {
          status = FStat.STATUS_DELETED;
        }
        else {
          status = FStat.STATUS_ONLY_ON_SERVER;
        }
      }
      else {
        if (headRev.length() == 0) {
          status = FStat.STATUS_ONLY_LOCAL;
        }
        else {
          status = FStat.STATUS_ON_SERVER_AND_LOCAL;
        }
      }

      if (action.length() == 0) {
        local = FStat.LOCAL_CHECKED_IN;
      }
      else if (action.equals(FileChange.ADD_ACTION)) {
        local = FStat.LOCAL_ADDING;
      }
      else if (action.equals(FileChange.EDIT_ACTION)) {
        local = FStat.LOCAL_CHECKED_OUT;
      }
      else if (action.equals(FileChange.BRANCH_ACTION)) {
        local = FStat.LOCAL_BRANCHING;
      }
      else if (action.equals(FileChange.INTEGRATE_ACTION)) {
        local = FStat.LOCAL_INTEGRATING;
      }
      else if (action.equals(FileChange.DELETE_ACTION)) {
        local = FStat.LOCAL_DELETING;
      }
      else {
        throw new VcsException(org.jetbrains.idea.perforce.PerforceBundle.message("exception.text.unknown.action", action));
      }
    }
}
