package org.jetbrains.idea.perforce.application;

public class ConnectionKey {
  public String server;
  public String client;
  public String user;

  public ConnectionKey(PerforceClient client) {
    this(client.getServerPort(), client.getName(), client.getUserName());
  }

  public ConnectionKey(final String server, final String client, final String user) {
    this.server = server;
    this.client = client;
    this.user = user;
  }

  public boolean equals(final Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    final ConnectionKey that = (ConnectionKey)o;

    if (!client.equals(that.client)) return false;
    if (!server.equals(that.server)) return false;
    if (!user.equals(that.user)) return false;

    return true;
  }

  public int hashCode() {
    int result;
    result = server.hashCode();
    result = 31 * result + client.hashCode();
    result = 31 * result + user.hashCode();
    return result;
  }

  @Override
  public String toString() {
    return server + ", " + user + "@" + client;
  }
}
