/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.VcsShowConfirmationOption;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.peer.PeerFactory;
import com.intellij.util.ui.ConfirmationDialog;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.actions.MessageManager;
import org.jetbrains.idea.perforce.perforce.FStat;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

import java.util.ArrayList;
import java.util.List;

public class DeleteHandler extends BaseAddDeleteHandler{

  class DeletedFileInfo {
    public P4Connection myConnection;
    public FilePath myFilePath;

    public DeletedFileInfo(VirtualFile file) {
      myConnection = PerforceConnectionManager.getInstance(myProject).getConnectionForFile(file);
      myFilePath = PeerFactory.getInstance().getVcsContextFactory().createFilePathOn(file);
    }
  }

  private final List<DeletedFileInfo> myDeletedFiles = new ArrayList<DeletedFileInfo>();
  private final List<DeletedFileInfo> myDeletedWithoutConfirmFiles = new ArrayList<DeletedFileInfo>();


  public DeleteHandler(Project project) {
    super(project);
  }

  private void deleteFile(DeletedFileInfo file) throws VcsException {
    final P4File p4File = P4File.createInefficientFromLocalPath(file.myFilePath.getPath());
    PerforceSettings settings = PerforceSettings.getSettings(myProject);
    PerfCommands.assureDel(p4File, settings, true, file.myConnection);
    VcsDirtyScopeManager.getInstance(myProject).fileDirty(file.myFilePath);
  }

  public void execute() throws VcsException {
    if (myDeletedFiles.isEmpty() && myDeletedWithoutConfirmFiles.isEmpty()) return;
    delete(myDeletedWithoutConfirmFiles);
    if (PerforceVcs.getInstance(myProject).getRemoveOption().getValue() == VcsShowConfirmationOption.Value.DO_NOTHING_SILENTLY) return;
    if (PerforceVcs.getInstance(myProject).getRemoveOption().getValue() == VcsShowConfirmationOption.Value.DO_ACTION_SILENTLY
        || myDeletedFiles.isEmpty()) {
      delete(myDeletedFiles);
    }
    else {
      if (!requestForConfirmation(composeMesasge())) {
        return;
      }
      delete(myDeletedFiles);
    }
  }

  private boolean requestForConfirmation(final String message) {
    final boolean[] result = new boolean[1];
    Runnable runnable = new Runnable() {
      public void run() {
        result[0] = ConfirmationDialog.requestForConfirmation(PerforceVcs.getInstance(myProject).getRemoveOption(),
                                                              myProject,
                                                              message,
                                                              PerforceBundle.message("confirmation.title.remove.files"),
                                                              Messages.getQuestionIcon());
      }
    };
    MessageManager.runShowAction(runnable);
    return result[0];
  }

  private String composeMesasge() {
    final StringBuffer files =
      new StringBuffer();
    for (DeletedFileInfo file : myDeletedFiles) {
      files.append("\n");
      files.append(file.myFilePath.getPath());
    }
    return PerforceBundle.message("confirmation.text.remove.files", files.toString());
  }

  private void delete(final List<DeletedFileInfo> files) throws VcsException {
    for (final DeletedFileInfo path : files) {
      deleteFile(path);
    }
  }

  protected void processFile(VirtualFile file) {
    final P4File p4File = P4File.create(file);

    PerforceSettings settings = PerforceSettings.getSettings(myProject);
    final P4Connection connection = PerforceConnectionManager.getInstance(myProject).getConnectionForFile(file);
    try {
      final FStat fstat = p4File.getFstat(settings, connection, true);

      if (fstat.status == FStat.STATUS_NOT_ADDED ||
          fstat.status == FStat.STATUS_NOT_IN_CLIENTSPEC ||
          fstat.status == FStat.STATUS_UNKNOWN ||
          fstat.local == FStat.LOCAL_NOT_LOCAL) {
        return;
      }

      if (fstat.status == FStat.STATUS_ONLY_LOCAL) {
        myDeletedWithoutConfirmFiles.add(new DeletedFileInfo(file));
        return;
      }
    }
    catch (VcsException e) {
      //ignore
    }



    myDeletedFiles.add(new DeletedFileInfo(file));
  }
}
