/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.options.Configurable;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.update.FileGroup;
import com.intellij.openapi.vcs.update.UpdatedFiles;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.idea.perforce.perforce.ExecResult;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class PerforceUpdateEnvironment extends AbstractUpdateEnvironment{
  @NonNls private static final String DELETED_MESSAGE = " - deleted as ";
  @NonNls private static final String UPDATING_MESSAGE = " - updating ";
  @NonNls private static final String ADDED_MESSAGE = " - added as ";

  private final static Map<String, String> ourPatternToGroupId = new HashMap<String,  String>();

  static {
    ourPatternToGroupId.put(DELETED_MESSAGE, FileGroup.REMOVED_FROM_REPOSITORY_ID);
    ourPatternToGroupId.put(UPDATING_MESSAGE, FileGroup.UPDATED_ID);
    ourPatternToGroupId.put(ADDED_MESSAGE, FileGroup.CREATED_ID);
  }

  public PerforceUpdateEnvironment(Project project) {
    super(project);
  }

  public void fillGroups(UpdatedFiles updatedFiles) {

  }

  protected boolean isTryToResolveAutomatically(final PerforceSettings settings) {
    return settings.SYNC_RUN_RESOLVE;
  }

  protected Map<String, String> getPatternToGroupId() {
    return ourPatternToGroupId;
  }

  protected boolean isRevertUnchanged(final PerforceSettings settings) {
    return settings.REVERT_UNCHANGED_FILES;
  }

  protected ExecResult performUpdate(final FilePath contentRoot, final P4File p4Dir, final PerforceSettings settings) throws VcsException {
    final P4Connection connectionForFile = settings.getConnectionForFile(contentRoot.getVirtualFile());
    return contentRoot.isDirectory() ? PerfCommands.p4syncDir(p4Dir, settings, settings.SYNC_FORCE, connectionForFile) :
           PerfCommands.p4syncFile(p4Dir, settings, settings.SYNC_FORCE, connectionForFile);
  }


  public Configurable createConfigurable(Collection<FilePath> files) {
    return new PerforceUpdateConfigurable(getSettings()){
      protected PerforcePanel createPanel() {
        return new PerforceUpdatePanel();
      }
    };
  }

}
