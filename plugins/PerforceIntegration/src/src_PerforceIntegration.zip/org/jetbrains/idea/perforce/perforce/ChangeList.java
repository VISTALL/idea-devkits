/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.perforce;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.DefaultJDOMExternalizer;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMExternalizable;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.versionBrowser.RepositoryVersion;
import com.intellij.openapi.vcs.versions.AbstractRevisions;
import org.jdom.Element;
import org.jetbrains.idea.perforce.ChangeListData;
import org.jetbrains.idea.perforce.application.PerforceRevisionsFactory;
import org.jetbrains.idea.perforce.changesBrowser.PerforceChangeRevisions;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import java.io.File;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

public class ChangeList implements JDOMExternalizable, RepositoryVersion{

  private final ChangeListData myData;

  private final Project myProject;
  private final P4Connection myConnection;

  public ChangeList(ChangeListData data, final Project project, P4Connection connection) {
    myProject = project;
    myConnection = connection;
    myData = data;
  }

  public void readExternal(Element element) throws InvalidDataException {
    DefaultJDOMExternalizer.readExternal(myData, element);
  }

  public void writeExternal(Element element) throws WriteExternalException {
    DefaultJDOMExternalizer.writeExternal(myData, element);
  }

  public long getNumber() {
    return myData.NUMBER;
  }

  public String getDescription() {
    return myData.DESCRIPTION;
  }

  public String toString() {
    String description = myData.DESCRIPTION;
    if (description.length() > 30) {
      description = myData.DESCRIPTION.substring(0, 25) + "...";
    }
    return "#" + myData.NUMBER + "(" + description + ")";
  }

  public Date getDate() {
    try {
      return ChangeListData.DATE_FORMAT.parse(myData.DATE);
    }
    catch (ParseException e) {
      return null;
    }
  }

  public String getUser() {
    return myData.USER;
  }

  public String getClient() {
    return myData.CLIENT;
  }

  public List<AbstractRevisions> getFileRevisions() throws VcsException {
    final PerforceSettings settings = PerforceSettings.getSettings(myProject);
    final List<PerforceAbstractChange> paths = PerfCommands.p4getChangedFiles(settings, getNumber(), myConnection);
    final PerforceRevisionsFactory perforceRevisionsFactory = new PerforceRevisionsFactory(myProject) {
      protected List<PerforceAbstractChange> getChanges() {
        return paths;
      }

      protected AbstractRevisions createRevisions(File file) {
        return new PerforceChangeRevisions(myFileToTreeElementMap.get(file), this, myProject,
                                           myConnection);
      }
    };
    return perforceRevisionsFactory.createRevisionsListOn(new String[]{"//"});
  }


  public boolean equals(final Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    final ChangeList that = (ChangeList)o;

    if (!myConnection.equals(that.myConnection)) return false;
    if (myData.NUMBER != that.myData.NUMBER) return false;
    if (!myProject.equals(that.myProject)) return false;

    return true;
  }

  public int hashCode() {
    int result;
    result = (int) myData.NUMBER;
    result = 31 * result + myConnection.hashCode();
    return result;
  }
}
