/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.command.CommandAdapter;
import com.intellij.openapi.command.CommandEvent;
import com.intellij.openapi.command.CommandProcessor;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.AbstractVcsHelper;
import com.intellij.openapi.vcs.FileStatusManager;
import com.intellij.openapi.vcs.ProjectLevelVcsManager;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vfs.*;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;

import java.util.ArrayList;

public final class PerforceListeners implements ProjectComponent {

  private AddHandler myAddHandler;
  private DeleteHandler myDeleteHandler;
  private MoveRenameHandler myMoveRenameHandler;
  private final Project myProject;
  private MyVirtualFileAdapter myVFSListener;
  private MyCommandAdapter myCommandListener;

  public PerforceListeners(Project project) {
    myProject = project;
  }

  public void projectOpened() {
    myVFSListener = new MyVirtualFileAdapter();
    myCommandListener = new MyCommandAdapter();

    VirtualFileManager.getInstance().addVirtualFileListener(myVFSListener);
    CommandProcessor.getInstance().addCommandListener(myCommandListener);
  }

  public void projectClosed() {
    VirtualFileManager.getInstance().removeVirtualFileListener(myVFSListener);
    CommandProcessor.getInstance().removeCommandListener(myCommandListener);
  }

  public String getComponentName() {
    return "PerforceDirect.Globals";
  }

  public void initComponent() {
  }

  public void disposeComponent() {
  }

  private class MyVirtualFileAdapter extends VirtualFileAdapter {

    public void beforePropertyChange(final VirtualFilePropertyEvent event) {
      if (isExternalChange(event)) {
        P4File.invalidateFstat(event.getFile());
        FileStatusManager.getInstance(myProject).fileStatusChanged(event.getFile());
        VcsDirtyScopeManager.getInstance(myProject).fileDirty(event.getFile());
      } else {
        if (event.getPropertyName().equalsIgnoreCase(VirtualFile.PROP_NAME)) {
          if (myMoveRenameHandler == null) myMoveRenameHandler = new MoveRenameHandler(myProject);
          final VirtualFile file = event.getFile();
          final VirtualFile parent = file.getParent();
          if (parent != null) {
            myMoveRenameHandler.onFileRenamedOrMoved(file, parent.getPath(), (String)event.getNewValue());
          }
        }
      }
    }

    public void beforeFileMovement(final VirtualFileMoveEvent event) {
      if (isExternalChange(event)) return;
      final VirtualFile file = event.getFile();
      if (myMoveRenameHandler == null) myMoveRenameHandler = new MoveRenameHandler(myProject);
      myMoveRenameHandler.onFileRenamedOrMoved(file, event.getNewParent().getPath(), file.getName());
    }

    public void beforeFileDeletion(final VirtualFileEvent event) {
      if (isExternalChange(event)) return;
      if (myDeleteHandler == null) myDeleteHandler = new DeleteHandler(myProject);
      myDeleteHandler.onFileAdded(event.getFile());
    }

    private boolean isExternalChange(final VirtualFileEvent event) {
      if (event.isFromRefresh()) return true;
      if (ProjectLevelVcsManager.getInstance(myProject).getVcsFor(event.getFile()) != PerforceVcs.getInstance(myProject)) {
        return true;
      }
      if (!PerforceSettings.getSettings(myProject).ENABLED) {
        return true;
      }

      return false;
    }

    public void fileCreated(final VirtualFileEvent event) {
      if (isExternalChange(event)) return;
      if (myAddHandler == null) {
        myAddHandler = new AddHandler(myProject);
      }
      myAddHandler.onFileAdded(event.getFile());
    }
  }

  private class MyCommandAdapter extends CommandAdapter {
    private int myCommandLavel;

    public void commandStarted(CommandEvent event) {
      if (myProject != event.getProject()) return;
      myCommandLavel++;
    }

    public void commandFinished(CommandEvent event) {
      if (myProject != event.getProject()) return;
      myCommandLavel--;
      if (myCommandLavel == 0) {
        if (hasSomeFilesToProcess()) {
          FileDocumentManager.getInstance().saveAllDocuments();
          final ArrayList<VcsException> vcsExceptions = new ArrayList<VcsException>();
          ProgressManager.getInstance().runProcessWithProgressSynchronously(new Runnable() {
            public void run() {
              try {
                executeAdd();
              }
              catch (VcsException e) {
                vcsExceptions.add(e);
              }
              try {
                executeDelete();
              }
              catch (VcsException e) {
                vcsExceptions.add(e);
              }
              try {
                executeMove();
              }
              catch (VcsException e) {
                vcsExceptions.add(e);
              }
            }
          }, PerforceBundle.message("progress.title.running.perforce.commands"), false, myProject);

          if (!vcsExceptions.isEmpty()){
            AbstractVcsHelper.getInstance(myProject).showErrors(vcsExceptions, PerforceBundle.message("message.title.perforce.errors"));
          }
        }
      }
    }

    private boolean hasSomeFilesToProcess() {
      if (myDeleteHandler != null) return true;
      if (myAddHandler != null) return true;
      if (myMoveRenameHandler != null) return true;
      return false;
    }

    private void executeDelete() throws VcsException {
      if (myDeleteHandler != null) {
        try {
          myDeleteHandler.execute();
        }
        finally {
          myDeleteHandler = null;
        }
      }
    }

    private void executeMove() throws VcsException {
      if (myMoveRenameHandler != null) {
        try {
          myMoveRenameHandler.execute();
        }
        finally {
          myMoveRenameHandler = null;
        }
      }
    }

    private void executeAdd() throws VcsException {
      if (myAddHandler != null) {
        try {
          myAddHandler.execute();
        }
        finally {
          myAddHandler = null;
        }
      }
    }
  }

}
