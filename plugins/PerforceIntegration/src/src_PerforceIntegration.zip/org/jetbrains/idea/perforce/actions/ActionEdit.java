/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.actions;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.idea.perforce.CancelActionException;
import static org.jetbrains.idea.perforce.PerforceBundle.message;
import org.jetbrains.idea.perforce.application.ActionWithTempFile;
import org.jetbrains.idea.perforce.perforce.FStat;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

import java.io.File;

public final class ActionEdit
  extends ActionBaseFile {
  @SuppressWarnings({"unchecked"})
  protected void performAction(final VirtualFile vFile,
                               final PerforceSettings settings,
                               final Project project,
                               final boolean topLevel,
                               final boolean alone, final ActionBaseFile.TemporarySettings tempSettings) throws CancelActionException, VcsException {
    final P4File p4File = P4File.create(vFile);

    final P4Connection connection = PerforceConnectionManager.getInstance(project).getConnectionForFile(vFile);

    log("Action edit on file: " + p4File.getLocalPath());

    boolean[] stats = (boolean[])ApplicationManager.getApplication().runReadAction(new Computable() {
      public Object compute() {
        boolean[] result = new boolean[2];
        result[0] = vFile.isDirectory();
        result[1] = vFile.isWritable();
        return result;
      }
    });
    boolean isDirectory = stats[0];
    boolean isWritable = stats[1];

    if (isDirectory) {
      final VirtualFile[] children = (VirtualFile[])ApplicationManager.getApplication().runReadAction(new Computable() {
        public Object compute() {
          return vFile.getChildren();
        }
      });
      for (final VirtualFile child : children) {
        performAction(child, settings, project, false, alone && (children.length == 1), tempSettings);
      }
      if (topLevel) {
        if (!checkFilename(p4File, project)) {
          return;
        }

        PerfCommands.p4editDir(p4File, settings, connection);
      }
    }
    else {

      if (!checkFilename(p4File, project)) {
        return;
      }

      // check whether it will be under any clientspec
      final FStat p4FStat = p4File.getFstat(settings, connection, true);
      if (p4FStat.status == FStat.STATUS_NOT_IN_CLIENTSPEC ||
          p4FStat.status == FStat.STATUS_UNKNOWN) {
        if (isWritable) {
          return;
        }
        if (alone) {
          final String msg = message("error.message.file.not.under.any.clientspec", p4File.getLocalPath());
          MessageManager.showMessageDialog(project, msg, message("message.title.cannot.edit"), Messages.getErrorIcon());
        }
        else {
          final String msg =
            message("confirmation.text.file.not.under.any.clientspec.continue.checkout", p4File.getLocalPath());

          final int answer = MessageManager.showDialog(project,
                                                       msg,
                                                       message("message.title.cannot.edit"),
                                                       YES_NO_OPTIONS,
                                                       1,
                                                       Messages.getErrorIcon());
          if (answer != 0) {
            throw new CancelActionException();
          }
        }
      }
      else {
        if (p4FStat.status == FStat.STATUS_NOT_ADDED ||
            p4FStat.status == FStat.STATUS_ONLY_LOCAL) {
          if (alone) {
            MessageManager.showMessageDialog(project,
                                             message("message.text.file.not.on.server", p4File.getLocalPath()),
                                             message("message.title.cannot.edit"),
                                             Messages.getErrorIcon());
          }
        }
        else if (p4FStat.status == FStat.STATUS_DELETED) {
          if (alone) {
            MessageManager.showMessageDialog(project,
                                             message("message.text.file.deleted.from.server",
                                                                                  p4File.getLocalPath()),
                                             message("message.title.cannot.edit"),
                                             Messages.getErrorIcon());
          }
        }
        else if (p4FStat.status == FStat.STATUS_ONLY_ON_SERVER) {
          final String msg =
              message("confirmation.text.file.registered.as.only.on.server.replace.it", p4File.getLocalPath(), p4FStat.depotFile);

          final int answer = MessageManager.showDialog(project,
                                                       msg,
                                                       message("confirmation.title.file.already.in.perforce"),
                                                       YES_NO_CANCELREST_OPTIONS,
                                                       1,
                                                       Messages.getErrorIcon());
          if (answer == 1) {
            //return
          }
          else if (answer == 2 || answer == -1) {
            throw new CancelActionException();
          }
          else {
            final String localPath = p4File.getLocalPath();
            final File file = new File(localPath);
            new ActionWithTempFile(file){
              protected void executeInternal() throws VcsException {
                PerfCommands.p4revertFile(p4File, settings, false, connection);
                PerfCommands.p4syncFile(p4File, settings, false, connection);
                PerfCommands.p4editFile(p4File, settings, connection);
              }
            }.execute();

          }
        }
        else if (p4FStat.local == FStat.LOCAL_DELETING) {
          final String msg =
              message("confirmation.text.file.marked.for.deletion.revert.and.replace", p4File.getLocalPath(), p4FStat.depotFile);

          final int answer = MessageManager.showDialog(project,
                                                       msg,
                                                       message("confirmation.title.file.already.in.perforce"),
                                                       YES_NO_CANCELREST_OPTIONS,
                                                       1,
                                                       Messages.getErrorIcon());
          if (answer == 1) {
            //return;
          }
          else if (answer == 2 || answer == -1) {
            throw new CancelActionException();
          }
          else {
            final String localPath = p4File.getLocalPath();
            final File file = new File(localPath);
            new ActionWithTempFile(file){
              protected void executeInternal() throws VcsException {
                PerfCommands.p4revertFile(p4File, settings, false, connection);
                PerfCommands.p4editFile(p4File, settings, connection);
              }
            }.execute();
          }

        }
        else if (p4FStat.local != FStat.LOCAL_CHECKED_IN && p4FStat.local != FStat.LOCAL_INTEGRATING) {
          if (alone) {
            final String msg =
              message("message.text.file.already.being.checked.out.or.added", p4File.getLocalPath());
            MessageManager.showMessageDialog(project, msg, message("message.title.no.reason.to.edit"), Messages.getInformationIcon());
          }
        }
        else {
          PerfCommands.p4editFile(p4File, settings, connection);
        }
      }
    }
  }

  protected boolean actionChangesFiles() {
    return true;
  }

}
