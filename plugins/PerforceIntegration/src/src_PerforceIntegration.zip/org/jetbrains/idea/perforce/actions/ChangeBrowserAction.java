/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.actions;

import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.SelectFromListDialog;
import com.intellij.openapi.vcs.AbstractVcsHelper;
import com.intellij.openapi.vcs.actions.VcsContext;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.peer.PeerFactory;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.application.PerforceManager;
import org.jetbrains.idea.perforce.changesBrowser.PerforceVersionsProvider;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import javax.swing.*;
import java.util.List;

public class ChangeBrowserAction extends AsyncUpdateAction<VcsContext> {

  protected VcsContext prepareDataFromContext(final AnActionEvent e) {
    return PeerFactory.getInstance().getVcsContextFactory().createCachedContextOn(e);
  }

  protected void performUpdate(final Presentation presentation, final VcsContext context) {
    final Project project = context.getProject();
    if (project == null || !PerforceSettings.getSettings(project).ENABLED) {
      presentation.setEnabled(false);
    } else {
      presentation.setEnabled(true);
    }
  }

  public void actionPerformed(AnActionEvent e) {
    final DataContext dataContext = e.getDataContext();
    final Project project = (Project)dataContext.getData(DataConstants.PROJECT);
    VirtualFile selectedFile = (VirtualFile)dataContext.getData(DataConstants.VIRTUAL_FILE);

    if (project != null) {
      final AbstractVcsHelper helper = AbstractVcsHelper.getInstance(project);
      if (selectedFile == null || !selectedFile.isDirectory()) {
        final PerforceSettings settings = PerforceSettings.getSettings(project);
        final List<P4Connection> allConnections = settings.getAllConnections();
        if (allConnections.isEmpty()) {
          //do nothing
        } else if (allConnections.size() == 1) {
          helper.showChangesBrowser(new PerforceVersionsProvider(project, allConnections.get(0)));
        } else {
          P4Connection connection = chooseConnection(allConnections, project);
          if (connection != null) {
            helper.showChangesBrowser(new PerforceVersionsProvider(project, connection));
          }

        }
      } else {
        helper.showChangesBrowser(new PerforceVersionsProvider(project, selectedFile),
                                  PerforceBundle.message(
                                    "changes.browser.changes.affecting.files.from.directory",
                                    selectedFile.getPresentableUrl()));
      }
    }
  }

  private static P4Connection chooseConnection(final List<P4Connection> allConnections, Project project) {
    final PerforceManager perforceManager = PerforceManager.getInstance(project);
    final SelectFromListDialog fromListDialog =
      new SelectFromListDialog(project, allConnections.toArray(new P4Connection[allConnections.size()]),
                               new SelectFromListDialog.ToStringAspect() {
                                 public String getToStirng(Object obj) {
                                   final P4Connection connection = (P4Connection)obj;
                                   final String name = perforceManager.getClient(connection).getName();
                                   final String host = perforceManager.getClient(connection).getServerPort();
                                   if (name != null && host != null) {
                                     return name + "@" + host;
                                   } else {
                                     return PerforceBundle.message("unknown.client.presentation");
                                   }

                                 }
                               }, PerforceBundle.message("select.perforce.client.dialog.title"), ListSelectionModel.SINGLE_SELECTION);
    fromListDialog.show();
    if (fromListDialog.isOK()) {
      return (P4Connection)fromListDialog.getSelection()[0];
    } else {
      return null;
    }
  }
}
