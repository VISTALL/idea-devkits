/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.actions;

import com.intellij.CommonBundle;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.AsyncUpdateAction;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.AbstractVcsHelper;
import com.intellij.openapi.vcs.FileStatusManager;
import com.intellij.openapi.vcs.ProjectLevelVcsManager;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.actions.VcsContext;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VirtualFileManager;
import com.intellij.peer.PeerFactory;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.idea.perforce.CancelActionException;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.application.PerforceVcs;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;

public abstract class ActionBaseFile extends AsyncUpdateAction<VcsContext> {

  public static class TemporarySettings {
    public boolean DO_FOR_ALL = false;
    private final int myFileCount;

    public TemporarySettings(final int fileCount) {
      myFileCount = fileCount;
    }

    public int getFileCount() {
      return myFileCount;
    }
  }

  private static final Logger LOG = Logger.getInstance("#org.jetbrains.idea.perforce.actions.ActionBaseFile");

  protected final static String[] YES_NO_OPTIONS = {CommonBundle.getYesButtonText(), CommonBundle.getNoButtonText()};
  protected final static String[] YES_NO_CANCELREST_OPTIONS = {CommonBundle.getYesButtonText(), CommonBundle.getNoButtonText(),
    PerforceBundle.message("button.text.cancel.rest")};
  protected final static String[] OK_CANCELREST_OPTIONS = {CommonBundle.getOkButtonText(),
    PerforceBundle.message("button.text.cancel.rest")};


  protected static void log(@NonNls final String msg) {
    LOG.debug(msg);
  }

  protected VcsContext prepareDataFromContext(final AnActionEvent e) {
    return PeerFactory.getInstance().getVcsContextFactory().createCachedContextOn(e);
  }


  protected void performUpdate(final Presentation presentation, final VcsContext context) {
    final Project project = context.getProject();
    if (project == null) {
      presentation.setVisible(false);
      return;
    }

    final PerforceSettings settings = PerforceSettings.getSettings(project);
    if (!settings.ENABLED) {
      presentation.setVisible(true);
      presentation.setEnabled(false);
      return;
    }

    presentation.setVisible(true);
    presentation.setEnabled(isEnabled(context));
  }

  protected boolean isEnabled(final VcsContext context) {
    return true;
  }

  protected abstract void performAction(final VirtualFile vFile,
                                        final PerforceSettings settings,
                                        Project project,
                                        boolean topLevel,
                                        final boolean alone, final ActionBaseFile.TemporarySettings tempSettings) throws CancelActionException, VcsException;

  public void actionPerformed(final AnActionEvent event) {
    final Project project = (Project)event.getDataContext().getData(DataConstants.PROJECT);
    final PerforceSettings settings = PerforceSettings.getSettings(project);

    if (actionChangesFiles()) {
      ApplicationManager.getApplication().runWriteAction(new Runnable() {
        public void run() {
          FileDocumentManager.getInstance().saveAllDocuments();
        }
      });
    }

    final VirtualFile[] vFiles = (VirtualFile[])event.getDataContext().getData(DataConstants.VIRTUAL_FILE_ARRAY);

    if (!ProjectLevelVcsManager.getInstance(project).checkAllFilesAreUnder(PerforceVcs.getInstance(project), vFiles)) {
      return;
    }

    boolean containsDirectory = false;
    if (vFiles != null && vFiles.length > 0) {
      try {
        final TemporarySettings tempSettings = new TemporarySettings(vFiles.length);
        for (final VirtualFile vFile : vFiles) {
          final boolean[] cancelled = new boolean[1];
          cancelled[0] = false;
          try {
            try {
              performAction(vFile, settings, project, true, (vFiles.length == 1), tempSettings);
              if (vFile.isDirectory()) {
                containsDirectory = true;
              }
            }
            catch (VcsException e) {
              AbstractVcsHelper.getInstance(project).showError(e, PerforceBundle.message("dialog.title.perforce"));
            }
          }
          catch (CancelActionException e) {
            cancelled[0] = true;
          }
          if (cancelled[0]) {
            break;
          }
        }
      }
      finally {
        if (containsDirectory) {
          VirtualFileManager.getInstance().refresh(true, new Runnable() {
            public void run() {
              P4File.invalidateFstat(project);
              FileStatusManager.getInstance(project).fileStatusesChanged();
            }
          });
        }
        else {
          for (final VirtualFile vFile : vFiles) {
            ApplicationManager.getApplication().runWriteAction(new Runnable() {
              public void run() {
                vFile.refresh(false, false);
              }
            });
            P4File.invalidateFstat(vFile);
            FileStatusManager.getInstance(project).fileStatusChanged(vFile);
            VcsDirtyScopeManager.getInstance(project).fileDirty(vFile);
          }
        }
      }
    }
  }


  abstract protected boolean actionChangesFiles();

  protected static boolean checkFilename(final P4File p4File, final Project project) throws VcsException {
    final String complaint = PerfCommands.getFileNameComplaint(p4File);
    if (complaint != null) {
      log(complaint);
      MessageManager.showMessageDialog(project,
                                       PerforceBundle.message("message.text.filename.non.acceptable", complaint),
                                       PerforceBundle.message("message.title.filename.non.acceptable"),
                                       Messages.getWarningIcon());
      return false;
    }
    return true;
  }

}
