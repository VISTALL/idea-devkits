/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.perforce.connections;

import org.jetbrains.idea.perforce.perforce.*;
import org.jetbrains.idea.perforce.CancelActionException;
import org.jetbrains.idea.perforce.StreamGobbler;
import org.jetbrains.annotations.NonNls;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.util.EnvironmentUtil;

import java.io.IOException;
import java.io.OutputStream;
import java.io.File;

class P4CommandLineConnection {

  private static final Logger LOG = Logger.getInstance("#org.jetbrains.idea.perforce.perforce.connections.P4CommandLineConnection");

  private P4CommandLineConnection() {
  }

  public static void runP4Command(PerforceSettings settings,
                                  String[] p4args,
                                  ExecResult retVal,
                                  final StringBuffer inputStream,
                                  final File cwd)
    throws VcsException, PerforceTimeoutException, IOException, InterruptedException {
    executeP4CommandLine(settings, p4args, retVal, inputStream, cwd);
  }

  static private ExecResult executeP4CommandLine(final PerforceSettings settings,
                                                              @NonNls final String[] p4args,
                                                              ExecResult retVal,
                                                              StringBuffer inputData, final File cwd) {
    try {
      runCmdLine(settings, p4args, retVal, inputData, cwd);
    }
    catch (CancelActionException e) {
      throw e;
    }
    catch (Exception e) {
      retVal.setException(e);
    }

    return retVal;
  }

  private static void runCmdLine(final PerforceSettings settings,
                                 @NonNls final String[] p4args,
                                 final ExecResult retVal,
                                 StringBuffer inputData,
                                 File cwd)
    throws IOException,
           InterruptedException, PerforceTimeoutException {
    final String[] connArgs = settings.getConnectArgs();
    final String[] cmd = new String[1 + connArgs.length + p4args.length];
    int c = 0;
    cmd[c++] = settings.getPathToExec();
    for (String connArg : connArgs) {
      cmd[c++] = connArg;
    }
    for (String p4arg : p4args) {
      cmd[c++] = p4arg;
    }
    final StringBuffer cmdLabel = new StringBuffer();
    for (String aCmd : cmd) {
      cmdLabel.append(" ");
      cmdLabel.append(aCmd);
    }

    if (LOG.isDebugEnabled()) {
      LOG.debug("[Perf Execute:] " + cmdLabel.toString() + "[cwd] " + cwd);
    }

    final Runtime rt = Runtime.getRuntime();
    final Process proc = rt.exec(cmd, EnvironmentUtil.getEnvironment(), cwd);
    if (inputData != null) {
      OutputStream outputStream = proc.getOutputStream();
      try {
        byte[] bytes = inputData.toString().getBytes();
        outputStream.write(bytes);
      }
      finally {
        outputStream.close();
      }
    }
    final StreamGobbler errorGobbler = new
      StreamGobbler(proc.getErrorStream());
    final StreamGobbler outputGobbler = new
      StreamGobbler(proc.getInputStream());
    errorGobbler.start();
    outputGobbler.start();

    final IOException[] ioEx = new IOException[1];
    final InterruptedException[] intEx = new InterruptedException[1];

    final PerfExecutionThread perfExecutionThread = new PerfExecutionThread(settings, settings.SERVER_TIMEOUT) {
      protected void runProcess() {
        try {
          retVal.setExitCode(proc.waitFor());
        }
        catch (InterruptedException ex) {
          retVal.setException(ex);
        }
      }

      protected void destroyProcess() {
        try {
          errorGobbler.join();
          outputGobbler.join();

          proc.getErrorStream().close();
          proc.getInputStream().close();
        }
        catch (InterruptedException e) {
          intEx[0] = e;
        }
        catch (IOException e) {
          ioEx[0] = e;
        }
        proc.destroy();
      }
    };
    errorGobbler.setExecutionThread(perfExecutionThread);
    outputGobbler.setExecutionThread(perfExecutionThread);
    perfExecutionThread.run();


    if (!perfExecutionThread.finished()) {
      throw new PerforceTimeoutException();
    }

    if (ioEx[0] != null) throw ioEx[0];
    if (intEx[0] != null) throw intEx[0];

    retVal.setOutputGobbler(outputGobbler);
    retVal.setErrorGobbler(errorGobbler);
  }

}
