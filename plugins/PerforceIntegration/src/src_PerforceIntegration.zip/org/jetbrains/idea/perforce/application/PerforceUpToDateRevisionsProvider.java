/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.localVcs.LvcsRevision;
import com.intellij.openapi.vcs.UpToDateRevisionProvider;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.idea.perforce.perforce.FStat;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import java.io.UnsupportedEncodingException;

public class PerforceUpToDateRevisionsProvider implements UpToDateRevisionProvider{
  private final PerforceVcs myVcs;

  public PerforceUpToDateRevisionsProvider(final PerforceVcs vcs) {
    myVcs = vcs;
  }

  public String getLastUpToDateContentFor(VirtualFile vFile, boolean quietly) {

    final P4File p4File = P4File.create(vFile);
    try {
      final PerforceSettings settings = PerforceSettings.getSettings(myVcs.getProject());
      final P4Connection connection = settings.getConnectionForFile(vFile);
      if (!settings.ENABLED) return null;
      final FStat fstat = p4File.getFstat(settings, connection, false);
      if (fstat.status == FStat.STATUS_UNKNOWN || fstat.status == FStat.STATUS_NOT_IN_CLIENTSPEC) {
        return null;
      }
      try {
        final byte[] bytes = PerfCommands.p4getByteContent(p4File.getAnyPath(), fstat.haveRev, settings, connection);
        return bytes != null ? new String(bytes, vFile.getCharset().name()) : null;
      }
      catch (UnsupportedEncodingException e) {
        throw new VcsException(e);
      }
    }
    catch (VcsException e) {
      return null;
    }

  }

  public boolean itemCanBePurged(LvcsRevision lvcsObject) {
    return true;
  }
}
