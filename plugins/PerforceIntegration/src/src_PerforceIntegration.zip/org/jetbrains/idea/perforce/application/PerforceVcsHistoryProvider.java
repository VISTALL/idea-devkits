/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.ToggleAction;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.history.*;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.ui.ColumnInfo;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.actions.ShowAllSubmittedFilesAction;
import org.jetbrains.idea.perforce.perforce.*;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class PerforceVcsHistoryProvider implements VcsHistoryProvider {
  private final PerforceVcs myVcs;
  private static final ColumnInfo<VcsFileRevision, String> REVISION = new ColumnInfo<VcsFileRevision, String>(
    PerforceBundle.message("file.history.revision.column.name")) {
    public String valueOf(VcsFileRevision vcsFileRevision) {
      if (!(vcsFileRevision instanceof PerforceFileRevision)) return "";
      return String.valueOf(((PerforceFileRevision) vcsFileRevision).getVersionNumber());
    }

    public Comparator<VcsFileRevision> getComparator() {
      return new Comparator<VcsFileRevision>() {
        public int compare(VcsFileRevision r1, VcsFileRevision r2) {
          if (!(r1 instanceof PerforceFileRevision)) return 1;
          if (!(r2 instanceof PerforceFileRevision)) return -1;
          return (int)(((PerforceFileRevision) r1).getVersionNumber() - ((PerforceFileRevision) r2).getVersionNumber());
        }
      };
    }
  };

  private static final ColumnInfo<VcsFileRevision, String> ACTION = new ColumnInfo<VcsFileRevision, String>(
    PerforceBundle.message("file.history.action.column.name")) {
    public String valueOf(VcsFileRevision vcsFileRevision) {
      if (!(vcsFileRevision instanceof PerforceFileRevision)) return "";
      return ((PerforceFileRevision) vcsFileRevision).getAction();
    }
  };

  private static final ColumnInfo<VcsFileRevision, String> CLIENT = new ColumnInfo<VcsFileRevision, String>(
    PerforceBundle.message("file.history.client.column.name")) {
    public String valueOf(VcsFileRevision vcsFileRevision) {
      if (!(vcsFileRevision instanceof PerforceFileRevision)) return "";
      return ((PerforceFileRevision) vcsFileRevision).getClient();
    }
  };


  public PerforceVcsHistoryProvider(PerforceVcs vcs) {
    myVcs = vcs;
  }

  public ColumnInfo[] getRevisionColumns() {
    return new ColumnInfo[]{
      REVISION, ACTION, CLIENT
    };


  }

  public AnAction[] getAdditionalActions(final FileHistoryPanel panel) {
    return new AnAction[]{new ShowBranchesAction(panel), new ShowAllSubmittedFilesAction()};
  }

  public String getHelpId() {
    return null;
  }

  public VcsHistorySession createSessionFor(FilePath filePath) throws VcsException {
    final VirtualFile virtualFile = filePath.getVirtualFile();
    final P4File p4File = P4File.create(filePath);
    p4File.invalidateFstat();
    final P4Connection connection = myVcs.getSettings().getConnectionForFile(virtualFile);
    P4Revision[] p4Revisions = PerfCommands.p4getRevisions(p4File, myVcs.getSettings(), connection);
    List<VcsFileRevision> revisions = new ArrayList<VcsFileRevision>();
    for (P4Revision p4Revision : p4Revisions) {

      revisions.add(new PerforceFileRevision(p4Revision,
                                             myVcs.getSettings(),
                                             virtualFile.getFileType().isBinary(),
                                             connection));
    }

    return new VcsHistorySession(revisions) {
      @Nullable
      public VcsRevisionNumber calcCurrentRevisionNumber() {
        try {
          final FStat fstat = p4File.getFstat(myVcs.getSettings(), connection, false);
          return new PerforceVcsRevisionNumber(Long.parseLong(fstat.haveRev),Long.parseLong(fstat.headChange), false);
        }
        catch (VcsException e) {
          return null;
        }
        catch (NumberFormatException e) {
          return null;
        }
      }

      @Override
      public boolean isCurrentRevision(VcsRevisionNumber rev) {
        if (!(rev instanceof PerforceVcsRevisionNumber)) return false;
        PerforceVcsRevisionNumber p4rev = (PerforceVcsRevisionNumber) rev;
        PerforceVcsRevisionNumber currentRev = (PerforceVcsRevisionNumber) getCurrentRevisionNumber();
        return currentRev != null && p4rev.getRevisionNumber() == currentRev.getRevisionNumber() && !p4rev.isBranched();
      }
    };
  }

  public HistoryAsTreeProvider getTreeHistoryProvider() {
    return null;
  }

  class ShowBranchesAction extends ToggleAction {
    private final FileHistoryPanel myPanel;

    public ShowBranchesAction(final FileHistoryPanel panel) {
      super(PerforceBundle.message("action.name.show.branches"), null, IconLoader.getIcon("/icons/showBranches.png"));
      myPanel = panel;
    }

    public boolean isSelected(AnActionEvent e) {
      return PerforceSettings.getSettings(myVcs.getProject()).SHOW_BRANCHES_HISTORY;
    }

    public void setSelected(AnActionEvent e, boolean state) {
      PerforceSettings.getSettings(myVcs.getProject()).SHOW_BRANCHES_HISTORY= state;
      if (myPanel != null) {
        myPanel.refresh();
      }
    }
  }
}
