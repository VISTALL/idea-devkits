/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.perforce;

import com.intellij.openapi.actionSystem.ActionManager;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.*;
import com.intellij.openapi.vfs.VirtualFile;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.ServerVersion;
import org.jetbrains.idea.perforce.application.ChangeListSynchronizer;
import org.jetbrains.idea.perforce.application.PerforceManager;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

import java.io.File;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public final class PerforceSettings implements ProjectComponent, JDOMExternalizable, PerforceIntegrationState {

  private Map<P4Connection, ParticularConnectionSettings> myConnectionSettings = new HashMap<P4Connection, ParticularConnectionSettings>();

  public static final String CHARSET_NONE = PerforceBundle.message("none.charset.presentation");

  public boolean useP4CONFIG = true;
  @NonNls public String port = "<perforce_server>:1666";
  public String client = "";
  public String user = "";
  public String passwd = "";
  public boolean showCmds = false;
  public boolean useNativeApi = SystemInfo.isWindows;

  public String pathToExec = s_p4cmd;
  public boolean useCustomPathToExec = false;

  private final Project myProject;


  @NonNls private static String s_p4cmd = "p4";
  private static final String[] EMPTY_CONFIG_ARGS = new String[0];
  public boolean SYNC_FORCE = false;
  public boolean SYNC_RUN_RESOLVE = true;
  public boolean REVERT_UNCHANGED_FILES = true;
  public String CHARSET = CHARSET_NONE;
  public boolean SHOW_BRANCHES_HISTORY = true;
  public boolean ENABLED = true;
  public boolean USE_LOGIN = false;
  public boolean LOGIN_SILENTLY = false;
  public boolean INTEGRATE_RUN_RESOLVE = true;
  public boolean INTEGRATE_REVERT_UNCHANGED = true;
  public int SERVER_TIMEOUT = 20000;

  @NonNls private static final String CURRENT_CHANGE_LIST_ELEMENT = "CURRENT_CHANGE_LIST";
  @NonNls private static final String ID_ELEMENT = "ID";
  @NonNls private static final String CONNECTION_SETTINGS = "CHANGE_LIST";

  private final List<PerforceActivityListener> myActivityListeners = new CopyOnWriteArrayList<PerforceActivityListener>();

  //
  // public PerforceSettings methods
  //


  public PerforceSettings(Project project) {
    myProject = project;
  }

  public boolean showCmds() {
    return showCmds;
  }

  public static PerforceSettings getSettings(final Project project) {
    return project.getComponent(PerforceSettings.class);
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  public String[] getConnectArgs() {
    if (useP4CONFIG) {
      return EMPTY_CONFIG_ARGS;
    }
    else {
      final ArrayList<String> args = new ArrayList<String>();
      if (port != null && port.length() > 0) {
        args.add("-p");
        args.add(port);
      }
      if (client != null && client.length() > 0) {
        args.add("-c");
        args.add(client);
      }
      if (user != null && user.length() > 0) {
        args.add("-u");
        args.add(user);
      }
      if (!USE_LOGIN) {
        final String pass = getPasswd();
        if (pass != null && pass.length() > 0) {
          args.add("-P");
          args.add(pass);
        }
      }

      if (!isNoneCharset()) {
        args.add("-C");
        args.add(CHARSET);
      }

      return args.toArray(new String[args.size()]);
    }
  }

  //
  // ProjectComponent methods
  //

  public void projectOpened() {
  }

  public void projectClosed() {
  }

  @NotNull
  public String getComponentName() {
    return "PerforceDirect.Settings";
  }

  public void initComponent() {
    // disable Dummy actions
    final ActionManager actionManager = ActionManager.getInstance();
    final AnAction actionRename = actionManager.getAction("PerforceDirect.Rename");
    if (actionRename != null) {
      actionRename.getTemplatePresentation().setEnabled(false);
    }
    final AnAction actionMove = actionManager.getAction("PerforceDirect.Move");
    if (actionMove != null) {
      actionMove.getTemplatePresentation().setEnabled(false);
    }
    final AnAction actionDelete = actionManager.getAction("PerforceDirect.Delete");
    if (actionDelete != null) {
      actionDelete.getTemplatePresentation().setEnabled(false);
    }
  }

  public void disposeComponent() {
  }

  //
  // JDOMExternalizable methods
  //

  public void readExternal(final Element element) throws InvalidDataException {
    DefaultJDOMExternalizer.readExternal(this, element);
    final List currentChangeListElements = element.getChildren(CURRENT_CHANGE_LIST_ELEMENT);
    for (Object cclObj : currentChangeListElements) {
      if (cclObj instanceof Element) {
        final Element currentCLElement = ((Element)cclObj);
        final Element idChild = currentCLElement.getChild(ID_ELEMENT);
        final Element connectionSettingsElement = currentCLElement.getChild(CONNECTION_SETTINGS);

        if (idChild != null && connectionSettingsElement != null) {
          final ConnectionId id = new ConnectionId();
          DefaultJDOMExternalizer.readExternal(id, idChild);
          P4Connection connection = findConnectionByClientId(id);
          if (connection != null) {
            ParticularConnectionSettings settings = new ParticularConnectionSettings(getProject(), connection);
            DefaultJDOMExternalizer.readExternal(settings, connectionSettingsElement);
            myConnectionSettings.put(connection, settings);
          }
        }
      }
    }

  }

  public void writeExternal(final Element element) throws WriteExternalException {
    DefaultJDOMExternalizer.writeExternal(this, element);
    for (P4Connection connection : myConnectionSettings.keySet()) {
      ConnectionId id = connection.getId();
      final Element currentChangeListElement = new Element(CURRENT_CHANGE_LIST_ELEMENT);
      element.addContent(currentChangeListElement);
      final Element clientIdElement = new Element(ID_ELEMENT);
      currentChangeListElement.addContent(clientIdElement);
      DefaultJDOMExternalizer.writeExternal(id, clientIdElement);

      final Element clientChangeListElement = new Element(CONNECTION_SETTINGS);
      currentChangeListElement.addContent(clientChangeListElement);
      DefaultJDOMExternalizer.writeExternal(myConnectionSettings.get(connection), clientChangeListElement);
    }
  }

  public boolean useNativeApi() {
    return useNativeApi;
  }

  public String getPathToExec() {
    return pathToExec;
  }

  public Project getProject() {
    return myProject;
  }

  @Nullable
  public String getPasswd() {
    if (passwd == null) {
      return null;
    }
    else if (passwd.length() == 0) {
      return passwd;
    }
    else {
      try {
        return PasswordUtil.decodePassword(passwd);
      }
      catch (Exception e) {
        return "";
      }
    }
  }

  public void setPasswd(final String passwd) {
    this.passwd = PasswordUtil.encodePassword(passwd);
  }

  public long getServerVersion(final P4Connection connection) {
    return PerforceManager.getInstance(myProject).getServerVertionYear(connection);
  }

  @Nullable
  public ServerVersion getServerFullVersion(final P4Connection connection) {
    return PerforceManager.getInstance(myProject).getServerVersion(connection);
  }

  public void disable() {
    ENABLED = false;
    PerforceManager.getInstance(myProject).configurationChanged();
  }

  public void enable() {
    ENABLED = true;
    PerforceManager.getInstance(myProject).configurationChanged();
  }

  public boolean canBeChanged() {
    return true;
  }

  @Nullable
  private P4Connection findConnectionByClientId(final ConnectionId id) {
    return PerforceConnectionManager.getInstance(myProject).findConnectionById(id, this);
  }

  public Map<P4Connection, List<File>> chooseConnectionForFile(final Collection<File> files) {
    final HashMap<P4Connection, List<File>> result = new LinkedHashMap<P4Connection, List<File>>();
    final PerforceConnectionManager connectionManager = PerforceConnectionManager.getInstance(getProject());
    for (File file : files) {
      final P4Connection connection = connectionManager.getConnectionForFile(file);
      if (!result.containsKey(connection)) {
        result.put(connection, new ArrayList<File>());
      }
      result.get(connection).add(file);
    }
    return result;
  }

  public P4Connection getConnectionForFile(final File file) {
    return PerforceConnectionManager.getInstance(getProject()).getConnectionForFile(file);
  }

  public P4Connection getConnectionForFile(final VirtualFile file) {
    return PerforceConnectionManager.getInstance(getProject()).getConnectionForFile(file);
  }

  public List<P4Connection> getAllConnections() {
    return PerforceConnectionManager.getInstance(getProject()).getAllConnections(this);
  }

  public long getCurrentChangeListNumber(final P4Connection connection) {
    return ChangeListSynchronizer.getInstance(myProject).getActiveChangeListNumber(connection);
  }


  // TODO: remove this method and all perforce changelist activity as well.
  public static Map<P4Connection, ChangeList> getCurrentChangeLists() {
    return Collections.emptyMap();
  }

  public ParticularConnectionSettings getSettings(final P4Connection connection) {
    if (!myConnectionSettings.containsKey(connection)) {
      myConnectionSettings.put(connection, new ParticularConnectionSettings(getProject(), connection));
    }
    return myConnectionSettings.get(connection);
  }

  public void addActivityListener(PerforceActivityListener listener) {
    myActivityListeners.add(listener);
  }

  public void removeActivityListener(PerforceActivityListener listener) {
    myActivityListeners.remove(listener);
  }

  void notifyChangeListSubmitted(P4Connection connection, long changeListNumber, final long newNumber) {
    for(PerforceActivityListener listener: myActivityListeners) {
      listener.changeListSubmitted(connection, changeListNumber, newNumber);
    }
  }

  public boolean isNoneCharset() {
    return CHARSET == null || CHARSET_NONE.equals(CHARSET);
  }
}
