/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.actions;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.vcs.AbstractVcsHelper;
import com.intellij.openapi.vcs.VcsDataConstants;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.history.VcsFileRevision;
import com.intellij.openapi.vcs.versions.AbstractRevisions;
import org.jetbrains.idea.perforce.ChangeListData;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.application.PerforceFileRevision;
import org.jetbrains.idea.perforce.application.PerforceVcsRevisionNumber;
import org.jetbrains.idea.perforce.perforce.ChangeList;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import java.util.ArrayList;
import java.util.List;

public class ShowAllSubmittedFilesAction extends AnAction {
  public ShowAllSubmittedFilesAction() {
    super(PerforceBundle.message("action.text.show.all.submitted"), null, IconLoader.getIcon("/icons/allRevisions.png"));
  }

  public void update(AnActionEvent e) {
    super.update(e);
    final Project project = (Project)e.getDataContext().getData(DataConstants.PROJECT);
    if (project == null) {
      e.getPresentation().setEnabled(false);
      return;
    }
    e.getPresentation().setEnabled(e.getDataContext().getData(VcsDataConstants.VCS_FILE_REVISION) != null);
  }

  public void actionPerformed(AnActionEvent e) {
    final Project project = (Project)e.getDataContext().getData(DataConstants.PROJECT);
    if (project == null) return;
    final VcsFileRevision revision = (VcsFileRevision)e.getDataContext().getData(VcsDataConstants.VCS_FILE_REVISION);
    if (revision != null) {
      final PerforceFileRevision perfRevision = ((PerforceFileRevision)revision);

      showAllSubmittedFiles(project, ((PerforceVcsRevisionNumber)perfRevision.getRevisionNumber()).getChangeNumber(),
                            perfRevision.getCommitMessage(), perfRevision.getConnection());

    }
  }

  public static void showAllSubmittedFiles(final Project project,
                                           final long number,
                                           final String submitMessage,
                                           final P4Connection connection) {
    final ChangeListData data = new ChangeListData();
    final ChangeList changeList = new ChangeList(data, project, connection);

    data.NUMBER = number;

    final List<AbstractRevisions> revisions = new ArrayList<AbstractRevisions>();

    final VcsException[] ex = new VcsException[1];

    final boolean processCompleted = ProgressManager.getInstance().runProcessWithProgressSynchronously(new Runnable() {
      public void run() {
        try {
          revisions.addAll(changeList.getFileRevisions());
        }
        catch (VcsException e) {
          ex[0] = e;
        }
      }
    }, PerforceBundle.message("show.all.files.from.change.list.searching.for.changed.files.progress.title"), true, project);


    if (processCompleted) {
      if (ex[0] == null) {
        if (calcFiles(revisions) > 300) {
          Messages.showInfoMessage(PerforceBundle.message("show.all.files.from.change.list.too.many.files.affected.error.message"),
                                   getTitle(changeList));
        }
        else {
          AbstractVcsHelper.getInstance(project).showRevisions(revisions, getTitle(changeList), submitMessage, PerforceBundle.message(
            "show.all.files.from.change.list.submit.message.title"));
        }

      }
      else {
        Messages
          .showErrorDialog(PerforceBundle.message("message.text.cannot.show.revisions", ex[0].getLocalizedMessage()), getTitle(changeList));
      }
    }

  }

  private static int calcFiles(final List<AbstractRevisions> revisions) {
    int result = 0;
    for (AbstractRevisions abstractRevisions : revisions) {
      result += calcFiles(abstractRevisions.getDirectories());
      result += abstractRevisions.getFiles().size();
    }
    return result;
  }

  private static String getTitle(final ChangeList changeList) {
    return PerforceBundle.message("dialog.title.show.all.revisions.in.changelist", new Long(changeList.getNumber()));
  }
}
