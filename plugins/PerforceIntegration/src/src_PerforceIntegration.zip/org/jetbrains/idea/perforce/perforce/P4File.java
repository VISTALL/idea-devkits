/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.perforce;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.ProjectLevelVcsManager;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.changes.ChangeListManager;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.Processor;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.application.PerforceManager;
import org.jetbrains.idea.perforce.application.PerforceVcs;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import java.io.File;

public final class P4File {

  //
  // constructor data
  //
  private VirtualFile m_vFile = null;
  private VirtualFile m_parentDirOfDeleted = null;
  private String m_name = null;

  //
  // cached values
  //
  private FStat m_fstat = null;
  private String m_localPath = null;

  @NonNls private static final String VF_CACHE = "P4_VF_CACHE";
  public static final Key<P4File> KEY = new Key<P4File>(VF_CACHE);
  @NonNls private static final String FILE_SEPARATOR_PROPERTY = "file.separator";

  public static P4File createInefficientFromLocalPath(final String localPath) {
    final P4File p4File = new P4File();
    p4File.m_localPath = localPath;
    return p4File;
  }

  public static P4File create(@NotNull final VirtualFile vFile) {
    final Object userData = vFile.getUserData(KEY);
    final P4File p4File;
    if (userData != null) {
      p4File = (P4File)userData;
    }
    else {
      p4File = new P4File();
      p4File.m_vFile = vFile;
      p4File.m_vFile.putUserData(KEY, p4File);
    }
    p4File.m_parentDirOfDeleted = null;
    return p4File;
  }

  public static P4File create(final FilePath filePath) {
    VirtualFile virtualFile = filePath.getVirtualFile();
    if (virtualFile != null) {
      return create(virtualFile);
    }
    else {
      P4File result = P4File.createInefficientFromLocalPath(filePath.getPath());
      result.m_parentDirOfDeleted = filePath.getVirtualFileParent();
      result.m_name = filePath.getName();
      return result;
    }
  }

  public static P4File create(final File file) {
    VirtualFile virtualFile = findVirtualFile(file);
    if (virtualFile != null) {
      return create(virtualFile);
    }
    else {
      P4File result = P4File.createInefficientFromLocalPath(file.getAbsolutePath());
      result.m_parentDirOfDeleted = findVirtualFile(file.getParentFile());
      result.m_name = file.getName();
      return result;
    }
  }

  private static VirtualFile findVirtualFile(final File file) {
    return ApplicationManager.getApplication().runReadAction(new Computable<VirtualFile>() {
      @Nullable
      public VirtualFile compute() {
        return LocalFileSystem.getInstance().findFileByIoFile(file);
      }
    });
  }

  private P4File() {
  }

  public String getAnyPath() throws VcsException {
    final String localPath = getLocalPath();
    if (localPath != null) {
      return localPath;
    }
    else {
      throw new VcsException(PerforceBundle.message("exception.text.p4file.doesnt.have.peth.info"));
    }
  }

  public String getEscapedPath() throws VcsException {
    String path = getAnyPath();
    path = path.replace("%", "%25");
    path = path.replace("@", "%40");
    path = path.replace("#", "%23");
    return path;
  }

  public void invalidateFstat() {
    m_fstat = null;

    if (m_vFile != null && m_vFile.isValid()) {
      invalidateFstat(m_vFile);
    }
  }

  public static void invalidateFstat(final Project project) {
    ApplicationManager.getApplication().runReadAction(new Runnable() {
      public void run() {
        final PerforceVcs perforceVcs = PerforceVcs.getInstance(project);
        final Module[] modules = ProjectLevelVcsManager.getInstance(project).getAllModulesUnder(perforceVcs);
        for (Module p4ControlledModule : modules) {
          final VirtualFile[] contentRoots = ModuleRootManager.getInstance(p4ControlledModule).getContentRoots();
          for (VirtualFile contentRoot : contentRoots) {
            invalidateFstat(contentRoot);
          }
        }
      }
    });
  }

  public static void invalidateFstat(final VirtualFile file) {
    ApplicationManager.getApplication().runReadAction(new Runnable() {
      public void run() {
        invalidateFStatImpl(file);
      }
    });
  }

  private static void invalidateFStatImpl(final VirtualFile m_vFile) {
    LocalFileSystem.getInstance().processCachedFilesInSubtree(m_vFile, new Processor<VirtualFile>() {
      public boolean process(final VirtualFile file) {
        file.putUserData(KEY, null);
        return true;
      }
    });
  }

  public void clearCache() {
    m_fstat = null;
    if (m_vFile != null) {
      m_localPath = null;
    }
  }

  public void setFStat(FStat stat) {
    m_fstat = stat;
  }

  public FStat getFstat(final PerforceSettings settings, final P4Connection connection, final boolean forceNew) throws VcsException {
    if (m_fstat == null || forceNew ||
        m_fstat.statTime < PerforceManager.getInstance(settings.getProject()).getLastValidTime()
        || PerforceManager.getInstance(settings.getProject()).getLastValidTime() == -1) {
      if (m_vFile != null && ChangeListManager.getInstance(settings.getProject()).isUnversioned(m_vFile) && !forceNew) {
        m_fstat = new FStat();
        m_fstat.status = FStat.STATUS_NOT_ADDED;
      }
      else {
        m_fstat = PerfCommands.p4fstat(this, settings, connection);
      }
    }
    return m_fstat;
  }

  public String getLocalPath() throws VcsException {
    final VcsException[] ex = new VcsException[1];
    if (m_localPath == null) {
      ApplicationManager.getApplication().runReadAction(new Runnable() {
        public void run() {
          try {
            if (m_vFile != null) {
              if (m_vFile.getParent() != null) {
                m_localPath = m_vFile.getPath();
              }
              else {
                if (m_parentDirOfDeleted != null) {
                  m_localPath = m_parentDirOfDeleted.getPath() + System.getProperty(FILE_SEPARATOR_PROPERTY) + m_name;
                }
                else {
                  throw new VcsException(PerforceBundle.message("exception.text.cannot.figure.out.local.path"));
                }
              }
            }
            else {
              // implement for any new file spec
              throw new RuntimeException(PerforceBundle.message("exception.text.not.implemented"));
            }
          }
          catch (VcsException e) {
            ex[0] = e;
          }
        }
      });
    }
    if (ex[0] != null) throw ex[0];
    return m_localPath;
  }

  @NonNls
  public String toString() {
    try {
      return "org.jetbrains.idea.perforce.perforce.P4File{" +
             "'" + getLocalPath() + "'" +
             "}";
    }
    catch (VcsException e) {
      return e.getLocalizedMessage();
    }
  }

  @Nullable
  public FStat getCachedStatus(final PerforceManager perforceManager) {
    if (m_fstat != null && perforceManager.statusIsValid(m_fstat.statTime)) {
      return m_fstat;
    }
    else {
      return null;
    }
  }
}
