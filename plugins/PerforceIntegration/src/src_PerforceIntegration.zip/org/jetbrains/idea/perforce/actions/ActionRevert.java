/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.actions;

import com.intellij.CommonBundle;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.actions.VcsContext;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.idea.perforce.CancelActionException;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.perforce.FStat;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

import java.io.File;

public final class ActionRevert
        extends ActionBaseFile {
  protected boolean isEnabled(final VcsContext context) {
    final VirtualFile[] vFiles = context.getSelectedFiles();
    if (vFiles == null || vFiles.length == 0) return false;

    for (VirtualFile vFile : vFiles) {
      if (vFile.isDirectory()) {
        return false;
      }
    }
    return true;
  }

  protected void performAction(
    final VirtualFile vFile,
    final PerforceSettings settings,
    final Project project,
    final boolean topLevel,
    final boolean alone, final ActionBaseFile.TemporarySettings tempSettings) throws CancelActionException, VcsException {
    ApplicationManager.getApplication().saveAll();

    final P4Connection connection = PerforceConnectionManager.getInstance(project).getConnectionForFile(vFile);
    if (vFile.isDirectory()) {
      final String msg = PerforceBundle.message("message.text.directory.revert.not.supported", vFile.getPath());
      MessageManager.showMessageDialog(project, msg, PerforceBundle.message("message.title.cannot.revert.directory"), Messages.getWarningIcon());
    } else {
      final P4File p4File = P4File.create(vFile);

      if (!checkFilename(p4File, project)) {
        return;
      }

      final FStat p4FStat = p4File.getFstat(settings, connection, false);
      if (p4FStat.status == FStat.STATUS_NOT_IN_CLIENTSPEC ||
          p4FStat.status == FStat.STATUS_UNKNOWN) {
        if (alone) {
          final String msg = PerforceBundle.message("error.message.file.not.under.any.clientspec", vFile.getPath());
          MessageManager.showMessageDialog(project, msg, PerforceBundle.message("message.title.cannot.revert"), Messages.getErrorIcon());
          return;
        } else {
          final String msg =
            PerforceBundle.message("confirmation.text.file.not.under.clientspec.continue.revert", vFile.getPath());

          final int answer = MessageManager.showDialog(
                  project,
                  msg,
                  PerforceBundle.message("message.title.cannot.revert"),
                  YES_NO_OPTIONS,
                  1,
                  Messages.getErrorIcon());
          if (answer == 0) {
            return;
          } else {
            throw new CancelActionException();
          }
        }
      } else if (p4FStat.local == FStat.LOCAL_NOT_LOCAL ||
                 p4FStat.local == FStat.LOCAL_CHECKED_IN) {
        final String msg = PerforceBundle
          .message("message.text.perforce.is.not.aware.of.any.local.version.of.file", vFile.getPath());
        MessageManager.showMessageDialog(project, msg, PerforceBundle.message("message.title.cannot.revert"), Messages.getErrorIcon());
        return;
      } else if (p4FStat.local == FStat.LOCAL_BRANCHING) {
        final String msg = PerforceBundle.message("message.text.file.moved.or.renamed.cannot.revert", vFile.getPath());
        MessageManager.showMessageDialog(project, msg, PerforceBundle.message("message.title.cannot.revert"), Messages.getErrorIcon());
        return;
      } else if (p4FStat.local == FStat.LOCAL_DELETING) {
        final String msg = PerforceBundle
          .message("confirmation.text.file.marked.for.deletion.revert", p4File.getLocalPath());

        final int answer = MessageManager.showDialog(
                project,
                msg,
                PerforceBundle.message("confirmation.text.revert.deleted.file"),
                YES_NO_CANCELREST_OPTIONS,
                1,
                Messages.getErrorIcon());
        if (answer == 1) {
          return;
        } else if (answer == 2 || answer == -1) {
          throw new CancelActionException();
        } else {
          PerfCommands.p4revertFile(p4File, settings, false, connection);
          PerfCommands.p4syncFile(p4File, settings, false, connection);
          return;
        }
      }

      final int ok = askUser(tempSettings, project, p4File);
      if (ok == 1) {
        if (tempSettings.getFileCount() == 1) { //canceled
          throw new CancelActionException();
        }
        tempSettings.DO_FOR_ALL = true;
      }
      if (ok == 0 || ok == 1) {
        PerfCommands.p4revertFile(p4File, settings, false, connection);

        if (p4FStat.local == FStat.LOCAL_ADDING) {
          final String msg = PerforceBundle.message("message.text.added.file.has.been.reverted", vFile.getPath());
          MessageManager.showMessageDialog(project, msg, PerforceBundle.message("message.title.after.revert.note"), Messages.getInformationIcon());
          return;
        }

      }

      if (ok == 3) {
        throw new CancelActionException();
      }

    }
  }

  private static int askUser(final TemporarySettings tempSettings, final Project project, final P4File p4File) throws VcsException {
    String displayPath = p4File.getAnyPath().replace('/', File.separatorChar);
    final String title = PerforceBundle.message("confirmation.title.confirm.revert");
    if (tempSettings.getFileCount() == 1) {
      return MessageManager.showOkCancelDialog(
              project,
              PerforceBundle.message("confirmation.text.revert.one.file", displayPath),
              title,
              Messages.getQuestionIcon());

    } else {
      return !tempSettings.DO_FOR_ALL ? MessageManager.showDialog(
        project,
        PerforceBundle.message("confirmation.text.revert.one.file", displayPath),
        title,
        new String[]{CommonBundle.getYesButtonText(), CommonBundle.getYesForAllButtonText(), CommonBundle.getNoButtonText(),
          CommonBundle.getCancelButtonText()},
        0,
        Messages.getQuestionIcon()) : 0;

    }
  }

  protected boolean actionChangesFiles() {
    return true;
  }

}
