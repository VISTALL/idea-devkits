/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.changesBrowser;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.checkin.changeListBasedCheckin.ChangeListBasedRevisionsFactory;
import com.intellij.openapi.vcs.checkin.changeListBasedCheckin.TreeElement;
import com.intellij.openapi.vcs.versions.AbstractRevisions;
import com.intellij.openapi.vcs.versions.VersionRevisions;
import org.jetbrains.idea.perforce.application.AbstractPerforceRevisions;
import org.jetbrains.idea.perforce.perforce.Change;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceAbstractChange;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

public class PerforceChangeRevisions extends AbstractPerforceRevisions implements VersionRevisions {
  private final Project myProject;
  private final P4Connection myConnection;

  public PerforceChangeRevisions(TreeElement treeElement,
                                 ChangeListBasedRevisionsFactory<PerforceAbstractChange> perforceRevisionsFactory,
                                 Project project,
                                 P4Connection connection) {
    super(treeElement, perforceRevisionsFactory);
    myProject = project;
    myConnection = connection;
  }

  protected AbstractRevisions createChild(final TreeElement<PerforceAbstractChange> child) {
    return new PerforceChangeRevisions(child, myRevisionsFactory, myProject, myConnection);
  }

  public String getFirstContent() throws VcsException {
    final FileChange fileChange = ((FileChange)getChange());
    if (fileChange.getType() != Change.EDIT) return null;
    return PerfCommands.p4getContents(fileChange.getDepotPath(), String.valueOf(fileChange.getRevisionBefore()),
                                      PerforceSettings.getSettings(myProject), myConnection);
  }

  public String getSecondContent() throws VcsException {
    final FileChange fileChange = ((FileChange)getChange());
    if (fileChange.getType() != Change.EDIT) return null;
    return PerfCommands.p4getContents(fileChange.getDepotPath(), String.valueOf(fileChange.getRevisionAfter()),
                                      PerforceSettings.getSettings(myProject), myConnection);
  }

  public P4Connection getConnection() {
    return myConnection;
  }
}
