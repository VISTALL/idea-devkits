/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.application.ModalityState;
import com.intellij.openapi.progress.ProcessCanceledException;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.LineTokenizer;
import com.intellij.openapi.vcs.AbstractVcsHelper;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.update.UpdateEnvironment;
import com.intellij.openapi.vcs.update.UpdateSession;
import com.intellij.openapi.vcs.update.UpdateSessionAdapter;
import com.intellij.openapi.vcs.update.UpdatedFiles;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VfsUtil;
import org.jetbrains.idea.perforce.merge.PerforceMergeProvider;
import org.jetbrains.idea.perforce.perforce.ExecResult;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Collections;

abstract class AbstractUpdateEnvironment implements UpdateEnvironment {
  protected final Project myProject;

  public AbstractUpdateEnvironment(final Project project) {
    myProject = project;
  }

  protected static void processOutput(final String output,
                               final UpdatedFiles updatedFiles,
                               final Map<String, String> patternToGroupId,
                               final PerforceClient client) throws VcsException {
    String[] lines = LineTokenizer.tokenize(output.toCharArray(), false);
    for (String line : lines) {
      fillUpdateInformationFromTheLine(line, updatedFiles, patternToGroupId, client);
    }
  }

  private static void fillUpdateInformationFromTheLine(String line,
                                                UpdatedFiles updatedFiles,
                                                Map<String, String> patternToGroupId,
                                                final PerforceClient client) throws VcsException {
    for (String pattern : patternToGroupId.keySet()) {
      if (processLine(line, updatedFiles, pattern, patternToGroupId.get(pattern), client)) {
        return;
      }
    }
  }

  private static boolean processLine(String line, UpdatedFiles updatedFiles,
                              String message, String fileGroupId, final PerforceClient client) throws VcsException {
    int messageStart = line.indexOf(message);
    if (messageStart < 0) return false;
    String depotFilePath = line.substring(0, messageStart).trim();
    final File fileByDepotName = PerforceManager.getFileByDepotName(depotFilePath, client);
    if (fileByDepotName != null) {
      updatedFiles.getGroupById(fileGroupId).add(fileByDepotName.getPath());
    }
    return true;
  }

  protected PerforceSettings getSettings() {
    return PerforceSettings.getSettings(myProject);
  }

  protected static void resolveAutomatically(final PerforceSettings settings, final FilePath contentRoot) throws VcsException {
    final P4Connection connection = settings.getConnectionForFile(contentRoot.getVirtualFile());
    PerfCommands.p4ResolveAutomatically(contentRoot.getVirtualFile(), settings);
    PerfCommands.executeP4Command(settings, new String[]{"resolve", "-af", contentRoot.getPath()}, connection);
  }

  public UpdateSession updateDirectories(FilePath[] contentRoots, UpdatedFiles updatedFiles, ProgressIndicator progressIndicator)
    throws ProcessCanceledException {
    PerforceSettings settings = getSettings();
    final ArrayList<VcsException> vcsExceptions = new ArrayList<VcsException>();


    try {
      for (FilePath contentRoot : contentRoots) {
        final PerforceClient client = PerforceManager.getInstance(myProject).getClient(
          PerforceConnectionManager.getInstance(myProject).getConnectionForFile(contentRoot.getVirtualFile()));

        if (isRevertUnchanged(settings)) {
          try {
            PerfCommands.p4revertUnchangedUnder(contentRoot.getPath(), PerforceSettings.getSettings(myProject));
          }
          catch (VcsException e) {
            vcsExceptions.add(e);
          }
        }

        try {
          final P4File p4Dir = P4File.create(contentRoot);
          final ExecResult execResult = performUpdate(contentRoot, p4Dir, settings);
          processOutput(execResult.getStdout(), updatedFiles, getPatternToGroupId(), client);
          VcsException[] updateExceptions = PerfCommands.checkErrors(execResult);
          if (updateExceptions.length > 0) {
            Collections.addAll(vcsExceptions, updateExceptions);
          }
          else {
            if (isTryToResolveAutomatically(settings)) {
              resolveAutomatically(settings, contentRoot);
            }
          }
        }
        catch (VcsException e) {
          vcsExceptions.add(e);
        }
      }

      try {
        final VirtualFile[] allFilesToResolve = PerfCommands.p4getResolvedWithConflicts(PerforceSettings.getSettings(myProject));
        final List<VirtualFile> filesToResolve = filterByContentRoot(filterByServerVersion(allFilesToResolve), contentRoots);
        if (!filesToResolve.isEmpty()) {
          ApplicationManager.getApplication().invokeAndWait(new Runnable() {
            public void run() {
              AbstractVcsHelper.getInstance(myProject).showMergeDialog(filesToResolve,
                                                                       new PerforceMergeProvider(myProject), null);
            }
          }, ModalityState.defaultModalityState());
        }
      }
      catch (VcsException e) {
         //ignore
      }
    }
    finally {
      PerforceSettings.getSettings(myProject).SYNC_FORCE = false;
    }
    return new UpdateSessionAdapter(vcsExceptions, false);
  }

  private static List<VirtualFile> filterByContentRoot(final List<VirtualFile> filesToResolve, final FilePath[] contentRoots) {
    final ArrayList<VirtualFile> result = new ArrayList<VirtualFile>();
    for(VirtualFile file: filesToResolve) {
      for(FilePath contentRoot: contentRoots) {
        if (VfsUtil.isAncestor(contentRoot.getIOFile(), VfsUtil.virtualToIoFile(file), false)) {
          result.add(file);
          break;
        }
      }
    }
    return result;
  }

  private List<VirtualFile> filterByServerVersion(final VirtualFile[] allFilesToResolve) {
    final PerforceConnectionManager connectionManager = PerforceConnectionManager.getInstance(myProject);
    final ArrayList<VirtualFile> result = new ArrayList<VirtualFile>();
    for (VirtualFile virtualFile : allFilesToResolve) {
      if (PerforceSettings.getSettings(myProject).getServerVersion(connectionManager.getConnectionForFile(virtualFile)) >= 2004) {
        result.add(virtualFile);
      }
    }
    return result;
  }

  protected abstract boolean isTryToResolveAutomatically(PerforceSettings settings);

  protected abstract Map<String, String> getPatternToGroupId();

  protected abstract boolean isRevertUnchanged(PerforceSettings settings);

  protected abstract ExecResult performUpdate(FilePath contentRoot, P4File p4Dir, PerforceSettings settings) throws VcsException;
}
