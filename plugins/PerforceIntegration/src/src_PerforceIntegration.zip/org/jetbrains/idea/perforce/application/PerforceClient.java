package org.jetbrains.idea.perforce.application;

import org.jetbrains.idea.perforce.perforce.View;

import java.util.List;

import com.intellij.openapi.vcs.VcsException;

public interface PerforceClient {
  String getName();

  String getRoot();

  List<View> getViews() throws VcsException;

  String getUserName();

  String getServerPort();
}
