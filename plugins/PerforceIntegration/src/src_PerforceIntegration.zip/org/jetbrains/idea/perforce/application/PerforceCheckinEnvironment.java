/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.CheckinProjectDialogImplementer;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.RollbackProvider;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.checkin.CheckinEnvironment;
import com.intellij.openapi.vcs.checkin.DifferenceType;
import com.intellij.openapi.vcs.checkin.RevisionsFactory;
import com.intellij.openapi.vcs.checkin.VcsOperation;
import com.intellij.openapi.vcs.checkin.changeListBasedCheckin.CommitChangeOperation;
import com.intellij.openapi.vcs.ui.Refreshable;
import com.intellij.openapi.vcs.ui.RefreshableOnComponent;
import com.intellij.openapi.vcs.versions.AbstractRevisions;
import com.intellij.util.ui.ColumnInfo;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.perforce.Change;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceAbstractChange;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PerforceCheckinEnvironment implements CheckinEnvironment{
  private final Project myProject;

  public boolean showCheckinDialogInAnyCase() {
    return true;
  }

  public PerforceCheckinEnvironment(Project project) {
    myProject = project;
  }

  public RevisionsFactory getRevisionsFactory() {
    return new PerforceRevisionsFactory(myProject);
  }

  public RollbackProvider createRollbackProviderOn(AbstractRevisions[] selectedRevisions, final boolean containsExcluded) {
    return new PerforceRollbackProvider(myProject, selectedRevisions);
  }

  public DifferenceType[] getAdditionalDifferenceTypes() {
    return new DifferenceType[0];
  }

  public ColumnInfo[] getAdditionalColumns(int index) {
    return new ColumnInfo[0];
  }

  public RefreshableOnComponent createAdditionalOptionsPanelForCheckinProject(final Refreshable panel) {
    return null;
    /*
    final MultipleChangeListPanel multipleChangeListPanel = new MultipleChangeListPanel(myProject, null);
    final JPanel component = multipleChangeListPanel.getPanel();
    multipleChangeListPanel.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        multipleChangeListPanel.applyToSettings(myProject);
        if (panel instanceof CheckinProjectPanel) {
          String currentDescription = PerforceSettings.getSettings(myProject).composeCurrentChangeListDescription();
          if (currentDescription != null) {
            ((CheckinProjectPanel)panel).setCommitMessage(currentDescription);
          }
        }
        panel.refresh();
      }
    });
    return new RefreshableOnComponent() {
      public JComponent getComponent() {
        return component;
      }

      public void refresh() {
      }

      public void saveState() {
        multipleChangeListPanel.applyToSettings(myProject);
      }

      public void restoreState() {
        multipleChangeListPanel.updateFromSettings(myProject);
      }
    };
    */
  }

  public RefreshableOnComponent createAdditionalOptionsPanelForCheckinFile(Refreshable panel) {
    return null;
  }

  public RefreshableOnComponent createAdditionalOptionsPanel(Refreshable panel, boolean checkinProject) {
    return null;
  }

  public String getDefaultMessageFor(FilePath[] filesToCheckin) {
    return null;
  }

  public void onRefreshFinished() {
  }

  public void onRefreshStarted() {
  }

  public AnAction[] getAdditionalActions(int index) {
    return new AnAction[0];
  }

  public String prepareCheckinMessage(String text) {
    return text;
  }

  public String getHelpId() {
    return null;
  }

  public List<VcsException> commit(CheckinProjectDialogImplementer dialog, Project project) {
    ArrayList<VcsException> vcsExceptions = new ArrayList<VcsException>();
    List<VcsOperation> checkinOperations = dialog.getCheckinProjectPanel().getCheckinOperations(this);
    if (!checkinOperations.isEmpty()) {
      List<PerforceAbstractChange> actualChanges = collectChanges(checkinOperations);
      if (actualChanges.isEmpty()) {
        vcsExceptions.add(new VcsException(PerforceBundle.message("exception.text.nothing.found.to.submit")));
      } else {
        try {
          PerfCommands.p4submit(
            PerforceSettings.getSettings(project),
            dialog.getPreparedComment(this),
            createChangeCollection(actualChanges));
        }
        catch (VcsException e) {
          vcsExceptions.add(e);
        }
      }
    }

    return vcsExceptions;
  }

  private static List<Change> createChangeCollection(final List<PerforceAbstractChange> actualChanges) {
    final ArrayList<Change> result = new ArrayList<Change>();
    for (final PerforceAbstractChange actualChange : actualChanges) {
      result.add((Change)actualChange);
    }
    return result;
  }

  public List<VcsException> commit(FilePath[] paths, Project project, String preparedComment) {
    ArrayList<VcsException> vcsExceptions = new ArrayList<VcsException>();
    try {
      List<Change> changes = PerfCommands.p4AllChanges(PerforceSettings.getSettings(project));

      ArrayList<FilePath> filePathList = new ArrayList<FilePath>();
      Collections.addAll(filePathList, paths);
      List<Change> actualChanges = PerforceChangeProvider.collectChanges(changes, filePathList);
      if (!actualChanges.isEmpty()){
        try {
          PerfCommands.p4submit(
            PerforceSettings.getSettings(project), preparedComment, actualChanges);
        }
        catch (VcsException e) {
          vcsExceptions.add(e);
        }

      } else {
        vcsExceptions.add(new VcsException(PerforceBundle.message("exception.text.nothing.found.to.submit")));
      }
    }
    catch (VcsException e) {
      vcsExceptions.add(e);
    } finally{
      PerforceManager.getInstance(project).clearCache();
    }
    return vcsExceptions;


  }

  private static List<PerforceAbstractChange> collectChanges(List<VcsOperation> checkinOperations) {
    ArrayList<PerforceAbstractChange> result = new ArrayList<PerforceAbstractChange>();
    for (final VcsOperation checkinOperation : checkinOperations) {
      CommitChangeOperation<PerforceAbstractChange> ciOperation = (CommitChangeOperation<PerforceAbstractChange>)checkinOperation;
      result.add(ciOperation.getChange());
    }
    return result;
  }

  public String getCheckinOperationName() {
    return PerforceBundle.message("operation.name.submit");
  }
}
