/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.perforce;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.VcsException;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ChangeListChooser {
  private final JComboBox myChangeList;
  private final Project myProject;
  private static final String DEFAULT = PerforceBundle.message("default.changelist.presentation");
  private List<ActionListener> myActionListeners = new ArrayList<ActionListener>();

  private List<Runnable> myRefreshListeners = new ArrayList<Runnable>();

  private boolean myIsInsideUpdate = false;
  private final P4Connection myConnection;

  public ChangeListChooser(final JComboBox changeLists,
                           final JButton newButton,
                           Project project,
                           final P4Connection connection) {
    myChangeList = changeLists;
    myProject = project;
    myConnection = connection;

    if (newButton != null) {
      newButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          final String description = Messages.showInputDialog(PerforceBundle.message("request.text.enter.change.description"), PerforceBundle.message("request.title.create.new.change.list"), Messages.getQuestionIcon());
          if (description != null) {
            try {
              long newChangeListNumber = PerfCommands.p4createChangeList(PerforceSettings.getSettings(myProject), description, connection,
                                                                         null);
              myIsInsideUpdate = true;
              try {
                refreshChangeLists(newChangeListNumber);
              }
              finally {
                myIsInsideUpdate = false;
                fireChangeListChanged();
              }
            }
            catch (VcsException e1) {
              Messages.showErrorDialog(PerforceBundle.message("message.text.cannot.create.new.changelist", e1.getLocalizedMessage()), PerforceBundle.message("message.title.create.new.chanhelist"));
            }
          }
        }
      });
    }

    myChangeList.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (!myIsInsideUpdate) {
          fireChangeListChanged();
        }
      }
    });
  }

  private void fireChangeListChanged() {
    for (ActionListener actionListener : myActionListeners) {
      actionListener.actionPerformed(null);
    }
  }

  private void refreshChangeLists(long newChangeListNumber) {
    final long selected = newChangeListNumber > 0 ? newChangeListNumber : getChangeListNumber();
    final PerforceSettings settings = PerforceSettings.getSettings(myProject);
    try {
      fillChangeLists(PerfCommands.p4getPendingChangeLists(settings, myConnection), selected);
    }
    catch (VcsException e1) {
      Messages.showErrorDialog(PerforceBundle.message("message.text.cannot.load.changes", e1.getLocalizedMessage()), PerforceBundle.message("message.title.refresh.chnages"));
    }
    finally {
      final Runnable[] listeners = myRefreshListeners.toArray(new Runnable[myRefreshListeners.size()]);
      for (Runnable runnable : listeners) {
        runnable.run();
      }
    }
  }

  public void fillChangeLists(final List<ChangeList> changeLists, long selection) {
    myChangeList.removeAllItems();
    myChangeList.addItem(DEFAULT);
    Object selected = DEFAULT;
    for (ChangeList changeListInfo : changeLists) {
      myChangeList.addItem(changeListInfo);
      if (changeListInfo.getNumber() == selection) {
        selected = changeListInfo;
      }
    }
    myChangeList.setSelectedItem(selected);
  }

  public long getChangeListNumber() {
    final ComboBoxModel model = myChangeList.getModel();
    final Object selectedItem = model.getSelectedItem();
    if (selectedItem instanceof ChangeList) {
      return ((ChangeList)selectedItem).getNumber();
    } else {
      return -1;
    }
  }

  public ChangeList getChangeList() {
    final ComboBoxModel model = myChangeList.getModel();
    final Object selectedItem = model.getSelectedItem();
    if (selectedItem instanceof ChangeList) {
      return (ChangeList)selectedItem;
    } else {
      return null;
    }
  }

  public List<ChangeList> getChangeLists() {
    final ArrayList<ChangeList> result = new ArrayList<ChangeList>();
    final ComboBoxModel model = myChangeList.getModel();
    for (int i = 0; i < model.getSize(); i++) {
      final Object element = model.getElementAt(i);
      if (element instanceof ChangeList) {
        result.add((ChangeList)element);
      }
    }
    return result;
  }

  public void selectChangeList(final long number) {
    Object selected = DEFAULT;
    final ComboBoxModel model = myChangeList.getModel();
    for (int i = 0; i < model.getSize(); i++) {
      final Object element = model.getElementAt(i);
      if (element instanceof ChangeList) {
        if (((ChangeList)element).getNumber() == number){
          myChangeList.setSelectedItem(element);
          return;
        }
      } else {
        if (number == -1) {
          myChangeList.setSelectedItem(selected);
          return;
        }
      }
    }
  }

  public void addRefreshListener(final Runnable runnable) {
    myRefreshListeners.add(runnable);
  }

  public void removeRefreshListener(final Runnable runnable) {
    myRefreshListeners.remove(runnable);
  }

  public void addActionListener(final ActionListener actionListener) {
    myActionListeners.add(actionListener);
  }

  public String getCurrentDescription() {
    final ComboBoxModel model = myChangeList.getModel();
    final Object selectedItem = model.getSelectedItem();
    if (selectedItem instanceof ChangeList) {
      final ChangeList changeList = ((ChangeList)selectedItem);
      if (changeList.getNumber() == -1) return null;
      final String result = changeList.getDescription();
      if (result.trim().length() == 0) return null;
      return result;
    } else {
      return null;
    }

  }
    }
