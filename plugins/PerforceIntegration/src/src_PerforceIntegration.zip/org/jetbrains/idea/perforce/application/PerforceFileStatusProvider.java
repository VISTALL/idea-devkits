/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.FileStatus;
import com.intellij.openapi.vcs.FileStatusProvider;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.idea.perforce.perforce.FStat;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

public class PerforceFileStatusProvider implements FileStatusProvider {
  private final Project myProject;

  public PerforceFileStatusProvider(Project project) {
    myProject = project;
  }

  public FileStatus getStatus(VirtualFile virtualFile) {
    if (!PerforceSettings.getSettings(myProject).ENABLED) return FileStatus.NOT_CHANGED;
    if (PerforceManager.getInstance(myProject).isUnderPerforceRoot(virtualFile)) {
      if (!virtualFile.isDirectory()) {
        final FStat fStat;
        try {
          final P4File p4File = P4File.create(virtualFile);
          fStat = p4File.getFstat(PerforceSettings.getSettings(myProject),
                                  PerforceConnectionManager.getInstance(myProject).getConnectionForFile(virtualFile), false);
        }
        catch (VcsException e) {
          return FileStatus.UNKNOWN;
        }

        return convertToFileStatus(fStat);
      }
      else {
        return FileStatus.NOT_CHANGED;
      }
    }
    else {
      return FileStatus.UNKNOWN;
    }
  }

  /*
  protected Map<VirtualFile, FileStatus> calcStatus(Collection<VirtualFile> virtualFiles) {
    final HashMap<VirtualFile, FileStatus> result = new HashMap<VirtualFile, FileStatus>();
    if (!PerforceSettings.getSettings(myProject).ENABLED) {
      for (final VirtualFile virtualFile : virtualFiles) {
        result.put(virtualFile, FileStatus.NOT_CHANGED);
      }
    }
    else {
      try {
        final ArrayList<VirtualFile> filtered = new ArrayList<VirtualFile>();
        for (VirtualFile virtualFile : virtualFiles) {
          if (PerforceManager.getInstance(myProject).isUnderPerforceRoot(virtualFile)) {
            FStat cached = P4File.create(virtualFile).getCachedStatus(PerforceManager.getInstance(myProject));
            if (cached != null) {
              result.put(virtualFile, convertToFileStatus(cached));
            }
            else if (!virtualFile.isDirectory()) {
              filtered.add(virtualFile);
            }
            else {
              result.put(virtualFile, FileStatus.NOT_CHANGED);
            }
          }
          else {
            result.put(virtualFile, FileStatus.UNKNOWN);
          }
        }
        final Map<VirtualFile, FStat> fileToFStat = PerfCommands.p4fstat(filtered, PerforceSettings.getSettings(myProject));
        for (VirtualFile virtualFile : filtered) {
          if (!fileToFStat.containsKey(virtualFile)) {
            result.put(virtualFile, FileStatus.UNKNOWN);
          }
          else {
            result.put(virtualFile, convertToFileStatus(fileToFStat.get(virtualFile)));
          }
        }
      }
      catch (VcsException e) {
        return result;
      }

    }
    return result;
  }
  */

  private static FileStatus convertToFileStatus(final FStat p4FStat) {
    if (p4FStat.status == FStat.STATUS_NOT_ADDED) return FileStatus.UNKNOWN;

    if (p4FStat.unresolved != null) {
      return FileStatus.MERGE;
    }

    switch (p4FStat.local) {
      case FStat.LOCAL_ADDING:
        return FileStatus.ADDED;
      case FStat.LOCAL_CHECKED_OUT:
        return FileStatus.MODIFIED;
      case FStat.LOCAL_CHECKED_IN:
        if (p4FStat.status == FStat.STATUS_DELETED) {
          return FileStatus.UNKNOWN;
        }
        else {
          return FileStatus.NOT_CHANGED;
        }
      case FStat.LOCAL_DELETING:
        return FileStatus.DELETED;
      default:
        return FileStatus.MODIFIED;
    }

  }

  /*
  public synchronized void clearCache() {
    super.clearCache();
    PerforceManager.getInstance(myProject).clearCache();
  }
  */
}
