/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.perforce;

import com.intellij.openapi.vcs.VcsException;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.idea.perforce.application.PerforceClient;
import org.jetbrains.idea.perforce.application.PerforceManager;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import java.io.File;

public class Change extends PerforceAbstractChange {


  private final String mySourceFilePath;
  private final P4Connection myConnection;
  @Nullable private ChangeList myChangeList;

  @Nullable
  public static Change createOn(String fileString,
                                PerforceClient client,
                                P4Connection connection,
                                @Nullable ChangeList changeList) throws VcsException {
    fileString = fileString.trim();
    String sourceFilePath = fileString;
    int typeIndex = fileString.indexOf("#");

    final File localFile = PerforceManager.getFileByDepotName(fileString.substring(0, typeIndex - 1), client);
    if (localFile != null) {
      String type = fileString.substring(typeIndex + 1).trim();
      return new Change(sourceFilePath, type, localFile, connection, changeList);
    }
    else {
      return null;
    }
  }

  private Change(String sourceFilePath, String type, File localFile, final P4Connection connection, final ChangeList changeList) {
    mySourceFilePath = sourceFilePath;
    myConnection = connection;
    myChangeList = changeList;
    setFile(localFile);
    setType(type);
  }

  public P4Connection getConnection() {
    return myConnection;
  }

  public String getSourceStirng() {
    return mySourceFilePath;
  }

  public int hashCode() {
    return mySourceFilePath.hashCode() ^ myType;
  }

  public boolean equals(Object o) {
    if (!(o instanceof Change)) return false;
    Change another = (Change)o;
    return mySourceFilePath.equals(another.mySourceFilePath) && (myType == another.myType);
  }

  public long getChangeListNum() {
    if (myChangeList == null) return -1;
    return myChangeList.getNumber();
  }

  public String getChangeListDescription() {
    if (myChangeList == null) return "";
    return myChangeList.getDescription();
  }

  @Nullable
  public ChangeList getChangeList() {
    return myChangeList;
  }

  @Override @NonNls
  public String toString() {
    return "perforce.Change[sourceFilePath=" + mySourceFilePath + ", changeList=" + myChangeList + "]";
  }
}
