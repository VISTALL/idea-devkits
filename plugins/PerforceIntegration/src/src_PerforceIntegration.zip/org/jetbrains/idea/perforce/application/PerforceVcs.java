/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.options.Configurable;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.*;
import com.intellij.openapi.vcs.annotate.AnnotationProvider;
import com.intellij.openapi.vcs.changes.ChangeProvider;
import com.intellij.openapi.vcs.changes.ChangeListManager;
import com.intellij.openapi.vcs.checkin.CheckinEnvironment;
import com.intellij.openapi.vcs.diff.DiffProvider;
import com.intellij.openapi.vcs.history.VcsHistoryProvider;
import com.intellij.openapi.vcs.update.UpdateEnvironment;
import com.intellij.openapi.vcs.versionBrowser.VersionsProvider;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.io.ReadOnlyAttributeUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.changesBrowser.PerforceVersionsProvider;
import org.jetbrains.idea.perforce.perforce.*;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

import java.io.IOException;
import java.util.List;

public class PerforceVcs extends AbstractVcs implements ProjectComponent {
  private static final Logger LOG = Logger.getInstance("#org.jetbrains.idea.perforce.application.PerforceVcs");
  private final FileStatusProvider myMyFileStatusProvider;
  private PerforceCheckinEnvironment myPerforceCheckinEnvironment;
  private final PerforceUpdateEnvironment myPerforceUpdateEnvironment;
  private final PerforceIntegrateEnvironment myPerforceIntegrateEnvironment;

  private final MyEditFileProvider myMyEditFileProvider;
  private final EditFileProvider myDisabledEditFileProvider;
  private final EditFileProvider myUnavailableEditFileProvider;
  private final ChangeProvider myChangeProvider;
  private final PerforceConfigurable myPerforceConfigurable;
  private final PerforceVcsHistoryProvider myHistoryProvider;
  private final PerforceUpToDateRevisionsProvider myUpToDateRevisionsProvider;
  private final PerforceAnnotationProvider myAnnotationProvider;
  private final PerforceDiffProvider myDiffProvider;
  private final PerforceSettings mySettings;

  private VcsShowConfirmationOption myAddOption;
  private VcsShowConfirmationOption myRemoveOption;


  public void projectOpened() {
    final ProjectLevelVcsManager vcsManager = ProjectLevelVcsManager.getInstance(getProject());
    myAddOption = vcsManager.getStandardConfirmation(VcsConfiguration.StandardConfirmation.ADD, this);
    myRemoveOption = vcsManager.getStandardConfirmation(VcsConfiguration.StandardConfirmation.REMOVE, this);
  }

  public void projectClosed() {

  }

  @NotNull
  public String getComponentName() {
    return getName();
  }

  public void initComponent() {
    myPerforceCheckinEnvironment = new PerforceCheckinEnvironment(myProject);
  }

  public void disposeComponent() {
  }

  public PerforceVcs(Project project) {
    super(project);
    myMyFileStatusProvider = new PerforceFileStatusProvider(myProject);
    myPerforceUpdateEnvironment = new PerforceUpdateEnvironment(myProject);
    myMyEditFileProvider = new MyEditFileProvider();
    myChangeProvider = new PerforceChangeProvider(this);
    myPerforceConfigurable = new PerforceConfigurable(myProject);
    myHistoryProvider = new PerforceVcsHistoryProvider(this);
    myUpToDateRevisionsProvider = new PerforceUpToDateRevisionsProvider(this);
    myAnnotationProvider = new PerforceAnnotationProvider(myProject);
    myDiffProvider = new PerforceDiffProvider(myProject);
    mySettings = PerforceSettings.getSettings(myProject);

    myDisabledEditFileProvider = new DisabledFileProvider(PerforceBundle.message("perforce.disabled.use.file.system.confirmation"));
    myUnavailableEditFileProvider = new DisabledFileProvider(PerforceBundle.message("perforce.unavailable.use.file.system.confirmation"));

    myPerforceIntegrateEnvironment = new PerforceIntegrateEnvironment(project);
  }

  public String getName() {
    return "Perforce";
  }

  public String getDisplayName() {
    return "Perforce";
  }

  public Configurable getConfigurable() {
    return myPerforceConfigurable;
  }

  private <T> T validProvider(T initialValue, T disabledValue) {
    if (!mySettings.ENABLED) {
      return disabledValue;
    }
    else {
      return initialValue;
    }
  }

  private <T> T validProvider(T initialValue) {
    return validProvider(initialValue, null);
  }


  public void attachModule(final Module module) {
    super.attachModule(module);
    PerforceConnectionManager.getInstance(getProject()).updateConnections();
  }

  public void detachModule(final Module module) {
    super.detachModule(module);
    PerforceConnectionManager.getInstance(getProject()).updateConnections();
  }

  public EditFileProvider getEditFileProvider() {
    if (!mySettings.ENABLED) {
      return myDisabledEditFileProvider;
    }
    else if (cannotConnectToPerforceServer(PerforceManager.getInstance(getProject()))) {
      return myUnavailableEditFileProvider;
    }
    else {
      return myMyEditFileProvider;
    }
  }

  public boolean supportsMarkSourcesAsCurrent() {
    return false;
  }

  public CheckinEnvironment getCheckinEnvironment() {
    return validProvider(myPerforceCheckinEnvironment);
  }

  public FileStatusProvider getFileStatusProvider() {
    return validProvider(myMyFileStatusProvider);
  }

  private void autoEditVFile(final VirtualFile[] vFiles) throws VcsException {
    final PerforceSettings settings = PerforceSettings.getSettings(myProject);
    final Project project = settings.getProject();

    for(VirtualFile vFile: vFiles) {
      final P4File p4File = P4File.create(vFile);

      final String complaint = PerfCommands.getFileNameComplaint(p4File);
      if (complaint != null) {
        LOG.info(complaint);
        return;
      }
    }

    // check whether it will be under any clientspec

    final VcsException[] ex = new VcsException[1];

    ProgressManager.getInstance().runProcessWithProgressSynchronously(new Runnable() {
      public void run() {
        try {
          for(VirtualFile vFile: vFiles) {
            final P4Connection connection = PerforceConnectionManager.getInstance(myProject).getConnectionForFile(vFile);

            P4File p4File = P4File.create(vFile);
            FStat p4FStat = p4File.getFstat(settings, connection, true);
            if ((p4FStat.status == FStat.STATUS_NOT_ADDED || p4FStat.status == FStat.STATUS_ONLY_LOCAL) &&
              p4FStat.local != FStat.LOCAL_BRANCHING) {
              throw new VcsException(
                PerforceBundle.message("confirmation.text.auto.edit.file.not.registered.on.server", p4File.getLocalPath()));
            }
            else if (p4FStat.status == FStat.STATUS_DELETED) {
              throw new VcsException(PerforceBundle.message("exception.text.file.deleted.from.server.cannot.edit", p4File.getLocalPath()));
            }
            else if (p4FStat.local != FStat.LOCAL_CHECKED_IN && p4FStat.local != FStat.LOCAL_INTEGRATING && p4FStat.local != FStat.LOCAL_BRANCHING) {
              throw new VcsException(
                PerforceBundle.message("exception.text.file..should.not.be.readonly.cannot.edit", p4File.getLocalPath()));
            }

            PerfCommands.p4editFile(p4File, settings, connection);
          }
        }
        catch (VcsException e) {
          ex[0] = e;
        }

      }

    }, PerforceBundle.message("progress.title.perforce.edit"), false, project);

    if (ex[0] != null) throw ex[0];
    for(VirtualFile vFile: vFiles) {
      vFile.refresh(true, false);
    }
  }

  public static PerforceVcs getInstance(Project project) {
    return project.getComponent(PerforceVcs.class);
  }


  public UpdateEnvironment getUpdateEnvironment() {
    return validProvider(myPerforceUpdateEnvironment);
  }

  public PerforceSettings getSettings() {
    return mySettings;
  }

  public Project getProject() {
    return myProject;
  }

  private class MyEditFileProvider implements EditFileProvider {
    public void editFiles(VirtualFile[] files) throws VcsException {
      autoEditVFile(files);
    }

    public String getRequestText() {
      return PerforceBundle.message("confirmation.text.open.files.for.edit");
    }

  }

  public boolean fileIsUnderVcs(FilePath filePath) {
    VirtualFile virtualFile = filePath.getVirtualFile();
    if (virtualFile == null) return false;

    final P4Connection connection = PerforceConnectionManager.getInstance(myProject).getConnectionForFile(virtualFile);

    if (virtualFile.isDirectory()) {
      return PerforceManager.getInstance(getProject()).isUnderPerforceRoot(virtualFile);
    }
    else {
      final P4File p4File = P4File.create(virtualFile);

      try {
        final FStat fstat = p4File.getFstat(getSettings(), connection, false);
        return fstat.status != FStat.STATUS_NOT_ADDED;
      }
      catch (VcsException e) {
        return false;
      }
    }
  }

  public boolean fileExistsInVcs(FilePath filePath) {
    VirtualFile virtualFile = filePath.getVirtualFile();
    if (virtualFile == null) return false;

    final PerforceManager perforceManager = PerforceManager.getInstance(getProject());

    if (!mySettings.ENABLED || cannotConnectToPerforceServer(perforceManager)) {
      return true;
    }

    if (virtualFile.isDirectory()) {
      return perforceManager.isUnderPerforceRoot(virtualFile);
    }
    else {
      final FileStatus fileStatus = ChangeListManager.getInstance(myProject).getStatus(virtualFile);
      return fileStatus != FileStatus.UNKNOWN && fileStatus != FileStatus.ADDED;
    }
  }

  private boolean cannotConnectToPerforceServer(final PerforceManager perforceManager) {
    final List<P4Connection> allConnections = PerforceSettings.getSettings(myProject).getAllConnections();
    for (P4Connection connection : allConnections) {
      final List<String> clientRoots = perforceManager.getCachedInfo(connection).get(PerfCommands.CLIENT_ROOT);
      if (clientRoots == null || clientRoots.isEmpty()) return true;
    }
    return false;
  }

  public VcsHistoryProvider getVcsHistoryProvider() {
    return validProvider(myHistoryProvider);
  }

  public VcsHistoryProvider getVcsBlockHistoryProvider() {
    return validProvider(myHistoryProvider);
  }

  public UpToDateRevisionProvider getUpToDateRevisionProvider() {
    return validProvider(myUpToDateRevisionsProvider);
  }

  public AnnotationProvider getAnnotationProvider() {
    return validProvider(myAnnotationProvider);
  }

  public DiffProvider getDiffProvider() {
    return validProvider(myDiffProvider);
  }

  public ChangeProvider getChangeProvider() {
    return validProvider(myChangeProvider);
  }

  public VcsShowConfirmationOption getAddOption() {
    return myAddOption;
  }

  public VcsShowConfirmationOption getRemoveOption() {
    return myRemoveOption;
  }

  private static class DisabledFileProvider implements EditFileProvider {
    private final String myMessage;

    public DisabledFileProvider(final String message) {
      myMessage = message;
    }

    public void editFiles(VirtualFile[] files) throws VcsException {
      final int answer =
        Messages.showYesNoDialog(myMessage, PerforceBundle.message("message.title.cannot.edit"), Messages.getWarningIcon());

      if (answer == 0) {
        for (final VirtualFile file : files) {
          final IOException[] ex = new IOException[1];
          ApplicationManager.getApplication().runWriteAction(new Runnable() {
            public void run() {
              try {
                ReadOnlyAttributeUtil.setReadOnlyAttribute(file, false);
              }
              catch (IOException e) {
                ex[0] = e;
              }
            }
          });
          if (ex[0] != null) {
            throw new VcsException(ex[0]);
          }
        }
      }

    }

    public String getRequestText() {
      return PerforceBundle.message("confirmation.text.open.files.for.edit");
    }
  }

  public UpdateEnvironment getIntegrateEnvironment() {
    return myPerforceIntegrateEnvironment;
  }

  public VersionsProvider getVersionsProvider(VirtualFile root) {
    return new PerforceVersionsProvider(getProject(), root);
  }

  protected void activate() {
    ChangeListSynchronizer.getInstance(myProject).startListening();
  }

  protected void deactivate() {
    ChangeListSynchronizer.getInstance(myProject).stopListening();
  }
}
