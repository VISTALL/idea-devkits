/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.FileStatusManager;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.FileStatus;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vcsUtil.VcsUtil;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.perforce.FStat;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MoveRenameHandler extends BaseHandler {

  class MovedFileInfo {
    P4Connection myOldConnection;
    P4Connection myNewConnection;

    String myOldPath;
    String myNewPath;
    private VirtualFile myFile;

    public MovedFileInfo(VirtualFile file, final String newPath) {
      myOldConnection = PerforceConnectionManager.getInstance(myProject).getConnectionForFile(file);
      myOldPath = file.getPath();
      myNewPath = newPath;
      myFile = file;
    }

    public void updateNewConnection() {
      myNewConnection = PerforceConnectionManager.getInstance(myProject).getConnectionForFile(myFile);
    }
  }

  private final List<MovedFileInfo> myMovedFileInfos = new ArrayList<MovedFileInfo>();
  private static final int CYCLE = 3;
  private static final int DOUBLE_RENAME = 2;
  private static final int SIMPLE = 1;

  public MoveRenameHandler(Project project) {
    super(project);
  }

  public void onFileRenamedOrMoved(VirtualFile file, String newParentPath, String newName) {
    if (file.isDirectory()) {
      VirtualFile[] children = file.getChildren();
      if (children != null) {
        for (VirtualFile child : children) {
          onFileRenamedOrMoved(child, newParentPath + "/" + newName, child.getName());
        }
      }
    }
    else {
      processFile(file, newParentPath, newName);
    }
  }

  private void processFile(VirtualFile file, String newParentPath, String newName) {
    if (FileStatusManager.getInstance(myProject).getStatus(file) != FileStatus.UNKNOWN) {
      myMovedFileInfos.add(new MovedFileInfo(file, newParentPath + "/" + newName));
    }
  }

  public void execute() throws VcsException {
    for (MovedFileInfo info : myMovedFileInfos) {
      info.updateNewConnection();
      moveFile(info.myOldConnection, info.myNewConnection, info.myOldPath, info.myNewPath, info.myFile);
    }
  }

  private void moveFile(final P4Connection oldConnection,
                        final P4Connection newConnection,
                        String oldPath,
                        String newPath,
                        final VirtualFile file) throws VcsException {

    PerforceSettings settings = PerforceSettings.getSettings(myProject);

    final P4File oldP4File = P4File.createInefficientFromLocalPath(oldPath);
    final P4File newP4File = P4File.createInefficientFromLocalPath(newPath);
    try {


      final String client = PerfCommands.p4client(settings, newConnection);

      if (client == null) {
        return;
      }

      final FStat oldfstat = oldP4File.getFstat(settings, oldConnection, false);

      boolean fileWasLocallyAdded = oldfstat.local == FStat.LOCAL_ADDING;
      boolean fileWasUnderPerforce = oldfstat.status != FStat.STATUS_NOT_ADDED;
      if (fileWasLocallyAdded || !fileWasUnderPerforce || oldConnection != newConnection) {
        if (fileWasLocallyAdded) {
          PerfCommands.assureNoFile(oldP4File, settings, true, false, oldConnection);
        }
        else {
          deleteOldFile(oldP4File, settings, oldConnection);
        }

        createNewFile(newP4File, settings, newConnection);
      }
      else {
        int type = detectType(oldfstat, oldP4File, newPath);
        switch (type) {
          case CYCLE:
            processCycle(newP4File, settings, oldP4File, newConnection);
            break;
          case DOUBLE_RENAME:
            processDoubleRename(oldfstat.fromFile, settings, newP4File, oldP4File, newConnection);
            break;
          case SIMPLE:
            processRename(newP4File, settings, oldP4File, newConnection);
            break;
        }
      }
    }
    finally {
      oldP4File.clearCache();
      newP4File.clearCache();
      P4File.invalidateFstat(file);
      FileStatusManager.getInstance(myProject).fileStatusChanged(file);
      VcsDirtyScopeManager.getInstance(myProject).fileDirty(VcsUtil.getFilePath(oldPath));
      VcsDirtyScopeManager.getInstance(myProject).fileDirty(VcsUtil.getFilePath(newPath));
    }

  }

  private static int detectType(FStat oldfstat, P4File oldP4File, String newPath) throws VcsException {
    boolean doubleRename = false;
    P4File realOldP4File = null;
    if (oldfstat.local == FStat.LOCAL_BRANCHING) {
      realOldP4File = oldfstat.fromFile;
      doubleRename = true;
    }
    if (realOldP4File == null) {
      realOldP4File = oldP4File;
      doubleRename = false;
    }

    if (doubleRename) {
      if (new File(newPath).equals(new File(realOldP4File.getLocalPath()))) {
        return CYCLE;
      }
      else {
        return DOUBLE_RENAME;
      }

    }
    else {
      return SIMPLE;
    }

  }

  private static void createNewFile(final P4File newP4File, PerforceSettings settings, final P4Connection connection) throws VcsException {
    PerfCommands.assureAdd(newP4File, settings, connection);
  }

  private static void deleteOldFile(final P4File oldP4File, PerforceSettings settings, final P4Connection connection) throws VcsException {
    //PerfCommands.assureRW(oldP4File, settings);
    PerfCommands.assureDel(oldP4File, settings, true, connection);
  }

  private static void processRename(final P4File newP4File, final PerforceSettings settings, final P4File oldP4File, final P4Connection connection)
    throws VcsException {

    final String newPath = newP4File.getAnyPath();
    final File newFile = new File(newPath);

    new ActionWithTempFile(newFile) {
      protected void executeInternal() throws VcsException {
        PerfCommands.assureNoFile(newP4File, settings, false, true, connection);

        final boolean deleteLocalCopy = !new File(oldP4File.getAnyPath()).isFile();
        PerfCommands.p4integrate(oldP4File, newP4File, settings, connection);
        PerfCommands.p4editFile(newP4File, settings, connection);
        if (deleteLocalCopy) {
          PerfCommands.assureDel(oldP4File, settings, true, connection);
        }
      }
    }.execute();
  }

  private static void processDoubleRename(final P4File realOldP4File,
                                          final PerforceSettings settings,
                                          final P4File newP4File,
                                          final P4File oldP4File,
                                          final P4Connection connection) throws VcsException {
    final FStat realOldfstat = realOldP4File.getFstat(settings, connection, false);
    if (realOldfstat.status == FStat.STATUS_DELETED) {
      throw new VcsException(PerforceBundle.message("exception.text.cannot.move.original.deleted"));
    }
    new ActionWithTempFile(new File(newP4File.getAnyPath())) {
      protected void executeInternal() throws VcsException {
        PerfCommands.assureNoFile(newP4File, settings, false, false, connection);
        PerfCommands.p4revertFile(oldP4File, settings, true, connection);
        PerfCommands.p4revertFile(realOldP4File, settings, true, connection);
        PerfCommands.p4integrate(realOldP4File, newP4File, settings, connection);
        PerfCommands.p4editFile(newP4File, settings, connection);
      }
    }.execute();
    PerfCommands.assureDel(oldP4File, settings, true, connection);
    PerfCommands.assureDel(realOldP4File, settings, true, connection);
  }

  private static void processCycle(final P4File newP4File, final PerforceSettings settings, final P4File oldP4File, final P4Connection connection)
    throws VcsException {
    final FStat newfstat = newP4File.getFstat(settings, connection, false);
    if (newfstat.local == FStat.LOCAL_DELETING) {
      new ActionWithTempFile(new File(newP4File.getAnyPath())) {
        protected void executeInternal() throws VcsException {
          PerfCommands.p4revertFile(newP4File, settings, false, connection);
          PerfCommands.p4editFile(newP4File, settings, connection);
        }
      }.execute();
    }
    else if (newfstat.status == FStat.STATUS_NOT_ADDED || newfstat.status == FStat.STATUS_ONLY_LOCAL) {
      createNewFile(newP4File, settings, connection);
    }
    else {
      throw new VcsException(PerforceBundle.message("exception.text.cannot.rename"));
    }
    PerfCommands.assureDel(oldP4File, settings, true, connection);
  }
}
