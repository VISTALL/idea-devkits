/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.AsyncUpdateAction;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.AbstractVcsHelper;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.actions.VcsContext;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.peer.PeerFactory;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.merge.PerforceMergeProvider;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import java.util.Arrays;
import java.util.List;

public class ResolveAllAction extends AsyncUpdateAction<VcsContext> {
  protected VcsContext prepareDataFromContext(final AnActionEvent e) {
    return PeerFactory.getInstance().getVcsContextFactory().createCachedContextOn(e);
  }

  protected void performUpdate(final Presentation presentation, final VcsContext context) {
    final Project project = context.getProject();
    presentation.setVisible(project != null);
    presentation.setEnabled(project != null);

    final PerforceSettings settings = PerforceSettings.getSettings(project);
    final List<P4Connection> allConnections = settings.getAllConnections();
    for (P4Connection connection : allConnections) {
      if (settings.getServerVersion(connection) < 2004){
        presentation.setVisible(false);
        presentation.setEnabled(false);
        return;
      }
    }
  }

  protected boolean forceSyncUpdate(final AnActionEvent e) {
    return true;
  }

  public void actionPerformed(AnActionEvent e) {
    final VcsContext context = PeerFactory.getInstance().getVcsContextFactory().createCachedContextOn(e);
    try {
      final VirtualFile[] filesToResolve = PerfCommands.p4getResolvedWithConflicts(PerforceSettings.getSettings(context.getProject()));
      if (filesToResolve.length == 0) {
        Messages.showInfoMessage(PerforceBundle.message("message.text.no.files.to.resolve"), PerforceBundle.message("message.title.resolve"));
      } else {
        AbstractVcsHelper.getInstance(context.getProject()).showMergeDialog(Arrays.asList(filesToResolve),
                                                                            new PerforceMergeProvider(context.getProject()), e);
      }
    }
    catch (VcsException e1) {
      Messages.showErrorDialog(e1.getLocalizedMessage(), PerforceBundle.message("message.title.resolve"));
    }
  }
}
