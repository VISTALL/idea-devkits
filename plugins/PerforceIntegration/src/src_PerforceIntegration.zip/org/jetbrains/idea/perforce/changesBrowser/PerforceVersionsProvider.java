/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.changesBrowser;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.ui.RefreshableOnComponent;
import com.intellij.openapi.vcs.versionBrowser.ChangeBrowserSettings;
import com.intellij.openapi.vcs.versionBrowser.RepositoryVersion;
import com.intellij.openapi.vcs.versionBrowser.VersionsProvider;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.ui.ColumnInfo;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.idea.perforce.ChangeListData;
import org.jetbrains.idea.perforce.PerforceBundle;
import org.jetbrains.idea.perforce.perforce.ChangeList;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerfCommands;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class PerforceVersionsProvider implements VersionsProvider {
  private final static ColumnInfo<ChangeList, Long> NUMBER =
    new ColumnInfo<ChangeList, Long>(PerforceBundle.message("changes.browser.change.coulmn.name")) {
      public Long valueOf(final ChangeList object) {
        return new Long(object.getNumber());
      }

      public Comparator<ChangeList> getComparator() {
        return new Comparator<ChangeList>() {
          public int compare(final ChangeList o1, final ChangeList o2) {
            if (o1.getNumber() == o2.getNumber()) return 0;
            return o1.getNumber() < o2.getNumber() ? -1 : 1;
          }
        };
      }
    };

  private final static ColumnInfo<ChangeList, String> CLIENT =
    new ColumnInfo<ChangeList, String>(PerforceBundle.message("changes.browser.client.column.name")) {
      public String valueOf(final ChangeList object) {
        return object.getClient();
      }

      public Comparator<ChangeList> getComparator() {
        return new Comparator<ChangeList>() {
          public int compare(final ChangeList o1, final ChangeList o2) {
            return o1.getClient().compareTo(o2.getClient());
          }
        };
      }
    };

  private final static ColumnInfo<ChangeList, String> USER =
    new ColumnInfo<ChangeList, String>(PerforceBundle.message("changes.browser.user.column.name")) {
      public String valueOf(final ChangeList object) {
        return object.getUser();
      }

      public Comparator<ChangeList> getComparator() {
        return new Comparator<ChangeList>() {
          public int compare(final ChangeList o1, final ChangeList o2) {
            return o1.getUser().compareTo(o2.getUser());
          }
        };
      }
    };

  private final static ColumnInfo<ChangeList, String> DATE =
    new ColumnInfo<ChangeList, String>(PerforceBundle.message("changes.browser.date.column.name")) {
      public String valueOf(final ChangeList object) {
        return ChangeListData.DATE_FORMAT.format(object.getDate());
      }

      public Comparator<ChangeList> getComparator() {
        return new Comparator<ChangeList>() {
          public int compare(final ChangeList o1, final ChangeList o2) {
            return o1.getDate().compareTo(o2.getDate());
          }
        };
      }
    };

  private final Project myProject;
  @Nullable private final VirtualFile mySelectedDirectory;
  private final P4Connection myConnection;


  public PerforceVersionsProvider(final Project project, final P4Connection connection) {
    myProject = project;
    myConnection = connection;
    mySelectedDirectory = null;
  }

  public PerforceVersionsProvider(final Project project, VirtualFile selectedDirectory) {
    myProject = project;
    mySelectedDirectory = selectedDirectory;
    myConnection = PerforceSettings.getSettings(project).getConnectionForFile(selectedDirectory);

  }

  public ColumnInfo[] getVersionProperties() {
    return new ColumnInfo[]{NUMBER,
      DATE,
      CLIENT,
      USER};
  }

  public RefreshableOnComponent createFilterUI() {
    return new PerforceVersionFilterComponent(myProject, myConnection);
  }

  public List<RepositoryVersion> getFilteredVersions() throws VcsException {
    final List<RepositoryVersion> changeListInfos = new ArrayList<RepositoryVersion>();
    final PerforceChangeBrowserSettings perforceBrowserSettings = PerforceChangeBrowserSettings.getSettingsInstance(myProject);
    final ChangeBrowserSettings settings = ChangeBrowserSettings.getSettings(myProject);

    final String client = perforceBrowserSettings.getClientFilter();
    final String user = settings.getUserFilter();
    changeListInfos.addAll(PerfCommands.p4getSubmittedChangeLists(PerforceSettings.getSettings(myProject), client, user, getRootP4File(),
                                                                  settings.getDateAfterFilter(), settings.getDateBeforeFilter(),
                                                                  settings.getChangeAfterFilter(), settings.getChangeBeforeFilter(),
                                                                  myConnection));
    settings.filterChanges(changeListInfos);
    return changeListInfos;
  }

  private P4File getRootP4File() {
    if (mySelectedDirectory == null) {
      return null;
    }
    else {
      return P4File.create(mySelectedDirectory);
    }
  }
}
