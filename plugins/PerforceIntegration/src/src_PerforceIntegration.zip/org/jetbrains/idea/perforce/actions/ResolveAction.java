/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.AsyncUpdateAction;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.AbstractVcsHelper;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.actions.VcsContext;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.peer.PeerFactory;
import org.jetbrains.idea.perforce.merge.PerforceMergeProvider;
import org.jetbrains.idea.perforce.perforce.FStat;
import org.jetbrains.idea.perforce.perforce.P4File;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

import java.util.Arrays;

public class ResolveAction extends AsyncUpdateAction<VcsContext> {
  protected VcsContext prepareDataFromContext(final AnActionEvent e) {
    return PeerFactory.getInstance().getVcsContextFactory().createCachedContextOn(e);
  }

  protected boolean forceSyncUpdate(final AnActionEvent e) {
    return true;
  }

  protected void performUpdate(final Presentation presentation, final VcsContext context) {
    final Project project = context.getProject();
    if (project == null) {
      presentation.setVisible(false);
      presentation.setEnabled(false);
      return;
    }
    presentation.setVisible(true);
    final VirtualFile[] selectedFiles = context.getSelectedFiles();
    if (selectedFiles.length == 0) {
      presentation.setEnabled(false);
      return;
    }
    else {
      for (VirtualFile selectedFile : selectedFiles) {
        if (PerforceSettings.getSettings(project).getServerVersion(PerforceSettings.getSettings(project).getConnectionForFile(selectedFile)) < 2004){
          presentation.setVisible(false);
          presentation.setEnabled(false);
          return;
        }

        if (selectedFile.isDirectory()) {
          presentation.setEnabled(false);
          return;
        }
      }
    }

   final P4Connection connection = PerforceConnectionManager.getInstance(project).getConnectionForFile(selectedFiles[0]);
    try {
      final FStat fstat = P4File.create(selectedFiles[0]).getFstat(PerforceSettings.getSettings(project), connection, false);
      if (fstat.unresolved == null) {
        presentation.setEnabled(false);
      }
    }
    catch (VcsException e1) {
      presentation.setEnabled(false);
    }
  }

  public void actionPerformed(AnActionEvent e) {
    final VcsContext context = PeerFactory.getInstance().getVcsContextFactory().createCachedContextOn(e);
    final VirtualFile[] selectedFiles = context.getSelectedFiles();

    final Project project = context.getProject();
    AbstractVcsHelper.getInstance(project).showMergeDialog(Arrays.asList(selectedFiles),
                                                           new PerforceMergeProvider(project), e);
  }
}
