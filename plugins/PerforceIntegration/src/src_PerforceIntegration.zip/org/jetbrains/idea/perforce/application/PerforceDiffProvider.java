/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.diff.DiffProvider;
import com.intellij.openapi.vcs.history.VcsFileContent;
import com.intellij.openapi.vcs.history.VcsRevisionNumber;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.idea.perforce.perforce.*;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.perforce.connections.PerforceConnectionManager;

public class PerforceDiffProvider implements DiffProvider{
  private final Project myProject;

  public PerforceDiffProvider(final Project project) {
    myProject = project;
  }

  public VcsRevisionNumber getCurrentRevision(VirtualFile file) {
    try {
      final P4Connection connection = PerforceConnectionManager.getInstance(myProject).getConnectionForFile(file);
      final FStat fstat = P4File.create(file).getFstat(PerforceSettings.getSettings(myProject), connection, false);
      return new PerforceVcsRevisionNumber(Long.parseLong(fstat.haveRev),Long.parseLong(fstat.headChange), false);
    }
    catch (VcsException e) {
      return null;
    }
  }

  public VcsRevisionNumber getLastRevision(VirtualFile file) {
    try {
      final P4Connection connection = PerforceConnectionManager.getInstance(myProject).getConnectionForFile(file);
      final FStat fstat = P4File.create(file).getFstat(PerforceSettings.getSettings(myProject), connection, false);
      final String headRev = fstat.headRev;
      final String headChange = fstat.headChange;
      if (headRev == null || headRev.length() == 0 || headChange == null || headChange.length() == 0) {
        return null;
      }
      return new PerforceVcsRevisionNumber(Long.parseLong(headRev), Long.parseLong(headChange), false);
    }
    catch (VcsException e) {
      return null;
    }
  }

  public VcsFileContent createFileContent(final VcsRevisionNumber revisionNumber, final VirtualFile selectedFile) {
    final long longValue = ((PerforceVcsRevisionNumber)revisionNumber).getRevisionNumber();
    return new VcsFileContent() {
      private byte[] myContent;
      public void loadContent() throws VcsException {
        final PerforceSettings settings = PerforceSettings.getSettings(myProject);
        final ExecResult execResult =
          PerfCommands.executeP4Command(settings, new String[]{"print", "-q", selectedFile.getPath() + "#" + longValue},
                                        settings.getConnectionForFile(selectedFile));
        PerfCommands.checkError(execResult);
        myContent = execResult.getByteOut();
      }

      public byte[] getContent() {
        return myContent;
      }
    };
  }
}
