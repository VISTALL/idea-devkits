/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.ide.FrameStateListener;
import com.intellij.ide.FrameStateManager;
import com.intellij.openapi.application.Application;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.vcs.*;
import com.intellij.openapi.vcs.changes.ChangeListManager;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vfs.*;
import com.intellij.util.Alarm;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.idea.perforce.perforce.*;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;
import org.jetbrains.idea.perforce.ServerVersion;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PerforceManager implements ProjectComponent {
  private final Project myProject;

  private static final Logger LOG = Logger.getInstance("#org.jetbrains.idea.perforce.application.PerforceManager");

  private Map<P4Connection, Map<String, List<String>>> myCachedP4Info = new HashMap<P4Connection, Map<String, List<String>>>();
  private final VirtualFileAdapter myListener;
  @SuppressWarnings({"FieldAccessedSynchronizedAndUnsynchronized"}) private long myLastValidTime;

  private final Alarm myUpdateAlarm = new Alarm(Alarm.ThreadToUse.SHARED_THREAD);
  private final Runnable myUpdateRequest;
  private final FrameStateListener myFrameStateListener = new FrameStateListener() {
    public void onFrameDeactivated() {

    }

    public void onFrameActivated() {
      if (perforceIsUsed()) {
        addUpdateRequest();
      }
    }
  };

  public static PerforceManager getInstance(Project project) {
    return project.getComponent(PerforceManager.class);
  }

  public synchronized void clearCache() {
    myLastValidTime = -1;
    refreshData(false);
  }

  private void refreshData(boolean updateOpened) {
    if (perforceIsUsed()) {
      new MyUpdateRequest(updateOpened).run();
    }
  }

  public boolean perforceIsUsed() {
    final AbstractVcs[] activeVcses = ApplicationManager.getApplication().runReadAction(new Computable<AbstractVcs[]>() {
      public AbstractVcs[] compute() {
        return ProjectLevelVcsManager.getInstance(myProject).getAllActiveVcss();
    }});
    final PerforceVcs perfVcs = PerforceVcs.getInstance(myProject);
    return Arrays.asList(activeVcses).contains(perfVcs);
  }

  public PerforceManager(Project project) {
    myProject = project;
    myListener = new VirtualFileAdapter() {
      public void propertyChanged(VirtualFilePropertyEvent event) {
        if (!event.isFromRefresh()) return;
        if (event.getPropertyName().equals(VirtualFile.PROP_WRITABLE)) {
          final boolean wasWritable = ((Boolean)event.getOldValue()).booleanValue();
          if (wasWritable) {
            event.getFile().putUserData(P4File.KEY, null);
          }
        }
      }

      public void contentsChanged(VirtualFileEvent event) {
        if (!event.isFromRefresh()) return;
        if (!event.getFile().isWritable()) {
          event.getFile().putUserData(P4File.KEY, null);
        }
      }
    };

    myUpdateRequest = new MyUpdateRequest(true);
  }

  private void updatePerforceModules() {
    ApplicationManager.getApplication().runReadAction(new Runnable() {
      public void run() {
        Module[] modules = ModuleManager.getInstance(myProject).getModules();
        for (Module module : modules) {
          if (ModuleLevelVcsManager.getInstance(module).getActiveVcs() instanceof PerforceVcs) {
            final ModuleRootManager rootManager = ModuleRootManager.getInstance(module);

            VirtualFile[] roots = rootManager.getContentRoots();
            for (VirtualFile root : roots) {
              VcsDirtyScopeManager.getInstance(myProject).dirDirtyRecursively(root, false);
            }
          }
        }
      }
    });

    ChangeListManager.getInstance(myProject).scheduleUpdate();
  }

  private void serverDataChanged() {
    myLastValidTime = System.currentTimeMillis();
  }

  public void projectOpened() {
    VirtualFileManager.getInstance().addVirtualFileListener(myListener);
    FrameStateManager.getInstance().addListener(myFrameStateListener);
    refreshData(false);
    myLastValidTime = System.currentTimeMillis();
  }

  public void projectClosed() {
    VirtualFileManager.getInstance().removeVirtualFileListener(myListener);
    myUpdateAlarm.cancelAllRequests();
    FrameStateManager.getInstance().removeListener(myFrameStateListener);
  }

  @NotNull
  public String getComponentName() {
    return "PerforceManager";
  }

  public void initComponent() {
  }

  public void disposeComponent() {
    myUpdateAlarm.cancelAllRequests();
  }

  private Map<P4Connection, Map<String, List<String>>> loadInfo() {
    final HashMap<P4Connection, Map<String, List<String>>> result = new HashMap<P4Connection, Map<String, List<String>>>();
    if (!PerforceSettings.getSettings(myProject).ENABLED) {
      return result;
    }
    else {

      final List<P4Connection> allConnections = getSettings().getAllConnections();
      for (P4Connection connection : allConnections) {
        try {
          final Map<String, List<String>> infoMap = PerfCommands.p4info(getSettings(), connection);
          // the following fields change on every invocation, and changes in these fields should not cause the
          // serverDataChanged notification to be fired
          infoMap.remove(PerfCommands.CLIENT_ADDRESS);
          infoMap.remove(PerfCommands.SERVER_DATE);
          result.put(connection, infoMap);
        }
        catch (VcsException e) {
          result.put(connection, new HashMap<String, List<String>>());
        }

      }

    }

    return result;
  }

  protected synchronized Map<String, List<String>> getCachedInfo(P4Connection connection) {
    if (myCachedP4Info == null || !myCachedP4Info.containsKey(connection)) {
      new MyUpdateRequest(false).run();
    }
    final Map<String, List<String>> result = myCachedP4Info.get(connection);
    if (result != null) {
      return result;
    }
    else {
      return new HashMap<String, List<String>>();
    }
  }

  private void addUpdateRequest() {
    myUpdateAlarm.cancelAllRequests();
    myUpdateAlarm.addRequest(myUpdateRequest, 100);
  }

  private PerforceSettings getSettings() {
    return PerforceSettings.getSettings(myProject);
  }


  public String getClientRoot(final P4Connection connection) {
    return getClientRoot(getCachedInfo(connection));
  }

  public static String getClientRoot(final Map<String, List<String>> info) {
    final List<String> mainRootValues = info.get(PerfCommands.CLIENT_ROOT);
    final List<String> altRootValues = info.get(PerfCommands.ALT_CLIENT_ROOT);

    if (mainRootValues != null) {
      for (String mainRootValue : mainRootValues) {
        if (new File(mainRootValue).isDirectory()) {
          return mainRootValue;
        }
      }
    }

    if (altRootValues != null) {
      for (String altRootValue : altRootValues) {
        if (new File(altRootValue).isDirectory()) {
          return altRootValue;
        }
      }
    }

    return null;
  }

  public long getServerVertionYear(final P4Connection connection) {
    final List<String> serverVersions = getCachedInfo(connection).get(PerfCommands.SERVER_VERSION);
    if (serverVersions == null || serverVersions.isEmpty()) return -1;
    return OutputMessageParser.parseServerVersion(serverVersions.get(0)).getVersionYear();
  }


  @Nullable
  public ServerVersion getServerVersion(final P4Connection connection) {
    final List<String> serverVersions = getCachedInfo(connection).get(PerfCommands.SERVER_VERSION);
    if (serverVersions == null || serverVersions.isEmpty()) return null;
    return OutputMessageParser.parseServerVersion(serverVersions.get(0));
  }

  public long getLastValidTime() {
    return myLastValidTime;
  }

  public boolean isUnderPerforceRoot(@NotNull final VirtualFile virtualFile) {
    final P4Connection connection = PerforceSettings.getSettings(myProject).getConnectionForFile(virtualFile);
    final Application application = ApplicationManager.getApplication();
    final boolean[] result = new boolean[1];
    final Runnable runnable = new Runnable() {
      public void run() {
        final String path = PerforceManager.getClientRoot(getCachedInfo(connection));
        if (path != null) {
          final VirtualFile root = LocalFileSystem.getInstance().findFileByIoFile(new File(path));
          if (root != null && ((root == virtualFile) || !VfsUtil.isAncestor(virtualFile, root, false))) {
            result[0] = true;
            return;
          }
        }
        result[0] = false;
      }
    };

    application.runReadAction(runnable);

    return result[0];
  }

  @Nullable
  public static String getRelativePath(String filePath, PerforceClient client) throws VcsException {
    return View.getRelativePath(filePath, client.getName(), client.getViews());
  }

  @Nullable
  public static File getFileByDepotName(final String depotPath, PerforceClient client) throws VcsException {

    int revNumStart = depotPath.indexOf("#");

    final String clientRoot = client.getRoot();
    if (clientRoot == null) {
      throw new VcsException("Failed to retrieve client root");
    }
    final String relativePath;

    if (revNumStart >= 0) {
      relativePath = getRelativePath(depotPath.substring(0, revNumStart), client);

    }
    else {
      relativePath = getRelativePath(depotPath, client);
    }

    if (relativePath == null)  {
      final StringBuffer message = new StringBuffer();
      final List<View> views = client.getViews();
      for (View view : views) {
        message.append('\n');
        message.append("View ");
        message.append(view.toString());
      }
      message.append("Cannot find local file for depot path: ").append(depotPath);
      LOG.info(message.toString());

      return null;
    }

    if (clientRoot.length() > 0) {
      return new File(clientRoot, relativePath.trim());
    }
    else {
      return new File(relativePath.trim());
    }
  }

  @NotNull
  public PerforceClient getClient(final P4Connection connection) {
    return new PerforceClientImpl(myProject, connection);
  }

  public boolean statusIsValid(final long statTime) {
    return getLastValidTime() != -1 && statTime > getLastValidTime();

  }

  public void configurationChanged() {
    clearCache();
    P4File.invalidateFstat(myProject);
    FileStatusManager.getInstance(myProject).fileStatusesChanged();

  }

  private class MyUpdateRequest implements Runnable {
    private boolean myUpdateOpened;

    public MyUpdateRequest(final boolean updateOpened) {
      myUpdateOpened = updateOpened;
    }

    @SuppressWarnings({"SynchronizeOnThis"})
    public void run() {
      myUpdateAlarm.cancelAllRequests();
      try {
        final Map<P4Connection, Map<String, List<String>>> oldInfo;
        synchronized (PerforceManager.this) {
          oldInfo = myCachedP4Info;
        }
        final Map<P4Connection, Map<String, List<String>>> newInfo = loadInfo();
        synchronized (PerforceManager.this) {
          myCachedP4Info = newInfo;
        }
        if (!Comparing.equal(oldInfo, newInfo)) {
          serverDataChanged();
        }

        if (myUpdateOpened && !ChangeListSynchronizer.getInstance(myProject).updateOpenedFiles()) {
          updatePerforceModules();
        }
      }
      finally {
        myUpdateAlarm.cancelAllRequests();
      }

    }
  }
}
