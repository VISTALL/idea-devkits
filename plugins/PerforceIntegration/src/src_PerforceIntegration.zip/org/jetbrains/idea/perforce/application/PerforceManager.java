/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.application;

import com.intellij.ide.FrameStateListener;
import com.intellij.ide.FrameStateManager;
import com.intellij.openapi.application.Application;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.vcs.AbstractVcs;
import com.intellij.openapi.vcs.ProjectLevelVcsManager;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.changes.ChangeListManager;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vfs.*;
import com.intellij.util.Alarm;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.idea.perforce.ServerVersion;
import org.jetbrains.idea.perforce.perforce.*;
import org.jetbrains.idea.perforce.perforce.connections.P4Connection;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PerforceManager  {
  private final Project myProject;

  private static final Logger LOG = Logger.getInstance("#org.jetbrains.idea.perforce.application.PerforceManager");

  private Map<P4Connection, Map<String, List<String>>> myCachedP4Info = null;
  private Map<P4Connection, Map<String, List<String>>> myCachedP4Clients = null;
  private Map<P4Connection, PerforceClient> myClientMap = new HashMap<P4Connection, PerforceClient>();
  
  private final VirtualFileAdapter myListener;
  @SuppressWarnings({"FieldAccessedSynchronizedAndUnsynchronized"}) private long myLastValidTime;

  private Alarm myUpdateAlarm;
  private final Runnable myUpdateRequest;
  private final FrameStateListener myFrameStateListener = new FrameStateListener() {
    public void onFrameDeactivated() {

    }

    public void onFrameActivated() {
      if (perforceIsUsed() && myProject.isInitialized()) {
        addUpdateRequest();
      }
    }
  };

  public static PerforceManager getInstance(Project project) {
    return ServiceManager.getService(project, PerforceManager.class);
  }

  public synchronized void clearCache() {
    myLastValidTime = -1;
    refreshData(false);
  }

  private void refreshData(boolean updateOpened) {
    if (perforceIsUsed()) {
      new MyUpdateRequest(updateOpened).run();
    }
  }

  public boolean perforceIsUsed() {
    final AbstractVcs[] activeVcses = ApplicationManager.getApplication().runReadAction(new Computable<AbstractVcs[]>() {
      public AbstractVcs[] compute() {
        return ProjectLevelVcsManager.getInstance(myProject).getAllActiveVcss();
    }});
    final PerforceVcs perfVcs = PerforceVcs.getInstance(myProject);
    return Arrays.asList(activeVcses).contains(perfVcs);
  }

  public PerforceManager(Project project) {
    myProject = project;
    myListener = new VirtualFileAdapter() {
      public void propertyChanged(VirtualFilePropertyEvent event) {
        if (!event.isFromRefresh()) return;
        if (event.getPropertyName().equals(VirtualFile.PROP_WRITABLE)) {
          final boolean wasWritable = ((Boolean)event.getOldValue()).booleanValue();
          if (wasWritable) {
            event.getFile().putUserData(P4File.KEY, null);
          }
        }
      }

      public void contentsChanged(VirtualFileEvent event) {
        if (!event.isFromRefresh()) return;
        if (!event.getFile().isWritable()) {
          event.getFile().putUserData(P4File.KEY, null);
        }
      }
    };

    myUpdateRequest = new MyUpdateRequest(true);
  }

  private void updatePerforceModules() {
    ApplicationManager.getApplication().runReadAction(new Runnable() {
      public void run() {
        PerforceVcs vcs = PerforceVcs.getInstance(myProject);
        VirtualFile[] contentRoots = ProjectLevelVcsManager.getInstance(myProject).getRootsUnderVcs(vcs);
        for(VirtualFile contentRoot: contentRoots) {
          VcsDirtyScopeManager.getInstance(myProject).dirDirtyRecursively(contentRoot);
        }
      }
    });

    ChangeListManager.getInstance(myProject).scheduleUpdate();
  }

  private void serverDataChanged() {
    myLastValidTime = System.currentTimeMillis();
  }

  public void startListening() {
    myUpdateAlarm = new Alarm(Alarm.ThreadToUse.OWN_THREAD);
    VirtualFileManager.getInstance().addVirtualFileListener(myListener);
    FrameStateManager.getInstance().addListener(myFrameStateListener);
    myLastValidTime = -1L;
  }

  public void stopListening() {
    VirtualFileManager.getInstance().removeVirtualFileListener(myListener);
    myUpdateAlarm.dispose();
    myUpdateAlarm = null;
    FrameStateManager.getInstance().removeListener(myFrameStateListener);
  }

  protected Map<String, List<String>> getCachedInfo(P4Connection connection) {
    return getCachedData(connection, true);
  }

  protected Map<String, List<String>> getCachedClients(P4Connection connection) {
    return getCachedData(connection, false);
  }

  private Map<String, List<String>> getCachedData(final P4Connection connection, boolean requestInfo) {
    synchronized (this) {
      Map<P4Connection, Map<String, List<String>>> map = requestInfo ? myCachedP4Info : myCachedP4Clients;
      if (map != null && map.containsKey(connection)) {
        final Map<String, List<String>> result = map.get(connection);
        if (result != null) {
          return result;
        }
        else {
          return new HashMap<String, List<String>>();
        }
      }
    }

    final MyUpdateRequest request = new MyUpdateRequest(false);
    request.run();
    Map<P4Connection, Map<String, List<String>>> map = requestInfo ? request.newInfo : request.newClients;
    if (map != null && map.containsKey(connection)) {
      return map.get(connection);
    }
    return new HashMap<String, List<String>>();
  }

  private void addUpdateRequest() {
    myUpdateAlarm.cancelRequest(myUpdateRequest);
    myUpdateAlarm.addRequest(myUpdateRequest, 100);
  }

  private PerforceSettings getSettings() {
    return PerforceSettings.getSettings(myProject);
  }


  public String getClientRoot(final P4Connection connection) {
    Map<String, List<String>> clientSpec = getCachedClients(connection);
    final List<String> mainRootValues = clientSpec.get(PerforceRunner.CLIENTSPEC_ROOT);
    final List<String> altRootValues = clientSpec.get(PerforceRunner.CLIENTSPEC_ALTROOTS);

    if (mainRootValues != null) {
      for (String mainRootValue : mainRootValues) {
        if (new File(mainRootValue).isDirectory()) {
          return mainRootValue;
        }
      }
    }

    if (altRootValues != null) {
      for (String altRootValue : altRootValues) {
        if (new File(altRootValue).isDirectory()) {
          return altRootValue;
        }
      }
    }

    return null;
  }

  public long getServerVertionYear(final P4Connection connection) {
    final List<String> serverVersions = getCachedInfo(connection).get(PerforceRunner.SERVER_VERSION);
    if (serverVersions == null || serverVersions.isEmpty()) return -1;
    return OutputMessageParser.parseServerVersion(serverVersions.get(0)).getVersionYear();
  }


  @Nullable
  public ServerVersion getServerVersion(final P4Connection connection) {
    final List<String> serverVersions = getCachedInfo(connection).get(PerforceRunner.SERVER_VERSION);
    if (serverVersions == null || serverVersions.isEmpty()) return null;
    return OutputMessageParser.parseServerVersion(serverVersions.get(0));
  }

  public long getLastValidTime() {
    return myLastValidTime;
  }

  public boolean isUnderPerforceRoot(@NotNull final VirtualFile virtualFile) {
    final P4Connection connection = PerforceSettings.getSettings(myProject).getConnectionForFile(virtualFile);
    final Application application = ApplicationManager.getApplication();
    final boolean[] result = new boolean[1];
    final Runnable runnable = new Runnable() {
      public void run() {
        final String path = getClientRoot(connection);
        if (path != null) {
          final VirtualFile root = LocalFileSystem.getInstance().findFileByIoFile(new File(path));
          if (root != null && ((root == virtualFile) || !VfsUtil.isAncestor(virtualFile, root, false))) {
            result[0] = true;
            return;
          }
        }
        result[0] = false;
      }
    };

    application.runReadAction(runnable);

    return result[0];
  }

  @Nullable
  private static String getRelativePath(String filePath, PerforceClient client) {
    return View.getRelativePath(filePath, client.getName(), client.getViews());
  }

  @Nullable
  public static File getFileByDepotName(final String depotPath, PerforceClient client) throws VcsException {

    int revNumStart = depotPath.indexOf("#");

    final String clientRoot = client.getRoot();
    if (clientRoot == null) {
      throw new VcsException("Failed to retrieve client root");
    }
    final String relativePath;

    if (revNumStart >= 0) {
      relativePath = getRelativePath(depotPath.substring(0, revNumStart), client);

    }
    else {
      relativePath = getRelativePath(depotPath, client);
    }

    if (relativePath == null)  {
      final StringBuffer message = new StringBuffer();
      final List<View> views = client.getViews();
      for (View view : views) {
        message.append('\n');
        message.append("View ");
        message.append(view.toString());
      }
      message.append("Cannot find local file for depot path: ").append(depotPath);
      LOG.info(message.toString());

      return null;
    }

    if (clientRoot.length() > 0) {
      return new File(clientRoot, relativePath.trim());
    }
    else {
      return new File(relativePath.trim());
    }
  }

  @NotNull
  public synchronized PerforceClient getClient(final P4Connection connection) {
    PerforceClient client = myClientMap.get(connection);
    if (client == null) {
      client = new PerforceClientImpl(myProject, connection);
      myClientMap.put(connection, client);
    }
    return client;
  }

  public void configurationChanged() {
    clearCache();
    P4File.invalidateFstat(myProject);
    ApplicationManager.getApplication().runReadAction(new Runnable() {
      public void run() {
        VcsDirtyScopeManager.getInstance(myProject).markEverythingDirty();
      }
    });
  }

  public void queueUpdateRequest(Runnable runnable) {
    if (ApplicationManager.getApplication().isUnitTestMode()) {
      runnable.run();
    }
    else {
      myUpdateAlarm.addRequest(runnable, 0);
    }
  }

  private class MyUpdateRequest implements Runnable {
    private boolean myUpdateOpened;
    public HashMap<P4Connection, Map<String, List<String>>> newInfo;
    public HashMap<P4Connection, Map<String, List<String>>> newClients;

    public MyUpdateRequest(final boolean updateOpened) {
      myUpdateOpened = updateOpened;
    }

    @SuppressWarnings({"SynchronizeOnThis"})
    public void run() {
      final Alarm alarm = myUpdateAlarm;
      if (alarm == null) return;   // already disposed
      alarm.cancelRequest(this);
      try {
        final Map<P4Connection, Map<String, List<String>>> oldInfo;
        final Map<P4Connection, Map<String, List<String>>> oldClients;
        synchronized (PerforceManager.this) {
          oldInfo = myCachedP4Info;
          oldClients = myCachedP4Clients;
        }

        newInfo = new HashMap<P4Connection, Map<String, List<String>>>();
        newClients = new HashMap<P4Connection, Map<String, List<String>>>();
        if (PerforceSettings.getSettings(myProject).ENABLED) {
          final List<P4Connection> allConnections = getSettings().getAllConnections();
          for (P4Connection connection : allConnections) {
            try {
              final Map<String, List<String>> infoMap = PerforceRunner.getInstance(myProject).getInfo(connection);
              final List<String> client = infoMap.get(PerforceRunner.CLIENT_NAME);
              final Map<String, List<String>> clientMap;
              if (client != null && client.size() > 0) {
                clientMap = PerforceRunner.getInstance(myProject).loadClient(client.get(0), connection);
              }
              else {
                clientMap = new HashMap<String, List<String>>();
              }
              // the following fields change on every invocation, and changes in these fields should not cause the
              // serverDataChanged notification to be fired
              infoMap.remove(PerforceRunner.CLIENT_ADDRESS);
              infoMap.remove(PerforceRunner.SERVER_DATE);
              newInfo.put(connection, infoMap);
              newClients.put(connection, clientMap);
            }
            catch (VcsException e) {
              newInfo.put(connection, new HashMap<String, List<String>>());
              newClients.put(connection, new HashMap<String, List<String>>());
            }
          }
        }

        synchronized (PerforceManager.this) {
          myCachedP4Info = newInfo;
          myCachedP4Clients = newClients;
        }
        if (!Comparing.equal(oldInfo, newInfo)) {
          serverDataChanged();
        }
        if (!Comparing.equal(oldClients, newClients)) {
          serverDataChanged();
          synchronized(PerforceManager.this) {
            myClientMap.clear();
          }
        }

        final ChangeListSynchronizer changeListSynchronizer = ChangeListSynchronizer.getInstance(myProject);
        if (myUpdateOpened && !myProject.isDisposed() && !changeListSynchronizer.updateOpenedFiles()) {
          changeListSynchronizer.requestDeleteEmptyChangeLists();
          updatePerforceModules();
        }
      }
      finally {
        alarm.cancelRequest(this);
      }
    }
  }
}
