/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.perforce.perforce.connections;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.idea.perforce.perforce.ConnectionId;
import org.jetbrains.idea.perforce.perforce.PerforceSettings;

import java.io.File;

public class SingletonConnection extends AbstractP4Connection {

  private final static Key<SingletonConnection> KEY_IN_PROJECT = new Key<SingletonConnection>("Connection per project");
  public static final ConnectionId SINGLETON_CONNECTION_ID = new ConnectionId();

  private SingletonConnection() {
  }

  public static SingletonConnection getInstance(Project project){
    SingletonConnection result = project.getUserData(KEY_IN_PROJECT);
    if (result == null) {
      result = new SingletonConnection();
      project.putUserData(KEY_IN_PROJECT, result);
    }
    return result;
  }

  protected void initNativeConnection(final PerforceSettings settings) throws VcsException {
    if (!settings.useP4CONFIG) {
      myNativeConnection.setPort(settings.port);
      myNativeConnection.setClient(settings.client);
      myNativeConnection.setUser(settings.user);

      if (!settings.USE_LOGIN) {
        myNativeConnection.setPassword(settings.getPasswd());
      }
      else {
        myNativeConnection.setPassword(null);
      }

      if (!settings.isNoneCharset()) {
        myNativeConnection.setCharset(settings.CHARSET);
      }
      else {
        myNativeConnection.setCharset(null);
      }
    } else {
      myNativeConnection.setPort(null);
      myNativeConnection.setClient(null);
      myNativeConnection.setUser(null);
      myNativeConnection.setPassword(null);
      myNativeConnection.setCharset(null);

    }
    myNativeConnection.setWorkingDir(null);
  }

  public ConnectionId getId() {
    return SINGLETON_CONNECTION_ID;
  }

  public boolean handlesFile(VirtualFile file) {
    return true;
  }

  protected File getCwd() {
    return new File(".");
  }
}
