/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.zkm;

import com.intellij.openapi.util.text.StringUtil;
import gnu.trove.TIntIntHashMap;

public final class ClassInfo {
  private final String myOriginalName;
  private final String myScrambledName;
  private String mySourceFile;
  private final TIntIntHashMap myNumbersScrambledToOriginalMap = new TIntIntHashMap();

  public ClassInfo(String originalName, String scrambledName) {
    myOriginalName = cutQuotes(originalName).intern();
    myScrambledName = cutQuotes(scrambledName).intern();
  }

  public String getOriginalName() {
    return myOriginalName;
  }

  public String getScrambledName() {
    return myScrambledName;
  }

  private static String cutQuotes(String s) {
    if (StringUtil.startsWithChar(s, '\"') && StringUtil.endsWithChar(s, '\"')) {
      s = s.substring(1, s.length() - 1);
    }
    return s;
  }


  public void putLineNumbers(int original, int scrambled) {
    myNumbersScrambledToOriginalMap.put(scrambled, original);
  }

  public int unscrambleLineNumber(int scrambled) {
    if (!myNumbersScrambledToOriginalMap.containsKey(scrambled)) return -1;
    return myNumbersScrambledToOriginalMap.get(scrambled);
  }

  public String getSourceFile() {
    return mySourceFile;
  }

  public void setSourceFile(String sourceFile) {
    mySourceFile = sourceFile.intern();
  }

/*
  public String toString() {
    StringBuffer buffer = new StringBuffer(256);
    buffer.append("Class:");
    buffer.append(" OriginalName = ");
    buffer.append(myOriginalName);
    buffer.append(" ScrambledName = ");
    buffer.append(myScrambledName);
    buffer.append('\n');
    for (int i = 0; i < myMethods.size(); i++) {
      MethodInfo info = (MethodInfo)myMethods.elementAt(i);
      buffer.append('\t');
      buffer.append(info);
      buffer.append('\n');
    }
    buffer.append('\n');
    return buffer.toString();
  }
*/
}
