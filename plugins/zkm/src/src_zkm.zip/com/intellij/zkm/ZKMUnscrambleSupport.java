/**
 * @author cdr
 */
/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.zkm;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.unscramble.UnscrambleSupport;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.util.StringTokenizer;

public class ZKMUnscrambleSupport implements UnscrambleSupport {
  public String getPresentableName() {
    return ZKMBundle.message("zkm.scrambler.persentable.name");
  }

  @Nullable
  public String unscramble(Project project, String text, String logName) {
    ZKMLog log = null;
    try {
      log = ZKMLog.getLog(logName);
      log.setProject(project);
      return log.unscrambleStackTrace(mergeLines(text));
    }
    catch (IOException e) {
      Messages.showMessageDialog(project,
                                 e.getMessage()+"\n"+e.toString(),
                                 ZKMBundle.message("zkm.error.reading.log.file"),
                                 Messages.getErrorIcon());
    }
    finally {
      if (log != null) {
        log.setProject(null);
      }
    }
    return null;
  }

  private static String mergeLines(String text) {
    text = StringUtil.replace(text, "\r\n", "\n");
    text = StringUtil.replace(text, "\r", "\n");
    StringBuilder result = new StringBuilder();
    StringTokenizer tokenizer = new StringTokenizer(text, "\n");

    StringBuilder tempBuffer = new StringBuilder();
    while (tokenizer.hasMoreElements()) {
      String s = (String)tokenizer.nextElement();
      if (s.endsWith(ZKMLog.SPACE_AT) || s.endsWith(ZKMLog.TAB_AT)) {
        s += ' ';
      }
      s += "\n";

      if (tempBuffer.length() == 0 && !isStartOfStackLine(s)) {
        result.append(s);
      }
      else {
        tempBuffer.append(s);
        if (s.indexOf(')') != -1) {
          String line = tempBuffer.toString();
          tempBuffer.setLength(0);
          line = removeLineBreaks(line);
          result.append(line);
          result.append("\n");
        }
      }
    }
    return result.toString();
  }
  private static String removeLineBreaks(String lines) {
    StringBuilder buffer = new StringBuilder();
    StringTokenizer tokenizer = new StringTokenizer(lines, "\n");
    while (tokenizer.hasMoreElements()) {
      String s = (String)tokenizer.nextElement();
      if (buffer.length() > 0) {
        if (StringUtil.startsWithChar(s, '>')) {
          if (s.startsWith("> ")) {
            if (!s.startsWith("> " + ZKMLog.AT)) {
              s = s.substring(2);
            }
          }
          else {
            s = s.substring(1);
          }
        }
      }
      buffer.append(s);
    }
    return buffer.toString();
  }

  private static boolean isStartOfStackLine(String s) {
    return s.contains(ZKMLog.SPACE_AT) || s.contains(ZKMLog.TAB_AT) || s.startsWith(ZKMLog.AT_SPACE);
  }
}