/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.zkm;

import com.intellij.openapi.util.text.StringUtil;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public final class ZKMLogReader {

  private final ArrayList myClasses = new ArrayList();
  private ClassInfo myCurrentClassInfo;

  @SuppressWarnings({"HardCodedStringLiteral"})
  private final static String CLASS_PREFIX = "Class: ";

  @SuppressWarnings({"HardCodedStringLiteral"})
  private final static String SOURCE = "Source: ";

  @SuppressWarnings({"HardCodedStringLiteral"})
  private final static String NAME_NOT_CHANGED = "NameNotChanged";

  private void proceedString(String s) {
    s = s.trim();
    if (s.startsWith(CLASS_PREFIX)) {
      proceedClassLine(s);
    }
    else if (s.startsWith(SOURCE)) {
      proceedSourceLine(s);
    }
    else if (s.indexOf('(') != -1) {
//      proceedMethodLine(s);
    }
    else {
      proceedLinenumbersLine(s);
    }
  }

  private void proceedClassLine(String s) {
    flushCurrentClassInfo();
    s = s.substring(CLASS_PREFIX.length());


    String[] tokens = getTokens(s);
    final String originalName;
    final String scrambledName;
    if (NAME_NOT_CHANGED.equals(tokens[tokens.length - 1])) {
      originalName = cutModifiers(tokens[tokens.length - 2]);
      scrambledName = cutModifiers(tokens[tokens.length - 2]);
    }
    else {
      originalName = cutModifiers(tokens[tokens.length - 3]);
      scrambledName = cutModifiers(tokens[tokens.length - 1]);
    }
    myCurrentClassInfo = new ClassInfo(originalName, scrambledName);
  }

  private void proceedSourceLine(String s) {
    if (myCurrentClassInfo == null) return;
    s = s.substring(SOURCE.length());
    s = cutQuotes(s);
    myCurrentClassInfo.setSourceFile(s);
  }

  private static String cutQuotes(String s) {
    if (StringUtil.startsWithChar(s, '\"') && StringUtil.endsWithChar(s, '\"')) {
      s = s.substring(1, s.length() - 1);
    }
    return s;
  }

  private void proceedLinenumbersLine(String s) {
    if (myCurrentClassInfo == null) return;
    String[] tokens = getTokens(s);
    if (tokens.length != 3) return;
    if (!"=>".equals(tokens[1])) return;
    int originalLineNumber;
    try {
      originalLineNumber = Integer.parseInt(tokens[0]);
    }
    catch (NumberFormatException e) {
      return;
    }

    String scrambledNumbers = tokens[2];
    scrambledNumbers = StringUtil.replace(scrambledNumbers, " and ", ",");
    StringTokenizer tokenizer = new StringTokenizer(scrambledNumbers, ",");
    while (tokenizer.hasMoreElements()) {
      String numberString = (String)tokenizer.nextElement();
      try {
        myCurrentClassInfo.putLineNumbers(originalLineNumber, Integer.parseInt(numberString));
      }
      catch (NumberFormatException e) {
      }
    }
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  private String cutModifiers(String s) {
    s = stripPrefix(s, "public ");
    s = stripPrefix(s, "private ");
    s = stripPrefix(s, "protected ");
    s = stripPrefix(s, "static ");
    s = stripPrefix(s, "abstract ");
    s = stripPrefix(s, "final ");
    return s;
  }

  private static String stripPrefix(String s, String prefix) {
    if (s.startsWith(prefix)) {
      s = s.substring(prefix.length());
    }
    return s;
  }

  private void flushCurrentClassInfo() {
    if (myCurrentClassInfo != null) {
      myClasses.add(myCurrentClassInfo);
      myCurrentClassInfo = null;
    }
  }

  private static String[] getTokens(String s) {
    ArrayList tokens = new ArrayList();
    StringTokenizer tokeniger = new StringTokenizer(s, "\t");
    while (tokeniger.hasMoreElements()) {
      String token = (String)tokeniger.nextElement();
      tokens.add(token);
    }
    return (String[])tokens.toArray(new String[tokens.size()]);
  }

  public static ZKMLog readLog(String logFileName) throws IOException {
    ZKMLogReader reader = new ZKMLogReader();
    reader.readLogImpl(logFileName);
    ArrayList classes = reader.myClasses;
    ClassInfo[] infos = (ClassInfo[])classes.toArray(new ClassInfo[classes.size()]);
    return new ZKMLog(infos);
  }

  private void readLogImpl(String logFileName) throws IOException {
    File file = new File(logFileName);
    long length = file.length();
    char[] chars = new char[(int)length];
    FileReader reader = new FileReader(file);
    try{
      reader.read(chars);
      StringBuffer buffer = new StringBuffer(512);
      for (int i = 0; i < chars.length; i++) {
        char c = chars[i];
        if (c == '\n') {
          String s = buffer.toString();
          proceedString(s);
          buffer.setLength(0);
        }
        else if (c != '\r') {
          buffer.append(c);
        }
      }
    } finally{
      reader.close();
    }
    flushCurrentClassInfo();
  }
}
