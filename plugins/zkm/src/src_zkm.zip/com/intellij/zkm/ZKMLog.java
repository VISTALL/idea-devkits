/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.zkm;

import com.intellij.openapi.editor.Document;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.*;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.util.containers.SoftValueHashMap;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public final class ZKMLog {
  private final Map<String,ClassInfo> myScrambledNameToInfoMap = new HashMap<String, ClassInfo>();
  private final Map<String,ClassInfo> myOriginalNameToInfoMap = new HashMap<String, ClassInfo>();
  private Project myProject;
  private static final Map<String,ZKMLog> ourName2Log = new SoftValueHashMap<String, ZKMLog>();

  @SuppressWarnings({"HardCodedStringLiteral"})
  public static final String AT = "at ";

  @SuppressWarnings({"HardCodedStringLiteral"})
  public static final String TAB_AT = "\tat ";

  @SuppressWarnings({"HardCodedStringLiteral"})
  protected static final String SPACE_AT = " at";

  @SuppressWarnings({"HardCodedStringLiteral"})
  protected static final String AT_SPACE = "at ";

  @SuppressWarnings({"HardCodedStringLiteral"})
  private static final String XXX = "XXX";

  public ZKMLog(ClassInfo[] classes) {
    for (ClassInfo classInfo : classes) {
      myScrambledNameToInfoMap.put(classInfo.getScrambledName(), classInfo);
      myOriginalNameToInfoMap.put(classInfo.getOriginalName(), classInfo);
    }
  }

  public ClassInfo getClassInfoByOriginalName(String originalName) {
    if (originalName == null) {
      return null;
    }
    return myOriginalNameToInfoMap.get(originalName);
  }

  private void appendUnscrambledLine(StringBuffer buffer, String scrambledLine) {
    int atIndex = scrambledLine.indexOf(AT);
    if (atIndex == -1) {
      atIndex = scrambledLine.indexOf(TAB_AT);
    }
    if (atIndex == -1) {
      buffer.append(scrambledLine);
      return;
    }

    String prefix = scrambledLine.substring(0, atIndex + 3);
    String line = scrambledLine.substring(atIndex + 3).trim();

    int lineNumber = -1;

    int parIndex = line.indexOf('(');
    if (parIndex != -1) {
      try {
        String numberStr = line.substring(line.lastIndexOf(':') + 1, line.lastIndexOf(')'));
        line = line.substring(0, parIndex);
        lineNumber = Integer.parseInt(numberStr);
      }
      catch (Exception e) {
      }
    }

    int methodNameSeparatorIndex = line.lastIndexOf('.');
    if (methodNameSeparatorIndex == -1) {
      buffer.append(scrambledLine);
      return;
    }

    String scrambledClassName = line.substring(0, methodNameSeparatorIndex);
//    String scrambledMethodName = line.substring(methodNameSeparatorIndex + 1, line.length());

    ClassInfo classInfo = myScrambledNameToInfoMap.get(scrambledClassName);
    if (classInfo == null) {
      buffer.append(scrambledLine);
      return;
    }

    String originalName = classInfo.getOriginalName();
    int unscrambledLineNumber = classInfo.unscrambleLineNumber(lineNumber);
    String sourceFile = classInfo.getSourceFile();

    buffer.append(prefix);
    buffer.append(originalName);
    buffer.append('.');
    buffer.append(findMethodName(myProject, originalName, unscrambledLineNumber));
    buffer.append('(');
    buffer.append(sourceFile);
    if (unscrambledLineNumber > 0) {
      buffer.append(':');
      buffer.append(unscrambledLineNumber);
    }
    buffer.append(')');
  }

  public String unscrambleStackTrace(String stackTrace) {
    stackTrace = StringUtil.replace(stackTrace, "\r\n", "\n");
    StringTokenizer tokenizer = new StringTokenizer(stackTrace, "\n");
    StringBuffer buffer = new StringBuffer();
    while (tokenizer.hasMoreElements()) {
      String line = (String)tokenizer.nextElement();
      appendUnscrambledLine(buffer, line);
      buffer.append("\r\n");
    }
    return buffer.toString();
  }

  public void setProject(Project project) {
    myProject = project;
  }

  private static String findMethodName(Project project, final String className, final int lineNumber) {
    if (project == null) return XXX;

    final PsiManager psiManager = PsiManager.getInstance(project);
    int index = className.indexOf('$');
    PsiClass psiClass = psiManager.findClass(index != -1 ? className.substring(0, index) : className,
                                             GlobalSearchScope.allScope(project));
    if (psiClass == null) return XXX;

    PsiFile psiFile = psiClass.getContainingFile();
    if (psiFile == null) return XXX;

    Document editorDocument = PsiDocumentManager.getInstance(project).getDocument(psiFile);
    if (editorDocument == null) return XXX;

    int offset;
    try {
      offset = editorDocument.getLineStartOffset(lineNumber);
    }
    catch (Exception e) {
      return XXX;
    }

    PsiElement elementAt = psiFile.findElementAt(offset);
    if (elementAt != null) {
      PsiMethod method = PsiTreeUtil.getParentOfType(elementAt, PsiMethod.class);
      if (method != null) {
        return method.getName();
      }
    }

    return XXX;
  }

  public static ZKMLog getLog(String logName) throws IOException {
    if (logName == null) {
      return new ZKMLog(new ClassInfo[0]);
    }
    ZKMLog log = ourName2Log.get(logName);
    if (log == null) {
      log = ZKMLogReader.readLog(logName);
      ourName2Log.put(logName, log);
    }
    return log;
  }
}
