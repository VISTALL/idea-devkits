/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.references;

import com.intellij.psi.PsiReferenceBase;
import com.intellij.psi.PsiElement;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.xml.XmlAttributeValue;
import com.intellij.gwt.module.GwtModulesManager;
import com.intellij.gwt.module.model.GwtModule;
import com.intellij.openapi.module.Module;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.ArrayList;

/**
 * @author nik
 */
public class GwtModuleReference extends PsiReferenceBase<XmlAttributeValue> {
  private GwtModulesManager myGwtModulesManager;

  public GwtModuleReference(final XmlAttributeValue xmlAttributeValue) {
    super(xmlAttributeValue);
    myGwtModulesManager = GwtModulesManager.getInstance(xmlAttributeValue.getProject());
  }

  @Nullable
  public PsiElement resolve() {
    final String value = myElement.getValue();
    if (value != null) {
      final Module module = getModule();
      final GlobalSearchScope scope = module != null ? GlobalSearchScope.moduleWithDependenciesAndLibrariesScope(module) : GlobalSearchScope.allScope(myElement.getProject());
      final GwtModule gwtModule = myGwtModulesManager.findGwtModuleByName(value, scope);
      if (gwtModule != null) {
        return gwtModule.getXmlTag();
      }
    }
    return null;
  }

  public Object[] getVariants() {
    List<String> names = new ArrayList<String>();
    for (GwtModule module : myGwtModulesManager.getGwtModules()) {
      names.add(module.getQualifiedName());
    }
    return names.toArray(new String[names.size()]);
  }

}
