/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.actions;

import com.intellij.gwt.GwtBundle;
import com.intellij.gwt.module.GwtModulesManager;
import com.intellij.gwt.module.model.GwtModule;
import com.intellij.gwt.templates.GwtTemplates;
import com.intellij.ide.fileTemplates.FileTemplate;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.PsiDirectory;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiPackage;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class CreateGwtSampleAppAction extends GwtCreateActionBase {
  private static final Logger LOG = Logger.getInstance("#com.intellij.gwt.actions.CreateGwtSampleAppAction");
  @NonNls private static final String SERVICE_SUFFIX = "Service";
  @NonNls private static final String SERVICE_ASYNC_SUFFIX = "ServiceAsync";
  @NonNls private static final String SERVICE_IMPL_SUFFIX = "ServiceImpl";
  @NonNls private static final String SERVICE_NAME_PROPERTY = "SERVICE_NAME";
  @NonNls private static final String CLIENT_PACKAGE_PROPERTY = "CLIENT_PACKAGE";
  @NonNls private static final String RELATIVE_PATH_PROPERTY = "RELATIVE_SERVLET_PATH";

  public CreateGwtSampleAppAction() {
    super(GwtBundle.message("newapp.menu.action.text"), GwtBundle.message("newapp.menu.action.description"));
  }

  protected boolean requireGwtModule() {
    return false;
  }

  protected String getDialogPrompt() {
    return GwtBundle.message("newapp.dlg.prompt");
  }

  protected String getDialogTitle() {
    return GwtBundle.message("newapp.dlg.title");
  }

  protected void doCheckBeforeCreate(String name, PsiDirectory directory) throws IncorrectOperationException {
    directory.checkCreateSubdirectory(name);
  }

  @NotNull
  protected PsiElement[] doCreate(String name, PsiDirectory directory, final GwtModule gwtModule) throws Exception {
    name = StringUtil.capitalize(name);
    final ArrayList<PsiElement> result = new ArrayList<PsiElement>(0);

    PsiDirectory moduleDir = directory.createSubdirectory(StringUtil.decapitalize(name));
    result.add(moduleDir);
    final PsiPackage psiPackage = moduleDir.getPackage();
    if (psiPackage == null) return PsiElement.EMPTY_ARRAY;
    String appPackageName = psiPackage.getQualifiedName();
    result.add(createFromTemplateInternal(moduleDir, name, name + GwtModulesManager.GWT_XML_SUFFIX, GwtTemplates.GWT_SAMPLE_APP_GWT_XML));

    PsiDirectory clientDir = moduleDir.createSubdirectory(GwtModulesManager.DEFAULT_SOURCE_PATH);
    result.add(clientDir);
    String serviceName = name + SERVICE_SUFFIX;
    result.add(createClassFromTemplate(clientDir, serviceName, GwtTemplates.GWT_SAMPLE_APP_SERVICE_JAVA,
                                       RELATIVE_PATH_PROPERTY, appPackageName + "." + name + "/" + serviceName));
    result.add(createClassFromTemplate(clientDir, name + SERVICE_ASYNC_SUFFIX, GwtTemplates.GWT_SAMPLE_APP_SERVICE_ASYNC_JAVA));
    result.add(createClassFromTemplate(clientDir, name, GwtTemplates.GWT_SAMPLE_ENTRY_POINT_JAVA));

    PsiDirectory serverDir = moduleDir.createSubdirectory("server");
    result.add(serverDir);
    final PsiPackage aPackage = clientDir.getPackage();
    LOG.assertTrue(aPackage != null);
    result.add(createFromTemplate(serverDir, name + SERVICE_IMPL_SUFFIX + "." + StdFileTypes.JAVA.getDefaultExtension(),
                                  GwtTemplates.GWT_SAMPLE_APP_SERVICE_IMPL_JAVA,
                                  SERVICE_NAME_PROPERTY, serviceName,
                                  CLIENT_PACKAGE_PROPERTY, aPackage.getQualifiedName()));

    PsiDirectory publicDir = moduleDir.createSubdirectory(GwtModulesManager.DEFAULT_PUBLIC_PATH);
    result.add(publicDir);
    result.add(createFromTemplate(publicDir, name + "." + StdFileTypes.HTML.getDefaultExtension(), GwtTemplates.GWT_SAMPLE_APP_HTML,
                                  FileTemplate.ATTRIBUTE_PACKAGE_NAME, appPackageName));

    return result.toArray(new PsiElement[result.size()]);
  }

  protected String getCommandName() {
    return GwtBundle.message("newapp.command.name");
  }

  protected String getActionName(PsiDirectory directory, String newName) {
    return GwtBundle.message("newapp.progress.text", newName);
  }
}
