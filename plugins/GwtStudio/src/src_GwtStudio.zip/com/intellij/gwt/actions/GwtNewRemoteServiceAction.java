/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.actions;

import com.intellij.gwt.GwtBundle;
import com.intellij.gwt.GwtConfiguration;
import com.intellij.gwt.inspections.RemoteServiceUtil;
import com.intellij.gwt.module.model.GwtModule;
import com.intellij.gwt.module.model.GwtServlet;
import com.intellij.gwt.templates.GwtTemplatesFactory;
import com.intellij.javaee.model.xml.web.WebApp;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.javaee.web.WebUtil;
import com.intellij.openapi.vfs.VfsUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiDirectory;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.xml.XmlFile;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class GwtNewRemoteServiceAction extends GwtNewActionBase {
  @NonNls private static final String QUALIFIED_SERVICE_NAME_PROPERTY = "QUALIFIED_SERVICE_NAME";
  @NonNls private static final String SERVICE_NAME_PROPERTY = "SERVICE_NAME";
  @NonNls private static final String SERVLET_PATH_PROPERTY = "SERVLET_PATH";
  @NonNls private static final String RELATIVE_PATH_PROPERTY = "RELATIVE_SERVLET_PATH";

  public GwtNewRemoteServiceAction() {
    super(GwtBundle.message("newservice.menu.action.text"), GwtBundle.message("newservice.menu.action.description"), null);
  }

  protected boolean requireGwtModule() {
    return true;
  }

  protected String getDialogPrompt() {
    return GwtBundle.message("newservice.dlg.prompt");
  }

  protected String getDialogTitle() {
    return GwtBundle.message("newservice.dlg.title");
  }


  protected PsiFile[] getAffectedFiles(final GwtModule gwtModule) {
    final XmlFile xmlFile = gwtModule.getModuleXmlFile();
    if (xmlFile != null) {
      final WebModuleProperties properties = WebUtil.getWebModuleProperties(xmlFile);
      if (properties != null) {
        final WebApp webApp = properties.getRoot();
        if (webApp != null) {
          return new PsiFile[]{xmlFile, webApp.getRoot().getFile()};
        }
      }
    }
    return new PsiFile[] {xmlFile};
  }

  @NotNull
  protected PsiElement[] doCreate(String serviceName, PsiDirectory directory, final GwtModule gwtModule) throws Exception {
    ArrayList<PsiElement> res = new ArrayList<PsiElement>(0);

    final String servletPath = RemoteServiceUtil.getServletPath(gwtModule, serviceName);
    final String templateName = GwtConfiguration.getInstance().isVersion1_0() ? GwtTemplatesFactory.GWT_SERVICE_JAVA_1_0 : GwtTemplatesFactory.GWT_SERVICE_JAVA;
    final PsiClass serviceClass = createClassFromTemplate(directory, serviceName, templateName,
                                                          SERVLET_PATH_PROPERTY, servletPath,
                                                          RELATIVE_PATH_PROPERTY, servletPath.substring(1));
    res.add(serviceClass);
    res.add(createClassFromTemplate(directory, serviceName + RemoteServiceUtil.ASYNC_SUFFIX, GwtTemplatesFactory.GWT_SERVICE_ASYNC_JAVA));


    final VirtualFile gwtModuleDir = gwtModule.getModuleDirectory();

    PsiClass servletImpl = generateServletClass(serviceName, directory, gwtModuleDir, serviceClass);

    XmlFile xml = gwtModule.getModuleXmlFile();
    if (xml == null) return PsiElement.EMPTY_ARRAY;

    final GwtServlet gwtServlet = gwtModule.addServlet();
    gwtServlet.getPath().setValue(servletPath);
    gwtServlet.getServletClass().setValue(servletImpl.getQualifiedName());

    final WebModuleProperties properties = WebUtil.getWebModuleProperties(xml);
    if (properties != null) {
      final WebApp webApp = properties.getRoot();
      if (webApp != null) {
        RemoteServiceUtil.registerServletForService(gwtModule, webApp, servletImpl, serviceName);
      }
    }

    return res.toArray(new PsiElement[res.size()]);
  }

  protected String getCommandName() {
    return GwtBundle.message("newservice.command.name");
  }

  protected String getActionName(PsiDirectory directory, String newName) {
    return GwtBundle.message("newservice.progress.text", newName);
  }

  private static PsiClass generateServletClass(String name,
                                                  PsiDirectory directory,
                                                  VirtualFile gwtModuleDir,
                                                  final PsiClass serviceClass) throws IncorrectOperationException {

    final VirtualFile client = gwtModuleDir.findChild("client");

    String pathFromClient = VfsUtil.getRelativePath(directory.getVirtualFile(), client, '/');

    PsiDirectory serverDest = directory.getManager().findDirectory(gwtModuleDir);
    if (serverDest == null) return null;

    final StringTokenizer tokenizer = new StringTokenizer("server/" + pathFromClient, "/");
    while (tokenizer.hasMoreTokens()) {
      final String dirName = tokenizer.nextToken();
      PsiDirectory nextDir = serverDest.findSubdirectory(dirName);
      if (nextDir == null) {
        nextDir = serverDest.createSubdirectory(dirName);
      }
      serverDest = nextDir;
    }

    return createClassFromTemplate(serverDest, name + RemoteServiceUtil.IMPL_SERVICE_SUFFIX, GwtTemplatesFactory.GWT_SERVICE_IMPL_JAVA,
                                   SERVICE_NAME_PROPERTY, serviceClass.getName(),
                                   QUALIFIED_SERVICE_NAME_PROPERTY, serviceClass.getQualifiedName());
  }
}