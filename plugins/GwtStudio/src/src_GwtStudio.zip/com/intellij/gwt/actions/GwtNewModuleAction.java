/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.actions;

import com.intellij.gwt.GwtBundle;
import com.intellij.gwt.module.GwtModulesManager;
import com.intellij.gwt.module.model.GwtModule;
import com.intellij.gwt.templates.GwtTemplatesFactory;
import com.intellij.psi.PsiDirectory;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiPackage;
import com.intellij.psi.PsiClass;
import com.intellij.util.IncorrectOperationException;
import com.intellij.ide.fileTemplates.FileTemplate;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class GwtNewModuleAction extends GwtNewActionBase {
  public GwtNewModuleAction() {
    super(GwtBundle.message("newmodule.menu.action.text"), GwtBundle.message("newmodule.menu.action.description"), null);
  }

  protected boolean requireGwtModule() {
    return false;
  }

  protected boolean requireGwtSupport() {
    return false;
  }

  protected String getDialogPrompt() {
    return GwtBundle.message("newmodule.dlg.prompt");
  }

  protected String getDialogTitle() {
    return GwtBundle.message("newmodule.dlg.title");
  }

  protected void doCheckBeforeCreate(final PsiDirectory directory, final String name) throws IncorrectOperationException {
    directory.checkCreateSubdirectory(name);
  }

  /**
   * @return created elements. Never null.
   */
  @NotNull
  protected PsiElement[] doCreate(String name, PsiDirectory directory, final GwtModule gwtModule) throws Exception {
    name = StringUtil.capitalize(name);
    final ArrayList<PsiElement> res = new ArrayList<PsiElement>(0);

    final PsiPackage psiPackage = directory.getPackage();
    if (psiPackage == null) return PsiElement.EMPTY_ARRAY;


    PsiDirectory client = directory.createSubdirectory(GwtModulesManager.DEFAULT_SOURCE_PATH);
    res.add(client);
    final PsiClass entryPointClass = createClassFromTemplate(client, name, GwtTemplatesFactory.GWT_ENTRY_POINT_JAVA);
    res.add(entryPointClass);

    String appPackageName = psiPackage.getQualifiedName();
    res.add(createFromTemplateInternal(directory, name, name + GwtModulesManager.GWT_XML_SUFFIX, GwtTemplatesFactory.GWT_MODULE_GWT_XML,
                                       "ENTRY_POINT_CLASS", entryPointClass.getQualifiedName()));

    PsiDirectory server = directory.createSubdirectory("server");
    res.add(server);

    PsiDirectory publicDir = directory.createSubdirectory(GwtModulesManager.DEFAULT_PUBLIC_PATH);
    res.add(publicDir);
    final String gwtModuleName = appPackageName.length() > 0 ? appPackageName + "." + name : name;
    res.add(createFromTemplate(publicDir, name + ".html", GwtTemplatesFactory.GWT_MODULE_HTML,
                               FileTemplate.ATTRIBUTE_PACKAGE_NAME, appPackageName,
                               "GWT_MODULE_NAME", gwtModuleName));
    res.add(createFromTemplate(publicDir, name + ".css", GwtTemplatesFactory.GWT_MODULE_CSS, FileTemplate.ATTRIBUTE_PACKAGE_NAME,
                               appPackageName));

    return res.toArray(new PsiElement[res.size()]);
  }

  protected String getCommandName() {
    return GwtBundle.message("newmodule.command.name");
  }

  protected String getActionName(PsiDirectory directory, String newName) {
    return GwtBundle.message("newmodule.progress.text", newName);
  }
}
