/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.i18n;

import com.intellij.lang.properties.psi.Property;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.pom.Navigatable;
import com.intellij.pom.java.LanguageLevel;
import com.intellij.psi.*;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.util.PsiUtil;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.text.MessageFormat;

/**
 * @author nik
 */
public class GwtI18nUtil {
  private static final Logger LOG = Logger.getInstance("#com.intellij.gwt.i18n.GwtI18nUtil");
  public static final Icon IMPLEMENTED_PROPERTY_METHOD_ICON = IconLoader.getIcon("/gutter/implementedMethod.png");
  @NonNls public static final String CONSTANTS_INTERFACE_NAME = "com.google.gwt.i18n.client.Constants"; 
  @NonNls public static final String MESSAGES_INTERFACE_NAME = "com.google.gwt.i18n.client.Messages";
  @NonNls private static final String PROPERTY_METHOD_PREFIX = "getProperty";
  @NonNls public static final String GWT_PROPERTY_KEY_JAVADOC = "/**\n*@gwt.key {0}\n*/";

  private GwtI18nUtil() {
  }

  public static void navigateToProperty(@NotNull Property property) {
    ((Navigatable)property).navigate(true);
  }

  public static String convertPropertyName2MethodName(String propertyName, final PsiNameHelper nameHelper, final LanguageLevel languageLevel) {
    if (nameHelper.isIdentifier(propertyName, languageLevel)) {
      return propertyName;
    }

    final String[] words = propertyName.split("\\.");
    StringBuilder builder = new StringBuilder();
    for (String word : words) {
      String id = convert2Id(word);
      if (id.length() > 0) {
        if (builder.length() > 0) {
          id = StringUtil.capitalize(id);
        }
        builder.append(id);
      }
    }

    String id = builder.toString();
    if (!nameHelper.isIdentifier(id, languageLevel)) {
      id = PROPERTY_METHOD_PREFIX + StringUtil.capitalize(id);
      if (!nameHelper.isIdentifier(id, languageLevel)) {
        id = PROPERTY_METHOD_PREFIX;
      }
    }
    return id;
  }

  private static String convert2Id(final String word) {
    final StringBuilder builder = new StringBuilder();
    for (int i = 0; i < word.length(); i++) {
      char c = word.charAt(i);
      if (builder.length() == 0 && Character.isJavaIdentifierStart(c)
          || builder.length() > 0 && Character.isJavaIdentifierPart(c)) {
        builder.append(c);
      }
    }
    return builder.toString();
  }

  public static void addMethod(PsiClass aClass, String propertyName, @Nullable String propertyValue) {
    try {
      PsiMethod method = addMethod(aClass, propertyName);
      PsiElementFactory psiElementFactory = method.getManager().getElementFactory();
      int parametersCount = getParametersCount(propertyValue);
      PsiClassType javaLangString = PsiType.getJavaLangString(method.getManager(), GlobalSearchScope.allScope(method.getProject()));
      for (int i = 0; i < parametersCount; i++) {
        method.getParameterList().add(psiElementFactory.createParameter("p" + i, javaLangString));
      }
    }
    catch (IncorrectOperationException e) {
      LOG.error(e);
    }
  }

  private static int getParametersCount(final @Nullable String propertyValue) {
    if (propertyValue == null) return 0;

    int maxParameter = -1;
    int i = propertyValue.indexOf('{');
    while (i != -1) {
      int end = propertyValue.indexOf('}', i);
      if (end == -1) break;

      int comma = propertyValue.indexOf(',', i);
      if (comma != -1 && comma < end) {
        end = comma;
      }

      try {
        int parameter = Integer.parseInt(propertyValue.substring(i+1, end));
        maxParameter = Math.max(maxParameter, parameter);
      }
      catch (NumberFormatException e) {
      }
      i = propertyValue.indexOf('{', end);
    }
    return maxParameter + 1;
  }

  public static PsiMethod addMethod(PsiClass aClass, String propertyName) throws IncorrectOperationException {
    final PsiManager psiManager = aClass.getManager();
    String methodName = convertPropertyName2MethodName(propertyName, psiManager.getNameHelper(), PsiUtil.getLanguageLevel(aClass));

    final PsiClassType javaLangString = PsiType.getJavaLangString(psiManager, aClass.getResolveScope());
    final PsiMethod method = psiManager.getElementFactory().createMethod(methodName, javaLangString);
    method.getModifierList().setModifierProperty(PsiModifier.PUBLIC, false);
    final PsiCodeBlock body = method.getBody();
    LOG.assertTrue(body != null);
    body.delete();
    final PsiElement addedMethod = aClass.add(method);

    if (!propertyName.equals(methodName)) {
      final String commentText = MessageFormat.format(GWT_PROPERTY_KEY_JAVADOC, propertyName);
      PsiComment comment = psiManager.getElementFactory().createCommentFromText(commentText, aClass);
      addedMethod.addBefore(comment, addedMethod.getFirstChild());
    }
    return (PsiMethod)addedMethod;
  }
}
