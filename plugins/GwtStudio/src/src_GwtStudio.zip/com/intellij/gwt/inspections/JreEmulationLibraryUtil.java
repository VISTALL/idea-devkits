/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.inspections;

import org.jetbrains.annotations.NonNls;

import java.util.Set;
import java.util.HashSet;

/**
 * @author nik
 */
//todo[nik] extract emulation library classes from gwt-user.jar
public class JreEmulationLibraryUtil {
  @NonNls private static final Set<String> LIBRARY_CLASSES = new HashSet<String>();
  @NonNls private static final String[] JAVA_LANG_CLASSES = {
    "ArrayStoreException", "AssertionError", "Boolean", "Byte", "Character",
    "Class", "ClassCastException", "Double", "Error", "Exception", "Float",
    "IllegalArgumentException", "IllegalStateException",
    "IndexOutOfBoundsException", "Integer", "Long", "Math", "NegativeArraySizeException",
    "NullPointerException", "Number", "NumberFormatException", "Object", "RuntimeException",
    "Short", "String", "StringBuffer", "StringIndexOutOfBoundsException", "System",
    "Throwable", "UnsupportedOperationException",

    "CharSequence", "Cloneable", "Comparable"
  };

  @NonNls private static final String[] JAVA_UTIL_CLASSES = {
    "AbstractCollection", "AbstractList", "AbstractMap", "AbstractSet",
    "ArrayList", "Arrays", "Collections", "Date", "EmptyStackException", "HashMap",
    "HashSet", "NoSuchElementException", "Stack", "TooManyListenersException", "Vector",

    "Collection", "Comparator", "EventListener", "Iterator",
    "List", "Map", "RandomAccess", "Set"
  };


  static {
    addClasses("java.lang", JAVA_LANG_CLASSES);
    addClasses("java.util", JAVA_UTIL_CLASSES);
  }

  private static void addClasses(@NonNls final String packageName, final String... classNames) {
    for (String className : classNames) {
      LIBRARY_CLASSES.add(packageName + "." + className);
    }
  }

  public static boolean libraryContains(final String className) {
    return LIBRARY_CLASSES.contains(className);
  }
}
