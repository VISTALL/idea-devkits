/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.inspections;

import com.intellij.codeInspection.InspectionManager;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.codeInspection.ProblemHighlightType;
import com.intellij.gwt.GwtBundle;
import com.intellij.gwt.i18n.GwtI18nManager;
import com.intellij.gwt.i18n.GwtI18nUtil;
import com.intellij.lang.properties.psi.PropertiesFile;
import com.intellij.psi.*;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.ArrayList;

/**
 * @author nik
 */
public class GwtMethodWithParametersInConstantsInterfaceInspection extends BaseGwtInspection {
  private static final Logger LOG = Logger.getInstance("#com.intellij.gwt.inspections.GwtMethodWithParametersInConstantsInterfaceInspection");

  @Nls @NotNull
  public String getDisplayName() {
    return GwtBundle.message("inspection.name.method.with.parameters.in.interface.extending.constants");
  }

  @NonNls @NotNull
  public String getShortName() {
    return "GwtMethodWithParametersInConstantsInterface";
  }

  @Nullable
  public ProblemDescriptor[] checkClass(@NotNull final PsiClass aClass, @NotNull final InspectionManager manager, final boolean isOnTheFly) {
    if (!shouldCheck(aClass)) return null;

    GwtI18nManager i18nManager = GwtI18nManager.getInstance(manager.getProject());
    PropertiesFile[] files = i18nManager.getPropertiesFiles(aClass);
    if (files.length == 0 || !i18nManager.isConstantsInterface(aClass)) return null;

    PsiJavaCodeReferenceElement extendsConstantsElement = null;
    PsiReferenceList list = aClass.getExtendsList();
    if (list != null) {
      for (PsiJavaCodeReferenceElement element : list.getReferenceElements()) {
        PsiElement anInterface = element.resolve();
        if (anInterface instanceof PsiClass &&
            GwtI18nUtil.CONSTANTS_INTERFACE_NAME.equals(((PsiClass)anInterface).getQualifiedName())) {
          extendsConstantsElement = element;
          break;
        }
      }
    }

    List<ProblemDescriptor> problems = new ArrayList<ProblemDescriptor>();
    for (PsiMethod psiMethod : aClass.getMethods()) {
      if (psiMethod.getParameterList().getParametersCount() > 0) {
        ReplaceConstantsByMessagesInExtendsListQuickFix quickFix = null;
        if (extendsConstantsElement != null) {
          quickFix = new ReplaceConstantsByMessagesInExtendsListQuickFix(aClass, extendsConstantsElement);
        }

        problems.add(manager.createProblemDescriptor(getElementToHighlight(psiMethod), GwtBundle.message(
          "problem.description.methods.with.parameters.are.not.allowed.in.an.interface.extending.constants"), quickFix, ProblemHighlightType.GENERIC_ERROR_OR_WARNING));
      }
    }

    return problems.toArray(new ProblemDescriptor[problems.size()]);
  }

  private static class ReplaceConstantsByMessagesInExtendsListQuickFix implements LocalQuickFix {
    private PsiClass myInterface;
    private final PsiJavaCodeReferenceElement myExtendsConstantsElement;

    private ReplaceConstantsByMessagesInExtendsListQuickFix(final PsiClass anInterface,
                                                            final PsiJavaCodeReferenceElement extendsConstantsElement) {
      myInterface = anInterface;
      myExtendsConstantsElement = extendsConstantsElement;
    }

    @NotNull
    public String getName() {
      return GwtBundle.message("quickfix.name.inherit.0.from.messages.instead.of.constants", myInterface.getName());
    }

    @NotNull
    public String getFamilyName() {
      return GwtInspectionsProvider.GWT_QUICKFIXES_FAMILY;
    }

    public void applyFix(@NotNull final Project project, @NotNull final ProblemDescriptor descriptor) {
      try {
        myExtendsConstantsElement.delete();
        PsiElementFactory factory = myInterface.getManager().getElementFactory();
        PsiClassType messagesType = factory.createTypeByFQClassName(GwtI18nUtil.MESSAGES_INTERFACE_NAME, myInterface.getResolveScope());
        PsiReferenceList extendsList = myInterface.getExtendsList();
        LOG.assertTrue(extendsList != null);
        extendsList.add(factory.createReferenceElementByType(messagesType));
      }
      catch (IncorrectOperationException e) {
        LOG.error(e);
      }
    }
  }
}
