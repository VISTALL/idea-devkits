/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.inspections;

import org.jetbrains.annotations.NonNls;
import com.intellij.psi.PsiClassType;
import com.intellij.psi.PsiType;
import com.intellij.psi.PsiArrayType;

import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

/**
 * @author nik
 */
public class GwtSerializableUtil {
  @NonNls private static Set<String> STANDARD_SERIALIZABLE_CLASSES = new HashSet<String>(Arrays.asList(
    "java.util.Date", "java.lang.Boolean", "java.lang.Byte", "java.lang.Character", "java.lang.Double",
    "java.lang.Float", "java.lang.Integer", "java.lang.Long", "java.lang.Short", "java.lang.String"
  ));
  @NonNls private static Set<String> COLLECTION_CLASSES = new HashSet<String>(Arrays.asList(
    "java.util.Vector", "java.util.Stack", "java.util.List", "java.util.ArrayList", "java.util.Map",
    "java.util.Map", "java.util.Set", "java.util.HashMap", "java.util.HashSet"
  ));

  private GwtSerializableUtil() {
  }

  public static boolean isSerializable(PsiClassType isSerialType, PsiType type) {
    if (type instanceof PsiArrayType) return isSerializable(isSerialType, ((PsiArrayType)type).getComponentType());

    if (isSerialType.isAssignableFrom(type)) return true;

    return STANDARD_SERIALIZABLE_CLASSES.contains(type.getCanonicalText());
  }

  public static boolean isCollection(PsiType type) {
    return COLLECTION_CLASSES.contains(type.getCanonicalText());
  }
}
