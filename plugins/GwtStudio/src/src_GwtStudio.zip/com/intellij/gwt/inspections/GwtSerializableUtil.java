/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.inspections;

import com.intellij.gwt.GwtBundle;
import com.intellij.gwt.facet.GwtFacet;
import com.intellij.gwt.sdk.GwtVersion;
import com.intellij.psi.*;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.*;

/**
 * @author nik
 */
public class GwtSerializableUtil {
  @NonNls private static Set<String> STANDARD_SERIALIZABLE_CLASSES = new HashSet<String>(Arrays.asList(
    "java.util.Date", "java.lang.Boolean", "java.lang.Byte", "java.lang.Character", "java.lang.Double",
    "java.lang.Float", "java.lang.Integer", "java.lang.Long", "java.lang.Short", "java.lang.String"
  ));
  @NonNls private static Set<String> COLLECTION_CLASSES = new HashSet<String>(Arrays.asList(
    "java.util.Vector", "java.util.Stack", "java.util.List", "java.util.ArrayList", "java.util.Map",
    "java.util.Map", "java.util.Set", "java.util.HashMap", "java.util.HashSet"
  ));
  @NonNls public static final String IS_SERIALIZABLE_INTERFACE_NAME = "com.google.gwt.user.client.rpc.IsSerializable";

  private GwtSerializableUtil() {
  }

  public static SerializableChecker createSerializableChecker(GwtFacet facet) {
    GlobalSearchScope scope = GlobalSearchScope.moduleWithDependenciesAndLibrariesScope(facet.getModule());
    PsiManager psiManager = PsiManager.getInstance(facet.getModule().getProject());
    return new SerializableChecker(facet.getSdkVersion(), scope, psiManager);
  }

  public static boolean isCollection(PsiType type) {
    return COLLECTION_CLASSES.contains(type.getCanonicalText());
  }

  public static boolean hasPublicNoArgConstructor(final PsiClass aClass) {
    final PsiMethod[] constructors = aClass.getConstructors();
    if (constructors.length == 0) {
      return true;
    }

    for (PsiMethod constructor : constructors) {
      if (constructor.hasModifierProperty(PsiModifier.PUBLIC) && constructor.getParameterList().getParametersCount() == 0) {
        return true;
      }
    }

    return false;
  }

  public static class SerializableChecker {
    private List<PsiClassType> mySerializableMarkerTypes;
    private List<PsiClass> mySerializableMarkerInterfaces;
    private final PsiManager myPsiManager;
    private PsiClass myIsSerializableInterface;

    private SerializableChecker(GwtVersion version, GlobalSearchScope scope, PsiManager psiManager) {
      myPsiManager = psiManager;
      myIsSerializableInterface = psiManager.findClass(IS_SERIALIZABLE_INTERFACE_NAME, scope);
      PsiClass class2 = null;
      if (version == GwtVersion.VERSION_1_4_OR_LATER) {
        class2 = psiManager.findClass(Serializable.class.getName(), scope);
      }
      mySerializableMarkerInterfaces = ContainerUtil.packNullables(myIsSerializableInterface, class2);
      mySerializableMarkerTypes = new ArrayList<PsiClassType>();
      for (PsiClass anInterface : mySerializableMarkerInterfaces) {
        mySerializableMarkerTypes.add(psiManager.getElementFactory().createType(anInterface));
      }
    }

    public List<PsiClass> getSerializableMarkerInterfaces() {
      return mySerializableMarkerInterfaces;
    }

    public boolean isSerializable(PsiType type) {
      if (type instanceof PsiPrimitiveType) {
        return true;
      }

      if (type instanceof PsiArrayType) {
        return isSerializable(((PsiArrayType)type).getComponentType());
      }

      if (isCollection(type) || STANDARD_SERIALIZABLE_CLASSES.contains(type.getCanonicalText())) {
        return true;
      }

      for (PsiClassType psiClassType : mySerializableMarkerTypes) {
        if (psiClassType.isAssignableFrom(type)) {
          return true;
        }
      }
      return false;
    }

    public boolean isGwtSerializable(@NotNull PsiClass psiClass) {
      return myIsSerializableInterface != null && psiClass.isInheritor(myIsSerializableInterface, true);
    }

    public boolean isMarkedSerializable(final @NotNull PsiClass psiClass) {
      for (PsiClass markerInterface : mySerializableMarkerInterfaces) {
        if (psiClass.isInheritor(markerInterface, true)) {
          return true;
        }
      }
      return false;
    }

    public boolean isSerializable(final PsiClass aClass) {
      return isSerializable(myPsiManager.getElementFactory().createType(aClass));
    }

    public String getPresentableSerializableClassesString() {
      if (mySerializableMarkerInterfaces.isEmpty()) return "";

      String name1 = mySerializableMarkerInterfaces.get(0).getQualifiedName();
      if (mySerializableMarkerInterfaces.size() == 1) {
        return "'" + name1 + "'";
      }
      String name2 = mySerializableMarkerInterfaces.get(1).getQualifiedName();
      return GwtBundle.message("text.0.or.1", name1, name2);
    }
  }
}
