/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.inspections;

import com.intellij.codeInsight.intention.IntentionManager;
import com.intellij.codeInsight.intention.QuickFixFactory;
import com.intellij.codeInspection.InspectionManager;
import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.codeInspection.ProblemHighlightType;
import com.intellij.gwt.GwtBundle;
import com.intellij.gwt.facet.GwtFacet;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.*;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * @author nik
 */
public class GwtNonSerializableRemoteServiceMethodParametersInspection extends BaseGwtInspection {

  @Nullable
  public ProblemDescriptor[] checkClass(@NotNull PsiClass aClass, @NotNull InspectionManager manager, boolean isOnTheFly) {
    GwtFacet gwtFacet = getFacet(aClass);
    if (gwtFacet == null) return null;

    if (RemoteServiceUtil.isRemoteServiceInterface(aClass)) {
      return checkRemoteService(gwtFacet, aClass, manager);
    }
    return null;
  }

  private static ProblemDescriptor[] checkRemoteService(final GwtFacet gwtFacet, final PsiClass aClass, final InspectionManager manager) {
    ArrayList<ProblemDescriptor> result = new ArrayList<ProblemDescriptor>(0);

    GwtSerializableUtil.SerializableChecker serializableChecker = GwtSerializableUtil.createSerializableChecker(gwtFacet);

    for (final PsiMethod method : aClass.getMethods()) {
      for (final PsiParameter param : method.getParameterList().getParameters()) {
        checkTypeSerial(param.getTypeElement(), serializableChecker, manager, result);

/*
      if ( isCollection( param.getTypeElement().getType() ) )
      {
        PsiDocComment doc = method.getDocComment();
        if ( doc == null )
          com.intellij.gwt.res.add( manager.createProblemDescriptor(
                  param,
                  "No GWT-required javadoc tag @gwt-typeArgs",
                  new ParamTypeQuickFix(param, psiManager, isSerialType, method),
                  ProblemHighlightType.GENERIC_ERROR_OR_WARNING));
        else
          for ( PsiDocTag tag : doc.getTags() )
            if ( tag.getName().equals("gwt-typeArgs"))
              continue;
      }
*/
      }
      final PsiTypeElement returnTypeElement = method.getReturnTypeElement();
      if (returnTypeElement != null) {
        checkTypeSerial(returnTypeElement, serializableChecker, manager, result);
      }
    }

    return result.toArray(new ProblemDescriptor[result.size()]);
  }

  private static void checkTypeSerial(PsiTypeElement typeElement,
                                      final GwtSerializableUtil.SerializableChecker serializableChecker,
                                      InspectionManager manager,
                                      ArrayList<ProblemDescriptor> res) {
    PsiType type = typeElement.getType();
    if (!type.isValid()) return;

    if (!serializableChecker.isSerializable(type)) {
      while (type instanceof PsiArrayType) {
        type = ((PsiArrayType)type).getComponentType();
      }

      if (type instanceof PsiClassType) {
        PsiClass aClass = ((PsiClassType)type).resolve();
        if (aClass != null) {
          final LocalQuickFix[] quickFixes;
          if (!isInSources(aClass)) {
            quickFixes = LocalQuickFix.EMPTY_ARRAY;
          }
          else {
            final List<PsiClass> list = serializableChecker.getSerializableMarkerInterfaces();
            final PsiElementFactory psiFactory = aClass.getManager().getElementFactory();
            quickFixes = new LocalQuickFix[list.size()];
            for (int i = 0; i < list.size(); i++) {
              quickFixes[i] = IntentionManager.getInstance().convertToFix(QuickFixFactory.getInstance()
                .createExtendsListFix(aClass, psiFactory.createType(list.get(i)), true));
            }
          }
          final String description = GwtBundle.message("problem.description.gwt.serializable.type.0.should.implements.marker.interface.1", type.getCanonicalText(), serializableChecker.getPresentableSerializableClassesString());
          res.add(manager.createProblemDescriptor(typeElement, description, quickFixes, ProblemHighlightType.GENERIC_ERROR_OR_WARNING));
        }
      }
    }
  }

  private static boolean isInSources(final PsiClass aClass) {
    VirtualFile file = aClass.getContainingFile().getVirtualFile();
    if (file == null) return false;
    Module module = ModuleUtil.findModuleForFile(file, aClass.getProject());
    return module != null && ModuleRootManager.getInstance(module).getFileIndex().isInSourceContent(file);
  }

  @NotNull
  public String getDisplayName() {
    return GwtBundle.message("inspection.name.non.serializable.service.method.parameters");
  }

  @NotNull
  @NonNls
  public String getShortName() {
    return "NonSerializableServiceParameters";
  }

}
