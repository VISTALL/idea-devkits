/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.inspections;

import com.intellij.codeInspection.*;
import com.intellij.gwt.GwtBundle;
import com.intellij.gwt.module.model.GwtModule;
import com.intellij.gwt.module.GwtModulesManager;
import com.intellij.codeHighlighting.HighlightDisplayLevel;
import com.intellij.psi.PsiClass;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.ReadonlyStatusHandler;
import com.intellij.openapi.module.Module;
import com.intellij.javaee.web.WebUtil;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.javaee.model.xml.web.WebApp;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

/**
 * @author nik
 */
public class GwtServiceNotRegisteredInspection extends LocalInspectionTool {
  @NotNull
  public String getGroupDisplayName() {
    return GwtInspectionsProvider.GWT_INSPECTIONS_GROUP;
  }

  @NotNull
  public String getDisplayName() {
    return GwtBundle.message("inspection.name.gwt.remote.service.is.not.registered.in.web.xml");
  }

  @NotNull
  @NonNls
  public String getShortName() {
    return "GwtServiceNotRegistered";
  }


  public boolean isEnabledByDefault() {
    return true;
  }

  @NotNull
  public HighlightDisplayLevel getDefaultLevel() {
    return HighlightDisplayLevel.ERROR;
  }


  @Nullable
  public ProblemDescriptor[] checkClass(@NotNull PsiClass aClass, @NotNull InspectionManager manager, boolean isOnTheFly) {
    final Project project = manager.getProject();
    if (RemoteServiceUtil.isRemoteServiceImplementation(aClass)) {
      final PsiClass service = RemoteServiceUtil.findRemoteServiceInterface(aClass);
      if (service == null) return null;

      GwtModulesManager gwtModulesManager = GwtModulesManager.getInstance(project);
      final VirtualFile virtualFile = service.getContainingFile().getVirtualFile();
      if (virtualFile == null) return null;

      GwtModule gwtModule = gwtModulesManager.findGwtModuleByClientSourceFile(virtualFile);
      if (gwtModule == null) return null;

      final Module module = gwtModule.getModule();
      if (module == null) return null;
      final WebModuleProperties webModuleProperties = WebUtil.getWebModuleProperties(module);
      if (webModuleProperties == null) return null;

      final WebApp webApp = webModuleProperties.getRoot();
      if (webApp == null) return null;

      if (!RemoteServiceUtil.isServiceRegistered(gwtModule, webApp, aClass)) {
        String serviceName = service.getName();

        return new ProblemDescriptor[]{manager.createProblemDescriptor(aClass.getNameIdentifier(), GwtBundle.message(
          "problem.description.remote.service.is.not.registered.as.a.servlet.in.web.xml"), new RegisterServiceQuickFix(gwtModule, webApp,
                                                                                                                       aClass, serviceName),
                                                                                           ProblemHighlightType.GENERIC_ERROR_OR_WARNING)};
      }
    }

    return null;
  }

  private static class RegisterServiceQuickFix implements LocalQuickFix {
    private GwtModule myGwtModule;
    private WebApp myWebApp;
    private PsiClass myServiceImpl;
    private String myServiceName;

    public RegisterServiceQuickFix(final GwtModule gwtModule, final WebApp webApp, final PsiClass serviceImpl, final String serviceName) {
      myGwtModule = gwtModule;
      myWebApp = webApp;
      myServiceImpl = serviceImpl;
      myServiceName = serviceName;
    }

    @NotNull
    public String getName() {
      return GwtBundle.message("quickfix.name.register.remote.service.0.in.web.xml", myServiceName);
    }

    @NotNull
    public String getFamilyName() {
      return getName();
    }

    public void applyFix(@NotNull final Project project, final ProblemDescriptor problemDescriptor) {
      if (!ReadonlyStatusHandler.getInstance(project).ensureFilesWritable(myWebApp.getRoot().getFile().getVirtualFile()).hasReadonlyFiles()) {
        RemoteServiceUtil.registerServletForService(myGwtModule, myWebApp, myServiceImpl, myServiceName);
      }
    }
  }
}
