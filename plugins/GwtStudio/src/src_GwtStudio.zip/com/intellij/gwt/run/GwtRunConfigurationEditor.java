/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.run;

import com.intellij.gwt.GwtBundle;
import com.intellij.gwt.module.GwtModulesManager;
import com.intellij.gwt.module.index.GwtFilesIndex;
import com.intellij.gwt.module.model.GwtModule;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.ui.ComboboxWithBrowseButton;
import com.intellij.ui.RawCommandLineEditor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class GwtRunConfigurationEditor extends SettingsEditor<GwtRunConfiguration> {
  private DefaultComboBoxModel myModulesModel;
  private DefaultComboBoxModel myPagesModel;
  private JComboBox myModulesBox;
  private JPanel myMainPanel;
  private ComboboxWithBrowseButton myHtmlPageBox;
  private JLabel myHtmlToOpenLabel;
  private RawCommandLineEditor myVMParameters;
  private RawCommandLineEditor myGwtShellParameters;
  private Project myProject;
  private GwtModulesManager myGwtModulesManager;

  public GwtRunConfigurationEditor(Project project) {
    myProject = project;
    myGwtModulesManager = GwtModulesManager.getInstance(myProject);
    myVMParameters.setDialodCaption(GwtBundle.message("dialog.caption.vm.parameters"));
    myGwtShellParameters.setDialodCaption(GwtBundle.message("dialog.caption.gwt.shell.parameters"));
  }

  public void resetEditorFrom(GwtRunConfiguration configuration) {
    myVMParameters.setText(configuration.VM_PARAMETERS);
    myGwtShellParameters.setText(configuration.SHELL_PARAMETERS);

    myModulesModel.removeAllElements();
    for (Module module : configuration.getValidModules()) {
      myModulesModel.addElement(module);
    }
    myModulesModel.setSelectedItem(configuration.getModule());

    fillPages(configuration.getModule());
    final VirtualFile file = page2HtmlFile(configuration);
    if (file != null) {
      myHtmlPageBox.getComboBox().getEditor().setItem(file.getPresentableUrl());
    }
  }

  private @Nullable VirtualFile page2HtmlFile(final GwtRunConfiguration configuration) {
    String page = configuration.getPage();
    final int index = page.indexOf('/');
    if (index == -1) return null;

    final Module module = configuration.getModule();
    if (module == null) {
      return null;
    }

    GwtModule gwtModule = myGwtModulesManager.findGwtModuleByName(page.substring(0, index), GlobalSearchScope.moduleWithDependenciesScope(module));
    if (gwtModule == null) return null;

    String name = page.substring(index + 1);
    final List<VirtualFile> publicRoots = gwtModule.getPublicRoots();
    for (VirtualFile root : publicRoots) {
      final VirtualFile file = root.findFileByRelativePath(name);
      if (file != null) {
        return file;
      }
    }
    return null;
  }

  private @Nullable String htmlFile2PageName(VirtualFile file) {
    final GwtModule gwtModule = getGwtModuleByHtmlFile(file);
    final String path = myGwtModulesManager.getPathFromPublicRoot(file);
    if (gwtModule != null && path != null) {
      return gwtModule.getQualifiedName() + "/" + path;
    }
    else {
      return null;
    }
  }

  @Nullable
  private GwtModule getGwtModuleByHtmlFile(final VirtualFile file) {
    final GwtModule[] modules = myGwtModulesManager.getGwtModulesByHtmlFile(file);
    if (modules.length > 0) {
      return modules[0];
    }
    return myGwtModulesManager.findGwtModuleByClientOrPublicFile(file);
  }

  private void fillPages(final Module module) {
    myPagesModel.removeAllElements();
    if (module == null) return;

    final GwtModule[] modules = myGwtModulesManager.getGwtModules(module);
    for (GwtModule gwtModule : modules) {
      final VirtualFile[] htmlFiles = GwtFilesIndex.getInstance(myProject).getHtmlFilesByModule(gwtModule.getQualifiedName());
      for (VirtualFile htmlFile : htmlFiles) {
        myPagesModel.addElement(htmlFile.getPath());
      }
    }
  }

  public void applyEditorTo(GwtRunConfiguration configuration) throws ConfigurationException {
    configuration.setModule((Module)myModulesBox.getSelectedItem());
    final String path = (String)myHtmlPageBox.getComboBox().getEditor().getItem();
    VirtualFile file = LocalFileSystem.getInstance().findFileByPath(FileUtil.toSystemIndependentName(path));
    configuration.setPage(file == null ? null : htmlFile2PageName(file));
    configuration.VM_PARAMETERS = myVMParameters.getText();           
    configuration.SHELL_PARAMETERS = myGwtShellParameters.getText();
  }

  @NotNull
  public JComponent createEditor() {
    myModulesModel = new DefaultComboBoxModel();
    myModulesBox.setModel(myModulesModel);
    myPagesModel = new DefaultComboBoxModel();
    final JComboBox comboBox = myHtmlPageBox.getComboBox();
    comboBox.setEditable(true);
    comboBox.setModel(myPagesModel);
    myHtmlToOpenLabel.setLabelFor(comboBox);

    myModulesBox.setRenderer(new DefaultListCellRenderer() {
      public Component getListCellRendererComponent(JList list, final Object value, int index, boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        final Module module = (Module)value;
        if (module != null) {
          setIcon(module.getModuleType().getNodeIcon(false));
          setText(module.getName());
        }
        return this;
      }
    });

    myModulesBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fillPages((Module)myModulesModel.getSelectedItem());
      }
    });

    myHtmlPageBox.addBrowseFolderListener(myProject, createHtmlFileChooserDescriptor());

    return myMainPanel;
  }

  private FileChooserDescriptor createHtmlFileChooserDescriptor() {
    final FileChooserDescriptor descriptor = new FileChooserDescriptor(true, false, false, false, false, false) {
      public boolean isFileVisible(VirtualFile file, boolean showHiddenFiles) {
        return super.isFileVisible(file, showHiddenFiles) &&
               (file.isDirectory() || FileTypeManager.getInstance().getFileTypeByFile(file) == StdFileTypes.HTML);
      }
    };
    final VirtualFile[] sourceRoots = ProjectRootManager.getInstance(myProject).getContentSourceRoots();
    descriptor.getRoots().clear();
    for (VirtualFile sourceRoot : sourceRoots) {
      descriptor.addRoot(sourceRoot);
    }
    return descriptor;
  }

  public void disposeEditor() {
  }
}
