/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.run;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.ExecutionResult;
import com.intellij.execution.configurations.*;
import com.intellij.execution.process.ProcessAdapter;
import com.intellij.execution.process.ProcessEvent;
import com.intellij.gwt.facet.GwtFacet;
import com.intellij.gwt.make.GwtCompilerPaths;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.roots.ProjectRootsTraversing;
import com.intellij.openapi.util.SystemInfo;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.util.PathsList;

import java.io.File;

/**
 * @author nik
*/
public class GwtCommandLineState extends JavaCommandLineState {
  private final Module myModule;
  private String myRunPage;
  private String myVMParameters;
  private GwtFacet myFacet;
  private final String myShellParameters;

  public GwtCommandLineState(final GwtFacet facet, final RunnerSettings runnerSettings, final ConfigurationPerRunnerSettings configurationSettings,
                             final String runPage,
                             final String vmParameters,
                             final String shellParameters) {
    super(runnerSettings, configurationSettings);
    myFacet = facet;
    myShellParameters = shellParameters;
    myModule = myFacet.getModule();
    myRunPage = runPage;
    myVMParameters = vmParameters;
  }

  protected JavaParameters createJavaParameters() throws ExecutionException {
    final JavaParameters params = new JavaParameters();

    params.setWorkingDirectory(getTempOutputDir());

    params.configureByModule(myModule, JavaParameters.JDK_AND_CLASSES);

    if (SystemInfo.isMac) {
      params.getVMParametersList().add("-XstartOnFirstThread");
    }
    params.getVMParametersList().addParametersString(myVMParameters);

    final ParametersList programParameters = params.getProgramParametersList();
    programParameters.add("-style");
    programParameters.add(myFacet.getConfiguration().getOutputStyle().getId());
    programParameters.add("-out");
    programParameters.add(getOutputPath().getAbsolutePath());
    programParameters.add("-gen");
    programParameters.add(getGenPath().getAbsolutePath());
    programParameters.addParametersString(myShellParameters);
    programParameters.add(myRunPage);

    final PathsList sources = ProjectRootsTraversing.collectRoots(myModule, new ProjectRootsTraversing.RootTraversePolicy(
      ProjectRootsTraversing.RootTraversePolicy.SOURCES, null, null, ProjectRootsTraversing.RootTraversePolicy.RECURSIVE));

    for (String path : sources.getPathList()) {
      params.getClassPath().addFirst(path);
    }

    params.getClassPath().addFirst(myFacet.getConfiguration().getSdk().getDevJarPath());
    params.setMainClass("com.google.gwt.dev.GWTShell");

    return params;
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  private File getGenPath() {
    return new File(getTempOutputDir(), "gen");
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  private File getOutputPath() {
    return new File(getTempOutputDir(), "www");
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  private File getTempOutputDir() {
    return new File(GwtCompilerPaths.getOutputRoot(myModule), "run");
  }

  public ExecutionResult execute() throws ExecutionException {
    getOutputPath().mkdirs();
    getGenPath().mkdirs();
    final ExecutionResult result = super.execute();
    result.getProcessHandler().addProcessListener(new ProcessAdapter() {
      public void processTerminated(final ProcessEvent event) {
        FileUtil.delete(getTempOutputDir());
      }
    });
    return result;
  }
}
