/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.facet;

import com.intellij.facet.FacetConfiguration;
import com.intellij.facet.ui.FacetEditorContext;
import com.intellij.facet.ui.FacetEditorTab;
import com.intellij.facet.ui.FacetValidatorsManager;
import com.intellij.gwt.sdk.GwtSdk;
import com.intellij.gwt.sdk.GwtSdkManager;
import com.intellij.gwt.module.model.GwtModule;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMExternalizer;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vfs.VfsUtil;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * @author nik
 */
public class GwtFacetConfiguration implements FacetConfiguration {
  @NonNls private static final String GWT_PATH_ATTRIBUTE = "gwtPath";
  @NonNls private static final String GWT_URL_ATTRIBUTE = "gwtSdkUrl";
  @NonNls private static final String WEB_FACET_ATTRIBUTE = "webFacet";
  @NonNls private static final String GWT_SCRIPT_OUTPUT_STYLE_ATTRIBUTE = "gwtScriptOutputStyle";
  @NonNls private static final String RUN_GWT_COMPILER_ON_MAKE_ATTRIBUTE = "runGwtCompilerOnMake";
  @NonNls private static final String COMPILER_MAX_HEAP_SIZE_ATTRIBUTE = "compilerMaxHeapSize";
  @NonNls private static final String PACKAGING_PATHS_ELEMENT = "packaging";
  @NonNls private static final String GWT_MODULE_ELEMENT = "module";
  @NonNls private static final String MODULE_NAME_ATTRIBUTE = "name";
  @NonNls private static final String PACKAGING_PATH_ATTRIBUTE = "path";

  private String myGwtSdkUrl = "";
  private GwtJavaScriptOutputStyle myOutputStyle = GwtJavaScriptOutputStyle.DETAILED;
  private boolean myRunGwtCompilerOnMake = true;
  private int myCompilerMaxHeapSize = 128;
  private String myWebFacetName;
  private Map<String, String> myPackagingPaths = new HashMap<String, String>();

  public FacetEditorTab[] createEditorTabs(final FacetEditorContext editorContext, final FacetValidatorsManager validatorsManager) {
    return new FacetEditorTab[]{new GwtFacetEditor(editorContext, validatorsManager, this)};
  }

  public void readExternal(Element element) throws InvalidDataException {
    String sdkUrl = JDOMExternalizer.readString(element, GWT_URL_ATTRIBUTE);
    if (sdkUrl == null) {
      //todo[nik] remove later. This code is used for compatibility with Selena EAPs before 7062.
      String sdkPath = JDOMExternalizer.readString(element, GWT_PATH_ATTRIBUTE);
      sdkUrl = VfsUtil.pathToUrl(FileUtil.toSystemIndependentName(sdkPath));
    }

    setGwtSdkUrl(sdkUrl == null ? "" : sdkUrl);
    final String styleId = JDOMExternalizer.readString(element, GWT_SCRIPT_OUTPUT_STYLE_ATTRIBUTE);
    final GwtJavaScriptOutputStyle style = GwtJavaScriptOutputStyle.byId(styleId);
    if (style != null) {
      myOutputStyle = style;
    }
    myRunGwtCompilerOnMake = !Boolean.toString(false).equals(JDOMExternalizer.readString(element, RUN_GWT_COMPILER_ON_MAKE_ATTRIBUTE));
    myWebFacetName = JDOMExternalizer.readString(element, WEB_FACET_ATTRIBUTE);
    myCompilerMaxHeapSize = JDOMExternalizer.readInteger(element, COMPILER_MAX_HEAP_SIZE_ATTRIBUTE, 128);
    Element packaging = element.getChild(PACKAGING_PATHS_ELEMENT);
    if (packaging != null) {
      //noinspection unchecked
      List<Element> children = packaging.getChildren(GWT_MODULE_ELEMENT);
      for (Element child : children) {
        myPackagingPaths.put(child.getAttributeValue(MODULE_NAME_ATTRIBUTE), child.getAttributeValue(PACKAGING_PATH_ATTRIBUTE));
      }
    }
  }

  public void writeExternal(Element element) throws WriteExternalException {
    JDOMExternalizer.write(element, GWT_URL_ATTRIBUTE, myGwtSdkUrl);

    if (myWebFacetName != null) {
      JDOMExternalizer.write(element, WEB_FACET_ATTRIBUTE, myWebFacetName);
    }
    JDOMExternalizer.write(element, GWT_SCRIPT_OUTPUT_STYLE_ATTRIBUTE, myOutputStyle.getId());
    JDOMExternalizer.write(element, RUN_GWT_COMPILER_ON_MAKE_ATTRIBUTE, myRunGwtCompilerOnMake);
    JDOMExternalizer.write(element, COMPILER_MAX_HEAP_SIZE_ATTRIBUTE, myCompilerMaxHeapSize);

    if (!myPackagingPaths.isEmpty()) {
      Element packaging = new Element(PACKAGING_PATHS_ELEMENT);
      for (String moduleName : myPackagingPaths.keySet()) {
        String path = myPackagingPaths.get(moduleName);
        Element moduleElement = new Element(GWT_MODULE_ELEMENT);
        moduleElement.setAttribute(MODULE_NAME_ATTRIBUTE, moduleName);
        moduleElement.setAttribute(PACKAGING_PATH_ATTRIBUTE, path);
        packaging.addContent(moduleElement);
      }
      element.addContent(packaging);
    }
  }

  public String getGwtSdkPath() {
    return FileUtil.toSystemDependentName(VfsUtil.urlToPath(myGwtSdkUrl));
  }

  public void setGwtSdkUrl(final String gwtUrl) {
    myGwtSdkUrl = gwtUrl;
  }

  @NotNull
  public GwtSdk getSdk() {
    return GwtSdkManager.getInstance().getGwtSdk(myGwtSdkUrl);
  }

  public String getGwtSdkUrl() {
    return myGwtSdkUrl;
  }

  public boolean isRunGwtCompilerOnMake() {
    return myRunGwtCompilerOnMake;
  }

  public void setRunGwtCompilerOnMake(final boolean runGwtCompiler) {
    myRunGwtCompilerOnMake = runGwtCompiler;
  }

  public int getCompilerMaxHeapSize() {
    return myCompilerMaxHeapSize;
  }

  public void setCompilerMaxHeapSize(final int compilerMaxHeapSize) {
    myCompilerMaxHeapSize = compilerMaxHeapSize;
  }

  public GwtJavaScriptOutputStyle getOutputStyle() {
    return myOutputStyle;
  }

  public void setOutputStyle(final GwtJavaScriptOutputStyle outputStyle) {
    myOutputStyle = outputStyle;
  }

  public void setWebFacetName(final String webFacetName) {
    myWebFacetName = webFacetName;
  }

  @Nullable
  public String getWebFacetName() {
    return myWebFacetName;
  }

  @NotNull
  public String getPackagingRelativePath(@NotNull GwtModule module) {
    String moduleName = module.getQualifiedName();
    String path = myPackagingPaths.get(moduleName);
    if (path != null) {
      return path;
    }
    return "/" + moduleName;
  }

  public void setPackagingRelativePath(@NotNull String moduleName, @NotNull String path) {
    myPackagingPaths.put(moduleName, path);
  }
}
