/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.facet;

import com.intellij.facet.Facet;
import com.intellij.facet.FacetType;
import com.intellij.facet.FacetTypeId;
import com.intellij.facet.autodetecting.FacetDetector;
import com.intellij.facet.autodetecting.FacetDetectorRegistry;
import com.intellij.facet.impl.autodetecting.FacetDetectorRegistryEx;
import com.intellij.gwt.GwtBundle;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.vfs.VirtualFile;
import static com.intellij.patterns.impl.StandardPatterns.string;
import static com.intellij.patterns.impl.StandardPatterns.virtualFile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.awt.*;
import java.util.Collection;

/**
 * @author nik
 */
public class GwtFacetType extends FacetType<GwtFacet, GwtFacetConfiguration> {
  public static final FacetTypeId<GwtFacet> ID = new FacetTypeId<GwtFacet>("gwt");
  public static final GwtFacetType INSTANCE = new GwtFacetType();
  private static Icon SMALL_ICON_12x12 = IconLoader.getIcon("/icons/google-small.png");
  //todo[nik] change .png file instead  
  public static Icon SMALL_ICON = new Icon() {
    public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
      SMALL_ICON_12x12.paintIcon(c, g, x + 2, y + 2);
    }

    public int getIconWidth() {
      return 16;
    }

    public int getIconHeight() {
      return 16;
    }
  };
  public static Icon LARGE_ICON = IconLoader.getIcon("/icons/google-large.png");

  private GwtFacetType() {
    super(ID, "gwt", GwtBundle.message("facet.type.name.gwt"));
  }

  public GwtFacetConfiguration createDefaultConfiguration() {
    return new GwtFacetConfiguration();
  }

  public GwtFacet createFacet(@NotNull Module module, final String name, @NotNull GwtFacetConfiguration configuration, @Nullable Facet underlyingFacet) {
    return new GwtFacet(this, module, name, configuration);
  }


  public boolean isOnlyOneFacetAllowed() {
    return true;
  }

  public void registerDetectors(final FacetDetectorRegistry<GwtFacetConfiguration> facetDetectorRegistry) {
    FacetDetectorRegistryEx<GwtFacetConfiguration> detectorRegistry = (FacetDetectorRegistryEx<GwtFacetConfiguration>)facetDetectorRegistry;
    FacetDetector<VirtualFile, GwtFacetConfiguration> facetDetector = new FacetDetector<VirtualFile, GwtFacetConfiguration>() {
      public GwtFacetConfiguration detectFacet(final VirtualFile source,
                                                            final Collection<GwtFacetConfiguration> existentFacetConfigurations) {
        if (!existentFacetConfigurations.isEmpty()) {
          return existentFacetConfigurations.iterator().next();
        }
        return new GwtFacetConfiguration();
      }
    };
    detectorRegistry.registerUniversalDetector(StdFileTypes.XML, virtualFile().withName(string().endsWith(".gwt.xml")), facetDetector);
  }

  public Icon getIcon() {
    return SMALL_ICON;
  }
}
