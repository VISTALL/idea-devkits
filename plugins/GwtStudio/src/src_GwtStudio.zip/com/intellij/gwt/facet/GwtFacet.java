/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.facet;

import com.intellij.facet.Facet;
import com.intellij.facet.FacetManager;
import com.intellij.facet.FacetType;
import com.intellij.facet.ModifiableFacetModel;
import com.intellij.facet.impl.ui.FacetEditorContextBase;
import com.intellij.gwt.sdk.GwtSdkManager;
import com.intellij.gwt.sdk.GwtVersion;
import com.intellij.gwt.sdk.GwtSdk;
import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.openapi.application.Result;
import com.intellij.openapi.application.WriteAction;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.roots.ModifiableRootModel;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.roots.libraries.LibraryTablesRegistrar;
import com.intellij.openapi.roots.libraries.LibraryTable;
import com.intellij.openapi.roots.libraries.Library;
import com.intellij.openapi.diagnostic.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author nik
 */
public class GwtFacet extends Facet<GwtFacetConfiguration> {
  private static final Logger LOG = Logger.getInstance("#com.intellij.gwt.facet.GwtFacet");

  public GwtFacet(@NotNull final FacetType facetType, @NotNull final Module module, final String name, @NotNull final GwtFacetConfiguration configuration) {
    super(facetType, module, name, configuration, null);
  }                                    

  @Nullable
  public static GwtFacet getInstance(@NotNull Module module) {
    return FacetManager.getInstance(module).getFacetByType(GwtFacetType.ID);
  }
  
  @Nullable
  public static GwtFacet findFacetBySourceFile(@NotNull Project project, @Nullable VirtualFile file) {
    if (file == null) return null;

    final Module module = ModuleUtil.findModuleForFile(file, project);
    if (module == null) return null;

    return getInstance(module);
  }

  public static boolean isInModuleWithGwtFacet(final @NotNull Project project, final @Nullable VirtualFile file) {
    return findFacetBySourceFile(project, file) != null;
  }

  @Nullable
  public WebFacet getWebFacet() {
    final String webFacetName = getConfiguration().getWebFacetName();
    return webFacetName != null ? FacetManager.getInstance(getModule()).findFacet(WebFacet.ID, webFacetName) : null;
  }

  public GwtVersion getSdkVersion() {
    return getConfiguration().getSdk().getVersion();
  }

  public void initFacet() {
    GwtSdkManager.getInstance().registerGwtSdk(getConfiguration().getGwtSdkUrl());
  }

  public static GwtFacet createNewFacet(final @NotNull Module module) {
    final ModifiableFacetModel model = FacetManager.getInstance(module).createModifiableModel();
    GwtFacet facet = model.getFacetByType(GwtFacetType.ID);
    if (facet != null) return facet;

    GwtFacetType type = GwtFacetType.INSTANCE;
    GwtFacetConfiguration configuration = type.createDefaultConfiguration();
    facet = type.createFacet(module, type.getDefaultFacetName(), configuration, null);
    model.addFacet(facet);

    final ModifiableRootModel rootModel = ModuleRootManager.getInstance(module).getModifiableModel();
    setupGwtSdkAndLibraries(configuration, rootModel);

    new WriteAction() {
      protected void run(final Result result) {
        model.commit();
        rootModel.commit();
      }
    }.execute();
    return facet;
  }

  public static void setupGwtSdkAndLibraries(final GwtFacetConfiguration configuration, ModifiableRootModel rootModel) {
    GwtSdk gwtSdk = GwtSdkManager.getInstance().suggestGwtSdk();
    if (gwtSdk != null) {
      configuration.setGwtSdkUrl(gwtSdk.getHomeDirectoryUrl());
      VirtualFile userJar = gwtSdk.getUserJar();
      LOG.assertTrue(userJar != null);
      LibraryTable libraryTable = LibraryTablesRegistrar.getInstance().getLibraryTable(rootModel.getModule().getProject());
      Library library =
        FacetEditorContextBase.createLibraryInTable("gwt-user", new VirtualFile[]{userJar}, new VirtualFile[]{userJar}, libraryTable);
      rootModel.addLibraryEntry(library);
    }
  }

}
