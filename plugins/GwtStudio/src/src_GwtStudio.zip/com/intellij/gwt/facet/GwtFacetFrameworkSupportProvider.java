/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.facet;

import com.intellij.facet.impl.ui.FacetTypeFrameworkSupportProvider;
import com.intellij.gwt.GwtBundle;
import com.intellij.openapi.roots.ModifiableRootModel;
import com.intellij.javaee.web.facet.WebFacet;

import java.util.Collection;

/**
 * @author nik
 */
public class GwtFacetFrameworkSupportProvider extends FacetTypeFrameworkSupportProvider<GwtFacet> {
  public GwtFacetFrameworkSupportProvider() {
    super(GwtFacetType.INSTANCE);
  }

  protected void setupConfiguration(final GwtFacet facet, final ModifiableRootModel rootModel, final String version) {
    Collection<WebFacet> facets = WebFacet.getInstances(facet.getModule());
    if (!facets.isEmpty()) {
      facet.getConfiguration().setWebFacetName(facets.iterator().next().getName());
    }
  }

  protected void onFacetCreated(final GwtFacet facet, final ModifiableRootModel rootModel, final String version) {
    GwtFacet.setupGwtSdkAndLibraries(facet.getConfiguration(), rootModel);
  }

  public String[] getPrecedingFrameworkProviderIds() {
    return new String[]{getProviderId(WebFacet.ID)};
  }

  public String getTitle() {
    return GwtBundle.message("framework.title.google.web.toolkit");
  }
}
