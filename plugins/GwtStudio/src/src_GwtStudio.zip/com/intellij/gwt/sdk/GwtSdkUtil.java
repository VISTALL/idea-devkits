/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.sdk;

import com.intellij.facet.ui.ValidationResult;
import com.intellij.gwt.GwtBundle;
import com.intellij.openapi.roots.libraries.LibraryUtil;
import com.intellij.openapi.util.SystemInfo;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vfs.JarFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.annotations.NonNls;

import java.io.File;

/**
 * @author nik
 */
public class GwtSdkUtil {
  @NonNls private static final String GWT_USER_JAR = "gwt-user.jar";
  @NonNls private static final String GWT_DEV_WINDOWS_JAR = "gwt-dev-windows.jar";
  @NonNls private static final String GWT_DEV_LINUX_JAR = "gwt-dev-linux.jar";
  @NonNls private static final String GWT_DEV_MAC_JAR = "gwt-dev-mac.jar";
  @NonNls public static final String GWT_CLASS_NAME = "com.google.gwt.core.client.GWT";

  private GwtSdkUtil() {
  }

  public static String getUserJarPath(String base) {
    return base + File.separator + GWT_USER_JAR;
  }

  public static String getDevJarPath(String base) {
    final String jarName;
    if (SystemInfo.isWindows) {
      jarName = GWT_DEV_WINDOWS_JAR;
    }
    else if (SystemInfo.isMac) {
      jarName = GWT_DEV_MAC_JAR;
    }
    else {
      jarName = GWT_DEV_LINUX_JAR;
    }
    return base + File.separator + jarName;
  }

  private static ValidationResult checkClass(final @NonNls String className, String gwtPath, final String jarPath) {
    final VirtualFile jarFile = JarFileSystem.getInstance().refreshAndFindFileByPath(FileUtil.toSystemIndependentName(jarPath)
                                                                                     + JarFileSystem.JAR_SEPARATOR);
    if (jarFile == null) {
      return new ValidationResult(GwtBundle.message("error.file.not.found.message", gwtPath, jarPath));
    }
    if (!LibraryUtil.isClassAvailableInLibrary(new VirtualFile[]{jarFile}, className)) {
      return new ValidationResult(GwtBundle.message("error.class.not.found.in.jar", gwtPath, className, jarFile));
    }
    return ValidationResult.OK;
  }

  public static ValidationResult checkGwtSdkPath(final String gwtPath) {
    ValidationResult result = checkClass("com.google.gwt.dev.GWTCompiler", gwtPath, getDevJarPath(gwtPath));
    if (result.isOk()) {
      result = checkClass("com.google.gwt.dev.GWTShell", gwtPath, getDevJarPath(gwtPath));
    }
    if (result.isOk()) {
      result = checkClass(GWT_CLASS_NAME, gwtPath, getUserJarPath(gwtPath));
    }
    return result;
  }

}
