/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt;

import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.vfs.VirtualFile;

public abstract class GWTFileScanner {
  public void scanFile(Module module, VirtualFile root, VirtualFile file) {
  }

  public void scanDir(Module module, VirtualFile root, VirtualFile[] files) {
    for (final VirtualFile file : files) {
      if (file.isDirectory()) {
        scanDir(module, root, file.getChildren());
      }
      else {
        scanFile(module, root, file);
      }
    }
  }

  public void scanModule(Module module) {
    for (VirtualFile root : ModuleRootManager.getInstance(module).getSourceRoots()) {
      scanRoot(module, root);
    }
  }

  public void scanRoot(Module module, VirtualFile root) {
    scanDir(module, root, root.getChildren());
  }

  public void scanModules(Module[] modules) {
    for (Module module : modules) {
      scanModule(module);
    }
  }

  public void scanProject(Project project) {
    scanModules(ModuleManager.getInstance(project).getModules());
  }
}
