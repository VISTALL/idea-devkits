/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.configuration;

import com.intellij.gwt.GwtJavaScriptOutputStyle;
import com.intellij.gwt.GwtBundle;
import com.intellij.ide.util.BrowseFilesListener;
import com.intellij.ui.FieldPanel;
import com.intellij.util.ui.UIUtil;

import javax.swing.*;
import java.awt.*;

/**
 * @author nik
 */
public class GwtConfigurationEditor {
  private JComboBox myOutputStyleBox;
  private JPanel myMainPanel;
  private JPanel myPathFieldPanel;
  private JLabel myOutputStyleLabel;
  private JCheckBox myRunGwtCompilerForJavaModules;
  private JTextField myPathField;

  public GwtConfigurationEditor() {
    myOutputStyleLabel.setText(GwtBundle.message("label.select.script.output.style.text"));

    for (GwtJavaScriptOutputStyle style : GwtJavaScriptOutputStyle.values()) {
      myOutputStyleBox.addItem(style);
    }

    myPathField = new JTextField();
    final BrowseFilesListener browseFilesListener = new BrowseFilesListener(myPathField, GwtBundle.message("config.label"),
                                                                            GwtBundle.message("config.descr"),
                                                                            BrowseFilesListener.SINGLE_DIRECTORY_DESCRIPTOR);
    final FieldPanel fieldPanel = new FieldPanel(myPathField, GwtBundle.message("config.label"), null, browseFilesListener, null);
    fieldPanel.getFieldLabel().setFont(UIUtil.getLabelFont().deriveFont(Font.BOLD));

    myPathFieldPanel.setLayout(new BorderLayout());
    myPathFieldPanel.add(fieldPanel, BorderLayout.CENTER);
  }

  public GwtJavaScriptOutputStyle getOutputStyle() {
    return (GwtJavaScriptOutputStyle)myOutputStyleBox.getSelectedItem();
  }

  public void setOutputStyle(GwtJavaScriptOutputStyle style) {
    myOutputStyleBox.setSelectedItem(style);
  }

  public String getGwtInstallationPath() {
    return myPathField.getText();
  }

  public JPanel getMainPanel() {
    return myMainPanel;
  }

  public void setGwtInstallationPath(final String gwtPath) {
    myPathField.setText(gwtPath);
  }

  public boolean isRunGwtCompilerForJavaModules() {
    return myRunGwtCompilerForJavaModules.isSelected();
  }

  public void setRunGwtCompilerForJavaModules(boolean b) {
    myRunGwtCompilerForJavaModules.setSelected(b);
  }
}
