/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.gwt.make;

import com.intellij.javaee.make.J2EEBuildParticipant;
import com.intellij.javaee.make.BuildRecipe;
import com.intellij.openapi.compiler.CompileContext;
import com.intellij.openapi.module.ModuleComponent;
import com.intellij.openapi.module.Module;
import com.intellij.gwt.GwtConfiguration;
import com.intellij.gwt.module.GwtModulesManager;
import com.intellij.gwt.module.model.GwtModule;

import java.io.File;

import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

/**
 * @author nik
 */
public class GwtWebBuildParticipant implements J2EEBuildParticipant, ModuleComponent {
  private Module myModule;

  public GwtWebBuildParticipant(Module module) {
    myModule = module;
  }

  public void registerBuildInstructions(BuildRecipe buildRecipe, CompileContext context) {
    if (GwtConfiguration.getInstance().isValidConfiguration()) {
      final GwtModule[] modules = GwtModulesManager.getInstance(myModule.getProject()).getGwtModules(myModule);
      for (GwtModule module : modules) {
        final File output = new File(GwtCompilerPaths.getOutputDirectory(myModule), module.getQualifiedName());
        buildRecipe.addFileCopyInstruction(output, true, myModule, "/", null);
      }
    }
  }

  public void afterJarCreated(File jarFile, CompileContext context) throws Exception {
  }

  public void afterExplodedCreated(File outputDir, CompileContext context) throws Exception {
  }

  public void buildFinished(CompileContext context) throws Exception {
  }


  public void projectOpened() {
  }

  public void projectClosed() {
  }

  public void moduleAdded() {
  }

  @NonNls
  @NotNull
  public String getComponentName() {
    return "GwtWebBuildParticipant";
  }

  public void initComponent() {
  }

  public void disposeComponent() {
  }
}
