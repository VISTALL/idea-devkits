/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.j2ee.wrappers;

import weblogic.management.runtime.ApplicationRuntimeMBean;
import weblogic.management.runtime.ComponentRuntimeMBean;
import weblogic.management.runtime.WebAppComponentRuntimeMBean;

import java.util.Set;
import java.util.Iterator;

/**
 * @author nik
 */
public class ApplicationRuntimeMBeanWrapper implements com.intellij.j2ee.wrappers.ApplicationRuntimeMBean {
  private ApplicationRuntimeMBean mySource;

  public ApplicationRuntimeMBeanWrapper(final ApplicationRuntimeMBean applicationRuntimeMBean) {
    mySource = applicationRuntimeMBean;
  }

  public WebLogicObjectName getObjectName() {
    return new WebLogicObjectNameWrapper(mySource.getObjectName());
  }

  public String getName() {
    return mySource.getName();
  }

  public String getContextRoot(final MBeanHome mBeanHome) {
    try {
      final ComponentRuntimeMBean[] runtimeMBeans = mySource.lookupComponents();
      for (ComponentRuntimeMBean runtimeMBean : runtimeMBeans) {
        if (runtimeMBean instanceof WebAppComponentRuntimeMBean) {
          return ((WebAppComponentRuntimeMBean)runtimeMBean).getContextRoot();
        }
      }
    }
    catch (NoSuchMethodError e) {
      final Set beans = mBeanHome.getMBeansByType("WebAppComponentRuntime", mBeanHome.getDomainName());
      for (Iterator iterator = beans.iterator(); iterator.hasNext();) {
        Object bean = iterator.next();
        if (bean instanceof WebLogicMBeanWrapper) {
          try {
            final WebLogicMBeanWrapper beanWrapper = (WebLogicMBeanWrapper)bean;
            final String applicationName = beanWrapper.getObjectName().getKeyProperty("ApplicationRuntime");
            if (getName().equals(applicationName)) {
              final Object source = beanWrapper.getSource();
              if (source instanceof WebAppComponentRuntimeMBean) {
                return ((WebAppComponentRuntimeMBean)source).getContextRoot();
              }
            }
          }
          catch (Exception e1) {
            //ignore
          }
        }
      }
    }
    return null;
  }
}
