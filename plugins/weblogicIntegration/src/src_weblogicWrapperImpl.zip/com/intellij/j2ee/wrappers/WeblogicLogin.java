/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.wrappers;

import weblogic.management.MBeanHome;
import weblogic.management.WebLogicObjectName;
import weblogic.management.deploy.utils.DeployerHelper;
import weblogic.security.Security;
import weblogic.security.auth.callback.URLCallback;

import javax.management.MalformedObjectNameException;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.security.auth.Subject;
import javax.security.auth.callback.*;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.Date;

public class WeblogicLogin implements WeblogicMain {
  private WeblogicOutputInfo myWeblogicOutputInfo = new WeblogicOutputInfoImpl();

  public WeblogicLogin() {
  }

  public Subject login(final String user, final String adminUrl, final char[] password) throws LoginException {
    // Create LoginContext; specify username/password login module
    //noinspection HardCodedStringLiteral
    LoginContext loginContext = new LoginContext("WebLogicLogin", new CallbackHandler() {
      public void handle(Callback[] callbacks) throws UnsupportedCallbackException {
        for (int i = 0; i < callbacks.length; i++) {
          final Callback callback = callbacks[i];
          if (callback instanceof NameCallback) {
            NameCallback nc = (NameCallback)callback;
            nc.setName(user);
          }
          else if (callback instanceof URLCallback) {
            ((URLCallback)callback).setURL(adminUrl);
          }
          else if (callback instanceof PasswordCallback) {
            PasswordCallback pc = (PasswordCallback)callback;
            pc.setPassword(password);
          }
          else if (callback instanceof TextInputCallback) {
            // Prompt the user for the username
          }
          else {
            throw new UnsupportedCallbackException(callback, "Unrecognized Callback");
          }
        }
      }
    });
    loginContext.login();
    return loginContext.getSubject();
  }

  public com.intellij.j2ee.wrappers.MBeanHome createMBeanHomeFromContext(Context ctx) throws NamingException {
    return new WebLogicMBeanWrapper(ctx.lookup(MBeanHome.ADMIN_JNDI_NAME));
  }

  public void runAs(Subject subject, PrivilegedExceptionAction privilegedExceptionAction) throws PrivilegedActionException {
    Security.runAs(subject, privilegedExceptionAction);
  }

  public void runAs(Subject subject, PrivilegedAction privilegedExceptionAction) {
    Security.runAs(subject, privilegedExceptionAction);
  }

  public ObjectNameWrapper createObjectName(String s) throws MalformedObjectNameExceptionWrapper {
    return new ObjectNameWrapper(s);
  }

  public com.intellij.j2ee.wrappers.WebLogicObjectName createWeblogicObjectName(String name,
                                                                                String type,
                                                                                String domainName,
                                                                                String serverName)
    throws MalformedObjectNameExceptionWrapper {
    try {
      return new WebLogicObjectNameWrapper(new WebLogicObjectName(name, type, domainName, serverName));
    }
    catch (MalformedObjectNameException e) {
      throw new MalformedObjectNameExceptionWrapper(e);
    }
  }

  public com.intellij.j2ee.wrappers.WebLogicLogNotification createWeblogicLogNotificationWrapper(Date date,
                                                                                                 String machineName,
                                                                                                 String serverName,
                                                                                                 String threadId,
                                                                                                 String userId,
                                                                                                 String tranId,
                                                                                                 String type,
                                                                                                 long sequenceNumber,
                                                                                                 int severity,
                                                                                                 String message,
                                                                                                 Object logNotification,
                                                                                                 Throwable e) {
    return new WebLogicLogNotificationWrapper(date, machineName, serverName, threadId, userId, tranId, type, sequenceNumber, severity, message, logNotification, e);
  }

  public com.intellij.j2ee.wrappers.WebLogicObjectName createWeblogicObjectName(String name,
                                                                                String type,
                                                                                String domainName,
                                                                                String serverName,
                                                                                com.intellij.j2ee.wrappers.WebLogicObjectName parent)
    throws MalformedObjectNameExceptionWrapper {
    try {
      return new WebLogicObjectNameWrapper(
        new WebLogicObjectName(name, type, domainName, serverName, (WebLogicObjectName)((WebLogicObjectNameWrapper)parent).getSource()));
    }
    catch (MalformedObjectNameException e) {
      throw new MalformedObjectNameExceptionWrapper(e);
    }
  }

  public com.intellij.j2ee.wrappers.DeploymentData createDeploymentData() {
    return new DeploymentDataWrapper();
  }

  public com.intellij.j2ee.wrappers.DeployerHelper createDeploymentHelper(com.intellij.j2ee.wrappers.MBeanHome mBeanHome) {
    return new DeployerHelperWrapper(new DeployerHelper((MBeanHome)((WebLogicMBeanWrapper)mBeanHome).getSource()));
  }

  public WeblogicOutputInfo getOutputInfo() {
    return myWeblogicOutputInfo;
  }
}
