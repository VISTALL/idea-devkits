/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.wrappers;

import weblogic.management.ManagementException;
import weblogic.management.configuration.TargetMBean;
import weblogic.management.runtime.DeployerRuntimeMBean;

public class DeployerRuntimeMBeanWrapper extends WebLogicMBeanWrapper implements com.intellij.j2ee.wrappers.DeployerRuntimeMBean {
  private final DeployerRuntimeMBean mySource;

  DeployerRuntimeMBeanWrapper(DeployerRuntimeMBean source) {
    super(source);
    mySource = source;
  }

  public com.intellij.j2ee.wrappers.TargetMBean[] lookupActiveTargetsForComponent(ComponentMBean component) {
    try {
      TargetMBean[] original = mySource.lookupActiveTargetsForComponent(((ComponentMBeanWrapper)component).getOriginal());
      if (original == null) return null;
      com.intellij.j2ee.wrappers.TargetMBean[] result = new TargetMBeanWrapper[original.length];
      for (int i = 0; i < original.length; i++) {
        result[i] = new TargetMBeanWrapper();
      }
      return result;
    }
    catch (RuntimeException e) {
      throw new ManagementRuntimeExceptionWrapper(e);
    }
  }

  public DeploymentTaskRuntimeMBean activate(String sourcePath,
                                                    String name,
                                                    DeploymentData info,
                                                    boolean b) throws ManagementExceptionWrapper {
    try {
      return new DeploymentTaskRuntimeMBeanWrapper(mySource.activate(sourcePath,
                                                                     name,
                                                                     null,
                                                                     ((DeploymentDataWrapper)info).getSource(),
                                                                     null,
                                                                     b));
    }
    catch (ManagementException e) {
      throw new ManagementExceptionWrapper(e);
    }

  }

  public DeploymentTaskRuntimeMBean remove(String name, DeploymentData info, boolean b) throws ManagementExceptionWrapper {
    try {
      return new DeploymentTaskRuntimeMBeanWrapper(mySource.remove(name, ((DeploymentDataWrapper)info).getSource(), null, b));
    }
    catch (ManagementException e) {
      throw new ManagementExceptionWrapper(e);
    }
  }
}
