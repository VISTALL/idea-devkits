/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.wrappers;

import weblogic.management.*;

import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

public class ObjectNameWrapper implements com.intellij.j2ee.wrappers.ObjectName {
  private final ObjectName myObjectName;

  ObjectNameWrapper(ObjectName objectName) {
    myObjectName = objectName;
  }

  ObjectNameWrapper(String str) throws MalformedObjectNameExceptionWrapper {
    try {
      myObjectName = new ObjectName(str);
    }
    catch (MalformedObjectNameException e) {
      throw new MalformedObjectNameExceptionWrapper(e);
    }
  }

  public String getKeyProperty(String s) {
    return myObjectName.getKeyProperty(s);
  }

  ObjectName getSource() {
    return myObjectName;
  }
  public String toString() {
    return myObjectName.toString();
  }


  public int hashCode() {
    return myObjectName != null ? myObjectName.hashCode() : 0;
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof ObjectNameWrapper)) {
      return false;
    }
    final ObjectNameWrapper other = (ObjectNameWrapper)obj;
    return myObjectName == null ? other.getSource() == null : myObjectName.equals(other.getSource());
  }
}