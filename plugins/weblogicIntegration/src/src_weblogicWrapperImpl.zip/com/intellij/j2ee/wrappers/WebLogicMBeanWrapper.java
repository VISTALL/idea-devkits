/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.wrappers;

import weblogic.management.ManagementException;
import weblogic.management.WebLogicMBean;
import weblogic.management.configuration.JDBCConnectionPoolMBean;
import weblogic.management.configuration.JDBCDataSourceMBean;
import weblogic.management.configuration.JDBCTxDataSourceMBean;
import weblogic.management.runtime.DeployerRuntimeMBean;
import weblogic.management.runtime.ApplicationRuntimeMBean;

import javax.management.InstanceNotFoundException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class WebLogicMBeanWrapper implements com.intellij.j2ee.wrappers.WebLogicMBean,
                                             com.intellij.j2ee.wrappers.ApplicationMBean,
                                             com.intellij.j2ee.wrappers.ServerRuntimeMBean,
                                             com.intellij.j2ee.wrappers.MBeanHome{
  private final Object mySource;

  WebLogicMBeanWrapper(Object delegate) {
    mySource = delegate;
  }

  private final WebLogicMBean getWebLogicMBean(){
    return (WebLogicMBean)mySource;
  }

  public com.intellij.j2ee.wrappers.WebLogicObjectName getObjectName() {
    return new WebLogicObjectNameWrapper(getWebLogicMBean().getObjectName());
  }

  public String getName() {
    return getWebLogicMBean().getName();
  }

  public String getFullPath() {
    return getApplicationMBean().getFullPath();
  }

  private weblogic.management.configuration.ApplicationMBean getApplicationMBean() {
    return (weblogic.management.configuration.ApplicationMBean)mySource;
  }

  public String getPath() {
    return getApplicationMBean().getPath();
  }

  public String getStagingPath() {
    return getApplicationMBean().getStagingPath();
  }

  public String getDeploymentType() {
    return getApplicationMBean().getDeploymentType();
  }

  public com.intellij.j2ee.wrappers.ComponentMBean[] getComponents() {
    weblogic.management.configuration.ComponentMBean[] original = getApplicationMBean().getComponents();
    if (original == null){
      return null;
    }
    com.intellij.j2ee.wrappers.ComponentMBean[] result = new com.intellij.j2ee.wrappers.ComponentMBean[original.length];
    for (int i = 0; i < original.length; i++) {
      result[i] = new ComponentMBeanWrapper(original[i]);
    }
    return result;
  }

  public void shutdown() throws Exception {
    getServerRuntime().shutdown();
  }

  private weblogic.management.runtime.ServerRuntimeMBean getServerRuntime() {
    return (weblogic.management.runtime.ServerRuntimeMBean)mySource;
  }

  public String getState() {
    return getServerRuntime().getState();
  }

    public String getDomainName() {
    return getMBeanHome().getDomainName();
  }

  private weblogic.management.MBeanHome getMBeanHome() {
    return (weblogic.management.MBeanHome)mySource;
  }

  public com.intellij.j2ee.wrappers.WebLogicMBean getMBean(com.intellij.j2ee.wrappers.ObjectName objectName)
    throws InstanceNotFoundExceptionWrapper {
    try {
      return createWeblogicMBeanWrapper(getMBeanHome().getMBean(((ObjectNameWrapper)objectName).getSource()));
    }
    catch (InstanceNotFoundException e) {
      throw new InstanceNotFoundExceptionWrapper(e);
    }
  }

  private com.intellij.j2ee.wrappers.WebLogicMBean createWeblogicMBeanWrapper(Object originalMBean) {
    if (originalMBean instanceof DeployerRuntimeMBean) {
      return new DeployerRuntimeMBeanWrapper((DeployerRuntimeMBean)originalMBean);
    } else if (originalMBean instanceof ApplicationRuntimeMBean) {
      return new ApplicationRuntimeMBeanWrapper((ApplicationRuntimeMBean)originalMBean);
    }
    else {
      return new WebLogicMBeanWrapper(originalMBean);
    }
  }

  public com.intellij.j2ee.wrappers.RemoteMBeanServer getMBeanServer() {
    return new RemoteMBeanServerWrapper(getMBeanHome().getMBeanServer());
  }

  public Set getMBeansByType(String s, String domain_name) {
    Set original = getMBeanHome().getMBeansByType(s, domain_name);
    HashSet result = new HashSet();
    for (Iterator iterator = original.iterator(); iterator.hasNext();) {
      result.add(createWeblogicMBeanWrapper(iterator.next()));
        }
    return result;
  }

  public DeploymentMBean createAdminMBean(String dsName, String s, String domain_name) throws ManagementExceptionWrapper {
    try {
      WebLogicMBean adminMBean = getMBeanHome().createAdminMBean(dsName, s, domain_name);
      if (adminMBean instanceof JDBCDataSourceMBean) {
        return new JDBCDataSourceMBeanWrapper((JDBCDataSourceMBean)adminMBean);
      }
      else if (adminMBean instanceof JDBCTxDataSourceMBean) {
        return new JDBCTxDataSourceMBeanWrapper((JDBCTxDataSourceMBean)adminMBean);
      }
      else if (adminMBean instanceof JDBCConnectionPoolMBean) {
        return new JDBCConnectionPoolMBeanWrapper((JDBCConnectionPoolMBean)adminMBean);
      }
      else {
        return null;
      }
    }
    catch (ManagementException e) {
      throw new ManagementExceptionWrapper(e);
    }
  }

  public com.intellij.j2ee.wrappers.WebLogicMBean getMBean(String dsName, String s) throws InstanceNotFoundExceptionWrapper {
    try {
      return createWeblogicMBeanWrapper(getMBeanHome().getMBean(dsName, s));
    }
    catch (InstanceNotFoundException e) {
      throw new InstanceNotFoundExceptionWrapper(e);
    }
  }

  public void deleteMBean(com.intellij.j2ee.wrappers.WebLogicObjectName objectName) throws Exception {
    getMBeanHome().deleteMBean(((WebLogicObjectNameWrapper)objectName).getSource());
  }

  public com.intellij.j2ee.wrappers.WebLogicMBean getAdminMBean(String serverName, String s) throws Exception {
    return createWeblogicMBeanWrapper(getMBeanHome().getAdminMBean(serverName, s));
  }

  public Object getSource() {
    return mySource;
  }

  public String toString() {
    return mySource.toString();
  }
}