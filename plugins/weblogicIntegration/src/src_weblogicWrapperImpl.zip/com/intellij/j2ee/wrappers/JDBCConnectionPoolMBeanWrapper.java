/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.wrappers;

import java.util.Properties;

public class JDBCConnectionPoolMBeanWrapper extends DeploymentMBeanWrapper implements com.intellij.j2ee.wrappers.JDBCConnectionPoolMBean {

  private final weblogic.management.configuration.JDBCConnectionPoolMBean mySource;

  JDBCConnectionPoolMBeanWrapper(weblogic.management.configuration.JDBCConnectionPoolMBean source) {
    super(source);
    mySource = source;
  }

  public void setCapacityIncrement(int capacityIncrement) throws Exception {
    mySource.setCapacityIncrement(capacityIncrement);
  }

  public void setDriverName(String driverClassname) throws Exception {
    mySource.setDriverName(driverClassname);
  }

  public void setInitialCapacity(int initialCapacity) throws Exception {
    mySource.setInitialCapacity(initialCapacity);
  }

  public void setMaxCapacity(int maxCapacity) throws Exception {
    mySource.setMaxCapacity(maxCapacity);
  }

  public void setProperties(Properties properties) throws Exception {
    mySource.setProperties(properties);
  }

  public void setURL(String url) throws Exception {
    mySource.setURL(url);
  }

  public void addTarget(MBeanHome serverMBean) throws Exception {
    mySource.addTarget((weblogic.management.configuration.TargetMBean)((WebLogicMBeanWrapper)serverMBean).getSource());
  }

  public String getName() {
    return mySource.getName();
  }
}
