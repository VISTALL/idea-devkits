/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.wrappers;

import weblogic.management.RemoteMBeanServer;
import weblogic.management.RemoteNotificationListener;

import javax.management.InstanceNotFoundException;
import javax.management.Notification;
import java.util.HashMap;
import java.util.Map;

public class RemoteMBeanServerWrapper implements com.intellij.j2ee.wrappers.RemoteMBeanServer {
  private final RemoteMBeanServer mySource;

  private final Map<RemoteNotificationListenerWrapper, RemoteNotificationListener> myListenersMap
    = new HashMap<RemoteNotificationListenerWrapper, RemoteNotificationListener>();


  RemoteMBeanServerWrapper(RemoteMBeanServer delegate) {
    mySource = delegate;
  }

  public String getServerName() {
    return mySource.getServerName();
  }

  public void removeNotificationListener(com.intellij.j2ee.wrappers.ObjectName logBroadcasterName,
                                         final RemoteNotificationListenerWrapper logNotificationListener)
    throws Exception {
    if (!myListenersMap.containsKey(logNotificationListener)) {
      return;
    }

    RemoteNotificationListener listener = myListenersMap.get(logNotificationListener);

    mySource.removeNotificationListener(((ObjectNameWrapper)logBroadcasterName).getSource(), listener);

    myListenersMap.remove(logBroadcasterName);

  }

  public void addNotificationListener(com.intellij.j2ee.wrappers.ObjectName logBroadcasterName,
                                      final RemoteNotificationListenerWrapper logNotificationListener)
    throws InstanceNotFoundExceptionWrapper {
    try {
      RemoteNotificationListener listener = new RemoteNotificationListener() {
        public void handleNotification(Notification notification, Object o) {
          logNotificationListener.handleNotification(NotificationWrapper.createNotificationInstance(notification),
                                                     o);
        }
      };

      mySource.addNotificationListener(((ObjectNameWrapper)logBroadcasterName).getSource(),
                                       listener, null, null);
      myListenersMap.put(logNotificationListener, listener);
    }
    catch (InstanceNotFoundException e) {
      throw new InstanceNotFoundExceptionWrapper(e);
    }

  }


}