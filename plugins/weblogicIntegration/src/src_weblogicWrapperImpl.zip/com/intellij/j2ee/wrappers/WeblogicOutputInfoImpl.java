/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.wrappers;

import weblogic.logging.Severities;
import weblogic.management.DeploymentNotification;
import weblogic.management.runtime.ServerStates;

import javax.management.MBeanServerNotification;

/**
 * @author nik
 */
public class WeblogicOutputInfoImpl implements WeblogicOutputInfo {
  private final String REGISTRATION_NOTIFICATION = javax.management.MBeanServerNotification.REGISTRATION_NOTIFICATION;
  private final String UNREGISTRATION_NOTIFICATION = MBeanServerNotification.UNREGISTRATION_NOTIFICATION;

  private final String RUNNING = ServerStates.RUNNING;
  private final String SHUTTING_DOWN = ServerStates.SHUTTING_DOWN;
  private final String SHUTDOWN = ServerStates.SHUTDOWN;


  private final String EMERGENCY_TEXT = Severities.EMERGENCY_TEXT;
  private final String ALERT_TEXT = Severities.ALERT_TEXT;
  private final String CRITICAL_TEXT = Severities.CRITICAL_TEXT;
  private final String ERROR_TEXT = Severities.ERROR_TEXT;
  private final String WARNING_TEXT = Severities.WARNING_TEXT;
  private final String NOTICE_TEXT = Severities.NOTICE_TEXT;
  private final String INFO_TEXT = Severities.INFO_TEXT;
  private final String DEBUG_TEXT = Severities.DEBUG_TEXT;


  private final String ACTIVATED = weblogic.management.DeploymentNotification.ACTIVATED;
  private final String ACTIVATING = DeploymentNotification.ACTIVATING;
  private final String PREPARED = DeploymentNotification.PREPARED;
  private final String PREPARING = DeploymentNotification.PREPARING;
  private final String DEACTIVATED = DeploymentNotification.DEACTIVATED;
  private final String DEACTIVATING = DeploymentNotification.DEACTIVATING;
  private final String UNPREPARED = DeploymentNotification.UNPREPARED;
  private final String UNPREPARING = DeploymentNotification.UNPREPARING;
  private final String FAILED = DeploymentNotification.FAILED;


  public int severityStringToNum(String severityStr) {
    return Severities.severityStringToNum(severityStr);
  }

  public String severityNumToString(int severity) {
    return Severities.severityNumToString(severity);
  }

  public String getRegistrationNotification() {
    return REGISTRATION_NOTIFICATION;
  }

  public String getUnregistrationNotification() {
    return UNREGISTRATION_NOTIFICATION;
  }

  public String getRunning() {
    return RUNNING;
  }

  public String getShuttingDown() {
    return SHUTTING_DOWN;
  }

  public String getShutdown() {
    return SHUTDOWN;
  }

  public String getEmergencyText() {
    return EMERGENCY_TEXT;
  }

  public String getAlertText() {
    return ALERT_TEXT;
  }

  public String getCriticalText() {
    return CRITICAL_TEXT;
  }

  public String getErrorText() {
    return ERROR_TEXT;
  }

  public String getWarningText() {
    return WARNING_TEXT;
  }

  public String getNoticeText() {
    return NOTICE_TEXT;
  }

  public String getInfoText() {
    return INFO_TEXT;
  }

  public String getDebugText() {
    return DEBUG_TEXT;
  }

  public String getActivated() {
    return ACTIVATED;
  }

  public String getActivating() {
    return ACTIVATING;
  }

  public String getPrepared() {
    return PREPARED;
  }

  public String getPreparing() {
    return PREPARING;
  }

  public String getDeactivated() {
    return DEACTIVATED;
  }

  public String getDeactivating() {
    return DEACTIVATING;
  }

  public String getUnprepared() {
    return UNPREPARED;
  }

  public String getUnpreparing() {
    return UNPREPARING;
  }

  public String getFailed() {
    return FAILED;
  }
}
