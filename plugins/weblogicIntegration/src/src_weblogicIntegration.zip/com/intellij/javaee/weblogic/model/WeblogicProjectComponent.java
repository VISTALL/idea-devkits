/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.model;

import com.intellij.codeInsight.intention.IntentionManager;
import com.intellij.javaee.JavaeeDeploymentDescriptor;
import com.intellij.javaee.weblogic.CreateEjbIntention;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.WeblogicDomAnnotator;
import com.intellij.javaee.weblogic.model.impl.WeblogicEjbJarImpl;
import com.intellij.javaee.weblogic.model.impl.persistence.WeblogicRdbmsBeanImpl;
import com.intellij.javaee.weblogic.model.impl.persistence.WeblogicRdbmsJarImpl;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsBean;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsJar;
import com.intellij.javaee.weblogic.module.WLEjbModuleProperties;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.module.Module;
import com.intellij.psi.xml.XmlFile;
import com.intellij.util.xml.DomFileDescription;
import com.intellij.util.xml.DomManager;
import com.intellij.util.xml.highlighting.DomElementsAnnotator;
import org.jetbrains.annotations.NotNull;

/**
 * @author peter
 */
public class WeblogicProjectComponent implements ProjectComponent{

  public WeblogicProjectComponent(DomManager domManager, IntentionManager intentionManager) {
    domManager.registerFileDescription(new DomFileDescription<WeblogicEjbJar>(WeblogicEjbJar.class, "weblogic-ejb-jar") {
      protected void initializeFileDescription() {
        registerImplementation(WeblogicEjbJar.class, WeblogicEjbJarImpl.class);
      }

      public DomElementsAnnotator createAnnotator() {
        return new WeblogicDomAnnotator();
      }

      public boolean isMyFile(XmlFile file, final Module module) {
        final WLEjbModuleProperties moduleProperties = WLEjbModuleProperties.getInstance(module);
        if (moduleProperties == null) return false;
        final JavaeeDeploymentDescriptor descriptor = moduleProperties.getEjbJarDeploymentDescriptor();
        return descriptor != null && file.equals(descriptor.getXmlFile());
      }

      public boolean isAutomaticHighlightingEnabled() {
        return false;
      }
    });
    domManager.registerFileDescription(new DomFileDescription<WeblogicRdbmsJar>(WeblogicRdbmsJar.class, "weblogic-rdbms-jar") {
      protected void initializeFileDescription() {
        registerImplementation(WeblogicRdbmsJar.class, WeblogicRdbmsJarImpl.class);
        registerImplementation(WeblogicRdbmsBean.class, WeblogicRdbmsBeanImpl.class);
      }

      public boolean isMyFile(XmlFile file, final Module module) {
        final WLEjbModuleProperties moduleProperties = WLEjbModuleProperties.getInstance(module);
        if (moduleProperties == null) return false;
        final JavaeeDeploymentDescriptor descriptor = moduleProperties.getCmpRdbmsDescriptor();
        return descriptor != null && file.equals(descriptor.getXmlFile());
      }

      public boolean isAutomaticHighlightingEnabled() {
        return false;
      }
    });

    intentionManager.registerIntentionAndMetaData(new CreateEjbIntention(), WeblogicBundle.message("intention.family.name.weblogic"));
  }

  public void projectOpened() {
  }

  public void projectClosed() {
  }

  @NotNull
  public String getComponentName() {
    return "WeblogicProjectComponent";
  }

  public void initComponent() {

  }

  public void disposeComponent() {
  }
}
