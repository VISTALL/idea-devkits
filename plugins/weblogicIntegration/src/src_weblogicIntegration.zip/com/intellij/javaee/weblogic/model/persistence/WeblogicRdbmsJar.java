// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:weblogic-rdbms-jarType interface.
 */
public interface WeblogicRdbmsJar extends JavaeeDomModelElement {

	/**
	 * Returns the list of weblogic-rdbms-bean children.
	 * @return the list of weblogic-rdbms-bean children.
	 */
	@NotNull
	List<WeblogicRdbmsBean> getWeblogicRdbmsBeans();
	/**
	 * Adds new child to the list of weblogic-rdbms-bean children.
	 * @return created child
	 */
	WeblogicRdbmsBean addWeblogicRdbmsBean();


	/**
	 * Returns the list of weblogic-rdbms-relation children.
	 * @return the list of weblogic-rdbms-relation children.
	 */
	List<WeblogicRdbmsRelation> getWeblogicRdbmsRelations();
	/**
	 * Adds new child to the list of weblogic-rdbms-relation children.
	 * @return created child
	 */
	WeblogicRdbmsRelation addWeblogicRdbmsRelation();


	/**
	 * Returns the value of the order-database-operations child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the order-database-operations child.
	 */
	GenericDomValue<Boolean> getOrderDatabaseOperations();


	/**
	 * Returns the value of the enable-batch-operations child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the enable-batch-operations child.
	 */
	GenericDomValue<Boolean> getEnableBatchOperations();


	/**
	 * Returns the value of the create-default-dbms-tables child.
	 * @return the value of the create-default-dbms-tables child.
	 */
	GenericDomValue<String> getCreateDefaultDbmsTables();


	/**
	 * Returns the value of the validate-db-schema-with child.
	 * @return the value of the validate-db-schema-with child.
	 */
	GenericDomValue<String> getValidateDbSchemaWith();


	/**
	 * Returns the value of the database-type child.
	 * @return the value of the database-type child.
	 */
	GenericDomValue<String> getDatabaseType();


	/**
	 * Returns the value of the default-dbms-tables-ddl child.
	 * @return the value of the default-dbms-tables-ddl child.
	 */
	GenericDomValue<String> getDefaultDbmsTablesDdl();


	/**
	 * Returns the value of the compatibility child.
	 * @return the value of the compatibility child.
	 */
	Compatibility getCompatibility();


}
