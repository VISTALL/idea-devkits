/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.actions.versionsBefore9;

import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.WeblogicConnectionPoolInfo;
import com.intellij.javaee.weblogic.actions.WeblogicCreateDatasourceDialog;
import com.intellij.javaee.weblogic.dataSource.WeblogicDataSourceInfo;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.versionsBefore9.WeblogicVersionBefore9AbstractInstance;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.ui.OptionGroup;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WeblogicBefore9CreateDatasourceDialog extends WeblogicCreateDatasourceDialog {
  private JComboBox myPool;
  private JTextField myConnectionWaitPeriod;
  private JCheckBox myWaitForConnectionEnabled;
  private JRadioButton myTxDataSource;
  private JRadioButton myNonTxDataSource;
  private JCheckBox myEnableTwoPhaseCommit;
  private Project myProject;

  public WeblogicBefore9CreateDatasourceDialog(Project project, WeblogicVersionBefore9AbstractInstance instance, String dsName) {
    super(project, instance, dsName);
    myProject = project;
    init();
    setTitle(WeblogicBundle.message("dialog.title.create.new.datasource"));
  }

  protected WeblogicVersionBefore9AbstractInstance getWeblogicInstance() {
    return (WeblogicVersionBefore9AbstractInstance)super.getWeblogicInstance();
  }

  protected JPanel createConnectionSettingsPanel() {
    final JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    JLabel label = new JLabel(WeblogicBundle.message("label.create.datasource.connection.pool"));
    panel.add(label, BorderLayout.WEST);

    String[] pools = getWeblogicInstance().getConfiguredConnectionPoolNames();
    myPool = new JComboBox(pools);
    label.setLabelFor(myPool);
    panel.add(myPool, BorderLayout.WEST);

    final JButton createPoolButton = new JButton(WeblogicBundle.message("button.create.new"));
    createPoolButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        String pool = createNewPool();
        if (pool == null) return;
        myPool.addItem(pool);
        myPool.setSelectedItem(pool);
      }
    });
    panel.add(createPoolButton, BorderLayout.CENTER);

    return panel;
  }

  private String createNewPool() {
    final String[] name = new String[1];
    WeblogicCreateConnectionPoolDialog dialog = new WeblogicCreateConnectionPoolDialog(myProject){
      protected void doOKAction() {
        try {
          final WeblogicConnectionPoolInfo connectionPoolInfo = getConnectionPoolInfo();
          getWeblogicInstance().createConnectionPool(connectionPoolInfo);
          name[0] = connectionPoolInfo.name;
          super.doOKAction();
        }
        catch (Exception e) {
          Messages.showErrorDialog(WeblogicBundle.message("message.text.error.creating.database.pool", e.getMessage()),
                                   WeblogicBundle.message("message.title.error.creating.pool"));
        }
      }
    };
    dialog.show();
    if (!dialog.isOK()) return null;
    return name[0];
  }

  protected JPanel createDataSourceTypeHolder() {
    final JPanel panel = new JPanel(new GridBagLayout());
    GridBagConstraints gb = new GridBagConstraints();
    gb.fill = GridBagConstraints.BOTH;
    gb.anchor = GridBagConstraints.NORTHWEST;
    gb.gridy = -1;
    gb.gridx = 0;
    gb.insets = new Insets(4, 8, 4, 8);

    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 1;
    myTxDataSource = new JRadioButton(WeblogicBundle.message("radio.create.datasource.tx.data.source"));
    panel.add(myTxDataSource, gb);

    gb.gridx++;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    gb.weightx = 1;
    myNonTxDataSource = new JRadioButton(WeblogicBundle.message("radio.create.datasource.non.tx.data.source"));
    panel.add(myNonTxDataSource, gb);

    final ButtonGroup group = new ButtonGroup();
    group.add(myTxDataSource);
    group.add(myNonTxDataSource);

    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 1;
    final OptionGroup txOptionsPanel = new OptionGroup(WeblogicBundle.message("option.group.create.datasource.tx.parameters"));
    myEnableTwoPhaseCommit = new JCheckBox(WeblogicBundle.message("checkbox.create.datasource.enable.two.phase.commit"));
    txOptionsPanel.add(myEnableTwoPhaseCommit);
    panel.add(txOptionsPanel.createPanel(), gb);

    gb.gridx++;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    gb.weightx = 1;
    final OptionGroup nonTxOptionsPanel = new OptionGroup(WeblogicBundle.message("option.group.create.datasource.non.tx.parameters"));
    final JPanel conn = new JPanel(new GridBagLayout());
    JLabel label = new JLabel(WeblogicBundle.message("label.create.datasource.connection.wait.period"));
    conn.add(label, new GridBagConstraints(0,0,1,1,0,1,GridBagConstraints.WEST,GridBagConstraints.NONE,new Insets(0,0,0,0), 0,0));
    myConnectionWaitPeriod = new JTextField("1");
    label.setLabelFor(myConnectionWaitPeriod);
    conn.add(myConnectionWaitPeriod, new GridBagConstraints(1,0,GridBagConstraints.REMAINDER,1,1,1,GridBagConstraints.EAST,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
    nonTxOptionsPanel.add(conn);

    myWaitForConnectionEnabled = new JCheckBox(WeblogicBundle.message("checkbox.create.datasource.wait.for.connection"), false);
    nonTxOptionsPanel.add(myWaitForConnectionEnabled);
    panel.add(nonTxOptionsPanel.createPanel(), gb);


    myTxDataSource.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        enableElements(txOptionsPanel.getComponents(), myTxDataSource.isSelected());
        enableElements(nonTxOptionsPanel.getComponents(), !myTxDataSource.isSelected());
      }
    });
    myNonTxDataSource.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        enableElements(txOptionsPanel.getComponents(), !myNonTxDataSource.isSelected());
        enableElements(nonTxOptionsPanel.getComponents(), myNonTxDataSource.isSelected());
      }
    });
    myNonTxDataSource.setSelected(true);
    return panel;
  }

  protected String getDimensionServiceKey() {
    return "#com.intellij.javaee.weblogic.actions.WeblogicCreateDatasourceDialog";
  }

  public WeblogicDataSourceInfo getDataSourceInfo() throws Exception {
    final WeblogicDataSourceInfo info = super.getDataSourceInfo();

    info.connectionPoolName = (String) myPool.getSelectedItem();
    if (info.connectionPoolName == null) {
      throw new Exception(WeblogicBundle.message("error.create.datasource.connection.pool.is.not.specified"));
    }

    info.connectionWaitPeriod = parseInt(myConnectionWaitPeriod.getText());
    info.waitForConnectionEnabled = myWaitForConnectionEnabled.isSelected();

    info.enableTwoPhaseCommit = myEnableTwoPhaseCommit.isSelected();
    info.isTxDataSource = myTxDataSource.isSelected();
    return info;
  }

  protected void doOKAction() {
    try {
      final WeblogicDataSourceInfo dataSourceInfo = getDataSourceInfo();
      getWeblogicInstance().createDatasource(dataSourceInfo);
      super.doOKAction();
    }
    catch (Exception e) {
      Messages.showMessageDialog(WeblogicBundle.message("message.text.error.creating.new.data.source", e.getMessage()),
                                 WeblogicBundle.message("message.title.error"), Messages.getErrorIcon());
    }
  }
}
