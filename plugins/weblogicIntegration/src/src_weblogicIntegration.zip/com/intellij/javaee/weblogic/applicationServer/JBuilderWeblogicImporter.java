/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.applicationServer;

import com.intellij.javaee.appServerIntegrations.ApplicationServerInfo;
import com.intellij.javaee.appServerIntegrations.*;
import com.intellij.javaee.appServerIntegrations.CantFindApplicationServerJarsException;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.openapi.util.Pair;
import com.intellij.util.projectImport.JBuilderProjectImportHelper;
import com.intellij.util.projectImport.JBuilderProjectImportWebHelper;
import org.jetbrains.annotations.Nullable;

/**
 * User: anna
 * Date: May 23, 2005
 */
public class JBuilderWeblogicImporter extends JBuilderProjectImportHelper implements JBuilderProjectImportWebHelper {
  public String getComponentName() {
    return "JBuilderWeblogicImporter";
  }

  @Nullable public Pair<? extends ApplicationServerHelper, String > getAppServerHelperWithIntegrationName(final String home, final String version) {
    final WeblogicPersistentData weblogicPersistentData = new WeblogicPersistentData();
    weblogicPersistentData.BEA_HOME = home;
    weblogicPersistentData.VERSION = version;
    try {
      new WeblogicApplicationServerHelper().getApplicationServerInfo(weblogicPersistentData);
    }
    catch (CantFindApplicationServerJarsException e) {
      return null;
    }
    return Pair.create(new WeblogicApplicationServerHelper(){
      public ApplicationServerInfo getApplicationServerInfo(ApplicationServerPersistentData persistentData)
                                                                                                            throws CantFindApplicationServerJarsException {
        final WeblogicPersistentData weblogicPersistentData = ((WeblogicPersistentData)persistentData);
        weblogicPersistentData.BEA_HOME = home;
        weblogicPersistentData.VERSION = version;
        return super.getApplicationServerInfo(persistentData);
      }
    }, WeblogicBundle.message("weblogic.integration.presentable.name"));
  }

  public void initComponent() {

  }

  public void disposeComponent() {

  }
 
}
