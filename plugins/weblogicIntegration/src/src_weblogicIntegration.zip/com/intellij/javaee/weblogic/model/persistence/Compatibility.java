// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

/**
 * http://www.bea.com/ns/weblogic/90:compatibilityType interface.
 */
public interface Compatibility extends JavaeeDomModelElement {

	/**
	 * Returns the value of the serialize-byte-array-to-oracle-blob child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the serialize-byte-array-to-oracle-blob child.
	 */
	GenericDomValue<Boolean> getSerializeByteArrayToOracleBlob();


	/**
	 * Returns the value of the serialize-char-array-to-bytes child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the serialize-char-array-to-bytes child.
	 */
	GenericDomValue<Boolean> getSerializeCharArrayToBytes();


	/**
	 * Returns the value of the allow-readonly-create-and-remove child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the allow-readonly-create-and-remove child.
	 */
	GenericDomValue<Boolean> getAllowReadonlyCreateAndRemove();


	/**
	 * Returns the value of the disable-string-trimming child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the disable-string-trimming child.
	 */
	GenericDomValue<Boolean> getDisableStringTrimming();


	/**
	 * Returns the value of the finders-return-nulls child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the finders-return-nulls child.
	 */
	GenericDomValue<Boolean> getFindersReturnNulls();


}
