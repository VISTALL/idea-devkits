/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.jdbc;

import org.jetbrains.annotations.NonNls;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.jdbc.JDBCDataSourceWL9Bean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.TargetWL9MBean;

/**
 * @author nik
 */
public class JDBCSystemResourceWL9MBean extends AbstractWL9MBean {
  @NonNls private static final String JDBC_RESOURCE_NAME = "JDBCResource";
  private static final MethodSignature ADD_TARGET_SIGNATURE = new MethodSignature("addTarget", ObjectName.class);

  public JDBCSystemResourceWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public JDBCDataSourceWL9Bean getJDBCResource() {
    return new JDBCDataSourceWL9Bean(getConnection(), getChild(JDBC_RESOURCE_NAME));
  }

  public void setNotes(String notes) {
    setAttribute("Notes", notes);
  }

  public void setDeploymentOrder(int deploymentOrder) {
    setAttribute("DeploymentOrder", deploymentOrder);
  }

  public void addTarget(TargetWL9MBean target) {
    invoke(ADD_TARGET_SIGNATURE, target.getBeanName());
  }

  public String getName() {
    return (String)getAttribute("Name");
  }

}
