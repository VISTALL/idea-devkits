/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9;

import com.intellij.openapi.diagnostic.Logger;
import org.jetbrains.annotations.NonNls;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author nik
 */
public class DeployerHelperWL9 {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.DeployerHelperWL9");
  @NonNls private static final String DEPLOYER_HELPER_CLASS_NAME = "weblogic.deploy.utils.DeployerHelper";
  @NonNls private static final String UPLOAD_SOURCE_METHOD_NAME = "uploadSource";
  private Method myUploadSourceMethod;
  private Object myInstance;

  public DeployerHelperWL9(ClassLoader loader) {
    try {
      final Class deploymentHelperClass = Class.forName(DEPLOYER_HELPER_CLASS_NAME, true, loader);
      myUploadSourceMethod = deploymentHelperClass.getMethod(UPLOAD_SOURCE_METHOD_NAME, String.class, String.class, String.class, String.class, String[].class, String.class);
      final Constructor constructor = deploymentHelperClass.getDeclaredConstructor();
      constructor.setAccessible(true);
      myInstance = constructor.newInstance();
    }
    catch (Exception e) {
      LOG.error(e);
    }
  }


  public String uploadSource(String adminUrl, String user, String password, String sourcePath, String name) throws Exception {
    try {
      return (String)myUploadSourceMethod.invoke(myInstance, adminUrl, user, password, sourcePath, null, name);
    }
    catch (IllegalAccessException e) {
      LOG.error(e);
    }
    catch (IllegalArgumentException e) {
      LOG.error(e);
    }
    catch (InvocationTargetException e) {
    }
    return null;
  }

}
