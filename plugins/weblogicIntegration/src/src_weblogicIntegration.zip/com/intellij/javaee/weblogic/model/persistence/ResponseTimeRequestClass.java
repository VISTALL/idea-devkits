// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:response-time-request-classType interface.
 */
public interface ResponseTimeRequestClass extends JavaeeDomModelElement {

	/**
	 * Returns the value of the name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdStringType documentation</h3>
	 * This type adds an "id" attribute to xsd:string.
	 * </pre>
	 * @return the value of the name child.
	 */
	@NotNull
	GenericDomValue<String> getName();


	/**
	 * Returns the value of the goal-ms child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:integer.
	 * </pre>
	 * @return the value of the goal-ms child.
	 */
	@NotNull
	GenericDomValue<Integer> getGoalMs();


}
