/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.actions.version9;

import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.WeblogicConnectionPoolInfo;
import com.intellij.javaee.weblogic.actions.WeblogicCreateDatasourceDialog;
import com.intellij.javaee.weblogic.dataSource.WeblogicDataSourceInfo;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.Weblogic9AbstractInstance;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;

import javax.swing.*;

/**
 * @author nik
 */
public class Weblogic9CreateDatasourceDialog extends WeblogicCreateDatasourceDialog {
  private JRadioButton myNoneTransactionProtocol;
  private JRadioButton myOnePhaseProtocol;
  private JRadioButton myTwoPhaseCommit;
  private ConnectionSettingsPanelWrapper myConnectionSettings;

  public Weblogic9CreateDatasourceDialog(Project project, final Weblogic9AbstractInstance instance, final String dsName) {
    super(project, instance, dsName);
    init();
    setTitle(WeblogicBundle.message("dialog.title.create.new.datasource"));
  }

  protected Weblogic9AbstractInstance getWeblogicInstance() {
    return (Weblogic9AbstractInstance)super.getWeblogicInstance();
  }

  protected JPanel createConnectionSettingsPanel() {
    myConnectionSettings = new ConnectionSettingsPanelWrapper();
    return myConnectionSettings.mySettingsPanel;
  }

  protected JPanel createDataSourceTypeHolder() {
    final JPanel panel = new JPanel();
    panel.setBorder(BorderFactory.createTitledBorder(WeblogicBundle.message("option.group.create.datasource.global.transaction.protocol")));
    myNoneTransactionProtocol = new JRadioButton(WeblogicBundle.message("radio.create.datasource.protocol.none"), false);
    panel.add(myNoneTransactionProtocol);
    myOnePhaseProtocol = new JRadioButton(WeblogicBundle.message("radio.create.datasource.protocol.one.phase.commit"), false);
    panel.add(myOnePhaseProtocol);
    myTwoPhaseCommit = new JRadioButton(WeblogicBundle.message("radio.create.datasource.protocol.two.phase.commit"), true);
    panel.add(myTwoPhaseCommit);
    final ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(myNoneTransactionProtocol);
    buttonGroup.add(myOnePhaseProtocol);
    buttonGroup.add(myTwoPhaseCommit);
    return panel;
  }

  protected WeblogicDataSourceInfo getDataSourceInfo() throws Exception {
    final WeblogicDataSourceInfo info = super.getDataSourceInfo();
    info.isTxDataSource = !myNoneTransactionProtocol.isSelected();
    info.enableTwoPhaseCommit = myTwoPhaseCommit.isSelected();
    return info;
  }

  protected void doOKAction() {
    try {
      final WeblogicDataSourceInfo dataSourceInfo = getDataSourceInfo();
      final WeblogicConnectionPoolInfo connectionPoolInfo = myConnectionSettings.getConnectionPoolInfo();
      getWeblogicInstance().createDatasource(dataSourceInfo, connectionPoolInfo);
      super.doOKAction();
    }
    catch (Exception e) {
      Messages.showMessageDialog(WeblogicBundle.message("message.text.error.creating.new.data.source", e.getMessage()),
                                 WeblogicBundle.message("message.title.error"), Messages.getErrorIcon());
    }
  }

  private static class ConnectionSettingsPanelWrapper {
    private JPanel mySettingsPanel;
    private JTextField myDriverClassname;
    private JTextField myDatabaseUrl;
    private JTextField myProperties;
    private JTextField myMaxCapacity;
    private JTextField myCapacityIncrement;
    private JTextField myInitialCapacity;
    private JLabel myDatabaseUrlLabel;
    private JLabel myDriverClassnameLabel;
    private JLabel myPropertiesLabel;
    private JLabel myInitialCapacityLabel;
    private JLabel myMaxCapacityLabel;
    private JLabel myCapacityIncrementLabel;

    public ConnectionSettingsPanelWrapper() {
      myDriverClassnameLabel.setLabelFor(myDriverClassname);
      myPropertiesLabel.setLabelFor(myProperties);
      myDatabaseUrlLabel.setLabelFor(myDatabaseUrl);
      myMaxCapacityLabel.setLabelFor(myMaxCapacity);
      myInitialCapacityLabel.setLabelFor(myInitialCapacity);
      myCapacityIncrementLabel.setLabelFor(myCapacityIncrement);
    }

    private WeblogicConnectionPoolInfo getConnectionPoolInfo() throws Exception {
      final WeblogicConnectionPoolInfo poolInfo = new WeblogicConnectionPoolInfo();
      poolInfo.driverClassname = myDriverClassname.getText();
      poolInfo.url = myDatabaseUrl.getText();
      poolInfo.properties = WeblogicCreateDatasourceDialog.parseProperties(myProperties.getText());
      poolInfo.initialCapacity = WeblogicCreateDatasourceDialog.parseInt(myInitialCapacity.getText());
      poolInfo.maxCapacity = WeblogicCreateDatasourceDialog.parseInt(myMaxCapacity.getText());
      poolInfo.capacityIncrement = WeblogicCreateDatasourceDialog.parseInt(myCapacityIncrement.getText());
      return poolInfo;
    }
  }
}
