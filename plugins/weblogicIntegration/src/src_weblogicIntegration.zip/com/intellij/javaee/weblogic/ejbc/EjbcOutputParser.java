/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.ejbc;

import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.ejb.EjbModuleUtil;
import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.javaee.model.common.ejb.EnterpriseBean;
import com.intellij.openapi.application.ReadAction;
import com.intellij.openapi.application.Result;
import com.intellij.openapi.diagnostic.Logger;
import org.jetbrains.annotations.NonNls;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Alexey Kudravtsev
 */
class EjbcOutputParser extends AbstractOutputParser {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.weblogic.ejbc.EjbcOutputParser");
  @NonNls protected static final String MESSAGE_PATTERN = "(?: Error from ejbc:\\s+)?((In EJB '?(\\S+)'?,)?\\s*\\S[^\\n\\r]+)[\\r\\n]*(.*)";
  @NonNls protected static final String ERROR_PATTERN = "^\\s*ERROR:(.+[^\\r\\n])?[\\r\\n]+(ERROR.*)";
  @NonNls protected static final String FOOTER_PATTERN = "^\\s*ERROR: (ejbc found errors)|(ejbc couldn't invoke compiler)\\s*$";

  public EjbcOutputParser(JavaeeFacet facet) {
    super(facet);
  }

  public synchronized void parseAvailableOutput() {
    String text = myOutput.substring(myCurrentPosition);
    LOG.debug(text);

    Pattern messagePattern = Pattern.compile(MESSAGE_PATTERN, Pattern.DOTALL);
    Pattern generalErrorPattern = Pattern.compile(ERROR_PATTERN, Pattern.DOTALL);
    Pattern footerPattern = Pattern.compile(FOOTER_PATTERN, Pattern.DOTALL);
    while (text != null) {
      Matcher matcher = footerPattern.matcher(text);
      if (matcher.matches()) {
        myCurrentPosition += text.length();
        break;
      }
      matcher = generalErrorPattern.matcher(text);
      if (!matcher.matches()) break;
      String message = matcher.group(1);
      text = matcher.group(2);
      myCurrentPosition += matcher.start(2);
      EnterpriseBean ejb = null;
      // try to parse message for details: ejb name etc
      matcher = messagePattern.matcher(message);
      if (matcher.matches()) {
        final String ejbName = matcher.group(3);
        ejb = new ReadAction<EnterpriseBean>() {
          protected void run(Result<EnterpriseBean> result) throws Throwable {
            if (myFacet instanceof EjbFacet) {
              final EnterpriseBean bean = EjbModuleUtil.findEjbByName((EjbFacet)myFacet, ejbName);
              LOG.debug("EJB (from ejbc for name '" + ejbName + "') = " + bean);
              result.setResult(bean);
            }
          }
        }.execute().getResultObject();
      }
      addMessage(new EjbcError(message, myFacet, ejb));
    }
  }

}
