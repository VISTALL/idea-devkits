// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

/**
 * http://www.bea.com/ns/weblogic/90:transport-requirementsType interface.
 */
public interface TransportRequirements extends JavaeeDomModelElement {

	/**
	 * Returns the value of the integrity child.
	 * @return the value of the integrity child.
	 */
	GenericDomValue<String> getIntegrity();


	/**
	 * Returns the value of the confidentiality child.
	 * @return the value of the confidentiality child.
	 */
	GenericDomValue<String> getConfidentiality();


	/**
	 * Returns the value of the client-cert-authentication child.
	 * @return the value of the client-cert-authentication child.
	 */
	GenericDomValue<String> getClientCertAuthentication();


}
