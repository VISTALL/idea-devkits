/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.ejbc;

import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.openapi.compiler.CompilerMessageCategory;
import org.jetbrains.annotations.NonNls;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Alexey Kudravtsev
 */
class AppcOutputParser extends AbstractOutputParser {
  @NonNls private static final String MESSAGE_PATTERN_TEXT = "\\[.*\\]Errors encountered while compiling module '.*':\n\r\n(.*)\n\r\n";
  @NonNls private static final String NOTE_PATTERN_TEXT = "Note:.*";
  private static final Pattern MESSAGE_PATTERN = Pattern.compile(MESSAGE_PATTERN_TEXT, Pattern.DOTALL);
  private static final Pattern NOTE_PATTERN = Pattern.compile(NOTE_PATTERN_TEXT, Pattern.DOTALL);

  public AppcOutputParser(JavaeeFacet facet) {
    super(facet);
  }

  public synchronized void parseAvailableOutput() {
    String text = myOutput.substring(myCurrentPosition);

    Matcher matcher = MESSAGE_PATTERN.matcher(text);
    if (matcher.matches()) {
      myCurrentPosition += text.length();
      String message = matcher.group(1);
      final EjbcError error = new EjbcError(message, myFacet, null);
      addMessage(error);
    }

    if (NOTE_PATTERN.matcher(text).matches()) {
      myCurrentPosition += text.length();
      addMessage(new EjbcError(text, myFacet, null, CompilerMessageCategory.WARNING));
    }
  }
}
