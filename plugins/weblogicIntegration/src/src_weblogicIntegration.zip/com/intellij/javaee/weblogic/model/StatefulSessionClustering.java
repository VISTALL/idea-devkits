// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

/**
 * http://www.bea.com/ns/weblogic/90:stateful-session-clusteringType interface.
 */
public interface StatefulSessionClustering extends JavaeeDomModelElement {

	/**
	 * Returns the value of the home-is-clusterable child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the home-is-clusterable child.
	 */
	GenericDomValue<Boolean> getHomeIsClusterable();


	/**
	 * Returns the value of the home-load-algorithm child.
	 * @return the value of the home-load-algorithm child.
	 */
	GenericDomValue<String> getHomeLoadAlgorithm();


	/**
	 * Returns the value of the home-call-router-class-name child.
	 * @return the value of the home-call-router-class-name child.
	 */
	GenericDomValue<String> getHomeCallRouterClassName();


	/**
	 * Returns the value of the use-serverside-stubs child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the use-serverside-stubs child.
	 */
	GenericDomValue<Boolean> getUseServersideStubs();


	/**
	 * Returns the value of the replication-type child.
	 * @return the value of the replication-type child.
	 */
	GenericDomValue<String> getReplicationType();


}
