// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:resource-env-descriptionType interface.
 */
public interface ResourceEnvDescription extends JavaeeDomModelElement {

	/**
	 * Returns the value of the resource-env-ref-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:jndi-nameType documentation</h3>
	 * The jndi-nameType type designates a JNDI name in the
	 * 	Deployment Component's environment and is relative to the
	 * 	java:comp/env context.  A JNDI name must be unique within the
	 * 	Deployment Component.
	 * </pre>
	 * @return the value of the resource-env-ref-name child.
	 */
	@NotNull
	GenericDomValue<String> getResourceEnvRefName();


	/**
	 * Returns the value of the jndi-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the value of the jndi-name child.
	 */
	@NotNull
	GenericDomValue<String> getJndiName();


	/**
	 * Returns the value of the resource-link child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the value of the resource-link child.
	 */
	@NotNull
	GenericDomValue<String> getResourceLink();


}
