/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.beaInstallation;

import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegration;
import com.intellij.openapi.util.*;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsBean;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsJar;
import com.intellij.javaee.weblogic.model.persistence.FieldGroup;
import com.intellij.javaee.weblogic.model.WeblogicEnterpriseBean;
import com.intellij.javaee.weblogic.model.WeblogicEjbJar;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.xml.GenericDomValue;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Namespace;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class WeblogicUtil {
  @NonNls private static final String CONFIG_DIR = "config";
  @NonNls private static final String CONFIG_XML = "config.xml";
  @NonNls private static final String REGISTRY_XML = "registry.xml";

  @NonNls private static final String BEA_DIR = "/bea";
  @NonNls private static final String C_BEA_DIR = "C:/bea";
  @NonNls private static final String D_BEA_DIR = "D:/bea";
  @NonNls private static final String LINUX_BEA_DIR = "/usr/local/bea";
  private static final File[] CANDIDATES = new File[]{
    new File(BEA_DIR),
    new File(C_BEA_DIR),
    new File(D_BEA_DIR),
    new File(LINUX_BEA_DIR)
  };
  @NonNls private static final String HOST_ELEMENT_NAME = "host";
  @NonNls private static final String PRODUCT_ELEMENT_NAME = "product";
  @NonNls private static final String RELEASE_ELEMENT_NAME = "release";
  @NonNls private static final String COMPONENT_ELEMENT_NAME = "component";
  @NonNls private static final String WEBLOGIC_NAME = "WebLogic Server";
  @NonNls private static final String INSTALL_DIR_ATTR = "InstallDir";
  @NonNls private static final String JAVA_HOME_ATTR = "JavaHome";
  @NonNls private static final String VERSION_ATTR = "version";

  @NonNls private static final String DOMAIN_ELEMENT_NAME = "Domain";
  @NonNls private static final String DOMAIN_9X_ELEMENT_NAME = "domain";
  @NonNls private static final String SERVER_ELEMENT_NAME = "Server";
  @NonNls private static final String SERVER_9X_ELEMENT_NAME = "server";
  @NonNls private static final String NAME_9X_ELEMENT_NAME = "name";
  @NonNls private static final String CONFIGURATION_VERSION_9X_ELEMENT_NAME = "configuration-version";
  @NonNls private static final String CONFIGURATION_VERSION_ATTRIBUTE_NAME = "ConfigurationVersion";
  @NonNls private static final String NAME_ATTR = "name";
  @NonNls private static final String NAME2_ATTR = "Name";
  @NonNls private static final String LISTEN_PORT_ATTR = "ListenPort";
  @NonNls private static final String LISTEN_PORT_9X_ELEMENT_NAME = "listen-port";
  @NonNls private static final String ADMIN_SERVER_NAME_CHILD = "admin-server-name";
  @NonNls private static final String WL9x_CONFIG_URI_1 = "http://www.bea.com/ns/weblogic/config";
  @NonNls private static final String WL9x_CONFIG_URI_2 = "http://www.bea.com/ns/weblogic/90/domain";
  @NonNls private static final String WL9x_CONFIG_URI_3 = "http://www.bea.com/ns/weblogic/920/domain";
  private static final Set<Namespace> WL9x_CONFIG_NAMESPACES = new HashSet<Namespace>(
    Arrays.asList(new Namespace[]{
      Namespace.getNamespace(WL9x_CONFIG_URI_1),
      Namespace.getNamespace(WL9x_CONFIG_URI_2),
      Namespace.getNamespace(WL9x_CONFIG_URI_3)
    }));

  @NonNls private static final String APPLICATIONS_DIR_7x8x = "applications";
  @NonNls private static final String SERVERS_DIR = "servers";
  @NonNls private static final String LOGS_DIR = "logs";
  @NonNls private static final String LOG_SUFFIX = ".log";
  @NonNls private static final String CMD_FILE = "startWebLogic.cmd";
  @NonNls private static final String SH_FILE = "startWebLogic.sh";
  @NonNls private static final String APPLICATIONS_DIR_9x = "autodeploy";
  private static File[] ourBeaRootCandidates;
  private static Map<File, Pair<Long, BeaDomain>> ourCachedDomains = new HashMap<File, Pair<Long, BeaDomain>>();

  private WeblogicUtil() {}

  public static BeaInstallation[] getAllPossibleServerLocations() {
    final List<BeaInstallation> result = new ArrayList<BeaInstallation>(2);
    for (File candidate : getBeaRootCandidates()) {
      final BeaInstallation installation = getInstallationByLocation(candidate);
      if (installation.isValid()) {
        result.add(installation);
      }
    }
    return result.toArray(new BeaInstallation[result.size()]);
  }

  private static File[] getBeaRootCandidates() {
    if (ourBeaRootCandidates == null) {
      final ArrayList<File> roots = new ArrayList<File>();
      final Set<String> rootPaths = new HashSet<String>();
      for (File candidate : CANDIDATES) {
        try {
          final String newPath = candidate.getCanonicalPath();
          if (!rootPaths.contains(newPath)) {
            rootPaths.add(newPath);
            roots.add(candidate);
          }
        }
        catch (IOException e) {
        }
      }
      ourBeaRootCandidates = roots.toArray(new File[roots.size()]);
    }
    return ourBeaRootCandidates;
  }

  public static BeaInstallation getInstallationByLocation(File file) {
    return new BeaInstallation(new File(file.getAbsolutePath()));
  }

  public static BeaVersion[] loadVersions(File location) {
    final File registry = new File(location, REGISTRY_XML);
    if (!registry.isFile()) {
      return BeaVersion.EMPTY_ARRAY;
    }
    try {
      Document document = JDOMUtil.loadDocument(registry);
      Element rootElement = document.getRootElement();
      return getAllVersionsFromHosts(rootElement.getChildren(HOST_ELEMENT_NAME));
    }
    catch (Exception e) {
      return BeaVersion.EMPTY_ARRAY;
    }
  }

  private static BeaVersion[] getAllVersionsFromHosts(List<Element> hosts) {
    final ArrayList<BeaVersion> result = new ArrayList<BeaVersion>();
    final List<Element> products = new ArrayList<Element>();
    for (final Element host : hosts) {
      products.addAll(host.getChildren(PRODUCT_ELEMENT_NAME));
    }
    final List<Element> releases = new ArrayList<Element>();
    for (final Element product : products) {
      releases.addAll(product.getChildren(RELEASE_ELEMENT_NAME));
    }
    for (final Element release : releases) {
      final String version = loadWeblogicServerVersion(release);
      if (version == null) {
        continue;
      }
      final String installDir = release.getAttributeValue(INSTALL_DIR_ATTR);
      final String javaHome = release.getAttributeValue(JAVA_HOME_ATTR);
      result.add(new BeaVersion(version, installDir, javaHome));
    }

    return result.toArray(new BeaVersion[result.size()]);
  }

  private static @Nullable String loadWeblogicServerVersion(Element release) {
    final List<Element> components = release.getChildren(COMPONENT_ELEMENT_NAME);
    for (final Element component : components) {
      if (Comparing.equal(component.getAttributeValue(NAME_ATTR), WEBLOGIC_NAME)) {
        return component.getAttributeValue(VERSION_ATTR);
      }
    }
    return null;
  }

  public static BeaDomain[] loadDomains(File location) {
    final Collection<File> configXmlFiles = new HashSet<File>();
    findAllConfigs(configXmlFiles, location, 4);
    final Collection<BeaDomain> domains = new HashSet<BeaDomain>();
    for (final File configXmlFile : configXmlFiles) {
      final BeaDomain validDomain = createValidDomainByConfigFile(configXmlFile);
      if (validDomain != null) {
        domains.add(validDomain);
      }
    }
    return domains.toArray(new BeaDomain[domains.size()]);
  }

  public static @Nullable BeaDomain createValidDomain(File domainLocation) {
    File configXml = new File(domainLocation, CONFIG_XML);
    if (configXml.exists()) {
      return createValidDomainByConfigFile(configXml);
    }
    configXml = new File(domainLocation, CONFIG_DIR + File.separator + CONFIG_XML);
    if (configXml.exists()) {
      return createValidDomainByConfigFile(configXml);
    }
    return null;
  }

  public static @NotNull BeaDomain createDomain(File domainLocation) {
    BeaDomain validDomain = createValidDomain(domainLocation);
    if (validDomain == null) {
      final String name = domainLocation.getName();
      validDomain = createBeaDomain7xOr8x(name, null, domainLocation, createServer(domainLocation, name, null, false, true));
    }
    return validDomain;
  }

  public static @Nullable BeaDomain createValidDomainByConfigFile(File configFile) {
    if (!configFile.isFile()) {
      return null;
    }

    final Pair<Long, BeaDomain> pair = ourCachedDomains.get(configFile);
    if (pair != null && configFile.lastModified() == pair.getFirst()) {
      return pair.getSecond();
    }

    final BeaDomain beaDomain = computeValidDomainByConfigFile(configFile);
    if (beaDomain != null) {
      ourCachedDomains.put(configFile, Pair.create(configFile.lastModified(), beaDomain));
    }
    return beaDomain;
  }

  @Nullable
  private static BeaDomain computeValidDomainByConfigFile(final File configFile) {
    try {
      final Document document = JDOMUtil.loadDocument(configFile);
      final Element rootElement = document.getRootElement();

      if (WL9x_CONFIG_NAMESPACES.contains(rootElement.getNamespace())) {
        return createValidDomainFor9x(configFile, rootElement);
      }

      return createValidDomainFor7xOr8x(configFile, rootElement);

    }
    catch (Exception e) {
      return null;
    }
  }

  private static @Nullable BeaDomain createValidDomainFor7xOr8x(final File configFile, final Element rootElement) {
    if (!rootElement.getName().equals(DOMAIN_ELEMENT_NAME)) {
      return null;
    }
    final String name = rootElement.getAttributeValue(NAME2_ATTR);
    if (name == null) {
      return null;
    }
    final File location = configFile.getParentFile();

    final List<Element> serverElements = rootElement.getChildren(SERVER_ELEMENT_NAME);
    List<BeaServer> servers = new ArrayList<BeaServer>(serverElements.size());
    for (Element serverElement : serverElements) {
      final String listenPort = serverElement.getAttributeValue(LISTEN_PORT_ATTR);
      final String serverName = serverElement.getAttributeValue(NAME2_ATTR);
      if (serverName != null && listenPort != null) {
        servers.add(createServer(location, serverName, listenPort, false, true));
      }
    }
    if (servers.isEmpty()) {
      return null;
    }

    final String version = rootElement.getAttributeValue(CONFIGURATION_VERSION_ATTRIBUTE_NAME);
    return createBeaDomain7xOr8x(name, version, location, servers.toArray(new BeaServer[servers.size()]));
  }

  private static @Nullable BeaDomain createValidDomainFor9x(final File configFile, final Element rootElement) {
    final Namespace namespace = rootElement.getNamespace();
    if (!rootElement.getName().equals(DOMAIN_9X_ELEMENT_NAME)) {
      return null;
    }

    final String name = rootElement.getChildText(NAME_9X_ELEMENT_NAME, namespace);
    if (name == null) {
      return null;
    }
    String version = rootElement.getChildText(CONFIGURATION_VERSION_9X_ELEMENT_NAME, namespace);
    final String adminServerName = rootElement.getChildText(ADMIN_SERVER_NAME_CHILD, namespace);
    final List<Element> serverElements = rootElement.getChildren(SERVER_9X_ELEMENT_NAME, namespace);

    final File domainHome = configFile.getParentFile().getParentFile();
    List<BeaServer> servers = new ArrayList<BeaServer>();
    for (Element serverElement : serverElements) {
      final String serverName = serverElement.getChildText(NAME_9X_ELEMENT_NAME, namespace);
      final String listenPort = serverElement.getChildText(LISTEN_PORT_9X_ELEMENT_NAME, namespace);
      if (serverName != null) {
        final boolean isAdmin = serverName.equals(adminServerName);
        servers.add(createServer(domainHome, serverName, listenPort, true, isAdmin));
      }
    }
    if (servers.isEmpty()) {
      return null;
    }

    return createBeaDomain9x(name, version, domainHome, servers.toArray(new BeaServer[servers.size()]));
  }

  private static BeaServer createServer(File domainHome, String name, String port, boolean is9x, final boolean isAdmin) {
    String pathToLog = is9x
                       ? SERVERS_DIR + File.separator + name + File.separator + LOGS_DIR + File.separator + name + LOG_SUFFIX
                       : name + File.separator + name + WeblogicUtil.LOG_SUFFIX;
    final int listenPort = port == null ? WeblogicIntegration.DEFAULT_PORT : Integer.parseInt(port);
    return new BeaServer(name, listenPort, isAdmin, new File(domainHome, pathToLog));
  }

  private static BeaDomain createBeaDomain9x(final String name, String version,
                                             final File domainHome,
                                             final BeaServer[] servers) {
    return new BeaDomain(name, version, domainHome, new File(domainHome, LOGS_DIR + File.separator + name + LOG_SUFFIX),
                         new File(domainHome, getDefaultStartupFileName()),
                         new File(domainHome, APPLICATIONS_DIR_9x),
                         servers);
  }

  private static BeaDomain createBeaDomain7xOr8x(String name, String version, File location, BeaServer... servers) {
    return new BeaDomain(name, version, location,
                         new File(location, WeblogicUtil.LOGS_DIR + File.separator + name + WeblogicUtil.LOG_SUFFIX),
                         new File(location, WeblogicUtil.getDefaultStartupFileName()),
                         new File(location, WeblogicUtil.APPLICATIONS_DIR_7x8x),
                         servers);
  }

  private static void findAllConfigs(Collection<File> result, File location, int level) {
    if (level < 0) {
      return;
    }
    final File[] files = location.listFiles();
    if (files == null) {
      return;
    }
    for (final File file : files) {
      if (file.isDirectory()) {
        findAllConfigs(result, file, level - 1);
      }
      else {
        if (CONFIG_XML.equalsIgnoreCase(file.getName())) {
          result.add(file);
        }
      }
    }
  }

  private static String getDefaultStartupFileName() {
    return SystemInfo.isWindows ? CMD_FILE : SH_FILE;
  }

  public static WeblogicRdbmsBean findRdbmsBean(final WeblogicRdbmsJar rdbmsRootDescriptor, final String ejbName) {
    return ejbName == null ? null : ContainerUtil.find(rdbmsRootDescriptor.getWeblogicRdbmsBeans(), new Condition<WeblogicRdbmsBean>() {
      public boolean value(final WeblogicRdbmsBean object) {
        return ejbName.equals(object.getEjbName().getStringValue());
      }
    });
  }

  public static WeblogicEnterpriseBean findEnterpriseBean(final WeblogicEjbJar ejbRootDescriptor, final String ejbName) {
    return ejbName == null ? null : ContainerUtil.find(ejbRootDescriptor.getWeblogicEnterpriseBeans(), new Condition<WeblogicEnterpriseBean>() {
      public boolean value(final WeblogicEnterpriseBean object) {
        return ejbName.equals(object.getEjbName().getStringValue());
      }
    });
  }


  public static void setCmpFields(final FieldGroup fieldGroup, final List<String> fields) {
    for (final GenericDomValue<String> value : fieldGroup.getCmpFields()) {
      value.undefine();
    }
    for (final String field : fields) {
      fieldGroup.addCmpField().setValue(field);
    }
  }
}