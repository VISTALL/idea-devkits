/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.configuration;

import com.intellij.execution.process.ProcessHandler;
import com.intellij.execution.process.ProcessOutputTypes;
import com.intellij.javaee.run.execution.OutputProcessor;
import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegration;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.LogNotificationListener;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicInstance;
import com.intellij.j2ee.wrappers.WebLogicLogNotification;
import com.intellij.j2ee.wrappers.WeblogicOutputInfo;
import com.intellij.openapi.util.Key;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jetbrains.annotations.NonNls;

/**
 * author: lesya
 */

class WeblogicOutputProcessorImpl implements OutputProcessor {
  private StringBuffer myOutput = new StringBuffer();
  private LogNotificationListener myLogListener;
  private final ProcessHandler myProcessHandler;
  private final WeblogicInstance myWeblogicInstance;
  private final WeblogicIntegration myIntegration;

  private final Map<String, Key> SEVERITY_NAME_TO_CONTENT_TYPE = new HashMap<String, Key>();
  @NonNls protected static final String MESSAGE_PATTERN = "<([^>]*)> <([^>]*)> <([^>]*)> <[^>\\d]*(\\d*)[^>\\d]*> <([^>]*)>.*";
  @NonNls protected static final String MESSAGE2_PATTERN = "weblogic\\.log\\.(\\w+)\\.(\\d+)";

  public WeblogicOutputProcessorImpl(ProcessHandler processHandler,
                                     WeblogicInstance weblogicInstance) {
    myProcessHandler = processHandler;
    myWeblogicInstance = weblogicInstance;
    myIntegration = WeblogicIntegration.getInstance();

    WeblogicOutputInfo outputInfo = myWeblogicInstance.getOutputInfo();

    SEVERITY_NAME_TO_CONTENT_TYPE.put(outputInfo.getEmergencyText(), WeblogicConsoleViewContentType.SEVERITY_EMERGENCY_KEY);
    SEVERITY_NAME_TO_CONTENT_TYPE.put(outputInfo.getAlertText(), WeblogicConsoleViewContentType.SEVERITY_ALERT_KEY);
    SEVERITY_NAME_TO_CONTENT_TYPE.put(outputInfo.getCriticalText(), WeblogicConsoleViewContentType.SEVERITY_CRITICAL_KEY);
    SEVERITY_NAME_TO_CONTENT_TYPE.put(outputInfo.getErrorText(), WeblogicConsoleViewContentType.SEVERITY_ERROR_KEY);
    SEVERITY_NAME_TO_CONTENT_TYPE.put(outputInfo.getWarningText(), WeblogicConsoleViewContentType.SEVERITY_WARNING_KEY);
    SEVERITY_NAME_TO_CONTENT_TYPE.put(outputInfo.getNoticeText(), WeblogicConsoleViewContentType.SEVERITY_NOTICE_KEY);
    SEVERITY_NAME_TO_CONTENT_TYPE.put(outputInfo.getInfoText(), WeblogicConsoleViewContentType.SEVERITY_INFO_KEY);
    SEVERITY_NAME_TO_CONTENT_TYPE.put(outputInfo.getDebugText(), WeblogicConsoleViewContentType.SEVERITY_DEBUG_KEY);

  }

  public void parseOutput(String text) {
    myOutput.append(text);
    int start = 0;
    while (true) {
      start = myOutput.indexOf("\n", start + 1);
      if (start == -1) break;
      final String message = myOutput.substring(0, start).trim();
      if (message.length() == 0) continue;
      if (message.charAt(message.length() - 1) == '>' ||
          myOutput.length() > start + 1 && myOutput.charAt(start + 1) == '<') {
        parseMessage(message);
        myOutput.delete(0, start + 1);
        break;
      }
    }
  }

  public void registerPrintingToConsoleLogListener() {
    myLogListener = new LogNotificationListener() {
      public void handleNotification(LogNotificationListener.LogNotification notification) {
        final WebLogicLogNotification wln = notification.getNotification();
        printLogMessageToConsole(wln);
      }
    };
    myWeblogicInstance.addLogNotificationListener(myLogListener);
  }

  public void dispose() {
    if (myLogListener != null) {
      myWeblogicInstance.removeLogNotificationListener(myLogListener);
      myLogListener = null;
    }
  }

  private void parseMessage(String message) {
    final Pattern pattern = Pattern.compile(MESSAGE_PATTERN, Pattern.DOTALL);
    final Matcher matcher = pattern.matcher(message);
    if (!matcher.matches()) {
      myProcessHandler.notifyTextAvailable(message + "\n", ProcessOutputTypes.STDOUT);
      return;
    }
    try {
      final String dateStr = matcher.group(1);
      Date date = parseDate(dateStr);
      if (date == null) date = new Date();
      final String severityStr = matcher.group(2);
      final int severity = myWeblogicInstance.getOutputInfo().severityStringToNum(severityStr);
      final String subsystem = matcher.group(3);
      final String seq = matcher.group(4);
      long sequence;
      try {
        sequence = Long.parseLong(seq);
      }
      catch (NumberFormatException e) {
        sequence = -1;
      }
      String text = matcher.group(5);
      if (text == null) text = "";
      @NonNls final String type = myIntegration.getPresentableName() + ".log." + subsystem + "." + sequence;
      @NonNls final String logNotification = "source";
      WebLogicLogNotification notification = myWeblogicInstance.createWebLogicLogNotification(date, type, sequence,
                                                                                              severity, text, logNotification, null);
      printLogMessageToConsole(notification);
    }
    catch (Exception e) {
      myWeblogicInstance.registerServerError(e);
    }
  }

  private static final int[] dStyles = new int[]{DateFormat.SHORT, DateFormat.MEDIUM, DateFormat.LONG, DateFormat.FULL};
  private static final int[] tStyles = new int[]{DateFormat.SHORT, DateFormat.MEDIUM, DateFormat.LONG, DateFormat.FULL};

  private static Date parseDate(final String dateStr) {
    for (int ds = 0; ds < dStyles.length; ds++) {
      int dStyle = dStyles[ds];
      for (int ts = 0; ts < tStyles.length; ts++) {
        int tStyle = tStyles[ts];
        try {
          final Date date = DateFormat.getDateTimeInstance(dStyle, tStyle, Locale.ENGLISH).parse(dateStr);
          int d = dStyles[0];
          dStyles[0] = dStyle;
          dStyles[ds] = d;
          int t = tStyles[0];
          tStyles[0] = tStyle;
          dStyles[ts] = t;
          return date;
        }
        catch (ParseException e) {
        }
      }
    }
    return null;
  }

  private void printLogMessageToConsole(final WebLogicLogNotification wln) {
    final long timeStamp = wln.getTimeStamp();
    final String date = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.FULL).format(new Date(timeStamp));
    final int severity = wln.getSeverity();
    final String severityStr = myWeblogicInstance.getOutputInfo().severityNumToString(severity);
    final String type = wln.getType();
    Pattern typePattern = Pattern.compile(MESSAGE2_PATTERN);
    final Matcher matcher = typePattern.matcher(type);
    final String subSystem;
    final String seqNo;
    if (matcher.matches()) {
      subSystem = matcher.group(1);
      seqNo = matcher.group(2);
    }
    else {
      subSystem = "";
      seqNo = "";
    }

    final String tail = MessageFormat.format("<{0}> <{1}> <{2}> <{3}>\n", wln.getServername(), subSystem, seqNo, wln.getMessage());
    myProcessHandler.notifyTextAvailable("<" + date + "> " + "\n", ProcessOutputTypes.STDOUT);
    Key contentType = SEVERITY_NAME_TO_CONTENT_TYPE.containsKey(severityStr) ?
                      SEVERITY_NAME_TO_CONTENT_TYPE.get(severityStr) : ProcessOutputTypes.SYSTEM;
    myProcessHandler.notifyTextAvailable("<" + severityStr + "> ", contentType);
    myProcessHandler.notifyTextAvailable(tail, ProcessOutputTypes.STDOUT);
    myProcessHandler.notifyTextAvailable(tail, ProcessOutputTypes.STDOUT);
    final Throwable throwable = wln.getThrowable();
    if (throwable != null) {
      final StringWriter stringWriter = new StringWriter();
      PrintWriter writer = new PrintWriter(stringWriter);
      throwable.printStackTrace(writer);
      myProcessHandler.notifyTextAvailable(stringWriter.toString(), ProcessOutputTypes.STDERR);
    }

  }


}
