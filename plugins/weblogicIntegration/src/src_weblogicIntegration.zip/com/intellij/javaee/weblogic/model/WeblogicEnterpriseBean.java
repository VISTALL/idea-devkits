/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.javaee.model.EjbResolveConverter;
import com.intellij.javaee.model.common.ejb.EnterpriseBean;
import com.intellij.javaee.weblogic.model.persistence.EjbReferenceDescription;
import com.intellij.javaee.weblogic.model.persistence.ResourceDescription;
import com.intellij.javaee.weblogic.model.persistence.ResourceEnvDescription;
import com.intellij.javaee.weblogic.model.persistence.ServiceReferenceDescription;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.Convert;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:weblogic-enterprise-beanType interface.
 */
public interface WeblogicEnterpriseBean extends JavaeeDomModelElement, ReferenceDescriptorGroup {

	/**
	 * Returns the value of the ejb-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:ejb-nameType documentation</h3>
	 * 	  The ejb-nameType specifies an enterprise bean's name. It is
	 * 	  used by ejb-name elements. This name is assigned by the
	 * 	  ejb-jar file producer to name the enterprise bean in the
	 * 	  ejb-jar file's deployment descriptor. The name must be
	 * 	  unique among the names of the enterprise beans in the same
	 * 	  ejb-jar file.
	 * 	  There is no architected relationship between the used
	 * 	  ejb-name in the deployment descriptor and the JNDI name that
	 * 	  the Deployer will assign to the enterprise bean's home.
	 * 	  The name for an entity bean must conform to the lexical
	 * 	  rules for an NMTOKEN.
	 * 	  Example:
	 * 	  <ejb-name>EmployeeService</ejb-name>
	 * 	  
	 * </pre>
	 * @return the value of the ejb-name child.
	 */
	@NotNull
        @Convert(EjbResolveConverter.class)
        GenericDomValue<EnterpriseBean> getEjbName();


	/**
	 * Returns the value of the transaction-descriptor child.
	 * @return the value of the transaction-descriptor child.
	 */
	TransactionDescriptor getTransactionDescriptor();


	/**
	 * Returns the value of the iiop-security-descriptor child.
	 * @return the value of the iiop-security-descriptor child.
	 */
	IiopSecurityDescriptor getIiopSecurityDescriptor();


	/**
	 * Returns the value of the enable-call-by-reference child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the enable-call-by-reference child.
	 */
	GenericDomValue<Boolean> getEnableCallByReference();


	/**
	 * Returns the value of the network-access-point child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdStringType documentation</h3>
	 * This type adds an "id" attribute to xsd:string.
	 * </pre>
	 * @return the value of the network-access-point child.
	 */
	GenericDomValue<String> getNetworkAccessPoint();


	/**
	 * Returns the value of the clients-on-same-server child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the clients-on-same-server child.
	 */
	GenericDomValue<Boolean> getClientsOnSameServer();


	/**
	 * Returns the value of the run-as-principal-name child.
	 * @return the value of the run-as-principal-name child.
	 */
	GenericDomValue<String> getRunAsPrincipalName();


	/**
	 * Returns the value of the create-as-principal-name child.
	 * @return the value of the create-as-principal-name child.
	 */
	GenericDomValue<String> getCreateAsPrincipalName();


	/**
	 * Returns the value of the remove-as-principal-name child.
	 * @return the value of the remove-as-principal-name child.
	 */
	GenericDomValue<String> getRemoveAsPrincipalName();


	/**
	 * Returns the value of the passivate-as-principal-name child.
	 * @return the value of the passivate-as-principal-name child.
	 */
	GenericDomValue<String> getPassivateAsPrincipalName();


	/**
	 * Returns the value of the jndi-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:jndi-nameType documentation</h3>
	 * The jndi-nameType type designates a JNDI name in the
	 * 	Deployment Component's environment and is relative to the
	 * 	java:comp/env context.  A JNDI name must be unique within the
	 * 	Deployment Component.
	 * </pre>
	 * @return the value of the jndi-name child.
	 */
	GenericDomValue<String> getJndiName();


	/**
	 * Returns the value of the local-jndi-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:jndi-nameType documentation</h3>
	 * The jndi-nameType type designates a JNDI name in the
	 * 	Deployment Component's environment and is relative to the
	 * 	java:comp/env context.  A JNDI name must be unique within the
	 * 	Deployment Component.
	 * </pre>
	 * @return the value of the local-jndi-name child.
	 */
	GenericDomValue<String> getLocalJndiName();


	/**
	 * Returns the value of the dispatch-policy child.
	 * @return the value of the dispatch-policy child.
	 */
	GenericDomValue<String> getDispatchPolicy();


	/**
	 * Returns the value of the remote-client-timeout child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the remote-client-timeout child.
	 */
	GenericDomValue<Integer> getRemoteClientTimeout();


	/**
	 * Returns the value of the entity-descriptor child.
	 * @return the value of the entity-descriptor child.
	 */
	@NotNull
	EntityDescriptor getEntityDescriptor();


	/**
	 * Returns the value of the stateless-session-descriptor child.
	 * @return the value of the stateless-session-descriptor child.
	 */
	@NotNull
	StatelessSessionDescriptor getStatelessSessionDescriptor();


	/**
	 * Returns the value of the stateful-session-descriptor child.
	 * @return the value of the stateful-session-descriptor child.
	 */
	@NotNull
	StatefulSessionDescriptor getStatefulSessionDescriptor();


	/**
	 * Returns the value of the message-driven-descriptor child.
	 * @return the value of the message-driven-descriptor child.
	 */
	@NotNull
	MessageDrivenDescriptor getMessageDrivenDescriptor();


	/**
	 * Returns the list of resource-description children.
	 * @return the list of resource-description children.
	 */
	List<ResourceDescription> getResourceDescriptions();
	/**
	 * Adds new child to the list of resource-description children.
	 * @return created child
	 */
	ResourceDescription addResourceDescription();


	/**
	 * Returns the list of resource-env-description children.
	 * @return the list of resource-env-description children.
	 */
	List<ResourceEnvDescription> getResourceEnvDescriptions();
	/**
	 * Adds new child to the list of resource-env-description children.
	 * @return created child
	 */
	ResourceEnvDescription addResourceEnvDescription();


	/**
	 * Returns the list of ejb-reference-description children.
	 * @return the list of ejb-reference-description children.
	 */
	List<EjbReferenceDescription> getEjbReferenceDescriptions();
	/**
	 * Adds new child to the list of ejb-reference-description children.
	 * @return created child
	 */
	EjbReferenceDescription addEjbReferenceDescription();


	/**
	 * Returns the list of service-reference-description children.
	 * @return the list of service-reference-description children.
	 */
	List<ServiceReferenceDescription> getServiceReferenceDescriptions();
	/**
	 * Adds new child to the list of service-reference-description children.
	 * @return created child
	 */
	ServiceReferenceDescription addServiceReferenceDescription();


}
