package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances;

import com.intellij.debugger.engine.DefaultJSPPositionManager;
import com.intellij.debugger.engine.DebugProcess;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.serverInstances.DefaultServerInstance;
import org.jetbrains.annotations.NonNls;

/**
 * @author nik
*/
public class WebLogicJSPPositionManager extends DefaultJSPPositionManager {
  private static final @NonNls String JSP_PACKAGE = "jsp_servlet";

  public WebLogicJSPPositionManager(final DebugProcess process, CommonModel commonModel) {
    super(process, DefaultServerInstance.getScopeFacetsWithIncluded(commonModel));
  }

  protected String getRelativePath(String jspPath) {
    if(jspPath.startsWith(JSP_PACKAGE)) {
      jspPath = jspPath.substring(JSP_PACKAGE.length() + 1);
    }

    return removeUnderscoresBeforeDirectories(jspPath);
  }

  protected String getGeneratedClassesPackage() {
    return JSP_PACKAGE;
  }

  public static String removeUnderscoresBeforeDirectories(final String jspPath) {
    StringBuilder buffer = new StringBuilder();
    int i = 0;
    while (i < jspPath.length()) {
      int next1 = jspPath.indexOf('/', i);
      int next2 = jspPath.indexOf('\\', i);
      int next;
      if (next1 == -1) {
        next = next2;
      }
      else if (next2 == -1) {
        next = next1;
      }
      else {
        next = Math.min(next1, next2);
      }
      if (next == -1) {
        buffer.append(jspPath.substring(i));
        break;
      }

      char c = jspPath.charAt(i);
      buffer.append(jspPath.substring(c == '_' ? i + 1 : i, next+1));
      i = next+1;
    }
    return buffer.toString();
  }
}
