/*
 * Copyright (c) 2000-2005 by JetBrains s.r.o. All Rights Reserved.
 * Use is subject to license terms.
 */
package com.intellij.javaee.weblogic.appServerIntegration;

import com.intellij.javaee.CommonModelManager;
import com.intellij.javaee.ejb.EjbModuleUtil;
import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.javaee.model.xml.ejb.EjbBase;
import com.intellij.javaee.module.view.ejb.editor.EjbAsVirtualFile;
import com.intellij.javaee.ui.MockJavaeeDomElementsEditor;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.beaInstallation.WeblogicUtil;
import com.intellij.javaee.weblogic.editors.EjbWebLogicEditor;
import com.intellij.javaee.weblogic.model.WeblogicEnterpriseBean;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsBean;
import com.intellij.javaee.weblogic.module.WeblogicEjbFacetUtil;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Factory;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.xml.XmlFile;
import com.intellij.util.xml.DomManager;
import com.intellij.util.xml.ui.*;
import org.jetbrains.annotations.NotNull;

/**
 * @author peter
 */
public class WeblogicEjbEditorProvider extends PerspectiveFileEditorProvider {
  public boolean accept(@NotNull Project project, @NotNull VirtualFile file) {
    if (!(file instanceof EjbAsVirtualFile)) return false;

    final EjbBase ejb = CommonModelManager.getInstance().getDomElement(((EjbAsVirtualFile)file).findElement(project));
    if (ejb == null) return false;

    EjbFacet ejbFacet = EjbModuleUtil.getEjbFacet(ejb);
    return ejbFacet != null && WeblogicEjbFacetUtil.getEjbRoot(ejbFacet) != null && WeblogicEjbFacetUtil.getRdbmsRoot(ejbFacet) != null;
  }

  @NotNull
  public PerspectiveFileEditor createEditor(@NotNull final Project project, @NotNull final VirtualFile file) {
    final EjbBase ejb = DomManager.getDomManager(project).createStableValue(new Factory<EjbBase>() {
      public EjbBase create() {
        return CommonModelManager.getInstance().getDomElement(((EjbAsVirtualFile)file).findElement(project));
      }
    });
    EjbFacet ejbFacet = EjbModuleUtil.getEjbFacet(ejb);
    return new WeblogicEjbEditor(ejb, ejbFacet).getFileEditor();
  }

  public double getWeight() {
    return 239;
  }

  private static class WeblogicEjbEditor extends MockJavaeeDomElementsEditor {
    private final EjbBase myEjb;

    public WeblogicEjbEditor(final EjbBase ejb, final EjbFacet ejbFacet) {
      super(ejbFacet);
      myEjb = ejb;
      final WeblogicEnterpriseBean weblogicEnterpriseBean =
        addEditedElement(WeblogicEnterpriseBean.class, new EditedElementDescription<WeblogicEnterpriseBean>() {
          public XmlFile getEditedFile() {
            return WeblogicEjbFacetUtil.getEjbJarDeploymentDescriptor(ejbFacet).getXmlFile();
          }

          public WeblogicEnterpriseBean find() {
            return WeblogicUtil.findEnterpriseBean(WeblogicEjbFacetUtil.getEjbRoot(ejbFacet), getEjbName());
          }

          public void initialize(final WeblogicEnterpriseBean element) {
            element.getEjbName().setStringValue(getEjbName());
          }

          public WeblogicEnterpriseBean addElement() {
            return WeblogicEjbFacetUtil.getEjbRoot(ejbFacet).addWeblogicEnterpriseBean();
          }
        });
      final WeblogicRdbmsBean weblogicRdbmsBean =
        addEditedElement(WeblogicRdbmsBean.class, new EditedElementDescription<WeblogicRdbmsBean>() {
          public XmlFile getEditedFile() {
            return WeblogicEjbFacetUtil.getCmpRdbmsDescriptor(ejbFacet).getXmlFile();
          }

          public WeblogicRdbmsBean find() {
            return WeblogicUtil.findRdbmsBean(WeblogicEjbFacetUtil.getRdbmsRoot(ejbFacet), getEjbName());
          }

          public void initialize(final WeblogicRdbmsBean element) {
            element.getEjbName().setStringValue(getEjbName());
          }

          public WeblogicRdbmsBean addElement() {
            return WeblogicEjbFacetUtil.getRdbmsRoot(ejbFacet).addWeblogicRdbmsBean();
          }
        });

      final String name = WeblogicBundle.message("weblogic.integration.presentable.name");

      final DomFileEditor editor = initFileEditor(myEjb.getManager().getProject(), myEjb.getRoot().getFile().getVirtualFile(), name, new Factory<BasicDomElementComponent>() {
        public BasicDomElementComponent create() {
          final EjbWebLogicEditor webLogicEditor = new EjbWebLogicEditor(myEjb, weblogicEnterpriseBean, weblogicRdbmsBean);
          final CaptionComponent captionComponent = DomUIFactory.getDomUIFactory().addErrorPanel(new CaptionComponent(name), weblogicEnterpriseBean, weblogicRdbmsBean);
          final BasicDomElementComponent component = DomFileEditor.createComponentWithCaption(webLogicEditor, captionComponent, ejb);
          return component;
        }
      });
      editor.addWatchedElement(WeblogicEjbFacetUtil.getEjbRoot(ejbFacet));
      editor.addWatchedElement(WeblogicEjbFacetUtil.getRdbmsRoot(ejbFacet));
    }

    private String getEjbName() {
      return myEjb.getEjbName().getValue();
    }

  }
}
