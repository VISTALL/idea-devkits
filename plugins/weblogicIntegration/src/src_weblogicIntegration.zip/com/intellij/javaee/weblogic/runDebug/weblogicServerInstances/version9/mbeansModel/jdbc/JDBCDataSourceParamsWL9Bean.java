/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.jdbc;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

/**
 * @author nik
 */
public class JDBCDataSourceParamsWL9Bean extends AbstractWL9MBean {
  private static final String JNDI_NAMES_ATTRIBUTE_NAME = "JNDINames";

  public JDBCDataSourceParamsWL9Bean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public void setJNDINames(String[] names) {
    setAttribute(JNDI_NAMES_ATTRIBUTE_NAME, names);
  }

  public String[] getJNDINames() {
    return (String[])getAttribute(JNDI_NAMES_ATTRIBUTE_NAME);
  }

  public void setRowPrefetch(boolean rowPrefetch) {
    setAttribute("RowPrefetch", rowPrefetch);
  }

  public void setRowPrefetchSize(int rowPrefetchSize) {
    setAttribute("RowPrefetchSize", rowPrefetchSize);
  }

  public void setStreamChunkSize(int streamChunkSize) {
    setAttribute("StreamChunkSize", streamChunkSize);
  }

  public void setGlobalTransactionsProtocol(GlobalTransactionsProtocol protocol) {
    setAttribute("GlobalTransactionsProtocol", protocol.getValue());
  }

  public enum GlobalTransactionsProtocol {
    NONE("None"), ONE_PHASE_COMMIT("OnePhaseCommit"), TWO_PHASE_COMMIT("TwoPhaseCommit");

    private String myValue;

    GlobalTransactionsProtocol(final String value) {
      myValue = value;
    }

    public String getValue() {
      return myValue;
    }
  }
}
