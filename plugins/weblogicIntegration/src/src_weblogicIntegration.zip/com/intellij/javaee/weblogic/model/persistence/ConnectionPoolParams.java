// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

/**
 * http://www.bea.com/ns/weblogic/90:connection-pool-paramsType interface.
 */
public interface ConnectionPoolParams extends JavaeeDomModelElement {

	/**
	 * Returns the value of the initial-capacity child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the initial-capacity child.
	 */
	GenericDomValue<Integer> getInitialCapacity();


	/**
	 * Returns the value of the max-capacity child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the max-capacity child.
	 */
	GenericDomValue<Integer> getMaxCapacity();


	/**
	 * Returns the value of the capacity-increment child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdPositiveIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:positiveInteger.
	 * </pre>
	 * @return the value of the capacity-increment child.
	 */
	GenericDomValue<Integer> getCapacityIncrement();


	/**
	 * Returns the value of the shrinking-enabled child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the shrinking-enabled child.
	 */
	GenericDomValue<Boolean> getShrinkingEnabled();


	/**
	 * Returns the value of the shrink-frequency-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdPositiveIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:positiveInteger.
	 * </pre>
	 * @return the value of the shrink-frequency-seconds child.
	 */
	GenericDomValue<Integer> getShrinkFrequencySeconds();


	/**
	 * Returns the value of the highest-num-waiters child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the highest-num-waiters child.
	 */
	GenericDomValue<Integer> getHighestNumWaiters();


	/**
	 * Returns the value of the highest-num-unavailable child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the highest-num-unavailable child.
	 */
	GenericDomValue<Integer> getHighestNumUnavailable();


	/**
	 * Returns the value of the connection-creation-retry-frequency-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:integer.
	 * </pre>
	 * @return the value of the connection-creation-retry-frequency-seconds child.
	 */
	GenericDomValue<Integer> getConnectionCreationRetryFrequencySeconds();


	/**
	 * Returns the value of the connection-reserve-timeout-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the connection-reserve-timeout-seconds child.
	 */
	GenericDomValue<Integer> getConnectionReserveTimeoutSeconds();


	/**
	 * Returns the value of the test-frequency-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the test-frequency-seconds child.
	 */
	GenericDomValue<Integer> getTestFrequencySeconds();


	/**
	 * Returns the value of the test-connections-on-create child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the test-connections-on-create child.
	 */
	GenericDomValue<Boolean> getTestConnectionsOnCreate();


	/**
	 * Returns the value of the test-connections-on-release child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the test-connections-on-release child.
	 */
	GenericDomValue<Boolean> getTestConnectionsOnRelease();


	/**
	 * Returns the value of the test-connections-on-reserve child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the test-connections-on-reserve child.
	 */
	GenericDomValue<Boolean> getTestConnectionsOnReserve();


	/**
	 * Returns the value of the profile-harvest-frequency-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the profile-harvest-frequency-seconds child.
	 */
	GenericDomValue<Integer> getProfileHarvestFrequencySeconds();


	/**
	 * Returns the value of the ignore-in-use-connections-enabled child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the ignore-in-use-connections-enabled child.
	 */
	GenericDomValue<Boolean> getIgnoreInUseConnectionsEnabled();


}
