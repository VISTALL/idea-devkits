/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9;

import org.jetbrains.annotations.NonNls;

import javax.management.remote.JMXConnector;
import javax.management.remote.JMXServiceURL;
import javax.management.remote.JMXConnectorFactory;
import javax.management.MBeanServerConnection;
import javax.naming.Context;
import java.io.IOException;
import java.util.HashMap;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.DomainRuntimeServiceWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.MBeansFactory;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.EditServiceWL9MBean;

/**
 * @author nik
 */
public abstract class WeblogicJMXConnector<T extends AbstractWL9MBean> {
  @NonNls private static final String T3_PROTOCOL = "t3";
  @NonNls private static final String JNDI_ROOT = "/jndi/";
  @NonNls private static final String DOMAIN_RUNTIME_MBEAN_SERVER = "weblogic.management.mbeanservers.domainruntime";
  @NonNls private static final String EDIT_MBEAN_SERVER = "weblogic.management.mbeanservers.edit";
  @NonNls private static final String WL_PROTOCOL_PROVIDER_PACKAGES = "weblogic.management.remote";
  protected MBeanServerConnection myConnection;
  private JMXConnector myConnector;
  private String myMBeanServer;

  protected WeblogicJMXConnector(final String mbeanServer) {
    myMBeanServer = mbeanServer;
  }

  public boolean isConnected() {
    return myConnection != null;
  }

  public void connect(final String hostname, final int port, final String username, final String password) throws IOException {
    JMXServiceURL serviceURL = new JMXServiceURL(T3_PROTOCOL, hostname, port, JNDI_ROOT + myMBeanServer);

    HashMap<String,Object> h = new HashMap<String, Object>();
    h.put(Context.SECURITY_PRINCIPAL, username);
    h.put(Context.SECURITY_CREDENTIALS, password);
    h.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES, WL_PROTOCOL_PROVIDER_PACKAGES);
    myConnector = JMXConnectorFactory.connect(serviceURL, h);
    myConnection = myConnector.getMBeanServerConnection();
  }

  public void disconnect() throws IOException {
    if (myConnector != null) {
      myConnector.close();
    }
    myConnection = null;
    myConnector = null;
  }

  public abstract T getRootMBean();

  public static WeblogicJMXConnector<DomainRuntimeServiceWL9MBean> createDomainRuntimeConnector()  {
    return new WeblogicJMXConnector<DomainRuntimeServiceWL9MBean>(DOMAIN_RUNTIME_MBEAN_SERVER) {
      public DomainRuntimeServiceWL9MBean getRootMBean() {
        return MBeansFactory.createDomainRuntimeService(myConnection);
      }
    };
  }

  public static WeblogicJMXConnector<EditServiceWL9MBean> createEditServiceConnector() {
    return new WeblogicJMXConnector<EditServiceWL9MBean>(EDIT_MBEAN_SERVER) {
      public EditServiceWL9MBean getRootMBean() {
        return MBeansFactory.createEditService(myConnection);
      }
    };
  }
}
