/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9;

import com.intellij.j2ee.wrappers.Notification;
import org.jetbrains.annotations.NotNull;

/**
 * @author nik
 */
public class WebLogic9NotificationWrapper implements Notification {
  protected javax.management.Notification myNotification;

  public WebLogic9NotificationWrapper(final @NotNull javax.management.Notification notification) {
    myNotification = notification;
  }

  public Object getSource() {
    return myNotification.getSource();
  }

  public String getType() {
    return myNotification.getType();
  }

  public String getMessage() {
    return myNotification.getMessage();
  }

  public Object getUserData() {
    return myNotification.getUserData();
  }
}
