// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:message-destination-descriptorType interface.
 */
public interface MessageDestinationDescriptor extends JavaeeDomModelElement {

	/**
	 * Returns the value of the message-destination-name child.
	 * @return the value of the message-destination-name child.
	 */
	@NotNull
	GenericDomValue<String> getMessageDestinationName();


	/**
	 * Returns the value of the destination-resource-link child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the value of the destination-resource-link child.
	 */
	@NotNull
	GenericDomValue<String> getDestinationResourceLink();


	/**
	 * Returns the value of the destination-jndi-name child.
	 * @return the value of the destination-jndi-name child.
	 */
	@NotNull
	GenericDomValue<String> getDestinationJndiName();


	/**
	 * Returns the value of the initial-context-factory child.
	 * @return the value of the initial-context-factory child.
	 */
	GenericDomValue<String> getInitialContextFactory();


	/**
	 * Returns the value of the provider-url child.
	 * @return the value of the provider-url child.
	 */
	GenericDomValue<String> getProviderUrl();


}
