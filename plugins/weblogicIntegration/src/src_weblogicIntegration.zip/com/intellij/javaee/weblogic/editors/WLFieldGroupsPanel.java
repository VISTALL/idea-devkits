/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.editors;

import com.intellij.javaee.model.xml.ejb.CmpField;
import com.intellij.javaee.model.xml.ejb.EntityBean;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.model.persistence.FieldGroup;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsBean;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.Condition;
import com.intellij.ui.BooleanTableCellEditor;
import com.intellij.ui.BooleanTableCellRenderer;
import com.intellij.util.Function;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.ui.ColumnInfo;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.reflect.DomGenericInfo;
import com.intellij.util.xml.ui.ChildGenericValueColumnInfo;
import com.intellij.util.xml.ui.DomCollectionControl;

import javax.swing.*;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class WLFieldGroupsPanel extends DomCollectionControl<FieldGroup> {
  private final EntityBean myEjb;

  public WLFieldGroupsPanel(EntityBean ejb, WeblogicRdbmsBean weblogicBean) {
    super(weblogicBean, "field-group");

    myEjb = ejb;
  }

  protected ColumnInfo[] createColumnInfos(final DomElement parent) {
    List<ColumnInfo<FieldGroup, ?>> result = new ArrayList<ColumnInfo<FieldGroup, ?>>();

    final DomGenericInfo info = parent.getManager().getGenericInfo(FieldGroup.class);
    result.add(new ChildGenericValueColumnInfo<FieldGroup>(WeblogicBundle.message("column.name.configure.field.groups.group.name"),
                                                           info.getFixedChildDescription("group-name"),
                                                           new DefaultCellEditor(new JTextField())));
    for (final CmpField field : myEjb.getCmpFields()) {
      final String fieldName = field.getFieldName().getValue();
      result.add(new ColumnInfo<FieldGroup, Boolean>(fieldName) {

        public TableCellRenderer getRenderer(final FieldGroup p0) {
          return new BooleanTableCellRenderer();
        }

        public TableCellEditor getEditor(final FieldGroup item) {
          return new BooleanTableCellEditor();
        }

        public void setValue(final FieldGroup o, final Boolean aValue) {
          Set<String> cmpNames = ContainerUtil.map2Set(myEjb.getCmpFields(), new Function<CmpField, String>() {
            public String fun(final CmpField s) {
              return s.getFieldName().getValue();
            }
          });
          for (final GenericDomValue<String> value : o.getCmpFields()) {
            if (!cmpNames.contains(value.getValue())) {
              value.undefine();
            }
          }

          if (!aValue) {
            final GenericDomValue<String> value = ContainerUtil.find(o.getCmpFields(), new Condition<GenericDomValue<String>>() {
              public boolean value(final GenericDomValue<String> object) {
                return Comparing.equal(fieldName, object.getValue());
              }
            });
            if (value != null) {
              value.undefine();
            }
          } else {
            o.addCmpField().setValue(fieldName);
          }
        }

        public boolean isCellEditable(final FieldGroup o) {
          return true;
        }

        public Boolean valueOf(final FieldGroup object) {
          return ContainerUtil.map2Set(object.getCmpFields(), new Function<GenericDomValue<String>, String>() {
            public String fun(final GenericDomValue<String> s) {
              return s.getValue();
            }
          }).contains(fieldName);
        }
      });
    }

    return result.toArray(new ColumnInfo[result.size()]);
  }

}
