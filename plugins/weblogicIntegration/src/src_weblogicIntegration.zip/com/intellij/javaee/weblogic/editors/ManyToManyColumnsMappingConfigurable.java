/**
 * @author cdr
 */
/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.editors;

import com.intellij.javaee.model.xml.ejb.EjbRelation;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsRelation;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRelationshipRole;
import com.intellij.openapi.util.Factory;
import com.intellij.openapi.util.Pair;
import com.intellij.util.Function;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.xml.ui.ComboControl;
import com.intellij.util.xml.ui.CommittablePanel;
import com.intellij.util.xml.ui.CompositeCommittable;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ManyToManyColumnsMappingConfigurable extends CompositeCommittable implements CommittablePanel {
  private JPanel myPanel12;
  private JPanel myPanel21;
  private TableColumnsMappingConfigurable myMapping12;
  private TableColumnsMappingConfigurable myMapping21;
  private JPanel myPanel;
  private JComboBox myJoinTable;
  private final EjbRelation myRelation;
  private final WeblogicRdbmsRelation myRdbmsRelation;

  public ManyToManyColumnsMappingConfigurable(final WeblogicRdbmsRelation rdbmsRelation, final EjbRelation relation) {
    myRdbmsRelation = rdbmsRelation;
    myRelation = relation;

    WeblogicRelationshipRole role1 = EjbRelationshipCommittablePanel.ensureWeblogicRole(0, myRdbmsRelation, relation.getEjbRelationshipRole1());
    WeblogicRelationshipRole role2 = EjbRelationshipCommittablePanel.ensureWeblogicRole(1, myRdbmsRelation, relation.getEjbRelationshipRole2());

    myMapping12 = new TableColumnsMappingConfigurable(new RdbmsHelper(myRdbmsRelation, role1, relation, relation.getEjbRelationshipRole1()), false);
    myMapping21 = new TableColumnsMappingConfigurable(new RdbmsHelper(myRdbmsRelation, role2, relation, relation.getEjbRelationshipRole2()), false);

    myPanel12.setLayout(new BorderLayout());
    myPanel21.setLayout(new BorderLayout());

    myPanel12.add(myMapping12.getComponent(), BorderLayout.CENTER);
    myPanel21.add(myMapping21.getComponent(), BorderLayout.CENTER);

    addComponent(new ComboControl(myRdbmsRelation.getTableName(), new Factory<List<Pair<String, Icon>>>() {
      public List<Pair<String, Icon>> create() {
        return ContainerUtil.map(RdbmsHelper.getAllAvailableTableNames(myRelation), new Function<String, Pair<String, Icon>>() {
          public Pair<String, Icon> fun(final String s) {
            return Pair.create(s, null);
          }
        });
      }
    })).bind(myJoinTable);

    addComponent(myMapping12);
    addComponent(myMapping21);
  }

  public WeblogicRdbmsRelation getRdbmsRelation() {
    return myRdbmsRelation;
  }

  public JComponent getComponent() {
    return myPanel;
  }

  public void commit() {
    super.commit();

    for (final WeblogicRelationshipRole role : myRdbmsRelation.getWeblogicRelationshipRoles()) {
      role.getRelationshipRoleMap().getForeignKeyTable().undefine();
    }
    myMapping12.reset();
    myMapping21.reset();
  }

}