// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

/**
 * http://www.bea.com/ns/weblogic/90:transaction-descriptorType interface.
 */
public interface TransactionDescriptor extends JavaeeDomModelElement {

	/**
	 * Returns the value of the trans-timeout-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the trans-timeout-seconds child.
	 */
	GenericDomValue<Integer> getTransTimeoutSeconds();


}
