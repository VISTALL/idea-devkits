// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.javaee.model.common.ejb.CmpField;
import com.intellij.javaee.weblogic.CmpFieldResolvingConverter;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.Convert;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:field-mapType interface.
 */
public interface FieldMap extends JavaeeDomModelElement {

	/**
	 * Returns the value of the cmp-field child.
	 * @return the value of the cmp-field child.
	 */
	@NotNull
        @Convert(CmpFieldResolvingConverter.class)
        GenericDomValue<CmpField> getCmpField();


	/**
	 * Returns the value of the dbms-column child.
	 * @return the value of the dbms-column child.
	 */
	@NotNull
	GenericDomValue<String> getDbmsColumn();


	/**
	 * Returns the value of the dbms-column-type child.
	 * @return the value of the dbms-column-type child.
	 */
	GenericDomValue<String> getDbmsColumnType();


	/**
	 * Returns the value of the dbms-default-value child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the dbms-default-value child.
	 */
	GenericDomValue<Boolean> getDbmsDefaultValue();


	/**
	 * Returns the value of the group-name child.
	 * @return the value of the group-name child.
	 */
	GenericDomValue<String> getGroupName();


}
