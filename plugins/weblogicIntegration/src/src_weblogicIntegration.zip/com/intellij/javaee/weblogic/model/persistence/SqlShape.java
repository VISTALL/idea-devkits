// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.Description;
import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:sql-shapeType interface.
 */
public interface SqlShape extends JavaeeDomModelElement {

	/**
	 * Returns the value of the description child.
	 * @return the value of the description child.
	 */
	Description getDescription();


	/**
	 * Returns the value of the sql-shape-name child.
	 * @return the value of the sql-shape-name child.
	 */
	@NotNull
	GenericDomValue<String> getSqlShapeName();


	/**
	 * Returns the list of table children.
	 * @return the list of table children.
	 */
	List<Table> getTables();
	/**
	 * Adds new child to the list of table children.
	 * @return created child
	 */
	Table addTable();


	/**
	 * Returns the value of the pass-through-columns child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdPositiveIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:positiveInteger.
	 * </pre>
	 * @return the value of the pass-through-columns child.
	 */
	GenericDomValue<Integer> getPassThroughColumns();


	/**
	 * Returns the list of ejb-relation-name children.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the list of ejb-relation-name children.
	 */
	List<GenericDomValue<String>> getEjbRelationNames();
	/**
	 * Adds new child to the list of ejb-relation-name children.
	 * @return created child
	 */
	GenericDomValue<String> addEjbRelationName();


}
