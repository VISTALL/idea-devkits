/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9;

import com.intellij.execution.ExecutionException;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.runDebug.configuration.WeblogicModel;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicServerEvent;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.DeployerRuntimeWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.ServerRuntimeWL9MBean;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author nik
 */
public class Weblogic9RemoteInstance extends Weblogic9AbstractInstance {
  private List<Throwable> myRegisteredExceptions = new ArrayList<Throwable>();

  public Weblogic9RemoteInstance(final CommonModel commonModel) throws ExecutionException {
    super(commonModel);
  }

  protected void autoDeploy(JavaeeModuleProperties moduleProperties, File source) {
    throw new IllegalArgumentException(WeblogicBundle.message("exception.text.remote.auto.deploy.not.supported"));
  }

  protected void autoUndeploy(File source) {
    throw new IllegalArgumentException(WeblogicBundle.message("exception.text.remote.auto.deploy.not.supported"));
  }

  protected void deploy(File source, String name) {
    try {
      WeblogicModel weblogicModel = getWeblogicConfiguration();
      final DeployerHelperWL9 deployerHelper = new DeployerHelperWL9(myWeblogicClassloader);
      final String sourcePath = source.getPath();
      String remoteSourcePath = deployerHelper.uploadSource(getAdminUrl(), weblogicModel.USER, weblogicModel.PASSWORD, sourcePath, name);
      final DeployerRuntimeWL9MBean deployerRuntime = myDomainRuntimeService.getDomainRuntime().getDeployerRuntime();
      deployerRuntime.activate(remoteSourcePath, name, getServerName());
    }
    catch (Exception e) {
      registerServerError(e);
    }
  }

  protected void undeploy(String name) {
    myDomainRuntimeService.getDomainRuntime().getDeployerRuntime().remove(name, getServerName());
  }


  public boolean connect() throws Exception {
    final boolean[] connected = new boolean[]{false};
    final String connectingMessage = WeblogicBundle.message("process.description.connecting");

    getServerPollThread().queueRequestAndWait(new Runnable() {
      public String toString() {
        return connectingMessage;
      }

      public void run() {
        myRegisteredExceptions.clear();
        refreshState();
        final String state = getState();
        if (state != null) {
          registerLogNotificationListener();

          fireServerListeners(new WeblogicServerEvent(state, getOutputInfo()));
          connected[0] = true;
        }
      }
    });

    if (getLoginException() != null) {
      throw getLoginException();
    }

    if (!myRegisteredExceptions.isEmpty()) {
      Throwable throwable = myRegisteredExceptions.get(0);
      if (throwable instanceof Exception) {
        throw (Exception)throwable;
      }
      else {
        throw new Exception(throwable);
      }
    }
    return connected[0];
  }


  public void testConnection() throws Exception {
    initialize();
    try {
      connect();
      if (!isConnected() || myDomainRuntimeService == null || myServerRuntime == null) {
        throw new RuntimeException(WeblogicBundle.message("exception.text.cannot.connect.to.remote.server"));
      }
      if (!findRemoteServer()) {
        throw new RuntimeException(WeblogicBundle.message("error.cannot.find.server.text", getWeblogicConfiguration().SERVER_NAME));
      }
    }
    finally {
      disconnect();
    }
  }

  private boolean findRemoteServer() {
    final boolean[] result = new boolean[]{false};
    final Runnable runnable = new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.loading.data.from.remote");
      }

      public void run() {
        final ServerRuntimeWL9MBean server = myDomainRuntimeService.findServerRuntimeByName(getWeblogicConfiguration().SERVER_NAME);
        result[0] = server != null;
      }
    };
    getServerPollThread().queueRequestAndWait(runnable);
    return result[0];
  }

  public void dispose() {
    unregisterServerPollThread();
  }


  public void registerServerError(Throwable e) {
    super.registerServerError(e);
    myRegisteredExceptions.add(e);
  }

}
