// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

/**
 * http://www.bea.com/ns/weblogic/90:stateful-session-cacheType interface.
 */
public interface StatefulSessionCache extends JavaeeDomModelElement {

	/**
	 * Returns the value of the max-beans-in-cache child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the max-beans-in-cache child.
	 */
	GenericDomValue<Integer> getMaxBeansInCache();


	/**
	 * Returns the value of the idle-timeout-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the idle-timeout-seconds child.
	 */
	GenericDomValue<Integer> getIdleTimeoutSeconds();


	/**
	 * Returns the value of the session-timeout-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the session-timeout-seconds child.
	 */
	GenericDomValue<Integer> getSessionTimeoutSeconds();


	/**
	 * Returns the value of the cache-type child.
	 * @return the value of the cache-type child.
	 */
	GenericDomValue<String> getCacheType();


}
