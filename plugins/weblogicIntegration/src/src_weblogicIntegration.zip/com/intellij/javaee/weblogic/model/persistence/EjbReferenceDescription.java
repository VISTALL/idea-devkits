// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:ejb-reference-descriptionType interface.
 */
public interface EjbReferenceDescription extends JavaeeDomModelElement {

	/**
	 * Returns the value of the ejb-ref-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:ejb-ref-nameType documentation</h3>
	 * 	  The ejb-ref-name element contains the name of an EJB
	 * 	  reference. The EJB reference is an entry in the
	 * 	  Deployment Component's environment and is relative to the
	 * 	  java:comp/env context.  The name must be unique within the
	 * 	  Deployment Component.
	 * 	  It is recommended that name is prefixed with "ejb/".
	 * 	  Example:
	 * 	  <ejb-ref-name>ejb/Payroll</ejb-ref-name>
	 * 	  
	 * </pre>
	 * @return the value of the ejb-ref-name child.
	 */
	@NotNull
	GenericDomValue<String> getEjbRefName();


	/**
	 * Returns the value of the jndi-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:jndi-nameType documentation</h3>
	 * The jndi-nameType type designates a JNDI name in the
	 * 	Deployment Component's environment and is relative to the
	 * 	java:comp/env context.  A JNDI name must be unique within the
	 * 	Deployment Component.
	 * </pre>
	 * @return the value of the jndi-name child.
	 */
	@NotNull
	GenericDomValue<String> getJndiName();


}
