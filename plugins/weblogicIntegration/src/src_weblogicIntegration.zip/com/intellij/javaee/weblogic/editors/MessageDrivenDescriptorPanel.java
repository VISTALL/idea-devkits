/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.editors;

import com.intellij.util.xml.ui.CommittablePanel;
import com.intellij.javaee.weblogic.model.MessageDrivenDescriptor;
import com.intellij.javaee.weblogic.model.WeblogicEnterpriseBean;
import com.intellij.openapi.util.Factory;
import com.intellij.util.xml.ui.BasicDomElementComponent;

import javax.swing.*;

public class MessageDrivenDescriptorPanel extends BasicDomElementComponent<MessageDrivenDescriptor> implements CommittablePanel {
  protected com.intellij.util.xml.ui.TextPanel myDestinationJndiName;
  private JPanel myPanel;

  public MessageDrivenDescriptorPanel(final WeblogicEnterpriseBean bean) {
    super(bean.getManager().createStableValue(new Factory<MessageDrivenDescriptor>() {
      public MessageDrivenDescriptor create() {
        return bean.getMessageDrivenDescriptor();
      }
    }));
    bindProperties();
  }

  public JComponent getComponent() {
    return myPanel;
  }

}
