/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9;

import com.intellij.javaee.weblogic.runDebug.configuration.WeblogicModel;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.ServerPollThread;
import com.intellij.openapi.project.Project;

import java.security.PrivilegedActionException;

/**
 * @author nik
 */
class ServerPollThreadForWL9 extends ServerPollThread {
  ServerPollThreadForWL9(final Weblogic9AbstractInstance weblogicAbstractInstance,
                         final Project project,
                         final WeblogicModel runConfiguration) {
    super(weblogicAbstractInstance, project, runConfiguration);
  }

  protected Weblogic9AbstractInstance getWeblogicInstance() {
    return (Weblogic9AbstractInstance)super.getWeblogicInstance();
  }

  protected void runRequest(Runnable request) throws PrivilegedActionException {
    request.run();
  }

  protected void initialize() {
  }

  public void refreshState() {
    getWeblogicInstance().refreshStateImpl();
  }
}
