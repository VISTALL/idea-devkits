package com.intellij.javaee.weblogic.appServerIntegration;

import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.javaee.weblogic.WeblogicPsiElementsProvider;
import com.intellij.javaee.ExternalResourceManager;
import com.intellij.javaee.CommonModelManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.NonNls;

/**
 * @author nik
 */
public class WebLogicApplicationComponent implements ApplicationComponent {
  private final ExternalResourceManager myExternalResourceManager;
  private final CommonModelManager myJavaeeManager;

  public WebLogicApplicationComponent(ExternalResourceManager externalResourceManager, final CommonModelManager javaeeManager) {
    myExternalResourceManager = externalResourceManager;
    myJavaeeManager = javaeeManager;
  }

  @NotNull
  public String getComponentName() {
    return "WebLogicApplicationComponent";
  }

  public void initComponent() {
    addResource("http://www.bea.com/servers/wls600/dtd/weblogic-ejb-jar.dtd", "/res/v6/weblogic-ejb-jar.dtd");
    addResource("http://www.bea.com/servers/wls700/dtd/weblogic-ejb-jar.dtd", "/res/v7/weblogic-ejb-jar.dtd");
    addResource("http://www.bea.com/servers/wls810/dtd/weblogic-ejb-jar.dtd", "/res/v8/weblogic-ejb-jar.dtd");
    addResource("http://www.bea.com/ns/weblogic/90/weblogic-ejb-jar.xsd", "/res/v9/weblogic-ejb-jar.xsd");

    addResource("http://www.bea.com/servers/wls600/dtd/weblogic-rdbms20-persistence-600.dtd", "/res/v6/weblogic-rdbms20-persistence-600.dtd");
    addResource("http://www.bea.com/servers/wls700/dtd/weblogic-rdbms20-persistence-700.dtd", "/res/v7/weblogic-rdbms20-persistence-700.dtd");
    addResource("http://www.bea.com/servers/wls810/dtd/weblogic-rdbms20-persistence-810.dtd", "/res/v8/weblogic-rdbms20-persistence-810.dtd");
    addResource("http://www.bea.com/ns/weblogic/90/weblogic-rdbms20-persistence.xsd", "/res/v9/weblogic-rdbms20-persistence.xsd");

    addResource("http://www.bea.com/servers/wls610/dtd/weblogic-web-jar.dtd", "/res/v6/weblogic-web-jar.dtd");
    addResource("http://www.bea.com/servers/wls700/dtd/weblogic700-web-jar.dtd", "/res/v7/weblogic700-web-jar.dtd");
    addResource("http://www.bea.com/servers/wls810/dtd/weblogic810-web-jar.dtd", "/res/v8/weblogic810-web-jar.dtd");
    addResource("http://www.bea.com/ns/weblogic/90/weblogic-web-app.xsd", "/res/v9/weblogic-web-app.xsd");

    addResource("http://www.bea.com/servers/wls700/dtd/weblogic-application_1_0.dtd", "/res/v7/weblogic-application_1_0.dtd");
    addResource("http://www.bea.com/servers/wls810/dtd/weblogic-application_2_0.dtd", "/res/v8/weblogic-application_2_0.dtd");
    addResource("http://www.bea.com/ns/weblogic/90/weblogic-application.xsd", "/res/v9/weblogic-application.xsd");

    myJavaeeManager.registerDeleteHandler(new WeblogicPsiElementsProvider());
  }

  private void addResource(@NonNls String url, @NonNls String location) {
    myExternalResourceManager.addStdResource(url, location, getClass());
  }

  public void disposeComponent() {
  }
}
