/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.applicationServer;

import com.intellij.javaee.weblogic.beaInstallation.BeaInstallation;
import com.intellij.javaee.weblogic.beaInstallation.BeaVersion;
import com.intellij.javaee.weblogic.beaInstallation.WeblogicUtil;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.appServerIntegrations.*;

import java.io.File;

public class WeblogicApplicationServerHelper implements ApplicationServerHelper {
  public ApplicationServerPersistentData createPersistentDataEmptyInstance() {
    return new WeblogicPersistentData();
  }

  public ApplicationServerInfo getApplicationServerInfo(ApplicationServerPersistentData persistentData)
    throws CantFindApplicationServerJarsException {
    final WeblogicPersistentData weblogicPersistentData = (WeblogicPersistentData)persistentData;
    final BeaInstallation beaHome = WeblogicUtil.getInstallationByLocation(new File(weblogicPersistentData.BEA_HOME.replace('/', File.separatorChar)));
    final BeaVersion selectedVersion = beaHome.findVersionByName(weblogicPersistentData.VERSION);
    if (selectedVersion != null) {
      final File jar = selectedVersion.getJarFile();
      if (!jar.isFile()) {
        throw new CantFindApplicationServerJarsException(WeblogicBundle.message("message.name.cant.find.file", jar.getAbsolutePath()));
      }
      File[] jars;
      if (selectedVersion.getName().startsWith("10.")) {
        jars = new File[]{jar, new File(selectedVersion.getLibDir(), "api.jar")};
      }
      else {
        jars = new File[]{jar};
      }
      return new ApplicationServerInfo(jars, WeblogicBundle.message("default.configured.server.name", selectedVersion.getName()));
    }
    else {
      throw new CantFindApplicationServerJarsException(
        WeblogicBundle.message("exception.text.version.does.not.exist.in.directory", weblogicPersistentData.VERSION,
                               weblogicPersistentData.BEA_HOME.replace('/', File.separatorChar))
      );
    }
  }

  public ApplicationServerPersistentDataEditor createConfigurable() {
    return new WeblogicApplicationServerPersistentDataEditor();
  }

}