/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime;

import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.NonNls;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.DomainRuntimeWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.DomainWL9MBean;

/**
 * @author nik
 */
public class DomainRuntimeServiceWL9MBean extends AbstractWL9MBean {
  @NonNls private static final String SERVER_RUNTIMES_ATTRIBUTE_NAME = "ServerRuntimes";
  @NonNls private static final String DOMAIN_RUNTIME_ATTRIBUTE_NAME = "DomainRuntime";
  @NonNls private static final String DOMAIN_CONFIGURATION_ATTRIBUTE_NAME = "DomainConfiguration";

  public DomainRuntimeServiceWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public @Nullable ServerRuntimeWL9MBean findServerRuntimeByName(@NotNull String serverName) {
    final ObjectName[] children = getChildren(SERVER_RUNTIMES_ATTRIBUTE_NAME);
    for (ObjectName objectName : children) {
      final ServerRuntimeWL9MBean serverRuntime = new ServerRuntimeWL9MBean(getConnection(), objectName);
      if (serverName.equals(serverRuntime.getName())) {
        return serverRuntime;
      }
    }
    return null;
  }

  public ServerRuntimeWL9MBean[] getServers() {
    final ObjectName[] children = getChildren(SERVER_RUNTIMES_ATTRIBUTE_NAME);
    final ServerRuntimeWL9MBean[] servers = new ServerRuntimeWL9MBean[children.length];
    for (int i = 0; i < children.length; i++) {
      servers[i] = new ServerRuntimeWL9MBean(getConnection(), children[i]);
    }
    return servers;
  }

  public DomainRuntimeWL9MBean getDomainRuntime() {
    return new DomainRuntimeWL9MBean(getConnection(), getChild(DOMAIN_RUNTIME_ATTRIBUTE_NAME));
  }

  public DomainWL9MBean getDomainConfiguration() {
    return new DomainWL9MBean(getConnection(), getChild(DOMAIN_CONFIGURATION_ATTRIBUTE_NAME));
  }
}
