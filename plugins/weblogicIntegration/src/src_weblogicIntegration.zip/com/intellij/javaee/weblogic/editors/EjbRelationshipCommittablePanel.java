/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.editors;

import com.intellij.javaee.model.enums.Multiplicity;
import com.intellij.javaee.model.xml.ejb.EjbRelation;
import com.intellij.javaee.model.xml.ejb.EjbRelationshipRole;
import com.intellij.javaee.ui.ComplexElementWrapper;
import com.intellij.javaee.ui.DialogCommittableTab;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsJar;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsRelation;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRelationshipRole;
import com.intellij.openapi.application.Result;
import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.Condition;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.xml.ui.CommittablePanel;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class EjbRelationshipCommittablePanel extends DialogCommittableTab<WeblogicRdbmsRelation> {
  private final EjbRelation myEjbRelation;
  @NotNull private CommittablePanel myDelegate = new CommittablePanel() {
    public JComponent getComponent() {
      return null;
    }

    public void commit() {
    }

    public void reset() {
    }

    public void dispose() {
    }
  };
  private final JPanel myPanel = new JPanel(new BorderLayout());

  public EjbRelationshipCommittablePanel(final String name, final WeblogicRdbmsJar root, final EjbRelation ejbRelation) {
    super(name, new ComplexElementWrapper<WeblogicRdbmsRelation>(
      ContainerUtil.find(root.getWeblogicRdbmsRelations(), new Condition<WeblogicRdbmsRelation>() {
        public boolean value(final WeblogicRdbmsRelation object) {
          return Comparing.equal(ejbRelation.getEjbRelationName().getValue(), object.getRelationName().getValue());
        }
      }), WeblogicRdbmsRelation.class, root.getModule()) {

      protected void initMockElement(final WeblogicRdbmsRelation relation) {
        relation.getRelationName().setValue(ejbRelation.getEjbRelationName().getValue());
      }

      protected WeblogicRdbmsRelation createRealElement() {
        return root.addWeblogicRdbmsRelation();
      }
    });
    myEjbRelation = ejbRelation;
  }

  public JComponent getPreferredFocusedComponent() {
    return null;
  }

  public JComponent getComponent() {
    return myPanel;
  }

  public void commit() {
    myDelegate.commit();
  }

  public void dispose() {
    myDelegate.dispose();
  }

  private CommittablePanel createCurrentPage() {
    final EjbRelationshipRole firstRole = myEjbRelation.getEjbRelationshipRole1();
    final EjbRelationshipRole secondRole = myEjbRelation.getEjbRelationshipRole2();

    final WeblogicRdbmsRelation weblogicRdbmsRelation = getDomElement();
    if (firstRole.getMultiplicity().getValue() == Multiplicity.MANY && secondRole.getMultiplicity().getValue() == Multiplicity.MANY) {
      if (myDelegate instanceof ManyToManyColumnsMappingConfigurable) return myDelegate;

      return new ManyToManyColumnsMappingConfigurable(weblogicRdbmsRelation, myEjbRelation);
    }

    if (myDelegate instanceof TableColumnsMappingConfigurable) return myDelegate;

    final EjbRelationshipRole role = secondRole.getMultiplicity().getValue() == Multiplicity.MANY ? firstRole : secondRole;
    final WeblogicRelationshipRole weblogicRole = ensureWeblogicRole(0, weblogicRdbmsRelation, role);
    return new TableColumnsMappingConfigurable(new RdbmsHelper(weblogicRdbmsRelation, weblogicRole, myEjbRelation, role), true);
  }

  static WeblogicRelationshipRole ensureWeblogicRole(final int index,
                                                     final WeblogicRdbmsRelation weblogicRdbmsRelation,
                                                     final EjbRelationshipRole role) {
    new WriteCommandAction(role.getManager().getProject()) {
      protected void run(Result result) throws Throwable {
        final List<WeblogicRelationshipRole> roles = weblogicRdbmsRelation.getWeblogicRelationshipRoles();
        WeblogicRelationshipRole weblogicRole =
          roles.size() < index + 1 ? weblogicRdbmsRelation.addWeblogicRelationshipRole() : roles.get(index);
        weblogicRole.getRelationshipRoleName().setValue(role.getEjbRelationshipRoleName().getValue());
      }
    }.execute();
    return weblogicRdbmsRelation.getWeblogicRelationshipRoles().get(index).createStableCopy();
  }

  public void reset() {
    myDelegate.dispose();
    myDelegate = createCurrentPage();
    myDelegate.reset();
    myPanel.removeAll();
    myPanel.add(myDelegate.getComponent());
    myPanel.revalidate();
    myPanel.repaint();
  }

}