/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.editors;

import com.intellij.javaee.dataSource.*;
import com.intellij.javaee.model.common.ejb.CmpField;
import com.intellij.javaee.model.xml.ejb.EntityBean;
import com.intellij.javaee.module.view.common.attributes.JavaeeTreeTableView;
import com.intellij.javaee.module.view.nodes.JavaeeNodeDescriptor;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.model.persistence.FieldMap;
import com.intellij.javaee.weblogic.model.persistence.TableMap;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsBean;
import com.intellij.openapi.application.Result;
import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Condition;
import com.intellij.openapi.util.Factory;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.util.Function;
import com.intellij.util.JavaeeIcons;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.ui.ColumnInfo;
import com.intellij.util.ui.treetable.TreeColumnInfo;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.ui.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;
import java.util.List;

/**
 * @author Alexey Kudravtsev
 */
public class WLEjbDataSourcePropertiesPanel extends CompositeCommittable implements CommittablePanel {
  private JPanel myPanel;
  private JComboBox myDataSource;

  private WeblogicRdbmsBean myWeblogicBean;
  private final EntityBean myEjb;
  private final Project myProject;
  private JPanel myTablesPanel;
  private JButton myConfigureButton;
  private JavaeeTreeTableView myMappingsEditor;

  protected WLEjbDataSourcePropertiesPanel(final WeblogicRdbmsBean weblogicEjb, EntityBean ejb) {

    myWeblogicBean = weblogicEjb;
    myEjb = ejb;

    myTablesPanel.setLayout(new BorderLayout());

    myProject = weblogicEjb.getManager().getProject();

    final DataSourceManager dataSourceManager = DataSourceManager.getInstance(myProject);
    final GenericDomValue<String> stableDataSourceName = weblogicEjb.getManager().createStableValue(new Factory<GenericDomValue<String>>() {
      public GenericDomValue<String> create() {
        return weblogicEjb.getRightDataSourceName();
      }
    });
    final ComboControl comboControl = addComponent(new ComboControl(stableDataSourceName, new Factory<List<Pair<String, Icon>>>() {
      public List<Pair<String, Icon>> create() {
        return ContainerUtil.map2List(dataSourceManager.getDataSources(), new Function<DataSource, Pair<String, Icon>>() {
          public Pair<String, Icon> fun(final DataSource s) {
            return Pair.create(s.getName(), JavaeeIcons.DATASOURCE_ICON);
          }
        });
      }
    }));

    comboControl.bind(myDataSource);

    comboControl.addCommitListener(new CommitAdapter() {
      public void afterCommit(DomUIControl control) {
        resetTableList();
      }
    });


    myMappingsEditor = addComponent(new MyJavaeeTreeTableView());

    dataSourceManager.addDataSourceListener(new DataSourceListener() {
      public void dataSourceAdded(DataSource dataSource) {
        reset();
      }

      public void dataSourceRemoved(DataSource dataSource) {
        reset();
      }

      public void dataSourceChanged(DataSource dataSource) {
        reset();
      }
    }, this);
    myConfigureButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dataSourceManager.manageDatasources();
      }
    });

    myTablesPanel.add(myMappingsEditor.getComponent());
  }

  private void saveCMPMapping(final String cmpField, final DatabaseTableFieldData fieldData) {
    final List<TableMap> list = myWeblogicBean.getTableMaps();
    if (!StringUtil.isEmpty(cmpField)) {
      for (final TableMap tableMap : list) {
        for (final FieldMap map : tableMap.getFieldMaps()) {
          if (cmpField.equals(map.getCmpField().getStringValue())) {
            map.undefine();
          }
        }
      }
    }

    final String tableName = fieldData.getTable().getName();
    TableMap tableMap = null;
    if (tableName != null) {
      tableMap = ContainerUtil.find(list, new Condition<TableMap>() {
        public boolean value(final TableMap object) {
          return tableName.equals(object.getTableName().getValue());
        }
      });
    }
    if (tableMap == null) {
      if (cmpField == null) return;

      tableMap = myWeblogicBean.addTableMap();
      tableMap.getTableName().setValue(tableName);
    }

    FieldMap fieldMap = ContainerUtil.find(tableMap.getFieldMaps(), new Condition<FieldMap>() {
      public boolean value(final FieldMap fieldMap) {
        return fieldData.getName().equals(fieldMap.getDbmsColumn().getValue());
      }
    });
    if (cmpField != null) {
      if (fieldMap == null) {
        fieldMap = tableMap.addFieldMap();
        fieldMap.getDbmsColumn().setValue(fieldData.getName());
      }
      fieldMap.getCmpField().setStringValue(cmpField);
    } else if (fieldMap != null) {
      fieldMap.undefine();
    }
  }


  @Nullable
  private String getSelectedDataSourceName() {
    final Pair<String, Icon> pair = (Pair<String, Icon>)myDataSource.getSelectedItem();
    return pair == null ? null : pair.first;
  }

  private void resetTableList() {
    myMappingsEditor.reset();
  }

  public JComponent getComponent() {
    return myPanel;
  }

  private class MyNodeDescriptor<T> extends JavaeeNodeDescriptor<T> {
    public MyNodeDescriptor(JavaeeNodeDescriptor parent, T element) {
      super(WLEjbDataSourcePropertiesPanel.this.myProject, parent, null, element);
    }

    protected String getNewNodeText() {
      return null;
    }

    public JavaeeNodeDescriptor[] getChildren() {
      DataSource dataSource = DataSourceManager.getInstance(myProject).getDataSourceByName(getSelectedDataSourceName());
      if (dataSource == null) return EMPTY_ARRAY;

      return ContainerUtil.map2Array(dataSource.getTables(), JavaeeNodeDescriptor.class, new Function<DatabaseTableData, JavaeeNodeDescriptor>() {
        public JavaeeNodeDescriptor fun(final DatabaseTableData table) {
          return new TableNodeDescriptor(MyNodeDescriptor.this, table);
        }
      });
    }

    private class TableNodeDescriptor extends MyNodeDescriptor<DatabaseTableData> {
      public TableNodeDescriptor(final MyNodeDescriptor<T> nodeDescriptor, final DatabaseTableData table) {
        super(nodeDescriptor, table);
        myOpenIcon = myClosedIcon = JavaeeIcons.DATASOURCE_TABLE_ICON;
      }

      protected String getNewNodeText() {
        return getElement().getName();
      }


      public JavaeeNodeDescriptor[] getChildren() {
        return ContainerUtil.map2Array(getElement().getFields(), JavaeeNodeDescriptor.class, new Function<DatabaseTableFieldData, JavaeeNodeDescriptor>() {
          public JavaeeNodeDescriptor fun(final DatabaseTableFieldData s) {
            return new MyNodeDescriptor<DatabaseTableFieldData>(TableNodeDescriptor.this, s) {
              {
                myOpenIcon = myClosedIcon = JavaeeIcons.DATASOURCE_TABLE_ICON;
              }

              protected String getNewNodeText() {
                return getElement().getName();
              }

              public JavaeeNodeDescriptor[] getChildren() {
                return JavaeeNodeDescriptor.EMPTY_ARRAY;
              }
            };
          }
        });
      }
    }


  }

  private class MyJavaeeTreeTableView extends JavaeeTreeTableView {
    public MyJavaeeTreeTableView() {
      super(WLEjbDataSourcePropertiesPanel.this.myProject, new MyNodeDescriptor(null, Boolean.TRUE));
      getTreeTableView().setShowVerticalLines(true);
      getTreeTableView().setIntercellSpacing(new Dimension(1, 0));
      init();
    }

    protected boolean isShowTree() {
      return DataSourceManager.getInstance(myProject).getDataSourceByName(getSelectedDataSourceName()) != null;
    }

    @NotNull
    protected String getEmptyPaneText() {
      final String dataSourceName = getSelectedDataSourceName();
      if (dataSourceName == null) {
        return WeblogicBundle.message("label.text.no.data.source.selected");
      }

      return WeblogicBundle.message("label.text.unknown.data.source", dataSourceName);
    }

    protected ColumnInfo[] createColumnInfos() {
      return new ColumnInfo[]{
        new TreeColumnInfo(WeblogicBundle.message("column.name.configure.ejbs.table.column")),
        new ColumnInfo<JavaeeNodeDescriptor,String>(WeblogicBundle.message("column.name.configure.ejbs.cmp.field")) {

          public void setValue(final JavaeeNodeDescriptor o, final String aValue) {
            new WriteCommandAction(getProject()) {
              protected void run(Result result) throws Throwable {
                saveCMPMapping(aValue, (DatabaseTableFieldData)o.getElement());
              }
            }.execute();
          }

          public boolean isCellEditable(final JavaeeNodeDescriptor o) {
            return o.getElement() instanceof DatabaseTableFieldData;
          }

          public TableCellRenderer getCustomizedRenderer(final JavaeeNodeDescriptor o, final TableCellRenderer renderer) {
            final Object element = o.getElement();
            if (element instanceof DatabaseTableFieldData) {
              final DatabaseTableFieldData databaseTableFieldData = (DatabaseTableFieldData)element;
              final GenericDomValue<CmpField> reference = getCmpFieldReference(databaseTableFieldData);
              if (reference != null) {
                return new ErrorableTableCellRenderer<GenericDomValue<CmpField>>(reference, super.getCustomizedRenderer(o, renderer), reference.getParent());
              }
            }
            return super.getCustomizedRenderer(o, renderer);
          }

          public TableCellEditor getEditor(final JavaeeNodeDescriptor item) {
            return new ComboTableCellEditor(ComboControl.createPresentationFunction(new Factory<Collection<? extends Object>>() {
              public Collection<? extends Object> create() {
                return myEjb.getCmpFields();
              }
            }), true);
          }

          @Nullable
          private GenericDomValue<CmpField> getCmpFieldReference(DatabaseTableFieldData fieldData) {
            final String tableName = fieldData.getTable().getName();
              if (tableName != null) {
                TableMap tableMap = ContainerUtil.find(myWeblogicBean.getTableMaps(), new Condition<TableMap>() {
                  public boolean value(final TableMap object) {
                    return tableName.equals(object.getTableName().getValue());
                  }
                });
                if (tableMap != null) {
                  final String fieldName = fieldData.getName();
                  if (fieldName != null) {
                    FieldMap fieldMap = ContainerUtil.find(tableMap.getFieldMaps(), new Condition<FieldMap>() {
                      public boolean value(final FieldMap object) {
                        return fieldName.equals(object.getDbmsColumn().getValue());
                      }
                    });
                    if (fieldMap != null) {
                      return fieldMap.getCmpField();
                    }
                  }
                }
              }
            return null;
          }

          public String valueOf(final JavaeeNodeDescriptor object) {
            final Object element = object.getElement();
            if (element instanceof DatabaseTableFieldData) {
              final GenericDomValue<CmpField> reference = getCmpFieldReference((DatabaseTableFieldData)element);
              if (reference != null) {
                return reference.getStringValue();
              }
            }
            return null;
          }
        }
      };
    }
  }
}
