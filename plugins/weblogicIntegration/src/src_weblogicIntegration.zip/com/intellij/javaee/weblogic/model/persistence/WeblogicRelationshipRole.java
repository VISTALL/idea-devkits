// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.SubTag;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:weblogic-relationship-roleType interface.
 */
public interface WeblogicRelationshipRole extends JavaeeDomModelElement {

	/**
	 * Returns the value of the relationship-role-name child.
	 * @return the value of the relationship-role-name child.
	 */
	@NotNull
	GenericDomValue<String> getRelationshipRoleName();


	/**
	 * Returns the value of the group-name child.
	 * @return the value of the group-name child.
	 */
	GenericDomValue<String> getGroupName();


	/**
	 * Returns the value of the relationship-role-map child.
	 * @return the value of the relationship-role-map child.
	 */
	RelationshipRoleMap getRelationshipRoleMap();


	/**
	 * Returns the value of the db-cascade-delete child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:emptyType documentation</h3>
	 * This type is used to designate an empty
	 * 	element when used.
	 * </pre>
	 * @return the value of the db-cascade-delete child.
	 */
	@SubTag (value = "db-cascade-delete", indicator = true)
	GenericDomValue<Boolean> getDbCascadeDelete();


	/**
	 * Returns the value of the enable-query-caching child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the enable-query-caching child.
	 */
	GenericDomValue<Boolean> getEnableQueryCaching();


}
