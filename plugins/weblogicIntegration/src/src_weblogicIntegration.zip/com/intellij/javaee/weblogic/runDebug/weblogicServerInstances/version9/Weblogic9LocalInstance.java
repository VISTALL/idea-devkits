/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9;

import com.intellij.execution.ExecutionException;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.DeployerRuntimeWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.AutoDeployUtil;

import java.io.File;
import java.io.IOException;

/**
 * @author nik
 */
public class Weblogic9LocalInstance extends Weblogic9AbstractInstance {
  public Weblogic9LocalInstance(final CommonModel commonModel) throws ExecutionException {
    super(commonModel);
  }

  protected void autoDeploy(final File source) {
    try {
      AutoDeployUtil.autoDeploy(getCommonModel(), source);
    }
    catch (IOException e) {
      registerServerError(e);
    }
  }

  protected void deploy(final File source, final String name, final String appName) {
    final DeployerRuntimeWL9MBean deployerRuntime = myDomainRuntimeService.getDomainRuntime().getDeployerRuntime();
    undeployIfDeployed(name, appName, deployerRuntime);
    deployerRuntime.deploy(source.getPath(), name, getServerName());
  }

  protected void undeploy(final String name) {
    myDomainRuntimeService.getDomainRuntime().getDeployerRuntime().remove(name, getServerName());
  }

  protected void autoUndeploy(final File source) {
    AutoDeployUtil.autoUndeploy(getCommonModel(), source);
  }

  public boolean connect() {
    final boolean[] connected = new boolean[]{false};
    getServerPollThread().queueRequestAndWait(new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.local.connect");
      }

      public void run() {
        refreshState();
        connected[0] = getState() != null;
      }
    });
    return connected[0];
  }
}
