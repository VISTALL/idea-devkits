/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicAbstractInstance;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.ServerPollThread;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.LogNotificationListener;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.*;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.ApplicationRuntimeWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.ComponentRuntimeWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.DomainRuntimeServiceWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.ServerRuntimeWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.jdbc.*;
import com.intellij.javaee.weblogic.runDebug.configuration.WeblogicModel;
import com.intellij.javaee.weblogic.dataSource.WeblogicDataSourceInfo;
import com.intellij.javaee.weblogic.WeblogicConnectionPoolInfo;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegration;
import com.intellij.javaee.weblogic.applicationServer.WeblogicPersistentData;
import com.intellij.j2ee.wrappers.*;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentStatus;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.appServerIntegrations.ApplicationServerPersistentData;
import com.intellij.javaee.appServerIntegrations.ApplicationServer;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.execution.ExecutionException;

import javax.sql.DataSource;
import javax.management.*;
import javax.management.Notification;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.*;
import java.io.IOException;
import java.io.File;
import java.net.MalformedURLException;

import org.jetbrains.annotations.Nullable;

/**
 * @author nik
 */
public abstract class Weblogic9AbstractInstance extends WeblogicAbstractInstance {
  private static final int START_EDIT_WAIT_TIME = 5000;
  private static final int START_EDIT_TIMEOUT = 5000;
  private static final int ACTIVATE_TIMEOUT = 5000;
  private boolean myIsStarting;
  private NotificationListener myLogNotificationListener;
  private WL9OutputInfo myWL9OutputInfo = new WL9OutputInfo();
  protected DomainRuntimeServiceWL9MBean myDomainRuntimeService;
  protected final ClassLoader myWeblogicClassloader;
  private InitialContext myInitialContext;
  private WeblogicJMXConnector<DomainRuntimeServiceWL9MBean> myDomainServiceConnector = WeblogicJMXConnector.createDomainRuntimeConnector();
  private WeblogicJMXConnector<EditServiceWL9MBean> myEditServiceConnector = WeblogicJMXConnector.createEditServiceConnector();
  protected ServerRuntimeWL9MBean myServerRuntime;
  private Exception myLoginException;
  private Map<String, String> myModuleName2ContextRoot = new HashMap<String, String>();

  protected Weblogic9AbstractInstance(final CommonModel commonModel) throws ExecutionException {
    super(commonModel);
    try {
      final ApplicationServer applicationServer = getCommonModel().getApplicationServer();
      final ApplicationServerPersistentData persistentData = applicationServer.getPersistentData();
      myWeblogicClassloader = ((WeblogicPersistentData)persistentData).getClassLoader(getCommonModel(), getClass().getClassLoader());
      myWeblogicClassloader.loadClass(WEBLOGIC_SERVER_CLASS);
    }
    catch (MalformedURLException e) {
      throw new ExecutionException(e.getLocalizedMessage());
    }
    catch (ClassNotFoundException e) {
      throw new ExecutionException(e.getLocalizedMessage());
    }
    initialize();
  }

  protected void initialize() {
    myIsStarting = true;
    registerServerPollThread();
  }

  protected ServerPollThread createServerPollThread() {
    final ServerPollThreadForWL9 serverPollThread = new ServerPollThreadForWL9(this, myProject, getWeblogicConfiguration());
    serverPollThread.setContextClassLoader(myWeblogicClassloader);
    return serverPollThread;
  }

  public ServerPollThreadForWL9 getServerPollThread() {
    return (ServerPollThreadForWL9)super.getServerPollThread();
  }

  private void initConnection() throws IOException, NamingException {
    connect(myDomainServiceConnector);
    myIsStarting = false;
    myDomainRuntimeService = myDomainServiceConnector.getRootMBean();
    myServerRuntime = myDomainRuntimeService.findServerRuntimeByName(getServerName());
    if (myServerRuntime == null) {
      final ServerRuntimeWL9MBean[] servers = myDomainRuntimeService.getServers();
      if (servers.length > 0) {
        myServerRuntime = servers[0];
        setServerName(myServerRuntime.getName());
      }
    }
    myInitialContext = createInitialContext();
  }

  private void connect(final WeblogicJMXConnector<?> connector) throws IOException {
    final WeblogicModel weblogicConfiguration = getWeblogicConfiguration();
    connector.connect(getCommonModel().getHost(), getCommonModel().getPort(),
                      weblogicConfiguration.USER, weblogicConfiguration.PASSWORD);
  }

  protected DeploymentStatus getDeploymentStatus(DeploymentModel model) throws MalformedObjectNameExceptionWrapper {
    if (!isConnected()) {
      return DeploymentStatus.UNKNOWN;
    }

    try {
      final String appName = getInternalWeblogicDeploymentName(model);
      if (myServerRuntime == null) {
        return DeploymentStatus.NOT_DEPLOYED;
      }
      final ApplicationRuntimeWL9MBean applicationRuntime = myServerRuntime.findApplicationRuntimeByName(appName);
      if (applicationRuntime == null) {
        return DeploymentStatus.NOT_DEPLOYED;
      }
      final ComponentRuntimeWL9MBean[] componentRuntimes = applicationRuntime.getComponentRuntimes();
      if (componentRuntimes.length == 0) {
        return DeploymentStatus.FAILED;
      }
      for (ComponentRuntimeWL9MBean componentRuntime : componentRuntimes) {
        if (componentRuntime.isWebAppComponent()) {
          myModuleName2ContextRoot.put(model.MODULE_NAME, componentRuntime.getContextRoot());
        }
        if (componentRuntime.getDeploymentState() != ComponentRuntimeWL9MBean.STATE_ACTIVATED) {
          return DeploymentStatus.FAILED;
        }
      }
      return DeploymentStatus.DEPLOYED;
    }
    catch (JMWrappedException e) {
      registerServerError(e);
      return DeploymentStatus.NOT_DEPLOYED;
    }
  }

  public DataSource getDataSource(final String dataSourceName) {
    final DataSource[] dataSource = new DataSource[]{null};
    getServerPollThread().queueRequestAndWait(new Runnable() {
      public void run() {
        if (!isConnected() || myInitialContext == null) return;
        String jndiName = getJNDIName(dataSourceName);
        if (jndiName != null) {
          try {
            final Object ds = myInitialContext.lookup(jndiName);
            if (ds instanceof DataSource) {
              dataSource[0] = (DataSource)ds;
            }
          }
          catch (NamingException e) {
          }
        }
      }
    });
    return dataSource[0];
  }

  private @Nullable String getJNDIName(final String dataSourceName) {
    final JDBCSystemResourceWL9MBean[] resources = myDomainRuntimeService.getDomainConfiguration().getJDBCSystemResources();
    for (JDBCSystemResourceWL9MBean resource : resources) {
      if (dataSourceName.equals(resource.getJDBCResource().getName())) {
        final String[] jndiNames = resource.getJDBCResource().getJDBCDataSourceParams().getJNDINames();
        if (jndiNames.length > 0) {
          return jndiNames[0];
        }
        return null;
      }
    }
    return null;
  }

  public String[] getConfiguredDataSourceNames() {
    final List<String> names = new ArrayList<String>();
    Runnable runnable = new Runnable() {
      public void run() {
        final JDBCSystemResourceWL9MBean[] resources = myDomainRuntimeService.getDomainConfiguration().getJDBCSystemResources();
        for (JDBCSystemResourceWL9MBean resource : resources) {
          names.add(resource.getJDBCResource().getName());
        }
      }
    };
    getServerPollThread().queueRequestAndWait(runnable);
    return names.toArray(new String[names.size()]);
  }

  public void createDatasource(final WeblogicDataSourceInfo info, final WeblogicConnectionPoolInfo poolInfo) throws Exception {
    final Runnable runnable = new Runnable() {
      public void run() {
        try {
          connect(myEditServiceConnector);
        }
        catch (IOException e) {
          throw new JMWrappedException(e);
        }
        EditServiceWL9MBean editService = myEditServiceConnector.getRootMBean();
        final ConfigurationManagerWL9MBean configurationManager = editService.getConfigurationManager();
        final DomainWL9MBean domain = configurationManager.startEdit(START_EDIT_WAIT_TIME, START_EDIT_TIMEOUT);
        try {
          final JDBCSystemResourceWL9MBean jdbcSystemResource = domain.createJDBCSystemResource(info.dsName);
          final JDBCDataSourceWL9Bean jdbcResource = jdbcSystemResource.getJDBCResource();
          final JDBCDataSourceParamsWL9Bean dataSourceParams = jdbcResource.getJDBCDataSourceParams();
          final JDBCConnectionPoolParamsWL9Bean connectionPoolParams = jdbcResource.getJDBCConnectionPoolParams();
          final JDBCDriverParamsWL9Bean jdbcDriverParams = jdbcResource.getJDBCDriverParams();

          jdbcResource.setName(info.dsName);
          jdbcSystemResource.setNotes(info.notes);
          addTargets(domain, jdbcSystemResource);
          dataSourceParams.setJNDINames(new String[]{info.jndiName});
          dataSourceParams.setRowPrefetch(info.rowPrefetchEnabled);
          dataSourceParams.setRowPrefetchSize(info.rowPrefetchSize);
          dataSourceParams.setStreamChunkSize(info.streamChunkSize);
          dataSourceParams.setGlobalTransactionsProtocol(getGlobalTransactionProtocol(info));
          connectionPoolParams.setCapacityIncrement(poolInfo.capacityIncrement);
          connectionPoolParams.setInitialCapacity(poolInfo.initialCapacity);
          connectionPoolParams.setMaxCapacity(poolInfo.maxCapacity);
          jdbcDriverParams.setDriverClass(poolInfo.driverClassname);
          jdbcDriverParams.setUrl(poolInfo.url);
          setProperties(jdbcDriverParams, poolInfo.properties);

          configurationManager.save();
          configurationManager.activate(ACTIVATE_TIMEOUT);
          myEditServiceConnector.disconnect();
        }
        catch (JMWrappedException e) {
          configurationManager.stopEdit();
          throw e;
        }
        catch (IOException e) {
          throw new JMWrappedException(e);
        }
      }
    };
    getServerPollThread().queueRequestAndWait(runnable);
  }

  private static void setProperties(final JDBCDriverParamsWL9Bean jdbcDriverParams, final Properties properties) {
    final JDBCPropertiesWL9Bean propertiesBean = jdbcDriverParams.getProperties();
    for (Map.Entry<Object, Object> entry : properties.entrySet()) {
      final JDBCPropertyWL9Bean property = propertiesBean.createProperty((String)entry.getKey());
      property.setValue((String)entry.getValue());
    }
  }

  private static void addTargets(final DomainWL9MBean domain, final JDBCSystemResourceWL9MBean jdbcSystemResource) {
    Set<TargetWL9MBean> targets = new HashSet<TargetWL9MBean>();
    final AppDeploymentWL9MBean[] appDeployments = domain.getAppDeployments();
    for (AppDeploymentWL9MBean appDeployment : appDeployments) {
      final TargetWL9MBean[] appTargets = appDeployment.getTargets();
      targets.addAll(Arrays.asList(appTargets));
    }

    for (TargetWL9MBean target : targets) {
      jdbcSystemResource.addTarget(target);
    }
  }

  private static JDBCDataSourceParamsWL9Bean.GlobalTransactionsProtocol getGlobalTransactionProtocol(final WeblogicDataSourceInfo info) {
    if (!info.isTxDataSource) {
      return JDBCDataSourceParamsWL9Bean.GlobalTransactionsProtocol.NONE;
    }
    return info.enableTwoPhaseCommit
           ? JDBCDataSourceParamsWL9Bean.GlobalTransactionsProtocol.TWO_PHASE_COMMIT
           : JDBCDataSourceParamsWL9Bean.GlobalTransactionsProtocol.ONE_PHASE_COMMIT;
  }

  public WeblogicOutputInfo getOutputInfo() {
    return myWL9OutputInfo;
  }

  private void unregisterLogNotificationListener() {
    if (myLogNotificationListener == null) return;
    myServerRuntime.getLogBroadcasterRuntime().removeNotificationListener(myLogNotificationListener);
  }

  protected void registerLogNotificationListener() {
    unregisterLogNotificationListener();

    if (myLogNotificationListener == null) {
      myLogNotificationListener = new NotificationListener() {
        public void handleNotification(final Notification notification, Object handback) {
          final WebLogic9LogNotificationWrapper notificationWrapper = new WebLogic9LogNotificationWrapper(notification, myWeblogicClassloader);
          fireLogNotificationListeners(new LogNotificationListener.LogNotification() {
            public WebLogicLogNotification getNotification() {
              return notificationWrapper;
            }
          });
        }
      };
    }
    myServerRuntime.getLogBroadcasterRuntime().addNotificationListener(myLogNotificationListener);
  }

  public WebLogicLogNotification createWebLogicLogNotification(Date date,
                                                               @Nullable String type,
                                                               long sequenceNumber,
                                                               int severity,
                                                               String message,
                                                               Object source,
                                                               Throwable throwable) {
    if (type == null) {
      type = "Type";
    }
    return new WebLogic9LogNotificationWrapper(new Notification(type, source, sequenceNumber, date.getTime(), message), "servername", severity, throwable);
  }

  public @Nullable String getContextRoot(String moduleName) {
    return myModuleName2ContextRoot.get(moduleName);
  }

  public boolean isStarting() {
    return myIsStarting;
  }

  public boolean isConnected() {
    return myDomainServiceConnector.isConnected();
  }

  public void cleanup() {
    super.cleanup();
    myServerRuntime = null;
    myDomainRuntimeService = null;
  }

  protected void instanceStopped() {
    unregisterLogNotificationListener();
    try {
      if (myDomainServiceConnector != null) {
        myDomainServiceConnector.disconnect();
      }
    }
    catch (IOException e) {
    }
    super.instanceStopped();
  }

  public void refreshStateImpl() {
    try {
      if (myServerRuntime != null) {
        setState(myServerRuntime.getState());
        return;
      }
    }
    catch (JMWrappedException e) {
    }

    myLoginException = null;
    try {
      initConnection();
    }
    catch (IOException e) {
      myLoginException = e;
    }
    catch (NamingException e) {
      myLoginException = e;
    }
    if (myServerRuntime == null) return;
    setState(myServerRuntime.getState());
  }

  protected Exception getLoginException() {
    return myLoginException;
  }

  public void startDeploy(DeploymentModel model) {
    if (!isConnected()) return;
    final JavaeeModuleProperties moduleProperties = model.getModuleProperties();
    File source = getDeploymentSource(model);
    if (source == null) {
      ApplicationManager.getApplication().invokeLater(new Runnable() {
        public void run() {
          reportNoDeploymentSource(moduleProperties);
        }
      });
      return;
    }
    if (model.getDeploymentMethod() == WeblogicIntegration.AUTODEPLOY) {
      autoDeploy(moduleProperties, source);
      return;
    }

    final String name = moduleProperties.getModule().getName();
    getServerPollThread().queueRequest(createDeployAction(source, name, model));
  }

  protected abstract void autoDeploy(JavaeeModuleProperties moduleProperties, File source);

  private Runnable createDeployAction(final File source, final String name, final DeploymentModel model) {
    return new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.local.deploy");
      }

      public void run() {
        try {
          deploy(source, name);
        }
        catch (final JMWrappedException e) {
          registerServerError(e);
        }
        finally {
          updateDeploymentStatus(model);
        }
      }
    };
  }

  protected abstract void deploy(File source, String name);

  public void startUndeploy(DeploymentModel model) {
    JavaeeModuleProperties moduleProperties = model.getModuleProperties();
    final String name = moduleProperties.getModule().getName();
    if (!isConnected()) return;

    File source = getDeploymentSource(model);
    if (source == null) {
      reportNoDeploymentSource(moduleProperties);
      return;
    }
    if (model.getDeploymentMethod() == WeblogicIntegration.AUTODEPLOY) {
      autoUndeploy(source);
      return;
    }

    final Runnable runnable = new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.local.undeploy");
      }

      public void run() {
        try {
          undeploy(name);
        }
        catch (JMWrappedException e) {
          registerServerError(e);
        }
      }
    };
    getServerPollThread().queueRequest(runnable);
  }

  protected abstract void undeploy(String name);

  protected abstract void autoUndeploy(File source);

  public void shutdown() {
    disconnect();
  }
}
