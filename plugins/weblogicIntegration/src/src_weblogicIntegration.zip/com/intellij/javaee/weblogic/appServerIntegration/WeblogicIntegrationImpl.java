/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.appServerIntegration;

import com.intellij.ide.fileTemplates.FileTemplateDescriptor;
import com.intellij.ide.fileTemplates.FileTemplateGroupDescriptor;
import com.intellij.javaee.CommonModelManager;
import com.intellij.javaee.ExternalResourceManager;
import com.intellij.javaee.appServerIntegrations.*;
import com.intellij.javaee.dataSource.DataSourceProvider;
import com.intellij.javaee.deployment.DeploymentProvider;
import com.intellij.javaee.ejb.EjbModuleUtil;
import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.model.xml.ejb.EjbRelation;
import com.intellij.javaee.ui.DialogCommittableTab;
import com.intellij.javaee.weblogic.WLFileTemplateNames;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.WeblogicPsiElementsProvider;
import com.intellij.javaee.weblogic.applicationServer.WeblogicApplicationServerHelper;
import com.intellij.javaee.weblogic.build.WebLogicValidatorsFactory;
import com.intellij.javaee.weblogic.dataSource.WeblogicDataSourceProviderImpl;
import com.intellij.javaee.weblogic.editors.EjbRelationshipCommittablePanel;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsJar;
import com.intellij.javaee.weblogic.module.WLDeploymentDecriptorsConstants;
import com.intellij.javaee.weblogic.module.WeblogicEjbFacetUtil;
import com.intellij.javaee.weblogic.runDebug.deployment.WeblogicDeploymentProvider;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.util.IconLoader;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

public class WeblogicIntegrationImpl extends WeblogicIntegration {
  private final WeblogicDeploymentProvider myDeploymentProvider = new WeblogicDeploymentProvider();
  private final WeblogicApplicationServerHelper myWeblogicAppServerDKInstallationHelper = new WeblogicApplicationServerHelper();
  private static final Icon ICON = IconLoader.getIcon("/nodes/beaSmall.png");
  private ExternalResourceManager myExternalResourceManager;

  public WeblogicIntegrationImpl(ExternalResourceManager externalResourceManager, final CommonModelManager javaeeManager) {
    myExternalResourceManager = externalResourceManager;

    addResource("http://www.bea.com/servers/wls600/dtd/weblogic-ejb-jar.dtd", "/res/v6/weblogic-ejb-jar.dtd");
    addResource("http://www.bea.com/servers/wls700/dtd/weblogic-ejb-jar.dtd", "/res/v7/weblogic-ejb-jar.dtd");
    addResource("http://www.bea.com/servers/wls810/dtd/weblogic-ejb-jar.dtd", "/res/v8/weblogic-ejb-jar.dtd");
    addResource("http://www.bea.com/ns/weblogic/90/weblogic-ejb-jar.xsd", "/res/v9/weblogic-ejb-jar.xsd");

    addResource("http://www.bea.com/servers/wls600/dtd/weblogic-rdbms20-persistence-600.dtd", "/res/v6/weblogic-rdbms20-persistence-600.dtd");
    addResource("http://www.bea.com/servers/wls700/dtd/weblogic-rdbms20-persistence-700.dtd", "/res/v7/weblogic-rdbms20-persistence-700.dtd");
    addResource("http://www.bea.com/servers/wls810/dtd/weblogic-rdbms20-persistence-810.dtd", "/res/v8/weblogic-rdbms20-persistence-810.dtd");
    addResource("http://www.bea.com/ns/weblogic/90/weblogic-rdbms20-persistence.xsd", "/res/v9/weblogic-rdbms20-persistence.xsd");

    addResource("http://www.bea.com/servers/wls610/dtd/weblogic-web-jar.dtd", "/res/v6/weblogic-web-jar.dtd");
    addResource("http://www.bea.com/servers/wls700/dtd/weblogic700-web-jar.dtd", "/res/v7/weblogic700-web-jar.dtd");
    addResource("http://www.bea.com/servers/wls810/dtd/weblogic810-web-jar.dtd", "/res/v8/weblogic810-web-jar.dtd");
    addResource("http://www.bea.com/ns/weblogic/90/weblogic-web-app.xsd", "/res/v9/weblogic-web-app.xsd");

    addResource("http://www.bea.com/servers/wls700/dtd/weblogic-application_1_0.dtd", "/res/v7/weblogic-application_1_0.dtd");
    addResource("http://www.bea.com/servers/wls810/dtd/weblogic-application_2_0.dtd", "/res/v8/weblogic-application_2_0.dtd");
    addResource("http://www.bea.com/ns/weblogic/90/weblogic-application.xsd", "/res/v9/weblogic-application.xsd");

    EjbCustomPageProvider.registerEjbCustomPageProvider(new EjbCustomPageProvider() {
      public @Nullable DialogCommittableTab getRelationPage(final EjbRelation ejbRelation) {
        EjbFacet ejbFacet = EjbModuleUtil.getEjbFacet(ejbRelation);
        if (ejbFacet == null) return null;
        final WeblogicRdbmsJar weblogicRdbmsJar = WeblogicEjbFacetUtil.getRdbmsRoot(ejbFacet);
        if (weblogicRdbmsJar == null) return null;

        return new EjbRelationshipCommittablePanel(getPresentableName(), weblogicRdbmsJar, ejbRelation);
      }
    });

    javaeeManager.registerDeleteHandler(new WeblogicPsiElementsProvider());
    EjbDescriptorsMetaDataRegistry.getInstance().registerMetaData(this, WLDeploymentDecriptorsConstants.WL_EJB_JAR_XML_META_DATA);
    EjbDescriptorsMetaDataRegistry.getInstance().registerMetaData(this, WLDeploymentDecriptorsConstants.WL_CMP_RDMS_XML_META_DATA);
    WebDescriptorsMetaDataRegistry.getInstance().registerMetaData(this, WLDeploymentDecriptorsConstants.WEBLOGIC_XML_META_DATA);
    JavaeeApplicationDescriptorsMetaDataRegistry.getInstance().registerMetaData(this, WLDeploymentDecriptorsConstants.WL_APPLICATION_XML_META_DATA);
  }

  public void initComponent() {
  }

  private void addResource(@NonNls String url, @NonNls String location) {
    myExternalResourceManager.addStdResource(url, location, getClass());
  }

  public void disposeComponent() {
  }

  @NotNull
  public String getComponentName() {
    return "WeblogicIntegrationImpl";
  }

  public Icon getIcon() {
    return ICON;
  }

  public String getPresentableName() {
    return WeblogicBundle.message("weblogic.integration.presentable.name");
  }

  public @Nullable AppServerSpecificValidator getAppServerSpecificValidator(@NotNull JavaeeFacet facet, final @NotNull ApplicationServer server) {
    return WebLogicValidatorsFactory.createValidator(facet, server);
  }

  public DeploymentProvider getDeploymentProvider() {
    return myDeploymentProvider;
  }

  public FileTemplateGroupDescriptor getFileTemplatesDescriptor() {
    FileTemplateGroupDescriptor root = new FileTemplateGroupDescriptor(WeblogicBundle.message("template.files.group.title.weblogic"), getIcon());

    FileTemplateGroupDescriptor v6 = new FileTemplateGroupDescriptor(WeblogicBundle.message("template.group.title.version.6.x"), null);
    v6.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_6x, StdFileTypes.XML.getIcon()));
    v6.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_XML_6X, StdFileTypes.XML.getIcon()));
    v6.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_6X, StdFileTypes.XML.getIcon()));
    v6.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_6X, StdFileTypes.XML.getIcon()));
    root.addTemplate(v6);

    FileTemplateGroupDescriptor v7 = new FileTemplateGroupDescriptor(WeblogicBundle.message("template.group.title.version.7.x"), null);
    v7.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_7x, StdFileTypes.XML.getIcon()));
    v7.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_XML_7X, StdFileTypes.XML.getIcon()));
    v7.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_7X, StdFileTypes.XML.getIcon()));
    v7.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_7X, StdFileTypes.XML.getIcon()));
    root.addTemplate(v7);

    FileTemplateGroupDescriptor v8 = new FileTemplateGroupDescriptor(WeblogicBundle.message("template.group.title.version.8.x"), null);
    v8.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_8x, StdFileTypes.XML.getIcon()));
    v8.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_XML_8X, StdFileTypes.XML.getIcon()));
    v8.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_8X, StdFileTypes.XML.getIcon()));
    v8.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_8X, StdFileTypes.XML.getIcon()));
    root.addTemplate(v8);

    FileTemplateGroupDescriptor v9 = new FileTemplateGroupDescriptor(WeblogicBundle.message("template.group.title.version.9.x"), null);
    v9.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_9x, StdFileTypes.XML.getIcon()));
    v9.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_XML_9X, StdFileTypes.XML.getIcon()));
    v9.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_9X, StdFileTypes.XML.getIcon()));
    v9.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_9X, StdFileTypes.XML.getIcon()));
    root.addTemplate(v9);

    return root;
  }

  public @NotNull AppServerDeployedFileUrlProvider getDeployedFileUrlProvider() {
    return WebLogicDeployedFileUrlProvider.INSTANCE;
  }

  public DataSourceProvider getDataSourceProvider() {
    return new WeblogicDataSourceProviderImpl();
  }

  public ApplicationServerHelper getApplicationServerHelper() {
    return myWeblogicAppServerDKInstallationHelper;
  }

  public String toString() {
    return WeblogicBundle.message("weblogin.integration.presentation");
  }
}
