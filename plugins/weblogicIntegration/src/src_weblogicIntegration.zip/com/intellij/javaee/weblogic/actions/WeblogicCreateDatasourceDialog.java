/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.actions;

import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.project.Project;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.dataSource.WeblogicDataSourceInfo;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicInstance;
import com.intellij.ui.IdeBorderFactory;

import javax.swing.*;
import java.awt.*;
import java.util.Properties;
import java.util.StringTokenizer;

/**
 * @author nik
 */
public abstract class WeblogicCreateDatasourceDialog extends DialogWrapper {
  private final WeblogicInstance myWeblogicInstance;
  private final String myDSName;
  private JTextField myJndiName;
  private JCheckBox myRowPrefetchEnabled;
  private JTextField myRowPrefetchSize;
  private JTextField myStreamChunkSize;
  private JTextField myNotes;

  protected WeblogicCreateDatasourceDialog(Project project, final WeblogicInstance instance, final String dsName) {
    super(project, false);
    myWeblogicInstance = instance;
    myDSName = dsName;
  }

  protected JComponent createNorthPanel() {
    final JPanel panel = new JPanel(new BorderLayout());
    panel.add(new JLabel(WeblogicBundle.message("label.create.datasource.specify.configuration.parameters", myDSName)), BorderLayout.NORTH);
    return panel;
  }

  protected JComponent createCenterPanel() {
    final JPanel panel = new JPanel();
    panel.setBorder(IdeBorderFactory.createBorder());
    final GridBagConstraints gb = new GridBagConstraints();
    panel.setLayout(new GridBagLayout());
    gb.fill = GridBagConstraints.BOTH;
    gb.anchor = GridBagConstraints.NORTHWEST;
    gb.gridy = -1;
    gb.gridx = 0;
    gb.insets = new Insets(4, 8, 4, 8);
    JLabel label;

    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 0;
    label = new JLabel(WeblogicBundle.message("label.create.datasource.name"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    final JTextField name = new JTextField(myDSName);
    name.setEditable(false);
    label.setLabelFor(name);
    panel.add(name, gb);


    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 0;
    label = new JLabel(WeblogicBundle.message("label.create.datasource.jndi.name"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    myJndiName = new JTextField(myDSName);
    label.setLabelFor(myJndiName);
    panel.add(myJndiName, gb);

    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    gb.weightx = 0;
    panel.add(createConnectionSettingsPanel(), gb);

    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 0;
    label = new JLabel(WeblogicBundle.message("label.create.datasource.deployment.order"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    final JTextField deploymentOrder = new JTextField("1000");
    label.setLabelFor(deploymentOrder);
    panel.add(deploymentOrder, gb);

    gb.gridy++;
    gb.gridx = 0;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    myRowPrefetchEnabled = new JCheckBox(WeblogicBundle.message("checkbox.create.datasource.row.prefetch.enabled"), false);
    panel.add(myRowPrefetchEnabled, gb);

    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 0;
    label = new JLabel(WeblogicBundle.message("label.create.datasource.row.prefetch.size"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    myRowPrefetchSize = new JTextField("48");
    label.setLabelFor(myRowPrefetchSize);
    panel.add(myRowPrefetchSize, gb);

    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 0;
    label = new JLabel(WeblogicBundle.message("label.create.datasource.stream.chunk.size"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    myStreamChunkSize = new JTextField("256");
    label.setLabelFor(myStreamChunkSize);
    panel.add(myStreamChunkSize, gb);

    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 0;
    label = new JLabel(WeblogicBundle.message("label.create.datasource.notes"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    myNotes = new JTextField();
    label.setLabelFor(myNotes);
    panel.add(myNotes, gb);

    JPanel dataSourceTypeHolder = createDataSourceTypeHolder();
    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    gb.weightx = 1;
    panel.add(dataSourceTypeHolder, gb);

    return panel;
  }

  protected abstract JPanel createConnectionSettingsPanel();

  protected abstract JPanel createDataSourceTypeHolder();

  protected void enableElements(Component[] components, boolean enable) {
    for (Component component : components) {
      component.setEnabled(enable);
      if (component instanceof Container) {
        enableElements(((Container)component).getComponents(), enable);
      }
    }
  }

  public JComponent getPreferredFocusedComponent() {
    return myJndiName;
  }

  protected WeblogicInstance getWeblogicInstance() {
    return myWeblogicInstance;
  }

  public static int parseInt(String s) throws Exception {
    try {
      return Integer.parseInt(s);
    }
    catch (NumberFormatException e) {
      throw new Exception(WeblogicBundle.message("error.create.datasource.integer.expected", s));
    }
  }

  protected WeblogicDataSourceInfo getDataSourceInfo() throws Exception {
    final WeblogicDataSourceInfo info = new WeblogicDataSourceInfo();
    info.dsName = myDSName;
    info.jndiName = myJndiName.getText();
    info.rowPrefetchEnabled = myRowPrefetchEnabled.isSelected();
    info.rowPrefetchSize = parseInt(myRowPrefetchSize.getText());
    info.streamChunkSize = parseInt(myStreamChunkSize.getText());
    info.notes = myNotes.getText();
    return info;
  }

  public static Properties parseProperties(String source) {
    final StringTokenizer tokenizer = new StringTokenizer(source, ";");
    final Properties properties = new Properties();
    while (tokenizer.hasMoreTokens()) {
      final String s = tokenizer.nextToken().trim();
      String key;
      String value;
      final int i = s.indexOf("=");
      if (i == -1) {
        key = s;
        value = "";
      }
      else {
        key = s.substring(0,i);
        value = s.substring(i+1);
      }
      properties.put(key,value);
    }
    return properties;
  }
}
