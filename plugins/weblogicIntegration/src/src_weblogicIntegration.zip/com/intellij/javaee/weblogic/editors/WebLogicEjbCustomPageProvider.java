package com.intellij.javaee.weblogic.editors;

import com.intellij.javaee.appServerIntegrations.EjbCustomPageProvider;
import com.intellij.javaee.ejb.EjbModuleUtil;
import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.javaee.model.xml.ejb.EjbRelation;
import com.intellij.javaee.ui.DialogCommittableTab;
import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegration;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsJar;
import com.intellij.javaee.weblogic.module.WeblogicEjbFacetUtil;
import org.jetbrains.annotations.Nullable;

/**
 * @author nik
 */
public class WebLogicEjbCustomPageProvider extends EjbCustomPageProvider {
  @Nullable
  public DialogCommittableTab getRelationPage(final EjbRelation ejbRelation) {
    EjbFacet ejbFacet = EjbModuleUtil.getEjbFacet(ejbRelation);
    if (ejbFacet == null) return null;
    final WeblogicRdbmsJar weblogicRdbmsJar = WeblogicEjbFacetUtil.getRdbmsRoot(ejbFacet);
    if (weblogicRdbmsJar == null) return null;

    return new EjbRelationshipCommittablePanel(WeblogicIntegration.getInstance().getPresentableName(), weblogicRdbmsJar, ejbRelation);
  }
}
