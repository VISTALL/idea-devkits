/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

/**
 * http://www.bea.com/ns/weblogic/90:message-driven-descriptorType interface.
 */
public interface MessageDrivenDescriptor extends JavaeeDomModelElement {

	/**
	 * Returns the value of the pool child.
	 * @return the value of the pool child.
	 */
	Pool getPool();


	/**
	 * Returns the value of the timer-descriptor child.
	 * @return the value of the timer-descriptor child.
	 */
	TimerDescriptor getTimerDescriptor();


	/**
	 * Returns the value of the init-suspend-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the init-suspend-seconds child.
	 */
	GenericDomValue<Integer> getInitSuspendSeconds();


	/**
	 * Returns the value of the max-suspend-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the max-suspend-seconds child.
	 */
	GenericDomValue<Integer> getMaxSuspendSeconds();


	/**
	 * Returns the value of the security-plugin child.
	 * @return the value of the security-plugin child.
	 */
	SecurityPlugin getSecurityPlugin();


	/**
	 * Returns the value of the resource-adapter-jndi-name child.
	 * @return the value of the resource-adapter-jndi-name child.
	 */
	GenericDomValue<String> getResourceAdapterJndiName();


	/**
	 * Returns the value of the jms-polling-interval-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the jms-polling-interval-seconds child.
	 */
	GenericDomValue<Integer> getJmsPollingIntervalSeconds();


	/**
	 * Returns the value of the jms-client-id child.
	 * @return the value of the jms-client-id child.
	 */
	GenericDomValue<String> getJmsClientId();


	/**
	 * Returns the value of the generate-unique-jms-client-id child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the generate-unique-jms-client-id child.
	 */
	GenericDomValue<Boolean> getGenerateUniqueJmsClientId();


	/**
	 * Returns the value of the durable-subscription-deletion child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the durable-subscription-deletion child.
	 */
	GenericDomValue<Boolean> getDurableSubscriptionDeletion();


	/**
	 * Returns the value of the max-messages-in-transaction child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the max-messages-in-transaction child.
	 */
	GenericDomValue<Integer> getMaxMessagesInTransaction();


	/**
	 * Returns the value of the destination-jndi-name child.
	 * @return the value of the destination-jndi-name child.
	 */
	GenericDomValue<String> getDestinationJndiName();


	/**
	 * Returns the value of the initial-context-factory child.
	 * @return the value of the initial-context-factory child.
	 */
	GenericDomValue<String> getInitialContextFactory();


	/**
	 * Returns the value of the provider-url child.
	 * @return the value of the provider-url child.
	 */
	GenericDomValue<String> getProviderUrl();


	/**
	 * Returns the value of the connection-factory-jndi-name child.
	 * @return the value of the connection-factory-jndi-name child.
	 */
	GenericDomValue<String> getConnectionFactoryJndiName();


	/**
	 * Returns the value of the destination-resource-link child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the value of the destination-resource-link child.
	 */
	GenericDomValue<String> getDestinationResourceLink();


	/**
	 * Returns the value of the connection-factory-resource-link child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the value of the connection-factory-resource-link child.
	 */
	GenericDomValue<String> getConnectionFactoryResourceLink();


}
