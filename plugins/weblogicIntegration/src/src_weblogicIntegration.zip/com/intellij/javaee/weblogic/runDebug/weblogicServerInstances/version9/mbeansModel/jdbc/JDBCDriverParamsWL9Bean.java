/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.jdbc;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

/**
 * @author nik
 */
public class JDBCDriverParamsWL9Bean extends AbstractWL9MBean {
  public JDBCDriverParamsWL9Bean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public void setUrl(String url) {
    setAttribute("Url", url);
  }

  public void setDriverClass(String classname) {
    setAttribute("DriverName", classname);
  }

  public JDBCPropertiesWL9Bean getProperties() {
    return new JDBCPropertiesWL9Bean(getConnection(), getChild("Properties"));
  }
}
