/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.Description;
import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.javaee.weblogic.model.persistence.MessageDestinationDescriptor;
import com.intellij.javaee.weblogic.model.persistence.RunAsRoleAssignment;
import com.intellij.javaee.weblogic.model.persistence.SecurityPermission;
import com.intellij.javaee.weblogic.model.persistence.SecurityRoleAssignment;
import com.intellij.javaee.weblogic.model.persistence.WorkManager;
import com.intellij.util.xml.GenericDomValue;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:weblogic-ejb-jarType interface.
 */
public interface WeblogicEjbJar extends JavaeeDomModelElement {

	/**
	 * Returns the value of the description child.
	 * @return the value of the description child.
	 */
	Description getDescription();


	/**
	 * Returns the list of weblogic-enterprise-bean children.
	 * @return the list of weblogic-enterprise-bean children.
	 */
	List<WeblogicEnterpriseBean> getWeblogicEnterpriseBeans();
	/**
	 * Adds new child to the list of weblogic-enterprise-bean children.
	 * @return created child
	 */
	WeblogicEnterpriseBean addWeblogicEnterpriseBean();


	/**
	 * Returns the list of security-role-assignment children.
	 * @return the list of security-role-assignment children.
	 */
	List<SecurityRoleAssignment> getSecurityRoleAssignments();
	/**
	 * Adds new child to the list of security-role-assignment children.
	 * @return created child
	 */
	SecurityRoleAssignment addSecurityRoleAssignment();


	/**
	 * Returns the list of run-as-role-assignment children.
	 * @return the list of run-as-role-assignment children.
	 */
	List<RunAsRoleAssignment> getRunAsRoleAssignments();
	/**
	 * Adds new child to the list of run-as-role-assignment children.
	 * @return created child
	 */
	RunAsRoleAssignment addRunAsRoleAssignment();


	/**
	 * Returns the value of the security-permission child.
	 * @return the value of the security-permission child.
	 */
	SecurityPermission getSecurityPermission();


	/**
	 * Returns the list of transaction-isolation children.
	 * @return the list of transaction-isolation children.
	 */
	List<TransactionIsolation> getTransactionIsolations();
	/**
	 * Adds new child to the list of transaction-isolation children.
	 * @return created child
	 */
	TransactionIsolation addTransactionIsolation();


	/**
	 * Returns the list of message-destination-descriptor children.
	 * @return the list of message-destination-descriptor children.
	 */
	List<MessageDestinationDescriptor> getMessageDestinationDescriptors();
	/**
	 * Adds new child to the list of message-destination-descriptor children.
	 * @return created child
	 */
	MessageDestinationDescriptor addMessageDestinationDescriptor();


	/**
	 * Returns the value of the idempotent-methods child.
	 * @return the value of the idempotent-methods child.
	 */
	IdempotentMethods getIdempotentMethods();


	/**
	 * Returns the list of retry-methods-on-rollback children.
	 * @return the list of retry-methods-on-rollback children.
	 */
	List<RetryMethodsOnRollback> getRetryMethodsOnRollbacks();
	/**
	 * Adds new child to the list of retry-methods-on-rollback children.
	 * @return created child
	 */
	RetryMethodsOnRollback addRetryMethodsOnRollback();


	/**
	 * Returns the value of the enable-bean-class-redeploy child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the enable-bean-class-redeploy child.
	 */
	GenericDomValue<Boolean> getEnableBeanClassRedeploy();


	/**
	 * Returns the list of disable-warning children.
	 * @return the list of disable-warning children.
	 */
	List<GenericDomValue<String>> getDisableWarnings();
	/**
	 * Adds new child to the list of disable-warning children.
	 * @return created child
	 */
	GenericDomValue<String> addDisableWarning();


	/**
	 * Returns the list of work-manager children.
	 * @return the list of work-manager children.
	 */
	List<WorkManager> getWorkManagers();
	/**
	 * Adds new child to the list of work-manager children.
	 * @return created child
	 */
	WorkManager addWorkManager();


	/**
	 * Returns the value of the weblogic-compatibility child.
	 * @return the value of the weblogic-compatibility child.
	 */
	WeblogicCompatibility getWeblogicCompatibility();


}
