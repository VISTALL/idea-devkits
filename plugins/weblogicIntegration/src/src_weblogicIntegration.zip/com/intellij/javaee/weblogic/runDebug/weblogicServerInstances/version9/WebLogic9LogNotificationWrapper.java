/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9;

import com.intellij.j2ee.wrappers.WebLogicLogNotification;
import com.intellij.openapi.diagnostic.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.NonNls;

import javax.management.Notification;

/**
 * @author nik
 */
public class WebLogic9LogNotificationWrapper extends WebLogic9NotificationWrapper implements WebLogicLogNotification {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.WebLogic9LogNotificationWrapper");
  @NonNls private static final String WL_LOG_NOTIFICATION_CLASS_NAME = "weblogic.management.logging.WebLogicLogNotification";
  @NonNls private static final String GET_SERVERNAME_METHOD_NAME = "getServername";
  @NonNls private static final String GET_SEVERITY_METHOD_NAME = "getSeverity";
  @NonNls private static final String GET_THROWABLE_METHOD_NAME = "getThrowable";
  private String myServerName;
  private int mySeverity;
  private Throwable myThrowable;

  public WebLogic9LogNotificationWrapper(final @NotNull Notification notification, ClassLoader loader) {
    super(notification);
    try {
      final Class<?> wlNotificationClass = Class.forName(WL_LOG_NOTIFICATION_CLASS_NAME, true, loader);
      LOG.assertTrue(wlNotificationClass.isInstance(notification));
      myServerName = (String)wlNotificationClass.getMethod(GET_SERVERNAME_METHOD_NAME).invoke(notification);
      mySeverity = (Integer)wlNotificationClass.getMethod(GET_SEVERITY_METHOD_NAME).invoke(notification);
      myThrowable = (Throwable)wlNotificationClass.getMethod(GET_THROWABLE_METHOD_NAME).invoke(notification);
    }
    catch (Exception e) {
      LOG.error(e);
    }
  }

  public WebLogic9LogNotificationWrapper(final @NotNull Notification notification,
                                         final String serverName,
                                         final int severity,
                                         final Throwable throwable) {
    super(notification);
    myServerName = serverName;
    mySeverity = severity;
    myThrowable = throwable;
  }

  public String getServername() {
    return myServerName;
  }

  public long getTimeStamp() {
    return myNotification.getTimeStamp();
  }

  public int getSeverity() {
    return mySeverity;
  }

  public Throwable getThrowable() {
    return myThrowable;
  }
}
