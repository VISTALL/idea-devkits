// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:idempotent-methodsType interface.
 */
public interface IdempotentMethods extends JavaeeDomModelElement {

	/**
	 * Returns the list of method children.
	 * @return the list of method children.
	 */
	List<Method> getMethods();
	/**
	 * Adds new child to the list of method children.
	 * @return created child
	 */
	Method addMethod();


}
