// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:table-mapType interface.
 */
public interface TableMap extends JavaeeDomModelElement {

	/**
	 * Returns the value of the table-name child.
	 * @return the value of the table-name child.
	 */
	@NotNull
	GenericDomValue<String> getTableName();


	/**
	 * Returns the list of field-map children.
	 * @return the list of field-map children.
	 */
	List<FieldMap> getFieldMaps();
	/**
	 * Adds new child to the list of field-map children.
	 * @return created child
	 */
	FieldMap addFieldMap();


	/**
	 * Returns the value of the verify-rows child.
	 * @return the value of the verify-rows child.
	 */
	GenericDomValue<String> getVerifyRows();


	/**
	 * Returns the value of the verify-columns child.
	 * @return the value of the verify-columns child.
	 */
	GenericDomValue<String> getVerifyColumns();


	/**
	 * Returns the value of the optimistic-column child.
	 * @return the value of the optimistic-column child.
	 */
	GenericDomValue<String> getOptimisticColumn();


	/**
	 * Returns the value of the trigger-updates-optimistic-column child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the trigger-updates-optimistic-column child.
	 */
	GenericDomValue<Boolean> getTriggerUpdatesOptimisticColumn();


	/**
	 * Returns the value of the version-column-initial-value child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the version-column-initial-value child.
	 */
	GenericDomValue<Integer> getVersionColumnInitialValue();


}
