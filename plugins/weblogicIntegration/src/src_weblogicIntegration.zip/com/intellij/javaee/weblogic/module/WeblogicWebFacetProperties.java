/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.weblogic.module;

import com.intellij.facet.ProjectWideFacetAdapter;
import com.intellij.facet.ProjectWideFacetListenersRegistry;
import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.javaee.facet.JavaeeFacetUtil;
import com.intellij.openapi.application.Result;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.startup.StartupManager;
import com.intellij.psi.PsiDocumentManager;
import com.intellij.psi.xml.XmlDocument;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import com.intellij.util.descriptors.ConfigFile;
import com.intellij.xml.XmlElementDescriptor;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;
import java.util.Collection;

/**
 * @author nik
 */
public class WeblogicWebFacetProperties implements ProjectComponent {
  @NonNls private static final String CONTEXT_ROOT_TAG_NAME = "context-root";
  private Project myProject;
  private final Set<WebFacet> myFacetsWithAddedContextTag = new HashSet<WebFacet>();
  private ProjectWideFacetAdapter<WebFacet> myWebFacetListener;

  public WeblogicWebFacetProperties(final Project project) {
    myProject = project;
  }

  public void initComponent() {
    StartupManager.getInstance(myProject).registerPostStartupActivity(new Runnable() {
      public void run() {
        final Collection<WebFacet> webFacets = JavaeeFacetUtil.getInstance().getJavaeeFacets(WebFacet.ID, myProject);
        for (WebFacet webFacet : webFacets) {
          checkDescriptor(webFacet);
        }
        myWebFacetListener = new ProjectWideFacetAdapter<WebFacet>() {
          public void facetConfigurationChanged(final WebFacet facet) {
            onFacetChanged(facet);
          }

          public void facetRemoved(final WebFacet facet) {
            myFacetsWithAddedContextTag.remove(facet);
          }
        };
        ProjectWideFacetListenersRegistry.getInstance(myProject).registerListener(WebFacet.ID, myWebFacetListener);
      }
    });
  }

  private void onFacetChanged(final WebFacet facet) {
    // we cannt change PSI from an event... so do it later :(
    ApplicationManager.getApplication().invokeLater(new Runnable() {
      public void run() {
        if (!facet.getModule().isDisposed()) {
          checkDescriptor(facet);
        }
      }
    });
  }

  private synchronized void checkDescriptor(WebFacet webFacet) {
    final ConfigFile descriptor = getMainDescriptor(webFacet);
    final XmlFile xmlFile = descriptor == null ? null : descriptor.getXmlFile();
    if (xmlFile == null) {
      myFacetsWithAddedContextTag.remove(webFacet);
      return;
    }
    if (!myFacetsWithAddedContextTag.contains(webFacet)) {
      if (xmlFile.getProject().isDisposed()) return;
      addContextRootTag(webFacet, xmlFile);
    }
  }

  private void addContextRootTag(final WebFacet webFacet, final XmlFile xmlFile) {
    final Project project = xmlFile.getProject();
    final PsiDocumentManager psiDocumentManager = PsiDocumentManager.getInstance(project);
    final Document document1 = psiDocumentManager.getDocument(xmlFile);
    if (document1 != null) {
      psiDocumentManager.commitAllDocuments();
    }
    new WriteCommandAction(project, xmlFile) {
      protected void run(final Result result) throws Throwable {
        final XmlDocument document = xmlFile.getDocument();
        if (document == null) return;

        final XmlTag rootTag = document.getRootTag();
        if (rootTag == null) return;

        final XmlElementDescriptor descriptor = rootTag.getDescriptor();
        if (descriptor == null) return;
        final XmlElementDescriptor[] elementsDescriptors = descriptor.getElementsDescriptors(rootTag);
        boolean found = false;
        for (XmlElementDescriptor d: elementsDescriptors) {
          final String name = d.getName();
          if (name != null && name.equals(CONTEXT_ROOT_TAG_NAME)) {
            found = true;
            break;
          }
        }
        if (!found) {
          return;
        }

        final XmlTag[] tags = rootTag.findSubTags(CONTEXT_ROOT_TAG_NAME, rootTag.getNamespace());
        if (tags.length > 0) {
          myFacetsWithAddedContextTag.add(webFacet);
          return;
        }

        final String facetName = webFacet.getModule().getName() + webFacet.getName();
        rootTag.add(rootTag.createChildTag(CONTEXT_ROOT_TAG_NAME, rootTag.getNamespace(), facetName, false));
        myFacetsWithAddedContextTag.add(webFacet);
      }
    }.execute();
  }

  @Nullable
  public static ConfigFile getMainDescriptor(@NotNull WebFacet webFacet) {
    return webFacet.getDescriptorsContainer().getConfigFile(WLDeploymentDecriptorsConstants.WEBLOGIC_XML_META_DATA);
  }

  public void disposeComponent() {
    if (myWebFacetListener != null) {
      ProjectWideFacetListenersRegistry.getInstance(myProject).unregisterListener(WebFacet.ID, myWebFacetListener);
    }
  }

  public void projectOpened() {
  }

  public void projectClosed() {
  }

  @NonNls
  @NotNull
  public String getComponentName() {
    return "WeblogicWebFacetProperties";
  }
}
