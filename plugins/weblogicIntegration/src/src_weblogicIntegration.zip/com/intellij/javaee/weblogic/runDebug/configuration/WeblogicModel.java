/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.configuration;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.configurations.LogFileOptions;
import com.intellij.execution.configurations.PredefinedLogFile;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.execution.configurations.RuntimeConfigurationWarning;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.javaee.appServerIntegrations.ApplicationServer;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentProvider;
import com.intellij.javaee.facet.JavaeeFacetUtil;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.run.configuration.PredefinedLogFilesProvider;
import com.intellij.javaee.run.configuration.ServerModel;
import com.intellij.javaee.run.execution.OutputProcessor;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegration;
import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegrationImpl;
import com.intellij.javaee.weblogic.applicationServer.WeblogicPersistentData;
import com.intellij.javaee.weblogic.beaInstallation.*;
import com.intellij.javaee.weblogic.module.WeblogicWebFacetProperties;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicInstance;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.Weblogic9LocalInstance;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.Weblogic9RemoteInstance;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.versionsBefore9.WeblogicVersionBefore9LocalInstance;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.versionsBefore9.WeblogicVersionBefore9RemoteInstance;
import com.intellij.openapi.deployment.DeploymentUtil;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.util.DefaultJDOMExternalizer;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.psi.xml.XmlFile;
import com.intellij.util.descriptors.ConfigFile;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class WeblogicModel implements ServerModel, PredefinedLogFilesProvider {
  @NonNls private static final String DOMAIN_LOG_ID = "WEBLOGIC_DOMAIN_LOG_FILE";
  @NonNls private static final String SERVER_LOG_ID = "WEBLOGIC_SERVER_LOG_FILE";
  public String DOMAIN_PATH = "";

  @NonNls public String USER = "weblogic";
  @NonNls public String PASSWORD = "";
  @NonNls public String SERVER_NAME = "myserver";
  @NonNls public String DOMAIN_NAME = "mydomain";

  private CommonModel myCommonModel;

  public void setCommonModel(CommonModel commonModel) {
    myCommonModel = commonModel;
  }

  public WeblogicModel() {

  }

  public int getDefaultPort() {
    return WeblogicIntegration.DEFAULT_PORT;
  }

  public OutputProcessor createOutputProcessor(ProcessHandler j2EEOSProcessHandlerWrapper, J2EEServerInstance serverInstance) {
    return new WeblogicOutputProcessorImpl(j2EEOSProcessHandlerWrapper, (WeblogicInstance)serverInstance);
  }

  public J2EEServerInstance createServerInstance() throws ExecutionException {
    boolean version9 = isVersion9OrLater();
    if (version9) {
      if (myCommonModel.isLocal()) {
        return new Weblogic9LocalInstance(myCommonModel);
      }
      else {
        return new Weblogic9RemoteInstance(myCommonModel);
      }
    }
    else {
      if (myCommonModel.isLocal()) {
        return new WeblogicVersionBefore9LocalInstance(myCommonModel);
      }
      else {
        return new WeblogicVersionBefore9RemoteInstance(myCommonModel);
      }
    }
  }

  public boolean isVersion9OrLater() {
    final WeblogicPersistentData persistentData = getPersistentData();
    return persistentData != null && persistentData.isVersion9xOrLater();
  }

  public boolean isVersion8() {
    final WeblogicPersistentData persistentData = getPersistentData();
    return persistentData != null && persistentData.isVersion8x();
  }

  public void readExternal(Element element) throws InvalidDataException {
    DefaultJDOMExternalizer.readExternal(this, element);
  }

  public void writeExternal(Element element) throws WriteExternalException {
    DefaultJDOMExternalizer.writeExternal(this, element);
  }


  public void testConnection() throws Exception {
    if (myCommonModel.isLocal()) {
      throw new RuntimeException(WeblogicBundle.message("exception.text.cannot.test.local.instance"));
    }

    if (isVersion9OrLater()) {
      final Weblogic9RemoteInstance remoteInstance = new Weblogic9RemoteInstance(myCommonModel);
      try {
        remoteInstance.testConnection();
      }
      finally {
        remoteInstance.dispose();
      }
    }
    else {
      WeblogicVersionBefore9RemoteInstance weblogicVersionBefore9RemoteInstance = new WeblogicVersionBefore9RemoteInstance(myCommonModel);
      try {
        weblogicVersionBefore9RemoteInstance.testConnection();
      }
      finally {
        weblogicVersionBefore9RemoteInstance.dispose();
      }
    }

  }

  public String getBeaHome() {
    final WeblogicPersistentData persistentData = getPersistentData();
    if (persistentData == null) {
      return "";
    }
    return persistentData.BEA_HOME.replace('/', File.separatorChar);
  }

  private @Nullable WeblogicPersistentData getPersistentData() {
    final ApplicationServer applicationServer = myCommonModel.getApplicationServer();
    if (applicationServer == null) {
      return null;
    }
    return (WeblogicPersistentData)applicationServer.getPersistentData();
  }

  public SettingsEditor<CommonModel> getEditor() {
    if (myCommonModel.isLocal()) {
      return new WeblogicLocalRunConfigurationEditor();
    }
    else {
      return new WeblogicRemoteEditor();
    }
  }

  public int getLocalPort() {
    final BeaDomain domain = createDomain();
    BeaServer server = findOrGetFirstServer(domain);
    return server.getPort();
  }

  public @NotNull BeaServer findOrGetFirstServer(final @NotNull BeaDomain domain) {
    BeaServer server = findServer(domain);
    if (server == null) {
      server = domain.getServers()[0];
    }
    return server;
  }

  public BeaDomain createDomain() {
    return WeblogicUtil.createDomain(new File(DOMAIN_PATH));
  }

  public DeploymentProvider getDeploymentProvider() {
    return ((WeblogicIntegrationImpl)myCommonModel.getIntegration()).getDeploymentProvider();
  }


  private void checkWebFacets() throws RuntimeConfigurationException {
    for (WebFacet webFacet : JavaeeFacetUtil.getInstance().getJavaeeFacets(WebFacet.ID, myCommonModel.getProject())) {
      checkWebFacet(webFacet);
    }
  }

  private void checkWebFacet(WebFacet webFacet) throws RuntimeConfigurationException {
    DeploymentModel deploymentModel = myCommonModel.getDeploymentModel(webFacet);
    if (deploymentModel != null && deploymentModel.DEPLOY) {
      ConfigFile mainDeploymentDescriptor = WeblogicWebFacetProperties.getMainDescriptor(webFacet);
      if (mainDeploymentDescriptor != null) {
        final String message = DeploymentUtil.getInstance().getConfigFileErrorMessage(mainDeploymentDescriptor);
        if (message != null) {
          throw new RuntimeConfigurationWarning(message);
        }
        XmlFile xmlFile = mainDeploymentDescriptor.getXmlFile();
        DebugParameterChecker checker = new DebugParameterChecker(xmlFile, myCommonModel.getProject());
        if (!checker.checkDebugParameter()) {
          RuntimeConfigurationException exception = new RuntimeConfigurationWarning(getCantDebugMessage(webFacet));
          exception.setQuickFix(checker.getQuickFix());
          throw exception;
        }
      }
    }
  }

  private static String getCantDebugMessage(WebFacet webFacet) {
    return WeblogicBundle.message("message.text.cant.debug.module", webFacet.getName());
  }

  public List<Pair<String, Integer>> getAddressesToCheck() {
    List<Pair<String, Integer>> result = new ArrayList<Pair<String, Integer>>();
    result.add(
      new Pair<String, Integer>(myCommonModel.getHost(), myCommonModel.getPort()));
    return result;
  }

  public String getDefaultUrlForBrowser() {
    return "http://" + myCommonModel.getHost() + ":" + myCommonModel.getPort();
  }

  public void checkConfiguration() throws RuntimeConfigurationException {
    if (!myCommonModel.isLocal()) {
      checkWebFacets();
      return;
    }
    WeblogicPersistentData weblogicPersistentData = getPersistentData();
    if (weblogicPersistentData == null || weblogicPersistentData.isVersion6x()) {
      return;
    }
    checkWebFacets();
    if (createValidDomain() == null) {
      throw new RuntimeConfigurationWarning(WeblogicBundle.message("exception.text.domain.wasnt.correctly.specified"));
    }
  }

  @Nullable
  private BeaDomain createValidDomain() {
    return WeblogicUtil.createValidDomain(new File(DOMAIN_PATH));
  }

  public CommonModel getCommonModel() {
    return myCommonModel;
  }

  public WeblogicModel clone() throws CloneNotSupportedException {
    return (WeblogicModel)super.clone();
  }

  private @Nullable BeaServer findServer(@Nullable BeaDomain beaDomain) {
    if (beaDomain == null) return null;

    for (BeaServer server : beaDomain.getServers()) {
      if (SERVER_NAME.equals(server.getName())) {
        return server;
      }
    }
    return null;
  }

  @NotNull public PredefinedLogFile[] getPredefinedLogFiles() {
    return new PredefinedLogFile[] {
      new PredefinedLogFile(DOMAIN_LOG_ID, true),
      new PredefinedLogFile(SERVER_LOG_ID, true)
    };
  }

  @Nullable
  public LogFileOptions getOptionsForPredefinedLogFile(PredefinedLogFile predefinedLogFile) {
    final BeaDomain domain = createValidDomain();
    final BeaServer server = findServer(domain);
    if (server == null) return null;

    if (DOMAIN_LOG_ID.equals(predefinedLogFile.getId())) {
      final File logFile = domain.getDomainLogFile();
      if (logFile.exists()) {
        return new LogFileOptions(WeblogicBundle.message("log.file.alias.domain.log"), logFile.getAbsolutePath(),
                                  predefinedLogFile.isEnabled(), true, false);
      }
    }
    else if (SERVER_LOG_ID.equals(predefinedLogFile.getId())) {
      final File logFile = server.getLogFile();
      if (logFile.exists()) {
        return new LogFileOptions(WeblogicBundle.message("log.file.alias.server.log", server.getName()), logFile.getAbsolutePath(),
                                  predefinedLogFile.isEnabled(), true, false);
      }
    }
    return null;
  }

  public @Nullable BeaVersion findVersion() {
    BeaInstallation installation = WeblogicUtil.getInstallationByLocation(new File(getBeaHome()));
    if (!installation.isValid()) {
      return null;
    }
    final WeblogicPersistentData persistentData = getPersistentData();
    if (persistentData == null) {
      return null;
    }
    return installation.findVersionByName(persistentData.VERSION);
  }
}
