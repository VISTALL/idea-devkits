// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:weblogic-rdbms-relationType interface.
 */
public interface WeblogicRdbmsRelation extends JavaeeDomModelElement {

  /**
   * Returns the value of the relation-name child.
   * @return the value of the relation-name child.
   */
  @NotNull
  GenericDomValue<String> getRelationName();


  /**
   * Returns the value of the table-name child.
   * @return the value of the table-name child.
   */
  GenericDomValue<String> getTableName();


  @NotNull
  List<WeblogicRelationshipRole> getWeblogicRelationshipRoles();

  @NotNull
  WeblogicRelationshipRole addWeblogicRelationshipRole();


}
