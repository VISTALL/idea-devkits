/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances;

import com.intellij.debugger.DebuggerManager;
import com.intellij.debugger.PositionManager;
import com.intellij.debugger.engine.DebugProcess;
import com.intellij.debugger.engine.DebugProcessAdapter;
import com.intellij.debugger.engine.DefaultJSPPositionManager;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.j2ee.wrappers.MalformedObjectNameExceptionWrapper;
import com.intellij.j2ee.wrappers.WebLogicLogNotification;
import com.intellij.javaee.J2EEModuleUtil;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.deployment.DeploymentManager;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentSource;
import com.intellij.javaee.deployment.DeploymentStatus;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.serverInstances.DefaultServerInstance;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegration;
import com.intellij.javaee.weblogic.runDebug.configuration.WeblogicModel;
import com.intellij.javaee.weblogic.runDebug.deployment.WLDeploymentModel;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NonNls;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

/**
 * @author nik
 */
public abstract class WeblogicAbstractInstance extends DefaultServerInstance implements WeblogicInstance {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicAbstractInstance");
  private static final @NonNls String JSP_PACKAGE = "jsp_servlet";
  private ServerPollThread myServerPollThread;
  protected final Project myProject;
  private String myServerName;
  private List<LogNotificationListener> myLogNotificationListeners = new ArrayList<LogNotificationListener>(2);
  private String myServerState;
  private String myDomainName;
  @NonNls protected static final String WEBLOGIC_SERVER_CLASS = "weblogic.Server";
  @NonNls private static final String INITIAL_CONTEXT_FACTORY_VALUE = "weblogic.jndi.WLInitialContextFactory";

  protected WeblogicAbstractInstance(CommonModel commonModel) {
    super(commonModel);
    myProject = commonModel.getProject();
    myServerName = getWeblogicConfiguration().SERVER_NAME;
    myDomainName = getWeblogicConfiguration().DOMAIN_NAME;
  }

  protected WeblogicModel getWeblogicConfiguration() {
    return (WeblogicModel)getCommonModel().getServerModel();
  }

  protected String getServerName() {
    return myServerName;
  }

  protected void registerServerPollThread() {
    if (getServerPollThread() == null) {
      myServerPollThread = createServerPollThread();
      getServerPollThread().start();
    }
  }

  protected abstract ServerPollThread createServerPollThread();

  protected void unregisterServerPollThread() {
    if (getServerPollThread() != null) {
      getServerPollThread().doNotPollServer();
      myServerPollThread = null;
    }
  }

  public void start(ProcessHandler processHandler) {
    DebuggerManager.getInstance(myProject).addDebugProcessListener(processHandler, new DebugProcessAdapter() {
      public void processAttached(DebugProcess process) {
        if (getServerPollThread() != null) {
          getServerPollThread().noPoll();
        }
        PositionManager positionManager = new DefaultJSPPositionManager(process, DefaultServerInstance.getScopeModulesWithIncluded(getCommonModel())) {
          protected String getRelativePath(String jspPath) {
            if(jspPath.startsWith(JSP_PACKAGE)) {
              jspPath = jspPath.substring(JSP_PACKAGE.length() + 1);
            }
            StringBuffer buffer = new StringBuffer(StringUtil.startsWithChar(jspPath, '_') ? jspPath.substring(1) : jspPath);
            for (int i = 0; i < buffer.length(); i++) {
              int idx = buffer.indexOf("/_", i);
              if (idx == -1) {
                idx = buffer.indexOf("\\_", i);
              }
              if (idx != -1) {
                buffer.replace(idx + 1, idx + 2, "");
                i = idx + 1;
              }
              else {
                break;
              }
            }

            return buffer.toString();
          }

          protected String getGeneratedClassesPackage() {
            return JSP_PACKAGE;
          }
        };
        process.appendPositionManager(positionManager);
      }
    });
  }

  protected static void reportNoDeploymentSource(JavaeeModuleProperties moduleProperties) {
    Messages.showErrorDialog(WeblogicBundle.message("message.text.no.deployment.source.configured",
                                                    moduleProperties.getModule().getModuleType().getName(),
                                                    moduleProperties.getPresentableName()),
                             WeblogicBundle.message("message.title.error.deploying"));
  }

  public void addLogNotificationListener(LogNotificationListener listener) {
    myLogNotificationListeners.add(listener);
  }

  public void removeLogNotificationListener(LogNotificationListener listener) {
    myLogNotificationListeners.remove(listener);
  }

  public void fireLogNotificationListeners(final LogNotificationListener.LogNotification event) {
    for (LogNotificationListener listener : myLogNotificationListeners) {
      listener.handleNotification(event);
    }
  }

  public void registerServerError(final Throwable e) {
    fireLogNotificationListeners(new LogNotificationListener.LogNotification() {
      public WebLogicLogNotification getNotification() {
        return createWebLogicLogNotification(new Date(), null, 0, 0,
                                             WeblogicBundle.message("message.text.error.occurred.during.deployment"),
                                             this, e);
      }
    });
  }

  public String getState() {
    return myServerState;
  }

  public void setState(String state) {
    myServerState = state;
  }

  public void cleanup() {
    myServerState = null;
    myLogNotificationListeners.clear();
  }

  protected String getDomainName() {
    return myDomainName;
  }

  protected void setDomainName(final String domainName) {
    myDomainName = domainName;
  }

  public void setServerName(final String serverName) {
    myServerName = serverName;
  }

  protected @NonNls String getAdminUrl() {
    return "t3://" + getUrl();
  }

  private String getUrl() {
    return getCommonModel().getHost() + ":" + getCommonModel().getPort();
  }

  public static File getDeploymentSource(final DeploymentModel model) {
    Project project = model.getModuleProperties().getModule().getProject();
    return DeploymentManager.getInstance(project).getDeploymentSource(model);
  }

  protected WLDeploymentModel findModuleDeploymentSettings(final String appName) {
    if (myProject == null) return null;
    return
      ApplicationManager.getApplication().runReadAction(new Computable<WLDeploymentModel>() {
        public WLDeploymentModel compute() {
          final Module[] allJ2EEModules = J2EEModuleUtil.getAllJ2EEModules(myProject);
          for (Module module : allJ2EEModules) {
            final JavaeeModuleProperties moduleProperties = JavaeeModuleProperties.getInstance(module);
            final WLDeploymentModel settings = (WLDeploymentModel)getCommonModel().getDeploymentModel(moduleProperties);
            if (settings == null) continue;
            final String deploymentName = getInternalWeblogicDeploymentName(settings);
            if (appName.equals(deploymentName)) {
              return settings;
            }
          }
          return null;
        }
      });
  }

  @NonNls
  protected static String getInternalWeblogicDeploymentName(DeploymentModel model) {
    if (model == null) return null;
    if (model.getDeploymentMethod() == WeblogicIntegration.DEPLOYER) {
      return model.getModuleProperties().getModule().getName();
    }
    final File source = getDeploymentSource(model);
    if (source == null) return null;
    if (model.getDeploymentSource() == DeploymentSource.FROM_JAR) {
      return "_appsdir_" + source.getName().replace('.', '_');
    }
    if (model.getDeploymentSource() == DeploymentSource.FROM_EXPLODED) {
      return "_appsdir_" + source.getName().replace('.', '_') + "_dir";
    }
    return null;
  }

  public void updateDeploymentStatus(final DeploymentModel model) {
    if (isConnected()) {
      final Runnable runnable = new Runnable() {
        public String toString() {
          return WeblogicBundle.message("process.descriptions.update.deployment.status");
        }

        public boolean equals(Object obj) {
          return obj instanceof Runnable && Comparing.strEqual(toString(), obj.toString());
        }

        public int hashCode() {
          return 0;
        }

        public void run() {
          try {
            DeploymentManager.getInstance(myProject).setDeploymentStatus(model.getModuleProperties(),
                                                                         getDeploymentStatus(model), getCommonModel(),
                                                                         WeblogicAbstractInstance.this);
          }
          catch (Exception e) {
            registerServerError(e);
          }
        }
      };
      getServerPollThread().queueRequest(runnable);
    }
    else {
      DeploymentManager.getInstance(myProject).setDeploymentStatus(model.getModuleProperties(), DeploymentStatus.DISCONNECTED,
                                                                   getCommonModel(), this);
    }
  }

  protected abstract DeploymentStatus getDeploymentStatus(DeploymentModel model) throws MalformedObjectNameExceptionWrapper;

  public ServerPollThread getServerPollThread() {
    return myServerPollThread;
  }

  public boolean isStopped() {
    return !isStarting() && !isConnected();
  }

  public void disconnect() {
    if (getServerPollThread() != null) {
      getServerPollThread().queueRequestAndWait(new Runnable() {
        public String toString() {
          return WeblogicBundle.message("process.description.disconnect");
        }

        public void run() {
          instanceStopped();
          cleanup();
        }
      });
    }
    fireServerListeners(new WeblogicServerEvent(WeblogicServerEvent.SERVER_STATE_DISCONNECTED, getOutputInfo()));
    // set all deployment stati back to UNKNOWN
    if (myProject != null) {
      DeploymentManager.getInstance(myProject).updateAllDeploymentStatus(this, getCommonModel());
    }

  }

  protected void instanceStopped() {
    unregisterServerPollThread();
  }

  protected void refreshState() {
    if (getServerPollThread() != null) {
      getServerPollThread().refreshState();
    }
  }

  protected InitialContext createInitialContext() throws NamingException {
    Hashtable<String, String> env = new Hashtable<String, String>();
    env.put(Context.INITIAL_CONTEXT_FACTORY, INITIAL_CONTEXT_FACTORY_VALUE);
    String adminUrl = getAdminUrl();
    env.put(Context.PROVIDER_URL, adminUrl);
    return new InitialContext(env);
  }
}
