// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.Description;
import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:weblogic-queryType interface.
 */
public interface WeblogicQuery extends JavaeeDomModelElement {

	/**
	 * Returns the value of the description child.
	 * @return the value of the description child.
	 */
	Description getDescription();


	/**
	 * Returns the value of the query-method child.
	 * @return the value of the query-method child.
	 */
	@NotNull
	QueryMethod getQueryMethod();


	/**
	 * Returns the value of the max-elements child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdPositiveIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:positiveInteger.
	 * </pre>
	 * @return the value of the max-elements child.
	 */
	GenericDomValue<Integer> getMaxElements();


	/**
	 * Returns the value of the include-updates child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the include-updates child.
	 */
	GenericDomValue<Boolean> getIncludeUpdates();


	/**
	 * Returns the value of the sql-select-distinct child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the sql-select-distinct child.
	 */
	GenericDomValue<Boolean> getSqlSelectDistinct();


	/**
	 * Returns the value of the enable-query-caching child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the enable-query-caching child.
	 */
	GenericDomValue<Boolean> getEnableQueryCaching();


	/**
	 * Returns the value of the ejb-ql-query child.
	 * @return the value of the ejb-ql-query child.
	 */
	@NotNull
	EjbQlQuery getEjbQlQuery();


	/**
	 * Returns the value of the sql-query child.
	 * @return the value of the sql-query child.
	 */
	@NotNull
	SqlQuery getSqlQuery();


}
