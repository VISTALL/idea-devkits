// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:entity-cache-refType interface.
 */
public interface EntityCacheRef extends JavaeeDomModelElement {

	/**
	 * Returns the value of the entity-cache-name child.
	 * @return the value of the entity-cache-name child.
	 */
	@NotNull
	GenericDomValue<String> getEntityCacheName();


	/**
	 * Returns the value of the idle-timeout-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the idle-timeout-seconds child.
	 */
	GenericDomValue<Integer> getIdleTimeoutSeconds();


	/**
	 * Returns the value of the read-timeout-seconds child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:nonNegativeInteger.
	 * </pre>
	 * @return the value of the read-timeout-seconds child.
	 */
	GenericDomValue<Integer> getReadTimeoutSeconds();


	/**
	 * Returns the value of the concurrency-strategy child.
	 * @return the value of the concurrency-strategy child.
	 */
	@NotNull
	GenericDomValue<String> getConcurrencyStrategy();


	/**
	 * Returns the value of the cache-between-transactions child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the cache-between-transactions child.
	 */
	GenericDomValue<Boolean> getCacheBetweenTransactions();


	/**
	 * Returns the value of the estimated-bean-size child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdPositiveIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:positiveInteger.
	 * </pre>
	 * @return the value of the estimated-bean-size child.
	 */
	GenericDomValue<Integer> getEstimatedBeanSize();


}
