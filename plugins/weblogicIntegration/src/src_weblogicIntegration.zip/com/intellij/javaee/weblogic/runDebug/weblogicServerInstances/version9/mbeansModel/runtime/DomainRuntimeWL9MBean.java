/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime;

import org.jetbrains.annotations.NonNls;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.DeployerRuntimeWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;

/**
 * @author nik
 */
public class DomainRuntimeWL9MBean extends AbstractWL9MBean {
  @NonNls private static final String DEPLOYER_RUNTIME_ATTRIBUTE_NAME = "DeployerRuntime";

  public DomainRuntimeWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public DeployerRuntimeWL9MBean getDeployerRuntime() {
    return new DeployerRuntimeWL9MBean(getConnection(), getChild(DEPLOYER_RUNTIME_ATTRIBUTE_NAME));
  }
}
