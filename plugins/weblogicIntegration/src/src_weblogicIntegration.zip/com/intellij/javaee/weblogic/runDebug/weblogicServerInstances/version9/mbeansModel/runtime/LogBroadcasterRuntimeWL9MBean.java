/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.JMWrappedException;

import javax.management.*;
import java.io.IOException;

/**
 * @author nik
 */
public class LogBroadcasterRuntimeWL9MBean extends AbstractWL9MBean {
  public LogBroadcasterRuntimeWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public void addNotificationListener(final NotificationListener listener) {
    try {
      getConnection().addNotificationListener(getBeanName(), listener, null, null);
    }
    catch (InstanceNotFoundException e) {
      throw new JMWrappedException(e);
    }
    catch (IOException e) {
      throw new JMWrappedException(e);
    }
  }

  public void removeNotificationListener(final NotificationListener listener) {
    try {
      getConnection().removeNotificationListener(getBeanName(), listener);
    }
    catch (JMException e) {
      throw new JMWrappedException(e);
    }
    catch (IOException e) {
      throw new JMWrappedException(e);
    }
  }
}
