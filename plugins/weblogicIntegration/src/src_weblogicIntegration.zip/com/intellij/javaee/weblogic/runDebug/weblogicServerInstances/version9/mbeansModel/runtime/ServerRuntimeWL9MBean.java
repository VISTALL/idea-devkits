/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime;

import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.ApplicationRuntimeWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;

/**
 * @author nik
 */
public class ServerRuntimeWL9MBean extends AbstractWL9MBean {
  @NonNls private static final String APPLICATION_RUNTIMES_ATTRIBUTE_NAME = "ApplicationRuntimes";
  @NonNls private static final String STATE_ATTRIBUTE_NAME = "State";
  @NonNls private static final String LOG_BROADCASTER_RUNTIME_NAME = "LogBroadcasterRuntime";
  @NonNls private static final String NAME_ATTRIBUTE_NAME = "Name";

  public ServerRuntimeWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public ApplicationRuntimeWL9MBean[] getApplicationRuntimes() {
    final ObjectName[] children = getChildren(APPLICATION_RUNTIMES_ATTRIBUTE_NAME);
    final ApplicationRuntimeWL9MBean[] applicationRuntimes = new ApplicationRuntimeWL9MBean[children.length];
    for (int i = 0; i < children.length; i++) {
      applicationRuntimes[i] = new ApplicationRuntimeWL9MBean(getConnection(), children[i]);
    }
    return applicationRuntimes;
  }

  public LogBroadcasterRuntimeWL9MBean getLogBroadcasterRuntime() {
    return new LogBroadcasterRuntimeWL9MBean(getConnection(), getChild(LOG_BROADCASTER_RUNTIME_NAME));
  }

  public String getState() {
    return (String)getAttribute(STATE_ATTRIBUTE_NAME);
  }

  public @Nullable ApplicationRuntimeWL9MBean findApplicationRuntimeByName(@NotNull String name) {
    final ObjectName[] children = getChildren(APPLICATION_RUNTIMES_ATTRIBUTE_NAME);
    for (ObjectName objectName : children) {
      final ApplicationRuntimeWL9MBean applicationRuntime = new ApplicationRuntimeWL9MBean(getConnection(), objectName);
      if (name.equals(applicationRuntime.getName())) {
        return applicationRuntime;
      }
    }
    return null;
  }

  public String getName() {
    return (String)getAttribute(NAME_ATTRIBUTE_NAME);
  }
}
