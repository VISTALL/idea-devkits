// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:application-admin-mode-triggerType interface.
 */
public interface ApplicationAdminModeTrigger extends JavaeeDomModelElement {

	/**
	 * Returns the value of the max-stuck-thread-time child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:integer.
	 * </pre>
	 * @return the value of the max-stuck-thread-time child.
	 */
	GenericDomValue<Integer> getMaxStuckThreadTime();


	/**
	 * Returns the value of the stuck-thread-count child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:integer.
	 * </pre>
	 * @return the value of the stuck-thread-count child.
	 */
	@NotNull
	GenericDomValue<Integer> getStuckThreadCount();


}
