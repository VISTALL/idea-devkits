/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.jdbc;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

/**
 * @author nik
 */
public class JDBCPropertiesWL9Bean extends AbstractWL9MBean {
  private static final MethodSignature CREATE_PROPERTY_SIGNATURE = new MethodSignature("createProperty", String.class);

  public JDBCPropertiesWL9Bean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public JDBCPropertyWL9Bean createProperty(String name) {
    final ObjectName beanName = (ObjectName)invoke(CREATE_PROPERTY_SIGNATURE, name);
    return new JDBCPropertyWL9Bean(getConnection(), beanName);
  }
}
