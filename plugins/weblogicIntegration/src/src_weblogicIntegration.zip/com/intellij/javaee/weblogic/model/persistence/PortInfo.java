// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:port-infoType interface.
 */
public interface PortInfo extends JavaeeDomModelElement {

	/**
	 * Returns the value of the port-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the value of the port-name child.
	 */
	@NotNull
	GenericDomValue<String> getPortName();


	/**
	 * Returns the list of stub-property children.
	 * @return the list of stub-property children.
	 */
	List<PropertyNamevalue> getStubProperties();
	/**
	 * Adds new child to the list of stub-property children.
	 * @return created child
	 */
	PropertyNamevalue addStubProperty();


	/**
	 * Returns the list of call-property children.
	 * @return the list of call-property children.
	 */
	List<PropertyNamevalue> getCallProperties();
	/**
	 * Adds new child to the list of call-property children.
	 * @return created child
	 */
	PropertyNamevalue addCallProperty();


}
