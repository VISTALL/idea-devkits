package com.intellij.javaee.weblogic.appServerIntegration;

import com.intellij.ide.fileTemplates.FileTemplateGroupDescriptorFactory;
import com.intellij.ide.fileTemplates.FileTemplateGroupDescriptor;
import com.intellij.ide.fileTemplates.FileTemplateDescriptor;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.WLFileTemplateNames;
import com.intellij.openapi.fileTypes.StdFileTypes;

/**
 * @author nik
 */
public class WebLogicFileTemplateDescriptorFactory implements FileTemplateGroupDescriptorFactory {
  public FileTemplateGroupDescriptor getFileTemplatesDescriptor() {
    FileTemplateGroupDescriptor root = new FileTemplateGroupDescriptor(WeblogicBundle.message("template.files.group.title.weblogic"), WeblogicIntegrationImpl.ICON);

    FileTemplateGroupDescriptor v6 = new FileTemplateGroupDescriptor(WeblogicBundle.message("template.group.title.version.6.x"), null);
    v6.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_6x, StdFileTypes.XML.getIcon()));
    v6.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_XML_6X, StdFileTypes.XML.getIcon()));
    v6.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_6X, StdFileTypes.XML.getIcon()));
    v6.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_6X, StdFileTypes.XML.getIcon()));
    root.addTemplate(v6);

    FileTemplateGroupDescriptor v7 = new FileTemplateGroupDescriptor(WeblogicBundle.message("template.group.title.version.7.x"), null);
    v7.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_7x, StdFileTypes.XML.getIcon()));
    v7.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_XML_7X, StdFileTypes.XML.getIcon()));
    v7.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_7X, StdFileTypes.XML.getIcon()));
    v7.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_7X, StdFileTypes.XML.getIcon()));
    root.addTemplate(v7);

    FileTemplateGroupDescriptor v8 = new FileTemplateGroupDescriptor(WeblogicBundle.message("template.group.title.version.8.x"), null);
    v8.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_8x, StdFileTypes.XML.getIcon()));
    v8.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_XML_8X, StdFileTypes.XML.getIcon()));
    v8.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_8X, StdFileTypes.XML.getIcon()));
    v8.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_8X, StdFileTypes.XML.getIcon()));
    root.addTemplate(v8);

    FileTemplateGroupDescriptor v9 = new FileTemplateGroupDescriptor(WeblogicBundle.message("template.group.title.version.9.x"), null);
    v9.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_9x, StdFileTypes.XML.getIcon()));
    v9.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_XML_9X, StdFileTypes.XML.getIcon()));
    v9.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_9X, StdFileTypes.XML.getIcon()));
    v9.addTemplate(new FileTemplateDescriptor(WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_9X, StdFileTypes.XML.getIcon()));
    root.addTemplate(v9);

    return root;
  }
}
