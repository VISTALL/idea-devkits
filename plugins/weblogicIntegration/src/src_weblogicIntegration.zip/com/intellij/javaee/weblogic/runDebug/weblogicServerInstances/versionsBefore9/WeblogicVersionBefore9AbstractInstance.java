/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.versionsBefore9;

import com.intellij.execution.ExecutionException;
import com.intellij.javaee.appServerIntegrations.ApplicationServer;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentStatus;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.WeblogicConnectionPoolInfo;
import com.intellij.javaee.weblogic.applicationServer.WeblogicPersistentData;
import com.intellij.javaee.weblogic.dataSource.WeblogicDataSourceInfo;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicAbstractInstance;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.ServerPollThread;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.LogNotificationListener;
import com.intellij.javaee.weblogic.runDebug.deployment.WLDeploymentModel;
import com.intellij.javaee.weblogic.runDebug.deployment.WeblogicDeploymentStatus;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.j2ee.wrappers.*;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.util.Computable;
import com.intellij.facet.pointers.FacetPointer;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.net.MalformedURLException;
import java.util.*;

/**
 * @author Alexey Kudravtsev
 */
public abstract class WeblogicVersionBefore9AbstractInstance extends WeblogicAbstractInstance {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.versionsBefore9.WeblogicVersionBefore9AbstractInstance");
  @NonNls private static final String SERVER_RUNTILE_OBJECT_NAME = "ServerRuntime";
  @NonNls private static final String SERVER_BEAN_NAME = "Server";
  @NonNls private static final String DEPLOYER_RUNTIME_NAME = "DeployerRuntime";
  @NonNls private static final String LOG_BROADCASTER_NAME = "TheLogBroadcaster";
  @NonNls private static final String LOG_BROADCASTER_RUNTIME_NAME = "LogBroadcasterRuntime";
  @NonNls private static final String JDBC_DS_NAME = "JDBCDataSource";
  @NonNls private static final String JDBC_TX_DS_NAME = "JDBCTxDataSource";
  @NonNls private static final String JDBC_CONNECTION_POOL_TYPE = "JDBCConnectionPool";
  @NonNls private static final String WEBLOGIC_LOGIN_CLASS_NAME = "com.intellij.j2ee.wrappers.WeblogicLogin";

  private ServerRuntimeMBean myServerRuntimeMBean;
  private RemoteMBeanServer myRemoteMBeanServer;
  protected MBeanHome myMBeanHome;
  protected DeployerRuntimeMBean myDeployerRuntimeMBean;
  private MyWeblogicLogNotificationListener myLogNotificationListener;
  private Set<ObjectName> myObjectNamesWithDeploymentListener = new HashSet<ObjectName>();
  private Context myInitialContext;
  private MBeanHome myServerMBean;
  protected WeblogicMain myWeblogicMain;
  private JMXDeploymentListener myJMXDeploymentListener;
  private boolean myIsStarting;
  private Map<String, String> myFacetId2ContextRoot = new HashMap<String, String>();

  protected WeblogicVersionBefore9AbstractInstance(CommonModel commonModel) throws ExecutionException {
    super(commonModel);
    try {
      myWeblogicMain = loadWeblogicMain(commonModel, getClass().getClassLoader());
      myWeblogicMain.getClass().getClassLoader().loadClass(WEBLOGIC_SERVER_CLASS);
    }
    catch (MalformedURLException e) {
      throw new ExecutionException(e.getLocalizedMessage());
    }
    catch (ClassNotFoundException e) {
      throw new ExecutionException(WeblogicBundle.message("exception.text.serverdk.not.configured.properly",
                                                          getCommonModel().getApplicationServer().getName(), e.getMessage()));
    }
    catch (InstantiationException e) {
      throw new ExecutionException(e.getLocalizedMessage());
    }
    catch (IllegalAccessException e) {
      throw new ExecutionException(e.getLocalizedMessage());
    }
    initialize();
  }

  protected void initialize() {
    myIsStarting = true;
    registerServerPollThread();
  }

  private MBeanHome getMBeanHome(Context ctx) {
    try {
      if (ctx == null) return null;
      return myWeblogicMain.createMBeanHomeFromContext(ctx);
    }
    catch (NamingException e) {
      return null;
    }
  }

  public RemoteMBeanServer getRemoteMBeanServer() {
    return myRemoteMBeanServer;
  }

  public WebLogicMBean getBean(ObjectName registeredBeanName) throws InstanceNotFoundExceptionWrapper {
    if (myMBeanHome == null) {
      return null;
    }
    else {
      return myMBeanHome.getMBean(registeredBeanName);
    }
  }

  public String getServerName() {
    return super.getServerName();
  }

  public String getDomainName() {
    return super.getDomainName();
  }

  public ServerRuntimeMBean getServerRuntimeBean() {
    return myServerRuntimeMBean;
  }

  public void refreshStateImpl() throws Exception {
    myInitialContext = createInitialContext();

    myMBeanHome = getMBeanHome(myInitialContext);

    if (myMBeanHome == null) return;
    myRemoteMBeanServer = myMBeanHome.getMBeanServer();
    myJMXDeploymentListener = new JMXDeploymentListener();
    final String serverName = myRemoteMBeanServer.getServerName();
    final String domainName = myMBeanHome.getDomainName();

    ObjectName name = getWeblogicLoginInstance().createWeblogicObjectName(serverName,
                                                                          SERVER_RUNTILE_OBJECT_NAME,
                                                                          domainName,
                                                                          serverName);
    myServerRuntimeMBean = (ServerRuntimeMBean)myMBeanHome.getMBean(name);
    if (myServerRuntimeMBean == null) return;
    myServerMBean =
    (MBeanHome)myMBeanHome.getAdminMBean(serverName, SERVER_BEAN_NAME);

    try {
      WebLogicObjectName objectName = getWeblogicLoginInstance().createWeblogicObjectName(DEPLOYER_RUNTIME_NAME,
                                                                                          DEPLOYER_RUNTIME_NAME, domainName,
                                                                                          serverName,
                                                                                          myServerRuntimeMBean.getObjectName());
      myDeployerRuntimeMBean =
      (DeployerRuntimeMBean)myMBeanHome.getMBean(objectName);
    }
    catch (Exception e) {
      WebLogicObjectName objectName = getWeblogicLoginInstance().createWeblogicObjectName(DEPLOYER_RUNTIME_NAME,
                                                                                          DEPLOYER_RUNTIME_NAME,
                                                                                          domainName,
                                                                                          serverName);
      myDeployerRuntimeMBean =
      (DeployerRuntimeMBean)myMBeanHome.getMBean(objectName);
    }

    setState(myServerRuntimeMBean.getState());
    myIsStarting = false;
  }

  protected ServerPollThread createServerPollThread() {
    final ServerPollThreadForWLBefore9 serverPollThread = new ServerPollThreadForWLBefore9(this, myProject, getWeblogicConfiguration());
    serverPollThread.setContextClassLoader(getWeblogicLoginInstance().getClass().getClassLoader());
    return serverPollThread;
  }

  public ServerPollThreadForWLBefore9 getServerPollThread() {
    return (ServerPollThreadForWLBefore9)super.getServerPollThread();
  }

  public boolean isStarting() {
    return myIsStarting;
  }


  void registerLogNotificationListener() {
    if (myLogNotificationListener == null) {
      myLogNotificationListener = new MyWeblogicLogNotificationListener();
    }
    try {
      WebLogicObjectName logBroadcasterName = myWeblogicMain.createWeblogicObjectName(LOG_BROADCASTER_NAME,
                                                                                      LOG_BROADCASTER_RUNTIME_NAME,
                                                                                      myMBeanHome.getDomainName(),
                                                                                      myRemoteMBeanServer.getServerName());
      try {
        //todo crash
        myRemoteMBeanServer.removeNotificationListener(logBroadcasterName, myLogNotificationListener);
      }
      catch (Exception e) {
        // its OK if no listeners bound
      }
      myRemoteMBeanServer.addNotificationListener(logBroadcasterName, myLogNotificationListener);
    }
    catch (Exception e) {
      registerServerError(e);
    }
  }

  private void removeLogNotificationListener() {
    try {
      if (myLogNotificationListener != null && myRemoteMBeanServer != null) {
        WebLogicObjectName logBroadcasterName = myWeblogicMain.createWeblogicObjectName(LOG_BROADCASTER_NAME,
                                                                                        LOG_BROADCASTER_RUNTIME_NAME,
                                                                                        getDomainName(),
                                                                                        getServerName());
        try {
          //todo crash in 8.x
          myRemoteMBeanServer.removeNotificationListener(logBroadcasterName, myLogNotificationListener);
        }
        catch (Exception e) {
          // it is OK
        }
        myLogNotificationListener = null;
      }
    }
    catch (Exception e) {
      registerServerError(e);
    }

  }

  public void createDatasource(final WeblogicDataSourceInfo dataSourceInfo) throws Exception {
    if (dataSourceInfo.isTxDataSource) {
      createTxDataSource(dataSourceInfo);
    }
    else {
      createNonTxDataSource(dataSourceInfo);
    }
  }

  private class MyWeblogicLogNotificationListener implements RemoteNotificationListenerWrapper {
    public void handleNotification(final Notification notification, Object o) {
      final LogNotificationListener.LogNotification weblogicLogNotification = new LogNotificationListener.LogNotification() {
        public WebLogicLogNotification getNotification() {
          return (WebLogicLogNotification)notification;
        }
      };
      fireLogNotificationListeners(weblogicLogNotification);
      // todo check whether we should update deploymenet status at each log event
//      updateAllDeploymentStatus(project);
    }
  }

  protected DeploymentStatus getDeploymentStatus(final DeploymentModel model) throws MalformedObjectNameExceptionWrapper {
    if (!isConnected()) {
      return DeploymentStatus.UNKNOWN;
    }
    else {
      ObjectName objectName = getDeployedObjectName(model, false);

      try {
        final WebLogicMBean mBean = myMBeanHome.getMBean(objectName);
        registerDeploymentListener(objectName);

        if (mBean instanceof ApplicationMBean) {
          final ApplicationMBean applicationMBean = (ApplicationMBean)mBean;
          final ComponentMBean[] components = applicationMBean.getComponents();

          if (components.length == 0) {
            return DeploymentStatus.FAILED;
          }
          else {
            for (ComponentMBean component : components) {
              TargetMBean[] targetMBeans = null;
              try {
                targetMBeans = myDeployerRuntimeMBean.lookupActiveTargetsForComponent(component);
              }
              catch (Exception e) {
                registerServerError(e);
              }
              if (targetMBeans == null || targetMBeans.length == 0) {
                return DeploymentStatus.FAILED;
              }
            }
          }
        }
      }
      catch (InstanceNotFoundExceptionWrapper e) {
        LOG.info(e);
        return DeploymentStatus.NOT_DEPLOYED;
      }
      catch (ManagementRuntimeExceptionWrapper e) {
        LOG.info(e);
        return DeploymentStatus.NOT_DEPLOYED;
      }

      try {
        final ObjectName applicationRuntime = getDeployedObjectName(model, true);
        final WebLogicMBean appRuntimeMBean = myMBeanHome.getMBean(applicationRuntime);
        if (appRuntimeMBean instanceof ApplicationRuntimeMBean) {
          myFacetId2ContextRoot.put(model.getFacetPointer().getId(), ((ApplicationRuntimeMBean)appRuntimeMBean).getContextRoot(myMBeanHome));
        }
      }
      catch (InstanceNotFoundExceptionWrapper e) {
        LOG.debug(e);
      }
    }
    return DeploymentStatus.DEPLOYED;
  }

  private ObjectName getDeployedObjectName(final DeploymentModel model, final boolean getRuntime) throws MalformedObjectNameExceptionWrapper {
    String internalName = ApplicationManager.getApplication().runReadAction(new Computable<String>() {
      public String compute() {
        return getInternalWeblogicDeploymentName(model);
      }
    });
    LOG.assertTrue(getDomainName() != null);
    @NonNls final String objectName;
    if (getRuntime) {
      objectName = getDomainName() + ":Location=" + getServerName() + ",Name=" + getServerName() + "_" + internalName
                   + ",ServerRuntime=" + getServerName() + ",Type=ApplicationRuntime";
    }
    else {
      objectName = getDomainName() + ":Name=" + internalName + ",Type=Application";
    }
    return myWeblogicMain.createObjectName(objectName);
  }

  void registerDeploymentListener(final ObjectName objectName) {
    if (!myObjectNamesWithDeploymentListener.add(objectName)) return;

    try {
      myRemoteMBeanServer.addNotificationListener(objectName, myJMXDeploymentListener);
    }
    catch (InstanceNotFoundExceptionWrapper e) {
    }
  }

  public boolean isConnected() {
    return myMBeanHome != null;
  }

  public boolean isRun() {
    return myServerRuntimeMBean != null;
  }

  public void cleanup() {
    super.cleanup();
    myMBeanHome = null;
    myServerRuntimeMBean = null;
    myRemoteMBeanServer = null;
    myIsStarting = false;
  }


  /**
   * will be called then user stopped or closed weblogic instance console
   */
  protected void instanceStopped() {
    removeLogNotificationListener();
    super.instanceStopped();
  }

  public DataSource getDataSource(final String dataSourceName) {
    final DataSource[] dataSource = new DataSource[]{null};

    Runnable runnable = new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.getting.datasource", dataSourceName);
      }

      public void run() {
        if (!isConnected() || myInitialContext == null) return;
        try {
          final Object ds = myInitialContext.lookup(dataSourceName);
          dataSource[0] = ds instanceof DataSource ? (DataSource)ds : null;
        }
        catch (NamingException e) {
        }
      }
    };
    getServerPollThread().queueRequestAndWait(runnable);
    return dataSource[0];
  }

  public String[] getConfiguredDataSourceNames() {
    final List<String> ds = new ArrayList<String>();
    Runnable runnable = new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.discover.server.datasources");
      }

      public void run() {
        Set dsMBeanSet = myMBeanHome.getMBeansByType(JDBC_DS_NAME, getDomainName());
        dsMBeanSet.addAll(myMBeanHome.getMBeansByType(JDBC_TX_DS_NAME, getDomainName()));
        Iterator iter = dsMBeanSet.iterator();
        while (iter.hasNext()) {
          WebLogicMBean dataSource = (WebLogicMBean)iter.next();
          ds.add(dataSource.getName());
        }
      }
    };
    getServerPollThread().queueRequestAndWait(runnable);

    return ds.toArray(new String[ds.size()]);
  }

  public String[] getConfiguredConnectionPoolNames() {
    final List<String> result = new ArrayList<String>();
    Runnable runnable = new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.retrieving.pool.names");
      }

      public void run() {
        Set poolBeans = myMBeanHome.getMBeansByType(JDBC_CONNECTION_POOL_TYPE,
                                                    getDomainName());
        Iterator iter = poolBeans.iterator();
        while (iter.hasNext()) {
          WebLogicMBean pool = (WebLogicMBean)iter.next();
          result.add(pool.getName());
        }
      }
    };
    getServerPollThread().queueRequestAndWait(runnable);
    return result.toArray(new String[result.size()]);
  }

  private void createNonTxDataSource(final WeblogicDataSourceInfo info) throws Exception {
    final Exception[] exception = new Exception[1];
    getServerPollThread().queueRequestAndWait(new Runnable() {
      public void run() {
        try {
          // Create DataSource  MBean
          JDBCDataSourceMBean dsMBean = (JDBCDataSourceMBean)myMBeanHome.createAdminMBean(info.dsName, JDBC_DS_NAME, getDomainName());

          // Set DataSource attributes
          dsMBean.setJNDIName(info.jndiName);
          dsMBean.setPoolName(info.connectionPoolName);
          dsMBean.setConnectionWaitPeriod(info.connectionWaitPeriod);
          dsMBean.setRowPrefetchEnabled(info.rowPrefetchEnabled);
          dsMBean.setRowPrefetchSize(info.rowPrefetchSize);
          dsMBean.setStreamChunkSize(info.streamChunkSize);
          dsMBean.setWaitForConnectionEnabled(info.waitForConnectionEnabled);
          dsMBean.setNotes(info.notes);

          // Startup datasource
          dsMBean.addTarget(myServerMBean);
        }
        catch (Exception e) {
          try {
            final WebLogicMBean mBean = myMBeanHome.getMBean(info.dsName, JDBC_DS_NAME);
            myMBeanHome.deleteMBean(mBean.getObjectName());
          }
          catch (Exception e1) {
            // it is OK
          }
          exception[0] = e;
        }
      }
    });
    if (exception[0] != null) {
      throw exception[0];
    }
  }

  private void createTxDataSource(final WeblogicDataSourceInfo info) throws Exception {
    final Exception[] exception = new Exception[1];
    getServerPollThread().queueRequestAndWait(new Runnable() {
      public void run() {
        try {
          // Create DataSource  MBean
          JDBCTxDataSourceMBean dsMBean = (JDBCTxDataSourceMBean)myMBeanHome.createAdminMBean(info.dsName, JDBC_TX_DS_NAME,
                                                                                              getDomainName());

          // Set DataSource attributes
          dsMBean.setJNDIName(info.jndiName);
          dsMBean.setPoolName(info.connectionPoolName);
          dsMBean.setRowPrefetchEnabled(info.rowPrefetchEnabled);
          dsMBean.setRowPrefetchSize(info.rowPrefetchSize);
          dsMBean.setStreamChunkSize(info.streamChunkSize);
          dsMBean.setNotes(info.notes);
          dsMBean.setEnableTwoPhaseCommit(info.enableTwoPhaseCommit);

          // Startup datasource
          dsMBean.addTarget(myServerMBean);
        }
        catch (Exception e) {
          try {
            final WebLogicMBean mBean = myMBeanHome.getMBean(info.dsName, JDBC_TX_DS_NAME);
            myMBeanHome.deleteMBean(mBean.getObjectName());
          }
          catch (Exception e1) {
            // it is OK
          }
          exception[0] = e;
        }
      }
    });
    if (exception[0] != null) {
      throw exception[0];
    }
  }

  public void createConnectionPool(final WeblogicConnectionPoolInfo info) throws Exception {
    final Exception[] exception = new Exception[1];
    getServerPollThread().queueRequestAndWait(new Runnable() {
      public void run() {
        try {
          // Create DataSource  MBean
          JDBCConnectionPoolMBean dsMBean = (JDBCConnectionPoolMBean)myMBeanHome.createAdminMBean(info.name, JDBC_CONNECTION_POOL_TYPE,
                                                                                                  getDomainName());

          // Set DataSource attributes
          dsMBean.setCapacityIncrement(info.capacityIncrement);
          dsMBean.setDriverName(info.driverClassname);
          dsMBean.setInitialCapacity(info.initialCapacity);
          dsMBean.setMaxCapacity(info.maxCapacity);
          dsMBean.setProperties(info.properties);
          dsMBean.setURL(info.url);

          // Startup datasource
          dsMBean.addTarget(myServerMBean);
        }
        catch (Exception e) {
          try {
            final WebLogicMBean mBean = myMBeanHome.getMBean(info.name, JDBC_CONNECTION_POOL_TYPE);
            myMBeanHome.deleteMBean(mBean.getObjectName());
          }
          catch (Exception e1) {
            // it is OK
          }
          exception[0] = e;
        }
      }
    });
    if (exception[0] != null) {
      throw exception[0];
    }
  }

  public WeblogicMain getWeblogicLoginInstance() {
    return myWeblogicMain;
  }

  public WeblogicOutputInfo getOutputInfo() {
    return myWeblogicMain.getOutputInfo();
  }

  public WLDeploymentModel findModuleDeploymentSettings(final String appName) {
    return super.findModuleDeploymentSettings(appName);
  }

  public WebLogicLogNotification createWebLogicLogNotification(final Date date,
                                                               @Nullable @NonNls String type,
                                                               final long sequenceNumber,
                                                               final int severity,
                                                               final String message,
                                                               final Object source,
                                                               final Throwable throwable) {
    @NonNls final String machineName = "machine";
    final String serverName = getServerName() == null ? "" : getServerName();
    @NonNls final String threadId = "thread";
    @NonNls final String userId = "user";
    @NonNls final String tranId = "tran";
    if (type == null) {
      type = "Type";
    }
    return myWeblogicMain.createWeblogicLogNotificationWrapper(date, machineName, serverName, threadId, userId, tranId, type, sequenceNumber, severity, message, source, throwable);
  }

  @Nullable
  public String getContextRoot(FacetPointer<JavaeeFacet> facetPointer) {
    return myFacetId2ContextRoot.get(facetPointer.getId());
  }

  private static WeblogicMain loadWeblogicMain(CommonModel commonModel, ClassLoader parent) throws MalformedURLException,
                                                                                                   ClassNotFoundException,
                                                                                                   InstantiationException,
                                                                                                   IllegalAccessException {

    final ApplicationServer server = commonModel.getApplicationServer();
    ClassLoader classLoader = ((WeblogicPersistentData)server.getPersistentData()).getClassLoader(commonModel, parent);
    Class weblogicLoginClass = classLoader.loadClass(WEBLOGIC_LOGIN_CLASS_NAME);
    return (WeblogicMain)weblogicLoginClass.newInstance();

  }

  protected class JMXDeploymentListener implements RemoteNotificationListenerWrapper {
    public void handleNotification(final Notification notification, final Object handback) {
      if (notification instanceof DeploymentNotification) {
        LOG.debug("** JMX Notification: "
                  + "; " + notification.getMessage()
                  + "; " + notification.getSource()
                  + "; " + notification.getType()
                  + "; " + notification.getUserData()
//            + "; " + appName
        );
        final DeploymentNotification deploymentNotification = (DeploymentNotification)notification;
        final String appName = deploymentNotification.getAppName();
        final WLDeploymentModel settings = findModuleDeploymentSettings(appName);
        LOG.debug("appName = " + appName + "; item =" + settings);
        if (settings == null) return;
        //final String weblogicStatus = deploymentNotification.getType();
        final String weblogicStatus = deploymentNotification.getTargetState();
        DeploymentStatus status = new WeblogicDeploymentStatus(getOutputInfo()).decodeWeblogicStatus(weblogicStatus);
        if (status == null) {
          updateDeploymentStatus(settings);
        }
      }
      else {
        LOG.debug("** Other Notification: " + notification.getMessage());
      }
    }
  }
}
