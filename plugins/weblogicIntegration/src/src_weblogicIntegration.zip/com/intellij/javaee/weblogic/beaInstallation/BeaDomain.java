/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.beaInstallation;

import org.jetbrains.annotations.Nullable;

import java.io.File;

public class BeaDomain {
  public static final BeaDomain[] EMPTY_ARRAY = new BeaDomain[0];
  private final String myName;
  private final @Nullable String myVersion;
  private final File myLocation;
  private final File myDomainLogFile;
  private final File myServerStartupScript;
  private final File myApplicationsDir;
  private BeaServer[] myServers;

  public BeaDomain(final String name, @Nullable String version, final File location,
                   final File domainLogFile, final File serverStartupScript, final File applicationsDir,
                   BeaServer[] servers) {
    myName = name;
    myVersion = version;
    myLocation = location;
    myDomainLogFile = domainLogFile;
    myServerStartupScript = serverStartupScript;
    myApplicationsDir = applicationsDir;
    myServers = servers;
  }

  public String getName() {
    return myName;
  }

  public BeaServer[] getServers() {
    return myServers;
  }

  public File getLocation() {
    return myLocation;
  }

  public File getDomainLogFile() {
    return myDomainLogFile;
  }

  public File getServerStartupScript() {
    return myServerStartupScript;
  }

  public File getApplicationsDir() {
    return myApplicationsDir;
  }

  public @Nullable String getVersion() {
    return myVersion;
  }
}