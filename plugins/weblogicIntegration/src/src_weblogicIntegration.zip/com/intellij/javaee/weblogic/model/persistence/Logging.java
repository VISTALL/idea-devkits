// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

/**
 * http://www.bea.com/ns/weblogic/90:loggingType interface.
 */
public interface Logging extends JavaeeDomModelElement {

	/**
	 * Returns the value of the log-filename child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the value of the log-filename child.
	 */
	GenericDomValue<String> getLogFilename();


	/**
	 * Returns the value of the logging-enabled child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the logging-enabled child.
	 */
	GenericDomValue<Boolean> getLoggingEnabled();


	/**
	 * Returns the value of the rotation-type child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the value of the rotation-type child.
	 */
	GenericDomValue<String> getRotationType();


	/**
	 * Returns the value of the number-of-files-limited child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the number-of-files-limited child.
	 */
	GenericDomValue<Boolean> getNumberOfFilesLimited();


	/**
	 * Returns the value of the file-count child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdPositiveIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:positiveInteger.
	 * </pre>
	 * @return the value of the file-count child.
	 */
	GenericDomValue<Integer> getFileCount();


	/**
	 * Returns the value of the file-size-limit child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdPositiveIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:positiveInteger.
	 * </pre>
	 * @return the value of the file-size-limit child.
	 */
	GenericDomValue<Integer> getFileSizeLimit();


	/**
	 * Returns the value of the rotate-log-on-startup child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the rotate-log-on-startup child.
	 */
	GenericDomValue<Boolean> getRotateLogOnStartup();


	/**
	 * Returns the value of the log-file-rotation-dir child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the value of the log-file-rotation-dir child.
	 */
	GenericDomValue<String> getLogFileRotationDir();


	/**
	 * Returns the value of the rotation-time child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the value of the rotation-time child.
	 */
	GenericDomValue<String> getRotationTime();


	/**
	 * Returns the value of the file-time-span child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdPositiveIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:positiveInteger.
	 * </pre>
	 * @return the value of the file-time-span child.
	 */
	GenericDomValue<Integer> getFileTimeSpan();


}
