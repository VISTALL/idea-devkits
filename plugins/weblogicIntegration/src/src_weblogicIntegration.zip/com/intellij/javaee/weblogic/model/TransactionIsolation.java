// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:transaction-isolationType interface.
 */
public interface TransactionIsolation extends JavaeeDomModelElement {

	/**
	 * Returns the value of the isolation-level child.
	 * @return the value of the isolation-level child.
	 */
	@NotNull
	GenericDomValue<String> getIsolationLevel();


	/**
	 * Returns the list of method children.
	 * @return the list of method children.
	 */
	@NotNull
	List<Method> getMethods();
	/**
	 * Adds new child to the list of method children.
	 * @return created child
	 */
	Method addMethod();


}
