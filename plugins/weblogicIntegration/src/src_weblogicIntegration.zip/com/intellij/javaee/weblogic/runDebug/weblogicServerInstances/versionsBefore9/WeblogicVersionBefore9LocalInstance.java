/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.versionsBefore9;

import com.intellij.execution.ExecutionException;
import com.intellij.j2ee.wrappers.DeploymentData;
import com.intellij.j2ee.wrappers.DeploymentTaskRuntimeMBean;
import com.intellij.j2ee.wrappers.ManagementExceptionWrapper;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegration;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.AutoDeployUtil;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicAbstractInstance;

import java.io.File;
import java.io.IOException;

/**
 * @author Alexey Kudravtsev
 */
public class WeblogicVersionBefore9LocalInstance extends WeblogicVersionBefore9AbstractInstance {
  public WeblogicVersionBefore9LocalInstance(CommonModel commonModel)
    throws ExecutionException {
    super(commonModel);
  }


  public void shutdown() {
    disconnect();
  }

  public void startDeploy(final DeploymentModel model) {
    if (!isConnected()) return;
    JavaeeFacet facet = model.getFacet();
    File source = getDeploymentSource(model);
    if (source == null) {
      reportNoDeploymentSource(facet);
      return;
    }
    if (model.getDeploymentMethod() == WeblogicIntegration.AUTODEPLOY) {
      autodeploy(source);
      return;
    }

    final String name = getDeploymentName(facet);

    // Build the DeploymentData object
    final DeploymentData info = myWeblogicMain.createDeploymentData();
    info.addTarget(getServerName());


    getServerPollThread().queueRequest(createDeployAction(source, name, info, model));
  }

  private Runnable createDeployAction(final File source,
                                      final String name,
                                      final DeploymentData info,
                                      final DeploymentModel model) {
    return new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.local.deploy");
      }

      public void run() {
        try {
          // Create the deployment task. Last arg indicates to just create the task, but not initiate it
          DeploymentTaskRuntimeMBean task = myDeployerRuntimeMBean.activate(source.getPath(), name, info, false);

          task.start();
        }
        catch (final ManagementExceptionWrapper e) {
          registerServerError(e);
        }
        finally {
          updateDeploymentStatus(model);
        }
      }
    };
  }

  public void startUndeploy(DeploymentModel model) {
    JavaeeFacet facet = model.getFacet();
    final String name = getDeploymentName(facet);
    if (!isConnected()) return;

    File source = getDeploymentSource(model);
    if (source == null) {
      reportNoDeploymentSource(facet);
      return;
    }
    if (model.getDeploymentMethod() == WeblogicIntegration.AUTODEPLOY) {
      AutoDeployUtil.autoUndeploy(getCommonModel(), source);
      return;
    }

    final Runnable runnable = new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.local.undeploy");
      }

      public void run() {
        try {
          // Build the DeploymentData object
          DeploymentData info = getWeblogicLoginInstance().createDeploymentData();
          info.addTarget(getServerName());
          // Create the deployment task. Last arg indicates to just create the task, but not initiate it
          DeploymentTaskRuntimeMBean task = myDeployerRuntimeMBean.remove(name, info, false);

          task.start();
        }
        catch (ManagementExceptionWrapper e) {
          registerServerError(e);
        }
      }
    };
    getServerPollThread().queueRequest(runnable);
  }

  public boolean connect() {
    final boolean[] connected = new boolean[]{false};
    getServerPollThread().queueRequestAndWait(new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.local.connect");
      }

      public void run() {
        refreshState();
        connected[0] = getState() != null;
      }
    });
    return connected[0];
  }

  private void autodeploy(final File sourceFile) {
    try {
      AutoDeployUtil.autoDeploy(getCommonModel(), sourceFile);
    }
    catch (final IOException e) {
      registerServerError(e);
    }
  }

}
