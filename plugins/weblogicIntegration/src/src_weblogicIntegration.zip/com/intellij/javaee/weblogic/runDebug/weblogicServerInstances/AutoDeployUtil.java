/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances;

import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.runDebug.configuration.WeblogicModel;
import com.intellij.openapi.util.io.FileUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;

/**
 * @author nik
 */
public class AutoDeployUtil {
  @NonNls private static final String META_INF_DIR = "META-INF";
  @NonNls private static final String REDEPLOY_DIR = "REDEPLOY";

  private AutoDeployUtil() {
  }

  public static void autoUndeploy(final CommonModel commonModel, final File sourceFile) {
    final File applicationsDir = getApplicationsDir(commonModel);
    final File targetFile = new File(applicationsDir, sourceFile.getName());
    FileUtil.delete(targetFile);
  }

  private static File getApplicationsDir(final CommonModel commonModel) {
    return ((WeblogicModel)commonModel.getServerModel()).createDomain().getApplicationsDir();
  }

  public static void autoDeploy(final @NotNull CommonModel commonModel, final File sourceFile) throws IOException {
    final File applicationsDir = getApplicationsDir(commonModel);
    final File targetFile = new File(applicationsDir, sourceFile.getName());

    if (sourceFile.isFile()) {
      FileUtil.copy(sourceFile, targetFile);
    }
    else if (sourceFile.isDirectory()) {
      FileUtil.copyDir(sourceFile, targetFile);
      final File touchDir = new File(targetFile, META_INF_DIR);
      final File touchFile = new File(touchDir, REDEPLOY_DIR);
      FileUtil.createParentDirs(touchFile);
      if (!touchFile.createNewFile()) {
        touchFile.setLastModified(System.currentTimeMillis());
      }
    }
    else {
      throw new IOException(WeblogicBundle.message("exception.text.invalid.file", sourceFile));
    }
  }
}
