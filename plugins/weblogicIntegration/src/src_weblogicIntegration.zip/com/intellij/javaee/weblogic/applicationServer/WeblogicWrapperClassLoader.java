/*
 * Copyright (c) 2000-2004 by JetBrains s.r.o. All Rights Reserved.
 * Use is subject to license terms.
 */
package com.intellij.javaee.weblogic.applicationServer;

import org.jetbrains.annotations.NonNls;

import java.net.URL;
import java.net.URLClassLoader;
import java.security.PermissionCollection;
import java.security.CodeSource;
import java.security.AllPermission;
import java.security.Permissions;

/**
 * @author nik
 */
public class WeblogicWrapperClassLoader extends URLClassLoader {
  @NonNls private static final String JAVAX_MANAGEMENT_PREFIX = "javax.management.";
  @NonNls private static final String JAVAX_MAIL_PREFIX = "javax.mail.";
  private Permissions myPermissions = new Permissions();
  private boolean myVersion9x;

  {
    myPermissions.add(new AllPermission());
  }

  public WeblogicWrapperClassLoader(URL[] urls, final boolean version9x, ClassLoader parent) {
    super(urls, parent);
    myVersion9x = version9x;
  }

  protected Class loadClass(String name, boolean resolve) throws ClassNotFoundException {
    if (canDelegate(name)) {
      return super.loadClass(name, resolve);
    }

    Class<?> c = findLoadedClass(name);
    if (c == null) {
      try {
        //try to load class first from URLClassLoader's classpath in order to load JDK classes
        // (such as javax.management.ObjectName) from weblogic's jars instead of IDEA's JDK
        // (see http://www.jetbrains.net/jira/browse/IDEA-1651)
        c = findClass(name);
        return c;
      }
      catch (ClassNotFoundException e) {
        return super.loadClass(name, resolve);
      }
    }
    if (resolve) {
      resolveClass(c);
    }
    return c;
  }

  private boolean canDelegate(final String name) {
    if (name == null) {
      return true;
    }
    return !name.startsWith(JAVAX_MANAGEMENT_PREFIX) && (!myVersion9x || !name.startsWith(JAVAX_MAIL_PREFIX));
  }

  protected PermissionCollection getPermissions(CodeSource codesource) {
    return myPermissions;
  }
}