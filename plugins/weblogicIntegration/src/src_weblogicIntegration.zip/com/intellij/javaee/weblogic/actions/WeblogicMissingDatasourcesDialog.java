/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.actions;

import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.actions.version9.Weblogic9CreateDatasourceDialog;
import com.intellij.javaee.weblogic.actions.versionsBefore9.WeblogicBefore9CreateDatasourceDialog;
import com.intellij.javaee.weblogic.beaInstallation.WeblogicUtil;
import com.intellij.javaee.weblogic.module.WeblogicEjbFacetUtil;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicInstance;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.Weblogic9AbstractInstance;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.versionsBefore9.WeblogicVersionBefore9AbstractInstance;
import com.intellij.javaee.model.common.ejb.EnterpriseBean;
import com.intellij.javaee.model.common.ejb.EntityBean;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsBean;
import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.util.JavaeeIcons;

import javax.sql.DataSource;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class WeblogicMissingDatasourcesDialog extends DialogWrapper {
  private final List<EnterpriseBean> myMissingDatasourceEjbs;
  private final WeblogicInstance myWeblogicInstance;
  private final List<EjbFacet> myEjbFacetsAffected;
  private JButton myConfigureButton;
  private JList myMissingDSList;
  private JList myConfiguredDSList;
  private DefaultListModel myMissingDSDataModel;
  private DefaultListModel myConfiguredDSDataModel;
  private Project myProject;
  private JPanel myPanel;

  public WeblogicMissingDatasourcesDialog(Project project, List<EnterpriseBean> missingDatasourceEjbs, WeblogicInstance instance, List<EjbFacet> ejbFacets) {
    super(project, false);
    myProject = project;
    myMissingDatasourceEjbs = missingDatasourceEjbs;
    myWeblogicInstance = instance;
    myEjbFacetsAffected = ejbFacets;
    init();
    setOKButtonText(WeblogicBundle.message("button.continue"));
    setTitle(WeblogicBundle.message("dialog.title.configure.missing.datasources"));
  }


  protected JComponent createCenterPanel() {
    return myPanel;
  }

  protected void init() {
    myMissingDSDataModel = new DefaultListModel();
    Set<String> dataSourceNames = new HashSet<String>();
    for (int i = 0; i < myMissingDatasourceEjbs.size(); i++) {
      EntityBean entityBean = (EntityBean) myMissingDatasourceEjbs.get(i);
      EjbFacet ejbFacet = myEjbFacetsAffected.get(i);
      final WeblogicRdbmsBean rdbmsBean = WeblogicUtil.findRdbmsBean(WeblogicEjbFacetUtil.getRdbmsRoot(ejbFacet), entityBean.getEjbName().getValue());
      if (rdbmsBean != null) {
        dataSourceNames.add(rdbmsBean.getRightDataSourceName().getValue());
      }
    }
    for (String dataSourceName : dataSourceNames) {
      myMissingDSDataModel.addElement(dataSourceName);
    }
    final DefaultListCellRenderer iconizedCellRenderer = new IconizedListCellRenderer();
    myMissingDSList.setCellRenderer(iconizedCellRenderer);
    myMissingDSList.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        missingDataSourceSelectionChanged();
      }
    });
    myMissingDSList.setModel(myMissingDSDataModel);

    myConfigureButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        final int selectedIndex = myMissingDSList.getSelectedIndex();
        if (selectedIndex == -1) return;
        String dsName = (String) myMissingDSList.getSelectedValue();
        createDataSource(dsName);
      }
    });

    myConfiguredDSDataModel = new DefaultListModel();
    refreshConfiguredDatasourceList();
    myConfiguredDSList.setCellRenderer(iconizedCellRenderer);
    myConfiguredDSList.setModel(myConfiguredDSDataModel);

    myMissingDSList.setSelectedIndex(0);

    super.init();
  }

  private void refreshConfiguredDatasourceList() {
    myConfiguredDSDataModel.clear();
    final String[] dataSourceNames = myWeblogicInstance.getConfiguredDataSourceNames();
    for (String dataSourceName : dataSourceNames) {
      myConfiguredDSDataModel.addElement(dataSourceName);
    }
  }

  private void missingDataSourceSelectionChanged() {
    final int selectedIndex = myMissingDSList.getSelectedIndex();
    myConfigureButton.setEnabled(selectedIndex != -1);
  }

  private void createDataSource(String dsName) {
    WeblogicCreateDatasourceDialog dialog;
    if (myWeblogicInstance instanceof WeblogicVersionBefore9AbstractInstance) {
      dialog = new WeblogicBefore9CreateDatasourceDialog(myProject, (WeblogicVersionBefore9AbstractInstance)myWeblogicInstance, dsName);
    }
    else {
      dialog = new Weblogic9CreateDatasourceDialog(myProject, (Weblogic9AbstractInstance)myWeblogicInstance, dsName);
    }
    dialog.show();
    if (!dialog.isOK()) {
      return;
    }
    myMissingDSDataModel.removeElement(dsName);
    refreshConfiguredDatasourceList();
    missingDataSourceSelectionChanged();
  }

  protected String getDimensionServiceKey() {
    return "#com.intellij.javaee.weblogic.actions.WeblogicMissingDatasourcesDialog";
  }

  private class IconizedListCellRenderer extends DefaultListCellRenderer {
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
      super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
      String dsName = (String) value;
      final DataSource dataSource = myWeblogicInstance.getDataSource(dsName);
      if (dataSource != null) {
        setIcon(JavaeeIcons.DATASOURCE_ICON);
        setToolTipText(WeblogicBundle.message("tooltip.missing.datasource.data.source.is.alive", dsName));
      }
      else {
        setIcon(JavaeeIcons.DATASOURCE_DISABLED_ICON);
        setToolTipText(WeblogicBundle.message("tooltip.missing.datasource.data.source.is.dead", dsName));
      }
      return this;
    }
  }

}
