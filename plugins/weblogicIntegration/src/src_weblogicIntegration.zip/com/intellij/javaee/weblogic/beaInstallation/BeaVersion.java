/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.beaInstallation;

import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.File;

public class BeaVersion {
  public static final BeaVersion[] EMPTY_ARRAY = new BeaVersion[0];
  private final String myName;
  private final String myInstallDir;
  private final String myJavaHome;
  @NonNls private static final String SERVER_DIR = "server";
  @NonNls private static final String LIB_DIR = "lib";
  @NonNls private static final String WEBLOGIC_JAR = "weblogic.jar";
  @NonNls private static final String JXM_CLIENT_JAR_NAME = "wljmxclient.jar";
  @NonNls private static final String XBEAN_JAR_NAME = "xbean.jar";

  public BeaVersion(String name, String installDir, @Nullable String javaHome) {
    myName = name;
    myInstallDir = installDir;
    myJavaHome = javaHome;
  }

  public String getName() {
    return myName;
  }

  public String toString() {
    return getName();
  }

  public String getInstallDir() {
    return myInstallDir;
  }

  public File getJarFile() {
    File libDir = getLibDir();
    return new File(libDir, WEBLOGIC_JAR);
  }

  public File getLibDir() {
    File serverDir = new File(myInstallDir, SERVER_DIR);
    return new File(serverDir, LIB_DIR);
  }

  public File getJMXClientJarFile() {
    return new File(getLibDir(), JXM_CLIENT_JAR_NAME);
  }

  @Nullable
  public String getJavaHome() {
    return myJavaHome;
  }

  public File getXBeanJarFile() {
    return new File(getLibDir(), XBEAN_JAR_NAME);
  }
}