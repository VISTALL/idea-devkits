package com.intellij.javaee.weblogic.appServerIntegration;

import com.intellij.javaee.facet.DescriptorMetaDataProvider;
import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.javaee.weblogic.module.WLDeploymentDecriptorsConstants;
import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.javaee.application.facet.JavaeeApplicationFacet;
import org.jetbrains.annotations.NotNull;

/**
 * @author nik
 */
public class WebLogicDescriptorMetaDataProvider extends DescriptorMetaDataProvider {
  public void registerDescriptors(@NotNull final MetaDataRegistry registry) {
    WeblogicIntegration integration = WeblogicIntegration.getInstance();
    registry.register(EjbFacet.ID, integration, WLDeploymentDecriptorsConstants.WL_EJB_JAR_XML_META_DATA);
    registry.register(EjbFacet.ID, integration, WLDeploymentDecriptorsConstants.WL_CMP_RDMS_XML_META_DATA);
    registry.register(WebFacet.ID, integration, WLDeploymentDecriptorsConstants.WEBLOGIC_XML_META_DATA);
    registry.register(JavaeeApplicationFacet.ID, integration, WLDeploymentDecriptorsConstants.WL_APPLICATION_XML_META_DATA);
  }
}
