/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

/**
 * @author nik
 */
public class ConfigurationManagerWL9MBean extends AbstractWL9MBean {
  private static final MethodSignature START_EDIT_SIGNATURE = new MethodSignature("startEdit", Integer.class, Integer.class);
  private static final MethodSignature STOP_EDIT_SIGNATURE = new MethodSignature("stopEdit", new String[0]);
  private static final MethodSignature SAVE_SIGNATURE = new MethodSignature("save", new String[0]);
  private static final MethodSignature ACTIVATE_SIGNATURE = new MethodSignature("activate", Long.class);

  public ConfigurationManagerWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public DomainWL9MBean startEdit(int waitTime, int timeout) {
    final ObjectName objectName = (ObjectName)invoke(START_EDIT_SIGNATURE, waitTime, timeout);
    return new DomainWL9MBean(getConnection(), objectName);
  }

  public void save() {
    invoke(SAVE_SIGNATURE);
  }

  public void activate(long timeout) {
    invoke(ACTIVATE_SIGNATURE, timeout);
  }

  public void stopEdit() {
    invoke(STOP_EDIT_SIGNATURE);
  }
}
