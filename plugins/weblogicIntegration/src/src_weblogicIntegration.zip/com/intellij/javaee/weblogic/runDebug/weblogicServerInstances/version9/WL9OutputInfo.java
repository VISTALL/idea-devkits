/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9;

import com.intellij.j2ee.wrappers.WeblogicOutputInfo;
import org.jetbrains.annotations.NonNls;

import java.util.Map;
import java.util.HashMap;

/**
 * @author nik
 */
public class WL9OutputInfo implements WeblogicOutputInfo {
  @NonNls private static final String RUNNING_SERVER_STATE = "RUNNING";
  @NonNls private static final String SHUTTING_DOWN_SERVER_STATE = "SHUTTING_DOWN";
  @NonNls private static final String SHUTDOWN_SERVER_STATE = "SHUTDOWN";

  @NonNls private static final String EMERGENCY_SEVERITY_TEXT = "Emergency";
  @NonNls private static final String ALERT_SEVERITY_TEXT = "Alert";
  @NonNls private static final String CRITICAL_SEVERITY_TEXT = "Critical";
  @NonNls private static final String ERROR_SEVERITY_TEXT = "Error";
  @NonNls private static final String WARNING_SEVERITY_TEXT = "Warning";
  @NonNls private static final String NOTICE_SEVERITY_TEXT = "Notice";
  @NonNls private static final String INFO_SEVERITY_TEXT = "Info";
  @NonNls private static final String DEBUG_SEVERITY_TEXT = "Debug";
  @NonNls private static final String TRACE_SEVERITY_TEXT = "Trace";

  private static final Map<Integer, String> SEVERITY_INT2TEXT = new HashMap<Integer, String>();
  private static final Map<String, Integer> SEVERITY_TEXT2INT = new HashMap<String, Integer>();
  static {
    registerSeverity(1, EMERGENCY_SEVERITY_TEXT);
    registerSeverity(2, ALERT_SEVERITY_TEXT);
    registerSeverity(4, CRITICAL_SEVERITY_TEXT);
    registerSeverity(8, ERROR_SEVERITY_TEXT);
    registerSeverity(16, WARNING_SEVERITY_TEXT);
    registerSeverity(32, NOTICE_SEVERITY_TEXT);
    registerSeverity(64, INFO_SEVERITY_TEXT);
    registerSeverity(128, DEBUG_SEVERITY_TEXT);
    registerSeverity(256, TRACE_SEVERITY_TEXT);
  }

  private static void registerSeverity(final int severity, final String text) {
    SEVERITY_INT2TEXT.put(severity, text);
    SEVERITY_TEXT2INT.put(text, severity);
  }

  public String getRunning() {
    return RUNNING_SERVER_STATE;
  }

  public String getShuttingDown() {
    return SHUTTING_DOWN_SERVER_STATE;
  }

  public String getShutdown() {
    return SHUTDOWN_SERVER_STATE;
  }


  public String getEmergencyText() {
    return EMERGENCY_SEVERITY_TEXT;
  }

  public String getAlertText() {
    return ALERT_SEVERITY_TEXT;
  }

  public String getCriticalText() {
    return CRITICAL_SEVERITY_TEXT;
  }

  public String getErrorText() {
    return ERROR_SEVERITY_TEXT;
  }

  public String getWarningText() {
    return WARNING_SEVERITY_TEXT;
  }

  public String getNoticeText() {
    return NOTICE_SEVERITY_TEXT;
  }

  public String getInfoText() {
    return INFO_SEVERITY_TEXT;
  }

  public String getDebugText() {
    return DEBUG_SEVERITY_TEXT;
  }


  public int severityStringToNum(String severityStr) {
    return SEVERITY_TEXT2INT.get(severityStr);
  }

  public String severityNumToString(int severity) {
    return SEVERITY_INT2TEXT.get(severity);
  }

  public String getRegistrationNotification() {
    throw new UnsupportedOperationException("'getRegistrationNotification' not implemented in " + getClass().getName());
  }

  public String getUnregistrationNotification() {
    throw new UnsupportedOperationException("'getUnregistrationNotification' not implemented in " + getClass().getName());
  }

  public String getActivated() {
    throw new UnsupportedOperationException("'getActivated' not implemented in " + getClass().getName());
  }

  public String getActivating() {
    throw new UnsupportedOperationException("'getActivating' not implemented in " + getClass().getName());
  }

  public String getPrepared() {
    throw new UnsupportedOperationException("'getPrepared' not implemented in " + getClass().getName());
  }

  public String getPreparing() {
    throw new UnsupportedOperationException("'getPreparing' not implemented in " + getClass().getName());
  }

  public String getDeactivated() {
    throw new UnsupportedOperationException("'getDeactivated' not implemented in " + getClass().getName());
  }

  public String getDeactivating() {
    throw new UnsupportedOperationException("'getDeactivating' not implemented in " + getClass().getName());
  }

  public String getUnprepared() {
    throw new UnsupportedOperationException("'getUnprepared' not implemented in " + getClass().getName());
  }

  public String getUnpreparing() {
    throw new UnsupportedOperationException("'getUnpreparing' not implemented in " + getClass().getName());
  }

  public String getFailed() {
    throw new UnsupportedOperationException("'getFailed' not implemented in " + getClass().getName());
  }
}
