/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel;

import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import javax.management.*;
import java.io.IOException;

/**
 * @author nik
 */
public abstract class AbstractWL9MBean {
  private @NotNull ObjectName myBeanName;
  private MBeanServerConnection myConnection;

  protected AbstractWL9MBean(final MBeanServerConnection connection, final @NotNull ObjectName beanName) {
    myConnection = connection;
    myBeanName = beanName;
  }

  protected ObjectName getChild(@NonNls String name) {
    return (ObjectName)getAttribute(name);
  }

  protected ObjectName[] getChildren(@NonNls String name) {
    return (ObjectName[])getAttribute(name);
  }

  public boolean equals(final Object o) {
    if (this == o) return true;
    if (!(o instanceof AbstractWL9MBean)) return false;
    final AbstractWL9MBean that = (AbstractWL9MBean)o;
    return myBeanName.equals(that.myBeanName);

  }

  public int hashCode() {
    return myBeanName.hashCode();
  }

  protected Object getAttribute(@NonNls String attributeName) {
    try {
      return myConnection.getAttribute(myBeanName, attributeName);
    }
    catch (JMException e) {
      throw new JMWrappedException(e);
    }
    catch (IOException e) {
      throw new JMWrappedException(e);
    }
  }

  protected void setAttribute(@NonNls String name, Object value) {
    try {
      myConnection.setAttribute(myBeanName, new Attribute(name, value));
    }
    catch (JMException e) {
      throw new JMWrappedException(e);
    }
    catch (IOException e) {
      throw new JMWrappedException(e);
    }
  }

  protected Object invoke(MethodSignature signature, Object... params) {
    try {
      return myConnection.invoke(myBeanName, signature.getName(), params, signature.getParameterTypes());
    }
    catch (JMException e) {
      throw new JMWrappedException(e);
    }
    catch (IOException e) {
      throw new JMWrappedException(e);
    }
  }

  protected ObjectName getBeanName() {
    return myBeanName;
  }

  protected MBeanServerConnection getConnection() {
    return myConnection;
  }

  protected static class MethodSignature {
    private @NonNls String myName;
    private String[] myParamTypes;

    public MethodSignature(@NonNls final String name, final Class... paramTypeClasses) {
      myName = name;
      myParamTypes = new String[paramTypeClasses.length];
      for (int i = 0; i < paramTypeClasses.length; i++) {
        myParamTypes[i] = paramTypeClasses[i].getName();
      }
    }

    public MethodSignature(@NonNls final String name, final @NonNls String... paramTypes) {
      myName = name;
      myParamTypes = paramTypes;
    }

    public @NonNls String getName() {
      return myName;
    }

    public String[] getParameterTypes() {
      return myParamTypes;
    }
  }
}
