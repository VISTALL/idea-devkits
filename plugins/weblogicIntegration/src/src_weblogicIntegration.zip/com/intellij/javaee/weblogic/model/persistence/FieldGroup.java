// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:field-groupType interface.
 */
public interface FieldGroup extends JavaeeDomModelElement {

	/**
	 * Returns the value of the group-name child.
	 * @return the value of the group-name child.
	 */
	@NotNull
	GenericDomValue<String> getGroupName();


	/**
	 * Returns the list of cmp-field children.
	 * @return the list of cmp-field children.
	 */
	List<GenericDomValue<String>> getCmpFields();
	/**
	 * Adds new child to the list of cmp-field children.
	 * @return created child
	 */
	GenericDomValue<String> addCmpField();


	/**
	 * Returns the list of cmr-field children.
	 * @return the list of cmr-field children.
	 */
	List<GenericDomValue<String>> getCmrFields();
	/**
	 * Adds new child to the list of cmr-field children.
	 * @return created child
	 */
	GenericDomValue<String> addCmrField();


}
