/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.configuration;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.command.CommandProcessor;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.ReadonlyStatusHandler;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiElementFactory;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import com.intellij.psi.xml.XmlDocument;
import com.intellij.util.IncorrectOperationException;
import com.intellij.xml.util.XmlTagTextUtil;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.module.WeblogicEjbFacetUtil;
import org.jetbrains.annotations.NonNls;

class DebugParameterChecker {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.weblogic.runDebug.configuration.DebugParameterChecker");

  private final XmlFile myXmlFile;
  private final Project myProject;

  @NonNls private static final String ROOT_TAG_NAME = "weblogic-web-app";
  @NonNls private static final String JSP_DESCRIPTOR_TAG_NAME = "jsp-descriptor";
  @NonNls private static final String JSP_PARAM_TAG_NAME = "jsp-param";
  @NonNls private static final String PARAM_TAG_NAME = "param-name";
  @NonNls private static final String DEBUG = "debug";
  @NonNls private static final String PARAM_VALUE = "param-value";
  @NonNls private static final String TRUE = "true";

  public DebugParameterChecker(XmlFile xmlFile, Project project) {
    myProject = project;
    myXmlFile = xmlFile;
  }

  public boolean checkDebugParameter() {
    if (myXmlFile == null) {
      return false;
    }

    final XmlDocument document = myXmlFile.getDocument();
    if (document == null) {
      return false;
    }

    XmlTag rootTag = document.getRootTag();
    if (rootTag == null || !ROOT_TAG_NAME.equals(rootTag.getName())) {
      return false;
    }

    XmlTag[] jspDescriptors = rootTag.findSubTags(JSP_DESCRIPTOR_TAG_NAME);
    final boolean version9x = WeblogicEjbFacetUtil.isVersion9x(myXmlFile);
    for (XmlTag jspDescriptor : jspDescriptors) {
      if (version9x) {
        final XmlTag tag = jspDescriptor.findFirstSubTag(DEBUG);
        if (tag != null && TRUE.equals(tag.getValue().getTrimmedText())) {
          return true;
        }
      }
      else {
        XmlTag[] jspParams = jspDescriptor.findSubTags(JSP_PARAM_TAG_NAME);
        for (XmlTag jspParam : jspParams) {
          XmlTag subTag = jspParam.findFirstSubTag(PARAM_TAG_NAME);
          if (subTag == null) continue;
          if (!DEBUG.equals(subTag.getValue().getTrimmedText())) continue;
          XmlTag paramValue = jspParam.findFirstSubTag(PARAM_VALUE);
          return paramValue != null && TRUE.equals(paramValue.getValue().getTrimmedText());
        }
      }
    }
    return false;
  }

  public Runnable getQuickFix() {
    if (myXmlFile == null || myXmlFile.getDocument() == null || myXmlFile.getDocument().getRootTag() == null) {
      return null;
    }
    return new DebugParameterQuickFix();
  }

  private class DebugParameterQuickFix implements Runnable {


    public void run() {
      CommandProcessor.getInstance().executeCommand(myProject, new Runnable() {
        public void run() {
          ApplicationManager.getApplication().runWriteAction(new Runnable() {
            public void run() {
              doFix();
            }
          });

        }
      }, WeblogicBundle.message("quickfix.name.debug.parameter.quickfix"), null);


    }

    private void doFix() {
      VirtualFile virtualFile = myXmlFile.getContainingFile().getVirtualFile();
      if (virtualFile != null && !virtualFile.isWritable()) {
        if (!ReadonlyStatusHandler.getInstance(myProject).ensureFilesWritable(virtualFile).hasReadonlyFiles()){
          return;
        }
      }

      try {
        XmlTag rootTag = myXmlFile.getDocument().getRootTag();
        if (!ROOT_TAG_NAME.equals(rootTag.getName())) {
          rootTag.setName(ROOT_TAG_NAME);
        }

        createDescriptorIn(rootTag);

        XmlTag[] jspDescriptors = rootTag.findSubTags(JSP_DESCRIPTOR_TAG_NAME);
        boolean version9x = WeblogicEjbFacetUtil.isVersion9x(myXmlFile);
        if (version9x) {
          final XmlTag debugTag = findOrCreateDebugSubTag(jspDescriptors);
          if (!TRUE.equals(debugTag.getValue().getTrimmedText())) {
            debugTag.getValue().setText(TRUE);
          }
        }
        else {
          XmlTag debug = findOrCreateDebugJspParamValueIn(jspDescriptors);
          if (!TRUE.equals(debug.getValue().getTrimmedText())) {
            debug.replace(getFactory().createTagFromText(XmlTagTextUtil.composeTagText(PARAM_VALUE, TRUE)));
          }
        }
      }
      catch (IncorrectOperationException e) {
        LOG.error(e);
      }
    }

    private XmlTag findOrCreateDebugSubTag(final XmlTag[] jspDescriptors) throws IncorrectOperationException {
      for (XmlTag jspDescriptor : jspDescriptors) {
        final XmlTag tag = jspDescriptor.findFirstSubTag(DEBUG);
        if (tag != null) {
          return tag;
        }
      }
      final XmlTag firstDescriptor = jspDescriptors[0];
      return (XmlTag)firstDescriptor.add(firstDescriptor.createChildTag(DEBUG, firstDescriptor.getNamespace(), TRUE, false));
    }

    private XmlTag findOrCreateDebugJspParamValueIn(XmlTag[] jspDescriptors) throws IncorrectOperationException {
      for (XmlTag jspDescriptor : jspDescriptors) {
        XmlTag[] jspParams = jspDescriptor.findSubTags(JSP_PARAM_TAG_NAME);
        for (XmlTag jspParam : jspParams) {
          XmlTag paramTag = jspParam.findFirstSubTag(PARAM_TAG_NAME);
          if (paramTag == null) continue;
          if (!DEBUG.equals(paramTag.getValue().getTrimmedText())) continue;
          XmlTag valueSubTag = jspParam.findFirstSubTag(PARAM_VALUE);
          if (valueSubTag != null) {
            return valueSubTag;
          }
          final XmlTag childTag = jspParam.createChildTag(PARAM_VALUE, jspParam.getNamespace(), TRUE, false);
          return (XmlTag)jspParam.add(childTag);
        }
      }

      XmlTag firstDescriptor = jspDescriptors[0];
      XmlTag param = firstDescriptor.createChildTag(JSP_PARAM_TAG_NAME, firstDescriptor.getNamespace(), null, false);
      param = (XmlTag)firstDescriptor.add(param);
      param.add(param.createChildTag(PARAM_TAG_NAME, firstDescriptor.getNamespace(), DEBUG, false));

      XmlTag childTag = param.createChildTag(PARAM_VALUE, firstDescriptor.getNamespace(), TRUE, false);
      return (XmlTag)param.add(childTag);
    }

    private PsiElementFactory getFactory() {
      return myXmlFile.getManager().getElementFactory();
    }

    private void createDescriptorIn(XmlTag rootTag) throws IncorrectOperationException {
      XmlTag[] jspDescriptors = rootTag.findSubTags(JSP_DESCRIPTOR_TAG_NAME);
      if (jspDescriptors.length == 0) {
        rootTag.add(rootTag.createChildTag(JSP_DESCRIPTOR_TAG_NAME, rootTag.getNamespace(), "", false));
      }
    }
  }

}