// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

/**
 * http://www.bea.com/ns/weblogic/90:iiop-security-descriptorType interface.
 */
public interface IiopSecurityDescriptor extends JavaeeDomModelElement {

	/**
	 * Returns the value of the transport-requirements child.
	 * @return the value of the transport-requirements child.
	 */
	TransportRequirements getTransportRequirements();


	/**
	 * Returns the value of the client-authentication child.
	 * @return the value of the client-authentication child.
	 */
	GenericDomValue<String> getClientAuthentication();


	/**
	 * Returns the value of the identity-assertion child.
	 * @return the value of the identity-assertion child.
	 */
	GenericDomValue<String> getIdentityAssertion();


}
