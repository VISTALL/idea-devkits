// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:method-paramsType interface.
 */
public interface MethodParams extends JavaeeDomModelElement {

	/**
	 * Returns the list of method-param children.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:java-typeType documentation</h3>
	 * This is a generic type that designates a Java primitive
	 * 	type or a fully qualified name of a Java interface/type,
	 * 	or an array of such types.
	 * </pre>
	 * @return the list of method-param children.
	 */
	List<GenericDomValue<String>> getMethodParams();
	/**
	 * Adds new child to the list of method-param children.
	 * @return created child
	 */
	GenericDomValue<String> addMethodParam();


}
