// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:relationship-cachingType interface.
 */
public interface RelationshipCaching extends JavaeeDomModelElement {

	/**
	 * Returns the value of the caching-name child.
	 * @return the value of the caching-name child.
	 */
	@NotNull
	GenericDomValue<String> getCachingName();


	/**
	 * Returns the list of caching-element children.
	 * @return the list of caching-element children.
	 */
	@NotNull
	List<CachingElement> getCachingElements();
	/**
	 * Adds new child to the list of caching-element children.
	 * @return created child
	 */
	CachingElement addCachingElement();


}
