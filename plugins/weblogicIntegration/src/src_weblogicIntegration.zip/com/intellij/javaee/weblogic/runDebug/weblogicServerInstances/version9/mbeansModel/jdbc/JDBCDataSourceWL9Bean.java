/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.jdbc;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

import org.jetbrains.annotations.NonNls;

/**
 * @author nik
 */
public class JDBCDataSourceWL9Bean extends AbstractWL9MBean {
  @NonNls private static final String JDBC_CONNECTION_POLL_PARAMS_NAME = "JDBCConnectionPoolParams";
  @NonNls private static final String JDBC_DATA_SOURCE_PARAMS_NAME = "JDBCDataSourceParams";
  @NonNls private static final String JDBCD_DRIVER_PARAMS_NAME = "JDBCDriverParams";
  @NonNls private static final String NAME_ATTRIBUTE_NAME = "Name";

  public JDBCDataSourceWL9Bean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public JDBCConnectionPoolParamsWL9Bean getJDBCConnectionPoolParams() {
    return new JDBCConnectionPoolParamsWL9Bean(getConnection(), getChild(JDBC_CONNECTION_POLL_PARAMS_NAME));
  }

  public JDBCDataSourceParamsWL9Bean getJDBCDataSourceParams() {
    return new JDBCDataSourceParamsWL9Bean(getConnection(), getChild(JDBC_DATA_SOURCE_PARAMS_NAME));
  }

  public JDBCDriverParamsWL9Bean getJDBCDriverParams() {
    return new JDBCDriverParamsWL9Bean(getConnection(), getChild(JDBCD_DRIVER_PARAMS_NAME));
  }

  public String getName() {
    return (String)getAttribute(NAME_ATTRIBUTE_NAME);
  }

  public void setName(String name) {
    setAttribute(NAME_ATTRIBUTE_NAME, name);
  }
}
