// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:unknown-primary-key-fieldType interface.
 */
public interface UnknownPrimaryKeyField extends JavaeeDomModelElement {

	/**
	 * Returns the value of the cmp-field child.
	 * @return the value of the cmp-field child.
	 */
	@NotNull
	GenericDomValue<String> getCmpField();


}
