// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:entity-descriptorType interface.
 */
public interface EntityDescriptor extends JavaeeDomModelElement {

	/**
	 * Returns the value of the pool child.
	 * @return the value of the pool child.
	 */
	Pool getPool();


	/**
	 * Returns the value of the timer-descriptor child.
	 * @return the value of the timer-descriptor child.
	 */
	TimerDescriptor getTimerDescriptor();


	/**
	 * Returns the value of the persistence child.
	 * @return the value of the persistence child.
	 */
	Persistence getPersistence();


	/**
	 * Returns the value of the entity-clustering child.
	 * @return the value of the entity-clustering child.
	 */
	EntityClustering getEntityClustering();


	/**
	 * Returns the value of the invalidation-target child.
	 * @return the value of the invalidation-target child.
	 */
	InvalidationTarget getInvalidationTarget();


	/**
	 * Returns the value of the enable-dynamic-queries child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the enable-dynamic-queries child.
	 */
	GenericDomValue<Boolean> getEnableDynamicQueries();


	/**
	 * Returns the value of the entity-cache child.
	 * @return the value of the entity-cache child.
	 */
	@NotNull
	EntityCache getEntityCache();


	/**
	 * Returns the value of the entity-cache-ref child.
	 * @return the value of the entity-cache-ref child.
	 */
	@NotNull
	EntityCacheRef getEntityCacheRef();


}
