/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.model.impl.persistence;

import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsBean;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.javaee.weblogic.module.WeblogicEjbFacetUtil;
import com.intellij.javaee.model.xml.impl.BaseImpl;
import com.intellij.javaee.ejb.EjbModuleUtil;
import com.intellij.psi.PsiManager;
import org.jetbrains.annotations.NotNull;

/**
 * @author peter
 */
public abstract class WeblogicRdbmsBeanImpl extends BaseImpl implements WeblogicRdbmsBean {

  @NotNull
  public GenericDomValue<String> getRightDataSourceName() {
    return WeblogicEjbFacetUtil.isVersion9x(EjbModuleUtil.getEjbFacet(this)) ? getDataSourceJndiName() : getDataSourceName();
  }


  public PsiManager getPsiManager() {
    return PsiManager.getInstance(getModule().getProject());
  }
}
