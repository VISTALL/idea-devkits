// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:relationship-role-mapType interface.
 */
public interface RelationshipRoleMap extends JavaeeDomModelElement {

	/**
	 * Returns the value of the foreign-key-table child.
	 * @return the value of the foreign-key-table child.
	 */
	GenericDomValue<String> getForeignKeyTable();


	/**
	 * Returns the value of the primary-key-table child.
	 * @return the value of the primary-key-table child.
	 */
	GenericDomValue<String> getPrimaryKeyTable();


	/**
	 * Returns the list of column-map children.
	 * @return the list of column-map children.
	 */
	@NotNull
	List<ColumnMap> getColumnMaps();
	/**
	 * Adds new child to the list of column-map children.
	 * @return created child
	 */
	ColumnMap addColumnMap();


}
