// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.Description;
import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:security-permissionType interface.
 */
public interface SecurityPermission extends JavaeeDomModelElement {

	/**
	 * Returns the value of the description child.
	 * @return the value of the description child.
	 */
	Description getDescription();


	/**
	 * Returns the value of the security-permission-spec child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:string documentation</h3>
	 * This is a special string datatype that is defined by J2EE as
	 * 	a base type for defining collapsed strings. When schemas
	 * 	require trailing/leading space elimination as well as
	 * 	collapsing the existing whitespace, this base type may be
	 * 	used.
	 * </pre>
	 * @return the value of the security-permission-spec child.
	 */
	@NotNull
	GenericDomValue<String> getSecurityPermissionSpec();


}
