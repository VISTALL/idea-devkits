/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.jdbc.JDBCSystemResourceWL9MBean;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

/**
 * @author nik
 */
public class DomainWL9MBean extends AbstractWL9MBean {
  private static final MethodSignature CREATE_RESOURCE_SIGNATURE = new MethodSignature("createJDBCSystemResource", String.class);

  public DomainWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public JDBCSystemResourceWL9MBean[] getJDBCSystemResources() {
    final ObjectName[] children = getChildren("JDBCSystemResources");
    final JDBCSystemResourceWL9MBean[] systemResources = new JDBCSystemResourceWL9MBean[children.length];
    for (int i = 0; i < children.length; i++) {
      systemResources[i] = new JDBCSystemResourceWL9MBean(getConnection(), children[i]);
    }
    return systemResources;
  }

  public JDBCSystemResourceWL9MBean createJDBCSystemResource(String name) {
    final ObjectName objectName = (ObjectName)invoke(CREATE_RESOURCE_SIGNATURE, name);
    return new JDBCSystemResourceWL9MBean(getConnection(), objectName);
  }

  public AppDeploymentWL9MBean[] getAppDeployments() {
    final ObjectName[] children = getChildren("AppDeployments");
    final AppDeploymentWL9MBean[] deployments = new AppDeploymentWL9MBean[children.length];
    for (int i = 0; i < children.length; i++) {
      deployments[i] = new AppDeploymentWL9MBean(getConnection(), children[i]);
    }
    return deployments;
  }
}
