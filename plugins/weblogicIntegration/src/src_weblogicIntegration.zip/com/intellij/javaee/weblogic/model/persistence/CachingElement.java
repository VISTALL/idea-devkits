// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:caching-elementType interface.
 */
public interface CachingElement extends JavaeeDomModelElement {

	/**
	 * Returns the value of the cmr-field child.
	 * @return the value of the cmr-field child.
	 */
	@NotNull
	GenericDomValue<String> getCmrField();


	/**
	 * Returns the value of the group-name child.
	 * @return the value of the group-name child.
	 */
	GenericDomValue<String> getGroupName();


	/**
	 * Returns the list of caching-element children.
	 * @return the list of caching-element children.
	 */
	List<CachingElement> getCachingElements();
	/**
	 * Adds new child to the list of caching-element children.
	 * @return created child
	 */
	CachingElement addCachingElement();


}
