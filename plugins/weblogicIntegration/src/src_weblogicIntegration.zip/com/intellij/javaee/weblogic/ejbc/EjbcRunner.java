/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.ejbc;

import com.intellij.execution.CantRunException;
import com.intellij.execution.configurations.GeneralCommandLine;
import com.intellij.execution.configurations.JavaParameters;
import com.intellij.execution.process.*;
import com.intellij.javaee.appServerIntegrations.ApplicationServer;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.compiler.CompileContext;
import com.intellij.openapi.compiler.CompilerMessageCategory;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.roots.OrderRootType;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.List;

/**
 * @author cdr
 */

public class EjbcRunner {
  protected final JavaeeModuleProperties myModuleProperties;
  private final String myCompilerName;
  private final String myCompilerClassName;
  @NonNls protected static final String FORCEGENERATION_PARAM_NAME = "-forceGeneration";

  public EjbcRunner(final JavaeeModuleProperties moduleProperties) {
    this(moduleProperties, WeblogicBundle.message("ejbc.compiler.name"), "weblogic.ejbc");
  }

  protected EjbcRunner(JavaeeModuleProperties moduleProperties, String compilerName, @NonNls String compilerClassName) {
    myModuleProperties = moduleProperties;
    myCompilerName = compilerName;
    myCompilerClassName = compilerClassName;
  }

  public void run(final File path, final CompileContext context, final ApplicationServer server) throws Exception {
    final GeneralCommandLine[] commandLine = new GeneralCommandLine[1];
    final CantRunException[] cantRunException = new CantRunException[]{null};
    ApplicationManager.getApplication().runReadAction(new Runnable() {
      public void run() {
        context.getProgressIndicator().setText(
          WeblogicBundle.message("progress.text.running.compilername.for.module", myCompilerName, myModuleProperties.getPresentableName()));
        Module module = myModuleProperties.getModule();
        ProjectJdk jdk = ModuleRootManager.getInstance(module).getJdk();
        if (jdk == null) {
          jdk = ProjectRootManager.getInstance(module.getProject()).getProjectJdk();
        }
        if (jdk == null) {
          cantRunException[0] = new CantRunException(WeblogicBundle.message("exception.text.jdk.not.specified"));
          return;
        }
        if (jdk.getVersionString().indexOf("1.4") == -1) {
          context.addMessage(CompilerMessageCategory.WARNING, WeblogicBundle.message("ejbc.runner.invalid.jdk.error.text", myCompilerName,
                                                                                     jdk.getVersionString(), module.getName()), null, -1, -1);
          return;
        }
        JavaParameters javaParameters = new JavaParameters();
        javaParameters.setJdk(jdk);
        VirtualFile[] files = server.getLibrary().getFiles(OrderRootType.CLASSES);
        for (VirtualFile file : files) {
          javaParameters.getClassPath().add(file);
        }

        javaParameters.getClassPath().add(javaParameters.getJdk().getToolsPath());
        javaParameters.setMainClass(myCompilerClassName);
        javaParameters.getProgramParametersList().add(FORCEGENERATION_PARAM_NAME, path.getPath());
        javaParameters.setWorkingDirectory(path.isDirectory() ? path : path.getParentFile());
        try {
          commandLine[0] = GeneralCommandLine.createFromJavaParameters(javaParameters);
        }
        catch (CantRunException e) {
          cantRunException[0] = e;
        }
      }
    });
    if (cantRunException[0] != null) throw cantRunException[0];
    if (commandLine[0] == null) {
      return;
    }

    final AbstractOutputParser ejbcOutput = createCompilerOutputParser();

    final OSProcessHandler handler = new DefaultJavaProcessHandler(commandLine[0]);
    final CheckCancelRunnable checkCancelRunnable = new CheckCancelRunnable(context, handler);

    handler.addProcessListener(new ProcessAdapter() {
      public void onTextAvailable(final ProcessEvent event, final Key outputType) {
        if (outputType == ProcessOutputTypes.STDERR) {
          ejbcOutput.outputAvailable(event.getText());
          ejbcOutput.parseAvailableOutput();
        }
      }

      public void processTerminated(ProcessEvent event) {
        ejbcOutput.parseAvailableOutput();
        String output = ejbcOutput.getOutput();
        if (output.length() != 0) {
          final EjbcError error = new EjbcError(output, myModuleProperties, null);
          ejbcOutput.addMessage(error);
        }
        
        checkCancelRunnable.cancel();
      }
    });

    handler.startNotify();
    checkCancelRunnable.run();
    if (context.getProgressIndicator().isCanceled()) return;

    final List<EjbcError> messages = ejbcOutput.getMessages();
    for (EjbcError error : messages) {
      final String message = error.getMessage();
      context.addMessage(error.getMessageCategory(), message, null, -1, -1);
    }
    if (messages.size() == 0) {
      context.addMessage(CompilerMessageCategory.INFORMATION, WeblogicBundle.message(
        "message.text.compiler.for.module.finished.successfully", myCompilerName, myModuleProperties.getPresentableName()), null, -1, -1);
    }
  }

  protected AbstractOutputParser createCompilerOutputParser() {
    return new EjbcOutputParser(myModuleProperties);
  }

  private static class CheckCancelRunnable implements Runnable {
    private final OSProcessHandler myProcessHandler;
    private boolean myCanceled;
    private final CompileContext myContext;

    private CheckCancelRunnable(CompileContext context, OSProcessHandler process) {
      myContext = context;
      myProcessHandler = process;
    }

    public void cancel() {
      myCanceled = true;
    }

    public void run() {
      while (!myCanceled) {
        if (myContext.getProgressIndicator().isCanceled()) {
          myProcessHandler.destroyProcess();
          return;
        }
        try {
          Thread.sleep(100);
        }
        catch (InterruptedException e) {
        }
      }
    }
  }
}
