// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

/**
 * http://www.bea.com/ns/weblogic/90:stateful-session-descriptorType interface.
 */
public interface StatefulSessionDescriptor extends JavaeeDomModelElement {

	/**
	 * Returns the value of the stateful-session-cache child.
	 * @return the value of the stateful-session-cache child.
	 */
	StatefulSessionCache getStatefulSessionCache();


	/**
	 * Returns the value of the persistent-store-dir child.
	 * @return the value of the persistent-store-dir child.
	 */
	GenericDomValue<String> getPersistentStoreDir();


	/**
	 * Returns the value of the stateful-session-clustering child.
	 * @return the value of the stateful-session-clustering child.
	 */
	StatefulSessionClustering getStatefulSessionClustering();


	/**
	 * Returns the value of the allow-concurrent-calls child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the allow-concurrent-calls child.
	 */
	GenericDomValue<Boolean> getAllowConcurrentCalls();


	/**
	 * Returns the value of the allow-remove-during-transaction child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the allow-remove-during-transaction child.
	 */
	GenericDomValue<Boolean> getAllowRemoveDuringTransaction();


}
