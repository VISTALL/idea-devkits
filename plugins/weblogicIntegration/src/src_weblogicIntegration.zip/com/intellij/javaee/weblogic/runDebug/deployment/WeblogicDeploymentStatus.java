/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.deployment;

import com.intellij.javaee.deployment.DeploymentStatus;
import com.intellij.j2ee.wrappers.WeblogicOutputInfo;

import java.util.HashMap;
import java.util.Map;

public class WeblogicDeploymentStatus {

  private Map<String, DeploymentStatus> weblogicToStatus = new HashMap<String, DeploymentStatus>();



  public WeblogicDeploymentStatus(WeblogicOutputInfo outputInfo) {
    weblogicToStatus.put(outputInfo.getActivated(), DeploymentStatus.DEPLOYED);
    weblogicToStatus.put(outputInfo.getActivating(), DeploymentStatus.ACTIVATING);
    weblogicToStatus.put(outputInfo.getPrepared(), DeploymentStatus.PREPARED);
    weblogicToStatus.put(outputInfo.getPreparing(), DeploymentStatus.PREPARING);
    weblogicToStatus.put(outputInfo.getDeactivated(), DeploymentStatus.NOT_DEPLOYED);
    weblogicToStatus.put(outputInfo.getDeactivating(), DeploymentStatus.DEACTIVATING);
    weblogicToStatus.put(outputInfo.getUnprepared(), DeploymentStatus.UNPREPARED);
    weblogicToStatus.put(outputInfo.getUnpreparing(), DeploymentStatus.UNPREPARING);
    weblogicToStatus.put(outputInfo.getFailed(), DeploymentStatus.FAILED);

  }

  public DeploymentStatus decodeWeblogicStatus(String weblogicStatus) {
    return weblogicToStatus.get(weblogicStatus);
  }
}
