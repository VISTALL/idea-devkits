/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

import org.jetbrains.annotations.NonNls;

/**
 * @author nik
 */
public class DeployerRuntimeWL9MBean extends AbstractWL9MBean {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.DeployerRuntimeWL9MBean");
  @NonNls private static final String DEPLOYMENT_DATA_CLASS_NAME = "weblogic.management.deploy.DeploymentData";
  @NonNls private static final String[] DEPLOY_PARAMETER_TYPES = new String[] {"java.lang.String", "java.lang.String", "java.lang.String", DEPLOYMENT_DATA_CLASS_NAME, "java.lang.String", "java.lang.Boolean"};
  @NonNls private static final String[] UNDEPLOY_PARAM_TYPES = new String[]{"java.lang.String", DEPLOYMENT_DATA_CLASS_NAME, "java.lang.String", "java.lang.Boolean"};
  private static final MethodSignature DEPLOY_SIGNATURE = new MethodSignature("deploy", DEPLOY_PARAMETER_TYPES);
  private static final MethodSignature ACTIVATE_SIGNATURE = new MethodSignature("activate", DEPLOY_PARAMETER_TYPES);
  private static final MethodSignature UNDEPLOY_SIGNATURE = new MethodSignature("undeploy", UNDEPLOY_PARAM_TYPES);
  private static final MethodSignature REMOVE_SIGNATURE = new MethodSignature("remove", UNDEPLOY_PARAM_TYPES);
  @NonNls private static final String ADD_GLOBAL_TARGET_NAME = "addGlobalTarget";
  private static final Boolean START_TASK_IMMEDIATELY = Boolean.FALSE;
  private static final Boolean ADD_TARGET_BEFORE_STARTING = true;

  public DeployerRuntimeWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  private DeploymentTaskRuntimeWL9MBean configureAndStartTask(final ObjectName objectName, final String serverName) {
    final DeploymentTaskRuntimeWL9MBean task = new DeploymentTaskRuntimeWL9MBean(getConnection(), objectName);
    if (!START_TASK_IMMEDIATELY) {
      if (!ADD_TARGET_BEFORE_STARTING) {
        final Object deploymentData = task.getDeploymentData();
        addTarget(deploymentData, serverName);
      }
      task.start();
    }
    return task;
  }

  private void addTarget(final Object deploymentData, final String serverName) {
    try {
      deploymentData.getClass().getMethod(ADD_GLOBAL_TARGET_NAME, String.class).invoke(deploymentData, serverName);
    }
    catch (Exception e) {
      LOG.error(e);
    }
  }

  public DeploymentTaskRuntimeWL9MBean activate(String source, String name, String serverName) {
    final ObjectName objectName = (ObjectName)invoke(ACTIVATE_SIGNATURE, source, name, null, createDeploymentData(serverName), null, START_TASK_IMMEDIATELY);
    return configureAndStartTask(objectName, serverName);
  }

  private Object createDeploymentData(final String serverName) {
    if (!ADD_TARGET_BEFORE_STARTING) {
      return null;
    }

    Object data = null;
    try {
      final Class<?> aClass = Class.forName(DEPLOYMENT_DATA_CLASS_NAME, true, Thread.currentThread().getContextClassLoader());
      data = aClass.newInstance();
      addTarget(data, serverName);
    }
    catch (Exception e) {
      LOG.error(e);
    }
    return data;
  }

  public DeploymentTaskRuntimeWL9MBean undeploy(String name, String serverName) {
    final ObjectName objectName = (ObjectName)invoke(UNDEPLOY_SIGNATURE, name, createDeploymentData(serverName), null, START_TASK_IMMEDIATELY);
    return configureAndStartTask(objectName, serverName);
  }

  public DeploymentTaskRuntimeWL9MBean remove(String name, String serverName) {
    final ObjectName objectName = (ObjectName)invoke(REMOVE_SIGNATURE, name, createDeploymentData(serverName), null, START_TASK_IMMEDIATELY);
    return configureAndStartTask(objectName, serverName);
  }
}
