/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel;

import org.jetbrains.annotations.NonNls;

import javax.management.ObjectName;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import java.text.MessageFormat;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.DomainRuntimeServiceWL9MBean;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.RuntimeServiceWL9MBean;

/**
 * @author nik
 */
public class MBeansFactory {
  @NonNls private static final String RUNTIME_SERVICE_MBEAN_TYPE = "weblogic.management.mbeanservers.runtime.RuntimeServiceMBean";
  @NonNls private static final String RUNTIME_SERVICE_MBEAN_NAME = "RuntimeService";
  @NonNls private static final String DOMAIN_RUNTIME_SERVICE_MBEAN_TYPE = "weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean";
  @NonNls private static final String DOMAIN_RUNTIME_SERVICE_MBEAN_NAME = "DomainRuntimeService";
  @NonNls private static final String EDIT_SERVICE_MBEAN_TYPE = "weblogic.management.mbeanservers.edit.EditServiceMBean";
  @NonNls private static final String EDIT_SERVICE_MBEAN_NAME = "EditService";
  @NonNls private static final String OBJECT_NAME_PATTERN = "com.bea:Name={0},Type={1}";
  @NonNls private static final String OBJECT_NAME_PATTERN_WITH_LOCATION = "com.bea:Name={0},Type={1},Location={2}";

  public static RuntimeServiceWL9MBean createRuntimeService(final MBeanServerConnection connection, final String serverName) {
    try {
      final ObjectName beanName = new ObjectName(MessageFormat.format(OBJECT_NAME_PATTERN_WITH_LOCATION, RUNTIME_SERVICE_MBEAN_NAME, RUNTIME_SERVICE_MBEAN_TYPE, serverName));
      return new RuntimeServiceWL9MBean(connection, beanName);
    }
    catch (MalformedObjectNameException e) {
      throw new JMWrappedException(e);
    }
  }

  public static DomainRuntimeServiceWL9MBean createDomainRuntimeService(final MBeanServerConnection connection) {
    try {
      final ObjectName name = new ObjectName(MessageFormat.format(OBJECT_NAME_PATTERN, DOMAIN_RUNTIME_SERVICE_MBEAN_NAME, DOMAIN_RUNTIME_SERVICE_MBEAN_TYPE));
      return new DomainRuntimeServiceWL9MBean(connection, name);
    }
    catch (MalformedObjectNameException e) {
      throw new JMWrappedException(e);
    }
  }

  public static EditServiceWL9MBean createEditService(final MBeanServerConnection connection) {
    try {
      final ObjectName name = new ObjectName(MessageFormat.format(OBJECT_NAME_PATTERN, EDIT_SERVICE_MBEAN_NAME, EDIT_SERVICE_MBEAN_TYPE));
      return new EditServiceWL9MBean(connection, name);
    }
    catch (MalformedObjectNameException e) {
      throw new JMWrappedException(e);
    }
  }
}
