/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.configuration;

import com.intellij.execution.ui.ConsoleViewContentType;
import com.intellij.openapi.editor.markup.EffectType;
import com.intellij.openapi.editor.markup.TextAttributes;
import com.intellij.openapi.util.Key;

import java.awt.*;

import org.jetbrains.annotations.NonNls;

class WeblogicConsoleViewContentType extends ConsoleViewContentType {
  private WeblogicConsoleViewContentType(@NonNls String name, TextAttributes textAttributes) {
    super(name, textAttributes);
  }

  private static final TextAttributes SEVERITY_DEBUG_ATTRIBUTES = new TextAttributes();
  private static final TextAttributes SEVERITY_INFO_ATTRIBUTES = new TextAttributes();
  private static final TextAttributes SEVERITY_WARNING_ATTRIBUTES = new TextAttributes();
  private static final TextAttributes SEVERITY_ERROR_ATTRIBUTES = new TextAttributes();
  private static final TextAttributes SEVERITY_NOTICE_ATTRIBUTES = new TextAttributes();
  private static final TextAttributes SEVERITY_CRITICAL_ATTRIBUTES = new TextAttributes();
  private static final TextAttributes SEVERITY_ALERT_ATTRIBUTES = new TextAttributes();
  private static final TextAttributes SEVERITY_EMERGENCY_ATTRIBUTES = new TextAttributes();

  public static final Key SEVERITY_DEBUG_KEY = new Key("SEVERITY_DEBUG");
  public static final Key SEVERITY_INFO_KEY = new Key("SEVERITY_INFO");
  public static final Key SEVERITY_WARNING_KEY = new Key("SEVERITY_WARNING");
  public static final Key SEVERITY_ERROR_KEY = new Key("SEVERITY_ERROR");
  public static final Key SEVERITY_NOTICE_KEY = new Key("SEVERITY_NOTICE");
  public static final Key SEVERITY_CRITICAL_KEY = new Key("SEVERITY_CRITICAL");
  public static final Key SEVERITY_ALERT_KEY = new Key("SEVERITY_ALERT");
  public static final Key SEVERITY_EMERGENCY_KEY = new Key("SEVERITY_EMERGENCY");


  static {
    SEVERITY_DEBUG_ATTRIBUTES.setForegroundColor(new Color(0, 100, 128));
    SEVERITY_INFO_ATTRIBUTES.setForegroundColor(new Color(0, 0, 128));
    SEVERITY_WARNING_ATTRIBUTES.setForegroundColor(new Color(255, 210, 80));
    SEVERITY_ERROR_ATTRIBUTES.setForegroundColor(Color.RED);
    SEVERITY_ERROR_ATTRIBUTES.setEffectType(EffectType.LINE_UNDERSCORE);
    SEVERITY_NOTICE_ATTRIBUTES.setForegroundColor(Color.GREEN);
    SEVERITY_CRITICAL_ATTRIBUTES.setForegroundColor(Color.PINK);
    SEVERITY_ALERT_ATTRIBUTES.setForegroundColor(Color.MAGENTA);
    SEVERITY_EMERGENCY_ATTRIBUTES.setForegroundColor(Color.CYAN);

    ConsoleViewContentType.registerNewConsoleViewType(SEVERITY_DEBUG_KEY, new WeblogicConsoleViewContentType("SEVERITY_DEBUG",
                                                                                                             SEVERITY_DEBUG_ATTRIBUTES));
    ConsoleViewContentType.registerNewConsoleViewType(SEVERITY_INFO_KEY, new WeblogicConsoleViewContentType("SEVERITY_INFO", SEVERITY_INFO_ATTRIBUTES));
    ConsoleViewContentType.registerNewConsoleViewType(SEVERITY_WARNING_KEY, new WeblogicConsoleViewContentType("SEVERITY_WARNING",
                                                                                                               SEVERITY_WARNING_ATTRIBUTES));
    ConsoleViewContentType.registerNewConsoleViewType(SEVERITY_ERROR_KEY, new WeblogicConsoleViewContentType("SEVERITY_ERROR",
                                                                                                             SEVERITY_ERROR_ATTRIBUTES));
    ConsoleViewContentType.registerNewConsoleViewType(SEVERITY_NOTICE_KEY, new WeblogicConsoleViewContentType("SEVERITY_NOTICE",
                                                                                                              SEVERITY_NOTICE_ATTRIBUTES));
    ConsoleViewContentType.registerNewConsoleViewType(SEVERITY_CRITICAL_KEY, new WeblogicConsoleViewContentType("SEVERITY_CRITICAL",
                                                                                                                SEVERITY_CRITICAL_ATTRIBUTES));
    ConsoleViewContentType.registerNewConsoleViewType(SEVERITY_ALERT_KEY, new WeblogicConsoleViewContentType("SEVERITY_ALERT",
                                                                                                             SEVERITY_ALERT_ATTRIBUTES));
    ConsoleViewContentType.registerNewConsoleViewType(SEVERITY_EMERGENCY_KEY, new WeblogicConsoleViewContentType("SEVERITY_EMERGENCY",
                                                                                                                 SEVERITY_EMERGENCY_ATTRIBUTES));

  }

}
