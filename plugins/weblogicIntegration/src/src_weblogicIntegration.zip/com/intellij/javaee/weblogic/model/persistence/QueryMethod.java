// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:query-methodType interface.
 */
public interface QueryMethod extends JavaeeDomModelElement {

	/**
	 * Returns the value of the method-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:method-nameType documentation</h3>
	 * The method-nameType contains a name of an enterprise
	 * 	bean method or the asterisk (*) character. The asterisk is
	 * 	used when the element denotes all the methods of an
	 * 	enterprise bean's client view interfaces.
	 * </pre>
	 * @return the value of the method-name child.
	 */
	@NotNull
	GenericDomValue<String> getMethodName();


	/**
	 * Returns the value of the method-params child.
	 * @return the value of the method-params child.
	 */
	@NotNull
	MethodParams getMethodParams();


}
