/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.configuration;

import com.intellij.javaee.appServerIntegrations.ApplicationServer;
import com.intellij.javaee.run.configuration.ApplicationServerSelectionListener;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.run.configuration.PredefinedLogFilesProviderEditor;
import com.intellij.javaee.run.configuration.PredefinedLogFilesListener;
import com.intellij.javaee.weblogic.applicationServer.WeblogicPersistentData;
import com.intellij.javaee.weblogic.beaInstallation.BeaDomain;
import com.intellij.javaee.weblogic.beaInstallation.BeaInstallation;
import com.intellij.javaee.weblogic.beaInstallation.BeaServer;
import com.intellij.javaee.weblogic.beaInstallation.WeblogicUtil;
import com.intellij.openapi.fileChooser.FileChooser;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.ui.ComboBoxFieldPanel;
import com.intellij.util.containers.HashMap;
import com.intellij.util.EventDispatcher;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

class WeblogicLocalRunConfigurationEditor extends SettingsEditor<CommonModel> implements ApplicationServerSelectionListener,
                                                                                         PredefinedLogFilesProviderEditor {
  private EventDispatcher<PredefinedLogFilesListener> myDispatcher = EventDispatcher.create(PredefinedLogFilesListener.class);
  private ApplicationServer myLastSelectedServer;
  private JPanel myPanel;
  private JPanel myDomainPathPanel;
  private final ComboBoxFieldPanel myDomainPath = new ComboBoxFieldPanel();

  private JTextField myUser;
  private JPasswordField myPassword;
  private JComboBox myServerCombobox;
  private JLabel myServerLabel;

  private final Map <String, BeaInstallation> myCashedInstallations = new HashMap<String, BeaInstallation>();

  public WeblogicLocalRunConfigurationEditor() {
    final FileChooserDescriptor domainPathChooserDescriptor = new FileChooserDescriptor(false, true, false, false, false, false);
    myDomainPath.setBrowseButtonActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        final String path = myDomainPath.getText();
        final VirtualFile toSelect = path != null && path.length() > 0? LocalFileSystem.getInstance().findFileByPath(path.replace(File.separatorChar, '/')) : null;
        final VirtualFile[] files = FileChooser.chooseFiles(myPanel, domainPathChooserDescriptor, toSelect);
        if (files != null && files.length == 1) {
          myDomainPath.setText(files[0].getPath().replace('/', File.separatorChar));
          onDomainChanged();
        }
      }
    });
    myDomainPath.createComponent();
    myDomainPath.getComboBox().addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        onDomainChanged();
      }
    });

    myServerCombobox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        predefinedLogFilesChanged();
      }
    });

    myDomainPathPanel.setLayout(new BorderLayout());
    myDomainPathPanel.add(myDomainPath, BorderLayout.CENTER);
  }

  private void onDomainChanged() {
    myServerCombobox.removeAllItems();
    final BeaDomain domain = WeblogicUtil.createDomain(new File(myDomainPath.getText()));
    final BeaServer[] servers = domain.getServers();
    for (BeaServer server : servers) {
      if (server.isAdmin()) {
        myServerCombobox.addItem(server.getName());
      }
    }
    if (myServerCombobox.getItemCount() > 0) {
      myServerCombobox.setSelectedIndex(0);
    }
    else {
      predefinedLogFilesChanged();
    }
    final boolean visible = myServerCombobox.getItemCount() > 1;
    myServerCombobox.setVisible(visible);
    myServerLabel.setVisible(visible);
  }

  private void predefinedLogFilesChanged() {
    try {
      myDispatcher.getMulticaster().predefinedLogFilesChanged(getSnapshot());
    }
    catch (ConfigurationException e) {
    }
  }

  public void serverSelected(@Nullable ApplicationServer server) {
    if (myLastSelectedServer == server) return;
    
    myLastSelectedServer = server;
    refreshDomainsList(server);
  }

  private void refreshDomainsList(@Nullable ApplicationServer server) {
    JComboBox comboBox = myDomainPath.getComboBox();
    comboBox.removeAllItems();
    if (server == null) return;

    BeaDomain[] domains = getDomains(getBeaPath(server));
    ArrayList<String> domainPaths = new ArrayList<String>();
    final String serverVersion = ((WeblogicPersistentData)server.getPersistentData()).VERSION;
    for (BeaDomain domain : domains) {
      if (serverVersion.equals(domain.getVersion())) {
        domainPaths.add(domain.getLocation().getAbsolutePath());
      }
    }
    Collections.sort(domainPaths);
    for (String domainPath : domainPaths) {
      comboBox.addItem(domainPath);
    }
  }

  private static String getBeaPath(final ApplicationServer server) {
    WeblogicPersistentData persistentData = (WeblogicPersistentData)server.getPersistentData();
    if (persistentData == null) return "";

    return FileUtil.toSystemDependentName(persistentData.BEA_HOME);
  }

  private BeaDomain[] getDomains(String path) {
    if (path.length() == 0) {
      return BeaDomain.EMPTY_ARRAY;
    }

    if (!myCashedInstallations.containsKey(path)){
      myCashedInstallations.put(path, WeblogicUtil.getInstallationByLocation(new File(path)));
    }
    if (path.length() == 0) {
      return BeaDomain.EMPTY_ARRAY;
    }

    return myCashedInstallations.get(path).getDomains();
  }

  public void applyEditorTo(CommonModel configuration) throws ConfigurationException {
    WeblogicModel wl = ((WeblogicModel)configuration.getServerModel());
    String domainPath = myDomainPath.getText();
    if (domainPath.length() != 0) {
      BeaDomain domain = WeblogicUtil.createDomain(new File(domainPath));
      wl.DOMAIN_PATH = domain.getLocation().getAbsolutePath();
      final String selectedServer = (String)myServerCombobox.getSelectedItem();
      wl.SERVER_NAME = selectedServer != null ? selectedServer : "";
      wl.DOMAIN_NAME = domain.getName();
    }
    else {
      wl.DOMAIN_PATH = "";
      wl.SERVER_NAME = "";
      wl.DOMAIN_NAME = "";

    }
    wl.USER = myUser.getText();
    wl.PASSWORD = new String(myPassword.getPassword());
  }

  public void resetEditorFrom(CommonModel configuration) {
    WeblogicModel wl = ((WeblogicModel)configuration.getServerModel());

    refreshDomainsList(configuration.getApplicationServer());
    myDomainPath.setText(wl.DOMAIN_PATH);
    onDomainChanged();
    for (int i = 0; i < myServerCombobox.getItemCount(); i++) {
      if (wl.SERVER_NAME.equals(myServerCombobox.getItemAt(i))) {
        myServerCombobox.setSelectedIndex(i);
        break;
      }
    }

    myUser.setText(wl.USER);
    myPassword.setText(wl.PASSWORD);
  }

  @NotNull
  public JComponent createEditor() {
    return myPanel;
  }

  public void disposeEditor() {
  }


  public void addListener(PredefinedLogFilesListener listener) {
    myDispatcher.addListener(listener);
  }

  public void removeListener(PredefinedLogFilesListener listener) {
    myDispatcher.removeListener(listener);
  }
}


