/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.javaee.weblogic.runDebug.configuration.WeblogicModel;
import com.intellij.javaee.deployment.DeploymentManager;

import java.security.PrivilegedActionException;
import java.util.List;
import java.util.LinkedList;
import java.net.Socket;
import java.io.IOException;

import org.jetbrains.annotations.NonNls;

/**
 * @author nik
 */
public abstract class ServerPollThread extends Thread {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.ServerPollThread");
  @NonNls private static final String THREAD_NAME = "ServerPollThread";
  protected final List<Runnable> myRequests = new LinkedList<Runnable>();
  protected boolean myInitialized = false;
  private boolean myPollServer;
  protected final WeblogicModel myRunConfiguration;
  private boolean myNoPoll;
  private final Project myProject;
  protected final int myPort;
  protected final String myHost;
  private final WeblogicAbstractInstance myWeblogicAbstractInstance;
  protected Runnable pollServerRequest = new Runnable() {
    @NonNls public String toString() {
      return "polling";
    }

    public void run() {
      pollServer();
    }
  };

  protected ServerPollThread(final WeblogicAbstractInstance weblogicAbstractInstance,
                             final Project project, final WeblogicModel runConfiguration) {
    super(THREAD_NAME);
    myWeblogicAbstractInstance = weblogicAbstractInstance;
    myProject = project;
    myPollServer = true;
    myRunConfiguration = runConfiguration;
    myPort = myRunConfiguration.getCommonModel().getPort();
    myHost = myRunConfiguration.getCommonModel().getHost();
  }

  public boolean queueRequest(Runnable runnable) {
    synchronized (myRequests) {
      return doQueueRequest(runnable);
    }
  }

  private boolean doQueueRequest(Runnable runnable) {
    if (myPollServer) {
      myRequests.add(runnable);
      LOG.debug("@@ Queued runnable = " + runnable);
      myRequests.notify();
      return true;
    }
    else {
      return false;
    }
  }

  public void queueRequestAndWait(Runnable runnable) {
    if (Thread.currentThread() == this) {
      runImmediately(runnable);
      return;
    }

    if (!queueRequest(runnable)) {
      return;
    }
    while (true) {
      synchronized (myRequests) {
        if (myRequests.indexOf(runnable) == -1) break;
      }
      synchronized (runnable) {
        try {
          runnable.wait(1000);
        }
        catch (InterruptedException e) {
        }
      }
    }
  }

  private void runImmediately(final Runnable runnable) {
    try {
      runRequest(runnable);
    }
    catch (Throwable e) {
      try {
        getWeblogicInstance().registerServerError(e);
      }
      catch (Throwable t) {
        LOG.error(t);
      }
    }
  }

  protected Runnable peekQueuedRequest() {
    synchronized (myRequests) {
      if (myRequests.size() == 0) return null;
      return myRequests.get(0);
    }
  }

  protected abstract void runRequest(Runnable request) throws PrivilegedActionException;

  public void noPoll() {
    myNoPoll = true;
  }

  public void doNotPollServer() {
    myPollServer = false;
  }

  protected WeblogicAbstractInstance getWeblogicInstance() {
    return myWeblogicAbstractInstance;
  }

  protected abstract void initialize();

  public abstract void refreshState();

  public  void run() {
    while (myPollServer || peekQueuedRequest() != null) {
      Runnable request = peekQueuedRequest();
      if (request == null) {
        request = pollServerRequest;
      }
      else {
        LOG.debug("@@ Dequeue request = " + request);
      }

      try {
        runImmediately(request);
      }
      finally {
        synchronized (myRequests) {
          myRequests.remove(request);
        }
        synchronized (request) {
          // signal runnable has been run
          request.notify();
        }
        synchronized (myRequests) {
          try {
            myRequests.wait(1000);
          }
          catch (InterruptedException e) {
          }
        }
      }
    }
  }

  private void pollServer() {
    Socket socket = null;
    final boolean connected;

    if (myNoPoll && myInitialized) {
      connected = true;
    }
    else {
      try {
        socket = new Socket(myHost,
                            myPort);
      }
      catch (IOException e) {
      }
      finally {
        if (socket != null) {
          try {
            socket.close();
          }
          catch (IOException e) {
          }
        }
      }
      connected = socket != null && socket.isConnected();
    }

    // getState() must be called from one thread, otherwise weblogic throws SecurityException
    boolean isStateChanged = false;
    if (connected && !myInitialized) {
      refreshState();
      if (!getWeblogicInstance().isConnected()) {
        return;
      }
      LOG.debug("getState() = " + getWeblogicInstance().getState());
      initialize();
      myInitialized = true;
      isStateChanged = true;
    }
    if (!connected && myInitialized) {
      getWeblogicInstance().cleanup();
      myInitialized = false;
      isStateChanged = true;
    }
    if (isStateChanged) {
      //fire listeners in another thread
      ApplicationManager.getApplication().invokeLater(new Runnable() {
        public void run() {
          if (!myProject.isOpen()) return;
          getWeblogicInstance().fireServerListeners(new WeblogicServerEvent(connected
                                                                                    ? getWeblogicInstance().getState()
                                                                                    : WeblogicServerEvent.SERVER_STATE_DISCONNECTED,
                                                                                    getWeblogicInstance().getOutputInfo()));
          DeploymentManager.getInstance(myProject).updateAllDeploymentStatus(getWeblogicInstance(), myRunConfiguration.getCommonModel());
        }
      });
    }
  }
}
