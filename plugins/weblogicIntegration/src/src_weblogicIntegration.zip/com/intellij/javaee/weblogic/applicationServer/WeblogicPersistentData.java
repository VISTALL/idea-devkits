/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.applicationServer;

import com.intellij.javaee.appServerIntegrations.ApplicationServer;
import com.intellij.javaee.appServerIntegrations.DefaultPersistentData;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegration;
import com.intellij.javaee.weblogic.beaInstallation.BeaInstallation;
import com.intellij.javaee.weblogic.beaInstallation.BeaVersion;
import com.intellij.javaee.weblogic.beaInstallation.WeblogicUtil;
import com.intellij.javaee.weblogic.runDebug.configuration.WeblogicModel;
import com.intellij.openapi.roots.OrderRootType;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.PathUtil;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

public class WeblogicPersistentData extends DefaultPersistentData {
  public String BEA_HOME = "";
  public String VERSION = "";
  private URLClassLoader myCachedClassLoader;
  private VirtualFile[] myCachedPaths;
  private File[] myCachedAdditionalPaths;
  @NonNls protected static final String WLWRAPPER_FILE = "wlWrapper";
  @NonNls protected static final String WLWRAPPER_JAR = "weblogicWrapperImpl.jar";
  @NonNls protected static final String WEBLOGIC_LOGIN_DIR = "weblogicWrapperImpl";
  @NonNls protected static final String CLASSES_DIR = "classes";

  public WeblogicPersistentData() {
    BeaInstallation[] possibleLocations = WeblogicUtil.getAllPossibleServerLocations();
    if (possibleLocations.length > 0) {
      BeaInstallation defaultLocation = possibleLocations[0];
      BEA_HOME = defaultLocation.getLocation().getAbsolutePath().replace(File.separatorChar, '/');
      BeaVersion[] versions = defaultLocation.getVersions();
      if (versions.length > 0) {
        VERSION = versions[0].getName();
      }
    }
  }

  public boolean isVersion6x() {
    return StringUtil.startsWithChar(VERSION, '6');
  }

  public boolean isVersion8x() {
    return StringUtil.startsWithChar(VERSION, '8');
  }

  public boolean isVersion9xOrLater() {
    return VERSION != null && (VERSION.startsWith("9") || VERSION.startsWith("10"));
  }

  public ClassLoader getClassLoader(CommonModel model, ClassLoader parent) throws MalformedURLException {
    final ApplicationServer server = model.getApplicationServer();
    VirtualFile[] newPaths = server.getLibrary().getFiles(OrderRootType.CLASSES);
    final File[] additionalPaths = getAdditionalPaths(model);

    if (myCachedClassLoader == null || !Comparing.equal(myCachedPaths, newPaths)
      || !Comparing.equal(myCachedAdditionalPaths, additionalPaths)) {
      myCachedPaths = newPaths;
      myCachedAdditionalPaths = additionalPaths;

      final List<URL> urls = new ArrayList<URL>();

      for (VirtualFile path : myCachedPaths) {
        final URL url = new File(path.getPresentableUrl()).toURL();
        urls.add(url);
      }
      for (File path : additionalPaths) {
        urls.add(path.toURL());
      }

      myCachedClassLoader = new WeblogicWrapperClassLoader(urls.toArray(new URL[urls.size()]), isVersion9xOrLater(), parent);
    }
    return myCachedClassLoader;
  }

  private File[] getAdditionalPaths(final CommonModel model) {
    if (!isVersion9xOrLater()) {
      File weblogicPluginClassesLocation = new File(PathUtil.getJarPathForClass(WeblogicIntegration.class));
      return new File[] {getWeblogicWrappersLocation(weblogicPluginClassesLocation)};
    }
    else {
      final BeaVersion version = ((WeblogicModel)model.getServerModel()).findVersion();
      //todo[nik] if version==null or file does not exist?
      return new File[]{
        version.getJMXClientJarFile(),
        version.getXBeanJarFile()
      };
    }
  }

  //Fix for weblogic version 7.x
  private static File getWeblogicWrappersLocation(File weblogicPluginClassesLocation) {
    if (weblogicPluginClassesLocation.isFile()) {//build
      File weblogicWrappersLocation = new File(weblogicPluginClassesLocation.getParent(), WLWRAPPER_FILE);
      return new File(weblogicWrappersLocation, WLWRAPPER_JAR);
    }
    else {//development mode
      return new File(weblogicPluginClassesLocation.getParent(), WEBLOGIC_LOGIN_DIR);
    }

  }

}