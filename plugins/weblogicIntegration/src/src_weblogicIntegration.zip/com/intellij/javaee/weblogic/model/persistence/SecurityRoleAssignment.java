// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.SubTag;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:security-role-assignmentType interface.
 */
public interface SecurityRoleAssignment extends JavaeeDomModelElement {

	/**
	 * Returns the value of the role-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:role-nameType documentation</h3>
	 * The role-nameType designates the name of a security role.
	 * 	The name must conform to the lexical rules for a token.
	 * </pre>
	 * @return the value of the role-name child.
	 */
	@NotNull
	GenericDomValue<String> getRoleName();


	/**
	 * Returns the list of principal-name children.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNMTOKENType documentation</h3>
	 * This type adds an "id" attribute to xsd:NMTOKEN.
	 * </pre>
	 * @return the list of principal-name children.
	 */
	@NotNull
	List<GenericDomValue<String>> getPrincipalNames();
	/**
	 * Adds new child to the list of principal-name children.
	 * @return created child
	 */
	GenericDomValue<String> addPrincipalName();


	/**
	 * Returns the value of the externally-defined child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:emptyType documentation</h3>
	 * This type is used to designate an empty
	 * 	element when used.
	 * </pre>
	 * @return the value of the externally-defined child.
	 */
	@SubTag (value = "externally-defined", indicator = true)
	@NotNull
	GenericDomValue<Boolean> getExternallyDefined();


}
