/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.dataSource;

import com.intellij.javaee.dataSource.DataSource;
import com.intellij.javaee.dataSource.JdbcOperation;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegration;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicAbstractInstance;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicInstance;
import com.intellij.openapi.util.Ref;
import org.jetbrains.annotations.Nullable;

import java.sql.Connection;
import java.sql.SQLException;

public class WeblogicDataSource extends DataSource {

  public WeblogicDataSource(String name) {
    setName(name);
  }

  @Nullable
  public <T> T performJdbcOperation(final J2EEServerInstance serverInstance, final Ref<String> errorMessage, final JdbcOperation<T> operation) {
    final Ref<T> result = new Ref<T>();
    ((WeblogicAbstractInstance)serverInstance).getServerPollThread().queueRequestAndWait(new Runnable() {
      public void run() {
        result.set(WeblogicDataSource.super.performJdbcOperation(serverInstance, errorMessage, operation));
      }
    });
    return result.get();
  }

  protected Connection getConnection(J2EEServerInstance serverInstance) throws Exception {
    final javax.sql.DataSource jdbcDataSource = createJDBCDataSource((WeblogicInstance)serverInstance);
    if (jdbcDataSource == null) return null;
    try {
      return jdbcDataSource.getConnection();
    }
    catch (SQLException e) {
      throw e;
    }
    catch (Exception e) {
      return null;
    }
  }

  protected String getSchemaName() {
    return null;
  }

  public void init() {
  }

  public String getSourceName() {
    return WeblogicIntegration.getInstance().getPresentableName();
  }

  @Nullable
  private javax.sql.DataSource createJDBCDataSource(final WeblogicInstance weblogicInstance){
    return !weblogicInstance.isConnected()? null : weblogicInstance.getDataSource(getName());
  }
}
