/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.jdbc;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

/**
 * @author nik
 */
public class JDBCConnectionPoolParamsWL9Bean extends AbstractWL9MBean {

  public JDBCConnectionPoolParamsWL9Bean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public void setCapacityIncrement(int capacityIncrement) {
    setAttribute("CapacityIncrement", capacityIncrement);
  }

  public void setInitialCapacity(int initialCapacity) {
    setAttribute("InitialCapacity", initialCapacity);
  }

  public void setMaxCapacity(int maxCapacity) {
    setAttribute("MaxCapacity", maxCapacity);
  }
}
