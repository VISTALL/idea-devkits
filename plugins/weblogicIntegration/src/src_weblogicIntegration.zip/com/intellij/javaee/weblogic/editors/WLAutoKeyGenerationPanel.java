/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.editors;

import com.intellij.javaee.weblogic.model.persistence.AutomaticKeyGeneration;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsBean;
import com.intellij.openapi.application.Result;
import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.util.Factory;
import com.intellij.openapi.util.Pair;
import com.intellij.ui.GuiUtils;
import com.intellij.util.Function;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.xml.DomManager;
import com.intellij.util.xml.GenericDomValue;
import com.intellij.util.xml.ui.*;
import org.jetbrains.annotations.NonNls;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * @author Alexey Kudravtsev
 */
public class WLAutoKeyGenerationPanel extends CompositeCommittable implements CommittablePanel {
  private JPanel myPanel;
  private JComboBox myGenType;
  private com.intellij.util.xml.ui.TextPanel myGenName;
  private com.intellij.util.xml.ui.TextPanel myGenKeyCacheSize;
  private JCheckBox myEnableAutoKeyGeneration;
  private AutomaticKeyGeneration myAutomaticKeyGeneration;
  private final ActionListener myEnableListener;

  public WLAutoKeyGenerationPanel(final WeblogicRdbmsBean bean) {

    @NonNls final String[] types = {"ORACLE", "SQL_SERVER", "NAMED_SEQUENCE_TABLE"};


    final DomManager domManager = bean.getManager();
    myEnableListener = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        new WriteCommandAction(domManager.getProject()) {
          protected void run(Result result) throws Throwable {
            if (myEnableAutoKeyGeneration.isSelected()) {
              myAutomaticKeyGeneration.ensureTagExists();
            }
            else {
              myAutomaticKeyGeneration.undefine();
            }
          }
        }.execute();
        reset();
      }
    };

    myAutomaticKeyGeneration = domManager.createStableValue(new Factory<AutomaticKeyGeneration>() {
      public AutomaticKeyGeneration create() {
        return bean.getAutomaticKeyGeneration();
      }
    });
    addComponent(DomUIFactory.createControl(domManager.createStableValue(new Factory<GenericDomValue<String>>() {
      public GenericDomValue<String> create() {
        return myAutomaticKeyGeneration.getGeneratorName();
      }
    }))).bind(myGenName);
    addComponent(DomUIFactory.getDomUIFactory().createTextControl(new DomStringWrapper(domManager.createStableValue(new Factory<GenericDomValue>() {
      public GenericDomValue create() {
        return myAutomaticKeyGeneration.getKeyCacheSize();
      }
    })), false)).bind(myGenKeyCacheSize);
    addComponent(new ComboControl(new DomStringWrapper(domManager.createStableValue(new Factory<GenericDomValue>() {
      public GenericDomValue create() {
        return myAutomaticKeyGeneration.getGeneratorType();
      }
    })), new Factory<List<Pair<String, Icon>>>() {
      public List<Pair<String, Icon>> create() {
        return ContainerUtil.map2List(types, new Function<String, Pair<String, Icon>>() {
          public Pair<String, Icon> fun(final String s) {
            return Pair.create(s, null);
          }
        });
      }
    })).bind(myGenType);

    reset();
  }

  public void reset() {
    myEnableAutoKeyGeneration.removeActionListener(myEnableListener);
    super.reset();
    final boolean selected = myAutomaticKeyGeneration.getXmlTag() != null;
    myEnableAutoKeyGeneration.setSelected(selected);
    GuiUtils.enableChildren(myPanel, selected, myEnableAutoKeyGeneration);
    myEnableAutoKeyGeneration.addActionListener(myEnableListener);
  }

  public JComponent getComponent() {
    return myPanel;
  }

}
