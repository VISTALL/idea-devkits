/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.configuration;

import com.intellij.execution.configurations.RuntimeConfigurationError;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.text.StringUtil;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.jetbrains.annotations.NotNull;

class WeblogicRemoteEditor extends SettingsEditor<CommonModel> {
  private JButton myTestConnectionButton;
  private JPanel myPanel;
  private JPasswordField myPassword;
  private JTextField myUser;
  private JTextField myServerField;
  private JLabel myServerLabel;

  public WeblogicRemoteEditor() {
    myTestConnectionButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        testConnection();
      }
    });
  }

  public void applyEditorTo(CommonModel configuration) throws ConfigurationException {
    WeblogicModel wl = ((WeblogicModel)configuration.getServerModel());
    wl.USER = myUser.getText();
    wl.PASSWORD = new String(myPassword.getPassword());
    wl.SERVER_NAME = myServerField.getText();
  }

  public void resetEditorFrom(CommonModel configuration) {
    WeblogicModel wl = ((WeblogicModel)configuration.getServerModel());
    myUser.setText(wl.USER);
    myPassword.setText(wl.PASSWORD);
    myServerField.setText(wl.SERVER_NAME);
  }

  @NotNull
  public JComponent createEditor() {
    return myPanel;
  }

  public void disposeEditor() {
  }

  private void testConnection() {
    try {
      CommonModel config = getSnapshot();
      try {
        config.checkConfiguration();
      }
      catch (RuntimeConfigurationError e) {
        Messages.showErrorDialog(WeblogicBundle.message("message.text.remote.configuration.cannot.save.settings", e.getLocalizedMessage()),
                                 WeblogicBundle.message("message.title.remote.configuration.test.connection"));
        return;
      }
      catch (ConfigurationException e) {
        //ignore warnings
      }
      try {
        ((WeblogicModel)config.getServerModel()).testConnection();
        Messages.showInfoMessage(WeblogicBundle.message("message.text.connection.successful"), WeblogicBundle.message("message.title.remote.configuration.test.connection"));
      }
      catch (Exception e) {
        String message = adjustErrorMessage(e.getLocalizedMessage());
        Messages.showErrorDialog(WeblogicBundle.message("message.text.remote.configuration.cannot.connect", message), WeblogicBundle.message("message.title.remote.configuration.test.connection"));
      }
    }
    catch (ConfigurationException e) {
      Messages.showErrorDialog(WeblogicBundle.message("message.text.remote.configuration.cannot.save.settings", e.getLocalizedMessage()), WeblogicBundle.message("message.title.remote.configuration.test.connection"));
    }
  }

  private static String adjustErrorMessage(final String message) {
    int index = message.length() - 1;
    while (index > 0 && Character.isWhitespace(message.charAt(index))) {
      index--;
    }
    final String[] strings = message.substring(0, index + 1).split(";");

    final StringBuilder builder = new StringBuilder();
    for (String string : strings) {
      if (builder.length() > 0) {
        builder.append(";\n");
      }
      for (int i = 0; i < string.length(); i++) {
        final char c = string.charAt(i);
        if (c != '\n' && c != '\r' && c != '\t') {
          builder.append(c);
        }
      }
    }
    return builder.toString();
  }
}