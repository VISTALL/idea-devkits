/**
 * @author cdr
 */
/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.editors;

import com.intellij.javaee.J2EEBundle;
import com.intellij.javaee.model.xml.ejb.EjbRelationshipRole;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.model.persistence.*;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.util.Factory;
import com.intellij.openapi.util.Pair;
import com.intellij.util.Function;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.xml.reflect.DomGenericInfo;
import com.intellij.util.xml.ui.*;

import javax.swing.*;
import java.awt.*;
import java.util.Collections;
import java.util.List;

public class TableColumnsMappingConfigurable extends CompositeCommittable implements CommittablePanel {
  private JPanel myPanel;
  private JPanel myTablePanel;
  private JComboBox myPKTableName;
  private JComboBox myFKTableName;
  private JLabel myForeignTableNameLabel;

  private final RdbmsHelper myRdbmsHelper;

  public TableColumnsMappingConfigurable(final RdbmsHelper helper, boolean showForeignColumn) {
    myRdbmsHelper = helper;

    final RelationshipRoleMap map = helper.getRdbmsRelationRole().getRelationshipRoleMap().createStableCopy();
    addComponent(new ComboControl(map.getPrimaryKeyTable(), new Factory<List<Pair<String, Icon>>>() {
      public List<Pair<String, Icon>> create() {
        return ContainerUtil.map(getTableNames(helper.getRole()), new Function<String, Pair<String, Icon>>() {
          public Pair<String, Icon> fun(final String s) {
            return Pair.create(s, null);
          }
        });
      }
    })).bind(myPKTableName);
    if (showForeignColumn) {
      addComponent(new ComboControl(map.getForeignKeyTable(), new Factory<List<Pair<String, Icon>>>() {
        public List<Pair<String, Icon>> create() {
          return ContainerUtil.map(getTableNames(helper.getTargetRole()), new Function<String, Pair<String, Icon>>() {
            public Pair<String, Icon> fun(final String s) {
              return Pair.create(s, null);
            }
          });
        }
      })).bind(myFKTableName);
    }

    final DomTableView collectionPanel = new DomTableView(helper.getProject()) {
      protected void tuneTable(JTable table) {
        table.setRowHeight(new JComboBox().getPreferredSize().height);
      }
    };

    myTablePanel.setLayout(new BorderLayout());
    myTablePanel.add(collectionPanel);

    final DomGenericInfo info = map.getManager().getGenericInfo(ColumnMap.class);
    ComboTableCellEditor pkEditor = new ComboTableCellEditor(new Factory<List<Pair<String, Icon>>>() {
      public List<Pair<String, Icon>> create() {
        return ContainerUtil
          .map(myRdbmsHelper.getSuitableNames(myPKTableName, helper.getRole(), true), new Function<String, Pair<String, Icon>>() {
            public Pair<String, Icon> fun(final String s) {
              return Pair.create(s, null);
            }
          });
      }
    }, false);
    ComboTableCellEditor fkEditor = new ComboTableCellEditor(new Factory<List<Pair<String, Icon>>>() {
      public List<Pair<String, Icon>> create() {
        return ContainerUtil
          .map(myRdbmsHelper.getSuitableNames(myFKTableName, helper.getTargetRole(), true), new Function<String, Pair<String, Icon>>() {
            public Pair<String, Icon> fun(final String s) {
              return Pair.create(s, null);
            }
          });
      }
    }, false);


    final DomCollectionControl control = new DomCollectionControl<ColumnMap>(
      map, "column-map", false,
      new ChildGenericValueColumnInfo<ColumnMap>(J2EEBundle.message("table.column.mappings.editor.pk.column.column.name"),
                                                 info.getFixedChildDescription("key-column"), pkEditor),
      new ChildGenericValueColumnInfo<ColumnMap>(J2EEBundle.message("table.column.mappings.editor.fk.column.column.name"),
                                                 info.getFixedChildDescription("foreign-key-column"), fkEditor)) {

      protected AnAction[] createAdditionActions() {
        return new AnAction[]{new ControlAddAction(WeblogicBundle.message("action.name.add.mapping")) {

          protected void tuneNewValue(final ColumnMap columnMap) {
            columnMap.getKeyColumn().setValue(WeblogicBundle.message("column.name.create.mapping.pk.column"));
            columnMap.getForeignKeyColumn().setValue(WeblogicBundle.message("column.name.create.mapping.fk.column"));
          }
        }};
      }
    };
    control.bind(collectionPanel);
    addComponent(control);

    if (!showForeignColumn) {
      myFKTableName.setVisible(false);
      myForeignTableNameLabel.setVisible(false);
    }
  }

  public WeblogicRdbmsRelation getWeblogicRdbmsRelation() {
    return myRdbmsHelper.getRdbmsRelation();
  }

  public JComponent getComponent() {
    return myPanel;
  }

  private List<String> getTableNames(EjbRelationshipRole role) {
    WeblogicRdbmsBean rdbmsBeanObject = myRdbmsHelper.getRdbmsBeanObject(role);

    if (rdbmsBeanObject == null) {
      return Collections.emptyList();
    }

    return ContainerUtil.map2List(rdbmsBeanObject.getTableMaps(), new Function<TableMap, String>() {
      public String fun(final TableMap s) {
        return s.getTableName().getValue();
      }
    });
  }

}

