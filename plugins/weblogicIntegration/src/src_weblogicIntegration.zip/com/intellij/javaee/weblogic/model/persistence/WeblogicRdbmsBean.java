// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.EntityBeanResolveConverter;
import com.intellij.javaee.model.common.ejb.EntityBean;
import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.Convert;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:weblogic-rdbms-beanType interface.
 */
public interface WeblogicRdbmsBean extends JavaeeDomModelElement {

  /**
   * Returns the value of the ejb-name child.
   * <pre>
   * <h3>Type http://java.sun.com/xml/ns/j2ee:ejb-nameType documentation</h3>
   * 	  The ejb-nameType specifies an enterprise bean's name. It is
   * 	  used by ejb-name elements. This name is assigned by the
   * 	  ejb-jar file producer to name the enterprise bean in the
   * 	  ejb-jar file's deployment descriptor. The name must be
   * 	  unique among the names of the enterprise beans in the same
   * 	  ejb-jar file.
   * 	  There is no architected relationship between the used
   * 	  ejb-name in the deployment descriptor and the JNDI name that
   * 	  the Deployer will assign to the enterprise bean's home.
   * 	  The name for an entity bean must conform to the lexical
   * 	  rules for an NMTOKEN.
   * 	  Example:
   * 	  <ejb-name>EmployeeService</ejb-name>
   *
   * </pre>
   * @return the value of the ejb-name child.
   */
  @NotNull
  @Convert(EntityBeanResolveConverter.class)
  GenericDomValue<EntityBean> getEjbName();

  @NotNull
  GenericDomValue<String> getRightDataSourceName();

  @NotNull
  GenericDomValue<String> getDataSourceName();


  /**
   * Returns the value of the data-source-jndi-name child.
   * @return the value of the data-source-jndi-name child.
   */
  @NotNull
  GenericDomValue<String> getDataSourceJndiName();


  /**
   * Returns the value of the unknown-primary-key-field child.
   * @return the value of the unknown-primary-key-field child.
   */
  UnknownPrimaryKeyField getUnknownPrimaryKeyField();


  /**
   * Returns the list of table-map children.
   * @return the list of table-map children.
   */
  @NotNull
  List<TableMap> getTableMaps();
  /**
   * Adds new child to the list of table-map children.
   * @return created child
   */
  TableMap addTableMap();


  /**
   * Returns the list of field-group children.
   * @return the list of field-group children.
   */
  List<FieldGroup> getFieldGroups();
  /**
   * Adds new child to the list of field-group children.
   * @return created child
   */
  FieldGroup addFieldGroup();


  /**
   * Returns the list of relationship-caching children.
   * @return the list of relationship-caching children.
   */
  List<RelationshipCaching> getRelationshipCachings();
  /**
   * Adds new child to the list of relationship-caching children.
   * @return created child
   */
  RelationshipCaching addRelationshipCaching();


  /**
   * Returns the list of sql-shape children.
   * @return the list of sql-shape children.
   */
  List<SqlShape> getSqlShapes();
  /**
   * Adds new child to the list of sql-shape children.
   * @return created child
   */
  SqlShape addSqlShape();


  /**
   * Returns the list of weblogic-query children.
   * @return the list of weblogic-query children.
   */
  List<WeblogicQuery> getWeblogicQueries();
  /**
   * Adds new child to the list of weblogic-query children.
   * @return created child
   */
  WeblogicQuery addWeblogicQuery();


  /**
   * Returns the value of the delay-database-insert-until child.
   * @return the value of the delay-database-insert-until child.
   */
  GenericDomValue<String> getDelayDatabaseInsertUntil();


  /**
   * Returns the value of the use-select-for-update child.
   * <pre>
   * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
   * This simple type designates a boolean with permissible values
   *   - true/false
   *   - yes/no
   *   - 1/0
   * </pre>
   * @return the value of the use-select-for-update child.
   */
  GenericDomValue<Boolean> getUseSelectForUpdate();


  /**
   * Returns the value of the lock-order child.
   * <pre>
   * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNonNegativeIntegerType documentation</h3>
   * This type adds an "id" attribute to xsd:nonNegativeInteger.
   * </pre>
   * @return the value of the lock-order child.
   */
  GenericDomValue<Integer> getLockOrder();


  /**
   * Returns the value of the instance-lock-order child.
   * @return the value of the instance-lock-order child.
   */
  GenericDomValue<String> getInstanceLockOrder();


  /**
   * Returns the value of the automatic-key-generation child.
   * @return the value of the automatic-key-generation child.
   */
  AutomaticKeyGeneration getAutomaticKeyGeneration();


  /**
   * Returns the value of the check-exists-on-method child.
   * <pre>
   * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
   * This simple type designates a boolean with permissible values
   *   - true/false
   *   - yes/no
   *   - 1/0
   * </pre>
   * @return the value of the check-exists-on-method child.
   */
  GenericDomValue<Boolean> getCheckExistsOnMethod();


  /**
   * Returns the value of the cluster-invalidation-disabled child.
   * <pre>
   * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
   * This simple type designates a boolean with permissible values
   *   - true/false
   *   - yes/no
   *   - 1/0
   * </pre>
   * @return the value of the cluster-invalidation-disabled child.
   */
  GenericDomValue<Boolean> getClusterInvalidationDisabled();


}
