/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.beaInstallation;

import com.intellij.javaee.weblogic.WeblogicBundle;

import java.io.File;

import org.jetbrains.annotations.Nullable;

public class BeaInstallation {
  private final File myLocation;
  private final BeaVersion[] myVersions;
  private BeaDomain[] myDomains;

  public BeaInstallation(File location) {
    myLocation = location;
    myVersions = WeblogicUtil.loadVersions(myLocation);
  }

  public String toString() {
    return myLocation.getAbsolutePath();
  }

  public boolean equals(Object o) {
    if (!(o instanceof BeaInstallation)) {
      return false;
    }
    return myLocation.equals(((BeaInstallation)o).myLocation);
  }

  public int hashCode() {
    return myLocation.hashCode();
  }

  public File getLocation() {
    return myLocation;
  }

  public BeaVersion[] getVersions() {
    return myVersions;
  }

  public boolean isValid() {
    return myVersions.length > 0;
  }

  public String getInvalidityReason() {
    if (isValid()) {
      return null;
    }
    if (!myLocation.isDirectory()) {
      return WeblogicBundle.message("message.text.label.weblogic.server.configuration.file.is.not.directory", myLocation.getAbsolutePath());
    }
    return WeblogicBundle.message("message.text.weblogic.server.configuration.directory.is.not.bea.home", myLocation.getAbsolutePath());
  }

  public BeaDomain[] getDomains() {
    if (myDomains == null) {
      myDomains = loadDomains();
    }
    return myDomains;
  }

  private BeaDomain[] loadDomains() {
    if (!isValid()) {
      return BeaDomain.EMPTY_ARRAY;
    }
    return WeblogicUtil.loadDomains(myLocation);
  }

  public @Nullable BeaVersion findVersionByName(String version) {
    for (BeaVersion beaVersion : myVersions) {
      if (beaVersion.getName().startsWith(version)) {
        return beaVersion;
      }
    }
    return null;
  }

}