/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.deployment;

import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.actions.WeblogicMissingDatasourcesDialog;
import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegration;
import com.intellij.javaee.weblogic.applicationServer.WeblogicDeploymentSettingsEditor;
import com.intellij.javaee.weblogic.beaInstallation.WeblogicUtil;
import com.intellij.javaee.weblogic.module.WLEjbModuleProperties;
import com.intellij.javaee.weblogic.module.WeblogicModulePropertiesBase;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.LogNotificationListener;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicInstance;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.versionsBefore9.WeblogicVersionBefore9AbstractInstance;
import com.intellij.j2ee.wrappers.WebLogicLogNotification;
import com.intellij.javaee.deployment.DeploymentMethod;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentProvider;
import com.intellij.javaee.model.common.ejb.EnterpriseBean;
import com.intellij.javaee.model.common.ejb.EntityBean;
import com.intellij.javaee.module.components.EjbModuleProperties;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsBean;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleType;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Comparing;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class WeblogicDeploymentProvider implements DeploymentProvider {

  public void doDeploy(final Project project, final J2EEServerInstance weblogicInstance, final DeploymentModel model) {
    ApplicationManager.getApplication().runReadAction(new Runnable() {
      public void run() {
        WLDeploymentModel wlDeploymentModel = (WLDeploymentModel)model;
        if (!wlDeploymentModel.CHECK_EJB_CMP_DATASOURCES || checkAndConfigureDatasources(project, weblogicInstance, model)) {
          invokeDeployOnInstance(weblogicInstance, model);
        }
      }
    });
  }

  public DeploymentModel createNewDeploymentModel(CommonModel configuration,
                                                  JavaeeModuleProperties j2eeModuleProperties) {
    return new WLDeploymentModel(configuration, j2eeModuleProperties);
  }

  private static boolean checkAndConfigureDatasources(final Project project,
                                                      final J2EEServerInstance weblogicInstance,
                                                      final DeploymentModel model) {
    final List<EjbModuleProperties> ejbModules = new ArrayList<EjbModuleProperties>();
    final JavaeeModuleProperties moduleProperties = model.getModuleProperties();
    if (ModuleType.J2EE_APPLICATION.equals(moduleProperties.getModule().getModuleType())) {
      Module[] containingModules = moduleProperties.getContainingIdeaModules();
      for (Module childModule : containingModules) {
        JavaeeModuleProperties childModuleProperties = JavaeeModuleProperties.getInstance(childModule);
        if (ModuleType.EJB.equals(childModuleProperties.getModule().getModuleType())) {
          ejbModules.add((EjbModuleProperties)childModuleProperties);
        }
      }
    }
    else if (ModuleType.EJB.equals(moduleProperties.getModule().getModuleType())) {
      ejbModules.add((EjbModuleProperties)moduleProperties);
    }
    else {
      return true;
    }
    final List<EnterpriseBean> missingDatasourceEjbs = new ArrayList<EnterpriseBean>();
    final List<WLEjbModuleProperties> ejbModulesAffected = new ArrayList<WLEjbModuleProperties>();
    // find out missing data sources
    for (final EjbModuleProperties rootDescriptor : ejbModules) {
      for (final EntityBean ejb : rootDescriptor.getMergedRoot().getEnterpriseBeans().getEntities()) {
        WLEjbModuleProperties module = (WLEjbModuleProperties)WeblogicModulePropertiesBase.getInstance(rootDescriptor.getModule());
        final WeblogicRdbmsBean rdbmsBean = WeblogicUtil.findRdbmsBean(module.getRdbmsRoot(), ejb.getEjbName().getValue());
        if (rdbmsBean == null) {
          continue;
        }
        final String dataSourceName = rdbmsBean.getDataSourceName().getValue();
        if (!"".equals(dataSourceName) && !isDatasourceConfigured((WeblogicInstance)weblogicInstance, dataSourceName)) {
          missingDatasourceEjbs.add(ejb);
          ejbModulesAffected.add(module);
        }
      }
    }

    if (missingDatasourceEjbs.size() != 0) {
      ApplicationManager.getApplication().invokeLater(new Runnable() {
        public void run() {
          final WeblogicMissingDatasourcesDialog dialog = new WeblogicMissingDatasourcesDialog(project, missingDatasourceEjbs,
                                                                                               (WeblogicInstance)weblogicInstance,
                                                                                               ejbModulesAffected);
          dialog.show();
          if (dialog.isOK()) {
            invokeDeployOnInstance(weblogicInstance, model);
          }
        }
      });
      return false;
    }
    return true;
  }

  private static boolean isDatasourceConfigured(WeblogicInstance weblogicInstance, String dataSourceName) {
    final String[] dataSourceNames = weblogicInstance.getConfiguredDataSourceNames();
    for (String name : dataSourceNames) {
      if (Comparing.strEqual(name, dataSourceName)) return true;
    }
    return false;
  }


  private static void invokeDeployOnInstance(final J2EEServerInstance weblogicInstance, DeploymentModel model) {
    try {
      ((WeblogicInstance)weblogicInstance).startDeploy(model);
    }
    catch (final Exception e) {
      ((WeblogicVersionBefore9AbstractInstance)weblogicInstance).fireLogNotificationListeners(new LogNotificationListener.LogNotification() {
        public WebLogicLogNotification getNotification() {
          return ((WeblogicInstance)weblogicInstance).createWebLogicLogNotification(new Date(), null, 0, 0,
                                                                                    WeblogicBundle.message("message.text.error.occurred.during.deployment"),
                                                                                    this, e);
        }
      });
    }
  }

  public String getHelpId() {
    return "webLogic.deployment";
  }

  public DeploymentMethod[] getAvailableMethods() {
    return WeblogicIntegration.AVAILABLE_DEPLOYMENT_METHODS;
  }

  public SettingsEditor<DeploymentModel> createAdditionalDeploymentSettingsEditor(final CommonModel configuration,
                                                                                  final JavaeeModuleProperties moduleProperties) {
    return new WeblogicDeploymentSettingsEditor(configuration, moduleProperties);
  }

  public void startUndeploy(J2EEServerInstance activeInstance, DeploymentModel model) {
    ((WeblogicInstance)activeInstance).startUndeploy(model);
  }

  public void updateDeploymentStatus(J2EEServerInstance instance, DeploymentModel model) {
    ((WeblogicInstance)instance).updateDeploymentStatus(model);
  }
}
