/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

/**
 * @author nik
 */
public class AppDeploymentWL9MBean extends AbstractWL9MBean {
  public AppDeploymentWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public TargetWL9MBean[] getTargets() {
    final ObjectName[] children = getChildren("Targets");
    final TargetWL9MBean[] targets = new TargetWL9MBean[children.length];
    for (int i = 0; i < children.length; i++) {
      targets[i] = new TargetWL9MBean(getConnection(), children[i]);
    }
    return targets;
  }

  public String getName() {
    return (String)getAttribute("Name");
  }
}
