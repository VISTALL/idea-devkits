/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.module;

import com.intellij.javaee.DeploymentDescriptorMetaData;
import com.intellij.javaee.weblogic.WLFileTemplateNames;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.openapi.module.ModuleType;
import org.jetbrains.annotations.NonNls;

import java.util.Arrays;

/**
 * author: lesya
 */
public interface WLDeploymentDecriptorsConstants {
  @NonNls String WEBLOGIC_VERSION_6x = "6.x";
  @NonNls String WEBLOGIC_VERSION_7x = "7.x";
  @NonNls String WEBLOGIC_VERSION_8x = "8.x";
  @NonNls String WEBLOGIC_VERSION_9x = "9.x";

  DeploymentDescriptorMetaData WL_APPLICATION_DEPLOYMENT_DESCRIPTOR = new DeploymentDescriptorMetaData() {
    public String[] getAvailableVersions() {
      return WEBLOGIC_VERSIONS;
    }

    public String getTemplateNameAccordingToVersion(String version) {
      return APP_TEMPLATES[Arrays.asList(WEBLOGIC_VERSIONS).indexOf(version)];
    }

    public String getDefaultVersion() {
      return WEBLOGIC_VERSION_7x;
    }

    public String getDefaultFileName() {
      return "weblogic-application.xml";
    }

    public String getDefaultDirectoryName() {
      return "META-INF";
    }

    public String getTitle() {
      return WeblogicBundle.message("deploymnet.descriptor.title.application.module");
    }

    public ModuleType[] getSuitableTypes() {
      return new ModuleType[]{ModuleType.J2EE_APPLICATION};
    }

    public boolean isDescriptorOptional() {
      return false;
    }

  };
  DeploymentDescriptorMetaData WL_CMP_RDBMS_JAR_XML_DEPLOYMENT_DESCRIPTOR = new DeploymentDescriptorMetaData() {
    public String[] getAvailableVersions() {
      return WEBLOGIC_VERSIONS;
    }

    public String getTemplateNameAccordingToVersion(String version) {
      return CMP_RDBMS_TEMPLATES[Arrays.asList(WEBLOGIC_VERSIONS).indexOf(version)];
    }

    public String getDefaultVersion() {
      return WEBLOGIC_VERSION_7x;
    }

    public String getDefaultFileName() {
      return "weblogic-cmp-rdbms-jar.xml";
    }

    public String getDefaultDirectoryName() {
      return "META-INF";
    }

    public String getTitle() {
      return WeblogicBundle.message("deployment.descriptor.title.ejb.persistence");
    }

    public ModuleType[] getSuitableTypes() {
      return new ModuleType[]{ModuleType.EJB};
    }

    public boolean isDescriptorOptional() {
      return false;
    }

  };
  DeploymentDescriptorMetaData WL_EJB_JAR_DEPLOYMENT_DESCRIPTOR = new DeploymentDescriptorMetaData() {
    public String[] getAvailableVersions() {
      return WEBLOGIC_VERSIONS;
    }

    public String getTemplateNameAccordingToVersion(String version) {
      return EJB_JAR_TEMPLATES[Arrays.asList(WEBLOGIC_VERSIONS).indexOf(version)];
    }

    public String getDefaultVersion() {
      return WEBLOGIC_VERSION_7x;
    }

    public String getDefaultFileName() {
      return "weblogic-ejb-jar.xml";
    }

    public String getDefaultDirectoryName() {
      return "META-INF";
    }

    public String getTitle() {
      return WeblogicBundle.message("deployment.descriptor.title.ejb");
    }

    public ModuleType[] getSuitableTypes() {
      return new ModuleType[]{ModuleType.EJB};
    }

    public boolean isDescriptorOptional() {
      return false;
    }

  };
  DeploymentDescriptorMetaData WL_XML_DESCRIPTOR = new DeploymentDescriptorMetaData() {
    public String[] getAvailableVersions() {
      return WEBLOGIC_VERSIONS;
    }

    public String getTemplateNameAccordingToVersion(String version) {
      return WL_XML_TEMPLATES[Arrays.asList(WEBLOGIC_VERSIONS).indexOf(version)];
    }

    public String getDefaultVersion() {
      return WEBLOGIC_VERSION_7x;
    }

    public String getDefaultFileName() {
      return "weblogic.xml";
    }

    public String getDefaultDirectoryName() {
      return "WEB-INF";
    }

    public String getTitle() {
      return WeblogicBundle.message("deployment.descriptor.title.web.module");
    }

    public ModuleType[] getSuitableTypes() {
      return new ModuleType[]{ModuleType.WEB};
    }

    public boolean isDescriptorOptional() {
      return false;
    }

  };

  String[] WEBLOGIC_VERSIONS = new String[]{WEBLOGIC_VERSION_6x,
                                            WEBLOGIC_VERSION_7x,
                                            WEBLOGIC_VERSION_8x,
                                            WEBLOGIC_VERSION_9x};

  String[] APP_TEMPLATES = new String[]{WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_6x,
                                        WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_7x,
                                        WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_8x,
                                        WLFileTemplateNames.WEBLOGIC_APPLICATION_XML_9x};

  String[] CMP_RDBMS_TEMPLATES = new String[]{WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_6X,
                                              WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_7X,
                                              WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_8X,
                                              WLFileTemplateNames.WEBLOGIC_CMP_RDBMS_9X};

  String[] EJB_JAR_TEMPLATES = new String[]{WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_6X,
                                            WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_7X,
                                            WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_8X,
                                            WLFileTemplateNames.WEBLOGIC_EJB_JAR_XML_9X};

  String[] WL_XML_TEMPLATES = new String[]{WLFileTemplateNames.WEBLOGIC_XML_6X,
                                           WLFileTemplateNames.WEBLOGIC_XML_7X,
                                           WLFileTemplateNames.WEBLOGIC_XML_8X,
                                           WLFileTemplateNames.WEBLOGIC_XML_9X};
}
