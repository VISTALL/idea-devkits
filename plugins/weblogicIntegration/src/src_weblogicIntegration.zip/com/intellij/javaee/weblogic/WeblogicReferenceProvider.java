/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic;

import com.intellij.javaee.JavaeeDeleteHandler;
import com.intellij.javaee.UserResponse;
import com.intellij.javaee.model.common.JavaeeModelElement;
import com.intellij.javaee.model.common.ejb.EnterpriseBean;
import com.intellij.javaee.model.common.ejb.EntityBean;
import com.intellij.javaee.weblogic.model.WeblogicEjbJar;
import com.intellij.javaee.weblogic.model.WeblogicEnterpriseBean;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsBean;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsJar;
import com.intellij.javaee.weblogic.module.WLEjbModuleProperties;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.util.IncorrectOperationException;

/**
 * @author peter
 */
public class WeblogicReferenceProvider extends JavaeeDeleteHandler {

  public void onDelete(JavaeeModelElement element, UserResponse response) throws IncorrectOperationException {
    if (element instanceof EnterpriseBean) {
      final EnterpriseBean ejb = (EnterpriseBean)element;
      final String name = ejb.getEjbName().getValue();
      if (!StringUtil.isEmpty(name)) {
        final WLEjbModuleProperties moduleProperties = WLEjbModuleProperties.getInstance(ejb.getModule());
        final WeblogicEjbJar weblogicEjbJar = moduleProperties.getEjbRoot();
        if (weblogicEjbJar != null) {
          for (final WeblogicEnterpriseBean bean : weblogicEjbJar.getWeblogicEnterpriseBeans()) {
            if (ejb.equals(bean.getEjbName().getValue())) {
              bean.undefine();
            }
          }
        }
        if (ejb instanceof EntityBean) {
          final WeblogicRdbmsJar weblogicRdbmsJar = moduleProperties.getRdbmsRoot();
          if (weblogicRdbmsJar != null) {
            for (final WeblogicRdbmsBean bean : weblogicRdbmsJar.getWeblogicRdbmsBeans()) {
              if (ejb.equals(bean.getEjbName().getValue())) {
                bean.undefine();
              }
            }
          }
        }
      }
    }
  }

}
