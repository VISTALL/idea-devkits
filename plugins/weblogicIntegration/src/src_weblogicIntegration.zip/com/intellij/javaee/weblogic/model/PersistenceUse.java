// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:persistence-useType interface.
 */
public interface PersistenceUse extends JavaeeDomModelElement {

	/**
	 * Returns the value of the type-identifier child.
	 * @return the value of the type-identifier child.
	 */
	@NotNull
	GenericDomValue<String> getTypeIdentifier();


	/**
	 * Returns the value of the type-version child.
	 * @return the value of the type-version child.
	 */
	@NotNull
	GenericDomValue<String> getTypeVersion();


	/**
	 * Returns the value of the type-storage child.
	 * @return the value of the type-storage child.
	 */
	@NotNull
	GenericDomValue<String> getTypeStorage();


}
