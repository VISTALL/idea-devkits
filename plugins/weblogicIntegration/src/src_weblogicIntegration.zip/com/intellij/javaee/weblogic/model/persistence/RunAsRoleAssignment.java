// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:run-as-role-assignmentType interface.
 */
public interface RunAsRoleAssignment extends JavaeeDomModelElement {

	/**
	 * Returns the value of the role-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:role-nameType documentation</h3>
	 * The role-nameType designates the name of a security role.
	 * 	The name must conform to the lexical rules for a token.
	 * </pre>
	 * @return the value of the role-name child.
	 */
	@NotNull
	GenericDomValue<String> getRoleName();


	/**
	 * Returns the value of the run-as-principal-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdNMTOKENType documentation</h3>
	 * This type adds an "id" attribute to xsd:NMTOKEN.
	 * </pre>
	 * @return the value of the run-as-principal-name child.
	 */
	@NotNull
	GenericDomValue<String> getRunAsPrincipalName();


}
