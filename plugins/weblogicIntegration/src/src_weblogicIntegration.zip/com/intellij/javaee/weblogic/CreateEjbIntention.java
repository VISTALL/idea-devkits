/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic;

import com.intellij.codeInsight.intention.IntentionAction;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.actionSystem.ActionGroup;
import com.intellij.openapi.ui.popup.JBPopupFactory;
import com.intellij.psi.PsiFile;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import com.intellij.util.IncorrectOperationException;
import com.intellij.util.xml.DomManager;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.DomFileElement;
import com.intellij.javaee.weblogic.model.WeblogicEjbJar;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsJar;
import com.intellij.javaee.ejb.EjbHelper;
import com.intellij.javaee.ejb.EjbModuleUtil;
import com.intellij.ide.DataManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * @author peter
 */
public class CreateEjbIntention implements IntentionAction {
  @NotNull
  public String getText() {
    return WeblogicBundle.message("intention.text.create.ejb");
  }

  @NotNull
  public String getFamilyName() {
    return getText();
  }

  public boolean isAvailable(Project project, Editor editor, PsiFile file) {
    if (!(file instanceof XmlFile)) return false;

    final DomFileElement<DomElement> element = DomManager.getDomManager(project).getFileElement((XmlFile)file);
    if (element != null) {
      final DomElement domElement = element.getRootElement();
      if (domElement instanceof WeblogicEjbJar || domElement instanceof WeblogicRdbmsJar) {
        final XmlTag tag = domElement.getXmlTag();
        return tag != null && tag.getTextRange().contains(editor.getCaretModel().getOffset());
      }
    }
    return false;
  }

  public void invoke(Project project, Editor editor, PsiFile file) throws IncorrectOperationException {
    final ActionGroup group = EjbHelper.getEjbHelper().createAddEjbActionGroup(EjbModuleUtil.getEjbFacet(file));
    final JComponent component = editor.getComponent();
    JBPopupFactory.getInstance().createActionGroupPopup(null, group, DataManager.getInstance().getDataContext(component), JBPopupFactory.ActionSelectionAid.NUMBERING, true).showInCenterOf(
      component);
  }

  public boolean startInWriteAction() {
    return false;
  }
}
