/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.configuration;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.runners.ProgramRunner;
import com.intellij.execution.util.EnvironmentVariable;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.run.localRun.*;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.beaInstallation.BeaDomain;
import com.intellij.javaee.weblogic.beaInstallation.BeaServer;
import com.intellij.javaee.weblogic.beaInstallation.BeaVersion;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.projectRoots.Sdk;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.util.SystemInfo;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.util.SystemProperties;
import org.jetbrains.annotations.NonNls;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WeblogicStartupPolicy implements ExecutableObjectStartupPolicy {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.weblogic.runDebug.configuration.WeblogicStartupPolicy");
  @NonNls private static final String SERVER_NAME_VARIABLE = "SERVER_NAME";
  @NonNls private static final String JAVA_OPTIONS_VARIABLE = "JAVA_OPTIONS";

  public EnvironmentHelper getEnvironmentHelper() {
    return new EnvironmentHelper() {
      public String getDefaultJavaVmEnvVariableName(CommonModel model) {
        return JAVA_OPTIONS_VARIABLE;
      }


      public List<EnvironmentVariable> getAdditionalEnvironmentVariables(CommonModel model) {
        WeblogicModel weblogicModel = (WeblogicModel)model.getServerModel();
        final ArrayList<EnvironmentVariable> variables = new ArrayList<EnvironmentVariable>();
        if (!weblogicModel.isVersion9OrLater()) {
          variables.add(new EnvironmentVariable(SERVER_NAME_VARIABLE, weblogicModel.SERVER_NAME, true));
        }
        return variables;
      }
    };
  }

  public ScriptHelper createStartupScriptHelper(final ProgramRunner runner) {
    return new ScriptHelper() {
      public ExecutableObject getDefaultScript(CommonModel model) {
        WeblogicModel weblogicModel = (WeblogicModel)model.getServerModel();
        final File serverStartupScript = weblogicModel.createDomain().getServerStartupScript();
        if (weblogicModel.isVersion9OrLater()) {
          return new CommandLineExecutableObject(new String[]{serverStartupScript.getAbsolutePath()}, null);
        }
        else {
          return new WebLogicScriptExecutableObject(serverStartupScript);
        }
      }
    };
  }

  private static String createStartupScriptText(final File serverStartupScript) throws ExecutionException {
    if (!serverStartupScript.exists()) {
      throw new ExecutionException(WeblogicBundle.message("error.startup.script.not.found", serverStartupScript.getAbsolutePath()));
    }

    BufferedReader reader = null;
    try {
      reader = new BufferedReader(new FileReader(serverStartupScript));
      final StringBuilder builder = new StringBuilder();
      while (true) {
        String line = reader.readLine();
        if (line == null) break;

        final int index = line.indexOf(JAVA_OPTIONS_VARIABLE + "=");
        if (index != -1 && line.indexOf(JAVA_OPTIONS_VARIABLE, index + 1) == -1) {
          final StringBuffer buffer = new StringBuffer(line);
          buffer.append(' ');
          ScriptUtil.appendEnvVariableReference(JAVA_OPTIONS_VARIABLE, buffer);
          line = buffer.toString();
        }

        if (!line.contains(SERVER_NAME_VARIABLE + "=")) {
          builder.append(line).append(SystemProperties.getLineSeparator());
        }
      }

      return builder.toString();
    }
    catch (IOException e) {
      LOG.info(e);
      throw new ExecutionException(WeblogicBundle.message("error.cannot.create.startup.script", e.getMessage()));
    }
    finally {
      if (reader != null) {
        try {
          reader.close();
        }
        catch (IOException e) {
          LOG.info(e);
          throw new ExecutionException(WeblogicBundle.message("error.cannot.create.startup.script", e.getMessage()));
        }
      }
    }
  }


  public ScriptHelper createShutdownScriptHelper(final ProgramRunner runner) {
    return new ScriptHelper() {
      @SuppressWarnings({"HardCodedStringLiteral"})
      public ExecutableObject getDefaultScript(CommonModel model) {
        WeblogicModel weblogicModel = (WeblogicModel)model.getServerModel();
        final BeaServer server = getAdminServerConfiguration(weblogicModel);

        BeaVersion version = weblogicModel.findVersion();
        if (version == null) {
          return null;
        }

        StringBuffer result = new StringBuffer();
        // TODO: how this code will behave under Linux and Mac?
        if (SystemInfo.isWindows) {
          result.append("@echo off\n");
          result.append("SETLOCAL\n");
        }
        String wlHome = version.getInstallDir();
        String javaHome = version.getJavaHome();
        if (javaHome == null) {
          Sdk projectJdk = ProjectRootManager.getInstance(model.getProject()).getProjectJdk();
          if (projectJdk == null) return null;
          javaHome = FileUtil.toSystemDependentName(projectJdk.getHomePath());
        }

        ScriptUtil.appendEnvVariableDeclaration("WL_HOME", "\""+wlHome+"\"", result);
        ScriptUtil.appendEnvVariableDeclaration("JAVA_HOME", "\""+ javaHome +"\"", result);
        ScriptUtil.appendEnvVariableDeclaration("CLASSPATH", version.getJarFile().getPath(), result);
        ScriptUtil.appendEnvVariableReference("JAVA_HOME", result);
        result.append(File.separatorChar);
        result.append("bin");
        result.append(File.separatorChar);
        result.append("java weblogic.Admin -url localhost:");
        result.append(server.getPort());
        result.append(" -username ");
        result.append(weblogicModel.USER);
        result.append(" -password ");
        result.append(weblogicModel.PASSWORD);
        result.append(" FORCESHUTDOWN ");
        result.append(server.getName());
        result.append("\n");
        if (SystemInfo.isWindows) {
          result.append("ENDLOCAL");
        }

        return new ScriptExecutableObject(result.toString(), "shutdown");
      }

    };
  }

  private static BeaServer getAdminServerConfiguration(final WeblogicModel weblogicModel) {
    BeaDomain domain = weblogicModel.createDomain();
    final BeaServer server = weblogicModel.findOrGetFirstServer(domain);
    if (server.isAdmin()) {
      return server;
    }
    final BeaServer[] servers = domain.getServers();
    for (BeaServer beaServer : servers) {
      if (beaServer.isAdmin()) {
        return beaServer;
      }
    }
    return server;
  }

  public ScriptsHelper getStartupHelper() {
    return null;
  }

  public ScriptsHelper getShutdownHelper() {
    return null;
  }

  private static class WebLogicScriptExecutableObject extends ScriptExecutableObject {
    private final File myServerStartupScript;

    public WebLogicScriptExecutableObject(final File serverStartupScript) {
      super(serverStartupScript.getName(), serverStartupScript.getParentFile(), "wlstart");
      myServerStartupScript = serverStartupScript;
    }

    protected String getScript() throws ExecutionException {
      return createStartupScriptText(myServerStartupScript);
    }
  }
}