// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:work-managerType interface.
 */
public interface WorkManager extends JavaeeDomModelElement {

	/**
	 * Returns the value of the name child.
	 * @return the value of the name child.
	 */
	@NotNull
	GenericDomValue<String> getName();


	/**
	 * Returns the value of the response-time-request-class child.
	 * @return the value of the response-time-request-class child.
	 */
	@NotNull
	ResponseTimeRequestClass getResponseTimeRequestClass();


	/**
	 * Returns the value of the fair-share-request-class child.
	 * @return the value of the fair-share-request-class child.
	 */
	@NotNull
	FairShareRequestClass getFairShareRequestClass();


	/**
	 * Returns the value of the context-request-class child.
	 * @return the value of the context-request-class child.
	 */
	@NotNull
	ContextRequestClass getContextRequestClass();


	/**
	 * Returns the value of the request-class-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdStringType documentation</h3>
	 * This type adds an "id" attribute to xsd:string.
	 * </pre>
	 * @return the value of the request-class-name child.
	 */
	@NotNull
	GenericDomValue<String> getRequestClassName();


	/**
	 * Returns the value of the min-threads-constraint child.
	 * @return the value of the min-threads-constraint child.
	 */
	@NotNull
	MinThreadsConstraint getMinThreadsConstraint();


	/**
	 * Returns the value of the min-threads-constraint-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdStringType documentation</h3>
	 * This type adds an "id" attribute to xsd:string.
	 * </pre>
	 * @return the value of the min-threads-constraint-name child.
	 */
	@NotNull
	GenericDomValue<String> getMinThreadsConstraintName();


	/**
	 * Returns the value of the max-threads-constraint child.
	 * @return the value of the max-threads-constraint child.
	 */
	@NotNull
	MaxThreadsConstraint getMaxThreadsConstraint();


	/**
	 * Returns the value of the max-threads-constraint-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdStringType documentation</h3>
	 * This type adds an "id" attribute to xsd:string.
	 * </pre>
	 * @return the value of the max-threads-constraint-name child.
	 */
	@NotNull
	GenericDomValue<String> getMaxThreadsConstraintName();


	/**
	 * Returns the value of the capacity child.
	 * @return the value of the capacity child.
	 */
	@NotNull
	Capacity getCapacity();


	/**
	 * Returns the value of the capacity-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdStringType documentation</h3>
	 * This type adds an "id" attribute to xsd:string.
	 * </pre>
	 * @return the value of the capacity-name child.
	 */
	@NotNull
	GenericDomValue<String> getCapacityName();


	/**
	 * Returns the value of the work-manager-shutdown-trigger child.
	 * @return the value of the work-manager-shutdown-trigger child.
	 */
	@NotNull
	WorkManagerShutdownTrigger getWorkManagerShutdownTrigger();


	/**
	 * Returns the value of the ignore-stuck-threads child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdBooleanType documentation</h3>
	 * This type adds an "id" attribute to xsd:boolean.
	 * </pre>
	 * @return the value of the ignore-stuck-threads child.
	 */
	@NotNull
	GenericDomValue<Boolean> getIgnoreStuckThreads();


}
