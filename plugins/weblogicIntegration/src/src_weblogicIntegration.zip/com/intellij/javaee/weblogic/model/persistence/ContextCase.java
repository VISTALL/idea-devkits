// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:context-caseType interface.
 */
public interface ContextCase extends JavaeeDomModelElement {

	/**
	 * Returns the value of the request-class-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdStringType documentation</h3>
	 * This type adds an "id" attribute to xsd:string.
	 * </pre>
	 * @return the value of the request-class-name child.
	 */
	@NotNull
	GenericDomValue<String> getRequestClassName();


	/**
	 * Returns the value of the user-name child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdStringType documentation</h3>
	 * This type adds an "id" attribute to xsd:string.
	 * </pre>
	 * @return the value of the user-name child.
	 */
	@NotNull
	GenericDomValue<String> getUserName();


	/**
	 * Returns the value of the group-name child.
	 * @return the value of the group-name child.
	 */
	@NotNull
	GenericDomValue<String> getGroupName();


}
