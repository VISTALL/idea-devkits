// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

import java.util.List;

/**
 * http://www.bea.com/ns/weblogic/90:sql-queryType interface.
 */
public interface SqlQuery extends JavaeeDomModelElement {

	/**
	 * Returns the value of the sql-shape-name child.
	 * @return the value of the sql-shape-name child.
	 */
	GenericDomValue<String> getSqlShapeName();


	/**
	 * Returns the value of the sql child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdStringType documentation</h3>
	 * This type adds an "id" attribute to xsd:string.
	 * </pre>
	 * @return the value of the sql child.
	 */
	GenericDomValue<String> getSql();


	/**
	 * Returns the list of database-specific-sql children.
	 * @return the list of database-specific-sql children.
	 */
	List<DatabaseSpecificSql> getDatabaseSpecificSqls();
	/**
	 * Adds new child to the list of database-specific-sql children.
	 * @return created child
	 */
	DatabaseSpecificSql addDatabaseSpecificSql();


}
