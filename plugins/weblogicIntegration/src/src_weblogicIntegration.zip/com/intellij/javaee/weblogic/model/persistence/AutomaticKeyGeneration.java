// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model.persistence;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NotNull;

/**
 * http://www.bea.com/ns/weblogic/90:automatic-key-generationType interface.
 */
public interface AutomaticKeyGeneration extends JavaeeDomModelElement {

	/**
	 * Returns the value of the generator-type child.
	 * @return the value of the generator-type child.
	 */
	@NotNull
	GenericDomValue<String> getGeneratorType();


	/**
	 * Returns the value of the generator-name child.
	 * @return the value of the generator-name child.
	 */
	GenericDomValue<String> getGeneratorName();


	/**
	 * Returns the value of the key-cache-size child.
	 * <pre>
	 * <h3>Type http://java.sun.com/xml/ns/j2ee:xsdPositiveIntegerType documentation</h3>
	 * This type adds an "id" attribute to xsd:positiveInteger.
	 * </pre>
	 * @return the value of the key-cache-size child.
	 */
	GenericDomValue<Integer> getKeyCacheSize();


}
