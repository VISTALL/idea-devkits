/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime;

import org.jetbrains.annotations.NonNls;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;

/**
 * @author nik
 */
public class DeploymentTaskRuntimeWL9MBean extends AbstractWL9MBean {
  @NonNls private static final String STATUS_ATTRIBUTE_NAME = "Status";
  @NonNls private static final String DEPLOYMENT_DATA_ATTRIBUTE_NAME = "DeploymentData";
  private static final MethodSignature START_SIGNATURE = new MethodSignature("start", new String[0]);

  public DeploymentTaskRuntimeWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public String getStatus() {
    return (String)getAttribute(STATUS_ATTRIBUTE_NAME);
  }

  public Object getDeploymentData() {
    return getAttribute(DEPLOYMENT_DATA_ATTRIBUTE_NAME);
  }

  public void start() {
    invoke(START_SIGNATURE);
  }
}
