/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;
import com.intellij.openapi.diagnostic.Logger;
import org.jetbrains.annotations.NonNls;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

/**
 * @author nik
 */
public class DeploymentTaskRuntimeWL9MBean extends AbstractWL9MBean {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime.DeploymentTaskRuntimeWL9MBean");
  @NonNls private static final String STATUS_ATTRIBUTE_NAME = "Status";
  @NonNls private static final String DEPLOYMENT_DATA_ATTRIBUTE_NAME = "DeploymentData";
  private static final MethodSignature START_SIGNATURE = new MethodSignature("start", new String[0]);
  private static final int WAIT_FOR_DELAY = 500;
  private static final int WAIT_FOR_TIMEOUT = 10*1000;

  public DeploymentTaskRuntimeWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public String getStatus() {
    return (String)getAttribute(STATUS_ATTRIBUTE_NAME);
  }

  public Boolean isRunning() {
    return (Boolean)getAttribute("Running");
  }

  public Object getDeploymentData() {
    return getAttribute(DEPLOYMENT_DATA_ATTRIBUTE_NAME);
  }

  public void start() {
    invoke(START_SIGNATURE);
  }

  public void waitFor() {
    LOG.debug("DeploymentTaskRuntimeMBean.waitFor");
    int time = 0;
    while (Boolean.TRUE.equals(isRunning()) && time < WAIT_FOR_TIMEOUT) {
      try {
        Thread.sleep(WAIT_FOR_DELAY);
      }
      catch (InterruptedException e) {
      }
      time += WAIT_FOR_DELAY;
    }
    if (time >= WAIT_FOR_TIMEOUT) {
      LOG.debug("DeploymentTaskRuntimeMBean.waitFor: timeout exceeded");
    }
  }
}
