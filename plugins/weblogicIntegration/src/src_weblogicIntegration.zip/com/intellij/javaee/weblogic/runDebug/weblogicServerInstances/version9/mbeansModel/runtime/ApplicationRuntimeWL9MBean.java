/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.runtime;

import org.jetbrains.annotations.NonNls;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel.AbstractWL9MBean;

/**
 * @author nik
 */
public class ApplicationRuntimeWL9MBean extends AbstractWL9MBean {
  @NonNls private static final String NAME_ATTRIBUTE_NAME = "ApplicationName";
  @NonNls private static final String COMPONENT_RUNTIMES_ATTRIBUTE_NAME = "ComponentRuntimes";

  public ApplicationRuntimeWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public String getName() {
    return (String)getAttribute(NAME_ATTRIBUTE_NAME);
  }

  public ComponentRuntimeWL9MBean[] getComponentRuntimes() {
    final ObjectName[] children = getChildren(COMPONENT_RUNTIMES_ATTRIBUTE_NAME);
    final ComponentRuntimeWL9MBean[] componentRuntimes = new ComponentRuntimeWL9MBean[children.length];
    for (int i = 0; i < children.length; i++) {
      componentRuntimes[i] = new ComponentRuntimeWL9MBean(getConnection(), children[i]);
    }
    return componentRuntimes;
  }
}
