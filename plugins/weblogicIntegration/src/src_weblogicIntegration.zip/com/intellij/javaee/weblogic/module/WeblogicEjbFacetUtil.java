/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.module;

import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.javaee.weblogic.model.WeblogicEjbJar;
import com.intellij.javaee.weblogic.model.impl.WeblogicEjbJarImpl;
import com.intellij.javaee.weblogic.model.impl.persistence.WeblogicRdbmsJarImpl;
import com.intellij.javaee.weblogic.model.persistence.WeblogicRdbmsJar;
import com.intellij.psi.xml.XmlDocument;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import com.intellij.util.descriptors.ConfigFile;
import com.intellij.util.xml.DomFileElement;
import com.intellij.util.xml.DomManager;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author Alexey Kudravtsev
 */
public class WeblogicEjbFacetUtil {
  private static final @NonNls String WL9_NAMESPACE = "http://www.bea.com/ns/weblogic/90";

  private WeblogicEjbFacetUtil() {
  }

  public static boolean isVersion9x(@Nullable EjbFacet ejbFacet) {
    if (ejbFacet != null) {
      final ConfigFile descriptor = getCmpRdbmsDescriptor(ejbFacet);
      if (descriptor != null) {
        final XmlFile xmlFile = descriptor.getXmlFile();
        if (xmlFile != null) {
          return isVersion9x(xmlFile);
        }
      }
    }
    return false;
  }

  public static boolean isVersion9x(final XmlFile xmlFile) {
    final XmlDocument document = xmlFile.getDocument();
    if (document == null) {
      return false;
    }

    final XmlTag rootTag = document.getRootTag();
    return rootTag != null && WL9_NAMESPACE.equals(rootTag.getNamespace());
  }

  @Nullable
  public static ConfigFile getEjbJarDeploymentDescriptor(@NotNull EjbFacet ejbFacet) {
    return ejbFacet.getDescriptorsContainer().getConfigFile(WLDeploymentDecriptorsConstants.WL_EJB_JAR_XML_META_DATA);
  }

  @Nullable
  public static ConfigFile getCmpRdbmsDescriptor(@NotNull EjbFacet ejbFacet) {
    return ejbFacet.getDescriptorsContainer().getConfigFile(WLDeploymentDecriptorsConstants.WL_CMP_RDMS_XML_META_DATA);
  }

  @Nullable
  public static WeblogicRdbmsJar getRdbmsRoot(@NotNull EjbFacet ejbFacet) {
    final ConfigFile descriptor = getCmpRdbmsDescriptor(ejbFacet);
    if (descriptor == null) return null;

    final XmlFile file = descriptor.getXmlFile();
    if (file == null) return null;

    final DomFileElement<WeblogicRdbmsJar> domFileElement =
      DomManager.getDomManager(file.getProject()).getFileElement(file, WeblogicRdbmsJar.class);
    if (domFileElement == null) return null;
    final WeblogicRdbmsJarImpl rdbmsJar = (WeblogicRdbmsJarImpl)domFileElement.getRootElement();
    rdbmsJar.registerDomModule(ejbFacet.getModule());
    return rdbmsJar;
  }

  @Nullable
  public static WeblogicEjbJar getEjbRoot(@NotNull EjbFacet ejbFacet) {
    final ConfigFile descriptor = getEjbJarDeploymentDescriptor(ejbFacet);
    if (descriptor == null) return null;

    final XmlFile file = descriptor.getXmlFile();
    if (file == null) return null;

    final DomFileElement<WeblogicEjbJar> domFileElement =
      DomManager.getDomManager(file.getProject()).getFileElement(file, WeblogicEjbJar.class);
    if (domFileElement == null) return null;
    final WeblogicEjbJarImpl weblogicEjbJar = (WeblogicEjbJarImpl)domFileElement.getRootElement();
    weblogicEjbJar.registerDomModule(ejbFacet.getModule());
    return weblogicEjbJar;
  }

}