/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.editors;

import com.intellij.javaee.dataSource.DataSource;
import com.intellij.javaee.dataSource.DataSourceManager;
import com.intellij.javaee.dataSource.DatabaseTableData;
import com.intellij.javaee.dataSource.DatabaseTableFieldData;
import com.intellij.javaee.model.common.JavaeeModelElement;
import com.intellij.javaee.model.common.ejb.EntityBean;
import com.intellij.javaee.model.xml.ejb.EjbRelation;
import com.intellij.javaee.model.xml.ejb.EjbRelationshipRole;
import com.intellij.javaee.weblogic.beaInstallation.WeblogicUtil;
import com.intellij.javaee.weblogic.model.persistence.*;
import com.intellij.javaee.weblogic.module.WLEjbModuleProperties;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.Condition;
import com.intellij.openapi.util.Pair;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class RdbmsHelper {
  private final EjbRelation myRelation;
  private final EjbRelationshipRole myRole;
  private WeblogicRdbmsRelation myRdbmsRelation;
  private WeblogicRelationshipRole myRdbmsRole;

  public RdbmsHelper(final WeblogicRdbmsRelation rdbmsRelation,
                     final WeblogicRelationshipRole rdbmsRole,
                     final EjbRelation relation,
                     final EjbRelationshipRole role) {
    myRdbmsRelation = rdbmsRelation;
    myRdbmsRole = rdbmsRole;
    myRelation = relation;
    myRole = role;
  }

  public WeblogicRdbmsRelation getRdbmsRelation() {
    return myRdbmsRelation;
  }

  public static WeblogicRdbmsRelation findRelationFor(EjbRelation relation) {
    final String name = relation.getEjbRelationName().getValue();
    if (name == null) return null;

    Module module = relation.getModule();
    WLEjbModuleProperties wlEjbModuleProperties = (WLEjbModuleProperties)WLEjbModuleProperties.getInstance(module);
    final WeblogicRdbmsJar root = wlEjbModuleProperties.getRdbmsRoot();
    if (root == null) return null;

    return ContainerUtil.find(root.getWeblogicRdbmsRelations(), new Condition<WeblogicRdbmsRelation>() {
      public boolean value(final WeblogicRdbmsRelation object) {
        return name.equals(object.getRelationName().getValue());
      }
    });
  }

  public static WeblogicRelationshipRole findRoleFor(EjbRelationshipRole role, WeblogicRdbmsRelation rdbmsRelation) {
    final String roleName = role.getEjbRelationshipRoleName().getValue();
    if (roleName == null) return null;

    return ContainerUtil.find(rdbmsRelation.getWeblogicRelationshipRoles(), new Condition<WeblogicRelationshipRole>() {
      public boolean value(final WeblogicRelationshipRole object) {
        return roleName.equals(object.getRelationshipRoleName().getValue());
      }
    });
  }

  public DatabaseTableData findTable(WeblogicRdbmsBean rdbmsBeanObject, String s) {
    String dataSourceName = rdbmsBeanObject.getRightDataSourceName().getValue();
    DataSource dataSource = DataSourceManager.getInstance(getProject()).getDataSourceByName(dataSourceName);
    if (dataSource == null) {
      return null;
    }

    if (!Comparing.equal(s, "")) {
      return dataSource.findTableByName(s);
    }

    List<TableMap> tableMaps = rdbmsBeanObject.getTableMaps();

    if (tableMaps.isEmpty()) {
      return null;
    }

    if (tableMaps.size() == 1) {
      return dataSource.findTableByName(tableMaps.get(0).getTableName().getValue());
    }

    return null;
  }

  @Nullable
  public WeblogicRdbmsBean getRdbmsBeanObject(EjbRelationshipRole role) {
    if (role == null) {
      return null;
    }

    final GenericDomValue<EntityBean> reference = role.getRelationshipRoleSource().getEntityBean();
    if (reference.getValue() == null) {
      return null;
    }

    return WeblogicUtil.findRdbmsBean(getRdbmsRootDescriptor(myRelation), reference.getStringValue());

  }

  public void createMapIfNecessary() {
    if (myRdbmsRelation == null) {
      myRdbmsRelation = getRdbmsRootDescriptor(myRelation).addWeblogicRdbmsRelation();
      myRdbmsRelation.getRelationName().setValue(myRelation.getEjbRelationName().getValue());
    }

    if (myRdbmsRole == null) {
      myRdbmsRole = myRdbmsRelation.addWeblogicRelationshipRole();
      myRdbmsRole.getRelationshipRoleName().setValue(myRole.getEjbRelationshipRoleName().getValue());
    }

    myRdbmsRole.getRelationshipRoleMap().ensureTagExists();
  }

  public List<String> getSuitableNames(JComboBox pkTableName, EjbRelationshipRole role, boolean isPrimary) {
    ArrayList<String> result = new ArrayList<String>();

    if (myRdbmsRelation == null) {
      return result;
    }

    WeblogicRdbmsBean rdbmsBeanObject = getRdbmsBeanObject(role);

    if (rdbmsBeanObject != null) {
      String joinTableName = myRdbmsRelation.getTableName().getValue();

      DatabaseTableData table = findTable(rdbmsBeanObject, !isPrimary && (joinTableName != null)
                                                           ? joinTableName
                                                           : ((Pair<String, Icon>)pkTableName.getEditor().getItem()).first);

      if (table != null) {
        for (final DatabaseTableFieldData field : table.getFields()) {
          if (field.isPrimary() == isPrimary) {
            result.add(field.getName());
          }
        }
      }
    }

    return result;
  }

  private static WeblogicRdbmsJar getRdbmsRootDescriptor(JavaeeModelElement object) {
    return ((WLEjbModuleProperties)WLEjbModuleProperties.getInstance(object.getModule())).getRdbmsRoot();
  }

  public Project getProject() {
    return getModule().getProject();
  }

  private Module getModule() {
    return myRelation.getModule();
  }

  public EjbRelationshipRole getTargetRole() {
    EjbRelation relation = (EjbRelation)myRole.getParent();
    final EjbRelationshipRole role1 = relation.getEjbRelationshipRole1();
    return role1.equals(myRole) ? relation.getEjbRelationshipRole2() : role1;
  }

  public EjbRelationshipRole getRole() {
    return myRole;
  }

  public WeblogicRelationshipRole getRdbmsRelationRole() {
    return myRdbmsRole;
  }

  public static List<String> getAllAvailableTableNames(EjbRelation relation) {
    ArrayList<String> result = new ArrayList<String>();

    WeblogicRdbmsJar rdbmsRootDescriptor = getRdbmsRootDescriptor(relation);
    DataSourceManager dataSourceManager = DataSourceManager.getInstance(relation.getManager().getProject());
    processRole(rdbmsRootDescriptor, relation.getEjbRelationshipRole1(), dataSourceManager, result);
    processRole(rdbmsRootDescriptor, relation.getEjbRelationshipRole2(), dataSourceManager, result);
    return result;
  }

  private static void processRole(final WeblogicRdbmsJar rdbmsRootDescriptor,
                                  final EjbRelationshipRole ejbRelationRole,
                                  final DataSourceManager dataSourceManager,
                                  final ArrayList<String> result) {
    final String ejbName = ejbRelationRole.getRelationshipRoleSource().getEntityBean().getStringValue();
    if (ejbName == null) return;

    WeblogicRdbmsBean rdbmsBean = WeblogicUtil.findRdbmsBean(rdbmsRootDescriptor, ejbName);
    if (rdbmsBean != null) {
      String dataSourceName = rdbmsBean.getRightDataSourceName().getValue();
      if (dataSourceName != null) {
        DataSource dataSource = dataSourceManager.getDataSourceByName(dataSourceName);
        if (dataSource != null) {
          for (final DatabaseTableData table : dataSource.getTables()) {
            String name = table.getName();
            if (!result.contains(name)) {
              result.add(name);
            }
          }
        }
      }
    }
  }

}