/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.actions.versionsBefore9;

import com.intellij.javaee.weblogic.WeblogicConnectionPoolInfo;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.actions.WeblogicCreateDatasourceDialog;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.ui.IdeBorderFactory;

import javax.swing.*;
import java.awt.*;

class WeblogicCreateConnectionPoolDialog extends DialogWrapper {
  private JTextField myName;
  private JTextField myUrl;
  private JTextField myDriverClassname;
  private JTextArea myProperties;
  private JTextField myMaxCapacity;
  private JTextField myInitialCapacity;
  private JTextField myCapacityIncrement;


  public WeblogicCreateConnectionPoolDialog(Project project) {
    super(project, false);
    init();
    setTitle(WeblogicBundle.message("dialog.title.create.connection.pool"));
  }

  protected JComponent createNorthPanel() {
    final JPanel panel = new JPanel(new BorderLayout());
    panel.add(new JLabel(WeblogicBundle.message("label.create.connection.pool.options.specify.configuration.parameters")), BorderLayout.NORTH);
    return panel;
  }

  protected JComponent createCenterPanel() {
    final JPanel panel = new JPanel();
    panel.setBorder(IdeBorderFactory.createBorder());
    final GridBagConstraints gb = new GridBagConstraints();
    panel.setLayout(new GridBagLayout());
    gb.fill = GridBagConstraints.BOTH;
    gb.anchor = GridBagConstraints.NORTHWEST;
    gb.gridy = -1;
    gb.gridx = 0;
    gb.insets = new Insets(4, 8, 4, 8);
    JLabel label;

    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 0;
    label = new JLabel(WeblogicBundle.message("label.create.connection.pool.options.name"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    myName = new JTextField();
    label.setLabelFor(myName);
    panel.add(myName, gb);


    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 0;
    label = new JLabel(WeblogicBundle.message("label.create.connection.pool.options.database.url"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    myUrl = new JTextField();
    label.setLabelFor(myUrl);
    panel.add(myUrl, gb);

    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 0;
    label = new JLabel(WeblogicBundle.message("label.create.connection.pool.options.driver.classname"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = 1;
    myDriverClassname = new JTextField();
    label.setLabelFor(myDriverClassname);
    panel.add(myDriverClassname, gb);

    gb.gridy++;
    gb.gridx = 0;
    gb.gridwidth = 1;
    gb.weightx = 0;
    label = new JLabel(WeblogicBundle.message("label.create.connection.pool.properties"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    myProperties= new JTextArea(3,10);
    label.setLabelFor(myProperties);
    panel.add(new JScrollPane(myProperties,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED), gb);

    gb.gridy++;
    gb.gridx = 0;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    label = new JLabel(WeblogicBundle.message("label.create.connection.pool.initial.capacity"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    myInitialCapacity = new JTextField("1");
    label.setLabelFor(myInitialCapacity);
    panel.add(myInitialCapacity, gb);

    gb.gridy++;
    gb.gridx = 0;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    label = new JLabel(WeblogicBundle.message("label.create.connection.pool.max.capacity"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    myMaxCapacity = new JTextField("1");
    label.setLabelFor(myMaxCapacity);
    panel.add(myMaxCapacity, gb);

    gb.gridy++;
    gb.gridx = 0;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    label = new JLabel(WeblogicBundle.message("label.create.connection.pool.capacity.increment"));
    panel.add(label, gb);

    gb.gridx++;
    gb.weightx = 1;
    gb.gridwidth = GridBagConstraints.REMAINDER;
    myCapacityIncrement = new JTextField("1");
    label.setLabelFor(myCapacityIncrement);
    panel.add(myCapacityIncrement, gb);


    return panel;
  }

  protected Action[] createActions() {
    return new Action[]{getOKAction(), getCancelAction()};
  }

  protected String getDimensionServiceKey() {
    return "#com.intellij.javaee.weblogic.actions.versionsBefore9.WeblogicCreateConnectionPoolDialog";
  }

  public JComponent getPreferredFocusedComponent() {
    return myName;
  }

  public WeblogicConnectionPoolInfo getConnectionPoolInfo() throws Exception {
    final WeblogicConnectionPoolInfo info = new WeblogicConnectionPoolInfo();
    info.name = myName.getText();
    info.url = myUrl.getText();
    info.driverClassname = myDriverClassname.getText();
    info.properties = WeblogicCreateDatasourceDialog.parseProperties(myProperties.getText());

    info.initialCapacity = WeblogicCreateDatasourceDialog.parseInt(myInitialCapacity.getText());
    info.maxCapacity = WeblogicCreateDatasourceDialog.parseInt(myMaxCapacity.getText());
    info.capacityIncrement = WeblogicCreateDatasourceDialog.parseInt(myCapacityIncrement.getText());

    return info;
  }

}
