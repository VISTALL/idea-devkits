/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.module;

import com.intellij.javaee.DeploymentDescriptorMetaData;
import com.intellij.javaee.JavaeeDeploymentDescriptor;
import com.intellij.javaee.JavaeeModuleListener;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.openapi.application.Result;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.startup.StartupManager;
import com.intellij.psi.xml.XmlDocument;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import com.intellij.xml.XmlElementDescriptor;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

public class WLWebModuleProperties extends WeblogicModulePropertiesBase {
  private JavaeeModuleListener myJavaeeModuleListener;
  private boolean myContextTagAdded = false;
  @NonNls private static final String CONTEXT_ROOT_TAG_NAME = "context-root";

  public WLWebModuleProperties(Module module) {
    super(module);
  }

  public void initComponent() {
    myJavaeeModuleListener = new JavaeeModuleListener() {
      public void moduleChanged(JavaeeModuleProperties moduleProperties) {
        if (moduleProperties.isDisposed()) {
          return;
        }

        final StartupManager startupManager = StartupManager.getInstance(getModule().getProject());
        startupManager.runPostStartup(new Runnable() {
          public void run() {
            // we cannt change PSI from an event... so do it later :( 
            ApplicationManager.getApplication().invokeLater(new Runnable() {
              public void run() {
                if (!myModule.isDisposed()) {
                  checkDescriptor();
                }
              }
            });
          }
        });
      }
    };
    JavaeeModuleProperties.getInstance(myModule).addModuleListener(myJavaeeModuleListener);
  }

  private synchronized void checkDescriptor() {
    final JavaeeDeploymentDescriptor descriptor = getMainDeploymentDescriptor();
    final XmlFile xmlFile = descriptor == null ? null : descriptor.getXmlFile();
    if (xmlFile == null) {
      myContextTagAdded = false;
      return;
    }
    if (!myContextTagAdded) {
      if (xmlFile.getProject().isDisposed()) return;
      addContextRootTag(xmlFile);
    }
  }

  private void addContextRootTag(final XmlFile xmlFile) {
    new WriteCommandAction(xmlFile.getProject(), xmlFile) {
      protected void run(final Result result) throws Throwable {
        final XmlDocument document = xmlFile.getDocument();
        if (document == null) return;

        final XmlTag rootTag = document.getRootTag();
        if (rootTag == null) return;

        final XmlElementDescriptor descriptor = rootTag.getDescriptor();
        if (descriptor == null) return;
        final XmlElementDescriptor[] elementsDescriptors = descriptor.getElementsDescriptors(rootTag);
        boolean found = false;
        for (XmlElementDescriptor d: elementsDescriptors) {
          final String name = d.getName();
          if (name != null && name.equals(CONTEXT_ROOT_TAG_NAME)) {
            found = true;
            break;
          }
        }
        if (!found) {
          return;
        }

        final XmlTag[] tags = rootTag.findSubTags(CONTEXT_ROOT_TAG_NAME, rootTag.getNamespace());
        if (tags.length > 0) {
          myContextTagAdded = true;
          return;
        }

        final String moduleName = myModule.getName();
        rootTag.add(rootTag.createChildTag(CONTEXT_ROOT_TAG_NAME, rootTag.getNamespace(), moduleName, false));
        myContextTagAdded = true;
      }
    }.execute();
  }

  public void disposeComponent() {
    JavaeeModuleProperties.getInstance(myModule).removeModuleListener(myJavaeeModuleListener);
  }

  protected @NotNull DeploymentDescriptorMetaData getMainDeploymentDescriptorDescription() {
    return WLDeploymentDecriptorsConstants.WL_XML_DESCRIPTOR;
  }

  @NotNull @NonNls
  public String getComponentName() {
    return "WeblogicWebModuleProperties";
  }
}
