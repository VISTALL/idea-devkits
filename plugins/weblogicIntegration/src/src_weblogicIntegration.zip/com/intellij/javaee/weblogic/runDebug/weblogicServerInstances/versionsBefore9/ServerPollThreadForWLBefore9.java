/**
 * @author cdr
 */
/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.versionsBefore9;

import com.intellij.j2ee.wrappers.*;
import com.intellij.javaee.weblogic.runDebug.configuration.WeblogicModel;
import com.intellij.javaee.weblogic.runDebug.deployment.WLDeploymentModel;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.ServerPollThread;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NonNls;

import javax.security.auth.Subject;
import java.net.URL;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * All this stuff is here thanks to weblogic feature to accept MBean access one thread per user
 */
class ServerPollThreadForWLBefore9 extends ServerPollThread {
  private static final Logger LOG = Logger.getInstance("#com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.versionsBefore9.ServerPollThreadForWLBefore9");

  private Subject mySubject;
  private Exception myLoginException;
  @NonNls private static final String APPLICATION = "Application";
  @NonNls private static final String TYPE_KEY_NAME = "Type";
  @NonNls private static final String NAME_KEY_NAME = "Name";
  @NonNls private static final String RESOURCE_NAME = "com/intellij/javaee/weblogic/sample_jaas.properties";
  @NonNls private static final String LOGIN_CONFIG_PROPERTY_KEY = "java.security.auth.login.config";
  @NonNls private static final String WEBLOGIC_RJVM_JVMID_CLASS = "weblogic.rjvm.JVMID";
  @NonNls private static final String LOCAL_ID_METHOD = "localID";
  @NonNls private static final String SET_DOMAIN_NAME_METHOD = "setDomainName";
  @NonNls private static final String SET_SERVER_NAME_METHOD = "setServerName";

  ServerPollThreadForWLBefore9(WeblogicVersionBefore9AbstractInstance weblogicAbstractInstance, Project project, WeblogicModel runConfiguration) {
    super(weblogicAbstractInstance, project, runConfiguration);
  }

  protected void initialize() {
    if (getWeblogicInstance().getRemoteMBeanServer() == null) return;
    try {
      @NonNls final String objectString = "JMImplementation:type=MBeanServerDelegate";
      ObjectName objectName = getWeblogicInstance().getWeblogicLoginInstance().createObjectName(objectString);
      getWeblogicInstance().getRemoteMBeanServer().addNotificationListener(objectName, new RemoteNotificationListenerWrapper() {
        public void handleNotification(Notification notification, Object o) {
          LOG.debug("$$ notification = " + notification + "; " + notification.getMessage());
          if (!(notification instanceof MBeanServerNotification)) {
            return;
          }
          final MBeanServerNotification beanServerNotification = (MBeanServerNotification)notification;
          LOG.debug("** MBeans Notification: "
                    + "; " + beanServerNotification.getMessage()
                    + "; " + beanServerNotification.getSource()
                    + "; " + beanServerNotification.getType()
                    + "; " + beanServerNotification.getUserData()
                    + "; " + beanServerNotification.getMBeanName());
          try {
            if (!getWeblogicInstance().getOutputInfo().getRegistrationNotification().equals(
              beanServerNotification.getType()) &&
                                                !getWeblogicInstance().getOutputInfo().getUnregistrationNotification().equals(
                                                  beanServerNotification.getType())) {
              return;
            }
            final ObjectName registeredBeanName = beanServerNotification.getMBeanName();
            if (APPLICATION.equals(registeredBeanName.getKeyProperty(TYPE_KEY_NAME))) {
              if (getWeblogicInstance().getOutputInfo().getRegistrationNotification().equals(
                beanServerNotification.getType())) {
                // catched application registration, attach deployment listeners
                final WebLogicMBean bean = getWeblogicInstance().getBean(registeredBeanName);
                if (bean == null) return;
                ApplicationMBean applicationMBean = (ApplicationMBean)bean;
                LOG.debug("** APP MBeans Notification: "
                          + "; " + applicationMBean.getFullPath()
                          + "; " + applicationMBean.getPath()
                          + "; " + applicationMBean.getStagingPath()
                          + "; " + applicationMBean.getDeploymentType()
                          + "; " + applicationMBean.getObjectName());
                getWeblogicInstance().registerDeploymentListener(applicationMBean.getObjectName());
              }
              else if (getWeblogicInstance().getOutputInfo().getUnregistrationNotification().equals(
                beanServerNotification.getType())) {
                // catched application unregistration
                final WLDeploymentModel settings = getWeblogicInstance().findModuleDeploymentSettings(
                  registeredBeanName.getKeyProperty(NAME_KEY_NAME));
                if (settings != null) {
                  //fire listeners in another thread
                  ApplicationManager.getApplication().invokeLater(new Runnable() {
                    public void run() {
                      getWeblogicInstance().updateDeploymentStatus(settings);
                    }
                  });
                }
              }
            }
          }
          catch (Exception e) {
            getWeblogicInstance().registerServerError(e);
          }
        }
      });
    }
    catch (Exception e) {
      getWeblogicInstance().registerServerError(e);
    }
  }


  protected void runRequest(final Runnable request) throws PrivilegedActionException {
    if (mySubject != null) {
      getWeblogicInstance().getWeblogicLoginInstance().runAs(mySubject, new PrivilegedExceptionAction() {
        public Object run() throws Exception {
          request.run();
          return null;
        }
      });
    }
    else {
      request.run();
    }
  }

  public void refreshState() {
    final WeblogicVersionBefore9AbstractInstance weblogicInstance = getWeblogicInstance();
    if (weblogicInstance.isRun()) {
      weblogicInstance.setState(weblogicInstance.getServerRuntimeBean().getState());
      return;
    }

    try {
      if (((WeblogicModel)weblogicInstance.getServerModel()).isVersion8()) {
        setDomainAndServerName(weblogicInstance);
      }
      URL resource = weblogicInstance.getClass().getClassLoader().getResource(RESOURCE_NAME);
      System.setProperty(LOGIN_CONFIG_PROPERTY_KEY, resource.toString());
      String adminUrl = getAdminUrl();
      mySubject = weblogicInstance.getWeblogicLoginInstance().login(myRunConfiguration.USER,
                                                                              adminUrl,
                                                                              myRunConfiguration.PASSWORD.toCharArray());
    }
    catch (Exception e) {
      weblogicInstance.registerServerError(e);
      myLoginException = e;
    }


    if (mySubject != null) {
      weblogicInstance.getWeblogicLoginInstance().runAs(mySubject, new PrivilegedAction() {
        public Object run() {
          try {
            weblogicInstance.refreshStateImpl();
          }
          catch (Throwable e) {
            weblogicInstance.registerServerError(e);
          }
          return null;
        }
      });
    }
  }

  private static void setDomainAndServerName(final WeblogicVersionBefore9AbstractInstance weblogicInstance) {
    try {
      final ClassLoader classLoader = weblogicInstance.getWeblogicLoginInstance().getClass().getClassLoader();
      final Class<?> jvmIDClass = Class.forName(WEBLOGIC_RJVM_JVMID_CLASS, true, classLoader);
      final Object localID = jvmIDClass.getMethod(LOCAL_ID_METHOD).invoke(null);
      if (localID != null) {
        invokeSetMethod(localID, SET_DOMAIN_NAME_METHOD, weblogicInstance.getDomainName());
        invokeSetMethod(localID, SET_SERVER_NAME_METHOD, weblogicInstance.getServerName());
      }
    }
    catch (Throwable e) {
      LOG.debug(e);
    }
  }

  private static void invokeSetMethod(final Object localID, final String methodName, final String arg) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
    final Method method = localID.getClass().getDeclaredMethod(methodName, String.class);
    method.setAccessible(true);
    method.invoke(localID, arg);
  }

  @NonNls private String getAdminUrl() {
    return "t3://" + myHost + ":" + myPort;
  }

  protected WeblogicVersionBefore9AbstractInstance getWeblogicInstance() {
    return (WeblogicVersionBefore9AbstractInstance)super.getWeblogicInstance();
  }

  public Exception getLoginException() {
    return myLoginException;
  }

}