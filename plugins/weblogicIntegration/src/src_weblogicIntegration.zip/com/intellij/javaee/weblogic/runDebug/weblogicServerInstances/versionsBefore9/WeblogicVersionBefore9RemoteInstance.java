/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.versionsBefore9;

import com.intellij.execution.ExecutionException;
import com.intellij.j2ee.wrappers.*;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.javaee.weblogic.appServerIntegration.WeblogicIntegration;
import com.intellij.javaee.weblogic.runDebug.configuration.WeblogicModel;
import com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.WeblogicServerEvent;
import com.intellij.openapi.application.ApplicationManager;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author Alexey Kudravtsev
 */
public class WeblogicVersionBefore9RemoteInstance extends WeblogicVersionBefore9AbstractInstance {
  private List<Throwable> myRegisteredExceptions = new ArrayList<Throwable>();
  @NonNls private static final String SERVER_MBEAN_TYPE = "Server";

  public WeblogicVersionBefore9RemoteInstance(CommonModel commonModel)
    throws ExecutionException {
    super(commonModel);
  }

  public void shutdown() {
    disconnect();
  }

  public void startUndeploy(DeploymentModel model) {
    final JavaeeFacet facet = model.getFacet();
    final String name = getDeploymentName(facet);
    if (!isConnected()) return;

    if (model.getDeploymentMethod() == WeblogicIntegration.AUTODEPLOY) {
      throw new IllegalArgumentException(WeblogicBundle.message("exception.text.remote.auto.deploy.not.supported"));
    }


    getServerPollThread().queueRequest(new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.remote.undeploy");
      }

      public void run() {
        try {
          // Build the DeploymentData object
          DeploymentData info = myWeblogicMain.createDeploymentData();
          info.addTarget(getServerName());
          // Create the deployment task. Last arg indicates to just create the task, but not initiate it
          DeploymentTaskRuntimeMBean task = myDeployerRuntimeMBean.remove(name, info, false);

          task.start();
        }
        catch (ManagementExceptionWrapper e) {
          registerServerError(e);
        }
      }
    });
  }

  protected @Nullable String doLoadDataFromRemoteInstance(final boolean setDefaultServerIfNotFound) {
    final String[] result = new String[]{null};
    final Runnable runnable = new Runnable() {
      public String toString() {
        return WeblogicBundle.message("process.description.loading.data.from.remote");
      }

      public void run() {
        if (myMBeanHome == null) {
          result[0] = WeblogicBundle.message("exception.text.cannot.connect.to.remote.server");
          return;
        }
        setDomainName(myMBeanHome.getDomainName());

        final RemoteMBeanServer beanServer = myMBeanHome.getMBeanServer();
        if (beanServer == null) {
          result[0] = WeblogicBundle.message("exception.text.cannot.connect.to.remote.server");
          return;
        }

        String serverName = getWeblogicConfiguration().SERVER_NAME;
        final Set servers = myMBeanHome.getMBeansByType(SERVER_MBEAN_TYPE, getDomainName());
        boolean found = false;
        for (Object server : servers) {
          final String existingName = ((WebLogicMBean)server).getName();
          if (serverName.equals(existingName)) {
            found = true;
            break;
          }
        }

        if (!found) {
          if (!setDefaultServerIfNotFound) {
            result[0] = WeblogicBundle.message("error.cannot.find.server.text", serverName);
            return;
          }
          serverName = beanServer.getServerName();
        }

        setServerName(serverName);
      }
    };
    getServerPollThread().queueRequestAndWait(runnable);
    return result[0];
  }

  public boolean connect() throws Exception {
    final boolean[] connected = new boolean[]{false};
    final String connectingMessage = WeblogicBundle.message("process.description.connecting");

    getServerPollThread().queueRequestAndWait(new Runnable() {
      public String toString() {
        return connectingMessage;
      }

      public void run() {
        myRegisteredExceptions.clear();
        refreshState();
      }
    });

    getServerPollThread().queueRequestAndWait(new Runnable() {
      public String toString() {
        return connectingMessage;
      }

      public void run() {
        final String state = getState();
        if (state != null) {
          registerLogNotificationListener();

          fireServerListeners(new WeblogicServerEvent(state, getOutputInfo()));
          connected[0] = true;
        }
      }
    });

    if (getServerPollThread().getLoginException() != null) {
      throw getServerPollThread().getLoginException();
    }

    if (!myRegisteredExceptions.isEmpty()) {
      Throwable throwable = myRegisteredExceptions.get(0);
      if (throwable instanceof Exception) {
        throw (Exception)throwable;
      }
      else {
        throw new Exception(throwable);
      }
    }
    return connected[0];
  }


  public void testConnection() throws Exception {
    initialize();
    connect();
    try {
      String errorMessage = doLoadDataFromRemoteInstance(false);
      if (errorMessage != null) {
        throw new RuntimeException(errorMessage);
      }
    }
    finally {
      disconnect();
    }


  }

  public void dispose() {
    unregisterServerPollThread();
  }

  private class DeployActionRunnable implements Runnable {
    private final File mySource;
    private final String myName;
    private final DeploymentData myInfo;
    private final DeploymentModel myModel;

    public DeployActionRunnable(File source, String name, DeploymentData info, DeploymentModel model) {
      mySource = source;
      myName = name;
      myInfo = info;
      myModel = model;
    }

    public String toString() {
      return WeblogicBundle.message("process.description.remote.deploy");
    }

    public void run() {
      try {
        String sourcePath = mySource.getPath();
        // upload app first
        DeployerHelper deployerHelper = myWeblogicMain.createDeploymentHelper(myMBeanHome);
        WeblogicModel weblogicModel = getWeblogicRunConfiguration();
        sourcePath = deployerHelper.uploadSource(getAdminUrl(), weblogicModel.USER, weblogicModel.PASSWORD, sourcePath, myName);
        // Create the deployment task. Last arg indicates to just create the task, but not initiate it
        DeploymentTaskRuntimeMBean task = myDeployerRuntimeMBean.activate(sourcePath, myName, myInfo, false);

        task.start();
      }
      catch (Exception e) {
        registerServerError(e);
      }
      finally {
        updateDeploymentStatus(myModel);
      }
    }

    private WeblogicModel getWeblogicRunConfiguration() {
      return (WeblogicModel)getCommonModel().getServerModel();
    }
  }

  public void registerServerError(Throwable e) {
    super.registerServerError(e);
    myRegisteredExceptions.add(e);
  }

  private boolean checkIsReadyToDeploy() {
    return doLoadDataFromRemoteInstance(true) == null;
  }

  private Runnable createDeployAction(File source, String name, DeploymentData info, DeploymentModel model) {
    return new DeployActionRunnable(source, name, info, model);
  }

  public void startDeploy(final DeploymentModel model) {
    if (!isConnected()) return;

    final JavaeeFacet facet = model.getFacet();
    final File source = getDeploymentSource(model);
    if (source == null) {
      ApplicationManager.getApplication().invokeLater(new Runnable() {
        public void run() {
          reportNoDeploymentSource(facet);
        }
      });
      return;
    }
    if (model.getDeploymentMethod() == WeblogicIntegration.AUTODEPLOY) {
      throw new IllegalArgumentException(WeblogicBundle.message("exception.text.remote.auto.deploy.not.supported"));
    }

    final String name = getDeploymentName(facet);

    final DeploymentData info = myWeblogicMain.createDeploymentData();
    if (checkIsReadyToDeploy()) {
      info.addTarget(getServerName());
    }

    getServerPollThread().queueRequest(createDeployAction(source, name, info, model));
  }


}
