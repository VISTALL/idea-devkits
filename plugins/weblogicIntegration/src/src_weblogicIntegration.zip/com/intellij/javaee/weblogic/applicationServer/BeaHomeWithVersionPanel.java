/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.weblogic.applicationServer;

import com.intellij.javaee.weblogic.beaInstallation.BeaInstallation;
import com.intellij.javaee.weblogic.beaInstallation.BeaVersion;
import com.intellij.javaee.weblogic.beaInstallation.WeblogicUtil;
import com.intellij.javaee.weblogic.WeblogicBundle;
import com.intellij.openapi.fileChooser.FileChooserDescriptorFactory;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.ui.TextComponentAccessor;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.IconLoader;
import com.intellij.ui.ComboboxWithBrowseButton;
import com.intellij.ui.DocumentAdapter;
import com.intellij.util.containers.HashMap;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Map;
import java.util.Observable;

public class BeaHomeWithVersionPanel extends Observable {
  private JPanel myMainPanel = new JPanel(new GridBagLayout());
  private final JComboBox myCbVersion = new JComboBox();
  private final JLabel myErrorLabel = new JLabel(WeblogicBundle.message("label.weblogic.server.configuration.bea.is.not.configured.properly"));
  private ComboboxWithBrowseButton myBeaHome = new ComboboxWithBrowseButton();

  private boolean myIsBeaHomeUpdating = false;
  private Map<File, BeaInstallation> myLocationToInstallationMap = new HashMap<File, BeaInstallation>();

  public BeaHomeWithVersionPanel() {
    myErrorLabel.setIcon(IconLoader.getIcon("/runConfigurations/configurationWarning.png"));
    myErrorLabel.setVisible(false);

    myCbVersion.setPrototypeDisplayValue("##########################");

    myMainPanel.add(new JLabel(WeblogicBundle.message("label.weblogic.server.configuration.bea.home")), new GridBagConstraints(0, GridBagConstraints.RELATIVE, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0 , 0), 0, 0));
    myMainPanel.add(myBeaHome, new GridBagConstraints(1, GridBagConstraints.RELATIVE, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 3, 0 , 0), 0, 0));

    myMainPanel.add(new JLabel(WeblogicBundle.message("label.weblogic.server.configuration.bea.version")), new GridBagConstraints(0, GridBagConstraints.RELATIVE, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0 , 0), 0, 0));
    myMainPanel.add(myCbVersion, new GridBagConstraints(1, GridBagConstraints.RELATIVE, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 3, 0 , 0), 0, 0));

    myMainPanel.add(new JLabel(WeblogicBundle.message("label.text.please.note.that.weblogic.versions.prior.to.7.0.are.not.supported")), new GridBagConstraints(0, GridBagConstraints.RELATIVE, 2, 1, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    final JPanel errorPanel = new JPanel(new BorderLayout());
    errorPanel.add(myErrorLabel, BorderLayout.CENTER);
    errorPanel.add(Box.createVerticalStrut(myErrorLabel.getPreferredSize().height * 2), BorderLayout.WEST);
    myMainPanel.add(errorPanel, new GridBagConstraints(0, GridBagConstraints.RELATIVE, 2, 1, 1.0, 1.0, GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(5, 0, 0 , 0), 0, 0));

    myCbVersion.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setModified();
      }
    });

    myBeaHome.getComboBox().setEditable(true);
    myBeaHome.addBrowseFolderListener(null, null, null, FileChooserDescriptorFactory.createSingleFolderDescriptor(), TextComponentAccessor.STRING_COMBOBOX_WHOLE_TEXT);

    BeaInstallation[] possibleLocations = WeblogicUtil.getAllPossibleServerLocations();
    for (int i = 0; i < possibleLocations.length; i++) {
      BeaInstallation possibleLocation = possibleLocations[i];
      myLocationToInstallationMap.put(possibleLocation.getLocation(), possibleLocation);
      myBeaHome.getComboBox().addItem(possibleLocation.getLocation().getAbsolutePath());
    }

    if (possibleLocations.length > 0) {
      myBeaHome.getComboBox().setSelectedIndex(0);
      onServerPathChanged(possibleLocations[0].getLocation().getAbsolutePath());
    }

    JTextField textField = (JTextField)myBeaHome.getComboBox().getEditor().getEditorComponent();
    textField.getDocument().addDocumentListener(new DocumentAdapter() {
      protected void textChanged(DocumentEvent e) {
        onServerPathChanged(getCurrentPath());
      }
    });
  }

  private void setModified() {
    setChanged();
    notifyObservers();
  }

  public BeaVersion getSelectedVersion() {
    return (BeaVersion)myCbVersion.getSelectedItem();
  }

  public JComponent getComponent() {
    return myMainPanel;
  }

  public BeaInstallation getSelectedInstallation() {
    return getCurrentSelection(getCurrentPath());
  }

  public void setBeaHome(String bea_home) {
    TextComponentAccessor.STRING_COMBOBOX_WHOLE_TEXT.setText(myBeaHome.getComboBox(), bea_home);
    onServerPathChanged(bea_home);
  }

  public void setVersion(String version) {
    myCbVersion.setSelectedItem(findVersionByName(version));
  }

  public void checkIsValid() throws ConfigurationException {
    BeaInstallation newInstallation = getCurrentSelection(getCurrentPath());
    if (!newInstallation.isValid()) {
      throw new ConfigurationException(newInstallation.getInvalidityReason());
    }
  }

  private String getCurrentPath() {
    return TextComponentAccessor.STRING_COMBOBOX_WHOLE_TEXT.getText(myBeaHome.getComboBox());
  }

  private BeaInstallation getCurrentSelection(String beaPath) {
    final File location = new File(beaPath);
    myIsBeaHomeUpdating = true;
    try {
      BeaInstallation beaInstallation = myLocationToInstallationMap.get(location);
      if (beaInstallation == null) {
        beaInstallation = WeblogicUtil.getInstallationByLocation(location);
        if (beaInstallation.isValid()) {
          myLocationToInstallationMap.put(location, beaInstallation);
          SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              final String absolutePath = location.getAbsolutePath();
              final JComboBox comboBox = myBeaHome.getComboBox();
              comboBox.addItem(absolutePath);
              comboBox.setSelectedItem(absolutePath);
            }
          });
        }
      }
      return beaInstallation;
    }
    finally {
      myIsBeaHomeUpdating = false;
    }
  }

  private void onServerPathChanged(String newBeaLocation) {
    if (myIsBeaHomeUpdating) {
      return;
    }
    final BeaInstallation currentSelection = getCurrentSelection(newBeaLocation);
    if (currentSelection.isValid()) {
      myErrorLabel.setVisible(false);
      final BeaVersion[] versions = currentSelection.getVersions();
      myCbVersion.removeAllItems();
      for (int i = 0; i < versions.length; i++) {
        myCbVersion.addItem(versions[i]);
      }
    }
    else {
      myErrorLabel.setVisible(true);
      myErrorLabel.setText(
        WeblogicBundle.message("label.weblogic.server.configuration.selection.is.invalid.warning", currentSelection.getInvalidityReason()));
    }
    setModified();
  }

  private BeaVersion findVersionByName(String name) {
    for (int i = 0; i < myCbVersion.getItemCount(); i++) {
      BeaVersion version = (BeaVersion)myCbVersion.getItemAt(i);
      if (Comparing.equal(name, version.getName())) {
        return version;
      }
    }
    return null;
  }


}