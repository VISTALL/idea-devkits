/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.weblogic.runDebug.weblogicServerInstances.version9.mbeansModel;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;

/**
 * @author nik
 */
public class EditServiceWL9MBean extends AbstractWL9MBean {
  public EditServiceWL9MBean(final MBeanServerConnection connection, final ObjectName beanName) {
    super(connection, beanName);
  }

  public ConfigurationManagerWL9MBean getConfigurationManager() {
    return new ConfigurationManagerWL9MBean(getConnection(), getChild("ConfigurationManager"));
  }
}
