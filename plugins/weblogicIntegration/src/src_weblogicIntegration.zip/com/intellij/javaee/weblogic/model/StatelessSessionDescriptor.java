// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;

/**
 * http://www.bea.com/ns/weblogic/90:stateless-session-descriptorType interface.
 */
public interface StatelessSessionDescriptor extends JavaeeDomModelElement {

	/**
	 * Returns the value of the pool child.
	 * @return the value of the pool child.
	 */
	Pool getPool();


	/**
	 * Returns the value of the timer-descriptor child.
	 * @return the value of the timer-descriptor child.
	 */
	TimerDescriptor getTimerDescriptor();


	/**
	 * Returns the value of the stateless-clustering child.
	 * @return the value of the stateless-clustering child.
	 */
	StatelessClustering getStatelessClustering();


}
