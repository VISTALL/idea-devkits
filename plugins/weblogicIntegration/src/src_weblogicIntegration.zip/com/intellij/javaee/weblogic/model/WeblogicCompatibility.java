// Generated on Tue Feb 28 15:57:37 MSK 2006
// DTD/Schema  :    http://www.bea.com/ns/weblogic/90

package com.intellij.javaee.weblogic.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.GenericDomValue;

/**
 * http://www.bea.com/ns/weblogic/90:weblogic-compatibilityType interface.
 */
public interface WeblogicCompatibility extends JavaeeDomModelElement {

	/**
	 * Returns the value of the entity-always-uses-transaction child.
	 * <pre>
	 * <h3>Type http://www.bea.com/ns/weblogic/90:true-falseType documentation</h3>
	 * This simple type designates a boolean with permissible values
	 *   - true/false
	 *   - yes/no
	 *   - 1/0
	 * </pre>
	 * @return the value of the entity-always-uses-transaction child.
	 */
	GenericDomValue<Boolean> getEntityAlwaysUsesTransaction();


}
