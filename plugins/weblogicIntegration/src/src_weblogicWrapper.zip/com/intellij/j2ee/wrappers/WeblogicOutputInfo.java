/*
 * Copyright (c) 2005 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.j2ee.wrappers;

/**
 * @author nik
 */
public interface WeblogicOutputInfo {
  int severityStringToNum(String severityStr);

  String severityNumToString(int severity);

  String getRegistrationNotification();

  String getUnregistrationNotification();

  String getRunning();

  String getShuttingDown();

  String getShutdown();

  String getEmergencyText();

  String getAlertText();

  String getCriticalText();

  String getErrorText();

  String getWarningText();

  String getNoticeText();

  String getInfoText();

  String getDebugText();

  String getActivated();

  String getActivating();

  String getPrepared();

  String getPreparing();

  String getDeactivated();

  String getDeactivating();

  String getUnprepared();

  String getUnpreparing();

  String getFailed();
}
