package com.intellij.vssSupport.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.VcsShowSettingOption;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssUtil;
import com.intellij.vssSupport.VssVcs;
import com.intellij.vssSupport.commands.GetDirCommand;
import com.intellij.vssSupport.commands.GetFilesCommand;

import java.util.ArrayList;

/**
 * @author Vladimir Kondratyev
 */
public class GetAction extends VssAction
{
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.actions.GetAction");

  public void actionPerformed( AnActionEvent e )
  {
    DataContext dataContext = e.getDataContext();
    Project project = (Project)dataContext.getData( DataConstants.PROJECT );
    LOG.assertTrue( project != null );
    VirtualFile[] files = VssUtil.getVirtualFiles( dataContext );
    LOG.assertTrue( files.length > 0 );

    ArrayList<VcsException> errors = new ArrayList<VcsException>();
    try
    {
      if( files.length == 1 && files[ 0 ].isDirectory() )
      {
        (new GetDirCommand( project, files[ 0 ], null, errors )).execute();
      }
      else
      {
        VcsShowSettingOption toShow = VssVcs.getInstance( project ).getGetOptions();
        (new GetFilesCommand( project, files, null, toShow.getValue(), errors)).execute();

      }
    }
    finally
    {
      if( !errors.isEmpty() )
        Messages.showErrorDialog( errors.get( 0 ).getLocalizedMessage(), VssBundle.message("message.title.could.not.start.process"));
    }
  }
}
