package com.intellij.vssSupport.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.FileStatus;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.changes.ChangeListManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssUtil;
import com.intellij.vssSupport.VssVcs;
import com.intellij.vssSupport.commands.CheckoutDirCommand;
import com.intellij.vssSupport.commands.CheckoutFilesCommand;

import java.util.ArrayList;

/**
 * @author Vladimir Kondratyev
 */
public class CheckoutAction extends VssAction
{
  // Command is enabled only if all files are under Vss control (this is checked)
  // in the base class, AND they have not been already checked out
  public void update( AnActionEvent e )
  {
    super.update( e );

    Presentation presentation = e.getPresentation();
    DataContext  dataContext = e.getDataContext();
    Project      project = (Project)dataContext.getData( DataConstants.PROJECT );
    boolean      isEnabled = e.getPresentation().isEnabled();
    if( isEnabled )
    {
      VirtualFile[] files = VssUtil.getVirtualFiles( dataContext );
      ChangeListManager mgr = ChangeListManager.getInstance( project );
      isEnabled = (files.length > 0) && allFilesAreFolders( files );

      if( !isEnabled )
      {
        isEnabled = true;
        for (VirtualFile file : files)
        {
          FileStatus status = mgr.getStatus( file );
          isEnabled &= !file.isDirectory() && (status == FileStatus.NOT_CHANGED);
        }
      }
    }
    presentation.setEnabled( isEnabled );
  }

  public void actionPerformed(AnActionEvent e)
  {
    DataContext dataContext = e.getDataContext();
    Project     project = (Project)dataContext.getData(DataConstants.PROJECT);
    VirtualFile[] files = VssUtil.getVirtualFiles( dataContext );
    ArrayList<VcsException> errors = new ArrayList<VcsException>();
    try
    {
      boolean showOptions = VssVcs.getInstance(project).getCheckoutOptions().getValue();
      if( allFilesAreFolders( files ) )
      {
        for( VirtualFile file : files )
        {
          (new CheckoutDirCommand(project, file, null,errors)).execute();
        }
      }
      else
      {
          new CheckoutFilesCommand( project, files, null, showOptions, errors, true ).execute();
      }
    }
    finally {
      if (!errors.isEmpty()){
        Messages.showErrorDialog(errors.get(0).getLocalizedMessage(), VssBundle.message("message.title.could.not.start.process"));
      }
    }
  }

  private static boolean allFilesAreFolders( VirtualFile [] files )
  {
    boolean allFolders = true;
    for( VirtualFile file : files )
      allFolders &= file.isDirectory();

    return allFolders;
  }
}
