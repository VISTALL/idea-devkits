package com.intellij.vssSupport.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.ProjectLevelVcsManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssUtil;
import com.intellij.vssSupport.VssVcs;
import com.intellij.vssSupport.commands.RunExplorerCommand;

/**
 * @author Vladimir Kondratyev
 */
public class RunExplorerAction extends VssAction{
  private static final Logger LOG=Logger.getInstance("#com.intellij.vssSupport.actions.RunExplorerAction");

  public void actionPerformed(AnActionEvent event){
    DataContext dataContext = event.getDataContext();
    final Project project = (Project)dataContext.getData(DataConstants.PROJECT);
    LOG.assertTrue(project!=null);
    VirtualFile virtualFile=VssUtil.getVirtualFile(dataContext);
    LOG.assertTrue(virtualFile!=null);
    (new RunExplorerCommand(project, virtualFile)).execute();
  }

  /**
   * Action is enabled if and only if project is accessible from context,
   * VSS integration is enabled and single selection exists.
   */
  public void update(AnActionEvent e){
    Presentation presentation = e.getPresentation();
    DataContext dataContext = e.getDataContext();
    Project project=(Project)dataContext.getData(DataConstants.PROJECT);
    // Check project
    if(project==null){
      presentation.setEnabled(false);
      return;
    }
    // Check that VSS is enabled
    // Check the single section
    VirtualFile[] virtualFiles=VssUtil.getVirtualFiles(dataContext);
    if (virtualFiles.length != 1){
      presentation.setEnabled(false);
      return;
    }

    VirtualFile virtualFile = virtualFiles[0];
    presentation.setEnabled(ProjectLevelVcsManager.getInstance(project).checkAllFilesAreUnder(VssVcs.getInstance(project), new VirtualFile[]{virtualFile}));
  }
}
