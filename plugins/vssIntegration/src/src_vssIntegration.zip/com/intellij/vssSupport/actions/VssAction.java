package com.intellij.vssSupport.actions;

import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.ProjectLevelVcsManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssUtil;
import com.intellij.vssSupport.VssVcs;

/**
 * @author Vladimir Kondratyev
 */
abstract class VssAction extends AnAction{
  /**
   * Action is enable if and only if project is accessible from context,
   * VSS isn't busy and at least one file in the context is under VSS control.
   */
  public void update(AnActionEvent e)
  {
    Presentation presentation = e.getPresentation();
    DataContext dataContext = e.getDataContext();
    boolean state = false;

    Project project = (Project)dataContext.getData(DataConstants.PROJECT);
    if( project != null)
    {
      // Check the VSS is enabled.
      VssVcs            host = VssVcs.getInstance(project);
      VssConfiguration  config = VssConfiguration.getInstance(project);
      ProjectLevelVcsManager pm = ProjectLevelVcsManager.getInstance(project);

      // At least one file should be under VSS control.
      VirtualFile[] virtualFiles = VssUtil.getVirtualFiles( dataContext );
      for(int i = 0; i < virtualFiles.length; i++ )
      {
        VirtualFile virtualFile = virtualFiles[ i ];
        if( pm.checkAllFilesAreUnder( host, new VirtualFile[]{ virtualFile }) && !config.isBusy())
        {
          if(VssUtil.isUnderVss(virtualFile, project))
          {
            state = true;
            break;
          }
        }
      }
    }
    presentation.setEnabled( state );
  }
}
