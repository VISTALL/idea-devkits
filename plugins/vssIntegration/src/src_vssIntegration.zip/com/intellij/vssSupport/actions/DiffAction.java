package com.intellij.vssSupport.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssUtil;
import com.intellij.vssSupport.commands.DiffFileCommand;

import java.util.ArrayList;

/**
 * @author Vladimir Kondratyev
 */
public class DiffAction extends VssAction
{
  private static final Logger LOG=Logger.getInstance("#com.intellij.vssSupport.actions.DiffAction");

  public void actionPerformed(AnActionEvent e){
    DataContext dataContext = e.getDataContext();
    Project project = (Project)dataContext.getData( DataConstants.PROJECT );
    LOG.assertTrue( project != null );
    VirtualFile[] virtualFiles = VssUtil.getVirtualFiles( dataContext );
    VirtualFile   vFile = virtualFiles[ 0 ];
    ArrayList<VcsException> errors = new ArrayList<VcsException>();
    (new DiffFileCommand(project, vFile, errors)).execute();
    
    if( !errors.isEmpty() )
      Messages.showErrorDialog(errors.get(0).getLocalizedMessage(), VssBundle.message("message.title.could.not.start.process"));
  }

  /**
   * Action is anable if and only if project and single FILE selection is available
   * and VSS isn't busy.
   */
  public void update(AnActionEvent e)
  {
    boolean isEnabled = false;
    DataContext dataContext = e.getDataContext();

    Project project = (Project)dataContext.getData( DataConstants.PROJECT );
    if( project != null )
    {
      VssConfiguration config = VssConfiguration.getInstance( project );
      VirtualFile[] files = VssUtil.getVirtualFiles( dataContext );

      isEnabled = !config.isBusy() && (files.length == 1) &&
                  !files[ 0 ].isDirectory() && VssUtil.isUnderVss( files[ 0 ], project );
    }
    e.getPresentation().setEnabled( isEnabled );
  }
}
