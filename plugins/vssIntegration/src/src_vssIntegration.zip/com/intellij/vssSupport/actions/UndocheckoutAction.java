package com.intellij.vssSupport.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssUtil;
import com.intellij.vssSupport.VssVcs;
import com.intellij.vssSupport.commands.UndocheckoutDirCommand;
import com.intellij.vssSupport.commands.UndocheckoutFilesCommand;

import java.util.ArrayList;

/**
 * @author Vladimir Kondratyev
 */
public class UndocheckoutAction extends VssAction
{
  //  Command is enabled only if all files are under Vss control (this is checked)
  //  in the base class, AND they have been already checked out

  public void update( AnActionEvent e )
  {
    super.update( e );

    Presentation presentation = e.getPresentation();
    DataContext dataContext = e.getDataContext();
    boolean isEnabled = e.getPresentation().isEnabled();
    
    if( isEnabled )
    {
      //  UndoCheckout works only for a set of folders or for a set of ordinary files
      VirtualFile[] files = VssUtil.getVirtualFiles( dataContext );
      isEnabled = allFilesAreFolders( files );
      if( !isEnabled )
      {
        isEnabled = true;
        for (VirtualFile file : files)
          isEnabled &= !file.isDirectory() && file.isWritable();
      }
    }
    presentation.setEnabled( isEnabled );
  }

  public void actionPerformed( AnActionEvent e )
  {
    DataContext dataContext = e.getDataContext();
    Project project = (Project)dataContext.getData( DataConstants.PROJECT );
    VirtualFile[] files = VssUtil.getVirtualFiles( dataContext );
    ArrayList<VcsException> errors = new ArrayList<VcsException>();

    try
    {
      VssConfiguration config = VssConfiguration.getInstance(project);
      boolean     showOptions = VssVcs.getInstance(config.getProject()).getUndoCheckoutOptions().getValue();

      if( allFilesAreFolders( files ))
      {
        for( VirtualFile file : files )
        {
          (new UndocheckoutDirCommand( project, file , null, showOptions, errors )).execute();
        }
      }
      else
      {
        (new UndocheckoutFilesCommand( project, files, null, showOptions, false, errors ) ).execute();
      }
    }
    finally
    {
      if (!errors.isEmpty())
        Messages.showErrorDialog(errors.get( 0 ).getLocalizedMessage(), VssBundle.message("message.title.could.not.start.process"));
    }
  }

  private static boolean allFilesAreFolders( VirtualFile [] files )
  {
    boolean allFolders = true;
    for( VirtualFile file : files )
      allFolders &= file.isDirectory();

    return allFolders;
  }
}
