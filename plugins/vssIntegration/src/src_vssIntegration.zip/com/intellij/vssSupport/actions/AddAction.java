package com.intellij.vssSupport.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.FileStatus;
import com.intellij.openapi.vcs.changes.ChangeListManager;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssUtil;
import com.intellij.vssSupport.VssVcs;

/**
 * @author Vladimir Kondratyev
 */
public class AddAction extends VssAction{
  public void actionPerformed(AnActionEvent e)
  {
    DataContext dataContext = e.getDataContext();
    Project project = (Project)dataContext.getData( DataConstants.PROJECT );

    //  Perform only moving the file into normal changelist with the
    //  proper status "ADDED". After that the file can be submitted into
    //  the repository via "Commit" dialog.
    VirtualFile[] files = VssUtil.getVirtualFiles( dataContext );
    VssVcs.getInstance( project ).add2NewFile( files[ 0 ] );

    VcsDirtyScopeManager mgr = VcsDirtyScopeManager.getInstance( project );
    mgr.fileDirty( files[ 0 ] );
    files[ 0 ].refresh( true, true );
  }

  /**
   * Action is enabled if and only if project and single FILE (not directory) selection
   * are available from context and VSS isn't busy.
   */
  public void update( AnActionEvent event )
  {
    boolean status = false;
    Presentation  presentation = event.getPresentation();
    DataContext   dataContext = event.getDataContext();
    Project       project = (Project)dataContext.getData( DataConstants.PROJECT );

    if( project != null )
    {
      VirtualFile[] files = VssUtil.getVirtualFiles( dataContext );
      ChangeListManager mgr = ChangeListManager.getInstance( project );

      if( files.length == 1 )
      {
        VirtualFile file = files[ 0 ];

        if( !file.isDirectory() && VssUtil.isUnderVss(file, project) )
        {
          // Check busy and file is not in the version control.
          status = !VssConfiguration.getInstance(project).isBusy();
          FileStatus fileStatus = mgr.getStatus( file );
          status &= (fileStatus == FileStatus.UNKNOWN);
        }
      }
    }
    presentation.setEnabled( status );
  }
}
