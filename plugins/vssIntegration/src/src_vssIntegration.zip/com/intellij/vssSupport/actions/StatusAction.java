package com.intellij.vssSupport.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.commands.GetStatusCommand;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 * Date: Mar 13, 2006
 * Time: 1:59:24 PM
 * To change this template use File | Settings | File Templates.
 */

public class StatusAction  extends VssAction
{
  public void actionPerformed(AnActionEvent e)
  {
    DataContext dataContext = e.getDataContext();
    Project project = (Project)dataContext.getData(DataConstants.PROJECT);
    ArrayList<VcsException> errors = new ArrayList<VcsException>();
    try {
      GetStatusCommand cmd = new GetStatusCommand( project );
      cmd.execute();
      errors.addAll( cmd.myErrors );
    }
    finally {
      if (!errors.isEmpty()){
        Messages.showErrorDialog( errors.get(0).getLocalizedMessage(),
                                  VssBundle.message( "message.title.could.not.start.process" ) );
      }
    }
  }
}
