/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.*;
import com.intellij.openapi.vcs.ModuleLevelVcsManager;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class VssConfiguration implements ProjectComponent, JDOMExternalizable
{
  @NonNls private static final String SSEXP_FILE_NAME = "ssexp.exe";
  @NonNls private static final String SSDIR_PARAM_NAME = "SSDIR";
  @NonNls private static final String _Y_OPTION = "-Y";
  @NonNls private static final String INVALID_ISBUSY_CALL = "Access to isBusy method is allowed in the event dispath thread";
  @NonNls private static final String INVALID_SETBUSY_CALL = "Access to setBusy method is allowed in the event dispath thread";
  @NonNls private static final String INVALID_BUSY_STATE = "Cannot set the same busy state: ";
  @NonNls private static final String MAP_ITEM_ELEMENT_NAME = "MapItem";
  @NonNls private static final String EXCLUDED_FILES_MASK_TAG = "VssConfigurableExcludedFilesTag";

  //  All fields are public for JDOM saving mechanism to
  //  work properly. Damn.
  public String CLIENT_PATH = "";
  public String SRCSAFEINI_PATH = "";
  public String USER_NAME = "";
  public String PWD = "";
  public ArrayList myMapItems;
  public boolean VSS_IS_INITIALIZED = false;

  /*
   * These options are reused by dialogs to "remember" previous option set.
   */
  private CheckoutOptions myCheckoutOptions;
  private CheckinOptions myCheckinOptions;
  private AddOptions myAddOptions;
  private UndocheckoutOptions myUndocheckoutOptions;
  private GetOptions myGetOptions;
  private boolean myBusy;
  private Project myProject;
  private String maskExcludedFilesPatterns = "";
  private HashSet<Pattern> extsByType = new HashSet<Pattern>();

  public VssConfiguration( Project project )
  {
    myProject = project;
    myMapItems = new ArrayList();
    myCheckoutOptions = new CheckoutOptions( this );
    myCheckinOptions = new CheckinOptions( this );
    myAddOptions = new AddOptions( this );
    myUndocheckoutOptions = new UndocheckoutOptions( this );
    myGetOptions = new GetOptions( this );
  }

  public void disposeComponent() {}
  public void initComponent() {}
  public void projectOpened() {}
  public void projectClosed() {}

  public Project         getProject()         {  return myProject;          }
  public CheckoutOptions getCheckoutOptions() {  return myCheckoutOptions;  }
  public CheckinOptions  getCheckinOptions()  {  return myCheckinOptions;   }
  public AddOptions      getAddOptions()      {  return myAddOptions;       }
  public GetOptions      getGetOptions()      {  return myGetOptions;       }
  public UndocheckoutOptions getUndocheckoutOptions(){ return myUndocheckoutOptions;  }

  @NotNull
  public String  getComponentName() {  return "VssConfiguration";  }

  /**
   * @return Error message text if path to VSS client is not properly configured.
   * Otherwise the method returns <code>NULL</code>.
   */
  @Nullable
  public String checkCmdPath()
  {
    String message = null;
    File client = new File( CLIENT_PATH );
    if( CLIENT_PATH.length() == 0 )
      message = VssBundle.message( "message.text.specify.path.to.client");
    else if( !client.exists() )
      message = VssBundle.message( "message.text.path.does.not.exist", CLIENT_PATH );
    else if( client.isDirectory() )
      message = VssBundle.message("message.text.path.is.directory", CLIENT_PATH);

    return message;
  }

  /**
   * @return full path to SourceSafe explorer executable. The path is constructed base on
   * config.CLIENT_PATH
   */
  public String getExplorerPath(){
    File client=new File(CLIENT_PATH);
    File clientDir=client.getParentFile();
    String pathToExplorer="";
    if(clientDir!=null){
      try{
        pathToExplorer=clientDir.getCanonicalPath()+File.separatorChar+SSEXP_FILE_NAME;
      }catch(IOException ignored){}
    }
    return pathToExplorer;
  }

  public String getSSDIR(){
    File srcsafeini=new File(SRCSAFEINI_PATH);
    File ssDir=srcsafeini.getParentFile();
    String pathToSSDIR="";
    if(ssDir!=null){
      try{
        pathToSSDIR=ssDir.getCanonicalPath();
      }catch(IOException ignored){}
    }
    return pathToSSDIR;
  }

  public HashMap<String, String> getSSDIREnv(){
    HashMap<String, String> result = new HashMap<String, String>(1);
    result.put(SSDIR_PARAM_NAME, getSSDIR());
    return result;
  }

  /**
   * Create "-Y" option for ss.exe command line tool.
   */
  public String getYOption(){
    return _Y_OPTION +USER_NAME+(getPassword().length()>0?","+getPassword():"");
  }

  public static VssConfiguration getInstance(Project project){
    return project.getComponent(VssConfiguration.class);
  }

  /**
   * @return <code>MapItem</code> with the specified index.
   */
  public MapItem getMapItem( int idx ){  return (MapItem) myMapItems.get( idx );  }

  /**
   * @return the number of all available items.
   */
  public int getMapItemCount(){  return myMapItems.size();  }

  /**
   * @return <code>true</code> if any VSS process is being executed. This "busy" flag is used
   * to don't allow several VSS processes to be executed at the same time. You have to carefully
   * use <code>isBusy</code> and <code>setBusy</code> methods, because whole VSS integration
   * might be broken if "busy" flag is turned on and not reset.
   */
  public boolean isBusy(){
    if(!ApplicationManager.getApplication().isDispatchThread()){
      throw new IllegalStateException(INVALID_ISBUSY_CALL);
    }
    return myBusy;
  }

  /**
   * Sets the new "busy" state. If the <code>state</code> is the same as
   * <code>isBusy()</code> then <code>IllegalArgumentException</code> is thrown.
   */
  public synchronized void setBusy(boolean state){
    if(!ApplicationManager.getApplication().isDispatchThread()){
      throw new IllegalStateException(INVALID_SETBUSY_CALL);
    }
    if(myBusy==state){
      throw new IllegalArgumentException(INVALID_BUSY_STATE +state);
    }
    myBusy=state;
  }

  public static boolean isEnabled(Module module) {
    ModuleLevelVcsManager moduleLevelVcsManager = ModuleLevelVcsManager.getInstance(module);
    return (moduleLevelVcsManager != null) && (moduleLevelVcsManager.getActiveVcs() instanceof VssVcs);
  }

  public String getPassword() {
    try {  return PasswordUtil.decodePassword(PWD);  }
    catch( Exception e ) {  return "";  }
  }

  public void setPassword(final String PWD) {  this.PWD = PasswordUtil.encodePassword( PWD );  }

  public String getExcludedMask() {  return maskExcludedFilesPatterns;  }

  public void setExcludedMask( final String masks )
  {
    maskExcludedFilesPatterns = masks;
    extsByType.clear();
    String[] byType = masks.split( ";" );
    for( String mask : byType )
    {
      Pattern p = compilePattern( mask );
      if( p != null )
      {
        extsByType.add( p );
      }
    }
  }

  public boolean isFileExcluded( final String fileName )
  {
    for( Pattern p : extsByType )
    {
      if( p.matcher( fileName ).matches() )
        return true;
    }
    return false;
  }

  @Nullable
  private static Pattern compilePattern( String template )
  {
    Pattern p = null;
    String strPattern = convertWildcard2Pattern( template.trim() );
    try
    {
      if( SystemInfo.isFileSystemCaseSensitive )
        p = Pattern.compile( strPattern );
      else
        p = Pattern.compile( strPattern, Pattern.CASE_INSENSITIVE );
    }
    catch( PatternSyntaxException e )
    {
      //  Generally - nothing to do.
      //noinspection HardCodedStringLiteral
      System.out.println( "Can not parse template: " + template );
    }
    return p;
  }

  private static String convertWildcard2Pattern( String wildcardPattern )
  {
    return wildcardPattern.
      replaceAll("\\\\!", "!").
      replaceAll("\\.", "\\\\.").
      replaceAll("\\*\\?", ".+").
      replaceAll("\\?\\*", ".+").
      replaceAll("\\*", ".*").
      replaceAll("\\?", ".").
      replaceAll("(?:\\.\\*)+", ".*");  // optimization
  }

  public void readExternal(Element parentNode) throws InvalidDataException
  {
    DefaultJDOMExternalizer.readExternal(this,  parentNode);
    myMapItems.clear();
    for (Iterator iterator = parentNode.getChildren().iterator(); iterator.hasNext();) {
      Element element = (Element)iterator.next();
      String name=element.getName();
      if(MAP_ITEM_ELEMENT_NAME.equals( name )){
        MapItem mapItem=new MapItem("","");
        mapItem.readExternal( element );
        myMapItems.add( mapItem );
      }else if( AddOptions.TAG.equals( name )){
        DefaultJDOMExternalizer.readExternal( myAddOptions, element );
      }else if( CheckoutOptions.TAG.equals( name )){
        DefaultJDOMExternalizer.readExternal( myCheckoutOptions, element );
      }else if( CheckinOptions.TAG.equals( name )){
        DefaultJDOMExternalizer.readExternal( myCheckinOptions, element );
      }else if( UndocheckoutOptions.TAG.equals( name )){
        DefaultJDOMExternalizer.readExternal( myUndocheckoutOptions, element );
      }else if( GetOptions.TAG.equals( name )){
        DefaultJDOMExternalizer.readExternal( myGetOptions, element );
      }else if( EXCLUDED_FILES_MASK_TAG.equals( name )){
        final String masks = element.getValue();
        setExcludedMask( masks );
      }
    }
  }

  public void writeExternal(Element parentNode) throws WriteExternalException
  {
    DefaultJDOMExternalizer.writeExternal(this,  parentNode);
    int size = myMapItems.size();
    for( int i = 0; i < size; i++){
      MapItem mapItem = (MapItem)myMapItems.get( i );
      Element elem = new Element(MAP_ITEM_ELEMENT_NAME);
      parentNode.addContent( elem );
      mapItem.writeExternal( elem );
    }

    // Write options.

    Element elem;

    elem = new Element( CheckoutOptions.TAG );
    parentNode.addContent( elem );
    DefaultJDOMExternalizer.writeExternal( myCheckoutOptions, elem );

    elem = new Element( CheckinOptions.TAG );
    parentNode.addContent( elem );
    DefaultJDOMExternalizer.writeExternal( myCheckinOptions, elem );

    elem = new Element( AddOptions.TAG );
    parentNode.addContent( elem );
    DefaultJDOMExternalizer.writeExternal( myAddOptions, elem );

    elem = new Element( UndocheckoutOptions.TAG );
    parentNode.addContent( elem );
    DefaultJDOMExternalizer.writeExternal( myUndocheckoutOptions, elem );

    elem = new Element( GetOptions.TAG );
    parentNode.addContent( elem );
    DefaultJDOMExternalizer.writeExternal( myGetOptions, elem );

    elem = new Element( EXCLUDED_FILES_MASK_TAG );
    parentNode.addContent( elem );
    elem.addContent(maskExcludedFilesPatterns);
  }
}