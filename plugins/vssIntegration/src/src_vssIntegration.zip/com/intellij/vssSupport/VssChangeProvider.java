package com.intellij.vssSupport;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ContentIterator;
import com.intellij.openapi.roots.ProjectFileIndex;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.changes.*;
import com.intellij.openapi.vcs.history.VcsRevisionNumber;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vcsUtil.VcsUtil;
import com.intellij.vssSupport.commands.*;
import com.intellij.vssSupport.commands.VSSExecUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 * Date: Apr 6, 2006
 */
public class VssChangeProvider implements ChangeProvider
{
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.VssChangeProvider");

  private static final int PER_FILE_DIFF_MARGIN = 10;

  private Project project;
  private VssVcs  host;
  private ProgressIndicator progress;

  private HashSet<String> filesNew = new HashSet<String>();
  private HashSet<String> filesChanged = new HashSet<String>();
  private ArrayList<String> foldersAbcent = new ArrayList<String>();

  public VssChangeProvider( Project project, VssVcs host )
  {
    this.project = project;
    this.host = host;
  }

  public void getChanges( final VcsDirtyScope dirtyScope, final ChangelistBuilder builder, final ProgressIndicator progress )
  {
    LOG.info( "-- ChangeProvider -- ");
    LOG.info( "   Dirty files: " + dirtyScope.getDirtyFiles().size() +
              ", dirty recursive directories: " + dirtyScope.getRecursivelyDirtyDirectories().size() );
    LOG.info( "   Is project default? " + project.isDefault() );

    boolean isBatchUpdate = dirtyScope.getRecursivelyDirtyDirectories().size() > 0;
    VssConfiguration config = VssConfiguration.getInstance( project );
    this.progress = progress;
    initInternals();

    //  Safety check #1: if user did not manage to set the proper path to ss.exe
    //  we fail to proceed further.
    final String checkMsg = config.checkCmdPath();
    if( checkMsg != null )
    {
      ApplicationManager.getApplication().invokeLater( new Runnable() {
         public void run() {  Messages.showErrorDialog( checkMsg, VssBundle.message( "message.title.could.not.start.process" ));  }
       });
      return;
    }

    if( isBatchUpdate )
    {
      iterateOverProjectStructure( dirtyScope );
    }
    iterateOverDirtyDirectories( dirtyScope );
    iterateOverDirtyFiles( dirtyScope );

    /**
     * Transform data accumulated in the internal data structures (filesNew,
     * filesChanged, filesDeleted, host.renamedFiles) into "Change" format
     * acceptable by ChangelistBuilder.
    */
    addNewOrRenamedFiles( builder );
    addChangedFiles( builder );
    addRemovedFiles( builder );
  }

  /**
   *  Iterate over the project structure, find all writable files in the project,
   *  and check their status against the VSS repository. If file exists in the repository
   *  it is assigned "changed" status, otherwise it has "new" status.
   */
  private void iterateOverProjectStructure( final VcsDirtyScope dirtyScope )
  {
    for( FilePath path : dirtyScope.getRecursivelyDirtyDirectories() )
    {
      iterateOverProjectPath( path );
    }
  }

  private void iterateOverProjectPath( FilePath path )
  {
    LOG.info( "-- ChangeProvider - Iterating over project structure starting from scope root: " + path.getPath() );
    if( progress != null )
      progress.setText( VssBundle.message( "message.statusbar.collect.writables" ) );

    List<String> writableFiles = new ArrayList<String>();
    collectSuspiciousFiles( path, writableFiles );
    LOG.info( "-- ChangeProvider - Found: " + writableFiles.size() + " writable files." );

    if( progress != null )
      progress.setText( VssBundle.message( "message.statusbar.searching.new" ) );
    analyzeNewFiles( path, writableFiles );
  }

  private void collectSuspiciousFiles( final FilePath filePath, final List<String> writableFiles )
  {
    final VssConfiguration config = VssConfiguration.getInstance( project );
    final ProjectFileIndex fileIndex = ProjectRootManager.getInstance( project ).getFileIndex();

    VirtualFile vf = VcsUtil.getVirtualFile( filePath.getPath() );
    if( vf != null )
    {
      fileIndex.iterateContentUnderDirectory( vf, new ContentIterator()
        {
          public boolean processFile( VirtualFile file )
          {
            if( isFileVssProcessable( config, file ) )
            {
              String path = file.getPath();
              writableFiles.add( path );
            }
            return true;
          }
        } );
    }
  }

  private void analyzeNewFiles( FilePath filePath, List<String> writableFiles )
  {
    final List<String> newFiles = new ArrayList<String>();
    final List<String> newFolders = new ArrayList<String>();

    if( writableFiles.size() < PER_FILE_DIFF_MARGIN )
    {
      LOG.info( "rem ChangeProvider - Analyzing writable files on per-file basis" );
      for( String path : writableFiles )
      {
        LOG.info( "rem ChangeProvider - Issue \"PROPERTIES\" command for getting information on writable file" );

        String pathNorm = VssUtil.getCanonicalVssPath( path ).toLowerCase();
        PropertiesCommand cmd = new PropertiesCommand( project, pathNorm, false );
        cmd.execute();

        if( !cmd.isValidRepositoryObject() )
          newFiles.add( path );
        else
          filesChanged.add( path );

        LOG.info( "rem ChangeProvider - \"PROPERTIES\" command finished" );
      }
    }
    else
    {
      LOG.info( "rem ChangeProvider - Analyzing writable files on the base of \"Directory\" command" );

      ArrayList<VcsException> errors = new ArrayList<VcsException>();
      DirectoryCommand cmd = new DirectoryCommand( project, filePath.getPath(), errors );
      cmd.execute();

      for( String path : writableFiles )
      {
        path = path.toLowerCase();
        if( !cmd.projectFiles.contains( path ) )
          newFiles.add( path );
        else
          filesChanged.add( path );
      }
    }

    //  For each new file check whether some subfolders structure above it
    //  is also new.
    final List<String> processedFolders = new ArrayList<String>();
    for( String file : newFiles )
    {
      if( !isPathUnderAbsentFolders( file ))
        analyzeParentFolderStructureForPresence( file, newFolders, processedFolders );
    }

    filesNew.addAll( newFolders );
    filesNew.addAll( newFiles );
  }

  //---------------------------------------------------------------------------
  //  For a given file which is known that it is new, check also its direct
  //  parent folder for presence in the VSS repository, and then all its indirect
  //  parent folders until we reach project boundaries.
  //---------------------------------------------------------------------------
  private void  analyzeParentFolderStructureForPresence( String file, List<String> newFolders,
                                                         List<String> processedFolders )
  {
    String fileParent = new File( file ).getParentFile().getPath();

    if( VssUtil.isPathUnderProject( project, fileParent ) && !processedFolders.contains( fileParent ) )
    {
      LOG.info( "rem ChangeProvider - Issue \"PROPERTIES\" command for getting information on potentially new folder" );

      processedFolders.add( fileParent );
      String fileParentCanonical = VssUtil.getCanonicalLocalPath( fileParent );
      PropertiesCommand cmd = new PropertiesCommand( project, fileParentCanonical, true );
      cmd.execute();
      LOG.info( "rem ChangeProvider - \"PROPERTIES\" command finished" );

      if( !cmd.isValidRepositoryObject() )
      {
        newFolders.add( fileParentCanonical );
        foldersAbcent.add( fileParent );

        analyzeParentFolderStructureForPresence( fileParent, newFolders, processedFolders );
      }
    }
  }
  /**
   *  Deleted and New folders are marked as dirty too and we provide here
   *  special processing for them.
   */
  private void iterateOverDirtyDirectories( final VcsDirtyScope dirtyScope )
  {
    for( FilePath path : dirtyScope.getDirtyFiles() )
    {
      if( path.isDirectory() )
      {
        LOG.info( "  Found dirty directory in the list of dirty files: " + path.getPath() );
        iterateOverProjectPath( path );
      }
    }
  }

  private void iterateOverDirtyFiles( final VcsDirtyScope scope )
  {
    final VssConfiguration config = VssConfiguration.getInstance( project );
    for( FilePath path : scope.getDirtyFiles() )
    {
      //-----------------------------------------------------------------------
      //  Do not process files which have RO status at all.
      //  Generally it means that all files which were got through some sort of
      //  "Get Latest Version" or "Update" are not processed at all, especially
      //  since there is no necessity in that. All other cases - modified and
      //  new files are processed as usual.
      //-----------------------------------------------------------------------
      VirtualFile file = VcsUtil.getVirtualFile( path.getPath() );
      String fileName = VssUtil.getCanonicalLocalPath( path.getPath() );

      if( isFileVssProcessable( config, file ) )
      {
        if( isProperNotification( path ) )
        {
          if( isPathUnderAbsentFolders( fileName ) )
          {
            filesNew.add( fileName );
          }
          else
          {
            String pathNorm = VssUtil.getCanonicalVssPath( path.getPath() ).toLowerCase();
            PropertiesCommand cmd = new PropertiesCommand( project, pathNorm, false );
            cmd.execute();

            if( !cmd.isValidRepositoryObject() )
              filesNew.add( fileName );
            else
              filesChanged.add( fileName );
          }
        }
      }
    }
  }

  public List<VcsException> commit(List<Change> changes, String comment)
  {
    List<VcsException> errors = new ArrayList<VcsException>();
    HashSet<FilePath> processedFiles = new HashSet<FilePath>();

    try
    {
      host.startTransaction();
      commitNew( changes, processedFiles );
      commitChanged( changes, processedFiles );
      host.commitTransaction( comment, errors );
    }
    catch( VcsException e )
    {
      errors.add( e );
    }

    for( FilePath path : processedFiles )
    {
      VcsUtil.markFileAsDirty(project, path);
    }
    return errors;
  }

  /**
   *  Add all folders first, then add all files into these folders.
   *  Difference between added and modified files is that added file
   *  has no "before" revision.
   */
  private void commitNew( List<Change> changes, HashSet<FilePath> processedFiles ) throws VcsException
  {
    ArrayList<FilePath> folders = new ArrayList<FilePath>();
    ArrayList<FilePath> files = new ArrayList<FilePath>();
    for( Change change : changes )
    {
      if( VcsUtil.isChangeForNew( change ) )
      {
        FilePath filePath = change.getAfterRevision().getFile();
        if( filePath.isDirectory() )
          folders.add( filePath );
        else
          files.add( filePath );
        processedFiles.add( filePath );
      }
    }

    FilePath[] folderPathsSorted = folders.toArray( new FilePath[ folders.size() ] );
    Arrays.sort( folderPathsSorted, new Comparator<FilePath>() {
     public int compare(FilePath o1, FilePath o2) {
        return o1.getPath().compareTo( o2.getPath() );
      }
    });
    for( FilePath folder : folderPathsSorted )
      host.addDirectory( folder.getVirtualFileParent().getPath(), folder.getName(), null, null );

    for( FilePath file : files )
      host.addFile( file.getVirtualFileParent().getPath(), file.getName(), null, null );
  }

  private void commitChanged( List<Change> changes, HashSet<FilePath> processedFiles ) throws VcsException
  {
    for( Change change : changes )
    {
      FilePath file = change.getAfterRevision().getFile();
      ContentRevision before = change.getBeforeRevision();

      if( !VcsUtil.isChangeForNew( change ) )
      {
        String newPath = VssUtil.getCanonicalLocalPath( file.getPath() );
        String oldPath = host.renamedFiles.get( newPath );
        if( oldPath != null )
        {
          FilePath oldFile = before.getFile();
          String prevPath = VssUtil.getCanonicalLocalPath( oldFile.getPath() );

          //  If parent folders' names of the revisions coinside, then we
          //  deal with the simle rename, otherwise we process full-scaled
          //  file movement across folders (packages).

          if( oldFile.getVirtualFileParent().getPath().equals( file.getVirtualFileParent().getPath() ))
          {
            host.renameAndCheckInFile( prevPath, file.getName(), null );
          }
          else
          {
            String newFolder = VssUtil.getCanonicalLocalPath( file.getVirtualFileParent().getPath() );
            host.moveRenameAndCheckInFile( prevPath, newFolder, file.getName(), null );
          }
          host.renamedFiles.remove( newPath );
        }
        else
        {
          host.checkinFile( file.getPath(), null, null );
        }

        processedFiles.add( file );
      }
    }
  }

  public List<VcsException> rollbackChanges( List<Change> changes )
  {
    List<VcsException> errors = new ArrayList<VcsException>();
    HashSet<FilePath> processedFiles = new HashSet<FilePath>();

    host.startTransaction();
    rollbackNew( changes, processedFiles );
    rollbackChanged( changes, processedFiles, errors );
    host.commitTransaction( null, errors );

    for( FilePath path : processedFiles )
      VcsUtil.markFileAsDirty(project, path);

    return errors;
  }

  private static void rollbackNew( List<Change> changes, HashSet<FilePath> processedFiles )
  {
    ArrayList<FilePath> folders = new ArrayList<FilePath>();
    ArrayList<FilePath> files = new ArrayList<FilePath>();
    for( Change change : changes )
    {
      if( VcsUtil.isChangeForNew( change ) )
      {
        FilePath filePath = change.getAfterRevision().getFile();
        if( filePath.isDirectory() )
          folders.add( filePath );
        else
          files.add( filePath );
        processedFiles.add( filePath );
      }
    }

    for( FilePath file : files )
      new File( file.getPath() ).delete();

    //  Sort folders in descending order - from the most inner folder
    //  to the outmost one.
    FilePath[] folderPathsSorted = folders.toArray( new FilePath[ folders.size() ] );
    Arrays.sort( folderPathsSorted, new Comparator<FilePath>() {
     public int compare(FilePath o1, FilePath o2) {
        return -o1.getPath().compareTo( o2.getPath() );
      }
    });
    for( FilePath folder : folders )
      FileUtil.delete( new File( folder.getPath() ) );
  }

  private void rollbackChanged( List<Change> changes, HashSet<FilePath> processedFiles, List<VcsException> errors )
  {
    ArrayList<String> rollbacked = new ArrayList<String>();
    for( Change change : changes )
    {
      if( !VcsUtil.isChangeForNew( change ) )
      {
        FilePath filePath = change.getAfterRevision().getFile();
        String path = filePath.getPath();

        if( VcsUtil.isRenameChange( change ) )
        {
          //  Track two different cases:
          //  - we delete the file which is already in the repository.
          //    Here we need to "Get" the latest version of the original
          //    file from the repository and delete the new file.
          //  - we delete the renamed file which is new and does not exist
          //    in the repository. We need to ignore the error message from
          //    the SourceSafe ("file not existing") and just delete the
          //    new file.

          List<VcsException> localErrs = new ArrayList<VcsException>();
          FilePath oldFile = change.getBeforeRevision().getFile();

          boolean renameNonexistingFile = host.getLatestVersion( oldFile.getPath(), null, null, localErrs );
          if( !renameNonexistingFile )
            errors.addAll( localErrs );

          host.renamedFiles.remove( filePath.getPath() );
          FileUtil.delete( new File( path ) );
        }
        else
        {
          //  Collect all files to be uncheckouted into one set so that
          //  if dialog popups we could say "Yes to all"
          rollbacked.add( path );
        }
        processedFiles.add( filePath );
      }
    }

    if( rollbacked.size() > 0 )
    {
      String[] files = rollbacked.toArray( new String[ rollbacked.size() ] );
      host.rollbackChanges( files, null, null, errors );
    }
  }

  public List<VcsException> scheduleMissingFileForDeletion( List<FilePath> paths )
  {
    List<File> files = ChangesUtil.filePathsToFiles( paths );
    List<VcsException> errors = new ArrayList<VcsException>();
    host.startTransaction();
    for( File file : files )
    {
      String path = VssUtil.getCanonicalLocalPath( file.getPath() );
      if( host.removedFiles.contains( path ) )
      {
        host.removeFile( path, null, null );
      }
      else
      {
        host.removeDirectory( path, null, null );
      }

      host.removedFiles.remove( path );
      host.removedFolders.remove( path );
    }
    host.commitTransaction( null, errors );
    return errors;
  }

  public List<VcsException> rollbackMissingFileDeletion( List<FilePath> paths )
  {
    VcsDirtyScopeManager mgr = VcsDirtyScopeManager.getInstance( project );
    List<VcsException> errors = new ArrayList<VcsException>();

    for( FilePath filePath : paths )
    {
      File file = filePath.getIOFile();

      //  VSS can not get the content of the directory (subproject) if:
      //  - there is no corresponding local working folder and
      //  - there is no files in that folder.
      //  Thus we need to create this subfolder anyway, set it as the working folder
      //  and only after that issue "Get latest version".
      String path = VssUtil.getCanonicalLocalPath( file.getPath() );
      if( host.removedFolders.contains( path ))
      {
        //  In order for the "GetFileCommand" to retrieve the folder, it must
        //  already exist so that we correctly determine the working folder
        //  (it is a parent for the file and a folder itself for a particular
        //  folder).
        file.mkdir();
      }

      host.rollbackDeleted( file.getPath(), null, null, errors );
      mgr.fileDirty( filePath );
    }
    return errors;
  }

  public List<VcsException> scheduleUnversionedFilesForAddition( List<VirtualFile> files )
  {
    VcsDirtyScopeManager mgr = VcsDirtyScopeManager.getInstance( project );

    for( VirtualFile file : files )
    {
      host.add2NewFile( file );
      mgr.fileDirty( file );
      file.refresh( true, true );
    }
    // Keep intentionally empty.
    return new ArrayList<VcsException>();
  }

  public boolean isModifiedDocumentTrackingRequired() {
    return false;
  }

  private void addNewOrRenamedFiles( final ChangelistBuilder builder )
  {
    for( String path : filesNew )
    {
      if( VssUtil.isPathUnderProject( project, path ) )
      {
        FilePath newFP = VcsUtil.getFilePath( path );
        String   oldName = host.renamedFiles.get( VssUtil.getCanonicalLocalPath( path ) );
        if( host.containsNew( path ) )
        {
          builder.processChange( new Change( null, new CurrentContentRevision( newFP ) ));
        }
        else
        if( oldName == null )
        {
          VirtualFile vFile = VssUtil.getVirtualFile( path );
          builder.processUnversionedFile( vFile );
        }
        else
        {
          ContentRevision before = new CurrentContentRevision( VcsUtil.getFilePath( oldName ) );
          builder.processChange( new Change( before, new CurrentContentRevision( newFP )));
        }
      }
    }
  }

  private void addChangedFiles( final ChangelistBuilder builder )
  {
    for( String path : filesChanged )
    {
      final FilePath fp = VcsUtil.getFilePath( path );
      builder.processChange( new Change( new VssRevision( fp, project ), new CurrentContentRevision( fp )));
    }
  }

  private void addRemovedFiles( final ChangelistBuilder builder )
  {
    for( String path : host.removedFolders )
      builder.processLocallyDeletedFile( VcsUtil.getFilePath( path ) );

    for( String path : host.removedFiles )
      builder.processLocallyDeletedFile( VcsUtil.getFilePath( path ) );
  }

  private boolean isPathUnderAbsentFolders( String pathToCheck )
  {
    for( String path : foldersAbcent )
    {
      if( pathToCheck.startsWith( path ) )
        return true;
    }
    return false;
  }

  private boolean isRenamedFile( String file )
  {
    return (host.renamedFiles.get( VssUtil.getCanonicalLocalPath( file ) ) != null);
  }

  /**
   * For the renamed or moved file we receive two change requests: one for
   * the old file and one for the new one. For renamed file old request differs
   * in filename, for the moved one - in parent path name. This request must be
   * ignored since all preliminary information is already accumulated.
   */
  private static boolean isProperNotification( final FilePath filePath )
  {
    String oldName = filePath.getName();
    String newName = (filePath.getVirtualFile() == null) ? "" : filePath.getVirtualFile().getName();
    String oldParent = (filePath.getVirtualFileParent() == null) ? "" : filePath.getVirtualFileParent().getPath();
    String newParent = filePath.getPath().substring( 0, filePath.getPath().length() - oldName.length() - 1 );
    newParent = VssUtil.getCanonicalLocalPath( newParent );

    //  Check the case when the file is deleted - its FilePath's VirtualFile
    //  component is null and thus new name is empty.
    return newParent.equals( oldParent ) &&
          ( newName.equals( oldName ) || (newName == "" && oldName != "") );
  }

  private void initInternals()
  {
    filesNew.clear();
    filesChanged.clear();
    foldersAbcent.clear();
  }

  private boolean isFileVssProcessable( VssConfiguration config, VirtualFile file )
  {
    return (file != null) && file.isWritable() && !file.isDirectory() &&
           VssUtil.isPathUnderProject( project, file.getPath() ) &&
           VssUtil.isUnderVss( file, project ) &&
           !config.isFileExcluded( file.getName() );
  }

  private static class VssRevision implements ContentRevision
  {
    @NonNls private static final String _GWR_OPTION = "-GWR";
    @NonNls private static final String _GL_OPTION = "-GL";
    @NonNls private static final String GET_COMMAND = "Get";
    @NonNls private static final String TMP_FILE_NAME = "idea_vss";

    private VirtualFile file;
    private FilePath    revisionPath;
    private Project     project;
    private File        myTmpFile;
    private String      myServerContent;

    public VssRevision( FilePath path, Project proj )
    {
      revisionPath = path;
      project = proj;

      file = path.getVirtualFile();
    }

    public String getContent()
    {
      if( myServerContent == null )
        myServerContent = getServerContent();

      return myServerContent;
    }

    private String getServerContent()
    {
      List<VcsException> errors = new ArrayList<VcsException>();
      GetContentListener listener = new GetContentListener( errors );

      //  For files which are in the project but reside outside the repository
      //  root their base revision version content is not defined (NULL).

      if( VssUtil.isUnderVss( file, project ))
      {
        VssConfiguration config = VssConfiguration.getInstance( project );
        try
        {
          // The name of temporary copy is the name of temporary directory concatenated
          // with the name of file.
          File tmpFile = File.createTempFile( TMP_FILE_NAME, "." + file.getExtension() );
          tmpFile.deleteOnExit();
          File tmpDir = tmpFile.getParentFile();
          myTmpFile = new File( tmpDir, file.getName() );
          myTmpFile.deleteOnExit();

          // Launch Get command to store temporary file.
          LinkedList<String> options = new LinkedList<String>();
          options.add( GET_COMMAND );
          options.add( VssUtil.getVssPath( file, project ));
          options.add( _GL_OPTION + tmpDir.getCanonicalPath() );
          options.add( _GWR_OPTION );
          if( config.USER_NAME.length() > 0 )
            options.add( config.getYOption() );

          VSSExecUtil.runProcess( config.CLIENT_PATH, options.toArray(new String[options.size()]), config.getSSDIREnv(),
                                  file.getParent().getPath().replace('/', File.separatorChar), listener );
          options.clear();
        }
        catch( Exception exc )
        {
          VssUtil.showErrorOutput( exc.getMessage(), project );
        }
      }

      return listener.content;
    }

    @NotNull public VcsRevisionNumber getRevisionNumber()  {  return VcsRevisionNumber.NULL;   }
    @NotNull public FilePath getFile()                     {  return revisionPath; }

    private class GetContentListener extends VssOutputCollector
    {
      @NonNls private static final String DELETED_MESSAGE = "has been deleted";
      @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";

      public String content = null;

      public GetContentListener( List<VcsException> errors ) { super( errors ); }

      public void everythingFinishedImpl()
      {
        final String out = getCmdOutput();

        if( VssUtil.EXIT_CODE_FAILURE == getExitCode() )
        {
          ApplicationManager.getApplication().invokeLater( new Runnable() { public void run() { VssUtil.showErrorOutput( out, project ); } });
        }
        else
        if(( out.indexOf( DELETED_MESSAGE ) == -1 ) && ( out.indexOf( NOT_EXISTING_MESSAGE ) == -1 ))
        {
          content = ApplicationManager.getApplication().runReadAction( new Computable<String>()
            {
              public String compute() {
                VirtualFile vFile = VssUtil.getVirtualFile( myTmpFile.getPath() );
                final Document doc = FileDocumentManager.getInstance().getDocument( vFile );
                return doc.getText();
              }
            });
        }
      }
    }
  }
}
