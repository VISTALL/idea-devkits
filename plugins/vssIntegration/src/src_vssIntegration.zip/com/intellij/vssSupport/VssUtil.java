package com.intellij.vssSupport;

import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vcs.ProjectLevelVcsManager;
import com.intellij.openapi.vfs.VfsUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.wm.WindowManager;
import com.intellij.vcsUtil.VcsUtil;

import javax.swing.*;
import java.io.File;

/**
 * @author Vladimir Kondratyev
 */
public class VssUtil extends VcsUtil
{
  private static final char[] ourCharsToBeChopped = new char[]{'/', '\\'};

  /**
   * Something went wrong. For example, VSS could not find its data files, or a
   * file you want to check out is already checked out.
   */
  public static final int EXIT_CODE_FAILURE = 100;
  /**
   * Indicates a milder sort of failure, and occurs in three circumstances:
   * When you run ss Dir and no items are found. When you run ss Status and at
   * least one item is checked out. When you run ss Diff, and at least one
   * file is different. All of these circumstances indicate that your next VSS
   * command may fail, even though this command ran successfully.
   */
  public static final int EXIT_CODE_WARNING = 1;
  /**
   * VSS executed successfully.
   */
  public static final int EXIT_CODE_SUCCESS = 0;
  public static final VirtualFile[] ourEmptyVirtualFileArray = new VirtualFile[]{};

  public static String getCanonicalVssPath(String vssPath) {
    vssPath = VssUtil.chopTrailingChars(vssPath.trim().replace('\\', '/').toLowerCase(), ourCharsToBeChopped);
    if ("$".equals(vssPath)) {
      vssPath = "$/";
    }
    return vssPath;
  }

  public static String getCanonicalLocalPath(String localPath) {
    localPath = VssUtil.chopTrailingChars(localPath.trim().replace('\\', '/'), ourCharsToBeChopped);
    if (localPath.length() == 2 && localPath.charAt(1) == ':') {
      localPath += '/';
    }
    return localPath;
  }

  /**
   * @return string without all specified chars at the end. For example,
   *         <code>chopTrailingChars("c:\\my_directory\\//\\",new char[]{'\\'}) is <code>"c:\\my_directory\\//"</code>,
   *         <code>chopTrailingChars("c:\\my_directory\\//\\",new char[]{'\\','/'}) is <code>"c:\my_directory"</code>.
   *         Actually this method can be used to normalize file names to chop trailing separator chars.
   */
  public static String chopTrailingChars(String source, char[] chars) {
    StringBuffer sb = new StringBuffer(source);
    while (true) {
      boolean atLeastOneCharWasChopped = false;
      for (int i = 0; i < chars.length && sb.length() > 0; i++) {
        if (sb.charAt(sb.length() - 1) == chars[i]) {
          sb.deleteCharAt(sb.length() - 1);
          atLeastOneCharWasChopped = true;
        }
      }
      if (!atLeastOneCharWasChopped) {
        break;
      }
    }
    return sb.toString();
  }

  /**
   * @return full local path for specified VSS item. Retruns <code>null</code>
   *         if local path cannot be resolved.
   */
  public static String getLocalPath(String vssPath, Project project) {
    MapItem nearestItem = getNearestMapItemForVssPath(vssPath, project);
    if (nearestItem == null) {
      return null;
    }
    String pathDifference = vssPath.substring(nearestItem.VSS_PATH.length());
    StringBuffer sb = new StringBuffer(nearestItem.LOCAL_PATH);
    if (!StringUtil.endsWithChar(nearestItem.LOCAL_PATH, '/')) {
      sb.append("/");
    }
    if (StringUtil.startsWithChar(pathDifference, '/')) {
      if (pathDifference.length() > 1) {
        sb.append(pathDifference.substring(1));
      }
    }
    else {
      sb.append(pathDifference);
    }
    String localPath = sb.toString();
    if (!StringUtil.endsWithChar(localPath, '/')) {
      return localPath.replace('/', File.separatorChar);
    }
    else {
      return localPath.substring(0, localPath.length() - 1).replace('/', File.separatorChar);
    }
  }

  /**
   * @return the nearest mapping for the specified <code>VirtualFile</code>.
   *         Returns <code>null</code> if mapping for the file doesn't exist.
   */
  public static MapItem getNearestMapItemByLocalFile(VirtualFile localFile, Project project) {
    return getNearestMapItemForLocalPath(localFile.getPath(), localFile.isDirectory(), project);
  }

  /**
   * @param localPath local path with UNIX separator chars.
   */
  private static MapItem getNearestMapItemForLocalPath(String localPath, boolean isDirectory, Project project) {
    VssConfiguration config = VssConfiguration.getInstance(project);
    localPath = localPath.toLowerCase();
    if (isDirectory) {
      localPath += "/";
    }
    MapItem nearestItem = null;
    int size = config.getMapItemCount();
    for (int i = 0; i < size; i++) {
      MapItem mapItem = config.getMapItem(i);
      String path = mapItem.LOCAL_PATH.replace('\\', '/').toLowerCase() + "/";
      if (
        localPath.startsWith(path) &&
        (nearestItem == null || nearestItem.LOCAL_PATH.length() < path.length() - 1) // '-1' is because we added "/" to the path
      ) {
        nearestItem = mapItem;
      }
    }
    return nearestItem;
  }

  /**
   * @return nearest <code>MapItem</code> to the specified <code>vssPath</code>. Returns
   *         <code>null</code> if there is no any item found.
   */
  public static MapItem getNearestMapItemForVssPath(String vssPath, Project project) {
    VssConfiguration config = VssConfiguration.getInstance(project);
    vssPath = vssPath.toLowerCase();
    MapItem nearestItem = null;
    int size = config.getMapItemCount();
    for (int i = 0; i < size; i++) {
      MapItem mapItem = config.getMapItem(i);
      if (
        StringUtil.startsWithIgnoreCase(vssPath, mapItem.VSS_PATH) &&
        (nearestItem == null || nearestItem.VSS_PATH.length() < mapItem.VSS_PATH.length())
      ) {
        nearestItem = mapItem;
      }
    }
    return nearestItem;
  }

  public static VirtualFile[] getPreferredFilesForRefresh(VirtualFile[] files) {
    if (files.length == 0) {
      return ourEmptyVirtualFileArray;
    }
    else if (files.length == 1) {
      return files;
    }
    return VfsUtil.getCommonAncestors(files);
  }

  /**
   * @return VSS path for stored in the Vss config file. Since it is
   *         common for all modules in the project we need to address
   *         the first map item in the configuration store.
   */
  public static String  getCommonVssPath( VssConfiguration config )
  {
    String  path = null;
    int  itemsCount = config.getMapItemCount();
    if( itemsCount > 0 )
    {
      path = config.getMapItem( 0 ).VSS_PATH;
    }
    return path;
  }

  /**
   * @return VSS path for the specified local file or <code>null</code> if
   *         the file isn't under VSS control.
   */
  public static String getVssPath(File localFile, Project project) {
    return getVssPathForLocalPath(localFile.getAbsolutePath().replace('\\', '/'), localFile.isDirectory(), project);
  }

  /**
   * @return VSS path for the specified virtual file or <code>null</code>
   *         if virtual file isn't under VSS control.
   */
  public static String getVssPath(VirtualFile localFile, Project project) {
    return getVssPathForLocalPath(getPath(localFile), localFile.isDirectory(), project);
  }

  /**
   * @param localPath local path with UNIX separator chars.
   */
  public static String getVssPathForLocalPath(String localPath, boolean isDirectory, Project project) {
    MapItem nearestItem = getNearestMapItemForLocalPath(localPath, isDirectory, project);
    if (nearestItem == null) {
      return null;
    }
    String pathDifference = localPath.substring(nearestItem.LOCAL_PATH.length()).replace('\\', '/');
    StringBuffer vssPath = new StringBuffer(nearestItem.VSS_PATH);
    if (!StringUtil.endsWithChar(nearestItem.VSS_PATH, '/')) {
      vssPath.append('/');
    }
    if (StringUtil.startsWithChar(pathDifference, '/')) {
      if (pathDifference.length() > 1) {
        vssPath.append(pathDifference.substring(1));
      }
    }
    else {
      vssPath.append(pathDifference);
    }
    return vssPath.toString();
  }

  /**
   * @return <code>true</code> if and only if the specified file can be under
   *         VSS control. It means that VSS intergation is enabled and the file is located
   *         in the one of the mapped working folders.
   */
  public static boolean isUnderVss(VirtualFile virtualFile, Project project) {
    if (!ProjectLevelVcsManager.getInstance(project).checkAllFilesAreUnder(VssVcs.getInstance(project), new VirtualFile[]{virtualFile})){
      return false;
    }
    return getNearestMapItemByLocalFile(virtualFile, project) != null;
  }

  public static boolean isUnderVss( String path, Project project)
  {
    VirtualFile file = VssUtil.getVirtualFile( path );
    return isUnderVss( file, project );
  }

  /**
   * Shows error message with specified message text and title.
   * The parent component is the root frame.
   */
  public static void showErrorMessage( final Project project, final String message, final String title )
  {
    if( ApplicationManager.getApplication().isDispatchThread() )
      Messages.showMessageDialog( project, message, title, Messages.getErrorIcon());
    else
      ApplicationManager.getApplication().invokeLater( new Runnable()
      {
        public void run() { Messages.showMessageDialog( project, message, title, Messages.getErrorIcon()); }
      });
  }

  public static void showErrorOutput(String message, Project project) {
    showErrorMessage(project, VssBundle.message("message.text.operation.failed", message), VssBundle.message("message.title.execution.error"));
  }

  public static String escapeQuotes(String str) {
    if (str == null) return str;
    int idx = str.indexOf('"');
    if (idx < 0) return str;
    StringBuffer buf = new StringBuffer(str);
    while (idx < buf.length()) {
      if (buf.charAt(idx) == '"') {
        buf.replace(idx, idx + 1, "\\\"");
        idx += 2;
      }
      else {
        idx += 1;
      }
    }
    return buf.toString();
  }

  /**
   * @return <code>VirtualFile</code> available in the current context.
   *         Returns not <code>null</code> if and only if exectly one file is available.
   */
  public static VirtualFile getVirtualFile(DataContext dataContext) {
    VirtualFile[] files = getVirtualFiles(dataContext);
    if (files.length != 1) {
      return null;
    }
    else {
      return files[0];
    }
  }

  /**
   * @return <code>VirtualFile</code>s available in the current context.
   *         Returns empty array if there are no available files.
   */
  public static VirtualFile[] getVirtualFiles(DataContext dataContext) {
    VirtualFile[] virtualFiles = (VirtualFile[])dataContext.getData(DataConstants.VIRTUAL_FILE_ARRAY);
    if (virtualFiles == null) {
      virtualFiles = ourEmptyVirtualFileArray;
    }
    return virtualFiles;
  }

  /**
   * Shows message in the status bar.
   */
  public static void showStatusMessage(final Project project, final String message) {
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        if (project.isOpen()) {
          WindowManager.getInstance().getStatusBar(project).setInfo(message);
        }
      }
    });
  }

  public static String getPath(final VirtualFile file) {
    return ApplicationManager.getApplication().runReadAction(new Computable<String>() {
      public String compute() {
        return file.getPath();
      }
    });
  }
}
