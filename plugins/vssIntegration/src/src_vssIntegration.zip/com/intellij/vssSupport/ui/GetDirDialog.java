/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport.ui;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.vssSupport.GetOptions;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssVcs;

import javax.swing.*;
import java.awt.*;

public class GetDirDialog extends CommandDialog
{
  private static final Logger LOG=Logger.getInstance("#com.intellij.vssSupport.ui.GetDirDialog");

  // UI controls.
  private JComboBox myComboBoxReplaceWritable;
  private JCheckBox myCheckBoxRecursive;
  private JCheckBox myCheckBoxMakeWritable;

  public GetDirDialog(Project project){
    super(project);
    init();
  }

  /**
   * GetDirDialog is used for "Update Project" operation as well. For this
   * particular operation several options must be prepared consistently to
   * the operation logics:
   * - It is always done recursively
   * - It uses "Skip" variant for interacting with user when dealing with
   *   writable files.
   * - Writable files are not ignored (and are not replaced).
   */
  public void makeConsistentForUpdateProject()
  {
    if( myCheckBoxRecursive != null )
    {
      myCheckBoxRecursive.setSelected( true );
      myCheckBoxRecursive.setEnabled( false );
    }
    
    if( myComboBoxReplaceWritable != null )
    {
      myComboBoxReplaceWritable.setSelectedIndex( 2 );
      myComboBoxReplaceWritable.setEnabled( false );
    }

    if( myCheckBoxMakeWritable != null )
    {
      myCheckBoxMakeWritable.setSelected( false );
      myCheckBoxMakeWritable.setEnabled( false );
    }
  }

  /**
   * Stores edited data into the passed data holder.
   */
  public void commit( GetOptions options )
  {
    int idx=myComboBoxReplaceWritable.getSelectedIndex();
    if(idx==0){
      options.REPLACE_WRITABLE=GetOptions.OPTION_ASK;
    }else if(idx==1){
      options.REPLACE_WRITABLE=GetOptions.OPTION_REPLACE;
    }else if(idx==2){
      options.REPLACE_WRITABLE=GetOptions.OPTION_SKIP;
    }else{
      LOG.error("Unknown idx: "+idx);
    }
    options.RECURSIVE=myCheckBoxRecursive.isSelected();
    options.MAKE_WRITABLE=myCheckBoxMakeWritable.isSelected();
    VssVcs.getInstance(options.getVssConfiguration().getProject()).getGetOptions().setValue(!myCheckBoxDoNotShowDialog.isSelected());
  }

  protected JComponent createCenterPanel(){
    JPanel panel=new JPanel(new GridBagLayout());

    // "Replace writable"

    JLabel label=new JLabel(VssBundle.message("label.get.options.replace.writable"));
    label.setLabelFor(myComboBoxReplaceWritable.getEditor().getEditorComponent());
    panel.add(
      label,
      new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,5,0),0,0)
    );
    panel.add(
      myComboBoxReplaceWritable,
      new GridBagConstraints(1,0,1,1,1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,10,5,0),0,0)
    );

    // "Recursive"

    panel.add(
      myCheckBoxRecursive,
      new GridBagConstraints(0,1,2,1,1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,5,0),0,0)
    );

    // "Make writable"

    myCheckBoxMakeWritable.setPreferredSize(new Dimension(280,20));
    panel.add(
      myCheckBoxMakeWritable,
      new GridBagConstraints(0,2,2,1,1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,5,0),0,0)
    );

    return panel;
  }

  protected void init(){
    myComboBoxReplaceWritable=new JComboBox(
      new DefaultComboBoxModel(
        new String[]{VssBundle.message("combo.replace.policy.ask"),
          VssBundle.message("combo.options.replace.policy.replace"),
          VssBundle.message("combo.options.replace.policy.skip")}
      )
    );
    myCheckBoxRecursive=new JCheckBox(VssBundle.message("checkbox.checkout.dir.options.recursive"));
    myCheckBoxMakeWritable=new JCheckBox(VssBundle.message("checkbox.get.optiond.make.writable"));
    super.init();
  }

  /**
   * Initialize dialog with the data.
   */
  public void init(GetOptions options){
    if(GetOptions.OPTION_ASK==options.REPLACE_WRITABLE){
     myComboBoxReplaceWritable.setSelectedIndex(0);
    }else if(GetOptions.OPTION_REPLACE==options.REPLACE_WRITABLE){
      myComboBoxReplaceWritable.setSelectedIndex(1);
    }else if(GetOptions.OPTION_SKIP==options.REPLACE_WRITABLE){
      myComboBoxReplaceWritable.setSelectedIndex(2);
    }else{
      LOG.error("Unknown REPLACE_WRITABLE: "+options.REPLACE_WRITABLE);
    }
    myCheckBoxRecursive.setSelected(options.RECURSIVE);
    myCheckBoxMakeWritable.setSelected(options.MAKE_WRITABLE);
    myCheckBoxDoNotShowDialog.setSelected(!VssVcs.getInstance(options.getVssConfiguration().getProject()).getGetOptions().getValue());
  }

}