/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport.ui;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsConfiguration;
import com.intellij.vssSupport.CheckoutOptions;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssVcs;

import javax.swing.*;
import java.awt.*;

public class CheckoutDirDialog extends CommandDialog
{
  // UI controls.
  private JTextArea myTextAreaComment;
  private JCheckBox myCheckBoxRecursive;
  private Project myProject;

  public CheckoutDirDialog(Project project){
    super(project);
    myProject = project;
    init();
  }

  protected String getDimensionServiceKey(){
    return "#com.intellij.vssSupport.ui.CheckoutDirDialog";
  }

  /**
   * Stores edited data into the passed data holder.
   */
  public void commit( CheckoutOptions options ){
    options.COMMENT=myTextAreaComment.getText().trim();
    options.RECURSIVE=myCheckBoxRecursive.isSelected();
    VssVcs.getInstance(myProject).getCheckoutOptions().setValue(!myCheckBoxDoNotShowDialog.isSelected());
  }

  protected JComponent createCenterPanel()
  {
    JPanel panel = new JPanel(new GridBagLayout());

    // "Comment"

    JLabel lblComment = new JLabel(VssBundle.message("label.checkout.dir.options.comment"));
    lblComment.setLabelFor(myTextAreaComment);
    panel.add( lblComment,
               new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,new Insets(0,0,3,5),0,0) );

    JScrollPane scrollPane = new JScrollPane( myTextAreaComment );
    scrollPane.setPreferredSize( new Dimension(250,70) );
    panel.add( scrollPane,
               new GridBagConstraints(0,1,1,1,1,1,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,5,0),0,0) );

    // "Recursive"

    panel.add( myCheckBoxRecursive,
               new GridBagConstraints(0,2,1,1,1,0,GridBagConstraints.WEST,GridBagConstraints.NONE,new Insets(0,0,5,0),0,0) );

    return panel;
  }

  public JComponent getPreferredFocusedComponent(){
    return VcsConfiguration.getInstance(myProject).PUT_FOCUS_INTO_COMMENT?myTextAreaComment:null;
  }

  protected void init(){
    myTextAreaComment = new JTextArea();
    myCheckBoxRecursive = new JCheckBox(VssBundle.message("checkbox.checkout.dir.options.recursive"));
    super.init();
  }

  /**
   * Initialize dialog with the data.
   */
  public void init( CheckoutOptions options )
  {
    myTextAreaComment.setText( VcsConfiguration.getInstance(myProject).SAVE_LAST_COMMIT_MESSAGE ? options.COMMENT : null );
    myCheckBoxRecursive.setSelected( options.RECURSIVE );
    myCheckBoxDoNotShowDialog.setSelected( !VssVcs.getInstance(myProject).getCheckoutOptions().getValue() );
  }

}
