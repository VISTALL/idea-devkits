/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport.ui;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsConfiguration;
import com.intellij.vssSupport.CheckoutOptions;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssVcs;

import javax.swing.*;
import java.awt.*;

public class CheckoutFilesDialog extends CommandDialog{

  // UI controls.
  private JTextArea myTextAreaComment;
  private Project myProject;

  public CheckoutFilesDialog(Project project){
    super(project);
    myProject = project;
    init();
  }

  protected String getDimensionServiceKey(){
    return "#com.intellij.vssSupport.ui.CheckoutFilesDialog";
  }

  /**
   * Stores edited data into the passed data holder.
   */
  public void commit( CheckoutOptions options ){
    options.COMMENT = myTextAreaComment.getText().trim();
    options.DO_NOT_GET_LATEST_VERSION = false;
    VssVcs.getInstance(myProject).getCheckoutOptions().setValue(!myCheckBoxDoNotShowDialog.isSelected());
  }

  protected JComponent createCenterPanel(){
    JPanel panel=new JPanel(new GridBagLayout());

    // "Comment"

    JLabel lblComment = new JLabel(VssBundle.message("label.checkout.file.options.comment"));
    lblComment.setLabelFor(myTextAreaComment);
    panel.add( lblComment,
               new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,new Insets(0,0,3,5),0,0) );

    JScrollPane scrollPane = new JScrollPane(myTextAreaComment);
    scrollPane.setPreferredSize(new Dimension(250,70));
    panel.add( scrollPane,
               new GridBagConstraints(0,1,1,1,1,1,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,5,0),0,0) );

    return panel;
  }

  public JComponent getPreferredFocusedComponent(){
    return VcsConfiguration.getInstance( myProject ).PUT_FOCUS_INTO_COMMENT ? myTextAreaComment : null;
  }

  protected void init(){
    myTextAreaComment = new JTextArea();
    super.init();
  }

  /**
   * Initialize dialog with the data.
   */
  public void init(CheckoutOptions options)
  {
    myTextAreaComment.setText( VcsConfiguration.getInstance(myProject).SAVE_LAST_COMMIT_MESSAGE ? options.COMMENT : null );
    myCheckBoxDoNotShowDialog.setSelected(!VssVcs.getInstance(myProject).getCheckoutOptions().getValue());
  }

}
