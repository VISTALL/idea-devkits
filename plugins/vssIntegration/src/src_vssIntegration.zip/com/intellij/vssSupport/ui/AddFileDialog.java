/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport.ui;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.ui.IdeBorderFactory;
import com.intellij.vssSupport.AddOptions;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssVcs;

import javax.swing.*;
import java.awt.*;

public class AddFileDialog extends CommandDialog{
  private static final Logger LOG=Logger.getInstance("#com.intellij.vssSupport.ui.AddFileDialog");

  // UI controls.
  private JCheckBox myCheckBoxStoreOnlyLatestVersion;
  private JCheckBox myCheckBoxCheckOutImmediately;
  private JRadioButton myRadioButtonAutoDetect;
  private JRadioButton myRadioButtonBinary;
  private JRadioButton myRadioButtonText;
  private Project myProject;

  public AddFileDialog(Project project){
    super(project);
    myProject = project;
    init();
  }

  protected String getDimensionServiceKey(){
    return "#com.intellij.vssSupport.ui.AddFileDialog";
  }

  /**
   * Stores edited data into the passed data holder.
   */
  public void commit(AddOptions options)
  {
    options.STORE_ONLY_LATEST_VERSION=myCheckBoxStoreOnlyLatestVersion.isSelected();
    options.CHECK_OUT_IMMEDIATELY=myCheckBoxCheckOutImmediately.isSelected();
    if(myRadioButtonAutoDetect.isSelected()){
      options.FILE_TYPE=AddOptions.AUTO_DETECT;
    } else if(myRadioButtonBinary.isSelected()){
      options.FILE_TYPE=AddOptions.BINARY;
    } else if(myRadioButtonText.isSelected()){
      options.FILE_TYPE=AddOptions.TEXT;
    } else{
      LOG.error("Unknown FILE_TYPE: "+options.FILE_TYPE);
    }
    VssVcs.getInstance(myProject).getAddOptions().setValue(!myCheckBoxDoNotShowDialog.isSelected());
  }

  protected JComponent createCenterPanel()
  {
    JPanel panel = new JPanel(new GridBagLayout());

    // Panel with check boxes.

    JPanel panelWithCheckBoxes = new JPanel(new GridBagLayout());
    panelWithCheckBoxes.setBorder(IdeBorderFactory.createTitledBorder(VssBundle.message("border.add.file.options.advanced.options")));
    panelWithCheckBoxes.add(
      myCheckBoxStoreOnlyLatestVersion,
      new GridBagConstraints(0,0,1,1,1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,5,5),0,0)
    );
    panelWithCheckBoxes.add(
      myCheckBoxCheckOutImmediately,
      new GridBagConstraints(0,1,1,1,1,1,GridBagConstraints.NORTHWEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,5,5),0,0)
    );

    // Panel with file type.

    JPanel panelFileType = new JPanel(new GridBagLayout());
    panelFileType.setBorder(IdeBorderFactory.createTitledBorder(VssBundle.message("border.add.file.options.file.type")));
    panelFileType.add( myRadioButtonAutoDetect,
      new GridBagConstraints(0,0,1,1,1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,5,5),0,0)
    );
    panelFileType.add( myRadioButtonBinary,
      new GridBagConstraints(0,1,1,1,1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,5,5),0,0)
    );
    panelFileType.add( myRadioButtonText,
      new GridBagConstraints(0,2,1,1,1,1,GridBagConstraints.NORTHWEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,5,5),0,0)
    );

    panel.add( panelWithCheckBoxes,
      new GridBagConstraints(0,0,1,1,1,1,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,5),0,0)
    );
    panel.add( panelFileType,
      new GridBagConstraints(1,0,1,1,1,1,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0)
    );

    //
    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add( myRadioButtonAutoDetect );
    buttonGroup.add( myRadioButtonBinary );
    buttonGroup.add( myRadioButtonText );

    return panel;
  }

  public JComponent getPreferredFocusedComponent(){
    return myCheckBoxStoreOnlyLatestVersion;
  }

  protected void init()
  {
    myCheckBoxStoreOnlyLatestVersion=new JCheckBox(VssBundle.message("checkbox.option.store.only.latest.version"));
    myCheckBoxCheckOutImmediately=new JCheckBox(VssBundle.message("checkbox.option.check.out.immediately"));
    myRadioButtonAutoDetect=new JRadioButton(VssBundle.message("radio.new.file.type.presentation.auto.detect"));
    myRadioButtonBinary=new JRadioButton(VssBundle.message("radio.new.file.type.presentation.binary"));
    myRadioButtonText=new JRadioButton(VssBundle.message("radio.new.file.type.presentation.text"));
    super.init();
  }

  /**
   * Initialize dialog with the data.
   */
  public void init(AddOptions options)
  {
    myCheckBoxStoreOnlyLatestVersion.setSelected(options.STORE_ONLY_LATEST_VERSION);
    myCheckBoxCheckOutImmediately.setSelected(options.CHECK_OUT_IMMEDIATELY);
    if(options.FILE_TYPE==AddOptions.AUTO_DETECT){
      myRadioButtonAutoDetect.setSelected(true);
    } else if(options.FILE_TYPE==AddOptions.BINARY){
      myRadioButtonBinary.setSelected(true);
    } else if(options.FILE_TYPE==AddOptions.TEXT){
      myRadioButtonText.setSelected(true);
    } else{
      LOG.error("Unknown FILE_TYPE: "+options.FILE_TYPE);
    }
    myCheckBoxDoNotShowDialog.setSelected(!VssVcs.getInstance(myProject).getAddOptions().getValue());
  }

}
