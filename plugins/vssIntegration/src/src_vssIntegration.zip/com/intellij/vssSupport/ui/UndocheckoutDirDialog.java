/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport.ui;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.vssSupport.UndocheckoutOptions;
import com.intellij.vssSupport.VssVcs;
import com.intellij.vssSupport.VssBundle;

import javax.swing.*;
import java.awt.*;

public class UndocheckoutDirDialog extends CommandDialog{
  private static final Logger LOG=Logger.getInstance("#com.intellij.vssSupport.ui.UndocheckoutDirDialog");

  // UI controls.
  private JComboBox myComboBoxReplaceLocalCopy;
  private JCheckBox myCheckBoxRecursive;
  private JCheckBox myCheckBoxMakeWritable;

  public UndocheckoutDirDialog(Project project){
    super(project);
    init();
  }

  /**
   * Stores edited data into the passed data holder.
   */
  public void commit(UndocheckoutOptions options){
    options.RECURSIVE=myCheckBoxRecursive.isSelected();
    options.MAKE_WRITABLE=myCheckBoxMakeWritable.isSelected();
    int idx=myComboBoxReplaceLocalCopy.getSelectedIndex();
    if(idx==0){
      options.REPLACE_LOCAL_COPY=UndocheckoutOptions.OPTION_ASK;
    }else if(idx==1){
      options.REPLACE_LOCAL_COPY=UndocheckoutOptions.OPTION_LEAVE;
    }else if(idx==2){
      options.REPLACE_LOCAL_COPY=UndocheckoutOptions.OPTION_REPLACE;
    }else{
      LOG.error("Unknown idx: "+idx);
    }
    VssVcs.getInstance(options.getVssConfiguration().getProject()).getUndoCheckoutOptions().setValue(!myCheckBoxDoNotShowDialog.isSelected());
  }

  protected JComponent createCenterPanel(){
    JPanel panel=new JPanel(new GridBagLayout());

    // "Local copy"

    JLabel label=new JLabel(VssBundle.message("label.undo.options.replace.local.copy"));
    label.setLabelFor(myComboBoxReplaceLocalCopy.getEditor().getEditorComponent());
    panel.add(
      label,
      new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,5,0),0,0)
    );
    panel.add(
      myComboBoxReplaceLocalCopy,
      new GridBagConstraints(1,0,1,1,1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,10,5,0),0,0)
    );

    // "Recursive"

    panel.add(
      myCheckBoxRecursive,
      new GridBagConstraints(0,1,2,1,1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,5,0),0,0)
    );

    // "Make writable"

    myCheckBoxMakeWritable.setPreferredSize(new Dimension(280,20));
    panel.add(
      myCheckBoxMakeWritable,
      new GridBagConstraints(0,2,2,1,1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,5,0),0,0)
    );

    return panel;
  }

  protected void init(){
    myCheckBoxRecursive=new JCheckBox(VssBundle.message("checkbox.undo.options.recursive"));
    myCheckBoxMakeWritable=new JCheckBox(VssBundle.message("checkbox.undo.optiond.make.writable"));
    myComboBoxReplaceLocalCopy=new JComboBox(
      new DefaultComboBoxModel(
        new String[]{VssBundle.message("combo.replace.policy.ask"),VssBundle.message("combo.undo.options.replace.policy.leave"),VssBundle.message("combo.options.replace.policy.replace")}
      )
    );
    super.init();
  }

  /**
   * Initialize dialog with the data.
   */
  public void init(UndocheckoutOptions options){
    myCheckBoxRecursive.setSelected(options.RECURSIVE);
    myCheckBoxMakeWritable.setSelected(options.MAKE_WRITABLE);
    if(UndocheckoutOptions.OPTION_ASK==options.REPLACE_LOCAL_COPY){
      myComboBoxReplaceLocalCopy.setSelectedIndex(0);
    }else if(UndocheckoutOptions.OPTION_LEAVE==options.REPLACE_LOCAL_COPY){
      myComboBoxReplaceLocalCopy.setSelectedIndex(1);
    }else if(UndocheckoutOptions.OPTION_REPLACE==options.REPLACE_LOCAL_COPY){
      myComboBoxReplaceLocalCopy.setSelectedIndex(2);
    }else{
     LOG.error("Unknown REPLACE_LOCAL_COPY: "+options.REPLACE_LOCAL_COPY);
    }
    myCheckBoxDoNotShowDialog.setSelected(!VssVcs.getInstance(options.getVssConfiguration().getProject()).getUndoCheckoutOptions().getValue());
  }

}