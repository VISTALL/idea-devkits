package com.intellij.vssSupport.ui;

import com.intellij.openapi.fileChooser.FileChooser;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.fileChooser.FileChooserDescriptorFactory;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.ui.FixedSizeButton;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.ui.TextFieldWithBrowseButton;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssUtil;
import com.intellij.vssSupport.VssVcs;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.HashSet;

/**
 * @author Vladimir Kondratyev
 */
public class EditMapItemDialog extends DialogWrapper
{
  // UI controls.
  private JComboBox myTfVssItem;
  private JTextField myTfLocalPath;
  private FixedSizeButton myBtnBrowseLocalPath;
  private Project myProject;
  private VssVcs  host;

  private HashSet<String> usedPaths;

  public EditMapItemDialog( Project project )
  {
    super(project, false);
    myProject = project;
    host = VssVcs.getInstance( project );
    usedPaths = host.getSavedProjectPaths();

    init();
  }

  protected JComponent createCenterPanel()
  {
    JPanel panel = new JPanel( new GridBagLayout() );

    //
    JLabel lblVssItem = new JLabel(VssBundle.message("label.configuration.vss.project"));
    panel.add( lblVssItem,
               new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,new Insets(0,5,3,5),0,0)
    );
    panel.add( myTfVssItem,
               new GridBagConstraints(0,1,2,1,1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,5,5,5),0,0)
    );

    //
    JLabel lblLocalPath=new JLabel(VssBundle.message("label.configuration.working.directory"));
    panel.add( lblLocalPath,
      new GridBagConstraints(0,2,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,new Insets(0,5,3,5),0,0)
    );
    myTfLocalPath.setPreferredSize(new Dimension(350,20));
    panel.add( myTfLocalPath,
      new GridBagConstraints(0,3,1,1,1,0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,new Insets(0,5,10,0),0,0)
    );
    panel.add( myBtnBrowseLocalPath,
      new GridBagConstraints(1,3,1,1,0,0,GridBagConstraints.CENTER,GridBagConstraints.NONE,new Insets(0,0,10,5),0,0)
    );

    //
    myBtnBrowseLocalPath.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent ignored){
          FileChooserDescriptor descriptor = FileChooserDescriptorFactory.createSingleFolderDescriptor();
          VirtualFile[] files = FileChooser.chooseFiles(myProject, descriptor);
          if(files.length != 0){
            myTfLocalPath.setText(files[0].getPath().replace('/',File.separatorChar));
          }
        }
      }
    );
    TextFieldWithBrowseButton.MyDoClickAction.addTo(myBtnBrowseLocalPath, myTfLocalPath);
    //

    return panel;
  }

  public JComponent getPreferredFocusedComponent() {  return myTfVssItem;  }

  /**
   * @return edited <code>VSS_PATH</code>.
   */
//  public String getVssPath() {  return VssUtil.getCanonicalVssPath(myTfVssItem.getText());  }
  public String getVssPath() {  return VssUtil.getCanonicalVssPath( (String)myTfVssItem.getSelectedItem() );  }

  /**
   * @return edited <code>LOCAL_PATH</code>. Returned string has no trailing "/" and "\" characters. All
   * reparators are UNIX separator chars.
   */
  public String getLocalPath() {  return VssUtil.getCanonicalLocalPath(myTfLocalPath.getText());  }

  /**
   * Initializes editor with the passed data.
   */
  public void init( String vssPath, String localPath )
  {
    myTfVssItem.setSelectedItem( vssPath );
    myTfLocalPath.setText( localPath.replace('/',File.separatorChar) );
  }

  protected void init()
  {
    String[] paths = new String[ usedPaths.size() ];
    int index = 0;
    for( String path : usedPaths )
      paths[ index++ ] = path;

    myTfVssItem = new JComboBox( paths );
    myTfVssItem.setEditable( true );
    myTfLocalPath = new JTextField();
    myBtnBrowseLocalPath = new FixedSizeButton( myTfLocalPath );
    super.init();
  }

  protected void doOKAction()
  {
    if( !VssUtil.isPathUnderProject( myProject, myTfLocalPath.getText() ))
    {
      Messages.showMessageDialog( myProject, VssBundle.message( "message.text.configuration.mapping.folder.outside" ),
                                  VssBundle.message( "dialog.title.configuration.edit.mapping" ), Messages.getWarningIcon());
    }

    for( int i = 0; i < myTfVssItem.getItemCount(); i++ )
      host.addSavedProjectPath( (String) myTfVssItem.getItemAt( i ) );
    host.addSavedProjectPath( (String)myTfVssItem.getSelectedItem() );
    
    super.doOKAction();
  }
}
