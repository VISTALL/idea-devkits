/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport.ui;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.vssSupport.VssBundle;

import javax.swing.*;
import java.awt.*;

abstract class CommandDialog extends DialogWrapper{

  protected JCheckBox myCheckBoxDoNotShowDialog;

  protected CommandDialog(Project project){
    super(project, false);
  }

  protected JComponent createSouthPanel(){
    JPanel panel=new JPanel(new BorderLayout());
    panel.add(super.createSouthPanel(),BorderLayout.CENTER);
    panel.add(myCheckBoxDoNotShowDialog,BorderLayout.WEST);
    return panel;
  }

  protected void init(){
    myCheckBoxDoNotShowDialog=new JCheckBox(VssBundle.message("checkbox.skip.this.dialog"));
    super.init();
  }

}
