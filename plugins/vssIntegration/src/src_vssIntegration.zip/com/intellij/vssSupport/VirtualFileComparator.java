/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport;

import com.intellij.openapi.vfs.VirtualFile;

import java.util.Comparator;

public class VirtualFileComparator implements Comparator{

  public static final VirtualFileComparator INSTANCE=new VirtualFileComparator();

  private VirtualFileComparator(){}

  public int compare(Object o1, Object o2){
    String name1=((VirtualFile)o1).getPresentableUrl();
    String name2=((VirtualFile)o2).getPresentableUrl();
    return name1.compareTo(name2);
  }
}
