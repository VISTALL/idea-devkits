/*
 * Created by IntelliJ IDEA.
 * User: mike
 * Date: Sep 16, 2002
 * Time: 2:16:40 PM
 * To change template for new class use
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package com.intellij.vssSupport;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.application.ModalityState;
import com.intellij.openapi.application.PathManager;
import com.intellij.openapi.application.Application;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.localVcs.LocalVcs;
import com.intellij.openapi.localVcs.LocalVcsServices;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.options.Configurable;
import com.intellij.openapi.progress.ProcessCanceledException;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMExternalizable;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vcs.*;
import com.intellij.openapi.vcs.history.VcsHistoryProvider;
import com.intellij.openapi.vcs.changes.ChangeProvider;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vcs.checkin.CheckinEnvironment;
import com.intellij.openapi.vcs.checkin.DifferenceType;
import com.intellij.openapi.vcs.checkin.RevisionsFactory;
import com.intellij.openapi.vcs.ui.Refreshable;
import com.intellij.openapi.vcs.ui.RefreshableOnComponent;
import com.intellij.openapi.vcs.ui.RevisionTreeNode;
import com.intellij.openapi.vcs.update.FileGroup;
import com.intellij.openapi.vcs.update.UpdateEnvironment;
import com.intellij.openapi.vcs.update.UpdateSession;
import com.intellij.openapi.vcs.update.UpdatedFiles;
import com.intellij.openapi.vcs.versions.AbstractRevisions;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.VirtualFileListener;
import com.intellij.util.BooleanValueHolder;
import com.intellij.util.ListWithSelection;
import com.intellij.util.containers.HashSet;
import com.intellij.util.ui.ColumnInfo;
import com.intellij.util.ui.ComboBoxTableCellEditor;
import com.intellij.util.ui.ComboBoxTableCellRenderer;
import com.intellij.vcsUtil.VcsUtil;
import com.intellij.vssSupport.commands.*;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

public class VssVcs extends AbstractVcs
                    implements ProjectComponent, EditFileProvider, JDOMExternalizable
{
  public static final Key<String> FILE_TYPE = new Key<String>("FILE_TYPE");
  public static final ListWithSelection TYPES_LIST = new ListWithSelection(Arrays.asList(AddOptions.AVAILABLE_TYPES),
                                                                           AddOptions.AVAILABLE_TYPES[0]);

  @NonNls private static final String PERSISTENCY_REMOVED_FILE_TAG = "SourceSafePersistencyRemovedFile";
  @NonNls private static final String PERSISTENCY_REMOVED_FOLDER_TAG = "SourceSafePersistencyRemovedFolder";
  @NonNls private static final String PERSISTENCY_RENAMED_FILE_TAG = "SourceSafePersistencyRenamedFile";
  @NonNls private static final String PERSISTENCY_NEW_FILE_TAG = "SourceSafePersistencyNewFile";
  @NonNls private static final String OPTIONS_FOLDER = "VSS";
  @NonNls private static final String OPTIONS_FILE = "projects";
  @NonNls private static final String PATH_DELIMITER = "%%%";

  @NonNls private static final String VSSVER_FILE_SIG = "vssver.scc";
  @NonNls private static final String VSSVER2_FILE_SIG = "vssver2.scc";

  private List<VssCommand> myCommands;
  private List<VssCommand> myCheckinCommands;
  private BooleanValueHolder ignoreAllNotCheckedOutConformations;

  private Collection<File> myDirectoriesSchedulledForDeletion;

  private CheckinEnvironment myCheckinEnvironment;
  private VssChangeProvider  changeProvider;
  private VssFileHistoryProvider historyProvider;
  private VirtualFileListener listener;

  private VcsShowSettingOption myAddOptions;
  private VcsShowSettingOption myCheckoutOptions;
  private VcsShowSettingOption myUndoCheckoutOptions;
  private VcsShowSettingOption myCompareOptions;
  private VcsShowSettingOption myGetOptions;
  private HashSet<String>      savedProjectPaths;

  public  HashSet<String> removedFiles;
  public  HashSet<String> removedFolders;
  private HashSet<String> newFiles;
  public  HashMap<String, String> renamedFiles;

  @SuppressWarnings({"UnusedDeclaration"})
  public VssVcs(Project project, LocalVcsServices localVcsServices)
  {
    super( project );

    myCheckinEnvironment = new VssCheckinEnvironment( this, localVcsServices );
    changeProvider = new VssChangeProvider( project, this );
    historyProvider = new VssFileHistoryProvider( project );

    removedFiles = new HashSet<String>();
    removedFolders = new HashSet<String>();
    renamedFiles = new HashMap<String, String>();
    newFiles = new HashSet<String>();
    savedProjectPaths = new HashSet<String>();
  }

  public VcsShowSettingOption getCheckoutOptions()     {  return myCheckoutOptions;  }
  public VcsShowSettingOption getAddOptions()          {  return myAddOptions;       }
  public VcsShowSettingOption getUndoCheckoutOptions() {  return myUndoCheckoutOptions;  }
  public VcsShowSettingOption getCompareOptions()      {  return myCompareOptions;   }
  public VcsShowSettingOption getGetOptions()          {  return myGetOptions;       }

  public void   initComponent()     {}
  public void   disposeComponent()  {  myCheckinEnvironment = null;  }
  public String getName()           {  return "SourceSafe";  }
  public String getDisplayName()    {  return "SourceSafe";  }
  public String getRequestText()    {  return VssBundle.message("edit.file.confirmation.text"); }
  public String getMenuItemText()   {  return VssBundle.message("menu.item.source.safe.group.name"); }
  private Project getProject()      {  return myProject;  }

  public static VssVcs getInstance(Project project) {  return project.getComponent(VssVcs.class);  }

  public boolean supportsMarkSourcesAsCurrent()  {  return true;  }
  public boolean markExternalChangesAsUpToDate() {  return true;  }
  @NotNull
  public String getComponentName()  {  return "VssVcs";  }

  public Configurable         getConfigurable()         {  return new VssConfigurable( myProject );  }
  public CheckinEnvironment   getCheckinEnvironment()   {  return myCheckinEnvironment;  }
  public ChangeProvider       getChangeProvider()       {  return changeProvider;  }
  public VcsHistoryProvider   getVcsHistoryProvider()   {  return historyProvider;  }
  public UpdateEnvironment    getUpdateEnvironment()    {  return new VssUpdateEnvironment();  }
  public UpToDateRevisionProvider getUpToDateRevisionProvider() {   return LocalVcsServices.getInstance(getProject()).getUpToDateRevisionProvider();  }
  public HashSet<String>      getSavedProjectPaths()    {  return savedProjectPaths;  }
  public void                 addSavedProjectPath( String path ) {  savedProjectPaths.add( path );  } 

  public void projectOpened()
  {
    final ProjectLevelVcsManager vcsManager = ProjectLevelVcsManager.getInstance(getProject());
    myAddOptions = vcsManager.getStandardOption(VcsConfiguration.StandardOption.ADD, this);
    myCheckoutOptions = vcsManager.getStandardOption(VcsConfiguration.StandardOption.CHECKOUT, this);

    myUndoCheckoutOptions = vcsManager.getOrCreateCustomOption(VssBundle.message("action.name.undo.check.out"), this);
    myCompareOptions = vcsManager.getOrCreateCustomOption(VssBundle.message("action.name.compare.with.sourcesafe.version"), this);
    myGetOptions = vcsManager.getOrCreateCustomOption(VssBundle.message("action.name.get.latest.version"), this);

    addIgnoredFolders();
    
    //  Control the appearance of project items so that we can easily
    //  track down potential changes in the repository.
    listener = new VFListener( getProject(), this );
    LocalFileSystem.getInstance().addVirtualFileListener( listener );
  }

  public void projectClosed() {
    LocalFileSystem.getInstance().removeVirtualFileListener( listener );
  }

  public void startTransaction()    {  init(); }
  public void rollbackTransaction() {  init(); }

  private void init()
  {
    myDirectoriesSchedulledForDeletion = new HashSet<File>();

    myCommands = new ArrayList<VssCommand>();
    myCheckinCommands = new ArrayList<VssCommand>();
    ignoreAllNotCheckedOutConformations = new BooleanValueHolder( false );
  }

  public void start() throws VcsException {
    super.start();
    VssConfiguration configuration = VssConfiguration.getInstance(myProject);
    if (!configuration.VSS_IS_INITIALIZED) {
      try {
        SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            if (!getProject().isOpen()) return;
            LocalVcs.getInstance(getProject()).markSourcesAsCurrent(VssBundle.message("local.vcs.action.name.mark.sources.as.current"));
          }
        });

      }
      finally {
        configuration.VSS_IS_INITIALIZED = true;
      }
    }

    //  Add information about VSS project roots from the local project.
    for( int i = 0; i < configuration.getMapItemCount(); i++ )
    {
      savedProjectPaths.add( configuration.getMapItem( i ).VSS_PATH );
    }
  }

  /**
   * Automatically add "vssver.scc" pattern into the list of ignored file so that
   * they are not becoming the part of the project.
   */
  private static void addIgnoredFolders()
  {
    String patterns = FileTypeManager.getInstance().getIgnoredFilesList();

    //  This code corrects the obvious bug in the previous installations
    @NonNls String errorPattern = "vssver.sccvssver2.scc;";
    patterns = patterns.replaceAll( errorPattern, "" );

    String newPattern = patterns;
    if( patterns.indexOf( VSSVER_FILE_SIG ) == -1 )
      newPattern += (( newPattern.charAt( newPattern.length() - 1 ) == ';') ? "" : ";" ) + VSSVER_FILE_SIG;

    if( patterns.indexOf( VSSVER2_FILE_SIG ) == -1 )
      newPattern += (( newPattern.charAt( newPattern.length() - 1 ) == ';') ? "" : ";" ) + VSSVER2_FILE_SIG;

    if( !newPattern.equals( patterns ))
    {
      final String newPat = newPattern;
      ApplicationManager.getApplication().runWriteAction( new Runnable()
        { public void run() { FileTypeManager.getInstance().setIgnoredFilesList( newPat ); } }
      );
    }
  }

  public void commitTransaction( String comment, final List<VcsException> errors )
  {
    if( comment != null )
      VssConfiguration.getInstance(myProject).getCheckinOptions().COMMENT = comment;

    myCommands.addAll( myCheckinCommands );
    if( myCommands.size() > 0 )
    {
      final Runnable superviserAction = new Runnable()
        {
          public void run()
          {
            for( VssCommand cmd : myCommands )
            {
              cmd.execute();
              errors.addAll( cmd.myErrors );
              if( !cmd.toContinue )
                break;
            }
          }
        };
      FileDocumentManager.getInstance().saveAllDocuments();
      if( ApplicationManager.getApplication().isDispatchThread() )
        superviserAction.run();
      else
        ApplicationManager.getApplication().invokeAndWait( superviserAction, ModalityState.defaultModalityState() );
      ApplicationManager.getApplication().runReadAction( new Runnable() { public void run() { LocalFileSystem.getInstance().refresh( true ); } } );
    }
  }

  public void checkinFile(String path, Object parameters, Map userData)
  {
    VirtualFile file = VcsUtil.getVirtualFile( path );
    VssConfiguration config = VssConfiguration.getInstance( myProject );
    myCheckinCommands.add( new CheckinOneFileCommand( myProject, file, config.getCheckinOptions(),
                                                      ignoreAllNotCheckedOutConformations ) );
  }

  public void addFile( String folderPath, String name, Object parameters, Map userData )
  {
    VssConfiguration config = VssConfiguration.getInstance( myProject );
    VirtualFile file = VcsUtil.getVirtualFile( new File(new File( folderPath ), name) );

    String addFileType = userData != null ? (String)userData.get(FILE_TYPE) : null;
    int addFileTypeIndex = AddOptions.convertFileTypeToInt(addFileType);
    AddOptions options = AddOptions.createCopyWithFileType( config, addFileTypeIndex );

    myCommands.add( new AddFileCommand( myProject, file, options, false ) );
  }

  public void removeFile( String path, Object parameters, Map userData )
  {
    File parentFile = new File( path ).getParentFile();
    if (myDirectoriesSchedulledForDeletion.contains( parentFile )) return;
    myCommands.add( new DeleteFileOrDirectoryCommand( myProject, path, true, true ) );
  }

  public void addDirectory(String parentPath, String name, Object parameters, Map userData) throws VcsException
  {
    VirtualFile directory = VcsUtil.getVirtualFile( new File(new File(parentPath), name) );
    myCommands.add( new CreateDirectoryCommand( myProject, directory ) );
  }

  public void removeDirectory(String path, Object parameters, Map userData)
  {
    File directory = new File( path );
    File parentFile = directory.getParentFile();
    if( myDirectoriesSchedulledForDeletion.contains( parentFile )) return;

    myDirectoriesSchedulledForDeletion.add(directory);
    myCommands.add( new DeleteFileOrDirectoryCommand( myProject, path, false, true ) );
  }

  public void renameAndCheckInFile(String path, String newName, Object parameters)
  {
    File file = new File( path );
    File newFile = new File( file.getParentFile(), newName );
    VirtualFile newVFile = VcsUtil.getVirtualFile( newFile );
    myCommands.add( new RenameFileCommand( myProject, newVFile, file.getName() ) );

    VssConfiguration config = VssConfiguration.getInstance( myProject );
    myCheckinCommands.add( new CheckinOneFileCommand( myProject, newVFile, config.getCheckinOptions(),
                                                      ignoreAllNotCheckedOutConformations ) );
  }

  public void renameDirectory(String path, String newName, Object parameters)
  {
    File file = new File(path);
    File newFile = new File( file.getParentFile(), newName );
    VirtualFile newVFile = VcsUtil.getVirtualFile( newFile );
    myCommands.add( new RenameFileCommand( myProject, newVFile, file.getName() ) );
  }

  public void moveRenameAndCheckInFile( String path, String newParentPath, String newName, Object parameters )
  {
    File oldFile = new File( path );
    File newParent = new File( newParentPath );
    File newFile = new File( newParent, newName );

    boolean isRenamed = !oldFile.getName().equals( newName );
    VirtualFile newVFile = VcsUtil.getVirtualFile( newFile );

    myCommands.add( new CopyFileCommand( myProject, oldFile, newFile ) );
    /*
    VssConfiguration config = VssConfiguration.getInstance( myProject );
    myCommands.add( new CheckinOneFileCommand( myProject, path, config.getCheckinOptions(),
                                               ignoreAllNotCheckedOutConformations ) );
    */
    myCommands.add( new ShareFileCommand( myProject, oldFile, newFile ) );
    myCommands.add( new DeleteFileOrDirectoryCommand( myProject, oldFile.getAbsolutePath(), false, !isRenamed ) );
    if( isRenamed )
    {
      myCommands.add( new RenameFileCommand( myProject, newVFile, oldFile.getName() ) );
    }
    myCommands.add( new DeleteFileCommand( myProject, oldFile ) );
    myCommands.add( new MarkROFileCommand( myProject, newFile ) );
  }

  private static class CopyFileCommand extends VssCommand
  {
    private final File myOldFile;
    private final File myNewFile;

    public  CopyFileCommand( Project project, File oldF, File newF ){ super( project ); myOldFile = oldF; myNewFile = newF; }
    @Nullable
    public  VssOutputCollector getProcessListener() { return null; }
    public  void execute() {
      try {  if( !myOldFile.exists() ) FileUtil.copy( myNewFile, myOldFile ); }
      catch( Exception e ) {}
    }
  }

  private static class MarkROFileCommand extends VssCommand
  {
    private final File myFile;

    public MarkROFileCommand( Project project, File file ){ super( project ); myFile = file; }
    public void execute() {  if( myFile.exists() ) myFile.setReadOnly();  }
    @Nullable
    public VssOutputCollector getProcessListener() { return null; }
  }

  private static class DeleteFileCommand extends VssCommand
  {
    private final File myOldFile;

    public DeleteFileCommand( Project project, File oldF ){ super( project ); myOldFile = oldF;  }
    @Nullable
    public VssOutputCollector getProcessListener() { return null; }
    public void execute() {  myOldFile.delete();  }
  }

  public void moveAndRenameDirectory(String path, String newParentPath, String newName, Object parameters)
  {
    File oldFile = new File( path );
    boolean isRenamed = (oldFile.getName() != newName);
    myCommands.add( new MoveDirectoryCommand( myProject, oldFile, new File( newParentPath, oldFile.getName() ), !isRenamed ) );

    if( isRenamed )
    {
      File newFile = new File( new File( newParentPath ), newName );
      VirtualFile newVFile = VcsUtil.getVirtualFile( newFile );
      myCommands.add( new RenameFileCommand( myProject, newVFile, oldFile.getName() ) );
    }
  }

  public boolean getLatestVersion( String path, Object params, Map userData, List<VcsException> errors )
  {
    return getLatestVersion( path, false, params, userData, errors );
  }

  public boolean getLatestVersion( String path, boolean makeWritable, Object params, Map userData, List<VcsException> errors )
  {
    GetFileCommand cmd = new GetFileCommand( getProject(), path, makeWritable, errors);
    cmd.execute();
    return cmd.isFileNonExistent();
  }

  public void rollbackDeleted( final String path, Object params, Map userData, List<VcsException> errors )
  {
    getLatestVersion( path, false, null, null, errors );

    //  Do not forget to refresh the VFS file holder.
    final VirtualFile[] file = new VirtualFile[ 1 ];
    ApplicationManager.getApplication().runWriteAction( new Runnable() {
      public void run() {
        final String localPath = VssUtil.getCanonicalLocalPath( path );
        file[ 0 ] = LocalFileSystem.getInstance().refreshAndFindFileByPath( localPath );
      }
    });

    if( file[ 0 ] != null )
    {
      //  During file deletion IDEA clears RO status from the file (if it is not
      //  cleared yet). If the file under the repository, it performs checkout
      //  automatically (otherwise, RO status is not cleared and file can not be
      //  removed). By "getLatestVersion" we got the content, now silently
      //  remove "Checkouted" sign from it.
      //
      //  Errors list is fake since we do not want to propagate any errors on this
      //  step back.
      List<VcsException> errorsFake = new ArrayList<VcsException>();
      rollbackChanges( path, params, userData, errorsFake );
    }
  }

  public void rollbackChanges( String path, Object params, Map userData, List<VcsException> errors )
  {
    VirtualFile file = VcsUtil.getVirtualFile( path );
    boolean canShowOptions = getUndoCheckoutOptions().getValue();

    if( file.isDirectory() )
    {
      (new UndocheckoutDirCommand( myProject, file, null, canShowOptions, errors )).execute();
    }
    else
    {
      (new UndocheckoutFilesCommand( myProject, new VirtualFile[]{ file }, null, canShowOptions, false, errors )).execute();
    }
  }

  public void rollbackChanges( String[] paths, Object params, Map userData, List<VcsException> errors )
  {
    VirtualFile[] files = paths2VFiles( paths );
    boolean canShowOptions = getUndoCheckoutOptions().getValue();
    if( files.length == 1 && files[ 0 ].isDirectory() )
    {
      (new UndocheckoutDirCommand( myProject, files[ 0 ], null, canShowOptions, errors )).execute();
    }
    else
    {
      (new UndocheckoutFilesCommand( myProject, files, null, canShowOptions, false, errors )).execute();
    }
  }

  public EditFileProvider getEditFileProvider()
  {
    VssConfiguration config = VssConfiguration.getInstance( getProject() );
    return config.isBusy() ? null : this;
  }

  public void editFiles( VirtualFile[] files )
  {
    VssConfiguration config = VssConfiguration.getInstance(getProject());
    if( !config.isBusy() )
    {
        boolean showOptions = VssVcs.getInstance( myProject ).getCheckoutOptions().getValue();
        ArrayList<VcsException> errors = new ArrayList<VcsException>();
        ( new CheckoutFilesCommand( myProject, files, null, showOptions, errors, false )).execute();

        if( !errors.isEmpty() )
        {
          Messages.showErrorDialog(errors.get(0).getLocalizedMessage(), VssBundle.message("message.title.could.not.start.process"));
          //  ToDo: Make files writable here.
//          for( VirtualFile file : files )
//          {}
        }
        else
        {
          for( VirtualFile file : files )
          {
            VcsDirtyScopeManager mgr = VcsDirtyScopeManager.getInstance( myProject );
            mgr.fileDirty( file );
          }
        }
    }
  }

  public boolean fileExistsInVcs( FilePath path ) {
    return fileIsUnderVcs( path ) && super.fileExistsInVcs( path );
  }

  public void doActivateActions(Module module) {
    LocalVcs.getInstance(getProject()).markModuleSourcesAsCurrent(module, VssBundle.message("local.vcs.action.name.mark.sources.as.current"));
  }

  public boolean fileIsUnderVcs(FilePath filePath) {
    VirtualFile file = filePath.getVirtualFile();
    return file != null && VssUtil.isUnderVss(file, getProject());
  }

  private static VirtualFile[] paths2VFiles( String[] paths )
  {
    VirtualFile[] files = new VirtualFile[ paths.length ];
    for( int i = 0; i < paths.length; i++ )
      files[ i ] = VcsUtil.getVirtualFile( paths[ i ] );

    return files;
  }
  
  public void add2NewFile( VirtualFile file ) {  add2NewFile( file.getPath() );       }
  public void add2NewFile( String path )      {  newFiles.add( path.toLowerCase() );  }
  public boolean containsNew( String path )   {  return newFiles.contains( path.toLowerCase() );   }

  //
  // JDOMExternalizable methods
  //

  public void readExternal(final Element element) throws InvalidDataException
  {
    List files = element.getChildren( PERSISTENCY_REMOVED_FILE_TAG );
    for (Object cclObj : files)
    {
      if (cclObj instanceof Element)
      {
        final Element currentCLElement = ((Element)cclObj);
        final String path = currentCLElement.getValue();

        // Safety check - file can be added again between IDE sessions.
        if( ! new File( path ).exists() )
          removedFiles.add( path );
      }
    }

    files = element.getChildren( PERSISTENCY_REMOVED_FOLDER_TAG );
    for (Object cclObj : files)
    {
      if (cclObj instanceof Element)
      {
        final Element currentCLElement = ((Element)cclObj);
        final String path = currentCLElement.getValue();

        // Safety check - file can be added again between IDE sessions.
        if( ! new File( path ).exists() )
          removedFolders.add( path );
      }
    }

    files = element.getChildren( PERSISTENCY_NEW_FILE_TAG );
    for (Object cclObj : files)
    {
      if (cclObj instanceof Element)
      {
        final Element currentCLElement = ((Element)cclObj);
        final String path = currentCLElement.getValue();

        // Safety check - file can be deleted or changed between IDE sessions.
        if( new File( path ).exists() )
          newFiles.add( path.toLowerCase() );
      }
    }

    files = element.getChildren( PERSISTENCY_RENAMED_FILE_TAG );
    for (Object cclObj : files)
    {
      if (cclObj instanceof Element)
      {
        final Element currentCLElement = ((Element)cclObj);
        final String pathPair = currentCLElement.getValue();
        int delimIndex = pathPair.indexOf( PATH_DELIMITER );
        if( delimIndex != -1 )
        {
          final String newName = pathPair.substring( 0, delimIndex );
          final String oldName = pathPair.substring( delimIndex + PATH_DELIMITER.length() );

          // Safety check - file can be deleted or changed between IDE sessions.
          if( new File( newName ).exists() )
            renamedFiles.put( newName, oldName );
        }
      }
    }

    readUsedProjectPaths();
  }

  public void writeExternal(final Element element) throws WriteExternalException
  {
    writeExternalElement( element, removedFiles, PERSISTENCY_REMOVED_FILE_TAG );
    writeExternalElement( element, removedFolders, PERSISTENCY_REMOVED_FOLDER_TAG );
    writeExternalElement( element, newFiles, PERSISTENCY_NEW_FILE_TAG );

    for( String file : renamedFiles.keySet() )
    {
      final Element listElement = new Element(PERSISTENCY_RENAMED_FILE_TAG);
      final String pathPair = file.concat( PATH_DELIMITER ).concat( renamedFiles.get( file ) );

      listElement.addContent( pathPair );
      element.addContent( listElement );
    }

    //  Do not write to the file which is shared between several projects since
    //  the default settings may be incomplete and they override the current
    //  project's settings.
    if( !myProject.isDefault() )
    {
      writeUsedProjectPaths();
    }
  }

  private static void writeExternalElement( final Element element, HashSet<String> files, String tag )
  {
    //  Sort elements of the list so that there is no perturbation in .ipr/.iml
    //  files in the case when no data has changed.
    String[] sorted = files.toArray( new String[ files.size() ] );
    Arrays.sort( sorted );

    for( String file : sorted )
    {
      final Element listElement = new Element( tag );
      listElement.addContent( file );
      element.addContent( listElement );
    }
  }
  
  private void readUsedProjectPaths()
  {
    String configPath = PathManager.getConfigPath( true );
    String optionsFile = configPath + File.separatorChar + OPTIONS_FOLDER +
                                      File.separatorChar + OPTIONS_FILE;
    savedProjectPaths.clear();
    try
    {
      //noinspection IOResourceOpenedButNotSafelyClosed
      BufferedReader reader = new BufferedReader( new FileReader( optionsFile ) );

      String line;
      while(( line = reader.readLine()) != null )
        savedProjectPaths.add( line );

      reader.close();
    }
    catch( Exception e ) {
      //  Nothing to do, no special treatment is necessary, the file
      //  can be recovered next time.
    }
  }

  private void writeUsedProjectPaths()
  {
    try
    {
      //  Create folder "VSS" under the predefined config folder,
      //  and put paths into the special file under that folder.

      String configPath = PathManager.getConfigPath( true );
      configPath += File.separatorChar + OPTIONS_FOLDER;
      new File( configPath ).mkdir();

      String optionsFile = configPath + File.separatorChar + OPTIONS_FILE;

      //  Do not forget to clear the content of the file - we always overwrite
      //  the available information anew.
      File file = new File( optionsFile );
      file.delete();

      //noinspection IOResourceOpenedButNotSafelyClosed
      PrintWriter writer = new PrintWriter( optionsFile );
      for( String path : savedProjectPaths )
        writer.write( path + "\n" );

      writer.close();
    }
    catch( IOException e ) {
      //  Nothing to do, no special treatment is necessary, the file
      //  can be recovered next time.
    }
  }

  private class VssUpdateEnvironment implements UpdateEnvironment
  {
    public void fillGroups( UpdatedFiles groups )
    {
      final FileGroup groupModified = new FileGroup(VssBundle.message("update.group.name.modified"),
                                                    VssBundle.message("update.group.name.modified"), false, FileGroup.MODIFIED_ID, false);
      groups.registerGroup(groupModified);

      final FileGroup groupSkipped = new FileGroup(VssBundle.message("update.group.name.skipped"),
                                                   VssBundle.message("update.group.name.skipped"), false, FileGroup.SKIPPED_ID, false);
      groups.registerGroup(groupSkipped);
    }

    public UpdateSession updateDirectories( FilePath[] contentRoots, UpdatedFiles updatedFiles, ProgressIndicator progressIndicator ) throws ProcessCanceledException
    {
      VssConfiguration config = VssConfiguration.getInstance( myProject );
      final ArrayList<VcsException> errors = new ArrayList<VcsException>();

      progressIndicator.setText( VssBundle.message("message.synch.with.repository") );
      FileDocumentManager.getInstance().saveAllDocuments();

      //  We allow update/symch operations only for Folders, not for ordinary
      //  files. Since in "Version Control" window it is allowable (so far) to
      //  issue "Update File" command on the individual file, we need to issue
      //  "Get" command instead.
      for( FilePath root : contentRoots )
      {
        final VirtualFile rootFile = root.getVirtualFile();
        if( root.isDirectory() )
        {
          boolean verbose = VssVcs.getInstance( config.getProject() ).getGetOptions().getValue();
          SynchronizeCommand cmd = new SynchronizeCommand( myProject, rootFile, null, verbose, errors );
          cmd.execute();

          fillGroup( updatedFiles, FileGroup.UPDATED_ID, cmd.filesAdded );
          fillGroup( updatedFiles, FileGroup.UPDATED_ID, cmd.filesChanged );
          fillGroup( updatedFiles, FileGroup.SKIPPED_ID, cmd.filesSkipped );

          //  Make files in the folder refresh immediately after the "Get" operation
          //  is finished. Otherwise synch can be made synchronously far later.

          ModalityState state = progressIndicator.getModalityState();
          final Application app = ApplicationManager.getApplication();
          app.invokeLater(new Runnable() {
            public void run() { app.runWriteAction(new Runnable() { public void run() { rootFile.refresh(true, true); } }); }
          }, state);
        }
        else
        {
          GetFileCommand cmd = new GetFileCommand( myProject, root.getPath(), errors );
          cmd.execute();
        }
      }

      return new UpdateSession(){
        public List<VcsException> getExceptions() { return errors; }
        public void onRefreshFilesCompleted()     {}
        public boolean isCanceled()               { return false;  }
      };
    }

    private void fillGroup( UpdatedFiles updatedFiles, String id, Collection<String> list )
    {
      for( String file : list )
        updatedFiles.getGroupById( id ).add( file );
    }

    @Nullable
    public Configurable createConfigurable(Collection<FilePath> files)
    {
      return null;
    }
  }

  private class VssCheckinEnvironment implements CheckinEnvironment
  {
    private CheckinEnvironment baseCheckinEnvironment;
    private VssVcs host;

    public VssCheckinEnvironment( VssVcs host, LocalVcsServices localVcsServices )
    {
      this.host = host;
      baseCheckinEnvironment = localVcsServices.createCheckinEnvironment( host );
    }

    public boolean showCheckinDialogInAnyCase()   {  return false;  }

    public RevisionsFactory getRevisionsFactory() {  return baseCheckinEnvironment.getRevisionsFactory();   }

    public RollbackProvider createRollbackProviderOn(AbstractRevisions[] selectedRevisions, final boolean containsExcluded) {
      return baseCheckinEnvironment.createRollbackProviderOn(selectedRevisions, containsExcluded);
    }

    public List<VcsException> commit(CheckinProjectDialogImplementer dialog, Project project) {
      return AbstractVcsHelper.getInstance(myProject)
        .doCheckinProject( dialog.getCheckinProjectPanel(), dialog.getPreparedComment( this ), host );
    }

    public List<VcsException> commit(FilePath[] roots, Project project, String preparedComment) {
      return baseCheckinEnvironment.commit(roots, project, preparedComment);
    }

    public DifferenceType[] getAdditionalDifferenceTypes() {   return new DifferenceType[0];   }

    public AnAction[] getAdditionalActions(int index) {  return new AnAction[0];  }

    public String prepareCheckinMessage(String text)  {  return text;  }

    public String getHelpId() {  return null;   }

    @Nullable
    public ColumnInfo[] getAdditionalColumns(int index) {
      if (index == 0) {
        return new ColumnInfo[0];
      }
      else {
        return new ColumnInfo[]{new ColumnInfo(VssBundle.message("checkin.project.dialog.file.type.column.name")) {
          public Object valueOf(Object object) {
            if (!isCellEditable(object)) return "";
            String selectedType = ((RevisionTreeNode)object).getUserData(FILE_TYPE);
            if (selectedType == null) {
              TYPES_LIST.selectFirst();
              selectedType = (String)TYPES_LIST.getSelection();
              setValue(object, selectedType);
            }
            TYPES_LIST.select(selectedType);
            return TYPES_LIST;
          }

          public boolean isCellEditable(Object o) {
            if (!(o instanceof RevisionTreeNode)) {
              return false;
            }
            RevisionTreeNode node = (RevisionTreeNode)o;
            AbstractRevisions revisions = node.getRevisions();
            VirtualFile virtualFile = revisions.getVirtualFile();
            if (virtualFile == null) return false;
            if (virtualFile.isDirectory()) return false;
            return revisions.getDifference() == DifferenceType.INSERTED;
          }

          public TableCellRenderer getRenderer(Object p0)
          {
            return isCellEditable(p0) ? ComboBoxTableCellRenderer.INSTANCE : null;
          }

          public TableCellEditor getEditor(Object item) {
            return ComboBoxTableCellEditor.INSTANCE;
          }

          public void setValue(Object o, Object aValue) {
            ((RevisionTreeNode)o).putUserData(FILE_TYPE, (String)aValue);
          }

          public String getMaxStringValue() {
            return VssBundle.message("new.file.type.presentation.auto.detect");
          }

          public int getAdditionalWidth() {
            return 30;
          }
        }
        };
      }
    }

    public RefreshableOnComponent createAdditionalOptionsPanelForCheckinProject(Refreshable panel) {
      return createPanel();
    }

    public RefreshableOnComponent createAdditionalOptionsPanelForCheckinFile(Refreshable panel) {
      return createPanel();
    }

    public RefreshableOnComponent createAdditionalOptionsPanel(Refreshable panel, boolean forProject) {
      return null;
    }

    private RefreshableOnComponent createPanel()
    {
      final JPanel additionalPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 4));
      final JCheckBox keepCheckedOut = new JCheckBox(VssBundle.message("checkbox.option.keep.checked.out"));
      final JCheckBox storeOnlyLatestVersion = new JCheckBox(VssBundle.message("checkbox.option.store.only.latest.version"));

      VssConfiguration config = VssConfiguration.getInstance(myProject);
      final AddOptions addOptions = config.getAddOptions();
      final CheckinOptions checkinOptions = config.getCheckinOptions();

      additionalPanel.add(keepCheckedOut);
      additionalPanel.add(storeOnlyLatestVersion);

      return new RefreshableOnComponent()
      {
        public JComponent getComponent() {   return additionalPanel;    }

        public void saveState() {
          addOptions.STORE_ONLY_LATEST_VERSION = storeOnlyLatestVersion.isSelected();
          checkinOptions.KEEP_CHECKED_OUT = addOptions.CHECK_OUT_IMMEDIATELY = keepCheckedOut.isSelected();
        }

        public void restoreState() {  refresh();   }

        public void refresh() {
          storeOnlyLatestVersion.setSelected(addOptions.STORE_ONLY_LATEST_VERSION);
          keepCheckedOut.setSelected(checkinOptions.KEEP_CHECKED_OUT);
        }
      };
    }

    public void onRefreshFinished() {}
    public void onRefreshStarted()  {}

    public String getDefaultMessageFor( FilePath[] filesToCheckin ) {  return null;    }
    public String getCheckinOperationName() {  return VssBundle.message("action.name.checkin");  }
  }
}
