/**
 * @author  Vladimir Kondratyev
 */
package com.intellij.vssSupport;

import com.intellij.openapi.options.BaseConfigurable;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.TextFieldWithBrowseButton;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.wm.WindowManager;
import com.intellij.ui.ScrollPaneFactory;
import com.intellij.ui.TableUtil;
import com.intellij.util.ui.ItemRemovable;
import com.intellij.util.ui.Table;
import com.intellij.vssSupport.ui.EditMapItemDialog;
import org.jetbrains.annotations.NonNls;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;

public class VssConfigurable extends BaseConfigurable {

  private static final Icon ourIcon=IconLoader.getIcon("/general/vss.png");

  private VssConfiguration myConfig;
  private ArrayList myMapItems;
  private TableModelAdapter myModel;

  // UI Components.
  // The components are created on demand by first call of getComponent() method.
  // If myPanel is null then all UI component are null either.
  JPanel myPanel;
  private JPanel myTableMappingsPanel;
  private TextFieldWithBrowseButton myClientPath;
  private TextFieldWithBrowseButton mySrcsafeIni;
  private JTextField myTextFieldUserName;
  private JPasswordField myPasswordField;
  private JTable myTableMappings;
  private JButton myButtonAdd;
  private JButton myButtonEdit;
  private JButton myButtonRemove;
  private JTextField myExcludedFilesMask;
  private Project myProject;

  @NonNls public static final String PATH_TO_SS_EXE = "ss.exe";
  @NonNls public static final String PATH_TO_SS_INI = "srcsafe.ini";

  @NonNls public String getDisplayName() {  return "SourceSafe";  }

  public VssConfigurable( Project project )
  {
    myProject = project;
    myMapItems = new ArrayList( 0 );
    myModel = new TableModelAdapter();
    myConfig = VssConfiguration.getInstance(myProject);
  }

  public void apply() throws ConfigurationException
  {
    myConfig.CLIENT_PATH = myClientPath.getText().replace('/',File.separatorChar);
    myConfig.SRCSAFEINI_PATH = mySrcsafeIni.getText().replace('/',File.separatorChar);
    myConfig.USER_NAME = myTextFieldUserName.getText().trim();
    myConfig.setExcludedMask( myExcludedFilesMask.getText() );
    myConfig.setPassword( new String( myPasswordField.getPassword() ) );
    myConfig.myMapItems = myMapItems;
  }

  public void disposeUIResources() {  myPanel = null;  }
  public String getHelpTopic() {  return "project.propVSS";  }
  public Icon getIcon() {  return ourIcon;  }


  private void editSelectedMapping(){
    int selectedIdx=myTableMappings.getSelectedRow();
    if(selectedIdx==-1){
      return;
    }
    EditMapItemDialog editor = new EditMapItemDialog( myProject );
    editor.setTitle(VssBundle.message("dialog.title.configuration.edit.mapping"));
    MapItem mapItem=(MapItem)myMapItems.get(selectedIdx);
    editor.init(mapItem.VSS_PATH,mapItem.LOCAL_PATH);
    editor.show();
    if(!editor.isOK()){
      return;
    }
    String vssPath=editor.getVssPath();
    String localPath=editor.getLocalPath();
    if(!isValidMapItem(vssPath,localPath,selectedIdx)){
      return;
    }
    myMapItems.set(selectedIdx,new MapItem(vssPath,localPath));
    myModel.fireTableRowsUpdated(selectedIdx,selectedIdx);
  }

  public JComponent createComponent()
  {
    myTableMappings=new Table(myModel);
    myTableMappings.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    JScrollPane scrollPane = ScrollPaneFactory.createScrollPane(myTableMappings);
    scrollPane.setPreferredSize(new Dimension(0,myTableMappings.getRowHeight()*11));

    myTableMappingsPanel.setLayout(new BorderLayout());
    myTableMappingsPanel.add(scrollPane,BorderLayout.NORTH);


    myClientPath.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent ignored){
          JFileChooser fileChooser=new JFileChooser();
          FileFilter[] filters=fileChooser.getChoosableFileFilters();
          for (FileFilter filter : filters) {
            fileChooser.removeChoosableFileFilter(filter);
          }
          fileChooser.addChoosableFileFilter(
            new FileFilter(){
              public boolean accept(File f){
                return f.isDirectory() || PATH_TO_SS_EXE.equalsIgnoreCase(f.getName());
              }

              public String getDescription(){
                return VssBundle.message("dialog.description.configuration.path.to.ss.exe");
              }
            }
          );
          if(
            JFileChooser.APPROVE_OPTION!=fileChooser.showOpenDialog(WindowManager.getInstance().suggestParentWindow(myProject))
          ){
            return;
          }
          File selection=fileChooser.getSelectedFile();
          myClientPath.setText(selection.getAbsolutePath());
        }
      }
    );

    // SSDIR (srcsafe.ini)

    mySrcsafeIni.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent ignored){
          JFileChooser fileChooser=new JFileChooser();
          FileFilter[] filters=fileChooser.getChoosableFileFilters();
          for (FileFilter filter : filters) {
            fileChooser.removeChoosableFileFilter(filter);
          }
          fileChooser.addChoosableFileFilter(
            new FileFilter(){
              public boolean accept(File f){
                return f.isDirectory() || PATH_TO_SS_INI.equalsIgnoreCase(f.getName());
              }

              public String getDescription(){
                return VssBundle.message("dialog.description.configuration.path.to.srcsafe.ini");
              }
            }
          );
          if(
            JFileChooser.APPROVE_OPTION!=fileChooser.showOpenDialog(WindowManager.getInstance().suggestParentWindow(myProject))
          ){
            return;
          }
          File selection=fileChooser.getSelectedFile();
          mySrcsafeIni.setText(selection.getAbsolutePath());
        }
      }
    );

    // "Add" button.

    myButtonAdd.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent ignored){
          EditMapItemDialog editor = new EditMapItemDialog( myProject );
          editor.setTitle(VssBundle.message("dialog.title.configuration.add.mapping"));
          editor.show();
          if(!editor.isOK()){
            return;
          }
          String vssPath=editor.getVssPath();
          String localPath=editor.getLocalPath();
          if(!isValidMapItem(vssPath,localPath,-1)){
            return;
          }
          myMapItems.add(new MapItem(vssPath,localPath));
          int insertedIdx=myMapItems.size()-1;
          myModel.fireTableRowsInserted(insertedIdx,insertedIdx);
          myTableMappings.getSelectionModel().setSelectionInterval(insertedIdx,insertedIdx);
        }
      }
    );

    // "Edit" button.

    myButtonEdit.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent ignored){
          editSelectedMapping();
        }
      }
    );

    // "Edit" dialog should appear on double click in JTable area

    myTableMappings.addMouseListener(
      new MouseAdapter(){
        public void mouseClicked(MouseEvent e){
          if(e.getClickCount()==2){
            editSelectedMapping();
          }
        }
      }
    );

    // "Remove" buttons.

    myButtonRemove.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent ignored){
          TableUtil.removeSelectedItems(myTableMappings);
          updateButtonsState();
        }
      }
    );

    // This listener manages state of "Edit" and "Remove" buttons.

    myTableMappings.getSelectionModel().addListSelectionListener(
      new ListSelectionListener(){
        public void valueChanged(ListSelectionEvent e){
          updateButtonsState();
        }
      }
    );

    return myPanel;
  }

  public boolean isModified(){
    if(
      !myClientPath.getText().replace('/',File.separatorChar).equals( myConfig.CLIENT_PATH )||
      !mySrcsafeIni.getText().replace('/',File.separatorChar).equals( myConfig.SRCSAFEINI_PATH )||
      !myTextFieldUserName.getText().trim().equals( myConfig.USER_NAME )||
      !myExcludedFilesMask.getText().trim().equals( myConfig.getExcludedMask() ) ||
      !(new String(myPasswordField.getPassword())).equals( myConfig.getPassword() )
    ){
      return true;
    }

    // Test that mappings are equal.

    if(myConfig.myMapItems.size()!=myMapItems.size()){
      return true;
    }
    int size=myMapItems.size();
    for(int i=0;i<size;i++){
      if(!myConfig.myMapItems.get(i).equals(myMapItems.get(i))){
        return true;
      }
    }

    return false;
  }

  private boolean isValidMapItem(String vssPath,String localPath,int excludeIdx)
  {
    // The following code tests that VSS_PATH has right prefix "$/"

    if(!vssPath.startsWith("$/")){
      VssUtil.showErrorMessage(myProject, VssBundle.message("message.text.configuration.invalid.project"),VssBundle.message("message.title.configuration.error"));
      return false;
    }

    // Check that there are no any mappings with the same left or right parts.

    int size=myMapItems.size();
    for(int i=0;i<size;i++){
      if(i==excludeIdx){
        continue;
      }
      MapItem item=(MapItem)myMapItems.get(i);

      if(vssPath.equalsIgnoreCase(item.VSS_PATH)){
        VssUtil.showErrorMessage(myProject,VssBundle.message("message.text.configuration.mapping.with.project.exists"),VssBundle.message("message.title.configuration.error"));
        return false;
      }

      if(localPath.equalsIgnoreCase(item.LOCAL_PATH)){
        VssUtil.showErrorMessage(myProject,VssBundle.message("message.text.configuration.mapping.with.directory.exists"),VssBundle.message("message.title.configuration.error"));
        return false;
      }
    }
    return true;
  }

  public void reset()
  {
    myClientPath.setText(myConfig.CLIENT_PATH);
    mySrcsafeIni.setText(myConfig.SRCSAFEINI_PATH);
    myTextFieldUserName.setText(myConfig.USER_NAME);
    myPasswordField.setText(myConfig.getPassword());
    setVssItems(myConfig.myMapItems);
    myExcludedFilesMask.setText( myConfig.getExcludedMask() );
  }

  /**
   * Sets new set of mappings between VSS items and local paths.
   */
  private void setVssItems(ArrayList vssItems){
    myMapItems = new ArrayList(vssItems);
    myModel.fireTableDataChanged();
  }

  private void updateButtonsState(){
    ListSelectionModel selectionModel = myTableMappings.getSelectionModel();
    boolean state=!selectionModel.isSelectionEmpty();
    myButtonEdit.setEnabled(state);
    myButtonRemove.setEnabled(state);
  }

  private class TableModelAdapter extends AbstractTableModel implements ItemRemovable
  {
    private String[] myColNames = new String[]{ VssBundle.message("column.name.configuration.vss.project"),
                                                VssBundle.message("column.name.configuration.working.directory")};

    public int getRowCount()    {  return myMapItems.size();  }
    public int getColumnCount() {  return myColNames.length;  }

    public String getColumnName(int column){  return myColNames[ column ];  }

    public Object getValueAt(int row, int column){
      switch(column){
        case 0: {  return ((MapItem)myMapItems.get(row)).VSS_PATH;  }
        case 1: {  return ((MapItem)myMapItems.get(row)).LOCAL_PATH.replace('/',File.separatorChar);  }
        default:{  assert false : "Unknown column: " + column; return null;  }
      }
    }

    public void removeRow(int rowIndex){
      myMapItems.remove( rowIndex );
      fireTableRowsDeleted( rowIndex, rowIndex );
    }
  }
}
