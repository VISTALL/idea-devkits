/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport;

import com.intellij.execution.process.ProcessAdapter;
import com.intellij.execution.process.ProcessEvent;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.execution.process.ProcessOutputTypes;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.vcs.VcsException;
import org.jetbrains.annotations.NonNls;

import java.util.ArrayList;
import java.util.List;

public abstract class VssOutputCollector extends ProcessAdapter
{
  @NonNls private static final String NO_DATABASE_MESSAGE = "No VSS database";
  @NonNls private static final String NO_ACCESS_RIGHTS_MESSAGE = "do not have access rights";
  @NonNls private static final String USERNAME_PREFIX = "Username:";

  private int myExitCode;
  private ProcessHandler source;
  private StringBuffer myErr;
  protected final List<VcsException> myErrors;
  private boolean myCriticalErrorOccured = false;

  /**
   * Creates new <code>VssOutputCollector</code> instance.
   */
  public VssOutputCollector(List<VcsException> errors)
  {
    myErr = new StringBuffer();
    myErrors = (errors == null) ? new ArrayList<VcsException>() : errors;
  }

  public void startNotified(final ProcessEvent event)
  {
    source = event.getProcessHandler();
  }

  public void onTextAvailable(ProcessEvent event, Key outputType)
  {
    if( outputType == ProcessOutputTypes.STDOUT )
      checkOutput( event );
    else
    if( outputType == ProcessOutputTypes.STDERR )
      checkErrOutput( event );
  }

  /**
   * Checks that the VSS client does not require user name. It can happen when
   * username/password pair isn't valid. If VSS client requires username/password
   * this method does the folowing:
   * 1. Terminates VSS process.
   * 2. Unregister the listener from the process' handler.
   * 3. Invokes <code>onIncorrectUsernamePassword</code> handler.
   */
  private void checkOutput(ProcessEvent e)
  {
    String text = e.getText();
    if( text != null )
    {
      myErr.append( text );
      if( text.startsWith( USERNAME_PREFIX ))
        onCommandCriticalFail( VssBundle.message("exception.text.incorrect.username.or.password") );
    }
  }

  /**
   * This method checks error output and terminates ss.exe process in
   * the following circumstances:
   *
   * 1. No VSS database if found.
   * 2. User has no rights to perform the operation.
   *
   * After process has been terminated the corresponded error handler is
   * invoked.
   */
  private void checkErrOutput(ProcessEvent e)
  {
    String text = e.getText();
    if( text != null )
    {
      myErr.append(text);
      if( text.indexOf( NO_DATABASE_MESSAGE ) != -1 )
        onCommandCriticalFail( VssBundle.message("exception.text.no.database.found") );
      else
      if( text.indexOf( NO_ACCESS_RIGHTS_MESSAGE ) != -1 )
        onCommandCriticalFail( VssBundle.message("exception.text.no.rights.to.perform.operation") );
    }
  }

  public String   getCmdOutput()          {  return myErr.toString();  }
  public int      getExitCode()           {  return myExitCode;  }
  public boolean  criticalErrorOccured()  {  return myCriticalErrorOccured;  }
  public void     processTerminated(ProcessEvent e) {  myExitCode = e.getExitCode();  }

  protected final void onCommandCriticalFail( final String message )
  {
    myErrors.add( new VcsException( message ) );
    myCriticalErrorOccured = true;

    //  Hack: there is no known (so far) way to give the necessary sequence of
    //  characters to the input of the SS.EXE process to emulate "Enter" on its
    //  request to reenter the password. Thus we simply notify the parent process
    //  that it should finish.
    
    source.destroyProcess();
  }

  /**
   * This method is invoked when process was finished incorrectly. This method is
   * invoked in event dispath thred.
   * @see VssOutputCollector#everythingFinishedImpl
   */
  public void processCriticalErrorImpl(){}

  /**
   * This method is invoked when process succesfully finished.
   * It means the VSS database was found, user name/password pair is correct
   * and user's access rights is also correct. Note, that the method is invoked
   * in event dispath thread.
   */
  public abstract void everythingFinishedImpl();
}