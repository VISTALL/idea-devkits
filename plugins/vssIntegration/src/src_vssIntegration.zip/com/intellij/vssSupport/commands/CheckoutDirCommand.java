/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.LineTokenizer;
import com.intellij.openapi.vcs.ProjectLevelVcsManager;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.update.FileGroup;
import com.intellij.openapi.vcs.update.UpdatedFiles;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.*;
import com.intellij.vssSupport.ui.CheckoutDirDialog;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.List;

/**
 * The command delegates its functionality to the <code>CheckoutFilesCommand</code>.
 */
public class CheckoutDirCommand extends VssCommandAbstract
{
  private static final Logger LOG=Logger.getInstance("#com.intellij.vssSupport.commands.CheckoutDirCommand");

  private CheckoutOptions myBaseOptions;
  private VirtualFile myDir;

  /**
   * @param project project.
   * @param dir directory to be checked out. Note, that the passed
   * directory must be a directory and this directory should be under VSS control,
   * i.e. method <code>VssUtil.isUnderVss</code> must return <code>true</code>.
   * @param options command options. If you use this constructor and
   * <code>options</code> isn't <code>null</code> then the <code>execute</code>
   * method will not show options' dialog.
   */
  public CheckoutDirCommand( Project project, VirtualFile dir,
                             CheckoutOptions options, List<VcsException> errors )
  {
    super(project, errors);
    LOG.assertTrue(dir.isDirectory());
    myBaseOptions = options;
    myDir = dir;
  }

  public void execute()
  {
    FileDocumentManager.getInstance().saveAllDocuments();
    VssConfiguration config = VssConfiguration.getInstance( myProject );

    if (myBaseOptions == null) {
      if ((myBaseOptions = createOptions()) == null) {
        return;
      }
    }

    try {
      CheckoutListener checkoutListener = new CheckoutListener( myErrors );
      List<String> options = myBaseOptions.getOptions( myDir );

      VSSExecUtil.runProcess( config.CLIENT_PATH, options.toArray( new String[ options.size() ] ), config.getSSDIREnv(),
                              myDir.getPath().replace('/', File.separatorChar), checkoutListener );
      //  Make "RO" attributes refresh immediately after the undo operation
      //  is finished. Otherwise synch can be made synchronously far later.
      ApplicationManager.getApplication().runWriteAction( new Runnable() { public void run() { myDir.refresh( false, true ); } } );
    }
    catch( ExecutionException exc )
    {
      String msg = config.checkCmdPath();
      myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
      config.setBusy( false ); // release "busy" state
    }
  }

  /**
   * Show dialog with command options.
   * @return options or <code>null</code> if command was cancelled.
   */
  @Nullable
  private CheckoutOptions createOptions()
  {
    VssConfiguration config = VssConfiguration.getInstance( myProject );
    CheckoutOptions options = config.getCheckoutOptions();

    boolean showOptions = VssVcs.getInstance( myProject ).getCheckoutOptions().getValue();
    if( showOptions )
    {
      CheckoutDirDialog editor = new CheckoutDirDialog( myProject );
      editor.setTitle( VssBundle.message("dialog.title.check.out.directory", myDir.getName()) );
      editor.init( options );
      editor.show();
      if(!editor.isOK()){
        return null;
      }
      editor.commit( options );
    }
    return options;
  }
  
  /**
   * Use this listener to catch messages from "Checkout" VSS command.
   */
  private class CheckoutListener extends VssOutputCollector
  {
    @NonNls private static final String CHECKED_BY_ANOTHER_GROUP = "CHECKED_BY_ANOTHER";
    @NonNls private static final String ALREADY_CHECKED_OUT_GROUP = "ALREADY_CHECKED_OUT";
    @NonNls private static final String WRITABLE_GROUP = "WRITABLE";
    @NonNls private static final String SUCCESS_GROUP = "SUCCESSFULLY_CHECKED_OUT";

    @NonNls private static final String ALREADY_CHECKED_MESSAGE = "currently have file ";
    @NonNls private static final String CHECKED_OUT_SUFFIX = " checked out";
    @NonNls private static final String WRITABLE_COPY_MESSAGE = "writable copy of ";
    @NonNls private static final String CHECKED_OUT_BY_ANOTHER_USER_MESSAGE = "is checked out by";
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";

    CheckoutListener( List<VcsException> errors ) {  super(errors);   }

    public void processCriticalErrorImpl() {   VssConfiguration.getInstance(myProject).setBusy( false );   }

    public void everythingFinishedImpl()
    {
      String text = getCmdOutput();

      if( text.indexOf( NOT_EXISTING_MESSAGE ) != -1 )
      {
        myErrors.add( new VcsException(VssBundle.message( "message.text.path.is.not.existing.filename.or.project", myDir.getPath() )));
        return;
      }

      UpdatedFiles updatedFiles = UpdatedFiles.create();
      updatedFiles.registerGroup( new FileGroup(VssBundle.message("update.group.name.checked.by.other"),
                                                VssBundle.message("update.group.name.checked.by.other"),
                                                false, CHECKED_BY_ANOTHER_GROUP, true ));
      updatedFiles.registerGroup( new FileGroup(VssBundle.message("update.group.name.already.checkedout"),
                                                VssBundle.message("update.group.name.already.checkedout"),
                                                false, ALREADY_CHECKED_OUT_GROUP, true ));
      updatedFiles.registerGroup( new FileGroup(VssBundle.message("update.group.name.writable"),
                                                VssBundle.message("update.group.name.writable"),
                                                false, WRITABLE_GROUP, true ));
      updatedFiles.registerGroup( new FileGroup(VssBundle.message("update.group.name.checked.out"),
                                                VssBundle.message("update.group.name.checked.out"),
                                                false, SUCCESS_GROUP, true ));

      int index;
      String fileName;
      String lastFolderName = myDir.getPath();

      String[] lines = LineTokenizer.tokenize( text, false );
      for( String line : lines )
      {
        if( line.length() == 0 )
          continue;

        if( line.charAt( line.length() - 1 ) == ':' )
        {
          lastFolderName = line.substring( 0, line.length() - 1 );
          if( lastFolderName.length() > 0 && lastFolderName.charAt( 0 ) == '$' )
            lastFolderName = VssUtil.getLocalPath( lastFolderName, myProject );  
        }
        else
        if( (index = line.indexOf(ALREADY_CHECKED_MESSAGE)) != -1 )
        {
          fileName = line.substring( index + ALREADY_CHECKED_MESSAGE.length() );
          fileName = fileName.substring( 0, fileName.length() - CHECKED_OUT_SUFFIX.length() );
          fileName = VssUtil.getLocalPath( fileName, myProject );

          updatedFiles.getGroupById( ALREADY_CHECKED_OUT_GROUP ).add( fileName );
        }
        else
        if( (index = line.indexOf(CHECKED_OUT_BY_ANOTHER_USER_MESSAGE)) != -1 )
        {
          fileName = line.substring( 0, index - 1 );
          fileName = fileName.substring( 5 );
          fileName = VssUtil.getLocalPath( fileName, myProject );

          updatedFiles.getGroupById( CHECKED_BY_ANOTHER_GROUP ).add( fileName );
        }
        else
        if( (index = line.indexOf(WRITABLE_COPY_MESSAGE)) != -1 )
        {
          fileName = line.substring( index + WRITABLE_COPY_MESSAGE.length() );
          fileName = fileName.substring( 0, fileName.length() - 15 );

          updatedFiles.getGroupById( WRITABLE_GROUP ).add( fileName );
        }
        else
        {
          if( line.charAt( line.length() - 1 ) != ':' )
          {
            updatedFiles.getGroupById( SUCCESS_GROUP ).add( lastFolderName + "\\" + line );
          }
        }
      }
      ProjectLevelVcsManager.getInstance(myProject).showProjectOperationInfo(
        updatedFiles, VssBundle.message("dialog.title.check.out.directory", myDir.getName()) );
    }
  }
}