package com.intellij.vssSupport.commands;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssUtil;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author: lesya
 * @author: lloix
 */
public class MoveDirectoryCommand extends AbstractVssCommand
{
  private final File myOldPath;
  private final File myNewPath;
  private final boolean myMarkAsUpToDate;
  @NonNls private static final String MOVE_COMMAND = "Move";
  @NonNls private static final String _I__OPTION = "-I-";

  public MoveDirectoryCommand( Project project, File oldPath, File newPath, boolean markAsUpToDate)
  {
    super( project );
    myNewPath = newPath;
    myOldPath = oldPath;
    myMarkAsUpToDate = markAsUpToDate;
  }

  protected List<String> createOptions()
  {
    ArrayList<String> options = new ArrayList<String>();
    options.add(MOVE_COMMAND);
    options.add(VssUtil.getVssPath(myOldPath, myProject));
    options.add(VssUtil.getVssPath(myNewPath.getParentFile(), myProject));
    options.add(_I__OPTION);
    VssConfiguration config = VssConfiguration.getInstance(myProject);
    if( config.USER_NAME.length() > 0 )
      options.add(config.getYOption());

    return options;
  }

  protected File    getFile()       {  return myNewPath; }
  protected boolean isFileCommand() {  return false;  }
  protected boolean cpRequired()    {  return false;  }
  protected boolean shouldMarkAsUpToDate() { return myMarkAsUpToDate;  }
  protected VirtualFile getVirtualFile()   { return LocalFileSystem.getInstance().findFileByIoFile(getFile());  }
}
