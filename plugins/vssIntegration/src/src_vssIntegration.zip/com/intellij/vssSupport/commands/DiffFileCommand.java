package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.diff.*;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssOutputCollector;
import com.intellij.vssSupport.VssUtil;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Vladimir Kondratyev
 */
public class DiffFileCommand  extends VssCommandAbstract
{
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.commands.DiffFileCommand");
  private VirtualFile myFile;
  private File myTmpFile;
  @NonNls private static final String _GWR_OPTION = "-GWR";
  @NonNls private static final String _GL_OPTION = "-GL";
  @NonNls private static final String GET_COMMAND = "Get";
  @NonNls private static final String TMP_FILE_NAME = "idea_vss";

  /**
   * @param project     project.
   * @param virtualFile file to be compared with repository version. Note, that the passed
   *                    file must be a file (not directory) and it should be under VSS control,
   *                    i.e. it must have not <code>null</code> nearest mapping item.
   */
  public DiffFileCommand( Project project, VirtualFile virtualFile, List<VcsException> errors )
  {
    super(project, errors);
    LOG.assertTrue(!virtualFile.isDirectory());
    myFile = virtualFile;
  }

  public void execute()
  {
    FileDocumentManager.getInstance().saveAllDocuments();
    VssConfiguration config = VssConfiguration.getInstance(myProject);

    // The implementation of Diff command consists from two parts:
    // 1. Get latest repository version into the temporary directory.
    // 2. Performs difference of two local versions.

    try {
      // The name of temporary copy is the name of temporary directory concatenated
      // with the name of file.
      File tmpFile = File.createTempFile(TMP_FILE_NAME, "." + myFile.getExtension());
      tmpFile.deleteOnExit();
      File tmpDir = tmpFile.getParentFile();
      myTmpFile = new File(tmpDir, myFile.getName());
      myTmpFile.deleteOnExit();

      // Launch Get command to store temporary file.
      GetListenerDiffProcessor getListener = new GetListenerDiffProcessor(myErrors);
      LinkedList<String> options = new LinkedList<String>();
      options.add(GET_COMMAND);
      options.add(VssUtil.getVssPath(myFile, myProject));
      options.add(_GL_OPTION + tmpDir.getCanonicalPath());
      options.add(_GWR_OPTION);
      if (config.USER_NAME.length() > 0) {
        options.add(config.getYOption());
      }
      VSSExecUtil.runProcess( config.CLIENT_PATH, options.toArray( new String[ options.size() ] ), config.getSSDIREnv(),
                              myFile.getParent().getPath().replace('/', File.separatorChar), getListener);
      options.clear();
    }
    catch (ExecutionException exc)
    {
      String msg = config.checkCmdPath();
      myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
    }
    catch (Exception exc) {
      LOG.error(exc);
    }
  }

  /**
   * Use this listener to catch messages from "Get" VSS command.
   * If "Get" command completed successfully then it launch "Diff"
   * VSS command or external diff (if specified).
   */
  private class GetListenerDiffProcessor extends VssOutputCollector
  {
    @NonNls private static final String DELETED_MESSAGE = "has been deleted";
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";

    public GetListenerDiffProcessor(List<VcsException> errors) {
      super(errors);
    }

    public void everythingFinishedImpl() {
      String errorOutput = getCmdOutput();

      if (errorOutput.indexOf(DELETED_MESSAGE) != -1) {
        onHasBeenDeleted();
      }
      else if (errorOutput.indexOf(NOT_EXISTING_MESSAGE) != -1) {
        onNotExistingFilenameOrProject();
      }
      else {
        if (VssUtil.EXIT_CODE_FAILURE == getExitCode()) {
          VssUtil.showErrorOutput(errorOutput, myProject);
          return;
        }
        try {
          SimpleDiffRequest diffData = new SimpleDiffRequest(myProject,
                                                             VssBundle.message("dialog.title.diff.for.file", myFile.getPresentableUrl()));
          diffData.setContentTitles(VssBundle.message("diff.content.title.repository"), VssBundle.message("diff.content.title.local"));
          DiffContent currentContent = FileContent.fromFile(myProject, myFile);
          DiffContent vssContent =
            SimpleContent.fromIoFile(myTmpFile, myFile.getCharset().name(), currentContent.getContentType());
          diffData.setContents(vssContent, currentContent);
          DiffManager.getInstance().getDiffTool().show(diffData);
        }
        catch (IOException e) {
          myErrors.add(new VcsException(e.getLocalizedMessage()));
        }
      }
    }

    private void onHasBeenDeleted()
    {
      myErrors.add( new VcsException( VssBundle.message("message.text.file.deleted", myFile.getPresentableUrl()) ));
    }

    private void onNotExistingFilenameOrProject()
    {
      myErrors.add( new VcsException( VssBundle.message("message.text.path.is.not.existing.filename.or.project",
                                                        VssUtil.getVssPath(myFile, myProject)) ));
    }
  }
}
