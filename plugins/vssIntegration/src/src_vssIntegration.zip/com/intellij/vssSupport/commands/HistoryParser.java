package com.intellij.vssSupport.commands;

import com.intellij.openapi.util.text.LineTokenizer;
import org.jetbrains.annotations.NonNls;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 * Date: May 31, 2006
 * Time: 3:48:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class HistoryParser
{
  @NonNls private static final String FILE_SECTION_SIG = "*****";
  @NonNls private static final String VERSION_SECTION_PREFIX_SIG = "*****************  Version ";
  @NonNls private static final String VERSION_SECTION_SUFFIX_SIG = "*****************";
  @NonNls private static final String FOLDER_LABEL_SECTION_PREFIX_SIG = "**********************";
  @NonNls private static final String CHECKED_IN_SIG = "Checked in ";
  @NonNls private static final String FILE_ADDED_SIG = " added";
  @NonNls private static final String FILE_LABELLED_SIG = "Labelled";
  @NonNls private static final String FILE_DELETED_SIG = " deleted";
  @NonNls private static final String FILE_PURGED_SIG = " purged";
  @NonNls private static final String FILE_RECOVERED_SIG = " recovered";
  @NonNls private static final String FILE_DESTROYED_SIG = " destroyed";
  @NonNls private static final String FILE_ACTION_REGEXP = " (added|deleted|purged|recovered|destroyed)";

  @NonNls private static final String VERSION_SIG = "Version ";
  @NonNls private static final String USER_SIG = "User: ";
  @NonNls private static final String DATE_SIG = "Date: ";
  @NonNls private static final String TIME_SIG = "Time: ";
  @NonNls private static final String COMMENT_SIG = "Comment: ";
  @NonNls private static final String LABEL_COMMENT_SIG = "Label comment: ";
  @NonNls private static final String LABEL_SIG = "Label: ";

  private HistoryParser() {
  }

  public static class SubmissionData
  {
    public String action;
    public String version;
    public String submitter;
    public String changeDate;
    public String changeTime;
    public String comment;
  }

  public static ArrayList<SubmissionData> parse( final String content )
  {
    ArrayList<SubmissionData> changes = new ArrayList<SubmissionData>();
    String[] lines = LineTokenizer.tokenize( content, false );

    for( int i = 0; i < lines.length; i++ )
    {
      if( lines[ i ].indexOf( FOLDER_LABEL_SECTION_PREFIX_SIG ) != -1 )
      {
        //  just skip this section in order not to mix it with others
        //  since it has a special format.
      }
      else
      if( lines[ i ].indexOf( VERSION_SECTION_PREFIX_SIG ) != -1 )
      {
        // !*****************  Version 6   *****************
        // !User: Lloix        Date: 13-11-06   Time:  5:52p
        // !Checked in $/VssTest/SRC/Dir1
        // !Comment: New comment
        //    or
        // !*****************  Version 6   *****************
        // !Label: <label>
        // !User: Lloix        Date: 13-11-06   Time:  5:52p
        // !Labelled
        // !Label Comment: New comment
        if( i + 3 < lines.length )
        {
          SubmissionData change = new SubmissionData();
          change.version = parseVersion( lines[ i ] );
          
          if( lines[ i + 1 ].indexOf( LABEL_SIG ) != -1 )
          {
            i++;
          }
          change.submitter = parseActor( lines[ i + 1 ] );
          change.changeDate = parseDate( lines[ i + 1 ] );
          change.changeTime = parseTime( lines[ i + 1 ] );
          change.action = parseAction( lines[ i + 2 ] );
          change.comment = parseComment( lines, i + 3 );

          changes.add( change );
        }
      }
      else
      if( lines[ i ].indexOf( FILE_SECTION_SIG ) != - 1 )
      {
        // !*****  File1.java  *****
        // !Version 6
        // !User: Lloix        Date: 13-11-06   Time:  5:52p
        // !Checked in $/VssTest/SRC/Dir1
        // !Comment: New comment
        if( i + 3 < lines.length )
        {
          SubmissionData change = new SubmissionData(); 
          change.submitter = parseActor( lines[ i + 2 ] );
          change.version = lines[ i + 1 ].substring( VERSION_SIG.length() );
          change.changeDate = parseDate( lines[ i + 2 ] );
          change.changeTime = parseTime( lines[ i + 2 ] );
          change.action = parseAction( lines[ i + 3 ] );
          change.comment = parseComment( lines, i + 4 );

          changes.add( change );
        }
      }
    }
    return changes;
  }

  private static String parseActor( String line )
  {
    int indexOfDate = line.indexOf( DATE_SIG );
    return line.substring( 0, indexOfDate - 1 ).replace( USER_SIG, "" ).trim();
  }

  private static String parseDate( String line )
  {
    int indexOfDate = line.indexOf( DATE_SIG );
    String date = line.substring( indexOfDate + DATE_SIG.length() );
    date = date.substring( 0, date.indexOf( TIME_SIG ) ).trim();
    return date;
  }

  private static String parseTime( String line )
  {
    int indexOfDate = line.indexOf( TIME_SIG );
    return line.substring( indexOfDate + TIME_SIG.length() ).trim();
  }

  private static String parseVersion( String line )
  {
    line = line.substring( VERSION_SECTION_PREFIX_SIG.length() );
    line = line.substring( 0, line.length() - VERSION_SECTION_SUFFIX_SIG.length() ).trim();
    return line;
  }

  private static String parseComment( final String[] lines, int startIndex )
  {
    StringBuffer comment = new StringBuffer();
    int i = startIndex;
    if( i < lines.length &&
        ( lines[ i ].startsWith( COMMENT_SIG ) || lines[ i ].startsWith( LABEL_COMMENT_SIG ) ))
    {
      if( lines[ i ].startsWith( COMMENT_SIG ) )
        lines[ i ] = lines[ i ].substring( COMMENT_SIG.length() );
      else
        lines[ i ] = lines[ i ].substring( LABEL_COMMENT_SIG.length() );
      
      while( i < lines.length && lines[ i ].length() > 0 )
      {
        if( comment.length() > 0 )
          comment.append( "\n" );
        comment.append( lines[ i ] );
        i++;
      }
    }
    return comment.toString();
  }
  
  private static String parseAction( String line )
  {
    String action = "Unknown";
    if( line.indexOf( CHECKED_IN_SIG ) != -1 )
    {
      action = "Checkin";
    }
    else
    if( line.endsWith( FILE_ADDED_SIG ) )
    {
      action = "Add";
    }
    else
    if( line.endsWith( FILE_LABELLED_SIG ) )
    {
      action = "Label";
    }
    else
    if( line.endsWith( FILE_DELETED_SIG ) || line.endsWith( FILE_PURGED_SIG ) ||
        line.endsWith( FILE_DESTROYED_SIG ))
    {
      action = "Deleted";
    }
    else
    if( line.endsWith( FILE_RECOVERED_SIG ) )
    {
      action = "Recovered";
    }
    return action;
  }
}
