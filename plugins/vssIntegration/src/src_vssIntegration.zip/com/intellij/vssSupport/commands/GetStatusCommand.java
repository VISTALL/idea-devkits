package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.LineTokenizer;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssOutputCollector;
import com.intellij.vssSupport.VssUtil;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 * Date: Mar 13, 2006
 */
public class GetStatusCommand extends VssCommand
{
    @NonNls private static final String CURRENT_USER_OPTION = "-U";
    @NonNls private static final String RECURSIVE_OPTION = "-R";
    @NonNls private static final String STATUS_COMMAND = "Status";

    private ArrayList<String> files;
    private ArrayList<String> dirs;

    public GetStatusCommand( Project project )
    {
      super( project );
      files = new ArrayList<String>();
      dirs = new ArrayList<String>();
    }

    public ArrayList<String> getCheckedOutFiles() { return files; }
    public ArrayList<String> getCheckedOutDirs() { return dirs; }

    public VssOutputCollector getProcessListener()
    {
      return new VssStatusListener( myErrors );
    }

    public void execute()
    {
      VssConfiguration config = VssConfiguration.getInstance( myProject );
      VssOutputCollector listener = new VssStatusListener( myErrors );

      files.clear();
      dirs.clear();

      //  GetStatus command issues "status" command to vss command line exe,
      //  retrieves its responce and parses it.
      //  "status" responce is a sequence of lines each corresponding to
      //  a particular checked out file from the repository project.

      LinkedList<String> options = new LinkedList<String>();
      for( int i = 0; i < config.getMapItemCount(); i++ )
      {
        options.add( STATUS_COMMAND );
        options.add( config.getMapItem( i ).VSS_PATH );
        options.add( RECURSIVE_OPTION );
        if( config.USER_NAME.length() > 0 )
        {
          options.add( CURRENT_USER_OPTION );
          options.add( config.getYOption() );
        }

        try
        {
          String wrkPath = config.getMapItem( i ).LOCAL_PATH;
          VSSExecUtil.runProcess( config.CLIENT_PATH, options.toArray( new String[ options.size() ]), config.getSSDIREnv(), wrkPath, listener );
        }
        catch( ExecutionException exc )
        {
          String msg = config.checkCmdPath();
          myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
        }
        options.clear();
      }
    }

    /**
     * Use this listener to catch messages from "Status" VSS command.
     * If "Status" command completed successfully then it parses command
     * output and updates the content of VssFileStatusManager.
     */
    private class VssStatusListener extends VssOutputCollector
    {
      @NonNls private static final String DELETED_MESSAGE = "has been deleted";
      @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";
      @NonNls private static final String NOFILES_SIG = "No checked out files";

      public VssStatusListener(List<VcsException> errors)
      {
        super( errors );
      }

      public void everythingFinishedImpl()
      {
        String errorOutput = getCmdOutput();

        if( errorOutput.indexOf( DELETED_MESSAGE ) != -1 )
          onHasBeenDeleted();
        else if( errorOutput.indexOf( NOT_EXISTING_MESSAGE ) != -1 )
          onNotExistingFilenameOrProject();
        else if( VssUtil.EXIT_CODE_FAILURE == getExitCode() )
          VssUtil.showErrorOutput( errorOutput, myProject );
        else
          parseContent( errorOutput );
      }

      private void parseContent(final String out )
      {
        String[] lines = LineTokenizer.tokenize( out, false );
        if( lines.length < 2 || !lines[ 1 ].startsWith( NOFILES_SIG ))
        {
          String basePath = "";
          for( String line : lines )
          {
            if( line.endsWith( ":" ) )
            {
              basePath = line.substring( 0, line.length() - 1 );
              basePath = VssUtil.getLocalPath(basePath, myProject);
              dirs.add( basePath);
            }
            else if( line.length() > 18 )
            {
              String file = line.substring( 0, 18 ).trim();
              file = basePath + "\\" + file;
              if( new File( file ).exists() && ( files.indexOf( file ) == -1 )) 
              {
                files.add( file );
              }
            }
          }
        }
      }

      private void onHasBeenDeleted()
      {
        myErrors.add( new VcsException( VssBundle.message("message.text.file.deleted", "???" ) ));
      }

      private void onNotExistingFilenameOrProject()
      {
        VssConfiguration config = VssConfiguration.getInstance( myProject );
        String vssPath = VssUtil.getCommonVssPath( config );
        myErrors.add( new VcsException( VssBundle.message( "message.text.path.is.not.existing.filename.or.project", vssPath ) ));
      }
   }
}
