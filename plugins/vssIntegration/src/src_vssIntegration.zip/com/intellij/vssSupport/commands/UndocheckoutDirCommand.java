/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.LineTokenizer;
import com.intellij.openapi.vcs.ProjectLevelVcsManager;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.update.FileGroup;
import com.intellij.openapi.vcs.update.UpdatedFiles;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.*;
import com.intellij.vssSupport.ui.UndocheckoutDirDialog;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.List;

public class UndocheckoutDirCommand extends VssCommandAbstract
{
  private static final Logger LOG=Logger.getInstance("#com.intellij.vssSupport.commands.UndocheckoutDirCommand");

  private UndocheckoutOptions myBaseOptions;
  private VirtualFile myDir;
  private boolean showOptions;

  /**
   * Creates new <code>UndocheckoutDirCommand</code> instance.
   * @param dir directory to be unchecked out. Note, that the passed
   * directory must be under VSS control, i.e. <code>VssUtil.isUnderVss</code>
   * method must return <code>true</code>.
   * @param options command options. If you use this constructor and
   * <code>options</code> isn't <code>null</code> then the <code>execute</code>
   * method will not show options' dialog.
   */
  public UndocheckoutDirCommand( Project project, VirtualFile dir, UndocheckoutOptions options,
                                 boolean canShowOptions, List<VcsException> errors )
  {
    super(project, errors);
    LOG.assertTrue(dir.isDirectory());

    myBaseOptions = options;
    myDir = dir;
    showOptions = canShowOptions;
  }

  public void execute()
  {
    FileDocumentManager.getInstance().saveAllDocuments();
    VssConfiguration config = VssConfiguration.getInstance( myProject );

    if( myBaseOptions == null )
      createOptions();

    if( myBaseOptions != null )
    {
      try
      {
        UndoCheckoutListener checkoutListener = new UndoCheckoutListener( myErrors );
        String[] options = myBaseOptions.getOptions( myDir );

        VSSExecUtil.runProcess( config.CLIENT_PATH, options, config.getSSDIREnv(),
                                myDir.getPath().replace('/', File.separatorChar), checkoutListener );
        //  Make "RO" attributes refresh immediately after the undo operation
        //  is finished. Otherwise synch can be made synchronously far later.
        ApplicationManager.getApplication().runWriteAction( new Runnable() { public void run() { myDir.refresh( false, true ); } } );
      }
      catch( ExecutionException exc )
      {
        String msg = config.checkCmdPath();
        myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
        config.setBusy( false ); // release "busy" state
      }
    }
  }

  private void createOptions()
  {
    VssConfiguration config = VssConfiguration.getInstance( myProject );
    final boolean[] cancelled = new boolean[ 1 ]; cancelled[ 0 ] = false;

    if( myBaseOptions == null )
      myBaseOptions = config.getUndocheckoutOptions();

    if( showOptions )
    {
      // Show dialog with command options.
      UndocheckoutDirDialog editor = new UndocheckoutDirDialog( myProject );
      editor.setTitle(VssBundle.message("dialog.title.undo.check.out.directory", myDir.getName()));
      editor.init( myBaseOptions );
      editor.show();

      if( editor.isOK() )
        editor.commit( myBaseOptions );
      else
        myBaseOptions = null;
    }
 }

  /**
   * Use this listener to catch messages from "Checkout" VSS command.
   */
  private class UndoCheckoutListener extends VssOutputCollector
  {
    @NonNls private static final String NOT_CHECKED_OUT_GROUP = "NOT_CHECKED_OUT";
    @NonNls private static final String NOT_EXISTING_GROUP = "NOT_EXISTING";

    @NonNls private static final String CHECKED_OUT_MESSAGE = "currently checked out";
    @NonNls private static final String DELETED_MESSAGE = "has been deleted";
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";
    @NonNls private static final String LOSE_CHANGES_NO_MESSAGE  = "has changed. Undo check out and lose changes?(Y/N)N";
    @NonNls private static final String LOSE_CHANGES_YES_MESSAGE = "has changed. Undo check out and lose changes?(Y/N)Y";
    @NonNls private static final String REPLACING_LOCAL_COPY_MESSAGE = "Replacing local copy of ";
    @NonNls private static final String CONTINUE_QUESTION_SIG = "continue anyway?";

    UndoCheckoutListener( List<VcsException> errors ) {  super(errors);   }

    public void processCriticalErrorImpl() {   VssConfiguration.getInstance(myProject).setBusy( false );   }

    public void everythingFinishedImpl()
    {
      String text = getCmdOutput();

      UpdatedFiles updatedFiles = UpdatedFiles.create();
      updatedFiles.registerGroup( new FileGroup(VssBundle.message("update.group.name.not.checkedout"),
                                                VssBundle.message("update.group.name.not.checkedout"),
                                                false, NOT_CHECKED_OUT_GROUP, true ));
      updatedFiles.registerGroup( new FileGroup(VssBundle.message("update.group.name.notexisting"),
                                                VssBundle.message("update.group.name.notexisting"),
                                                false, NOT_EXISTING_GROUP, true ));

      int index;
      String fileName;
      String lastFolderName = myDir.getPath();

      String[] lines = LineTokenizer.tokenize( text, false );
      for( String line : lines )
      {
        if( line.length() == 0 )
          continue;

        //  If the file is modified and local copy will be replace, this
        //  line is ignored since the next line will indicate that file is
        //  replaced.
        if( line.indexOf( LOSE_CHANGES_YES_MESSAGE ) != -1 )
          continue;

        //  These questions are ignored since all the necessary status information
        //  is shown afterwards in the "Version Control" toolwindow.
        if( line.indexOf( CONTINUE_QUESTION_SIG ) != -1 )
          continue;

        if( line.charAt( line.length() - 1 ) == ':' )
        {
          lastFolderName = line.substring( 0, line.length() - 1 );
          lastFolderName = VssUtil.getLocalPath( lastFolderName, myProject );
        }
        else
        if( (index = line.indexOf( LOSE_CHANGES_NO_MESSAGE )) != -1 )
        {
          fileName = line.substring( 0, index - 1 );
          updatedFiles.getGroupById( FileGroup.SKIPPED_ID ).add( fileName );
        }
        else
        if( (index = line.indexOf( NOT_EXISTING_MESSAGE )) != -1 )
        {
          fileName = line.substring( 0, index );
          fileName = VssUtil.getLocalPath( fileName, myProject );

          updatedFiles.getGroupById( NOT_EXISTING_GROUP ).add( fileName );
        }
        else
        if( (index = line.indexOf( CHECKED_OUT_MESSAGE )) != -1 )
        {
          fileName = line.substring( 0, index );
          updatedFiles.getGroupById( NOT_CHECKED_OUT_GROUP ).add( fileName );
        }
        else
        if( (index = line.indexOf( DELETED_MESSAGE )) != -1 )
        {
          fileName = line.substring( 0, index );
          updatedFiles.getGroupById( FileGroup.REMOVED_FROM_REPOSITORY_ID ).add( fileName );
        }
        else
        if( line.indexOf( REPLACING_LOCAL_COPY_MESSAGE ) != -1 )
        {
          /*
             Do nothing with these files. Since they are successfully replaced,
             just do not mess them with other output information.
          */
        }
      }
      ProjectLevelVcsManager.getInstance(myProject).showProjectOperationInfo(
        updatedFiles, VssBundle.message("dialog.title.undo.check.out.directory", myDir.getName()) );
    }
  }
}
