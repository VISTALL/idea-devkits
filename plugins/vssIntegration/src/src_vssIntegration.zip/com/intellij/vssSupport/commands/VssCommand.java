package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssOutputCollector;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author: lesya
 * @author: LloiX
 */
public abstract class VssCommand
{
  @NonNls private static final String QUESTION_SUBSTRING = "(Y/N)N";
  @NonNls private static final String _I_OPTION = "-I";
  @NonNls private static final String _I_Y_OPTION = "-I-Y";
  @NonNls private static final String _I__OPTION = "-I-";

  protected final Project myProject;
  protected boolean myContinue = false;
  protected boolean continueUponPositiveAnswer = true;

  public final List<VcsException> myErrors;
  public boolean toContinue = true;

  protected VssCommand( Project project )
  {
    myProject = project;
    myErrors = new ArrayList<VcsException>();
  }

  public void setExecutionState( boolean runNextCommand )  {  toContinue = runNextCommand;  }

  protected void runProcess( VssConfiguration config, Collection<String> options,
                             VirtualFile file, VssOutputCollector procListener,
                             VSSExecUtil.UserInput userInput)
  {
    runProcess(config, options, procListener, file.getParent().getPath().replace('/', File.separatorChar), userInput);
  }

  protected void runProcess( VssConfiguration config, Collection<String> options,
                             VirtualFile file, VssOutputCollector procListener)
  {
    runProcess(config, options, file, procListener, null);
  }

  protected void runProcess( VssConfiguration config, Collection<String> options, File file,
                             VssOutputCollector procListener, final VSSExecUtil.UserInput userInput)
  {
    runProcess(config, options, procListener, file.getParentFile().getPath(), userInput);
  }

  private void runProcess( VssConfiguration config, Collection<String> options, VssOutputCollector procListener,
                           String workingPath, final VSSExecUtil.UserInput userInput)
  {
    try {
      VSSExecUtil.runProcess( config.CLIENT_PATH, options.toArray(new String[options.size()]),
                              config.getSSDIREnv(), workingPath, procListener, userInput );
    }
    catch ( ExecutionException exc ) {
      String msg = config.checkCmdPath();
      myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
    }
  }

  protected void showProcessErrorMessage(VssConfiguration config, Exception ex) {
    myErrors.add(new VcsException(VssBundle.message("exception.text.could.not.start.process", ex.getMessage())));
  }

  protected List<String> appendIOption(List<String> options){
    for (final String option : options) {
      if( option.startsWith( _I_OPTION ) ) return options;
    }
    if (myContinue)
      options.add(_I_Y_OPTION);
    else
      options.add(_I__OPTION);

    return options;
  }

  /**
   * Standard behavior for a ss.exe command which require some input from the user:
   * if we find a question signature (with the default answer) - ask the user exactly
   * the same question, and in the case of positive answer restart the command with
   * the flag to set "-I-Y" option into the command line (via <myContinue> field).
   *
   * NB: Current problem - ss.exe commands are divided into two classes - those
   *     which require the reissuing the command after the answer and those which
   *     finish the desired action after the answer. In the latter case reissuing
   *     command leads to an error message.
   *     At least one command known - "Add" (file) - belongs to the second
   *     class. 
   */
  protected boolean processQuestion( String errorOutput )
  {
    int questionIndex = errorOutput.indexOf(QUESTION_SUBSTRING);
    if( questionIndex != -1 )
    {
      if( !ApplicationManager.getApplication().isDispatchThread() )
        throw new AssertionError( "Commands can be issued only in the dispatch thread" );

      String request = errorOutput.substring(0, questionIndex);
      int answer = Messages.showYesNoDialog(request, VssBundle.message("message.title.source.safe"), Messages.getQuestionIcon());
      if( answer != DialogWrapper.OK_EXIT_CODE )
      {
        setExecutionState( false );
      }
      else
      {
        myContinue = true;
        if( continueUponPositiveAnswer )
          execute();
      }
      return true;
    }
    return false;
  }

  public abstract VssOutputCollector getProcessListener();

  public abstract void execute();
}
