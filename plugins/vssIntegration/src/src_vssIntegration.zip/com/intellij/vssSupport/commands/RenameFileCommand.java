package com.intellij.vssSupport.commands;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssConfiguration;
import org.jetbrains.annotations.NonNls;

import java.util.ArrayList;
import java.util.List;

/**
 * author: lesya
 */
public class RenameFileCommand extends VssCommandOnVirtualFile
{
  private final String myOldName;
  @NonNls private static final String RENAME_COMMAND = "Rename";
  @NonNls private static final String _I__OPTION = "-I-";

  public RenameFileCommand( Project project, VirtualFile virtualFile, String oldName )
  {
    super( project, virtualFile );
    myOldName = oldName;
  }

  protected List<String> createOptions()
 {
    ArrayList<String> options = new ArrayList<String>();
    options.add( RENAME_COMMAND );
    options.add( myOldName );
    options.add( myFile.getName() );
    options.add( _I__OPTION );
    VssConfiguration config = VssConfiguration.getInstance( myProject );
    if( config.USER_NAME.length() > 0 )
      options.add( config.getYOption() );

    return options;
  }
}