package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.*;
import com.intellij.vssSupport.ui.CheckoutFilesDialog;
import com.intellij.vssSupport.ui.ConfirmMultipleDialog;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Vladimir Kondratyev
 * @author LloiX
 */
public class CheckoutFilesCommand  extends VssCommandAbstract
{
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.commands.CheckoutFilesCommand");

  @NonNls private static final String CHECKED_OUT_BY_ANOTHER_USER_MESSAGE = "is checked out by";

  private VirtualFile[] myFiles;
  private CheckoutOptions myBaseOptions;
  private boolean myCanShowOptions;
  private boolean myReplaceAllWritable;
  private boolean myDoNotReplaceAllWritable;
  private final boolean myRefreshAfter;
  @NonNls private static final String STATUS_COMMAND = "Status";
  @NonNls private static final String _U_OPTION = "-U";

  /**
   * Creates new <code>CheckoutFilesCommand</code> instance.
   * @param project project.
   * @param files files to be checked out. Note, that the passed
   * files must be under VSS control, i.e. <code>VssUtil.isUnderVss</code>
   * method must return <code>true</code> for each of them.
   * @param baseOptions command options. The parameter can be <code>null</code>.
   * @param verbose whether the command shows options dialog.
   * @param refreshAfter
   */
  public CheckoutFilesCommand( Project project, VirtualFile[] files,
                               CheckoutOptions baseOptions, boolean verbose,
                               List<VcsException> errors, boolean refreshAfter)
  {
    super(project, errors);
    myRefreshAfter = refreshAfter;
    for (VirtualFile virtualFile : files)
    {
      if (virtualFile.isDirectory())
        LOG.assertTrue(false, virtualFile.getPresentableUrl() + " isn't a file");
    }
    Arrays.sort(files, VirtualFileComparator.INSTANCE);
    myFiles = files;
    myBaseOptions = baseOptions;
    myCanShowOptions = verbose;
  }

  /**
   * Checks out the files specified in the constructor.
   */
  public void execute() {
    FileDocumentManager.getInstance().saveAllDocuments();
    if (myBaseOptions == null) {
      if ((myBaseOptions = createOptions()) == null) {
        return;
      }
    }
    VssConfiguration.getInstance(myProject).setBusy(true); // trun on "busy" flag
    checkOut( 0 );
  }

  /**
   * Checkes out the file with the specified index.
   * If index is out of range then does nothing.
   */
  private void checkOut( int idx )
  {
    if (idx >= myFiles.length) { // all files are checked out
      refreshAndSetNonbusy();
      return;
    }

    VssConfiguration config = myBaseOptions.getVssConfiguration();
    VirtualFile file = myFiles[ idx ];

    // If file is writable then I need to check whether it already is checked out
    // or not. I should not show "Confirm Replace" dialog if the file is writable and
    // is checked out.
    if( file.isWritable() )
    {
      try {
        ArrayList<String> options = new ArrayList<String>();
        options.add(STATUS_COMMAND);
        options.add(VssUtil.getVssPath(file, myProject));
        options.add(_U_OPTION);
        if (config.USER_NAME.length() > 0)
          options.add(config.getYOption());

        StatusListener statusListener = new StatusListener( idx, myErrors );
        VSSExecUtil.runProcess( config.CLIENT_PATH, options.toArray( new String[ options.size() ] ),
                                config.getSSDIREnv(), file.getParent().getPath().replace('/', File.separatorChar),
                                statusListener );
        options.clear();
      }
      catch( ExecutionException exc )
      {
        String msg = config.checkCmdPath();
        myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
        config.setBusy( false ); // release "busy" state
      }
      return;
    }

    // Launch ss.exe.
    try {
      CheckoutListener checkoutListener = new CheckoutListener(idx, myErrors);
      List<String> options = myBaseOptions.getOptions(file);
      VSSExecUtil.runProcess( config.CLIENT_PATH, options.toArray( new String[ options.size() ] ),
                              config.getSSDIREnv(), file.getParent().getPath().replace('/', File.separatorChar),
                              checkoutListener);
    }
    catch( ExecutionException exc )
    {
      String msg = config.checkCmdPath();
      myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
      config.setBusy( false ); // release "busy" state
    }
  }

  /**
   * @return options or <code>null</code> if command was cancelled.
   */
  private CheckoutOptions createOptions()
  {
    VssConfiguration config = VssConfiguration.getInstance(myProject);
    CheckoutOptions options = config.getCheckoutOptions();
    // Show dialog with command options.
    if (myCanShowOptions) {
      CheckoutFilesDialog editor = new CheckoutFilesDialog(myProject);
      if (myFiles.length == 1) {
        editor.setTitle(VssBundle.message("dialog.title.check.out.file", myFiles[0].getName()));
      } else {
        editor.setTitle(VssBundle.message("dialog.title.check.out.multiple"));
      }
      editor.init(options);
      editor.show();
      if (!editor.isOK()) {
        return null;
      }
      editor.commit(options);
    }
    return options;
  }

  private void onCurrentlyCheckedOut(int idx)
  {
    myErrors.add(new VcsException(VssBundle.message("message.text.file.checked.out", myFiles[idx].getPresentableUrl())));
  }

  private void onHasBeenDeleted(int idx)
  {
    myErrors.add(new VcsException( VssBundle.message("message.text.cannot.checkout.file.deleted", myFiles[idx].getPresentableUrl()) ));
  }

  private void onIsCheckedOutByAnotherUser(int idx, String userName)
  {
    String message = VssBundle.message("message.text.file.checked.out.by.another.user", myFiles[ idx ].getPresentableUrl());
    if (userName.length() > 0) message = message + " (" + userName + ")";

    myErrors.add(new VcsException( message ));
  }

  private void onNotExistingFilenameOrProject(int idx)
  {
    myErrors.add(new VcsException(
      VssBundle.message("message.text.path.is.not.existing.filename.or.project", VssUtil.getVssPath(myFiles[idx], myProject))));
  }

  private void refreshAll() {
    VirtualFile[] files = VssUtil.getPreferredFilesForRefresh(myFiles);
    for( VirtualFile file : files )
      file.refresh(true, true);
  }

  private void refreshAndSetNonbusy()
  {
    Runnable refreshAction = new Runnable() {
      public void run() {
        VssConfiguration.getInstance( myProject ).setBusy( false );
        if( myRefreshAfter )
          refreshAll();
      }
    };
    if( ApplicationManager.getApplication().isDispatchThread() )
      refreshAction.run();
    else
      ApplicationManager.getApplication().invokeLater( refreshAction );
  }

  /**
   * Use this listener to catch messages from "Checkout" VSS command.
   */
  private class CheckoutListener extends VssOutputCollector {
    /**
     * Index of file to be checked out.
     */
    private int myIdx;
    @NonNls private static final String HAVE_FILE_MESSAGE = "currently have file";
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";
    @NonNls private static final String DELETED_MESSAGE = "has been deleted";

    CheckoutListener(int idx, List<VcsException> errors) {
      super(errors);
      myIdx = idx;
    }

    public void processCriticalErrorImpl() {
      VssConfiguration.getInstance(myProject).setBusy(false);
    }

    /**
     * Parses ss.exe output and shows corresponded messages in case of error.
     * If no fatal error occurred then checkes out the next file.
     */
    public void everythingFinishedImpl()
    {
      String errorOutput = getCmdOutput();
      if (errorOutput.indexOf(HAVE_FILE_MESSAGE) != -1) {
        onCurrentlyCheckedOut(myIdx);
      } else if (errorOutput.indexOf(NOT_EXISTING_MESSAGE) != -1) {
        onNotExistingFilenameOrProject(myIdx);
      } else if (errorOutput.indexOf(DELETED_MESSAGE) != -1) {
        onHasBeenDeleted(myIdx);
      } else if (errorOutput.indexOf(CHECKED_OUT_BY_ANOTHER_USER_MESSAGE) != -1) {
        onIsCheckedOutByAnotherUser(myIdx, getUserNameFrom(errorOutput));
      } else {
        int exitCode = getExitCode();
        if( VssUtil.EXIT_CODE_SUCCESS == exitCode || VssUtil.EXIT_CODE_WARNING == exitCode ) {
          showStatusMessage(myFiles[myIdx]);
        } else {
          VssUtil.showErrorOutput(errorOutput, myProject);
        }
      }
      // Check out the next file.
      checkOut(myIdx + 1);
    }

    private void showStatusMessage(final VirtualFile file) {
      ApplicationManager.getApplication().invokeLater(new Runnable() {
        public void run() {
          VssUtil.showStatusMessage(myProject, VssBundle.message("mesage.text.file.checked.out.successfully", getPresentableUrl(file)));
        }
      });
    }

    private String getPresentableUrl(final VirtualFile file) {
      return ApplicationManager.getApplication().runReadAction(new Computable<String>() {
        public String compute() {
          return file.getPresentableUrl();
        }
      });
    }
  }

  private class StatusListener extends VssOutputCollector {
    /**
     * Index of file to be tested.
     */
    private int myIdx;
    @NonNls private static final String NO_FILES_CHECKED_OUT_MESSAGE = "No files found checked out by";
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";
    @NonNls private static final String DELETED_MESSAGE = "has been deleted";

    public StatusListener(int idx, List<VcsException> errors) {
      super(errors);
      myIdx = idx;
    }

    public void processCriticalErrorImpl() {
      VssConfiguration.getInstance(myProject).setBusy(false);
    }

    public void everythingFinishedImpl() {
      String errorOutput = getCmdOutput();
      if (errorOutput.indexOf(NO_FILES_CHECKED_OUT_MESSAGE) != -1) {
        // If the file is writable then user can change to replace or leave
        // the file for each file to be checked out. It means that options set can
        // be different for each "Checkout" command. For this purpose I clone
        // the initial options and modify the local copy.
        CheckoutOptions options = myBaseOptions.getCopy();
        VirtualFile file = myFiles[myIdx];
        if (myReplaceAllWritable) {
          options.REPLACE_WRITABLE = true;
        } else if (myDoNotReplaceAllWritable) {
          options.REPLACE_WRITABLE = false;
          options.DO_NOT_GET_LATEST_VERSION = true;
        } else {
          ConfirmMultipleDialog dialog = new ConfirmMultipleDialog(
              VssBundle.message("dialog.title.confirm.replace"),
              VssBundle.message("dialog.label.file.is.writable.confirm.replace", file.getPresentableUrl()),
              myProject
          );
          dialog.show();
          int exitCode = dialog.getExitCode();
          if (ConfirmMultipleDialog.YES_EXIT_CODE == exitCode) {
            options.REPLACE_WRITABLE = true;
          } else if (ConfirmMultipleDialog.YES_ALL_EXIT_CODE == exitCode) {
            myReplaceAllWritable = true;
            options.REPLACE_WRITABLE = true;
          } else if (ConfirmMultipleDialog.NO_EXIT_CODE == exitCode) {
            options.REPLACE_WRITABLE = false;
            options.DO_NOT_GET_LATEST_VERSION = true;
          } else if (ConfirmMultipleDialog.NO_ALL_EXIT_CODE == exitCode) {
            myDoNotReplaceAllWritable = true;
            options.REPLACE_WRITABLE = false;
            options.DO_NOT_GET_LATEST_VERSION = true;
          } else if (ConfirmMultipleDialog.CANCEL_OPTION == exitCode) {
            VssConfiguration.getInstance(myProject).setBusy(false);
            return;
          } else {
            LOG.error("Unknown exit code: " + exitCode);
          }
        }
        // Launch ss.exe.
        VssConfiguration config = options.getVssConfiguration();
        try {
          CheckoutListener checkoutListener = new CheckoutListener(myIdx, myErrors);
          List<String> options2 = options.getOptions(file);
          VSSExecUtil.runProcess(
              config.CLIENT_PATH,
              options2.toArray(new String[options2.size()]),
              config.getSSDIREnv(),
              file.getParent().getPath().replace('/', File.separatorChar),
              checkoutListener);
        }
        catch( ExecutionException exc )
        {
          String msg = config.checkCmdPath();
          myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
          VssConfiguration.getInstance( myProject ).setBusy( false );
        }
        return;
      } else if (errorOutput.indexOf(NOT_EXISTING_MESSAGE) != -1) {
        onNotExistingFilenameOrProject(myIdx);
      } else if (errorOutput.indexOf(DELETED_MESSAGE) != -1) {
        onHasBeenDeleted(myIdx);
      } else {
        onCurrentlyCheckedOut(myIdx);
      }
      checkOut(myIdx + 1);
    }
  }

  public static String getUserNameFrom(String errorOutput) {
    int beginOfUserName = errorOutput.indexOf(CHECKED_OUT_BY_ANOTHER_USER_MESSAGE);
    if (beginOfUserName == -1) return "";
    beginOfUserName += CHECKED_OUT_BY_ANOTHER_USER_MESSAGE.length();
    int endOfUserName = errorOutput.indexOf(";", beginOfUserName);
    if (endOfUserName == -1) return "";
    return errorOutput.substring(beginOfUserName, endOfUserName).trim();
  }
}