package com.intellij.vssSupport.commands;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssUtil;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * author: lesya
 */
public class DeleteFileOrDirectoryCommand extends AbstractVssCommand {
  private final String myPath;
  private VssConfiguration myVssConfiguration;
  private final boolean myIsForFile;
  private final boolean myShouldMarkAsUpToDate;
  @NonNls private static final String DELETE_COMMAND = "Delete";
  @NonNls private static final String _I_Y_OPTION = "-I-Y";

  public DeleteFileOrDirectoryCommand(Project project, String path, boolean isFile, boolean shouldMarkAsUpToDate)
  {
    super(project);
    myPath = path;
    myVssConfiguration = VssConfiguration.getInstance(myProject);
    myIsForFile = isFile;
    myShouldMarkAsUpToDate = shouldMarkAsUpToDate;
  }

  protected List<String> createOptions()
 {
    ArrayList<String> options = new ArrayList<String>();
    options.add(DELETE_COMMAND);
    options.add(VssUtil.getVssPath(new File(myPath), myProject));
    options.add(_I_Y_OPTION);
    if( myVssConfiguration.USER_NAME.length() > 0)
      options.add(myVssConfiguration.getYOption());

    return options;
  }

  protected File    getFile()       {  return new File(myPath);  }
  protected boolean isFileCommand() {  return myIsForFile;  }
  protected boolean cpRequired()    {  return false;        }
  protected boolean shouldMarkAsUpToDate() {  return myShouldMarkAsUpToDate;  }
  protected File    getWorkingDirectory()  {  return new File("").getAbsoluteFile();  }
  protected VirtualFile getVirtualFile()   {  return null;   }
}
