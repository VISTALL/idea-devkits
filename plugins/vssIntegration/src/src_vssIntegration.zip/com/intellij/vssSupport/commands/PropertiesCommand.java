package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssOutputCollector;
import com.intellij.vssSupport.VssUtil;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 * Date: Apr 13, 2006
 */
public class PropertiesCommand extends VssCommand
{
  @NonNls private static final String PROPS_COMMAND = "Properties";
  @NonNls private static final String NO_RECURSIVE_SWITCH = "-R-";

    private String vssPath;
    private String tmpPath;
    private boolean isValidRepositoryObject;

    public PropertiesCommand( Project project, String path, boolean isFolder )
    {
      super( project );
      tmpPath = new File( path ).getParent();
      vssPath = VssUtil.getVssPathForLocalPath( path, isFolder, project );
      isValidRepositoryObject = true;
    }

    public VssOutputCollector getProcessListener()
    {
      return new VssPropsListener( myErrors );
    }

    public void execute()
    {
      //  Avoid running the command with NULL Vss path. This is possible when
      //  input path lies outside the Vss project store.
      if( vssPath != null )
      {
        VssConfiguration config = VssConfiguration.getInstance( myProject );

        //  Issue "Properties" command to vss command line tool, retrieve its responce
        //  and parse it.

        LinkedList<String> options = new LinkedList<String>();
        options.add( PROPS_COMMAND );
        options.add( NO_RECURSIVE_SWITCH );
        options.add( vssPath );
        if(config.USER_NAME.length() > 0)
          options.add( config.getYOption() );

        try
        {
          VSSExecUtil.runProcess( config.CLIENT_PATH, options.toArray( new String[ options.size() ] ),
                                  config.getSSDIREnv(), tmpPath, new VssPropsListener( myErrors ) );
        }
        catch( ExecutionException exc )
        {
          String msg = config.checkCmdPath();
          myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
        }
        options.clear();
      }
    }

  public boolean isValidRepositoryObject() {
    return isValidRepositoryObject;
  }

  /**
   * Use this listener to catch messages from "Properties" VSS command.
   */
  private class VssPropsListener extends VssOutputCollector
  {
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";
    @NonNls private static final String VSS_PROJECT_DELETED = "has been deleted.";

    public VssPropsListener(List<VcsException> errors)
    {
      super( errors );
    }

    public void everythingFinishedImpl()
    {
      String output = getCmdOutput();

      if( output.indexOf( NOT_EXISTING_MESSAGE ) != -1 || output.indexOf( VSS_PROJECT_DELETED ) != -1 )
        isValidRepositoryObject = false;
    }
  }
}
