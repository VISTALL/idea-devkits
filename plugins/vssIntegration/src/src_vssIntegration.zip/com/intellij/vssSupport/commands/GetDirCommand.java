/**
 * @author Vladimir Kondratyev
 */
package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.LineTokenizer;
import com.intellij.openapi.vcs.ProjectLevelVcsManager;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.update.FileGroup;
import com.intellij.openapi.vcs.update.UpdatedFiles;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.*;
import com.intellij.vssSupport.ui.GetDirDialog;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.List;

/**
 * The command delegates its functionality to the <code>CheckoutFilesCommand</code>.
 */
public class GetDirCommand extends VssCommandAbstract
{
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.commands.GetDirCommand");

  private GetOptions myBaseOptions;
  private VirtualFile myDir;

  /**
   * @param project project.
   * @param dir directory to be checked out. Note, that the passed
   * directory must be a directory and this directory should be under VSS control,
   * i.e. method <code>VssUtil.isUnderVss</code> must return <code>true</code>.
   * @param options command options. If you use this constructor and
   * <code>options</code> isn't <code>null</code> then the <code>execute</code>
   * method will not show options' dialog.
   */
  public GetDirCommand( Project project, VirtualFile dir,
                        GetOptions options, List<VcsException> errors )
  {
    super(project, errors);
    LOG.assertTrue(dir.isDirectory());
    myBaseOptions = options;
    myDir = dir;
  }

  public void execute()
  {
    FileDocumentManager.getInstance().saveAllDocuments();
    VssConfiguration config = VssConfiguration.getInstance( myProject );

    if (myBaseOptions == null) {
      if ((myBaseOptions = createOptions()) == null) {
        return;
      }
    }

    // Launch ss.exe.
    try
    {
      GetListener getListener = new GetListener( myErrors );
      myBaseOptions.ANSWER_POSITIVELY = true;
      String[] options = myBaseOptions.getOptions( myDir );

      VSSExecUtil.runProcess( config.CLIENT_PATH, options, config.getSSDIREnv(),
                              myDir.getPath().replace('/', File.separatorChar), getListener);

      //  Make files in the folder refresh immediately after the "Get" operation
      //  is finished. Otherwise synch can be made synchronously far later.
      ApplicationManager.getApplication().runWriteAction( new Runnable() { public void run() { myDir.refresh( false, true ); } } );
    }
    catch( ExecutionException exc )
    {
      String msg = config.checkCmdPath();
      myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
      config.setBusy( false ); // release "busy" state
    }
  }

  /**
   * Show dialog with command options.
   * @return options or <code>null</code> if command was cancelled.
   */
  @Nullable
  private GetOptions createOptions()
  {
    VssConfiguration config = VssConfiguration.getInstance( myProject );
    GetOptions options = config.getGetOptions();

    boolean showOptions = VssVcs.getInstance( myProject ).getGetOptions().getValue();
    if( showOptions )
    {
      GetDirDialog editor = new GetDirDialog( myProject );
      editor.setTitle( VssBundle.message("dialog.title.get.directory", myDir.getName()) );
      editor.init( options );
      editor.show();
      if(!editor.isOK()){
        return null;
      }
      editor.commit( options );
    }
    return options;
  }

  /**
   * Use this listener to catch messages from "Checkout" VSS command.
   */
  private class GetListener extends VssOutputCollector
  {
    @NonNls private static final String REPLACED_GROUP = "REPLACED";

    @NonNls private static final String REPLACING_LOCAL_MESSAGE = "Replacing local copy of ";
    @NonNls private static final String GETTING_PREFIX = "Getting ";
    @NonNls private static final String NOT_FOUND_FOLDER_CREATE = "not found, create?";
    @NonNls private static final String SET_AS_DEFAULT_PROJECT = "as the default project";
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";

    GetListener( List<VcsException> errors ) {  super(errors);   }

    public void processCriticalErrorImpl() {}

    public void everythingFinishedImpl()
    {
      String text = getCmdOutput();

      if( text.indexOf( NOT_EXISTING_MESSAGE ) != -1 )
      {
        myErrors.add( new VcsException(VssBundle.message( "message.text.path.is.not.existing.filename.or.project", myDir.getPath() )));
        return;
      }

      UpdatedFiles updatedFiles = UpdatedFiles.create();
      updatedFiles.registerGroup( new FileGroup(VssBundle.message("update.group.name.replaced"),
                                                VssBundle.message("update.group.name.replaced"),
                                                false, REPLACED_GROUP, true ));

      int index;
      String fileName;
      String lastFolderName = myDir.getPath();

      String[] lines = LineTokenizer.tokenize( text, false );
      for( String line : lines )
      {
        if( line.length() == 0 )
          continue;

        //  Several patterns serve as the default notifications on actions done
        //  (since we always start the command with the -I-Y or -I-N switches).
        //  Skip these lines.
        if( line.indexOf( NOT_FOUND_FOLDER_CREATE ) != -1 ||
            line.indexOf( SET_AS_DEFAULT_PROJECT ) != -1 )
          continue;
        
        if( line.charAt( line.length() - 1 ) == ':' )
        {
          lastFolderName = line.substring( 0, line.length() - 1 );
          lastFolderName = VssUtil.getLocalPath( lastFolderName, myProject );
        }
        else
        if( (index = line.indexOf(REPLACING_LOCAL_MESSAGE)) != -1 )
        {
          fileName = line.substring( index + REPLACING_LOCAL_MESSAGE.length() );
          updatedFiles.getGroupById( REPLACED_GROUP ).add( lastFolderName + "\\" + fileName );
        }
        else
        if( (index = line.indexOf( GETTING_PREFIX )) != -1 )
        {
          fileName = line.substring( index + GETTING_PREFIX.length() );
          updatedFiles.getGroupById( FileGroup.UPDATED_ID ).add( lastFolderName + "\\" + fileName );
        }
      }
      ProjectLevelVcsManager.getInstance(myProject).showProjectOperationInfo(
        updatedFiles, VssBundle.message("dialog.title.get.file", myDir.getName()) );
    }
  }
}