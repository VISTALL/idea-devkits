package com.intellij.vssSupport.commands;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssUtil;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


/**
 * author: lesya
 */
public class ShareFileCommand extends AbstractVssCommand
{
  private final File myOldFile;
  private final File myNewFile;
  @NonNls private static final String SHARE_COMMAND = "Share";
  @NonNls private static final String _I_OPTION = "-I-Y";

  public ShareFileCommand(Project project, File oldFile, File newFile)
  {
    super(project);
    myOldFile = oldFile;
    myNewFile = newFile;
  }

  protected List<String> createOptions()
  {
    ArrayList<String> options = new ArrayList<String>();
    options.add(SHARE_COMMAND);
    options.add(VssUtil.getVssPath(myOldFile, myProject));
    options.add(_I_OPTION);
    VssConfiguration config = VssConfiguration.getInstance(myProject);
    if( config.USER_NAME.length() > 0 )
      options.add(config.getYOption());

    return options;
  }

  protected File    getFile()       {  return myNewFile;  }
  protected boolean isFileCommand() {  return false;  }
  protected boolean cpRequired()    {  return true;  }
  protected VirtualFile getVirtualFile()   {  return null;  }
  protected boolean shouldMarkAsUpToDate() {  return false;  }
  protected File    getWorkingDirectory()  {  return new File("");  }
}
