package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssOutputCollector;
import com.intellij.vssSupport.VssUtil;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * author: lesya
 */
public class CpOutputController extends VssOutputCollector
{
  @NonNls private static final String CP_COMMAND = "Cp";

  private final VssConfiguration myVssConfiguration;
  private final String myWorkingDir;
  private final Collection<String> myBaseCommandOptions;
  private final VssCommand myCommand;

  public CpOutputController(Project project,
                            String workingDir,
                            Collection<String> baseCommandOptions,
                            VssCommand command,
                            List<VcsException> errors)
  {
    super(errors);
    myWorkingDir = workingDir;
    myVssConfiguration = VssConfiguration.getInstance(project);
    myBaseCommandOptions = baseCommandOptions;
    myCommand = command;
  }

  public void everythingFinishedImpl() {
    String errorOutput = getCmdOutput();
    if (getExitCode() == VssUtil.EXIT_CODE_FAILURE) {
      myErrors.add(new VcsException(errorOutput));
      myCommand.setExecutionState(false);
      return;
    }

    try {
      VSSExecUtil.runProcess(
        myVssConfiguration.CLIENT_PATH,
        myBaseCommandOptions.toArray(new String[myBaseCommandOptions.size()]),
        myVssConfiguration.getSSDIREnv(),
        myWorkingDir,
        myCommand.getProcessListener());
    }
    catch (ExecutionException exc)
    {
      String msg = myVssConfiguration.checkCmdPath();
      myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
    }
  }

  public static void executeAfterCP(Project project,
                                    File current,
                                    Collection<String> options,
                                    VssCommand listener,
                                    List<VcsException> errors)
  {
    executeAfterCP(project, current, current, options, listener, errors);
  }

  public static void executeAfterCP(Project project,
                                    final File currentProject,
                                    File workingFolder,
                                    Collection<String> options,
                                    VssCommand listener,
                                    List<VcsException> errors)
  {
    VssConfiguration config = VssConfiguration.getInstance( project );

    String vssPath = VssUtil.getVssPath( currentProject, project );
    if (vssPath == null){
      errors.add( new VcsException(VssBundle.message("exception.text.could.not.find.project", currentProject.getAbsolutePath())));
      listener.setExecutionState( false );
      return;
    }

    LinkedList<String> option = getCPOptions( config, vssPath );

    performCall( project, config, workingFolder.getAbsolutePath(), option, options, listener, errors );
  }

  /**
   * This method takes default Vss project path stored in the
   * VssConfiguration's MapItem. Since we have only one of them per
   * project, it is common for all modules in the local project.
   */
  public static void executeAfterCP( Project project,
                                     Collection<String> options,
                                     VssCommand listener,
                                     List<VcsException> errors)
  {
    VssConfiguration config = VssConfiguration.getInstance( project );

    String vssPath = VssUtil.getCommonVssPath( config );
    if ( vssPath == null ){
      errors.add(new VcsException(VssBundle.message( "exception.text.could.not.find.project", "" )));
      listener.setExecutionState(false);
      return;
    }

    final String tmpDire = FileUtil.getTempDirectory();
    LinkedList<String> option = getCPOptions( config, vssPath );

    performCall( project, config, tmpDire, option, options, listener, errors );
  }

  /**
   * This method takes default Vss project path stored in the
   * VssConfiguration's MapItem. Since we have only one of them per
   * project, it is common for all modules in the local project.
   */
  public static void executeAfterCP( Project project,
                                     String tmpDir,
                                     Collection<String> options,
                                     VssCommand listener,
                                     List<VcsException> errors)
  {
    VssConfiguration config = VssConfiguration.getInstance( project );

    String vssPath = VssUtil.getCommonVssPath( config );
    if ( vssPath == null ){
      errors.add(new VcsException(VssBundle.message( "exception.text.could.not.find.project", "" )));
      listener.setExecutionState(false);
      return;
    }

    LinkedList<String> option = getCPOptions( config, vssPath );
    performCall( project, config, tmpDir, option, options, listener, errors );
  }

  private static void  performCall( Project project, VssConfiguration config, String tmpDir,
                                    LinkedList<String> cpCmdOptions, Collection<String> nextCmdOptions,
                                    VssCommand nextCmd, List<VcsException> errors )
  {
    try
    {
      String[] arrayOptions = cpCmdOptions.toArray(new String[ cpCmdOptions.size() ]);
      CpOutputController outputController = new CpOutputController( project, tmpDir, nextCmdOptions,  nextCmd, errors );
      VSSExecUtil.runProcess( config.CLIENT_PATH, arrayOptions, config.getSSDIREnv(), tmpDir, outputController );
    }
    catch( ExecutionException exc )
    {
      String msg = config.checkCmdPath();
      errors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
    }
  }

  /**
   * Construct a list of options for "Cp" Vss command.
   */
  private static LinkedList<String> getCPOptions( VssConfiguration config, String vssPath )
  {
    LinkedList<String> option = new LinkedList<String>();

    option.add( CP_COMMAND );
    option.add( vssPath );
    if (config.USER_NAME.length() > 0) {
      option.add(config.getYOption());
    }
    return option;
  }
}
