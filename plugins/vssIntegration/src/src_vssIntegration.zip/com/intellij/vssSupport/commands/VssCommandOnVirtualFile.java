package com.intellij.vssSupport.commands;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VfsUtil;
import com.intellij.openapi.vfs.VirtualFile;

import java.io.File;

/**
 * @author: lesya
 * @author: LloiX
 */
public abstract class VssCommandOnVirtualFile extends AbstractVssCommand
{
  protected final VirtualFile myFile;

  public VssCommandOnVirtualFile(Project project, VirtualFile file)
  {
    super(project);
    myFile = file;
  }

  protected File    getFile()       {  return VfsUtil.virtualToIoFile(myFile);  }
  protected boolean isFileCommand() {  return false;  }
  protected boolean cpRequired()    {  return true;  }
  protected boolean shouldMarkAsUpToDate() {  return true;  }
  protected VirtualFile getVirtualFile()   {  return myFile;  }
}
