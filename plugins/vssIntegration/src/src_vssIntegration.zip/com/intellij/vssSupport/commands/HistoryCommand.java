package com.intellij.vssSupport.commands;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.vcsUtil.VcsUtil;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssOutputCollector;
import com.intellij.vssSupport.VssUtil;
import org.jetbrains.annotations.NonNls;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 */
public class HistoryCommand extends VssCommand
{
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.HistoryCommand");

  @NonNls private static final String CONFIRMATION_OPTION = "-I-Y";
  @NonNls private static final String HISTORY_COMMAND = "History";

  public ArrayList<HistoryParser.SubmissionData> changes;

  private FilePath file;

  public HistoryCommand( Project project, FilePath file )
  {
    super( project );
    this.file = file;
  }

  public VssOutputCollector getProcessListener()
  {
    return new VssHistoryListener( myErrors );
  }

  public void execute()
  {
    //  Protect ourselves from calling History on the deleted files (since
    //  FilePath object can refere to already illegal file system objects).
    String pathNorm = VssUtil.getCanonicalLocalPath( file.getPath() );
    if( VcsUtil.getVirtualFile( pathNorm ) != null )
    {
      LinkedList<String> options = new LinkedList<String>();
      VssConfiguration config = VssConfiguration.getInstance(myProject);
      String vssPath = VssUtil.getVssPathForLocalPath( pathNorm, false, myProject );

      options.add( HISTORY_COMMAND );
      options.add( vssPath );
      options.add( CONFIRMATION_OPTION );
      if( config.USER_NAME.length() > 0 )
        options.add( config.getYOption() );

      CpOutputController.executeAfterCP( myProject, options, this, myErrors );
      options.clear();
    }
  }

  /**
   * Use this listener to catch messages from "History" VSS command.
   * If "History" command completed successfully then it parses command
   * output and collects history records.
   */
  public class VssHistoryListener extends VssOutputCollector
  {
    @NonNls private static final String DELETED_MESSAGE = "has been deleted";
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";

    public VssHistoryListener(List<VcsException> errors)
    {
      super(errors);
    }

    public void everythingFinishedImpl()
    {
      String outText = getCmdOutput();
      LOG.info( outText );
      
      if (outText.indexOf(DELETED_MESSAGE) != -1)
        onHasBeenDeleted();
      else
      if (outText.indexOf(NOT_EXISTING_MESSAGE) != -1)
        onNotExistingFilenameOrProject();
      else
      if (VssUtil.EXIT_CODE_FAILURE == getExitCode())
          VssUtil.showErrorOutput(outText, myProject);
      else
      {
        changes = HistoryParser.parse( outText );
      }
    }

    private void onHasBeenDeleted()
    {
      myErrors.add( new VcsException( VssBundle.message("message.text.file.deleted", "???" ) ));
    }

    private void onNotExistingFilenameOrProject()
    {
      myErrors.add( new VcsException( VssBundle.message( "message.text.path.is.not.under.repository", file.getPath() ) ));
    }
  }
}
