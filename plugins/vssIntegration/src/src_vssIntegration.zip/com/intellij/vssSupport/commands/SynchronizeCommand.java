package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.application.ModalityState;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.LineTokenizer;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.*;
import com.intellij.vssSupport.ui.GetDirDialog;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Michael (LloiX) Gerasimov
 */
public class SynchronizeCommand extends VssCommandAbstract
{
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.commands.GetFilesCommand");

  private VirtualFile projectRoot;
  private GetOptions myOptions;
  private boolean myCanShowOptions;
  /**
   * List of <code>java.io.File</code> objects. It doesn't contains directories.
   */
  public ArrayList<String> filesChanged;
  public ArrayList<String> filesAdded;
  public ArrayList<String> filesSkipped;

  /**
   * Creates new <code>SynchronizeCommand</code> instance.
   *
   * @param project        project.
   * @param path           paths to be gotten. Note, that the passed
   *                       paths must be under VSS control, i.e. <code>VssUtil.isUnderVss</code>
   *                       method must return <code>true</code> for each of them.
   * @param baseOptions    command options.
   * @param canShowOptions whether the command shows option dialog or not.
   */
  public SynchronizeCommand( Project project, VirtualFile path, GetOptions baseOptions, boolean canShowOptions, List<VcsException> errors)
  {
    super( project, errors );

    projectRoot = path;
    myOptions = baseOptions;
    myCanShowOptions = canShowOptions;
    filesChanged = new ArrayList<String>();
    filesAdded = new ArrayList<String>();
    filesSkipped = new ArrayList<String>();
  }

  /**
   * Gets the files specified in the constructor.
   */
  public void execute()
  {
    if( myOptions == null )
      myOptions = createOptions();

    if( myOptions != null )
    {
      VssConfiguration config = myOptions.getVssConfiguration();

      //---------------------------------------------------------------------
      //  Consider two different cases:
      //  - given root is a subfolder under any VSS project. Issue Synch
      //    starting from this given root;
      //  - given root is above one or several VSS projects (via mappings).
      //    Issue Synch for every mapped folder under this root. This
      //    situation is hypothetical since Synch is called from the
      //    UpdateEnvironmet.updateDirectories which passes correct content
      //    roots (already mapped from the vcs roots). But who known how this
      //    command will be used later...
      //---------------------------------------------------------------------
      if( isPathUnderAnyVssRoot( projectRoot.getPath() ))
      {
        processProjectPath( projectRoot );
      }
      else
      {
        for( int i = 0; i < config.getMapItemCount(); i++ )
        {
          MapItem map = config.getMapItem( i );
          String localPath = map.LOCAL_PATH;
          if( canonicalPathsStartWith( localPath, projectRoot.getPath() ))
          {
            VirtualFile root = VssUtil.getVirtualFile( localPath );
            if( root != null)
              processProjectPath( root );
          }
        }
      }
    }
  }

  private void processProjectPath( VirtualFile path )
  {
    myOptions.ANSWER_POSITIVELY = true;
    myOptions.MAKE_WRITABLE = false;
    myOptions.RECURSIVE = true;
    myOptions.REPLACE_WRITABLE = GetOptions.OPTION_SKIP;
    
    VssConfiguration config = myOptions.getVssConfiguration();

    try {
      String[] options = myOptions.getOptions( path );
      SynchronizeListener synchronizeListener = new SynchronizeListener( path, myErrors );
      VSSExecUtil.runProcess( config.CLIENT_PATH, options, config.getSSDIREnv(), path.getPath(), synchronizeListener );
    }
    catch (ExecutionException exc)
    {
      String msg = config.checkCmdPath();
      myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
    }
  }

  /**
   * @return options or <code>null</code> if user cancels command.
   */
  @Nullable
  private GetOptions createOptions()
  {
    VssConfiguration config = VssConfiguration.getInstance(myProject);
    final GetOptions options = config.getGetOptions();

    final boolean[] cancelled = new boolean[ 1 ]; cancelled[ 0 ] = false;
    if( myCanShowOptions )
    {
      Runnable runnable = new Runnable()
      {
        public void run()
        {
          GetDirDialog editor = new GetDirDialog( myProject );
          editor.setTitle(VssBundle.message("dialog.title.get.file", projectRoot.getName()));

          editor.init( options );
          editor.makeConsistentForUpdateProject();
          
          editor.show();
          if(!editor.isOK())
            cancelled[ 0 ] = true;
          else
            editor.commit( options );
        }
      };
      ApplicationManager.getApplication().invokeAndWait( runnable, ModalityState.defaultModalityState() );
    }
    return cancelled[ 0 ] ? null : options;
  }

  private class SynchronizeListener extends VssOutputCollector
  {
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";
    @NonNls private static final String WRITABLE_COPY_PREFIX = "A writable copy of ";
    @NonNls private static final String WRITABLE_COPY_SUFFIX = " already exists";
    @NonNls private static final String GETTING_PREFIX = "Getting ";
    @NonNls private static final String REPLACING_PREFIX = "Replacing local copy of ";
    @NonNls private static final String NOT_FOUND_FOLDER_CREATE = "not found, create?";
    @NonNls private static final String SET_AS_DEFAULT_PROJECT = "as the default folder";
    @NonNls private static final String FILE_DESTROYED_PROJECT = "has been destroyed, ";
    @NonNls private static final String CONTINUE_ANYWAY_SIG = "Continue anyway?";

    private VirtualFile path;

    public SynchronizeListener( VirtualFile pathToProcess, List<VcsException> errors)
    {
      super(errors);
      LOG.assertTrue( pathToProcess.isDirectory(), pathToProcess.getPath() + " isn't a directory");
      path = pathToProcess;
    }

    public void everythingFinishedImpl()
    {
      String errorOutput = getCmdOutput();
      if( errorOutput.indexOf( NOT_EXISTING_MESSAGE ) != -1 )
        myErrors.add( new VcsException(VssBundle.message( "message.text.path.is.not.existing.filename.or.project", path )));
      else
        parseOutput( errorOutput );
    }

    private void parseOutput( String errorOutput )
    {
      String[] lines = LineTokenizer.tokenize(errorOutput.toCharArray(), false);
      int offset = 0;
      while( offset < lines.length )
      {
        if( isSubProjectLine( lines[ offset ] ) )
        {
          String  vssProjectPath = lines[ offset].substring( 0, lines[offset].length() - 1 );
          String  localProjectPath = VssUtil.getLocalPath( vssProjectPath, myProject );

          offset++;
          while( offset < lines.length && !isSubProjectLine( lines[ offset ] ))
          {
            if( lines[ offset ].trim().length() > 0 )
              analyzeLine( lines[ offset ], localProjectPath );

            offset++;
          }
          continue;
        }
        else
        if( isStringVss2005Formatted( lines[ offset ] ) )
        {
          processVss2005Formatted( lines[ offset ] );
        }
        offset++;
      }
    }

    private boolean isSubProjectLine( final String line )
    {
      return StringUtil.startsWithChar(line, '$') &&
             StringUtil.endsWithChar( line, ':' );
    }

    private void analyzeLine( String line, String localProjectPath )
    {
      //  Several patterns serve as the default notifications on actions done
      //  (since we always start the command with the -I-Y or -I-N switches).
      //  Skip these lines.
      if( line.indexOf( NOT_FOUND_FOLDER_CREATE ) != -1 ||
          line.indexOf( SET_AS_DEFAULT_PROJECT ) != -1 ||
          line.indexOf( FILE_DESTROYED_PROJECT ) != -1 ||
          line.indexOf( CONTINUE_ANYWAY_SIG ) != -1 )
        return;

      //  Skip writable files which are either checked-out files and must not be
      //  changed or accidentally writable files which should be resolved later.
      if( line.indexOf( WRITABLE_COPY_PREFIX ) != -1 )
      {
        line = line.substring( WRITABLE_COPY_PREFIX.length() );
        line = line.replaceFirst( WRITABLE_COPY_SUFFIX, "" );
        filesSkipped.add( line );
      }
      else
      {
        //  File is either new:
        //  - if the file or its directory is not under the project;
        //  - prefix "Getting" is present;
        //  or modified:
        //  - prefix "Replacing local copy of " is present;

        String  fullPath = new File( localProjectPath, line ).getPath();
        if( line.startsWith( REPLACING_PREFIX ) )
        {
          line = line.substring( REPLACING_PREFIX.length() );
          fullPath = new File( localProjectPath, line ).getPath();
          filesChanged.add( fullPath );
        }
        else
        if( line.startsWith( GETTING_PREFIX ) )
        {
          line = line.substring( GETTING_PREFIX.length() );
          fullPath = new File( localProjectPath, line ).getPath();
          filesAdded.add( fullPath );
        }
        else
        if( !VssUtil.isPathUnderProject( myProject, fullPath ))
        {
          filesAdded.add( fullPath );
        }
      }
    }

    private boolean isStringVss2005Formatted( final String line )
    {
      return line.startsWith( GETTING_PREFIX ) && (line.indexOf( "$/" ) > 0);
    }

    private void processVss2005Formatted( String line )
    {
      line = line.substring( GETTING_PREFIX.length() );
      line = VssUtil.getLocalPath( line, myProject );
      filesAdded.add( line );
    }
  }

  private boolean isPathUnderAnyVssRoot( final String path )
  {
    return VssUtil.isUnderVss( path, myProject );
  }

  private static boolean canonicalPathsStartWith( String localPath, String rootPath )
  {
    return
    VssUtil.getCanonicalLocalPath( localPath.toLowerCase() ).startsWith(
        VssUtil.getCanonicalLocalPath( rootPath.toLowerCase() ));
  }
}
