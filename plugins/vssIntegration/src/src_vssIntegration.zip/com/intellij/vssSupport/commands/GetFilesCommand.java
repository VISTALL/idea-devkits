package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.text.LineTokenizer;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.*;
import com.intellij.vssSupport.ui.ConfirmMultipleDialog;
import com.intellij.vssSupport.ui.GetDirDialog;
import com.intellij.vssSupport.ui.GetFilesDialog;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Vladimir Kondratyev
 */
public class GetFilesCommand extends VssCommandAbstract{
  private static final Logger LOG=Logger.getInstance("#com.intellij.vssSupport.commands.GetFilesCommand");

  private VirtualFile[] myFiles;
  private GetOptions myBaseOptions;
  private boolean myCanShowOptions;
  /**
   * List of <code>java.io.File</code> objects. It doesn't contains directories.
   */
  private ArrayList<File> myFilesToBeGot;
  private boolean myReplaceAllWritable;
  private boolean myDoNotReplaceAllWritable;
  private boolean myCreateAllFolders;
  private boolean myDoNotCreateAllFolders;

  @NonNls private static final String DIR_COMMAND = "Dir";
  @NonNls private static final String _R_OPTION = "-R";

  /**
   * Creates new <code>GetFilesCommand</code> instance.
   * @param project project.
   * @param files files to be gotten. Note, that the passed
   * files must be under VSS control, i.e. <code>VssUtil.isUnderVss</code>
   * method must return <code>true</code> for each of them.
   * @param baseOptions command options.
   * @param canShowOptions whether the command shows option dialog or not.
   */
  public GetFilesCommand( Project project, VirtualFile[] files, GetOptions baseOptions,
                          boolean canShowOptions, List<VcsException> errors){
    super( project, errors );
    Arrays.sort( files, VirtualFileComparator.INSTANCE );
    myFiles=files;
    myBaseOptions = baseOptions;
    myCanShowOptions = canShowOptions;
    myFilesToBeGot = new ArrayList<File>(myFiles.length);
  }

  /**
   * Gets the files specified in the constructor.
   */
  public void execute()
  {
    if( !allFilesUnderVss() )
    {
      myErrors.add( new VcsException( VssBundle.message("message.text.cannot.checkout.not.all.files.under.vss") ));
    }
    else
    {
      FileDocumentManager.getInstance().saveAllDocuments();
      if(myBaseOptions==null){
        if((myBaseOptions=createOptions())==null){
          return;
        }
      }
      collectFiles(0);
    }
  }

  /**
   * Collect all files and projecs from myFiles[idx].
   * Stores collected files in the myFilesToBeGot list. When all files are collected then
   * it invokes get(0) function
   */
  private void collectFiles(int idx){
    if(idx>=myFiles.length){
      get(0);
      return;
    }

    VirtualFile file=myFiles[idx];

    if(!file.isDirectory()){
      myFilesToBeGot.add(new File(file.getPath().replace('/',File.separatorChar)));
      collectFiles(idx+1);
      return;
    }else if(file.isDirectory()){
      ArrayList<String> options=new ArrayList<String>();
      options.add(DIR_COMMAND);
      options.add(VssUtil.getVssPath(file, myProject));
      if(myBaseOptions.RECURSIVE){
        options.add(_R_OPTION);
      }
      VssConfiguration config=myBaseOptions.getVssConfiguration();
      if(config.USER_NAME.length()>0){
        options.add(config.getYOption());
      }
      try{
        DirListener dirListener = new DirListener( idx, myErrors );
        VSSExecUtil.runProcess(
          config.CLIENT_PATH,
          options.toArray(new String[options.size()]),
          config.getSSDIREnv(),
          null,
          dirListener);
        options.clear();
      }
      catch( ExecutionException exc )
      {
        String msg = config.checkCmdPath();
        myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
      }
    }
  }

  /**
   * @return options or <code>null</code> if user cancels command.
   */
  private GetOptions createOptions()
  {
    VssConfiguration config=VssConfiguration.getInstance(myProject);
    GetOptions options=config.getGetOptions();

    if(myCanShowOptions)
    {
      boolean containsDirs = anyDirectoryPresent();
      if( containsDirs ){
        GetDirDialog editor=new GetDirDialog(myProject);
        if (myFiles.length == 1) {
          editor.setTitle(VssBundle.message("dialog.title.get.file", myFiles[0].getName()));
        } else {
          editor.setTitle(VssBundle.message("dialog.title.get.multiple"));
        }

        editor.init(options);
        editor.show();
        if(!editor.isOK()){
          return null;
        }
        editor.commit(options);
      }else{
        GetFilesDialog editor=new GetFilesDialog(myProject);
        if (myFiles.length == 1) {
          editor.setTitle(VssBundle.message("dialog.title.get.file", myFiles[0].getName()));
        } else {
          editor.setTitle(VssBundle.message("dialog.title.get.multiple"));
        }
        editor.init(options);
        editor.show();
        if(!editor.isOK()){
          return null;
        }
        editor.commit(options);
      }
    }
    return options;
  }

  /**
   * Checkes out the file with the specified index.
   * If index is out of range then does nothing.
   */
  private void get(int idx){
    if(idx>=myFilesToBeGot.size()){
      refreshAll();
      return;
    }

    File file=getFileToBeGot(idx);

    // Test whether file is writable.
    // User is free to replace or skip writable files. It means
    // that command's options can be different for each file.

    GetOptions options = myBaseOptions;
    if( file.exists() && file.canWrite() && GetOptions.OPTION_ASK == options.REPLACE_WRITABLE )
    {
      options = myBaseOptions.getCopy();
      if( myReplaceAllWritable ){
        options.REPLACE_WRITABLE = GetOptions.OPTION_REPLACE;
      }else if( myDoNotReplaceAllWritable ){
        options.REPLACE_WRITABLE = GetOptions.OPTION_SKIP;
      }else{
        ConfirmMultipleDialog dialog = new ConfirmMultipleDialog(
          VssBundle.message("dialog.title.confirm.replace"),
          VssBundle.message("dialog.label.file.is.writable.confirm.replace", file.getAbsolutePath()),
          myProject);
        dialog.show();
        int exitCode = dialog.getExitCode();
        if(ConfirmMultipleDialog.YES_EXIT_CODE == exitCode){
          options.REPLACE_WRITABLE = GetOptions.OPTION_REPLACE;
        }else if(ConfirmMultipleDialog.YES_ALL_EXIT_CODE == exitCode){
          myReplaceAllWritable = true;
          options.REPLACE_WRITABLE = GetOptions.OPTION_REPLACE;
        }else if(ConfirmMultipleDialog.NO_EXIT_CODE==exitCode){
          options.REPLACE_WRITABLE = GetOptions.OPTION_SKIP;
        }else if(ConfirmMultipleDialog.NO_ALL_EXIT_CODE==exitCode){
          myDoNotReplaceAllWritable = true;
          options.REPLACE_WRITABLE = GetOptions.OPTION_SKIP;
        }else if(ConfirmMultipleDialog.CANCEL_OPTION==exitCode){
          return;
        }else{
          LOG.error( "Unknown exitCode: " + exitCode );
        }
      }
    }

    // Launch ss.exe.

    VssConfiguration config = options.getVssConfiguration();
    try{
      GetListener checkoutListener = new GetListener( idx, myErrors );
      VSSExecUtil.runProcess( config.CLIENT_PATH, options.getOptions( file ),
                              config.getSSDIREnv(), file.getParentFile().getAbsolutePath(),
                              checkoutListener );
    }
    catch( ExecutionException exc )
    {
      String msg = config.checkCmdPath();
      myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
    }
  }

  private File getFileToBeGot(int idx){
    return myFilesToBeGot.get(idx);
  }

  private void onHasBeenDeleted(String path){
    Messages.showMessageDialog(
      myProject,
      VssBundle.message("message.text.cannot.get.deleted.file", path),
      VssBundle.message("dialog.title.get.info"),
      Messages.getInformationIcon()
    );
  }

  private void onNotExistingFilenameOrProject(String vssPath){
    Messages.showMessageDialog(
      myProject,
      VssBundle.message("message.text.path.is.not.existing.filename.or.project", vssPath),
      VssBundle.message("dialog.title.get.info"),
      Messages.getInformationIcon()
    );
  }

  private void refreshAll(){
    VirtualFile[] files=VssUtil.getPreferredFilesForRefresh(myFiles);
    for (VirtualFile file : files) {
      file.refresh(true, true);
    }
  }

  private boolean allFilesUnderVss()
  {
    for (VirtualFile myFile : myFiles) {
      if (!VssUtil.isUnderVss(myFile, myProject)) return false;
    }
    return true;
  }

  private boolean anyDirectoryPresent()
  {
    for (VirtualFile file : myFiles) {
      if (file.isDirectory()) return true;
    }
    return false;
  }


  private class DirListener extends VssOutputCollector{
    /**
     * Index of direcory to be listed.
     */
    private int myIdx;
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";
    @NonNls private static final String DELETED_MESSAGE = "has been deleted";
    @NonNls private static final String NO_ITEMS_FOUND_MESSAGE = "No items found under $/";

    public DirListener(int idx, List<VcsException> errors){
      super(errors);
      if (!myFiles[idx].isDirectory()) {
        LOG.assertTrue(false,myFiles[idx].getPresentableUrl()+" isn't a directory");
      }
      myIdx=idx;
    }

    public void everythingFinishedImpl(){
      String errorOutput= getCmdOutput();
      if(errorOutput.indexOf(NOT_EXISTING_MESSAGE)!=-1){
        onNotExistingFilenameOrProject(VssUtil.getVssPath(myFiles[myIdx], myProject));
      }else if(errorOutput.indexOf(DELETED_MESSAGE)!=-1){
        VirtualFile file = myFiles[myIdx];
        onHasBeenDeleted(file.getPath().replace('/',File.separatorChar));
      }else{
        if(!parseOutput(errorOutput)){
          return;
        }
      }
      // Collect content of the next file.
      collectFiles(myIdx+1);
    }

    private boolean parseOutput(String errorOutput){
      String[] lines=LineTokenizer.tokenize(errorOutput.toCharArray(),false);
      int offset=0;
      while(offset<lines.length&&offset!=-1){
        String line=lines[offset];
        // found project
        if(StringUtil.startsWithChar(line, '$') && StringUtil.endsWithChar(line, ':')){
          offset=parseProject(lines,offset);
          continue;
        }
        offset++;
      }
      return offset!=-1;
    }

    /**
     * Starts parsing of project.
     * @param offset start index.
     * @return index of next block. Returns -1 if parsing has been cancelled.
     */
    private int parseProject(String[] lines,int offset){
      if(offset>=lines.length){
        return offset;
      }
      String vssProject=lines[offset].substring(0,lines[offset].length()-1);
      String locaProjectPath=VssUtil.getLocalPath(vssProject, myProject);
      if (locaProjectPath==null) {
        LOG.error("Can not resolve local path for " + vssProject);
      }
      File file=new File(locaProjectPath);
      boolean collectFiles;
      if(file.exists()){
        collectFiles=true;
      }else{
        if(myCreateAllFolders){
          if(!(collectFiles=file.mkdir())){
            VssUtil.showErrorMessage(myProject, VssBundle.message("mesasge.text.can.not.create.folder", locaProjectPath),VssBundle.message("message.title.get.error"));
            return -1;
          }
        }else if(myDoNotCreateAllFolders){
          collectFiles=false;
        }else{
          ConfirmMultipleDialog dialog=new ConfirmMultipleDialog(
            VssBundle.message("message.title.confirm.create.folder"),
            VssBundle.message("confirmation.text.folder.create.folder", locaProjectPath),
            myProject);
          dialog.show();
          int exitCode=dialog.getExitCode();
          switch(exitCode){
            case ConfirmMultipleDialog.YES_EXIT_CODE:{
              if(!(collectFiles=file.mkdir())){
                VssUtil.showErrorMessage(myProject, VssBundle.message("mesasge.text.can.not.create.folder", locaProjectPath),VssBundle.message("message.title.get.error"));
                return -1;
              }
              break;
            }case ConfirmMultipleDialog.YES_ALL_EXIT_CODE:{
              if(!(collectFiles=file.mkdir())){
                VssUtil.showErrorMessage(myProject, VssBundle.message("mesasge.text.can.not.create.folder", locaProjectPath),VssBundle.message("message.title.get.error"));
                return -1;
              }
              myCreateAllFolders=true;
              break;
            }case ConfirmMultipleDialog.NO_EXIT_CODE:{
              collectFiles=false;
              break;
            }case ConfirmMultipleDialog.NO_ALL_EXIT_CODE:{
              collectFiles=false;
              myDoNotCreateAllFolders=true;
              break;
            }case ConfirmMultipleDialog.CANCEL_OPTION:{
              return -1;
            }default:{
              LOG.error("Unknown exitCode: "+exitCode);
              collectFiles=false;
            }
          }
        }
      }
      return parseProjectContent(lines,offset+1,vssProject,collectFiles);
    }

    private int parseProjectContent(String[] lines,int offset,String project,boolean collectFiles){
      if(offset>=lines.length){
        return offset;
      }
      // If project is empty.
      if(lines[offset].startsWith(NO_ITEMS_FOUND_MESSAGE)){
        return offset+1;
      }
      while(offset<lines.length) {
        String line = lines[offset];
        // Skip all subprojects.
        if (StringUtil.startsWithChar(line, '$')) {
          offset++;
          continue;
        }
        // End of project content is reached.
        if (line.length() == 0) {
          return offset + 1;
        }
        // Found file.
        if (!collectFiles) {
          offset++;
          continue;
        }
        String file;
        // If file name contains shared version information then I must truncate that version
        // info to get real name of the file.
        int idx = line.lastIndexOf(';');
        if (idx == -1) {
          file = project + '/' + line;
        }
        else {
          file = project + '/' + line.substring(0, idx);
        }
        String localPath = VssUtil.getLocalPath(file, myProject);
        if (localPath == null) {
          LOG.error("Can not resolve local path for " + file);
        }
        myFilesToBeGot.add(new File(localPath));
        offset++;
        continue;
      }
      return offset;
    }
  }

  private class GetListener extends VssOutputCollector
  {
    /**
     * Index of file to be checked out.
     */
    private int myIdx;
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";
    @NonNls private static final String DELETED_MESSAGE = "has been deleted";

    public GetListener(int idx, List<VcsException> errors){
      super(errors);
      myIdx=idx;
    }

    public void everythingFinishedImpl()
    {
      int exitCode = getExitCode();
      String errorOutput = getCmdOutput();

      if(errorOutput.indexOf(NOT_EXISTING_MESSAGE)!=-1){
        onNotExistingFilenameOrProject(VssUtil.getVssPath(getFileToBeGot(myIdx), myProject));
      }else if(errorOutput.indexOf(DELETED_MESSAGE)!=-1){
        onHasBeenDeleted(getFileToBeGot(myIdx).getAbsolutePath());
      }else if( VssUtil.EXIT_CODE_SUCCESS == exitCode || VssUtil.EXIT_CODE_WARNING == exitCode ){
        VssUtil.showStatusMessage(myProject, VssBundle.message("message.text.file.successfully.received", getFileToBeGot(myIdx)));
      }else
        myErrors.add( new VcsException( errorOutput ));

      // Get the next file.
      get( myIdx + 1 );
    }
  }
}
