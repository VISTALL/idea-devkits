package com.intellij.vssSupport.commands;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vcsUtil.VcsUtil;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssOutputCollector;
import com.intellij.vssSupport.VssUtil;

import java.io.File;
import java.util.List;

/**
 * author: lesya
 * author: lloix
 */
public abstract class AbstractVssCommand extends VssCommand
{
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.commands.AbstractVssCommand");

  public AbstractVssCommand( Project project ) {  super( project );  }

  public void execute()
  {
    if (cpRequired()) {
      CpOutputController.executeAfterCP( myProject, getFile().getParentFile(),
                                         getWorkingDirectory(), createOptions(), this, myErrors);
    }
    else {
      runProcess( VssConfiguration.getInstance(myProject), appendIOption( createOptions() ),
                  getWorkingDirectory(), getProcessListener(), null);
    }
  }

  public VssOutputCollector getProcessListener()
  {
    return new VssOutputCollector(myErrors)
    {
      public void everythingFinishedImpl()
      {
        String errorOutput = getCmdOutput();
        if (getExitCode() == VssUtil.EXIT_CODE_FAILURE) {
          myErrors.add(new VcsException(errorOutput));
          setExecutionState(false);
          return;
        }

        if( processQuestion( errorOutput ) )
          return;

        if (getExitCode() == VssUtil.EXIT_CODE_WARNING) {
          final VcsException exception = new VcsException(errorOutput);
          exception.setIsWarning( true );
          myErrors.add(exception);
        }
        if( getExitCode() == VssUtil.EXIT_CODE_SUCCESS ) {
          markAsUpToDate();
          setExecutionState(true);
        }
      }
    };
  }

  protected File getWorkingDirectory() {
    File result = getFile().getParentFile();
    LOG.assertTrue(result.isDirectory());
    return result;
  }

  protected void markAsUpToDate()
  {
    if( shouldMarkAsUpToDate() )
    {
      VirtualFile virtualFile = getVirtualFile();
      if( virtualFile != null )
        VcsUtil.markFileAsUpToDate( virtualFile, myProject );
      else if( isFileCommand() )
        VcsUtil.markFileAsUpToDate(getFile().getAbsolutePath(), myProject);
      else
        VcsUtil.markDirectoryAsUpToDate(getFile().getAbsolutePath(), myProject);
    }
  }

  protected abstract File     getFile();
  protected abstract boolean  isFileCommand();
  protected abstract boolean  cpRequired();
  protected abstract boolean  shouldMarkAsUpToDate();
  protected abstract VirtualFile  getVirtualFile();
  protected abstract List<String> createOptions();
}
