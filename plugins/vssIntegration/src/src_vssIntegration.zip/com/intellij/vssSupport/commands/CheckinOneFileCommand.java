package com.intellij.vssSupport.commands;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VfsUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.BooleanValueHolder;
import com.intellij.vcsUtil.VcsUtil;
import com.intellij.vssSupport.*;
import org.jetbrains.annotations.NonNls;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.util.List;

/**
 * @author: lesya
 * @author: lloix
 */
public class CheckinOneFileCommand extends VssCommand
{
  private final VirtualFile myFile;
  private CheckinOptions myOptions;
  private BooleanValueHolder myIgnoreAllNotCheckedOutConformations;
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.commands.CheckinOneFileCommand");

  public CheckinOneFileCommand( Project project, VirtualFile file, CheckinOptions options,
                                BooleanValueHolder ignoreAllNotCheckedOutConformations ) {
    super(project);
    myFile = file;
    myOptions = options;
    myIgnoreAllNotCheckedOutConformations = ignoreAllNotCheckedOutConformations;
  }

  public CheckinOneFileCommand( Project project, String path, CheckinOptions options,
                                BooleanValueHolder ignoreAllNotCheckedOutConformations ) {
    super(project);
    myFile = VcsUtil.getVirtualFile( path );
    myOptions = options;
    myIgnoreAllNotCheckedOutConformations = ignoreAllNotCheckedOutConformations;
  }

  private static File virtualToIoFile(final VirtualFile parent) {
    return ApplicationManager.getApplication().runReadAction(new Computable<File>() {
      public File compute() {
        return VfsUtil.virtualToIoFile(parent);
      }
    });
  }

  private VirtualFile getParent() {
    return ApplicationManager.getApplication().runReadAction(new Computable<VirtualFile>() {
      public VirtualFile compute() {
        return myFile.getParent();
      }
    });
  }

  public VssOutputCollector getProcessListener() {  return new CheckinFileController( myErrors );  }

  public void execute() {
    CpOutputController.executeAfterCP( myProject, virtualToIoFile( getParent() ),
                                       appendIOption( myOptions.getOptions( myFile )), this, myErrors );
  }

  private class CheckinFileController extends VssOutputCollector
  {
    private static final int IGNORE_ALL = 1;
    private static final int IGNORE = 0;
    @NonNls private static final String NO_ANSWER = "N\n";
    @NonNls private static final String YES_ANSWER = "Y\n";
    @NonNls private static final String NOT_FROM_CURRENT_MESSAGE = "not from the current folder";
    @NonNls private static final String DELETED_MESSAGE = "has been deleted";
    @NonNls private static final String ALREADY_CHECKED_OUT_MESSAGE = "is already checked out, continue?";
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";
    @NonNls private static final String CHECKED_OUT_MESSAGE = "currently checked out";
    @NonNls private static final String PROPERLY_MERGED_QUESTION = "properly merged?";
    @NonNls private static final String NO_CONFLICTS_MESSAGE = "with no conflicts";
    @NonNls private static final String CONFLICTS_MESSAGE = "there are conflicts";

    public CheckinFileController( List<VcsException> errors ) {  super(errors);   }

    private void showStatusMessage(String errorOutput)
    {
      if( getExitCode() != VssUtil.EXIT_CODE_FAILURE )
        VssUtil.showStatusMessage( myProject,  VssBundle.message("message.text.file.checked.in.successfully", getPresentableUrl()));
      else
        VssUtil.showErrorOutput( errorOutput, myProject );
    }


    public void everythingFinishedImpl()
    {
      String errorOutput = getCmdOutput();
      
      if( isConflictsMessage( errorOutput )) {
        addWarning(VssBundle.message("message.text.conflicts.after.merge", getPresentableUrl()));
      }
      else if (isNoConflictMessage( errorOutput )) {
        addWarning(VssBundle.message("message.text.no.conflects.after.merge", getPresentableUrl()));
      }
      else if (isProperlyMergedRequest( errorOutput )) {
        onProperlyMerged();
        setExecutionState( false );
        return;
      }
      else if (isNotCurrentlyCheckedOutMessage( errorOutput )) {
        onNotCheckedOut();
        setExecutionState( false );
        return;
      }
      else if (isNotExistingMessage( errorOutput )) {
        addWarning(VssBundle.message("message.text.path.is.not.existing.filename.or.project", VssUtil.getVssPath(myFile, myProject)));
      }
      else if (isAlreadyCheckedOutMessage( errorOutput )) {
        onIsAlreadyCheckedOut();
        setExecutionState( false );
        return;
      }
      else if (isHasBeenDeletedMessage( errorOutput )) {
        addWarning(VssBundle.message("message.text.file.deleted.cannot.be.checked.in", getPresentableUrl()));
      }
      else if (isNotFromCurrentFolderMessage( errorOutput )) {
        addWarning( VssBundle.message("message.text.file.checked.out.not.from.current.cannot.be.checked.in", getPresentableUrl()) );
      } else if (processQuestion( errorOutput )){
        return;
      }
      else if (VssUtil.EXIT_CODE_WARNING == getExitCode()){
        addWarning( errorOutput );
        showStatusMessage( errorOutput );
      }
      if (VssUtil.EXIT_CODE_SUCCESS == getExitCode() || VssUtil.EXIT_CODE_WARNING == getExitCode()) {
        VcsUtil.markFileAsUpToDate( VssUtil.getPath( myFile ), myProject );
      }
      setExecutionState( true );
    }

    private String getPresentableUrl() {  return getPresentableUrl( myFile );  }

    private void addWarning(final String message) {  myErrors.add( new VcsException( message ).setIsWarning( true ));  }

    private boolean isNotFromCurrentFolderMessage(String errorOutput) {
      return errorOutput.indexOf(NOT_FROM_CURRENT_MESSAGE) != -1;
    }

    private boolean isHasBeenDeletedMessage(String errorOutput) {
      return errorOutput.indexOf(DELETED_MESSAGE) != -1;
    }

    private boolean isAlreadyCheckedOutMessage(String errorOutput) {
      return errorOutput.indexOf(ALREADY_CHECKED_OUT_MESSAGE) != -1 && myOptions.KEEP_CHECKED_OUT;
    }

    private boolean isNotExistingMessage(String errorOutput) {
      return errorOutput.indexOf(NOT_EXISTING_MESSAGE) != -1;
    }

    private boolean isNotCurrentlyCheckedOutMessage(String errorOutput) {
      return errorOutput.indexOf(CHECKED_OUT_MESSAGE) != -1;
    }

    private boolean isProperlyMergedRequest(String errorOutput) {
      return errorOutput.indexOf(PROPERLY_MERGED_QUESTION) != -1;
    }

    private boolean isNoConflictMessage(String errorOutput) {
      return errorOutput.indexOf(NO_CONFLICTS_MESSAGE) != -1;
    }

    private boolean isConflictsMessage(String errorOutput) {
      return errorOutput.indexOf(CONFLICTS_MESSAGE) != -1;
    }

    private void onIsAlreadyCheckedOut() {
      VssConfiguration conf = myOptions.getVssConfiguration();
      CheckoutOptions options = new CheckoutOptions(conf);
      options.REPLACE_WRITABLE = true;
      runProcess(conf, options.getOptions(myFile), myFile, createSimpleCollection());
    }

    private void onNotCheckedOut() {
      if (myIgnoreAllNotCheckedOutConformations.getValue()) {
        setExecutionState(true);
      }
      else {
        int exitCode = showFileIsNotCurrentlyCheckedOutMessage();
        if (exitCode == IGNORE) {
          setExecutionState(true);
        }
        else if (exitCode == IGNORE_ALL) {
          myIgnoreAllNotCheckedOutConformations.setValue(true);
          setExecutionState(true);
        }
        else {
          setExecutionState(false);
        }
      }
    }

    private int showFileIsNotCurrentlyCheckedOutMessage() {
      addWarning(VssBundle.message("message.text.file.not.checked.out", getPresentableUrl()));
      return 1;
    }

    private String getPresentableUrl(final VirtualFile file) {
      return ApplicationManager.getApplication().runReadAction(new Computable<String>() {
        public String compute() {
          return file.getPresentableUrl();
        }
      });
    }

    private void onProperlyMerged()
    {
      boolean fileHasBeenProperlyMerged = fileHasBeenProperlyMerged();

      if (fileHasBeenProperlyMerged)
      {
        myOptions.defaultAnswer = Boolean.TRUE;
        runProcess( myOptions.getVssConfiguration(), myOptions.getOptions( myFile ), myFile, createSimpleCollection());
      }
      else
      {
        myOptions.defaultAnswer = null;
        final boolean redoAutomaticMerge = redoAutomaticMerge();
        runProcess( myOptions.getVssConfiguration(), myOptions.getOptions(myFile), myFile, createSimpleCollection(), new MergeUserInput( redoAutomaticMerge ) );
      }
    }

    private class MergeUserInput implements VSSExecUtil.UserInput
    {
      private boolean redoMerge;
      public MergeUserInput( boolean redoAutoMerge )
      {
        redoMerge = redoAutoMerge; 
      }
      public void doInput( Writer writer ) {
        try {
          answerNo(writer);
          if( redoMerge )
            answerYes(writer);
          else
            answerNo(writer);
          writer.flush();
        }
        catch (IOException e) {
          showProcessErrorMessage(myOptions.getVssConfiguration(), e);
        }
      }
    }

    private void answerYes(Writer writer) throws IOException {  writer.write( YES_ANSWER );  }
    private void answerNo (Writer writer) throws IOException {  writer.write( NO_ANSWER );   }

    private VssOutputCollector createSimpleCollection() {
      return new VssOutputCollector(myErrors) {
        public void everythingFinishedImpl() {
          showStatusMessage(getCmdOutput());
          setExecutionState(true);
        }
      };
    }

    private boolean redoAutomaticMerge()
    {
      final boolean[] status = new boolean[ 1 ];
      LOG.assertTrue( ApplicationManager.getApplication().isDispatchThread() );
      status[ 0 ] = showDialog( myProject, VssBundle.message("confirmation.text.redo.the.automatic.merge"),
                                VssBundle.message("confirmation.title.checkin"), Messages.getQuestionIcon() );
      /*
      else
      {
        Runnable runnable = new Runnable() {
          public void run() { status[ 0 ] = showDialog( myProject, VssBundle.message("confirmation.text.redo.the.automatic.merge"),
                                                        VssBundle.message("confirmation.title.checkin"), Messages.getQuestionIcon() ); } };
        ApplicationManager.getApplication().invokeAndWait( runnable, ModalityState.defaultModalityState() );
      }
      */
      return status[ 0 ];
    }

    private boolean fileHasBeenProperlyMerged()
    {
      final boolean[] status = new boolean[ 1 ];
      LOG.assertTrue( ApplicationManager.getApplication().isDispatchThread() );
      status[ 0 ] = showDialog( myProject, VssBundle.message("request.text.properly.merged", getPresentableUrl()),
                                VssBundle.message("confirmation.title.checkin"), Messages.getQuestionIcon() );
      /*
      {
        Runnable runnable = new Runnable() {
          public void run() { status[ 0 ] = showDialog( myProject, VssBundle.message("request.text.properly.merged", getPresentableUrl()),
                                  VssBundle.message("confirmation.title.checkin"), Messages.getQuestionIcon() ); } };
        ApplicationManager.getApplication().invokeAndWait( runnable, ModalityState.defaultModalityState() );
      }
      */
      return status[ 0 ];
    }
    
    private boolean showDialog( Project project, String message, String title, Icon icon )
    {
      return Messages.showYesNoDialog( project, message, title, icon ) == 0;
    }
  }
}
