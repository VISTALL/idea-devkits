/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.text.LineTokenizer;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssOutputCollector;
import com.intellij.vssSupport.VssUtil;
import org.jetbrains.annotations.NonNls;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 * Date: Nov 9, 2006
 * Time: 10:53:37 AM
 * To change this template use File | Settings | File Templates.
 */

public class DirectoryCommand extends VssCommandAbstract
{
  @NonNls private static final String DIR_COMMAND = "Dir";
  @NonNls private static final String RECURSIVE_OPTION = "-R";

  private HashMap<String, String> vssProjectPaths = new HashMap<String,String> ();
  public HashSet<String> projectFiles;

  /**
   * @param project project.
   * directory must be a directory and this directory should be under VSS control,
   * i.e. method <code>VssUtil.isUnderVss</code> must return <code>true</code>.
   */
  public DirectoryCommand( Project project, List<VcsException> errors )
  {
    super(project, errors);
    projectFiles = new HashSet<String>();

    VssConfiguration config = VssConfiguration.getInstance( myProject );
    for( int i = 0; i < config.getMapItemCount(); i++ )
    {
      vssProjectPaths.put( config.getMapItem( i ).VSS_PATH, config.getMapItem( i ).LOCAL_PATH );
    }
  }

  public DirectoryCommand( Project project, String path, List<VcsException> errors )
  {
    super(project, errors);
    projectFiles = new HashSet<String>();

    VssConfiguration config = VssConfiguration.getInstance( myProject );
    path = VssUtil.getCanonicalLocalPath( path ).toLowerCase();

    //  - Either given folder is under any of the repository roots - add it to
    //    the processing list (and stop selecting),
    //  - Or given folder is higher repository roots - add all roots below to the
    //    processing list.

    for( int i = 0; i < config.getMapItemCount(); i++ )
    {
      String mappedPath = VssUtil.getCanonicalLocalPath( config.getMapItem( i ).LOCAL_PATH ).toLowerCase();

      if( path.startsWith( mappedPath ) ) // given folder is under some repository folder
      {
        VirtualFile aux = VssUtil.getVirtualFile( path );
        path = VssUtil.getVssPath( aux, myProject );
        vssProjectPaths.put( path, config.getMapItem( i ).LOCAL_PATH );
        break;
      }
      else
      if( mappedPath.startsWith( path ) )
      {
        vssProjectPaths.put( config.getMapItem( i ).VSS_PATH, config.getMapItem( i ).LOCAL_PATH );
      }
    }
  }

  public void execute()
  {
    for( String vssPath : vssProjectPaths.keySet() )
    {
      executeOnPath( vssPath );
    }
  }

  private void executeOnPath( final String vssPath )
  {
    VssConfiguration config = VssConfiguration.getInstance( myProject );

    // Launch ss.exe.
    try
    {
      String localPath = vssProjectPaths.get( vssPath );
      DirListener dirListener = new DirListener( myErrors );

      ArrayList<String> options = new ArrayList<String>();
      options.add( DIR_COMMAND );
      options.add( vssPath );
      options.add( RECURSIVE_OPTION );
      if( config.USER_NAME.length() > 0 )
        options.add( config.getYOption() );

      VSSExecUtil.runProcess( config.CLIENT_PATH, options.toArray( new String[ options.size() ] ),
                              config.getSSDIREnv(), localPath, dirListener);
    }
    catch( ExecutionException exc )
    {
      String msg = config.checkCmdPath();
      myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
      config.setBusy( false ); // release "busy" state
    }
  }

  /**
   * Use this listener to catch messages from "Checkout" VSS command.
   */
  private class DirListener extends VssOutputCollector
  {
    @NonNls private static final String TOTAL_SIG = " items(s)";
    @NonNls private static final String NO_ITEMS_FOUND_SIG = "No items found under";
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";

    DirListener( List<VcsException> errors ) {  super(errors);   }

    public void processCriticalErrorImpl() {}

    public void everythingFinishedImpl()
    {
      String text = getCmdOutput();

      if( text.indexOf( NOT_EXISTING_MESSAGE ) != -1 )
      {
        myErrors.add( new VcsException(VssBundle.message( "message.text.path.is.not.existing.filename.or.project", vssProjectPaths)));
        return;
      }

      String lastFolderName = vssProjectPaths.keySet().iterator().next();
      lastFolderName = VssUtil.getLocalPath( lastFolderName, myProject );

      String[] lines = LineTokenizer.tokenize( text, false );
      for( String line : lines )
      {
        if( line.length() == 0 )
          continue;

        //  Skip lines which indicate subfolders of the current folder.
        if( line.charAt( 0 ) == '$' && ( line.charAt( line.length() - 1 ) != ':' ))
          continue;

        //  Several patterns serve as the default notifications on actions done.
        //  Skip these lines.
        if( line.indexOf( TOTAL_SIG ) != -1 || line.indexOf( NO_ITEMS_FOUND_SIG ) != -1 )
          continue;

        if( line.charAt( line.length() - 1 ) == ':' )
        {
          lastFolderName = line.substring( 0, line.length() - 1 );
          lastFolderName = VssUtil.getLocalPath( lastFolderName, myProject );
        }
        else
        {
          String fileName = lastFolderName + "\\" + line;
          fileName = VssUtil.getCanonicalLocalPath( fileName ).toLowerCase();
          projectFiles.add( fileName );
        }
      }
    }
  }
}