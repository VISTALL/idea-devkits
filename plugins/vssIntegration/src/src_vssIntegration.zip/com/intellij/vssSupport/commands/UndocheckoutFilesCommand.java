package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.application.ModalityState;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.*;
import com.intellij.vssSupport.ui.ConfirmMultipleDialog;
import com.intellij.vssSupport.ui.UndocheckoutFilesDialog;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.Arrays;
import java.util.List;

/**
 * @author Vladimir Kondratyev
 */
public class UndocheckoutFilesCommand extends VssCommandAbstract
{
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.commands.UndocheckoutFilesCommand");

  private VirtualFile[] myFiles;
  private UndocheckoutOptions myBaseOptions;
  private boolean myCanShowOptions;
  private boolean mySuppressOnNotCheckedOutMessage;

  private boolean myReplaceAllLocalCopies;
  private boolean myDoNotReplaceAllLocalCopies;

  /**
   * Creates new <code>UndocheckoutFilesCommand</code> instance.
   * @param files files to be unchecked out. Note, that the passed
   * files must be under VSS control, i.e. <code>VssUtil.isUnderVss</code>
   * method must return <code>true</code> for each of them.
   * @param baseOptions command options.
   * @param canShowOptions whether the command shows option dialog.
   */
  public UndocheckoutFilesCommand( Project project, VirtualFile[] files,
                                   UndocheckoutOptions baseOptions, boolean canShowOptions,
                                   boolean suppressNotCheckedOutDiag, List<VcsException> errors )
  {
    super( project, errors );
    for( VirtualFile virtualFile : files )
    {
      if (virtualFile.isDirectory())
        LOG.error( virtualFile.getPresentableUrl() + " isn't a file" );
    }
    Arrays.sort( files, VirtualFileComparator.INSTANCE );
    myFiles = files;
    myBaseOptions = baseOptions;

    myCanShowOptions = canShowOptions;
    mySuppressOnNotCheckedOutMessage = suppressNotCheckedOutDiag;
  }

  public void execute()
  {
    if( myBaseOptions == null){
      if( (myBaseOptions = createOptions() ) == null )
        return;
    }
    
    FileDocumentManager.getInstance().saveAllDocuments();
    undoCheckOut( 0 );
  }

  @Nullable
  private UndocheckoutOptions createOptions()
  {
    final VssConfiguration config = VssConfiguration.getInstance( myProject );
    final UndocheckoutOptions options = config.getUndocheckoutOptions();
    final boolean[] cancelled = new boolean[ 1 ]; cancelled[ 0 ] = false;

    if( myCanShowOptions )
    {
      if( ApplicationManager.getApplication().isDispatchThread() )
      {
        cancelled[ 0 ] = runDialogCreateOptions( options );
      }
      else
      {
        Runnable runnable = new Runnable() {  public void run() { cancelled[ 0 ] = runDialogCreateOptions( options ); } };
        ApplicationManager.getApplication().invokeAndWait( runnable, ModalityState.defaultModalityState() );
      }
    }
    return cancelled[ 0 ] ? null : options;
  }

  private boolean runDialogCreateOptions( UndocheckoutOptions options )
  {
    UndocheckoutFilesDialog dialog = new UndocheckoutFilesDialog( myProject );
    dialog.init( options );
    if( myFiles.length == 1)
      dialog.setTitle( VssBundle.message("dialog.title.undo.check.out.file", myFiles[ 0 ].getName()) );
    else
      dialog.setTitle( VssBundle.message("dialog.title.undo.check.out.multiple") );

    dialog.show();
    boolean cancelled = !dialog.isOK();
    if( !cancelled )
      dialog.commit( options );

    return cancelled;
  }

  private void refreshAll()
  {
    VirtualFile[] files = VssUtil.getPreferredFilesForRefresh( myFiles );
    for( VirtualFile file : files )
      file.refresh( true, true );
  }

  private void undoCheckOut(int idx)
  {
    if( idx >= myFiles.length ){
      refreshAll();
      return;
    }

    // If base options specify leave local copies or replace then everything is OK.
    //
    // If base options specify ask before replace local files then our life become a
    // litte bit difficult.
    // First of all I need to run Undocheckout with -I-N option. It cause replacement
    // of unchenged file but skip the operation if the file has been changed. So after
    // that I should analize output and repeat with rigth "Yes" or "No" answer.

    runVss( idx, myBaseOptions, new UndocheckoutListener( idx, myErrors ));
  }

  private void runVss( int idx, UndocheckoutOptions options, VssOutputCollector processListener )
  {
    VirtualFile file = myFiles[ idx ];
    VssConfiguration config = options.getVssConfiguration();
    try{
      VSSExecUtil.runProcess( config.CLIENT_PATH, options.getOptions( file ), config.getSSDIREnv(),
                              file.getParent().getPath().replace('/',File.separatorChar), processListener);
    }
    catch( ExecutionException exc )
    {
      String msg = config.checkCmdPath();
      myErrors.add( new VcsException( (msg != null) ? msg : exc.getLocalizedMessage() ));
    }
  }

  private void showStatusMessage(int idx,int exitCode,String errorOutput){
    if( VssUtil.EXIT_CODE_SUCCESS == exitCode || VssUtil.EXIT_CODE_WARNING == exitCode )
      VssUtil.showStatusMessage(myProject, VssBundle.message("message.text.undo.successfully", myFiles[idx].getPresentableUrl()));
    else
      VssUtil.showErrorOutput(errorOutput, myProject);
  }

  private class UndocheckoutListener extends VssOutputCollector
  {
    private int myIdx;
    @NonNls private static final String CHECKED_OUT_MESSAGE = "currently checked out";
    @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";
    @NonNls private static final String DELETED_MESSAGE = "has been deleted";
    @NonNls private static final String NOT_FROM_CURRENT_MESSAGE = "not from the current folder";
    @NonNls private static final String UNDO_CHECKOUT_CONF_MESSAGE = "Undo check out and lose changes?(Y/N)N";

    public UndocheckoutListener(int idx, List<VcsException> errors)
    {
      super( errors );
      myIdx = idx;
    }

    public void everythingFinishedImpl()
    {
      String errorOutput = getCmdOutput();
      if( errorOutput.indexOf( CHECKED_OUT_MESSAGE ) != -1 )
      {
        if( !mySuppressOnNotCheckedOutMessage )
          onNotCheckedOut();
      }
      else if( errorOutput.indexOf( NOT_EXISTING_MESSAGE ) != -1 )
        onNotExistingFilenameOrProject();
      else if( errorOutput.indexOf( DELETED_MESSAGE )!= -1 )
        onHasBeenDeleted();
      else if( errorOutput.indexOf( NOT_FROM_CURRENT_MESSAGE )!= -1)
        onNotFromCurrentFolder();
      else if( errorOutput.indexOf( UNDO_CHECKOUT_CONF_MESSAGE )!= -1){
        onLooseChanges();
        return;
      }else
        showStatusMessage(myIdx,getExitCode(),errorOutput);

      undoCheckOut( myIdx + 1 );
    }

    private void onLooseChanges()
    {
      int exitCode = askOption();

      if(ConfirmMultipleDialog.YES_EXIT_CODE == exitCode)
      {
        UndocheckoutOptions options = myBaseOptions.copy();
        options.REPLACE_LOCAL_COPY = UndocheckoutOptions.OPTION_REPLACE;
        runVss( myIdx, options,  new VssOutputCollector(myErrors){
                                        public void everythingFinishedImpl(){
                                          showStatusMessage( myIdx, getExitCode(), getCmdOutput() );
                                          undoCheckOut( myIdx + 1 );
                                        }
                                 } );
        return;
      }
      else if(ConfirmMultipleDialog.YES_ALL_EXIT_CODE == exitCode)
      {
        UndocheckoutOptions options = myBaseOptions.copy();
        options.REPLACE_LOCAL_COPY = UndocheckoutOptions.OPTION_REPLACE;
        myReplaceAllLocalCopies = true;
        runVss( myIdx, options, new VssOutputCollector(myErrors){
                                      public void everythingFinishedImpl(){
                                        showStatusMessage(myIdx,getExitCode(), getCmdOutput());
                                        undoCheckOut( myIdx + 1 );
                                      }
                                } );
        return;
      }else if(ConfirmMultipleDialog.NO_EXIT_CODE==exitCode){
        // Skip current file and continue
      }else if(ConfirmMultipleDialog.NO_ALL_EXIT_CODE==exitCode){
        myDoNotReplaceAllLocalCopies=true;
        // Skip current file and continue
      }else if(ConfirmMultipleDialog.CANCEL_OPTION==exitCode){
        // Break undo sequence
        return;
      }
      undoCheckOut( myIdx + 1 );
    }

    private int askOption()
    {
      final int[] exitCode = new int[ 1 ];
      if( myReplaceAllLocalCopies )
        exitCode[ 0 ] = ConfirmMultipleDialog.YES_ALL_EXIT_CODE;
      else
      if( myDoNotReplaceAllLocalCopies )
        exitCode[ 0 ] = ConfirmMultipleDialog.NO_ALL_EXIT_CODE;
      else
      {
        if( ApplicationManager.getApplication().isDispatchThread() )
          exitCode[ 0 ] = runDialogAskOption();
        else
        {
          Runnable runnable = new Runnable() {  public void run() {  exitCode[ 0 ] = runDialogAskOption(); } };
          ApplicationManager.getApplication().invokeAndWait( runnable, ModalityState.defaultModalityState() );
        }
      }
      return exitCode[ 0 ];
    }

    private int  runDialogAskOption()
    {
      ConfirmMultipleDialog dialog = new ConfirmMultipleDialog(
        VssBundle.message("confirm.text.undo.check.out"),
        VssBundle.message("confirm.text.file.changed.undo", myFiles[myIdx].getPresentableUrl()), myProject);
      dialog.show();
      return dialog.getExitCode();
    }

    private void onHasBeenDeleted()
    {
      myErrors.add( new VcsException( VssBundle.message("message.text.cannot.undo.file.deleted", myFiles[myIdx].getPresentableUrl()) ));
    }

    private void onNotFromCurrentFolder()
    {
      myErrors.add( new VcsException( VssBundle.message("message.text.cannot.undo.checked.out.not.from.current", myFiles[myIdx].getPresentableUrl()) ));
    }

    private void onNotCheckedOut()
    {
      myErrors.add( new VcsException( VssBundle.message("message.text.file.not.checked.out", myFiles[myIdx].getPresentableUrl()) ));
    }

    private void onNotExistingFilenameOrProject()
    {
      myErrors.add( new VcsException( VssBundle.message("message.text.path.is.not.existing.filename.or.project", VssUtil.getVssPath(myFiles[myIdx], myProject)) ));
    }
  }
}