package com.intellij.vssSupport.commands;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.AddOptions;
import com.intellij.vssSupport.VssBundle;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.ui.AddFileDialog;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * @author Vladimir Kondratyev
 */
public class AddFileCommand extends VssCommandOnVirtualFile
{
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.commands.AddFileCommand");

  private AddOptions myOptions;
  private boolean myCanShowOptions;

  public AddFileCommand( Project project, VirtualFile virtualFile, AddOptions options, boolean canShowOptions )
  {
    super( project, virtualFile );
    LOG.assertTrue(!virtualFile.isDirectory());

    myOptions = options;
    myCanShowOptions = canShowOptions;

    //-------------------------------------------------------------------------
    //  Notify base class that this command should not be repeated if for a
    //  question issued to the user a positive answer was given.
    //  In particular, this modifier prohibits running "ADD" command twice if
    //  user tries to add a file which was deleted from the repository.
    //-------------------------------------------------------------------------
    continueUponPositiveAnswer = false;
  }

  public void execute() {
    if (myOptions == null) {
      if ((myOptions = createAddOptions()) == null) {
        return;
      }
    }

    super.execute();
  }

  protected List<String> createOptions() {
    return myOptions.getOptions(myFile);
  }

  @Nullable
  protected AddOptions createAddOptions() {
    VssConfiguration config = VssConfiguration.getInstance(myProject);
    AddOptions options = config.getAddOptions();
    if (myCanShowOptions) {
      AddFileDialog editor = new AddFileDialog(myProject);
      editor.setTitle(VssBundle.message("dialog.title.add.file.options", myFile.getName()));
      editor.init(options);
      editor.show();
      if (!editor.isOK()) {
        return null;
      }
      editor.commit(options);
    }
    return options;
  }
}