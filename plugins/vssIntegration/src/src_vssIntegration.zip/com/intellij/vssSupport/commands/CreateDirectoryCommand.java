package com.intellij.vssSupport.commands;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.vssSupport.VssConfiguration;
import org.jetbrains.annotations.NonNls;

import java.util.ArrayList;
import java.util.List;

/**
 * @author: lesya
 * @author: LloiX
 */
public class CreateDirectoryCommand extends VssCommandOnVirtualFile
{
  @NonNls private static final String CREATE_COMMAND = "Create";
  @NonNls private static final String _I__OPTION = "-I-";

  public CreateDirectoryCommand( Project project, VirtualFile file )
  {
    super( project, file );
  }

  protected List<String> createOptions()
 {
    List<String> options = new ArrayList<String>();
    options.add(CREATE_COMMAND);
    options.add(myFile.getName());
    options.add(_I__OPTION);
    VssConfiguration config = VssConfiguration.getInstance(myProject);
    if( config.USER_NAME.length() > 0 )
      options.add(config.getYOption());

    return options;
  }

}
