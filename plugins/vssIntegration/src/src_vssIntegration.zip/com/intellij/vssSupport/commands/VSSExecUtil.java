package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.configurations.GeneralCommandLine;
import com.intellij.execution.process.DefaultJavaProcessHandler;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.vssSupport.VssOutputCollector;
import org.jetbrains.annotations.NonNls;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;

/**
 * @author dyoma
 * @author LloiX
 */
public class VSSExecUtil
{
  @NonNls private final static String SYSTEMROOT_VAR = "SYSTEMROOT";
  @NonNls private final static String TEMP_VAR = "TEMP";
  @NonNls private final static String USER_SIG_OPTION_PREFIX = " -Y";

  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.commands.VSSExecUtil");

  private VSSExecUtil() {}

  public static interface UserInput {
    void doInput(Writer writer);
  }

  public static void runProcess( String exePath, String[] programParms,
                                 HashMap<String, String> envParms, String workingDir,
                                 VssOutputCollector listener) throws ExecutionException
  {
    runProcess( exePath, programParms, envParms, workingDir, listener, null );
  }
  public synchronized static void runProcess( String exePath, String[] programParms,
                                 HashMap<String, String> envParams, String workingDir,
                                 VssOutputCollector listener, UserInput input ) throws ExecutionException

  {
    addVSS2005Values( envParams );

    GeneralCommandLine generalCommandLine = new GeneralCommandLine();
    generalCommandLine.addParameters( programParms );
    generalCommandLine.setWorkDirectory( workingDir );
    generalCommandLine.setEnvParams( envParams );
    generalCommandLine.setExePath( exePath );

    LOG.info( generalCommandLine.getCommandLineString() );

    final ProgressIndicator progress = ProgressManager.getInstance().getProgressIndicator();
    if (progress != null)
    {
      String processHeader = prepareTitleString( generalCommandLine.getCommandLineString() );
      progress.setText( processHeader );
    }

    final DefaultJavaProcessHandler result = new DefaultJavaProcessHandler(generalCommandLine);

    if (listener == null) {
      listener = new VssOutputCollector(null) { public void everythingFinishedImpl() {} };
    }

    result.addProcessListener( listener );
    result.startNotify();

    if (input != null) {
      final OutputStreamWriter writer = new OutputStreamWriter(result.getProcessInput());
      try     { input.doInput(writer); }
      finally { try { writer.close(); } catch (IOException e) { /*ignore*/  }  }
    }

    result.waitFor();
    result.removeProcessListener( listener );

    if (progress != null) {
      progress.setText("");
    }

    if (listener.criticalErrorOccured()) {
      listener.processCriticalErrorImpl();
    } else {
      listener.everythingFinishedImpl();
    }
  }

  public static void runProcessDoNotWaitForTermination( String exePath, String[] programParms,
                                                        HashMap<String, String> envParams ) throws ExecutionException
  {
    addVSS2005Values( envParams );

    GeneralCommandLine generalCommandLine = new GeneralCommandLine();
    generalCommandLine.addParameters(programParms);
    generalCommandLine.setWorkDirectory(null);
    generalCommandLine.setEnvParams( envParams );
    generalCommandLine.setExePath(exePath);

    final DefaultJavaProcessHandler result = new DefaultJavaProcessHandler(generalCommandLine);
    result.startNotify();
  }

  /**
   * Add two system environment variables to the environment of this process.
   * This is required for Visual SourceSafe 2005 support.
   */
  private static void addVSS2005Values( HashMap<String, String> envParams )
  {
    String sysRootVar = System.getenv( SYSTEMROOT_VAR );
    String tempVar = System.getenv( TEMP_VAR );
    if( sysRootVar != null )
      envParams.put( SYSTEMROOT_VAR, sysRootVar );
    if( tempVar != null )
      envParams.put( TEMP_VAR, tempVar );
  }

  private static String  prepareTitleString( String original )
  {
    String result = original;
    int index = result.indexOf( USER_SIG_OPTION_PREFIX );
    if( index != -1 )
    {
      int blankIndex = result.indexOf( ' ', index + 2 );
      if( blankIndex == -1 )
        result = result.substring( 0, index );
      else
        result = result.substring( 0, index ) + result.substring( blankIndex );
    }
    return result;
  }
}
