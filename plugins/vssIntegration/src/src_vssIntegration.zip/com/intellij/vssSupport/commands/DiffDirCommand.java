package com.intellij.vssSupport.commands;

import com.intellij.execution.ExecutionException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.vcsUtil.VcsUtil;
import com.intellij.vssSupport.DiffDirParser;
import com.intellij.vssSupport.VssConfiguration;
import com.intellij.vssSupport.VssOutputCollector;
import com.intellij.vssSupport.VssUtil;
import org.jetbrains.annotations.NonNls;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 * Date: Mar 13, 2006
 */
public class DiffDirCommand extends VssCommand
{
    @NonNls private static final String DIFF_DIR_COMMAND = "Diff";

    public HashSet<String> filesNew = new HashSet<String>();
    public HashSet<String> filesDeleted = new HashSet<String>();
    public HashSet<String> filesChanged = new HashSet<String>();
    public boolean         folderNotFound = false;

    private String vssPath;
    private String tmpPath;

    public DiffDirCommand(Project project, String subprojectPath)
    {
      super( project );
      tmpPath = subprojectPath;
      vssPath = VssUtil.getVssPathForLocalPath( tmpPath, true, project );
    }

    public VssOutputCollector getProcessListener()
    {
      return new VssStatusListener( myErrors );
    }

    public void execute()
    {
      //  Avoid running the command with NULL Vss path. This is possible when
      //  input path lies outside the Vss project store.
      if( vssPath != null )
      {
        VssConfiguration config = VssConfiguration.getInstance( myProject );

        //  Issue "diff" command to vss command line tool, retrieve its responce
        //  and parse it.

        LinkedList<String> options = new LinkedList<String>();
        options.add( DIFF_DIR_COMMAND );
        options.add( vssPath );
        if( config.USER_NAME.length() > 0 )
          options.add( config.getYOption() );

        try {
          VSSExecUtil.runProcess( config.CLIENT_PATH, options.toArray(new String[ options.size() ]),
                                  config.getSSDIREnv(), tmpPath, getProcessListener() );
        }
        catch (ExecutionException exc) {
            myErrors.add( new VcsException( exc.getLocalizedMessage() ) );
        }
        options.clear();
      }
    }

    /**
     * Use this listener to catch messages from "Diff" VSS command.
     * If "Diff" command completed successfully then it parses command
     * output and updates the content of VssFileStatusManager.
     */
    private class VssStatusListener extends VssOutputCollector
    {
      @NonNls private static final String DELETED_MESSAGE = "has been deleted";
      @NonNls private static final String NOT_EXISTING_MESSAGE = "is not an existing";
      @NonNls private static final String PROJECT_NOT_IN_VSS = "File or project not found";

      public VssStatusListener(List<VcsException> errors)
      {
        super( errors );
      }

      public void everythingFinishedImpl()
      {
        final String errorOutput = getCmdOutput();

        if( errorOutput.indexOf( PROJECT_NOT_IN_VSS ) != -1 )
          folderNotFound = true;
        else
        if( errorOutput.indexOf(DELETED_MESSAGE) != -1 )
          filesDeleted.add( tmpPath );
        else
        if (errorOutput.indexOf(NOT_EXISTING_MESSAGE) != -1)
          filesNew.add( tmpPath );
        else
        {
          if( VssUtil.EXIT_CODE_FAILURE == getExitCode() )
          {
            myErrors.add( new VcsException( errorOutput ) );
          }
          else
            parseContent( errorOutput );
        }
      }

      private void parseContent( String out )
      {
        if( out.indexOf( PROJECT_NOT_IN_VSS ) != -1 )
        {
          new PropertiesCommand( myProject, tmpPath, true ).execute();
        }
        else
        {
          DiffDirParser.parse( out );
          for( String item : DiffDirParser.filesNew )
          {
            if( VcsUtil.isPathUnderProject( myProject, item ))
              filesNew.add( VssUtil.getCanonicalLocalPath( item ) );
          }
          for( String item : DiffDirParser.filesDeleted )
            filesDeleted.add( VssUtil.getCanonicalLocalPath( item ) );
          
          for( String item : DiffDirParser.filesChanged )
            filesChanged.add( VssUtil.getCanonicalLocalPath( item ) );
        }
      }
   }
}
