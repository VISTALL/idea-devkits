/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.vssSupport;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.history.*;
import com.intellij.util.ArrayUtil;
import com.intellij.util.ui.ColumnInfo;
import com.intellij.vssSupport.commands.GetFileCommand;
import com.intellij.vssSupport.commands.HistoryCommand;
import com.intellij.vssSupport.commands.HistoryParser;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 */
public class VssFileHistoryProvider implements VcsHistoryProvider
{
  private static final Logger LOG = Logger.getInstance("#com.intellij.vssSupport.VssFileHistoryProvider");

  private Project project;

  public VssFileHistoryProvider( Project project )
  {
    this.project = project;
  }

  @NonNls
  @Nullable
  public String getHelpId() {  return null;  }

  @Nullable
  public HistoryAsTreeProvider getTreeHistoryProvider() {  return null;   }

  public ColumnInfo[] getRevisionColumns() {  return new ColumnInfo[0];   }

  public AnAction[] getAdditionalActions(final FileHistoryPanel panel) {  return new AnAction[0];   }

  public VcsHistorySession createSessionFor( FilePath filePath ) throws VcsException
  {
    try
    {
      HistoryCommand cmd = new HistoryCommand( project, filePath );
      cmd.execute();

      if( cmd.myErrors.size() > 0 )
        throw cmd.myErrors.get( 0 );

      ArrayList<HistoryParser.SubmissionData> changes = cmd.changes;
      ArrayList<VcsFileRevision> revisions = new ArrayList<VcsFileRevision>();
      for( HistoryParser.SubmissionData change : changes )
      {
        VcsFileRevision rev = new VssFileRevision( change, filePath );
        revisions.add( rev );
      }

      return new VssHistorySession( revisions );
    }
    catch( Throwable e )
    {
      //  This is one of the potential problems. And most common.
      throw new VcsException( VssBundle.message("message.file.deleted.or.not.in.repository") );
    }
  }

  private class VssFileRevision implements VcsFileRevision
  {
    private int    version;
    private String submitter;
    private Date changeDate;
    private String comment;

    private FilePath path;
    private byte[] content;

    public VssFileRevision( HistoryParser.SubmissionData data, FilePath path )
    {
      Locale locale = Locale.getDefault();

      version = Integer.parseInt( data.version );
      submitter = data.submitter;
      comment = data.comment;
      changeDate = new Date();

      long dateValue = 0;

      //  Parse separately date and time using several simple heuristics.
      try
      {
        DateFormat df = DateFormat.getDateInstance( DateFormat.SHORT, locale );
        changeDate = df.parse( data.changeDate );
        dateValue = changeDate.getTime();
      }
      catch( ParseException e )
      {
        //  Hack: when user modifies an existing locale, these changes are
        //  not propagated into ResourceBundle which is used by SimpleDateFormat
        //  stuff. Prepare seveal more commonly used and try to precess them
        //  separately.
        //  Todo: move a format into IDEA property?

        @NonNls String[] dateFormats = new String[] { "M/d/y", "M.d.y", "d.M.y", "d.MM.yy", "d-M-y", "M/d/yy", "M.d.yy", "d.M.yy", "d-M-yy" };

        for( String format : dateFormats )
        {
          try
          {
            DateFormat df = new SimpleDateFormat( format );
            Date date = df.parse( data.changeTime );
            dateValue = date.getTime();
            break;
          }
          catch( ParseException e2 ){
            System.out.println( e.getMessage() + " with format " + format );
          }
        }
      }

      try
      {
        DateFormat tf = DateFormat.getTimeInstance( DateFormat.SHORT, locale );
        Date changeTime = tf.parse( data.changeTime );
        changeDate.setTime( dateValue + changeTime.getTime() );
      }
      catch( ParseException e )
      {
        //  Hack: Same as in the case of Date value parsing.
        @NonNls String[] formats = new String[] { "h:mm a", "H:mm", "hh:mm a", "HH:mm" };

        for( String format : formats )
        {
          try
          {
            DateFormat tf = new SimpleDateFormat( format );
            Date changeTime = tf.parse( data.changeTime );
            changeDate.setTime( dateValue + changeTime.getTime() );
            break;
          }
          catch( ParseException e2 ){
            System.out.println( e.getMessage() + " with format " + format );
          }
        }
      }

      this.path = path;
    }

    public VcsRevisionNumber getRevisionNumber() { return new VcsRevisionNumber.Int( version ); }
    public String getBranchName() { return null; }
    public Date getRevisionDate() { return changeDate; }
    public String getAuthor()     { return submitter; }
    public String getCommitMessage() { return comment; }
    public int    getRevisionIntNumber() { return version; }

    public void loadContent()
    {
      ArrayList<VcsException> errors = new ArrayList<VcsException>();
      String tmpDir = FileUtil.getTempDirectory();
      
      GetFileCommand cmd = new GetFileCommand( project, path.getPath(), Integer.toString( version ), errors );
      cmd.setOutputPath( tmpDir );
      cmd.execute();

      File fileContent = new File( tmpDir, path.getName() );
      content = ArrayUtil.EMPTY_BYTE_ARRAY;
      try
      {
        content = FileUtil.loadFileBytes( fileContent );
        fileContent.delete();
      }
      catch( IOException e ){
        LOG.error( e.getMessage() );
      }
    }

    public byte[] getContent()
    {
      return content;
    }

    public int compareTo( Object revision )
    {
      return changeDate.compareTo( ((VcsFileRevision)revision).getRevisionDate() );
    }
  }

  private static class VssHistorySession extends VcsHistorySession
  {
    public VssHistorySession( ArrayList<VcsFileRevision> revs )
    {
      super( revs );
    }

    protected VcsRevisionNumber calcCurrentRevisionNumber()
    {
      VcsRevisionNumber revision;
      try
      {
        int maxRevision = 0;
        for( VcsFileRevision rev : getRevisionList() )
        {
          maxRevision = Math.max( maxRevision, ((VssFileRevision)rev).getRevisionIntNumber() );
        }
        revision = new VcsRevisionNumber.Int( maxRevision + 1 );
      }
      catch( Exception e )
      {
        //  We can catch e.g. com.starbase.starteam.ItemNotFoundException if we
        //  try to show history records for the deleted file.
        revision = VcsRevisionNumber.NULL;
      }
      return revision;
    }

    @Override
    public synchronized boolean refresh() {
      // Don't refresh history by timer - this is too expensive performance-wise
      return false;
    }
  }
}
