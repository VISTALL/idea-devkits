/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.vssSupport;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.FileStatus;
import com.intellij.openapi.vcs.FileStatusManager;
import com.intellij.openapi.vcs.changes.VcsDirtyScopeManager;
import com.intellij.openapi.vfs.*;

import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: lloix
 * Date: Sep 21, 2006
 * Time: 6:47:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class VFListener implements VirtualFileListener
{
  private Project myProject;
  private VssVcs  host;

  public VFListener( Project project, VssVcs host ) {  myProject = project; this.host = host; }

  public void beforeContentsChange(VirtualFileEvent event) {}
  public void contentsChanged(VirtualFileEvent event) {}
  public void fileDeleted(VirtualFileEvent event) {}
  public void fileMoved(VirtualFileMoveEvent event) {}

  public void beforeFileMovement(VirtualFileMoveEvent event)
  {
    if( !event.getFile().isDirectory() )
    {
      String oldName = event.getFile().getPath();
      String newName = event.getNewParent().getPath() + "/" + event.getFile().getName();

      String prevName = host.renamedFiles.get( oldName );
      if( VssUtil.isUnderVss( event.getFile(), myProject ) || prevName != null )
      {
        //  Newer name must refer to the oldest one in the chain of movements
        if( prevName == null )
          prevName = oldName;

        //  Check whether we are trying to rename the file back -
        //  if so, just delete the old key-value pair
        if( !prevName.equals( newName ) )
          host.renamedFiles.put( newName, prevName );

        host.renamedFiles.remove( oldName );
      }
    }
  }

  public void propertyChanged(VirtualFilePropertyEvent event) {}

  public void beforePropertyChange(VirtualFilePropertyEvent event)
  {
    VirtualFile file = event.getFile();
    if( event.getPropertyName() == VirtualFile.PROP_NAME )
    {
      //  When a folder is renamed (e.g. as the result of the "rename package"
      //  refactoring), we do not support renaming in the "Changes" dataflow,
      //  so we emulate that by "deleting" old subdirectory structure and
      //  marking the renamed one as new.
      //  Rename of files is supported as usual.
      if( file.isDirectory() )
      {
        host.removedFolders.add( file.getPath() );
        markSubfolderStructure( file.getPath() );

        //  During folder rename the sequence of the actions is as follows:
        //  - files under this folder are checked out (if they are not yet)
        //  - they are changed
        //  - folder is renamed
        //  So as input to the ChangeProvider we have not very complete
        //  information about what have been done actually. Since we emulate
        //  package rename with "removed/add package" all files under the
        //  renamed folder must be marked as "new" (as a new request).
        VcsDirtyScopeManager mgr = VcsDirtyScopeManager.getInstance( myProject );
        mgr.dirDirtyRecursively( file, true );
      }
      else
      {
        String parentDir = file.getParent().getPath() + "/";
        String oldName = parentDir + event.getOldValue();
        String newName = parentDir + event.getNewValue();

        //  Do not react on files which are not under this vcs
        if( VssUtil.isUnderVss( file, myProject ))
        {
          //  Newer name must refer to the oldest name in the chain of renamings
          String prevName = host.renamedFiles.get( oldName );
          if( prevName == null )
            prevName = oldName;

          //  Check whether we are trying to rename the file back - if so,
          //  just delete the old key-value pair
          if( !prevName.equals( newName ) )
            host.renamedFiles.put( newName, prevName );

          host.renamedFiles.remove( oldName );
        }
      }
    }
  }

  public void fileCreated(VirtualFileEvent event)
  {
    //  In the case when the project content is synchronized over the
    //  occasionally removed files.
    host.removedFiles.remove( event.getFile().getPath() );
    host.removedFolders.remove( event.getFile().getPath() );
  }

  public void beforeFileDeletion(VirtualFileEvent event)
  {
    VirtualFile file = event.getFile();
    FileStatus status = FileStatusManager.getInstance( myProject ).getStatus( file );
    if( VssUtil.isUnderVss( file, myProject ) &&
       ( status != FileStatus.ADDED ) && ( status != FileStatus.UNKNOWN )) 
    {
      if( file.isDirectory() )
      {
        String path = file.getPath();
        markSubfolderStructure( path );
        host.removedFolders.add( path );
      }
      else
        host.removedFiles.add( file.getPath());
    }
  }

  /**
   * When adding new path into the list of the removed folders, remove from
   * that list all files/folders which were removed previously locating under
   * the given one (including it).
   */
  private void  markSubfolderStructure( String path )
  {
    for( Iterator<String> it = host.removedFiles.iterator(); it.hasNext(); )
    {
      String strFile = it.next();
      if( strFile.startsWith( path ) )
       it.remove();
    }
    for( Iterator<String> it = host.removedFolders.iterator(); it.hasNext(); )
    {
      String strFile = it.next();
      if( strFile.startsWith( path ) )
       it.remove();
    }
  }
}
