/*
 * Copyright 2005-2006 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.lang.javascript.psiutil;

import com.intellij.lang.javascript.JSTokenTypes;
import com.intellij.lang.javascript.psi.JSAssignmentExpression;
import com.intellij.lang.javascript.psi.JSCallExpression;
import com.intellij.lang.javascript.psi.JSElement;
import com.intellij.lang.javascript.psi.JSExpression;
import com.intellij.lang.javascript.psi.JSNewExpression;
import com.intellij.lang.javascript.psi.JSPostfixExpression;
import com.intellij.lang.javascript.psi.JSPrefixExpression;
import com.intellij.psi.tree.IElementType;

public class SideEffectChecker {
    private SideEffectChecker() {}

    public static boolean mayHaveSideEffects(JSExpression exp) {
        final SideEffectsVisitor visitor = new SideEffectsVisitor();
        exp.accept(visitor);
        return visitor.mayHaveSideEffects();
    }

    private static class SideEffectsVisitor extends JSRecursiveElementVisitor {
        private boolean mayHaveSideEffects;

        public void visitJSElement(JSElement element) {
            if (!this.mayHaveSideEffects) {
                super.visitJSElement(element);
            }
        }

        public void visitJSCallExpression(JSCallExpression expression) {
            this.mayHaveSideEffects = true;
        }

        public void visitJSNewExpression(JSNewExpression expression) {
            this.mayHaveSideEffects = true;
        }

        public void visitJSAssignmentExpression(JSAssignmentExpression expression) {
            this.mayHaveSideEffects = true;
        }

        public void visitJSPrefixExpression(JSPrefixExpression expression) {
            super.visitJSPrefixExpression(expression);
            final IElementType sign = expression.getOperationSign();

            if (sign != null &&
                (sign.equals(JSTokenTypes.PLUSPLUS)   ||
                 sign.equals(JSTokenTypes.MINUSMINUS))) {
                this.mayHaveSideEffects = true;
            }
        }

        public void visitJSPostfixExpression(JSPostfixExpression expression) {
            super.visitJSPostfixExpression(expression);
            final IElementType sign = expression.getOperationSign();

            if (sign != null &&
                (sign.equals(JSTokenTypes.PLUSPLUS)   ||
                 sign.equals(JSTokenTypes.MINUSMINUS))) {
                this.mayHaveSideEffects = true;
            }
        }

        public boolean mayHaveSideEffects() {
            return this.mayHaveSideEffects;
        }
    }
}
