/*
 * Copyright 2005-2006 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.lang.javascript.psiutil;

import java.util.ArrayList;
import java.util.List;

import com.intellij.lang.javascript.psi.JSElement;
import com.intellij.lang.javascript.psi.JSElementVisitor;
import com.intellij.lang.javascript.psi.JSReferenceExpression;

/**
 * Represents a JS element visitor which recursively visits the children of the element
 * on which the visit was started.
 */
public abstract class JSRecursiveElementVisitor extends JSElementVisitor {
    /** This stack thing is intended to prevent exponential child traversing due to visitReferenceExpression calls both visitRefElement
        and visitExpression. */
    private List<JSReferenceExpression> myRefExprsInVisit = new ArrayList<JSReferenceExpression>();

    public void visitJSElement(JSElement element) {
        if (this.peekStack() == element) {
            this.popStack();
            this.pushStack(null);
        } else {
            element.acceptChildren(this);
        }
    }

    public void visitJSReferenceElement(JSReferenceExpression expression) {
        this.pushStack(expression);

        try {
            this.visitJSExpression          (expression);
            this.visitJSReferenceExpression(expression);
        } finally {
            this.popStack();
        }
    }

    private void pushStack(JSReferenceExpression expression) {
        this.myRefExprsInVisit.add(expression);
    }

    private JSReferenceExpression popStack() {
        final int index = this.myRefExprsInVisit.size() - 1;

        if (index < 0) {
            return null;
        }

        JSReferenceExpression poppedElement = this.myRefExprsInVisit.get(index);

        this.myRefExprsInVisit.remove(index);
        return poppedElement;
    }

    private JSReferenceExpression peekStack() {
        return ((this.myRefExprsInVisit.size() > 0) ? this.myRefExprsInVisit.get(this.myRefExprsInVisit.size() - 1)
                                                    : null);
    }
}

