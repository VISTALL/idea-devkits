/*
 * Copyright 2005-2006 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.lang.javascript.intention;

import org.intellij.idea.lang.javascript.psiutil.JSElementFactory;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.intellij.codeInsight.intention.IntentionAction;
import com.intellij.openapi.editor.CaretModel;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.util.IncorrectOperationException;

public abstract class JSIntention implements IntentionAction {

    @NonNls private static final String INTENTION_SUFFIX = "Intention";
    @NonNls private static final String DISPLAY_NAME     = ".display-name";
    @NonNls private static final String FAMILY_NAME      = ".family-name";
    private         static final String PACKAGE_NAME     = JSIntention.class.getPackage().getName();

    private final JSElementPredicate predicate;

    /** @noinspection AbstractMethodCallInConstructor,OverridableMethodCallInConstructor*/
    protected JSIntention() {
        this.predicate = this.getElementPredicate();
    }

    public void invoke(Project project, Editor editor, PsiFile file)
            throws IncorrectOperationException {
        if (JSElementFactory.isFileReadOnly(project, file)) {
            return;
        }

        final PsiElement element = this.findMatchingElement(file, editor);

        if (element != null) {
            this.processIntention(element);
        }
    }

    protected abstract void processIntention(@NotNull PsiElement element)
            throws IncorrectOperationException;

    @NotNull
    protected abstract JSElementPredicate getElementPredicate();

    @Nullable
    protected PsiElement findMatchingElement(PsiFile file, Editor editor) {
        final CaretModel caretModel = editor.getCaretModel();
        final int        position   = caretModel.getOffset();
        PsiElement       element    = file.findElementAt(position);

        while (element != null) {
            if (this.predicate.satisfiedBy(element)) {
                return element;
            }

            element = element.getParent();
        }
        return null;
    }

    public boolean isAvailable(Project project, Editor editor, PsiFile file) {
        return (this.findMatchingElement(file, editor) != null);
    }

    public boolean startInWriteAction() {
        return true;
    }

    protected String getTextKey(@NonNls Object... suffixes) {
        return JSIntentionBundle.getKey(this.getClass().getName().substring(PACKAGE_NAME.length() + 1),
                                        INTENTION_SUFFIX, null, suffixes);
    }

    @SuppressWarnings({"UnresolvedPropertyKey"})
    @NotNull public String getText() {
        return JSIntentionBundle.message(this.getTextKey(DISPLAY_NAME));
    }

    @SuppressWarnings({"UnresolvedPropertyKey"})
    public String getText(@NonNls Object... arguments) {
        return JSIntentionBundle.message(this.getTextKey(DISPLAY_NAME), arguments);
    }

    @SuppressWarnings({"UnresolvedPropertyKey"})
    protected String getSuffixedDisplayName(@NonNls String suffix, @NonNls Object... arguments) {
        return JSIntentionBundle.message(this.getTextKey(DISPLAY_NAME, '.', suffix), arguments);
    }

    @SuppressWarnings({"UnresolvedPropertyKey"})
    @NotNull public String getFamilyName() {
        return JSIntentionBundle.message(this.getTextKey(FAMILY_NAME));
    }
}
