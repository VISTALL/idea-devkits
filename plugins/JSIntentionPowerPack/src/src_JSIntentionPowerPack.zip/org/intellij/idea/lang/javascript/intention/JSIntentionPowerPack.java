/*
 * Copyright 2005-2006 Olivier Descout
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.intellij.idea.lang.javascript.intention;

import org.intellij.idea.lang.javascript.intention.bool.DeMorgansLawIntention;
import org.intellij.idea.lang.javascript.intention.bool.FlipComparisonIntention;
import org.intellij.idea.lang.javascript.intention.bool.FlipConjunctionIntention;
import org.intellij.idea.lang.javascript.intention.bool.NegateComparisonIntention;
import org.intellij.idea.lang.javascript.intention.bool.RemoveBooleanEqualityIntention;
import org.intellij.idea.lang.javascript.intention.braces.AddBracesIntention;
import org.intellij.idea.lang.javascript.intention.braces.RemoveBracesIntention;
import org.intellij.idea.lang.javascript.intention.comment.ChangeToCStyleCommentIntention;
import org.intellij.idea.lang.javascript.intention.comment.ChangeToEndOfLineCommentIntention;
import org.intellij.idea.lang.javascript.intention.comment.MoveCommentToSeparateLineIntention;
import org.intellij.idea.lang.javascript.intention.conditional.FlipConditionalIntention;
import org.intellij.idea.lang.javascript.intention.conditional.FlipIfIntention;
import org.intellij.idea.lang.javascript.intention.conditional.RemoveConditionalIntention;
import org.intellij.idea.lang.javascript.intention.conditional.ReplaceConditionalWithIfIntention;
import org.intellij.idea.lang.javascript.intention.constant.ConstantExpressionIntention;
import org.intellij.idea.lang.javascript.intention.constant.ConstantSubexpressionIntention;
import org.intellij.idea.lang.javascript.intention.increment.ExtractIncrementIntention;
import org.intellij.idea.lang.javascript.intention.initialization.MergeDeclarationAndInitializationIntention;
import org.intellij.idea.lang.javascript.intention.initialization.SplitDeclarationAndInitializationIntention;
import org.intellij.idea.lang.javascript.intention.loop.MergeParallelForInLoopsIntention;
import org.intellij.idea.lang.javascript.intention.loop.MergeParallelForLoopsIntention;
import org.intellij.idea.lang.javascript.intention.number.ConvertIntegerToDecimalIntention;
import org.intellij.idea.lang.javascript.intention.number.ConvertIntegerToHexIntention;
import org.intellij.idea.lang.javascript.intention.number.ConvertIntegerToOctalIntention;
import org.intellij.idea.lang.javascript.intention.number.ReplaceMultiplyWithShiftIntention;
import org.intellij.idea.lang.javascript.intention.number.ReplaceShiftWithMultiplyIntention;
import org.intellij.idea.lang.javascript.intention.opassign.ReplaceWithOperatorAssignmentIntention;
import org.intellij.idea.lang.javascript.intention.parenthesis.RemoveUnnecessaryParenthesesIntention;
import org.intellij.idea.lang.javascript.intention.string.DoubleToSimpleQuotedStringIntention;
import org.intellij.idea.lang.javascript.intention.string.JoinConcatenatedStringLiteralsIntention;
import org.intellij.idea.lang.javascript.intention.string.SimpleToDoubleQuotedStringIntention;
import org.intellij.idea.lang.javascript.intention.switchtoif.ReplaceIfWithSwitchIntention;
import org.intellij.idea.lang.javascript.intention.switchtoif.ReplaceSwitchWithIfIntention;
import org.intellij.idea.lang.javascript.intention.test.JSIntentionTestManager;
import org.intellij.idea.lang.javascript.intention.trivialif.MergeElseIfIntention;
import org.intellij.idea.lang.javascript.intention.trivialif.MergeIfAndIntention;
import org.intellij.idea.lang.javascript.intention.trivialif.MergeIfOrIntention;
import org.intellij.idea.lang.javascript.intention.trivialif.MergeParallelIfsIntention;
import org.intellij.idea.lang.javascript.intention.trivialif.RemoveRedundantElseIntention;
import org.intellij.idea.lang.javascript.intention.trivialif.ReplaceIfWithConditionalIntention;
import org.intellij.idea.lang.javascript.intention.trivialif.SimplifyIfElseIntention;
import org.intellij.idea.lang.javascript.intention.trivialif.SplitElseIfIntention;
import org.intellij.idea.lang.javascript.intention.trivialif.SplitIfAndIntention;
import org.intellij.idea.lang.javascript.intention.trivialif.SplitIfOrIntention;
import org.jetbrains.annotations.NotNull;

import com.intellij.codeInsight.intention.IntentionManager;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.project.Project;

@SuppressWarnings({"OverlyCoupledClass"})
public class JSIntentionPowerPack implements ProjectComponent {
    /**
     * To be set to true if you want to run plugin unit tests (both intention
     * actions and inspections) when opening an IntelliJ IDEA project.
     * Test output is printed out on the IDEA log.
     */
    public static final boolean RUN_TEST = false;

    protected final Project project;

    public JSIntentionPowerPack(Project project) {
        this.project = project;
    }

    @NotNull public String getComponentName() {
        return JSIntentionBundle.message("plugin.JSIntentionPowerPack.name");
    }

    @SuppressWarnings({"OverlyLongMethod", "OverlyCoupledMethod"})
    public void projectOpened() {
        final Project          project                = this.project;
        final IntentionManager mgr                    = IntentionManager.getInstance(project);
        final String           javascriptCategoryName = JSIntentionBundle.message("plugin.category.javascript");

        final String[] category = new String[] { javascriptCategoryName,
                                                 JSIntentionBundle.message("plugin.category.numbers") };
        mgr.registerIntentionAndMetaData(new ConvertIntegerToDecimalIntention(), category);
        mgr.registerIntentionAndMetaData(new ConvertIntegerToHexIntention(),     category);
        mgr.registerIntentionAndMetaData(new ConvertIntegerToOctalIntention(),   category);

        final String[] booleanCategory = new String[] { javascriptCategoryName,
                                                        JSIntentionBundle.message("plugin.category.boolean") };
        mgr.registerIntentionAndMetaData(new DeMorgansLawIntention(),          booleanCategory);
        mgr.registerIntentionAndMetaData(new RemoveBooleanEqualityIntention(), booleanCategory);
        mgr.registerIntentionAndMetaData(new NegateComparisonIntention(),      booleanCategory);
        mgr.registerIntentionAndMetaData(new FlipComparisonIntention(),        booleanCategory);
        mgr.registerIntentionAndMetaData(new FlipConjunctionIntention(),       booleanCategory);

        final String[] conditionalCategory = new String[] { javascriptCategoryName,
                                                            JSIntentionBundle.message("plugin.category.conditional") };
        mgr.registerIntentionAndMetaData(new FlipConditionalIntention(),          conditionalCategory);
        mgr.registerIntentionAndMetaData(new FlipIfIntention(),                   conditionalCategory);
        mgr.registerIntentionAndMetaData(new ReplaceConditionalWithIfIntention(), conditionalCategory);
        mgr.registerIntentionAndMetaData(new ReplaceIfWithConditionalIntention(), conditionalCategory);
        mgr.registerIntentionAndMetaData(new RemoveConditionalIntention(),        conditionalCategory);

        final String[] shiftCategory = new String[] { javascriptCategoryName,
                                                      JSIntentionBundle.message("plugin.category.shift") };
        mgr.registerIntentionAndMetaData(new ReplaceMultiplyWithShiftIntention(), shiftCategory);
        mgr.registerIntentionAndMetaData(new ReplaceShiftWithMultiplyIntention(), shiftCategory);

        final String[] declarationCategory = new String[] { javascriptCategoryName,
                                                            JSIntentionBundle.message("plugin.category.declaration") };
        mgr.registerIntentionAndMetaData(new MergeDeclarationAndInitializationIntention(), declarationCategory);
        mgr.registerIntentionAndMetaData(new SplitDeclarationAndInitializationIntention(), declarationCategory);

        final String[] commentsCategory = new String[] { javascriptCategoryName,
                                                         JSIntentionBundle.message("plugin.category.comments") };
        mgr.registerIntentionAndMetaData(new ChangeToCStyleCommentIntention(),     commentsCategory);
        mgr.registerIntentionAndMetaData(new ChangeToEndOfLineCommentIntention(),  commentsCategory);
        mgr.registerIntentionAndMetaData(new MoveCommentToSeparateLineIntention(), commentsCategory);

        final String[] controlFlowCategory = new String[] { javascriptCategoryName,
                                                            JSIntentionBundle.message("plugin.category.control-flow") };
        mgr.registerIntentionAndMetaData(new SplitElseIfIntention(),             controlFlowCategory);
        mgr.registerIntentionAndMetaData(new MergeElseIfIntention(),             controlFlowCategory);
        mgr.registerIntentionAndMetaData(new MergeIfAndIntention(),              controlFlowCategory);
        mgr.registerIntentionAndMetaData(new MergeIfOrIntention(),               controlFlowCategory);
        mgr.registerIntentionAndMetaData(new MergeParallelIfsIntention(),        controlFlowCategory);
        mgr.registerIntentionAndMetaData(new SplitIfAndIntention(),              controlFlowCategory);
        mgr.registerIntentionAndMetaData(new SplitIfOrIntention(),               controlFlowCategory);
        mgr.registerIntentionAndMetaData(new ReplaceSwitchWithIfIntention(),     controlFlowCategory);
        mgr.registerIntentionAndMetaData(new ReplaceIfWithSwitchIntention(),     controlFlowCategory);
        mgr.registerIntentionAndMetaData(new SimplifyIfElseIntention(),          controlFlowCategory);
        mgr.registerIntentionAndMetaData(new RemoveRedundantElseIntention(),     controlFlowCategory);
        mgr.registerIntentionAndMetaData(new MergeParallelForLoopsIntention(),   controlFlowCategory);
        mgr.registerIntentionAndMetaData(new MergeParallelForInLoopsIntention(), controlFlowCategory);
        mgr.registerIntentionAndMetaData(new AddBracesIntention(),               controlFlowCategory);
        mgr.registerIntentionAndMetaData(new RemoveBracesIntention(),            controlFlowCategory);

        final String[] otherCategory = new String[] { javascriptCategoryName,
                                                      JSIntentionBundle.message("plugin.category.other") };
        mgr.registerIntentionAndMetaData(new RemoveUnnecessaryParenthesesIntention(),   otherCategory);
        mgr.registerIntentionAndMetaData(new JoinConcatenatedStringLiteralsIntention(), otherCategory);
        mgr.registerIntentionAndMetaData(new ReplaceWithOperatorAssignmentIntention(),  otherCategory);
        mgr.registerIntentionAndMetaData(new SimpleToDoubleQuotedStringIntention(),     otherCategory);
        mgr.registerIntentionAndMetaData(new DoubleToSimpleQuotedStringIntention(),     otherCategory);
        mgr.registerIntentionAndMetaData(new ConstantExpressionIntention(),             otherCategory);
        mgr.registerIntentionAndMetaData(new ConstantSubexpressionIntention(),          otherCategory);
        mgr.registerIntentionAndMetaData(new ExtractIncrementIntention(),               otherCategory);

        //noinspection ConstantConditions
        if (RUN_TEST) {
            JSIntentionTestManager.runTest(project);
        }
    }

    public void projectClosed() {}

    public void initComponent() {}

    public void disposeComponent() {}
}
