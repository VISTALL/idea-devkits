/*
 * Copyright 2000-2006 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jetbrains.communicator.util;

import java.util.HashSet;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author Kir
 */
public class MergingQueue {
  private Timer myTimer;
  private final Set<Task> myTasks = new HashSet<Task>();

  public MergingQueue() {
    myTimer = new Timer(true);
  }

  public void cancel() {
    myTimer.cancel();
  }

  public void queue(int delay, String mergeName, final Runnable action) {
    Task newTask = new Task(mergeName, action);

    synchronized(myTasks) {
      Task[] tasks = myTasks.toArray(new Task[myTasks.size()]);
      for (Task task : tasks) {
        if (task.equals(newTask)) {
          myTasks.remove(task);
          task.cancel();
        }
      }
      myTasks.add(newTask);
    }

     myTimer.schedule(newTask, delay);
  }

  private class Task extends TimerTask {
    private final Runnable myAction;
    private final String myName;

    Task(String name, Runnable action) {
      myAction = action;
      myName = name;
    }

    public void run() {
      synchronized(myTasks) {
        myTasks.remove(this);
      }
      myAction.run();
    }

    public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;

      final Task task = (Task) o;

      return !(myName != null ? !myName.equals(task.myName) : task.myName != null);
    }

    public int hashCode() {
      return (myName != null ? myName.hashCode() : 0);
    }
  }
}
