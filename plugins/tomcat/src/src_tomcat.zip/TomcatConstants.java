/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.tomcat;

import com.intellij.javaee.DeploymentDescriptorMetaData;
import com.intellij.openapi.module.ModuleType;
import org.jdom.Comment;
import org.jetbrains.annotations.NonNls;

public interface TomcatConstants {
  @NonNls String CATALINA_CONFIG_DIRECTORY_NAME = "conf";
  @NonNls String CATALINA_WORK_DIRECTORY_NAME = "work";
  @NonNls String SCRATCHDIR_NAME = "_scratchdir";
  @NonNls String SERVER_XML = "server.xml";
  @NonNls String WEB_XML = "web.xml";
  @NonNls String CATALINA_BIN_DIRECTORY_NAME = "bin";
  @NonNls String CATALINA_COMMON_DIRECTORY_NAME = "common";
  @NonNls String CATALINA_LIB_DIRECTORY_NAME = "lib";
  Comment CONTEXT_COMMENT = new Comment(
    TomcatBundle.message("comment.text.context.generated.by.idea")
  );
  @NonNls String CONTEXT_XML_TEMPLATE_FILE_NAME = "context.xml";

  DeploymentDescriptorMetaData TOMCAT_CONTEXT_DESCRIPTOR = new DeploymentDescriptorMetaData() {
    private final ModuleType[] MODULE_TYPES = new ModuleType[]{ModuleType.WEB};
    @NonNls private final String TOMCAT_VERSION_5x = "5.x";
    private final String[] TOMCAT5_VERSIONS = new String[] {TOMCAT_VERSION_5x};

    public String[] getAvailableVersions() {
      return TOMCAT5_VERSIONS;
    }

    public String getTemplateNameAccordingToVersion(String version) {
      return CONTEXT_XML_TEMPLATE_FILE_NAME;
    }

    public String getDefaultVersion() {
      return TOMCAT_VERSION_5x;
    }

    public String getDefaultFileName() {
      return CONTEXT_XML_TEMPLATE_FILE_NAME;
    }

    public String getDefaultDirectoryName() {
      return "META-INF";
    }

    public String getTitle() {
      return TomcatBundle.message("tomcat.deployment.descriptor.title");
    }

    public ModuleType[] getSuitableTypes() {
      return MODULE_TYPES;
    }

    public boolean isDescriptorOptional() {
      return true;
    }

  };
}