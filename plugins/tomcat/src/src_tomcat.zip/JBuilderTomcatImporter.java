/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.tomcat;

import com.intellij.javaee.appServerIntegrations.ApplicationServerInfo;
import com.intellij.javaee.appServerIntegrations.*;
import com.intellij.javaee.appServerIntegrations.CantFindApplicationServerJarsException;
import com.intellij.openapi.util.Pair;
import com.intellij.util.projectImport.JBuilderProjectImportHelper;
import com.intellij.util.projectImport.JBuilderProjectImportWebHelper;
import org.jetbrains.annotations.Nullable;

/**
 * User: anna
 * Date: May 23, 2005
 */
public class JBuilderTomcatImporter extends JBuilderProjectImportHelper implements JBuilderProjectImportWebHelper {
  public String getComponentName() {
    return "JBuilderTomcatImporter";
  }

  @Nullable public Pair<? extends ApplicationServerHelper, String> getAppServerHelperWithIntegrationName(final String home, final String version) {
    try {
      final TomcatPersistentData tomcatPersistentData = new TomcatPersistentData();
      tomcatPersistentData.CATALINA_HOME = home;
      tomcatPersistentData.VERSION = version;
      new TomcatApplicationServerHelper().getApplicationServerInfo(tomcatPersistentData);
    }
    catch (CantFindApplicationServerJarsException e) {
      return null;
    }
    return Pair.create(new TomcatApplicationServerHelper(){
      public ApplicationServerInfo getApplicationServerInfo(ApplicationServerPersistentData persistentData)
        throws CantFindApplicationServerJarsException {
        final TomcatPersistentData tomcatPersistentData = ((TomcatPersistentData)persistentData);
        tomcatPersistentData.CATALINA_HOME = home;
        tomcatPersistentData.VERSION = version;
        return super.getApplicationServerInfo(persistentData);
      }
    }, TomcatBundle.message("tomcat.application.server.name"));

  }

  public void initComponent() {

  }

  public void disposeComponent() {

  }

}
