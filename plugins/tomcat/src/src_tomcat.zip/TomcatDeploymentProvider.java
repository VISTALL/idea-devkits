/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.tomcat;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.deployment.*;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.util.text.StringUtil;
import org.jdom.Document;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class TomcatDeploymentProvider implements DeploymentProvider {
  private static final Logger LOG = Logger.getInstance("#com.intellij.j2ee.web.tomcat.TomcatDeploymentProvider");
  @NonNls private static final String CONTEXT_ELEMENT_NAME = "Context";
  @NonNls private static final String PATH_ATTR = "path";
  @NonNls private static final String DOC_BASE_ATTR = "docBase";
  @NonNls private static final String WORKDIR_ATTR = "workDir";
  @NonNls private static final String APP_BASE_ATTR = "appBase";
  @NonNls private static final String AUTO_DEPLOY_ATTR = "autoDeploy";
  @NonNls private static final String UNPACK_WARS_ATTR = "unpackWARs";
  @NonNls private static final String MANAGER_XML_FILE_NAME = "manager.xml";
  @NonNls private static final String TOMCAT_USERS_XML = "tomcat-users.xml";
  @NonNls private static final String MANAGER_CONTEXT_PATH = "/manager";

  public void doDeploy(Project project, J2EEServerInstance instance, DeploymentModel model) {
    Module module = model.getModuleProperties().getModule();
    final TomcatModuleDeploymentModel tomcatModel = (TomcatModuleDeploymentModel)model;
    try {
      final TomcatModel serverModel = (TomcatModel)model.getServerModel();
      final List<TomcatUtil.ContextItem> contexts = TomcatUtil.getContexts(serverModel);
      for (TomcatUtil.ContextItem contextItem : contexts) {
        String docBase = contextItem.getElement().getAttributeValue(DOC_BASE_ATTR);
        if (docBase != null && docBase.equals(TomcatUtil.getDeploymentPath(model))) {
          TomcatUtil.removeContextItem(serverModel, contextItem);
        }
      }
      addApplicationContext(tomcatModel);
      setDeploymentStatus(instance, tomcatModel, DeploymentStatus.DEPLOYED);

      if (!serverModel.versionHigher(TomcatPersistentData.VERSION50) && instance.isConnected()) {
        new Tomcat4Deployer(serverModel).deploy(getContextPath(tomcatModel));
      }
    }
    catch (ExecutionException e) {
      Messages.showErrorDialog(project, e.getMessage(), TomcatBundle.message("message.text.error.deploying.module", module.getName()));
      setDeploymentStatus(instance, tomcatModel, DeploymentStatus.FAILED);
    }
  }

  private static void setDeploymentStatus(J2EEServerInstance instance, TomcatModuleDeploymentModel model, DeploymentStatus status) {
    final CommonModel configuration = instance.getCommonModel();
    final TomcatModel tomcatConfiguration = ((TomcatModel)configuration.getServerModel());
    final JavaeeModuleProperties item = model.getModuleProperties();
    DeploymentManager.getInstance(tomcatConfiguration.getProject()).setDeploymentStatus(item, status, configuration, instance);
  }

  public DeploymentModel createNewDeploymentModel(CommonModel configuration, JavaeeModuleProperties j2eeModuleProperties) {
    return new TomcatModuleDeploymentModel(configuration, j2eeModuleProperties);
  }

  public SettingsEditor<DeploymentModel> createAdditionalDeploymentSettingsEditor(CommonModel configuration, JavaeeModuleProperties moduleProperties) {
    return new TomcatDeploymentSettingsEditor(configuration, moduleProperties);
  }

  public void startUndeploy(J2EEServerInstance activeInstance, DeploymentModel model) {
    final CommonModel configuration = activeInstance.getCommonModel();
    final TomcatModel serverModel = ((TomcatModel)configuration.getServerModel());
    final TomcatModuleDeploymentModel tomcatModel = (TomcatModuleDeploymentModel)model;
    if (!serverModel.isLocal()) {
      final Module module = model.getModuleProperties().getModule();
      Messages.showErrorDialog(
        module.getProject(),
        TomcatBundle.message("message.text.deployment.not.supported.for.remote"),
        TomcatBundle.message("message.text.error.deploying.module", module.getName())
      );
      setDeploymentStatus(activeInstance, tomcatModel, DeploymentStatus.FAILED);
    }
    else {
      final String contextPath = getContextPath(tomcatModel);
      if (serverModel.versionHigher(TomcatPersistentData.VERSION50)) {
        final String contextXML = TomcatUtil.getContextXML(serverModel.getBaseDirectoryPath(), contextPath);
        final File contextXmlFile = new File(contextXML);
        if(contextXmlFile.exists()) {
          contextXmlFile.delete();
        }
      }
      else {
        try {
          addOrRemoveContextElementInServerXml(serverModel, contextPath, null);
          new Tomcat4Deployer(serverModel).undeploy(contextPath);
        }
        catch (ExecutionException e) {
        }
      }
      setDeploymentStatus(activeInstance, tomcatModel, DeploymentStatus.NOT_DEPLOYED);
    }
  }

  public void updateDeploymentStatus(J2EEServerInstance instance, DeploymentModel model) {
    try {
      CommonModel configuration = instance.getCommonModel();
      TomcatModel serverModel = ((TomcatModel)configuration.getServerModel());
      final TomcatModuleDeploymentModel tomcatDeploymentModel = (TomcatModuleDeploymentModel)model;
      String contextPath = getContextPath(tomcatDeploymentModel);

      final Element contextElement = TomcatUtil.findContextElement(serverModel.getBaseDirectoryPath(), contextPath, tomcatDeploymentModel);

      JavaeeModuleProperties item = model.getModuleProperties();

      if (serverModel.isLocal()) {
        DeploymentManager.getInstance(serverModel.getProject()).setDeploymentStatus(
          item,
          contextElement != null ? DeploymentStatus.DEPLOYED : DeploymentStatus.NOT_DEPLOYED,
          configuration, instance
        );
      }
      else {
        DeploymentManager.getInstance(serverModel.getProject()).setDeploymentStatus(item, DeploymentStatus.UNKNOWN, configuration, instance);
      }
    }
    catch (ExecutionException e) {
      LOG.error(e);
    }
  }

  public String getHelpId() {
    return null;
  }

  private static void addApplicationContext(TomcatModuleDeploymentModel tomcatModuleDeploymentModel) throws ExecutionException {
    try {
      TomcatModel serverModel = (TomcatModel)tomcatModuleDeploymentModel.getServerModel();
      String contextPath = getContextPath(tomcatModuleDeploymentModel);

      Element contextElement = TomcatUtil.findContextElement(serverModel.getSourceBaseDirectoryPath(), contextPath, tomcatModuleDeploymentModel);

      if (contextElement == null) {
        contextElement = new Element(CONTEXT_ELEMENT_NAME);
        //contextElement.addContent((Comment)TomcatConstants.CONTEXT_COMMENT.clone());
      }

      final String explodedPath = TomcatUtil.getDeploymentPath(tomcatModuleDeploymentModel);
      if (explodedPath == null) {
        throw new ExecutionException(TomcatBundle.message("exception.text.neither.exploded.directory.nor.jar.file.configured"));
      }

      if (!new File(explodedPath).exists()) {
        throw new ExecutionException(TomcatBundle.message("exception.text.file.not.found.for.web.module", explodedPath));
      }

      //remove unpacked WAR directory
      if(DeploymentSource.FROM_JAR == tomcatModuleDeploymentModel.getDeploymentSource()) {
        final String contextXML = TomcatUtil.getContextXML(serverModel.getSourceBaseDirectoryPath(), contextPath);
        final String xmlName = new File(contextXML).getName();
        final String dirName = xmlName.substring(0, xmlName.length() - 4);

        final Document serverXmlDocument = TomcatUtil.loadXMLFile(TomcatUtil.serverXML(serverModel.getBaseDirectoryPath()));
        final Element localHost = TomcatUtil.findLocalHost(serverXmlDocument.getRootElement());

        final String appBase = localHost.getAttributeValue(APP_BASE_ATTR);
        FileUtil.delete(new File(appBase, dirName));
      }

      contextElement.setAttribute(PATH_ATTR, contextPath);
      contextElement.setAttribute(DOC_BASE_ATTR, explodedPath);

      if(serverModel.versionHigher(TomcatPersistentData.VERSION50)) {
        final String contextXML = TomcatUtil.getContextXML(serverModel.getBaseDirectoryPath(), contextPath);
        final File targetContextXmlFile = new File(contextXML);
        targetContextXmlFile.getParentFile().mkdirs();

        final Document xmlDocument;
        if(contextElement.getDocument() != null && contextElement.isRootElement()) {
          xmlDocument = (Document)contextElement.getDocument().clone();
        }
        else{
          xmlDocument = new Document();
          xmlDocument.setRootElement((Element)contextElement.clone());
        }
        TomcatUtil.saveXMLFile(xmlDocument, targetContextXmlFile.getPath(), true);
      }
      else {
        String scratchdir = TomcatUtil.getGeneratedFilesPath(serverModel).replace('/', File.separatorChar) + File.separator + TomcatConstants.CATALINA_WORK_DIRECTORY_NAME + File.separator + new File(TomcatUtil.getContextXML(serverModel.getBaseDirectoryPath(), contextPath)).getName();
        new File(scratchdir).mkdirs();

        contextElement.setAttribute(WORKDIR_ATTR, scratchdir);

        addOrRemoveContextElementInServerXml(serverModel, contextPath, contextElement);
      }
    }
    catch (RuntimeConfigurationException e) {
      throw new ExecutionException(e.getMessage());
    }
  }

  private static void addOrRemoveContextElementInServerXml(final TomcatModel serverModel, final String contextPath,
                                                           final @Nullable Element newContext) throws ExecutionException {
    Document serverXmlDocument = TomcatUtil.loadXMLFile(TomcatUtil.serverXML(serverModel.getBaseDirectoryPath()));

    Element localHost = TomcatUtil.findLocalHost(serverXmlDocument.getRootElement());
    Element oldContext = TomcatUtil.findContextByPath(localHost, contextPath);
    if(oldContext != null) {
      localHost.removeContent(oldContext);
    }
    if (newContext != null) {
      localHost.addContent((Element)newContext.clone());
    }
    TomcatUtil.saveXMLFile(serverXmlDocument, TomcatUtil.serverXML(serverModel.getBaseDirectoryPath()), true);
  }

  public DeploymentMethod[] getAvailableMethods() {
    return null;
  }

  public static String getContextPath(TomcatModuleDeploymentModel deploymentSettings) {
    String contextPath = deploymentSettings.CONTEXT_PATH;
    if(!StringUtil.startsWithChar(contextPath, '/')) {
      contextPath =  "/" + contextPath;
    }

    if(contextPath.equals("/")) {
      contextPath = "";
    }

    return contextPath;
  }

  public static void prepareServer(TomcatModel tomcatModel) throws ExecutionException {
    try {
      if(!tomcatModel.isLocal()) return;

      FileUtil.delete(new File(tomcatModel.getBaseDirectoryPath()));

      File sourceBase = new File(TomcatUtil.baseConfigDir(tomcatModel.getSourceBaseDirectoryPath()));
      File workBase = new File(TomcatUtil.baseConfigDir(tomcatModel.getBaseDirectoryPath()));

      try {
        FileUtil.copyDir(sourceBase, workBase);
      }
      catch (IOException e) {
        throw new ExecutionException(TomcatBundle.message("message.text.error.copying.configuration.files.from.0.to.1.because.of.2",
                                                          sourceBase.getPath(), workBase.getPath(), e.getMessage()));
      }

      List<TomcatUtil.ContextItem> contexts = TomcatUtil.getContexts(tomcatModel);

      for (TomcatUtil.ContextItem contextItem : contexts) {
        if (tomcatModel.DEPLOY_TOMCAT_MANAGER && MANAGER_XML_FILE_NAME.equals(contextItem.getFile().getName())) {
          continue;
        }
        if (!tomcatModel.versionHigher(TomcatPersistentData.VERSION50)) {
          final Element element = contextItem.getElement();
          if (element != null && MANAGER_CONTEXT_PATH.equals(element.getAttributeValue(PATH_ATTR))) {
            continue;
          }
        }

        TomcatUtil.removeContextItem(tomcatModel, contextItem);
      }

      String xmlPath = TomcatUtil.serverXML(tomcatModel.getBaseDirectoryPath());

      Document serverXmlDocument = TomcatUtil.loadXMLFile(xmlPath);
      Document original = (Document)serverXmlDocument.clone();
      Element localHost = TomcatUtil.findLocalHost(serverXmlDocument.getRootElement());

      String appBase = localHost.getAttributeValue(APP_BASE_ATTR);

      if(appBase == null) appBase = "";

      if(!new File(appBase).isAbsolute()) {
        appBase = new File(tomcatModel.getSourceBaseDirectoryPath(), appBase).getAbsolutePath();
      }
      localHost.setAttribute(APP_BASE_ATTR, appBase);
      localHost.setAttribute(AUTO_DEPLOY_ATTR, Boolean.TRUE.toString());
      localHost.setAttribute(UNPACK_WARS_ATTR, Boolean.TRUE.toString());
      TomcatUtil.saveXMLFile(localHost.getDocument(), xmlPath, true);

      File tomcatUsers = new File(workBase, TOMCAT_USERS_XML);
      if (tomcatUsers.exists() && !tomcatModel.versionHigher(TomcatPersistentData.VERSION50)) {
        Tomcat4Deployer.addManagerUser(tomcatUsers);
      }

      TomcatUtil.configureWebXml(tomcatModel);
    }
    catch (RuntimeConfigurationException e) {
      LOG.assertTrue(false);
    }
  }
}
