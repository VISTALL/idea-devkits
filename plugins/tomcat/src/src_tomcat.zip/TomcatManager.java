/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.tomcat;

import com.intellij.ide.fileTemplates.FileTemplateDescriptor;
import com.intellij.ide.fileTemplates.FileTemplateGroupDescriptor;
import com.intellij.javaee.DeploymentDescriptorMetaData;
import com.intellij.javaee.appServerIntegrations.AppServerIntegration;
import com.intellij.javaee.appServerIntegrations.ApplicationServerHelper;
import com.intellij.javaee.appServerIntegrations.AppServerDeployedFileUrlProvider;
import com.intellij.javaee.deployment.DeploymentProvider;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.fileTypes.StdFileTypes;
import com.intellij.openapi.module.ModuleType;
import com.intellij.openapi.util.IconLoader;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.NonNls;

import javax.swing.*;


public class TomcatManager extends AppServerIntegration {
  public static final Icon ICON_TOMCAT = IconLoader.getIcon("/runConfigurations/tomcat.png");
  private final TomcatDeploymentProvider myTomcatDeploymentProvider = new TomcatDeploymentProvider();
  private ApplicationServerHelper myApplicationServerHelper = new TomcatApplicationServerHelper();

  public static Icon getIcon() {
    return ICON_TOMCAT;
  }

  public String getPresentableName() {
    return TomcatBundle.message("tomcat.application.server.name");
  }

  @NotNull @NonNls
  public String getComponentName() {
    return "#com.intellij.j2ee.web.tomcat.TomcatManager";
  }

  public void initComponent() {
  }

  public void disposeComponent() {
  }

  public DeploymentProvider getDeploymentProvider() {
    return myTomcatDeploymentProvider;
  }

  public static TomcatManager getInstance() {
    return ApplicationManager.getApplication().getComponent(TomcatManager.class);
  }

  public ApplicationServerHelper getApplicationServerHelper() {
    return myApplicationServerHelper;
  }

  @NotNull
  public ModuleType[] getSupportedModuleTypes() {
    return new ModuleType[]{ModuleType.WEB};
  }

  public @NotNull AppServerDeployedFileUrlProvider getDeployedFileUrlProvider() {
    return TomcatDeployedFileUrlProvider.INSTANCE;
  }

  @NotNull
  public DeploymentDescriptorMetaData[] getDeploymentDescriptorDescriptions() {
    return new DeploymentDescriptorMetaData[] {TomcatConstants.TOMCAT_CONTEXT_DESCRIPTOR};
  }

  public FileTemplateGroupDescriptor getFileTemplatesDescriptor() {
    final FileTemplateGroupDescriptor root = new FileTemplateGroupDescriptor(TomcatBundle.message("templates.group.title"), getIcon());
    root.addTemplate(new FileTemplateDescriptor(TomcatConstants.CONTEXT_XML_TEMPLATE_FILE_NAME, StdFileTypes.XML.getIcon()));
    return root;
  }
}
