/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.tomcat;

import com.intellij.javaee.appServerIntegrations.ApplicationServerPersistentDataEditor;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.ui.TextFieldWithBrowseButton;
import com.intellij.ui.DocumentAdapter;
import org.jetbrains.annotations.NonNls;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import java.io.File;

public class TomcatDataEditor extends ApplicationServerPersistentDataEditor<TomcatPersistentData> {
  private JPanel myPanel;
  private TextFieldWithBrowseButton myHomeDir;
  private TextFieldWithBrowseButton myBaseDir;
  private JLabel myVersionLabel;
  private boolean myShouldSyncBase = true;
  private boolean myIsInSync = false;

  public TomcatDataEditor() {
    initChooser(myHomeDir, TomcatBundle.message("chooser.title.tomcat.home.directory"), TomcatBundle.message("chooser.description.tomcat.home.directory"));
    initChooser(myBaseDir, TomcatBundle.message("chooser.title.tomcat.base.directory"), TomcatBundle.message("chooser.description.tomcat.base.directory"));

    myHomeDir.getTextField().getDocument().addDocumentListener(new DocumentAdapter() {
      public void textChanged(DocumentEvent event) {
        update();
      }
    });

    myBaseDir.getTextField().getDocument().addDocumentListener(new DocumentAdapter() {
      public void textChanged(DocumentEvent event) {
        if (!myIsInSync) myShouldSyncBase = false;
      }
    });
  }

  private void initChooser(TextFieldWithBrowseButton field, String title, String description) {
    field.setText(TomcatUtil.getDefaultLocation());
    field.getTextField().setEditable(true);
    field.addBrowseFolderListener(title,
                                  description,
                                  null,
                                  new FileChooserDescriptor(false, true, false, false, false, false));
  }

  private void update() {
    myVersionLabel.setText(getVersion());

    if (myShouldSyncBase) {
      myIsInSync = true;
      try {
        myBaseDir.setText(myHomeDir.getText());
      }
      finally {
        myIsInSync = false;
      }
    }
  }

  private String getVersion() {
    String homeDir = myHomeDir.getText();
    @NonNls final String pathToServletJar = homeDir + File.separator + "common" + File.separator + "lib" + File.separator + "servlet.jar";
    File jar40 = new File(pathToServletJar);
    if (jar40.exists()) {
      return TomcatPersistentData.VERSION40;
    }
    @NonNls final String pathToServletApiJar = homeDir + File.separator + "lib" + File.separator + "servlet-api.jar";
    File jar60 = new File(pathToServletApiJar);
    if (jar60.exists()) {
      return TomcatPersistentData.VERSION60;
    }
    return TomcatPersistentData.VERSION50;
  }

  public void resetEditorFrom(TomcatPersistentData data) {
    myHomeDir.setText(data.CATALINA_HOME.replace('/', File.separatorChar));
    myShouldSyncBase = data.CATALINA_BASE.length() == 0;
    myBaseDir.setText(myShouldSyncBase ? data.CATALINA_HOME.replace('/', File.separatorChar) : data.CATALINA_BASE.replace('/', File.separatorChar));
    update();
  }

  public void applyEditorTo(TomcatPersistentData data) throws ConfigurationException {
    final String version = myVersionLabel.getText();
    File home = new File(myHomeDir.getText()).getAbsoluteFile();
    checkIsDirectory(home);
    checkIsDirectory(new File(home, TomcatConstants.CATALINA_CONFIG_DIRECTORY_NAME));
    checkIsDirectory(new File(home, TomcatConstants.CATALINA_BIN_DIRECTORY_NAME));
    if (TomcatPersistentData.VERSION60.equals(version)) {
      checkIsDirectory(new File(home, TomcatConstants.CATALINA_LIB_DIRECTORY_NAME));
    }
    else {
      File common = new File(home, TomcatConstants.CATALINA_COMMON_DIRECTORY_NAME);
      checkIsDirectory(common);
      checkIsDirectory(new File(common, TomcatConstants.CATALINA_LIB_DIRECTORY_NAME));
    }

    File base = new File(myBaseDir.getText()).getAbsoluteFile();
    checkIsDirectory(base);
    checkIsDirectory(new File(base, TomcatConstants.CATALINA_CONFIG_DIRECTORY_NAME));

    data.CATALINA_HOME = home.getAbsolutePath().replace(File.separatorChar, '/');
    data.CATALINA_BASE = base.getAbsolutePath().replace(File.separatorChar, '/');
    if (data.CATALINA_BASE.equals(data.CATALINA_HOME)) {
      data.CATALINA_BASE = "";
      myShouldSyncBase = true;
    }
    else {
      myShouldSyncBase = false;
    }

    data.VERSION = version;
  }

  private void checkIsDirectory(File file) throws ConfigurationException {
    if (!file.isDirectory()) {
      throw new ConfigurationException(TomcatBundle.message("message.text.cant.find.directory", file.getAbsolutePath()));
    }
  }

  public JComponent createEditor() {
    return myPanel;
  }

  public void disposeEditor() {
  }

  protected JComponent createCenterPanel() {
    return myPanel;
  }
}