/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.util;

import java.io.IOException;
import java.io.InputStream;

public abstract class FileWrapper {

    private final String name;

    private final String path;

    protected FileWrapper(String name, String path) {
        this.name = name;
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public String getPath() {
        return path;
    }

    public abstract InputStream getStream() throws IOException;
}
