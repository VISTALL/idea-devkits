/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.util;

import java.util.HashMap;
import java.util.Map;
import javax.swing.*;
import org.jetbrains.annotations.NonNls;

public class IconLoader {

    private static final Map<String, Icon> icons = new HashMap<String, Icon>();

    private static final Map<String, Icon> transparents = new HashMap<String, Icon>();

    private IconLoader() {
    }

    public static Icon get(@NonNls String path) {
        Icon icon = icons.get(path);
        if (icon == null) {
            icon = com.intellij.openapi.util.IconLoader.getIcon(path);
            icons.put(path, icon);
        }
        return icon;
    }

    public static Icon getTransparent(@NonNls String path) {
        Icon icon = transparents.get(path);
        if (icon == null) {
            icon = com.intellij.openapi.util.IconLoader.getTransparentIcon(get(path));
            transparents.put(path, icon);
        }
        return icon;
    }
}
