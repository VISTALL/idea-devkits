/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.util;

import javax.swing.*;
import com.intellij.ide.TreeExpander;
import com.intellij.util.ui.tree.TreeUtil;

public class TreeExpanderImpl implements TreeExpander {

    private final JTree tree;

    public TreeExpanderImpl(JTree tree) {
        this.tree = tree;
    }

    public void expandAll() {
        TreeUtil.expandAll(tree);
    }

    public boolean canExpand() {
        return tree.getRowCount() > 0;
    }

    public void collapseAll() {
        TreeUtil.collapseAll(tree, 0);
    }

    public boolean canCollapse() {
        return tree.getRowCount() > 0;
    }
}
