/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.util;

import javax.swing.*;
import com.intellij.util.xml.ui.GenericValueColumnInfo;

public class GenericColumnInfo<T> extends GenericValueColumnInfo<T> {

    public GenericColumnInfo(String name, Class<T> type, Icon icon) {
        super(name, type, new IconTableCellRenderer(icon), new DefaultCellEditor(new JTextField()));
    }
}
