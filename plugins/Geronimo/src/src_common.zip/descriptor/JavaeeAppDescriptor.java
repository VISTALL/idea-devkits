/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.descriptor;

import com.fuhrer.idea.javaee.JavaeeBundle;
import com.fuhrer.idea.javaee.server.JavaeeIntegration;
import com.fuhrer.idea.javaee.util.IconLoader;
import com.intellij.javaee.appServerIntegrations.JavaeeApplicationDescriptorsMetaDataRegistry;
import com.intellij.util.descriptors.ConfigFileMetaData;

class JavaeeAppDescriptor extends JavaeeDescriptorType {

    JavaeeAppDescriptor() {
        super(IconLoader.get("/resources/app.png"));
    }

    @Override
    String getTitle(JavaeeIntegration integration) {
        return JavaeeBundle.get("AppDescriptor.title", integration.getName());
    }

    @Override
    void registerMetaData(JavaeeIntegration integration, ConfigFileMetaData meta) {
        JavaeeApplicationDescriptorsMetaDataRegistry.getInstance().registerMetaData(integration, meta);
    }
}
