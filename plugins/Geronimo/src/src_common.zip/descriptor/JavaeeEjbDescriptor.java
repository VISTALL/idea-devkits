/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.descriptor;

import com.fuhrer.idea.javaee.JavaeeBundle;
import com.fuhrer.idea.javaee.server.JavaeeIntegration;
import com.fuhrer.idea.javaee.util.IconLoader;
import com.intellij.javaee.appServerIntegrations.EjbDescriptorsMetaDataRegistry;
import com.intellij.util.descriptors.ConfigFileMetaData;

class JavaeeEjbDescriptor extends JavaeeDescriptorType {

    JavaeeEjbDescriptor() {
        super(IconLoader.get("/resources/ejb.png"));
    }

    @Override
    String getTitle(JavaeeIntegration integration) {
        return JavaeeBundle.get("EjbDescriptor.title", integration.getName());
    }

    @Override
    void registerMetaData(JavaeeIntegration integration, ConfigFileMetaData meta) {
        EjbDescriptorsMetaDataRegistry.getInstance().registerMetaData(integration, meta);
    }
}
