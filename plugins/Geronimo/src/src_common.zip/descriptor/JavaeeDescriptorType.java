/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.descriptor;

import java.util.*;
import javax.swing.*;
import com.fuhrer.idea.javaee.server.JavaeeIntegration;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.psi.xml.XmlFile;
import com.intellij.util.descriptors.ConfigFile;
import com.intellij.util.descriptors.ConfigFileMetaData;
import com.intellij.util.descriptors.ConfigFileVersion;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.DomFileElement;
import com.intellij.util.xml.DomManager;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class JavaeeDescriptorType {

    @SuppressWarnings({"ClassReferencesSubclass"})
    public static final JavaeeDescriptorType APP = new JavaeeAppDescriptor();

    @SuppressWarnings({"ClassReferencesSubclass"})
    public static final JavaeeDescriptorType EJB = new JavaeeEjbDescriptor();

    @SuppressWarnings({"ClassReferencesSubclass"})
    public static final JavaeeDescriptorType CMP = new JavaeeCmpDescriptor();

    @SuppressWarnings({"ClassReferencesSubclass"})
    public static final JavaeeDescriptorType WEB = new JavaeeWebDescriptor();

    @SuppressWarnings({"PublicStaticArrayField"})
    public static final JavaeeDescriptorType[] ALL = {APP, EJB, CMP, WEB};

    private final Icon icon;

    @NonNls
    private String file;

    @NonNls
    private String root;

    private ConfigFileMetaData meta;

    private final List<ConfigFileVersion> versions = new ArrayList<ConfigFileVersion>();

    private final Set<String> namespaces = new HashSet<String>();

    protected JavaeeDescriptorType(Icon icon) {
        this.icon = icon;
    }

    public Icon getIcon() {
        return icon;
    }

    public String getRoot() {
        return root;
    }

    public ConfigFileMetaData getMetaData() {
        return meta;
    }

    public boolean hasNamespace(String namespace) {
        return namespaces.contains(namespace);
    }

    @SuppressWarnings({"ParameterHidesMemberVariable"})
    public void init(@NonNls String file, @NonNls String root) {
        this.file = file;
        this.root = root;
    }

    public void addVersion(@NonNls String version, @NonNls String template, @NonNls String namespace) {
        versions.add(new ConfigFileVersion(version, template));
        namespaces.add(namespace);
    }

    public void registerMetaData(JavaeeIntegration integration) {
        ConfigFileVersion[] tmp = versions.toArray(new ConfigFileVersion[versions.size()]);
        Arrays.sort(tmp, new Comparator<ConfigFileVersion>() {
            public int compare(ConfigFileVersion v1, ConfigFileVersion v2) {
                return v1.getName().compareTo(v2.getName());
            }
        });
        meta = new ConfigFileMetaData(getTitle(integration), file, getPath(), tmp, null, true, true, true);
        registerMetaData(integration, meta);
    }

    @Nullable
    public <T extends DomElement> T getRoot(@Nullable JavaeeFacet facet, @NotNull Class<T> type) {
        if (facet != null) {
            ConfigFile item = facet.getDescriptorsContainer().getConfigFile(meta);
            if (item != null) {
                XmlFile xml = item.getXmlFile();
                if (xml != null) {
                    DomFileElement<T> element = DomManager.getDomManager(facet.getModule().getProject()).getFileElement(xml, type);
                    if (element != null) {
                        return element.getRootElement();
                    }
                }
            }
        }
        return null;
    }

    abstract String getTitle(JavaeeIntegration integration);

    abstract void registerMetaData(JavaeeIntegration integration, ConfigFileMetaData meta);

    @NonNls
    String getPath() {
        return "META-INF";
    }
}
