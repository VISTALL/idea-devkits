/*
 * Copyright (c) 2008 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.descriptor;

import java.io.IOException;
import com.fuhrer.idea.javaee.JavaeeLogger;
import com.fuhrer.idea.javaee.util.DirectoryScanner;
import com.fuhrer.idea.javaee.util.FileWrapper;
import com.intellij.javaee.ExternalResourceManager;
import com.intellij.openapi.components.ApplicationComponent;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

public abstract class JavaeeResources implements ApplicationComponent {

    @NotNull
    public String getComponentName() {
        return getClass().getSimpleName();
    }

    public void initComponent() {
        try {
            final ExternalResourceManager manager = ExternalResourceManager.getInstance();
            new DirectoryScanner(".+\\.(dtd|xsd)") {
                @Override
                protected void handle(FileWrapper file) throws Exception {
                    manager.addStdResource(getResourceUri(file), file.getPath(), getClass());
                }
            }.scan("descriptors");
        } catch (IOException e) {
            JavaeeLogger.error(e);
        }
    }

    public void disposeComponent() {
    }

    @NotNull
    @NonNls
    protected abstract String getResourceUri(FileWrapper file) throws Exception;
}
