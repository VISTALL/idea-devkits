/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.editor;

import com.fuhrer.idea.javaee.server.JavaeeIntegration;
import com.intellij.javaee.CommonModelManager;
import com.intellij.javaee.application.facet.JavaeeApplicationFacet;
import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.model.xml.ejb.EjbBase;
import com.intellij.javaee.model.xml.ejb.EntityBean;
import com.intellij.javaee.model.xml.ejb.MessageDrivenBean;
import com.intellij.javaee.model.xml.ejb.SessionBean;
import com.intellij.javaee.model.xml.web.Servlet;
import com.intellij.javaee.module.view.common.editor.JavaeeFacetAsVirtualFile;
import com.intellij.javaee.module.view.ejb.editor.EjbAsVirtualFile;
import com.intellij.javaee.module.view.web.editor.ServletAsVirtualFile;
import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.ui.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class JavaeeEditorProvider extends PerspectiveFileEditorProvider {

    @SuppressWarnings({"ChainOfInstanceofChecks", "InstanceofIncompatibleInterface", "CastToIncompatibleInterface"})
    public final boolean accept(@NotNull Project project, @NotNull VirtualFile file) {
        boolean accept = false;
        if (file instanceof JavaeeFacetAsVirtualFile) {
            JavaeeFacet facet = ((JavaeeFacetAsVirtualFile) file).findFacet(project);
            if (facet != null) {
                accept = acceptFacet(facet);
            }
        } else if (file instanceof EjbAsVirtualFile) {
            EjbBase bean = CommonModelManager.getInstance().getDomElement(((EjbAsVirtualFile) file).findElement(project));
            if (bean != null) {
                accept = acceptEjbBean(bean);
            }
        } else if (file instanceof ServletAsVirtualFile) {
            Servlet servlet = ((ServletAsVirtualFile) file).findElement(project);
            if (servlet != null) {
                accept = acceptServlet(servlet);
            }
        }
        return accept;
    }

    @Override
    @NotNull
    @SuppressWarnings({"ChainOfInstanceofChecks", "InstanceofIncompatibleInterface", "CastToIncompatibleInterface"})
    public final PerspectiveFileEditor createEditor(@NotNull Project project, @NotNull VirtualFile file) {
        PerspectiveFileEditor editor = null;
        if (file instanceof JavaeeFacetAsVirtualFile) {
            JavaeeFacet facet = ((JavaeeFacetAsVirtualFile) file).findFacet(project);
            if (facet != null) {
                editor = createModuleEditor(project, file, facet);
            }
        } else if (file instanceof EjbAsVirtualFile) {
            EjbBase bean = CommonModelManager.getInstance().getDomElement(((EjbAsVirtualFile) file).findElement(project));
            if (bean != null) {
                editor = createEjbBeanEditor(project, file, bean);
            }
        } else if (file instanceof ServletAsVirtualFile) {
            Servlet servlet = ((ServletAsVirtualFile) file).findElement(project);
            if (servlet != null) {
                editor = createServletEditor(project, file, servlet);
            }
        }
        if (editor == null) {
            editor = createEmptyEditor(project, file);
        }
        return editor;
    }

    protected boolean acceptFacet(@NotNull JavaeeFacet facet) {
        boolean accept = false;
        if (JavaeeApplicationFacet.ID.equals(facet.getTypeId())) {
            accept = acceptAppRoot((JavaeeApplicationFacet) facet);
        } else if (EjbFacet.ID.equals(facet.getTypeId())) {
            accept = acceptEjbRoot((EjbFacet) facet);
        } else if (WebFacet.ID.equals(facet.getTypeId())) {
            accept = acceptWebRoot((WebFacet) facet);
        }
        return accept;
    }

    protected boolean acceptAppRoot(@NotNull JavaeeApplicationFacet facet) {
        return false;
    }

    protected boolean acceptEjbRoot(@NotNull EjbFacet facet) {
        return false;
    }

    protected boolean acceptWebRoot(@NotNull WebFacet facet) {
        return false;
    }

    @SuppressWarnings({"ChainOfInstanceofChecks"})
    protected boolean acceptEjbBean(@NotNull EjbBase bean) {
        boolean accept = false;
        if (bean instanceof SessionBean) {
            accept = acceptSessionBean((SessionBean) bean);
        } else if (bean instanceof EntityBean) {
            accept = acceptEntityBean((EntityBean) bean);
        } else if (bean instanceof MessageDrivenBean) {
            accept = acceptMessageBean((MessageDrivenBean) bean);
        }
        return accept;
    }

    protected boolean acceptEntityBean(@NotNull EntityBean bean) {
        return false;
    }

    protected boolean acceptSessionBean(@NotNull SessionBean bean) {
        return false;
    }

    protected boolean acceptMessageBean(@NotNull MessageDrivenBean bean) {
        return false;
    }

    protected boolean acceptServlet(@NotNull Servlet servlet) {
        return false;
    }

    @Nullable
    protected PerspectiveFileEditor createModuleEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeFacet facet) {
        PerspectiveFileEditor editor;
        if (JavaeeApplicationFacet.ID.equals(facet.getTypeId())) {
            editor = createAppRootEditor(project, file, (JavaeeApplicationFacet) facet);
        } else if (EjbFacet.ID.equals(facet.getTypeId())) {
            editor = createEjbRootEditor(project, file, (EjbFacet) facet);
        } else if (WebFacet.ID.equals(facet.getTypeId())) {
            editor = createWebRootEditor(project, file, (WebFacet) facet);
        } else {
            editor = createEmptyEditor(project, file);
        }
        return editor;
    }

    @Nullable
    protected PerspectiveFileEditor createAppRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeApplicationFacet facet) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    protected PerspectiveFileEditor createEjbRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull EjbFacet facet) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    protected PerspectiveFileEditor createWebRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull WebFacet facet) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    @SuppressWarnings({"ChainOfInstanceofChecks"})
    protected PerspectiveFileEditor createEjbBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull EjbBase bean) {
        PerspectiveFileEditor editor;
        if (bean instanceof SessionBean) {
            editor = createSessionBeanEditor(project, file, (SessionBean) bean);
        } else if (bean instanceof EntityBean) {
            editor = createEntityBeanEditor(project, file, (EntityBean) bean);
        } else if (bean instanceof MessageDrivenBean) {
            editor = createMessageBeanEditor(project, file, (MessageDrivenBean) bean);
        } else {
            editor = createEmptyEditor(project, file);
        }
        return editor;
    }

    @Nullable
    protected PerspectiveFileEditor createEntityBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull EntityBean bean) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    protected PerspectiveFileEditor createSessionBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull SessionBean bean) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    protected PerspectiveFileEditor createMessageBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull MessageDrivenBean bean) {
        return createEmptyEditor(project, file);
    }

    @Nullable
    protected PerspectiveFileEditor createServletEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull Servlet servlet) {
        return createEmptyEditor(project, file);
    }

    @NotNull
    protected PerspectiveFileEditor createEditor(@NotNull DomElement element, @NotNull CommittablePanel panel) {
        JavaeeIntegration integration = JavaeeIntegration.getInstance();
        CaptionComponent caption = new CaptionComponent(integration.getPresentableName(), integration.getBigIcon());
        caption = DomUIFactory.getDomUIFactory().addErrorPanel(caption, element);
        return DomFileEditor.createDomFileEditor(caption.getText(), element, caption, panel);
    }

    @NotNull
    private PerspectiveFileEditor createEmptyEditor(@NotNull Project project, @NotNull VirtualFile file) {
        JavaeeIntegration integration = JavaeeIntegration.getInstance();
        return new JavaeeEmptyEditor(project, file, integration.getPresentableName(), integration.getBigIcon());
    }
}
