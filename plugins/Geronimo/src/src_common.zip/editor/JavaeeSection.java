/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.editor;

import java.util.List;
import com.intellij.util.xml.DomElement;

public interface JavaeeSection<T extends DomElement> {

    JavaeeSectionInfo<T>[] createColumnInfos();

    List<T> getValues();
}
