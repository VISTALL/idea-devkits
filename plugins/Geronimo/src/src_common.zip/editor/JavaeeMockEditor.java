/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.editor;

import com.fuhrer.idea.javaee.server.JavaeeIntegration;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.ui.MockJavaeeDomElementsEditor;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.ui.*;
import org.jetbrains.annotations.Nullable;

public abstract class JavaeeMockEditor extends MockJavaeeDomElementsEditor {

    protected JavaeeMockEditor(JavaeeFacet facet) {
        super(facet);
    }

    protected final DomFileEditor<?> initEditor(CommittablePanel panel, DomElement element) {
        JavaeeIntegration integration = JavaeeIntegration.getInstance();
        CaptionComponent caption = new CaptionComponent(integration.getPresentableName(), integration.getBigIcon());
        caption = DomUIFactory.getDomUIFactory().addErrorPanel(caption, element);
        BasicDomElementComponent<?> component = DomFileEditor.createComponentWithCaption(panel, caption, element);
        return initFileEditor(component, element.getRoot().getFile().getVirtualFile(), caption.getText());
    }

    protected void addWatchedElement(DomFileEditor<?> editor, @Nullable DomElement element) {
        if (element != null) {
            editor.addWatchedElement(element);
        }
    }
}
