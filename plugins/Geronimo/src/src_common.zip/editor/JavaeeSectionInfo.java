/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.editor;

import javax.swing.table.*;
import com.intellij.util.ui.ColumnInfo;
import com.intellij.util.xml.DomElement;

public abstract class JavaeeSectionInfo<T extends DomElement> extends ColumnInfo<T, String> {

    private static final TableCellRenderer renderer = new DefaultTableCellRenderer();

    protected JavaeeSectionInfo(String name) {
        super(name);
    }

    @Override
    public TableCellRenderer getRenderer(T item) {
        return renderer;
    }
}
