/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee;

import java.util.ListResourceBundle;
import java.util.ResourceBundle;
import com.intellij.CommonBundle;
import com.intellij.ide.plugins.cl.PluginClassLoader;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.PropertyKey;

public abstract class JavaeeBundle extends ListResourceBundle {

    @NonNls
    private static final String PATH = "resources.javaee";

    private static final ResourceBundle BUNDLE = ResourceBundle.getBundle(PATH);

    public static String get(@PropertyKey(resourceBundle = PATH)String key, Object... params) {
        return CommonBundle.message(BUNDLE, key, params);
    }

    @Override
    @SuppressWarnings({"ZeroLengthArrayAllocation"})
    protected Object[][] getContents() {
        ClassLoader loader = getClass().getClassLoader();
        if (loader instanceof PluginClassLoader) {
            @NonNls String key = "plugin." + ((PluginClassLoader) loader).getPluginId() + ".description";
            return new Object[][]{{key, get("Integration.description", getName())}};
        } else {
            return new Object[][]{};
        }
    }

    @NotNull
    protected abstract String getName();
}
