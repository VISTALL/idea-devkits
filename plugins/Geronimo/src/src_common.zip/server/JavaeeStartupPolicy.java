/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import com.intellij.execution.util.EnvironmentVariable;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.run.localRun.*;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;

public abstract class JavaeeStartupPolicy<T extends JavaeeServerModel> implements ExecutableObjectStartupPolicy {

    public ScriptsHelper getStartupHelper() {
        return new ScriptsHelper() {
            public ExecutableObject getDefaultScript(CommonModel config) {
                JavaeeParameters params = new JavaeeParameters();
                getStartupParameters(params, getServerModel(config));
                return new CommandLineExecutableObject(params.get(), null);
            }
        };
    }

    public ScriptsHelper getShutdownHelper() {
        return new ScriptsHelper() {
            public ExecutableObject getDefaultScript(CommonModel config) {
                JavaeeParameters params = new JavaeeParameters();
                getShutdownParameters(params, getServerModel(config));
                return new CommandLineExecutableObject(params.get(), null);
            }
        };
    }

    public EnvironmentHelper getEnvironmentHelper() {
        return new EnvironmentHelper() {
            @Override
            public String getDefaultJavaVmEnvVariableName(CommonModel config) {
                return getEnvironmentVariableName(getServerModel(config));
            }

            @Override
            public List<EnvironmentVariable> getAdditionalEnvironmentVariables(CommonModel config) {
                return getEnvironmentVariables(getServerModel(config));
            }
        };
    }

    @NonNls
    protected abstract void getStartupParameters(JavaeeParameters params, T model);

    @NonNls
    protected abstract void getShutdownParameters(JavaeeParameters params, T model);

    @NonNls
    protected String getEnvironmentVariableName(T model) {
        return "JAVA_OPTS";
    }

    @Nullable
    @NonNls
    protected List<EnvironmentVariable> getEnvironmentVariables(T model) {
        return null;
    }

    protected void add(List<String> list, @NonNls String... parameters) {
        for (String parameter : parameters) {
            if (StringUtil.isEmpty(parameter)) {
                return;
            }
        }
        list.addAll(Arrays.asList(parameters));
    }

    @SuppressWarnings({"unchecked"})
    private T getServerModel(CommonModel config) {
        return (T) config.getServerModel();
    }
}
