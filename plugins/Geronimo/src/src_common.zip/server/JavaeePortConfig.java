/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import com.intellij.openapi.util.text.StringUtil;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class JavaeePortConfig {

    private static final Map<Object, JavaeePortConfig> configs = new HashMap<Object, JavaeePortConfig>();

    private long stamp;

    private int port;

    protected static <M extends JavaeeServerModel> int get(Factory<M> factory, M model, int dflt) {
        Key key = factory.createKey(model);
        if (key.isValid()) {
            JavaeePortConfig config = configs.get(key);
            if (config == null) {
                config = factory.createConfig(model);
                configs.put(key, config);
            }
            int port = config.getPort(model);
            if (port > 0) {
                return port;
            }
        }
        return dflt;
    }

    @Nullable
    protected Element findElement(Element parent, @NonNls String tag, @NonNls String name, @NonNls String value) {
        for (Object o : parent.getChildren(tag, parent.getNamespace())) {
            Element element = (Element) o;
            if (element.getAttributeValue(name).matches(value)) {
                return element;
            }
        }
        return null;
    }

    protected long getStamp(File file) {
        return ((file != null) && file.exists()) ? (file.lastModified() ^ file.length()) : 0;
    }

    protected long getStamp(String str) {
        return (str != null) ? str.hashCode() : 0;
    }

    protected abstract long getStamp(JavaeeServerModel model);

    protected abstract int findPort(JavaeeServerModel model);

    private int getPort(JavaeeServerModel model) {
        if (stamp != getStamp(model)) {
            port = findPort(model);
            stamp = getStamp(model);
        }
        return port;
    }

    @SuppressWarnings({"ProtectedInnerClass"})
    protected static class Key {

        private final String[] parts;

        @SuppressWarnings({"PublicConstructorInNonPublicClass", "AssignmentToCollectionOrArrayFieldFromParameter"})
        public Key(@NotNull String... parts) {
            this.parts = parts;
        }

        public boolean isValid() {
            for (String part : parts) {
                if (StringUtil.isEmpty(part)) {
                    return false;
                }
            }
            return true;
        }

        @Override
        @SuppressWarnings({"AccessingNonPublicFieldOfAnotherObject"})
        public boolean equals(Object other) {
            return (other instanceof Key) && Arrays.equals(parts, ((Key) other).parts);
        }

        @Override
        public int hashCode() {
            return Arrays.hashCode(parts);
        }
    }

    @SuppressWarnings({"ProtectedInnerClass"})
    protected interface Factory<M extends JavaeeServerModel> {

        @NotNull
        Key createKey(M model);

        @NotNull
        JavaeePortConfig createConfig(M model);
    }
}
