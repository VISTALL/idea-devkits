/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.util.HashMap;
import java.util.Map;
import com.fuhrer.idea.javaee.util.CachedConfig;

public abstract class JavaeePortConfig extends CachedConfig<JavaeeServerModel> {

    private static final Map<Key, JavaeePortConfig> cache = new HashMap<Key, JavaeePortConfig>();

    private int port;

    @SuppressWarnings({"MethodOverridesStaticMethodOfSuperclass", "AccessingNonPublicFieldOfAnotherObject"})
    protected static <M extends JavaeeServerModel> int get(Factory<M> factory, M model, int dflt) {
        JavaeePortConfig config = get(cache, factory, model);
        if (config != null) {
            int port = config.port;
            if (port > 0) {
                return port;
            }
        }
        return dflt;
    }

    @Override
    protected void update(JavaeeServerModel data) {
        port = getPort(data);
    }

    protected abstract int getPort(JavaeeServerModel model);

    @SuppressWarnings({"ProtectedInnerClass", "MarkerInterface", "ClassNameSameAsAncestorName"})
    protected interface Factory<T extends JavaeeServerModel> extends CachedConfig.Factory<T, JavaeePortConfig> {

    }
}
