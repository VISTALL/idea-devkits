/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import com.intellij.facet.pointers.FacetPointer;
import com.intellij.javaee.deployment.DeploymentMethod;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.deployment.DeploymentProvider;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

class JavaeeDeploymentProvider implements DeploymentProvider {

    private static final DeploymentMethod[] METHODS = {};

    public DeploymentMethod[] getAvailableMethods() {
        return METHODS;
    }

    @Nullable
    public SettingsEditor<DeploymentModel> createAdditionalDeploymentSettingsEditor(CommonModel config, JavaeeFacet facet) {
        return null;
    }

    public DeploymentModel createNewDeploymentModel(CommonModel config, FacetPointer<JavaeeFacet> pointer) {
        return new JavaeeDeploymentModel(config, pointer);
    }

    public void doDeploy(Project project, J2EEServerInstance instance, DeploymentModel deployment) {
        ((JavaeeServerInstance) instance).deploy(deployment);
    }

    public void startUndeploy(J2EEServerInstance instance, DeploymentModel deployment) {
        ((JavaeeServerInstance) instance).undeploy(deployment);
    }

    public void updateDeploymentStatus(J2EEServerInstance instance, DeploymentModel deployment) {
        ((JavaeeServerInstance) instance).updateDeploymentStatus(deployment);
    }

    @Nullable
    @NonNls
    public String getHelpId() {
        return null;
    }
}
