/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.javaee.server;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import javax.swing.*;
import com.fuhrer.idea.javaee.JavaeeBundle;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptorType;
import com.intellij.codeInspection.InspectionToolProvider;
import com.intellij.ide.IconProvider;
import com.intellij.ide.fileTemplates.FileTemplateDescriptor;
import com.intellij.ide.fileTemplates.FileTemplateGroupDescriptor;
import com.intellij.javaee.ExternalResourceManager;
import com.intellij.javaee.appServerIntegrations.AppServerDeployedFileUrlProvider;
import com.intellij.javaee.appServerIntegrations.AppServerIntegration;
import com.intellij.javaee.appServerIntegrations.ApplicationServerHelper;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.deployment.DeploymentUtil;
import com.intellij.openapi.util.JDOMUtil;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.PsiElement;
import com.intellij.psi.util.SimpleCachedValueProvider;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import com.intellij.ui.LayeredIcon;
import com.intellij.util.descriptors.ConfigFileVersion;
import com.intellij.util.xml.DomElement;
import com.intellij.util.xml.DomFileElement;
import com.intellij.util.xml.DomManager;
import org.jdom.DocType;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class JavaeeIntegration extends AppServerIntegration implements InspectionToolProvider, IconProvider {

    @SuppressWarnings({"StaticNonFinalField"})
    private static JavaeeIntegration instance;

    private final Map<String, JavaeeDescriptorType> descriptors = new HashMap<String, JavaeeDescriptorType>();

    private final SimpleCachedValueProvider<Icon, XmlFile> provider = new SimpleCachedValueProvider<Icon, XmlFile>(getComponentName()) {
        @Override
        @Nullable
        protected Icon updateValue(XmlFile file) {
            return getIcon(file);
        }
    };

    @SuppressWarnings({"NonThreadSafeLazyInitialization"})
    public static JavaeeIntegration getInstance() {
        if (instance == null) {
            instance = ApplicationManager.getApplication().getComponents(JavaeeIntegration.class)[0];
        }
        return instance;
    }

    @NotNull
    @NonNls
    public String getComponentName() {
        return getClass().getSimpleName();
    }

    public void initComponent() {
        registerResources();
        registerTemplates();
        for (JavaeeDescriptorType descriptorType : descriptors.values()) {
            descriptorType.registerMetaData(this);
        }
    }

    public void disposeComponent() {
    }

    @Override
    public String getPresentableName() {
        return JavaeeBundle.get("Integration.name", getName());
    }

    @Override
    @Nullable
    public ApplicationServerHelper getApplicationServerHelper() {
        return new JavaeeServerHelper();
    }

    @Override
    @Nullable
    public FileTemplateGroupDescriptor getFileTemplatesDescriptor() {
        FileTemplateGroupDescriptor root = new FileTemplateGroupDescriptor(getPresentableName(), getIcon());
        Set<JavaeeDescriptorType> set = new HashSet<JavaeeDescriptorType>(descriptors.values());
        for (JavaeeDescriptorType type : JavaeeDescriptorType.ALL) {
            if (set.remove(type)) {
                getFileTemplates(root, type);
            }
        }
        for (JavaeeDescriptorType type : set) {
            getFileTemplates(root, type);
        }
        return root;
    }

    @Override
    @NotNull
    public AppServerDeployedFileUrlProvider getDeployedFileUrlProvider() {
        return new AppServerDeployedFileUrlProvider() {
            @Nullable
            public String getUrlForDeployedFile(J2EEServerInstance instance, DeploymentModel deployment, String path) {
                if (instance instanceof JavaeeServerInstance) {
                    String root = ((JavaeeServerInstance) instance).getContextRoot(deployment);
                    if (root != null) {
                        JavaeeServerModel model = (JavaeeServerModel) instance.getCommonModel().getServerModel();
                        return DeploymentUtil.concatPaths(model.getDefaultUrlForBrowser(false), root, path);
                    }
                }
                return null;
            }
        };
    }

    public Class<?>[] getInspectionClasses() {
        return new Class[]{getInspectionClass()};
    }

    @Nullable
    public Icon getIcon(@NotNull PsiElement element, int flags) {
        return (element instanceof XmlFile) ? provider.getValue((XmlFile) element) : null;
    }

    @NotNull
    public abstract String getName();

    @NotNull
    public abstract Icon getIcon();

    @NotNull
    public abstract Icon getBigIcon();

    @NotNull
    @NonNls
    protected abstract String getResourceUri(JavaeeFile file) throws Exception;

    @Nullable
    @NonNls
    protected abstract String getNameFromTemplate(String template) throws Exception;

    @Nullable
    @NonNls
    protected abstract String getVersionFromTemplate(String template) throws Exception;

    protected abstract void registerDescriptorTypes(Map<String, JavaeeDescriptorType> types);

    @NotNull
    @NonNls
    protected abstract String getServerVersion(String home) throws Exception;

    protected abstract void checkValidServerHome(String home) throws Exception;

    protected abstract void addLibraryLocations(String home, List<File> locations);

    @NotNull
    protected abstract Class<? extends JavaeeInspection> getInspectionClass();

    protected void checkFile(@NonNls String home, @NonNls String path) throws IOException {
        if (!new File(home, path).exists()) {
            throw new FileNotFoundException(JavaeeBundle.get("Error.fileNotFound", path));
        }
    }

    private void registerResources() {
        try {
            new JavaeeFileScanner(".+\\.(dtd|xsd)") {
                @Override
                protected void handle(JavaeeFile file) throws Exception {
                    ExternalResourceManager manager = ExternalResourceManager.getInstance();
                    manager.addStdResource(getResourceUri(file), file.getPath(), getClass());
                }
            }.scan("descriptors");
        } catch (IOException e) {
            JavaeeLogger.error(e);
        }
    }

    private void registerTemplates() {
        final Map<String, JavaeeDescriptorType> types = new HashMap<String, JavaeeDescriptorType>();
        registerDescriptorTypes(types);
        try {
            new JavaeeFileScanner(".+\\.xml\\.ft") {
                @Override
                protected void handle(JavaeeFile file) throws Exception {
                    @NonNls String template = file.getName().replaceFirst("\\.ft$", "");
                    @NonNls String name = getNameFromTemplate(template) + ".xml";
                    @NonNls String version = getVersionFromTemplate(template);
                    if (!StringUtil.isEmpty(name) && !StringUtil.isEmpty(version) && types.containsKey(name)) {
                        Element root = JDOMUtil.loadDocument(file.getStream()).getRootElement();
                        JavaeeDescriptorType descriptor = descriptors.get(root.getName());
                        if (descriptor == null) {
                            descriptor = types.get(name);
                            descriptor.init(name, root.getName());
                            descriptors.put(root.getName(), descriptor);
                        }
                        descriptor.addVersion(version, template, getNamespace(root));
                    }
                }
            }.scan("fileTemplates/j2ee");
        } catch (IOException e) {
            JavaeeLogger.error(e);
        }
    }

    private String getNamespace(Element root) {
        String namespace = root.getNamespaceURI();
        if (StringUtil.isEmpty(namespace)) {
            DocType type = root.getDocument().getDocType();
            namespace = (type != null) ? type.getSystemID() : "";
        }
        return namespace;
    }

    private void getFileTemplates(FileTemplateGroupDescriptor root, JavaeeDescriptorType type) {
        Icon icon = getIcon(type);
        ConfigFileVersion[] versions = type.getMetaData().getVersions();
        if (versions.length == 1) {
            root.addTemplate(new FileTemplateDescriptor(versions[0].getTemplateName(), icon));
        } else {
            FileTemplateGroupDescriptor group = new FileTemplateGroupDescriptor(type.getMetaData().getTitle(), icon);
            for (ConfigFileVersion version : versions) {
                group.addTemplate(new FileTemplateDescriptor(version.getTemplateName(), icon));
            }
            root.addTemplate(group);
        }
    }

    @Nullable
    private Icon getIcon(XmlFile file) {
        DomFileElement<DomElement> element = DomManager.getDomManager(file.getProject()).getFileElement(file);
        if (element != null) {
            DomElement root = element.getRootElement();
            XmlTag tag = root.getXmlTag();
            if (tag != null) {
                JavaeeDescriptorType type = descriptors.get(root.getXmlElementName());
                if ((type != null) && type.hasNamespace(tag.getNamespace())) {
                    return getIcon(type);
                }
            }
        }
        return null;
    }

    @NotNull
    private Icon getIcon(@NotNull JavaeeDescriptorType type) {
        LayeredIcon icon = new LayeredIcon(2);
        icon.setIcon(type.getIcon(), 1);
        icon.setIcon(getIcon(), 0);
        return icon;
    }
}
