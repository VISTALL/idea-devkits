/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.server;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import javax.enterprise.deploy.spi.factories.DeploymentFactory;
import javax.management.ObjectName;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import com.fuhrer.idea.geronimo.model.GeronimoCommonRoot;
import com.fuhrer.idea.geronimo.model.GeronimoWebRoot;
import com.fuhrer.idea.javaee.server.JavaeeServerImpl;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.Computable;
import org.apache.geronimo.deployment.plugin.factories.DeploymentFactoryImpl;
import org.apache.geronimo.gbean.GBeanQuery;
import org.apache.geronimo.kernel.Kernel;
import org.apache.geronimo.kernel.config.PersistentConfigurationList;
import org.apache.geronimo.kernel.jmx.KernelDelegate;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

class GeronimoServer10 extends JavaeeServerImpl {

    private Kernel kernel;

    @Override
    protected boolean isConnected(String host, int port) throws Exception {
        return getKernel() && kernel.isRunning() && isStarted();
    }

    @Override
    protected DeploymentFactory getDeploymentFactory() {
        return new DeploymentFactoryImpl();
    }

    @Override
    @NonNls
    protected String getDeployerUrl(String host, int port) {
        return "deployer:geronimo:jmx://" + host + ':' + port;
    }

    @Override
    @Nullable
    @NonNls
    protected String getDeploymentId(final DeploymentModel deployment) throws Exception {
        return ApplicationManager.getApplication().runReadAction(new Computable<String>() {
            @Nullable
            public String compute() {
                GeronimoCommonRoot root = GeronimoDescriptors.getCommonRoot(deployment);
                return (root != null) ? root.getConfigId().getStringValue() : null;
            }
        });
    }

    @Override
    @Nullable
    protected String getContextRoot(Module module) {
        GeronimoWebRoot web = GeronimoDescriptors.getWebRoot(module);
        return (web != null) ? web.getContextRoot().getValue() : null;
    }

    private boolean getKernel() {
        if (kernel == null) {
            try {
                String[] credentials = new String[]{getUsername(), getPassword()};
                Map<String, String[]> env = Collections.singletonMap("jmx.remote.credentials", credentials);
                String url = "service:jmx:rmi://" + getHost() + "/jndi/rmi://" + getHost() + ':' + getPort() + "/JMXConnector";
                kernel = new KernelDelegate(JMXConnectorFactory.connect(new JMXServiceURL(url), env).getMBeanServerConnection());
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    @SuppressWarnings({"unchecked"})
    private boolean isStarted() throws Exception {
        Set<ObjectName> configs = kernel.listGBeans(new GBeanQuery(null, PersistentConfigurationList.class.getName()));
        return !configs.isEmpty() && Boolean.TRUE.equals(kernel.getAttribute(configs.iterator().next(), "kernelFullyStarted"));
    }
}
