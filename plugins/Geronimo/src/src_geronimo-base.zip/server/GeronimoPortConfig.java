/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.fuhrer.idea.javaee.server.JavaeePortConfig;
import com.intellij.openapi.util.JDOMUtil;
import org.jdom.Document;
import org.jdom.Element;

class GeronimoPortConfig extends JavaeePortConfig {

    private final File config;

    private final File props;

    GeronimoPortConfig(String home) {
        config = new File(home, "var/config/config.xml");
        props = new File(home, "var/config/config-substitutions.properties");
    }

    @Override
    protected long getStamp() {
        return getStamp(config) ^ getStamp(props);
    }

    @Override
    protected int findPort() {
        try {
            Document doc = JDOMUtil.loadDocument(config);
            Element cfg = findElement(doc.getRootElement(), "configuration", "name", "geronimo/rmi-naming/.*");
            if (cfg == null) {
                cfg = findElement(doc.getRootElement(), "module", "name", "(:?geronimo|org\\.apache\\.geronimo\\.configs)/rmi-naming/.*");
            }
            if (cfg != null) {
                Element bean = findElement(cfg, "gbean", "name", "RMIRegistry");
                if (bean != null) {
                    Element attribute = findElement(bean, "attribute", "name", "port");
                    if (attribute != null) {
                        return parse(attribute.getTextTrim());
                    }
                }
            }
        } catch (Exception e) {
            // ignore...
        }
        return 0;
    }

    private int parse(String port) throws IOException {
        Matcher matcher = Pattern.compile("\\$\\{\\s*(\\w+)\\s*\\+\\s*(\\w+)\\s*\\}").matcher(port);
        if (matcher.matches() && props.exists()) {
            Properties properties = new Properties();
            properties.load(new FileInputStream(props));
            String part1 = properties.getProperty(matcher.group(1), "0");
            String part2 = properties.getProperty(matcher.group(2), "0");
            return Integer.parseInt(part1) + Integer.parseInt(part2);
        }
        return Integer.parseInt(port);
    }
}
