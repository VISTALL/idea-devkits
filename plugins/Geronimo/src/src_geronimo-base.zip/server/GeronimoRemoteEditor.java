/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.server;

import javax.swing.*;
import com.intellij.openapi.options.ConfigurationException;
import com.fuhrer.idea.javaee.server.JavaeeRunSettingsEditor;

class GeronimoRemoteEditor extends JavaeeRunSettingsEditor<GeronimoRemoteModel> {

    private JPanel panel;

    private JTextField port;

    @Override
    protected JComponent createAdditionalEditor() {
        return panel;
    }

    @Override
    protected void resetEditorFrom(GeronimoRemoteModel model) {
        super.resetEditorFrom(model);
        port.setText(String.valueOf(model.JNDI_PORT));
    }

    @Override
    protected void applyEditorTo(GeronimoRemoteModel model) throws ConfigurationException {
        super.applyEditorTo(model);
        try {
            model.JNDI_PORT = Integer.parseInt(port.getText());
        } catch (Exception e) {
            model.JNDI_PORT = 0;
        }
    }
}
