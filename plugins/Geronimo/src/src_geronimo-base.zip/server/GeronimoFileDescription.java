/*
 * Copyright (c) 2007 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.server;

import java.util.Collections;
import java.util.List;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptorType;
import com.fuhrer.idea.javaee.descriptor.JavaeeFileDescription;
import com.intellij.psi.xml.XmlTag;
import com.intellij.util.NotNullFunction;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

abstract class GeronimoFileDescription<T> extends JavaeeFileDescription<T> {

    @NonNls
    private static final String SYS = "http://geronimo.apache.org/xml/ns/deployment";

    GeronimoFileDescription(Class<T> type, JavaeeDescriptorType meta) {
        super(type, meta);
        registerNamespacePolicy("sys", new NotNullFunction<XmlTag, List<String>>() {
            @NotNull
            public List<String> fun(XmlTag tag) {
                String namespace = tag.getNamespace();
                int pos = namespace.lastIndexOf('-');
                if (pos > 0) {
                    String version = namespace.substring(pos);
                    if (!"1.0".equals(version)) {
                        return Collections.singletonList(SYS + version);
                    }
                }
                return Collections.emptyList();
            }
        });
    }
}
