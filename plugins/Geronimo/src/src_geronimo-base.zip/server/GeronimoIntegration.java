/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.server;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.jar.JarFile;
import javax.swing.*;
import com.fuhrer.idea.geronimo.GeronimoBundle;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptorType;
import com.fuhrer.idea.javaee.server.JavaeeFile;
import com.fuhrer.idea.javaee.server.JavaeeInspection;
import com.fuhrer.idea.javaee.server.JavaeeIntegration;
import com.fuhrer.idea.javaee.util.IconLoader;
import com.intellij.openapi.util.JDOMUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class GeronimoIntegration extends JavaeeIntegration {

    @Override
    @NotNull
    public String getName() {
        return GeronimoBundle.get("GeronimoIntegration.name");
    }

    @Override
    @NotNull
    public Icon getIcon() {
        return IconLoader.get("/resources/geronimo.png");
    }

    @Override
    @NotNull
    public Icon getBigIcon() {
        return IconLoader.get("/resources/geronimobig.png");
    }

    @Override
    @NotNull
    @NonNls
    protected String getResourceUri(JavaeeFile file) throws Exception {
        return JDOMUtil.loadDocument(file.getStream()).getRootElement().getAttribute("targetNamespace").getValue();
    }

    @Override
    @Nullable
    @NonNls
    protected String getNameFromTemplate(String template) throws Exception {
        return template.replaceAll("([\\w-]+)-\\d\\.\\d\\.xml", "$1");
    }

    @Override
    @Nullable
    @NonNls
    protected String getVersionFromTemplate(String template) throws Exception {
        return template.replaceAll("[\\w-]+-(\\d\\.\\d)\\.xml", "$1");
    }

    @Override
    protected void registerDescriptorTypes(Map<String, JavaeeDescriptorType> types) {
        types.put("geronimo-application.xml", JavaeeDescriptorType.APP);
        types.put("openejb-jar.xml", JavaeeDescriptorType.EJB);
        types.put("geronimo-web.xml", JavaeeDescriptorType.WEB);
    }

    @Override
    @NotNull
    protected String getServerVersion(String home) throws Exception {
        @NonNls String name = "org/apache/geronimo/system/serverinfo/geronimo-version.properties";
        JarFile file = new JarFile(getFile(home));
        Properties properties = new Properties();
        properties.load(file.getInputStream(file.getEntry(name)));
        return properties.getProperty("version");
    }

    @Override
    protected void addLibraryLocations(String home, List<File> locations) {
        locations.add(new File(home, "repository"));
    }

    @Override
    @NotNull
    protected Class<? extends JavaeeInspection> getInspectionClass() {
        return GeronimoInspection.class;
    }

    @Nullable
    private File getFile(String home) {
        File file = getFile(new File(home, "lib"));
        if (file == null) {
            file = getFile(new File(home, "repository/org/apache/geronimo/modules/geronimo-system").listFiles()[0]);
        }
        return file;
    }

    @Nullable
    private File getFile(File dir) {
        for (File file : dir.listFiles()) {
            if (file.getName().matches("geronimo-system-.*\\.jar")) {
                return file;
            }
        }
        return null;
    }
}
