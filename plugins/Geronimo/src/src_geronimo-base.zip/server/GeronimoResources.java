/*
 * Copyright (c) 2008 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.server;

import com.fuhrer.idea.javaee.descriptor.JavaeeResources;
import com.fuhrer.idea.javaee.util.FileWrapper;
import com.intellij.openapi.util.JDOMUtil;
import org.jetbrains.annotations.NotNull;

class GeronimoResources extends JavaeeResources {

    @Override
    @NotNull
    protected String getResourceUri(FileWrapper file) throws Exception {
        return JDOMUtil.loadDocument(file.getStream()).getRootElement().getAttribute("targetNamespace").getValue();
    }
}
