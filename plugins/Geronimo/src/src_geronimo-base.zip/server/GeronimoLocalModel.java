/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.server;

import java.io.File;
import com.fuhrer.idea.geronimo.GeronimoBundle;
import com.fuhrer.idea.javaee.server.JavaeeRunSettingsEditor;
import com.intellij.execution.configurations.RuntimeConfigurationError;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.javaee.deployment.DeploymentSource;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.openapi.options.SettingsEditor;
import org.jetbrains.annotations.Nullable;

class GeronimoLocalModel extends GeronimoServerModel {

    public SettingsEditor<CommonModel> getEditor() {
        return new JavaeeRunSettingsEditor<GeronimoLocalModel>();
    }

    @Override
    public int getLocalPort() {
        return GeronimoPortConfig.getLocal(this);
    }

    @Override
    public void checkConfiguration() throws RuntimeConfigurationException {
        if (getServerPort() <= 0) {
            throw new RuntimeConfigurationError(GeronimoBundle.get("GeronimoLocalModel.error.invalid"));
        }
        super.checkConfiguration();
    }

    @Override
    protected boolean isDeploymentSourceSupported(DeploymentSource source) {
        return true;
    }

    @Override
    protected int getServerPort() {
        return GeronimoPortConfig.getAdmin(this);
    }

    @Nullable
    protected String getLogFilePath(String home) {
        return new File(home, "var/log/geronimo.log").getAbsolutePath();
    }
}
