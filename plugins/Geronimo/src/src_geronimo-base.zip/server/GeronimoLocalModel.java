/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.server;

import java.io.File;
import com.fuhrer.idea.geronimo.GeronimoBundle;
import com.intellij.execution.configurations.RuntimeConfigurationError;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.javaee.deployment.DeploymentSource;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.Nullable;

class GeronimoLocalModel extends GeronimoServerModel {

    public SettingsEditor<CommonModel> getEditor() {
        return new GeronimoLocalEditor();
    }

    @Override
    public int getLocalPort() {
        return GeronimoPortConfig.getLocal(this);
    }

    @Override
    public void checkConfiguration() throws RuntimeConfigurationException {
        if (getServerPort() <= 0) {
            throw new RuntimeConfigurationError(GeronimoBundle.getText("GeronimoLocalModel.error.invalid"));
        }
        super.checkConfiguration();
    }

    @Override
    protected boolean isDeploymentSourceSupported(DeploymentSource source) {
        return true;
    }

    @Override
    protected int getServerPort() {
        return GeronimoPortConfig.getAdmin(this);
    }

    @Override
    @Nullable
    protected String getLogFilePath(String home) {
        if (!StringUtil.isEmpty(home)) {
            return new File(home, "var/log/geronimo.log").getAbsolutePath();
        }
        return null;
    }
}
