/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.server;

import java.util.HashMap;
import java.util.Map;
import com.fuhrer.idea.geronimo.GeronimoBundle;
import com.fuhrer.idea.javaee.server.JavaeeRunSettingsEditor;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.javaee.deployment.DeploymentSource;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.util.text.StringUtil;

class GeronimoLocalModel extends GeronimoServerModel {

    private static final Map<String, GeronimoPortConfig> config = new HashMap<String, GeronimoPortConfig>();

    public SettingsEditor<CommonModel> getEditor() {
        return new JavaeeRunSettingsEditor<GeronimoLocalModel>();
    }

    @Override
    public void checkConfiguration() throws RuntimeConfigurationException {
        if (getServerPort() <= 0) {
            throw new RuntimeConfigurationException(GeronimoBundle.get("GeronimoLocalModel.error.invalid"));
        }
    }

    @Override
    protected boolean isDeploymentSourceSupported(DeploymentSource source) {
        return true;
    }

    @Override
    protected int getServerPort() {
        int port = 0;
        String home = getHome();
        if (StringUtil.isNotEmpty(home)) {
            GeronimoPortConfig entry = config.get(home);
            if (entry == null) {
                entry = new GeronimoPortConfig(home);
                config.put(home, entry);
            }
            port = entry.getPort();
        }
        return port;
    }
}
