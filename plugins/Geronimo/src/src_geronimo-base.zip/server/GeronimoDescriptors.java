/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.server;

import com.fuhrer.idea.geronimo.model.GeronimoAppRoot;
import com.fuhrer.idea.geronimo.model.GeronimoCommonRoot;
import com.fuhrer.idea.geronimo.model.GeronimoEjbRoot;
import com.fuhrer.idea.geronimo.model.GeronimoWebRoot;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptorType;
import com.fuhrer.idea.javaee.descriptor.JavaeeDescriptors;
import com.intellij.javaee.JavaeeDeploymentDescriptor;
import com.intellij.javaee.deployment.DeploymentModel;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

public class GeronimoDescriptors extends JavaeeDescriptors {

    GeronimoDescriptors(Project project) {
        super(project);
    }

    @Nullable
    public static GeronimoAppRoot getAppRoot(@Nullable Module module) {
        return (module != null) ? getInstance(module).getAppRoot(module, GeronimoAppRoot.class) : null;
    }

    @Nullable
    public static GeronimoEjbRoot getEjbRoot(@Nullable Module module) {
        return (module != null) ? getInstance(module).getEjbRoot(module, GeronimoEjbRoot.class) : null;
    }

    @Nullable
    public static GeronimoWebRoot getWebRoot(@Nullable Module module) {
        return (module != null) ? getInstance(module).getWebRoot(module, GeronimoWebRoot.class) : null;
    }

    @Nullable
    public static GeronimoCommonRoot getCommonRoot(DeploymentModel deployment) {
        for (JavaeeDeploymentDescriptor descriptor : deployment.getModuleProperties().getDeploymentDescriptors()) {
            if (descriptor.getDescription() instanceof JavaeeDescriptorType) {
                Module module = deployment.getModuleProperties().getModule();
                return getInstance(module).getRoot(module, (JavaeeDescriptorType) descriptor.getDescription(), GeronimoCommonRoot.class);
            }
        }
        return null;
    }

    @NotNull
    private static GeronimoDescriptors getInstance(@NotNull Module module) {
        return module.getProject().getComponent(GeronimoDescriptors.class);
    }

    @Override
    protected void registerFileDescriptions() {
        register(GeronimoAppRoot.class, JavaeeDescriptorType.APP);
        register(GeronimoEjbRoot.class, JavaeeDescriptorType.EJB);
        register(GeronimoWebRoot.class, JavaeeDescriptorType.WEB);
    }
}
