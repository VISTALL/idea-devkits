/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.server;

import java.io.File;
import com.fuhrer.idea.javaee.server.JavaeeParameters;
import com.fuhrer.idea.javaee.server.JavaeeStartupPolicy;
import com.intellij.openapi.util.SystemInfo;
import org.jetbrains.annotations.NonNls;

class GeronimoStartupPolicy extends JavaeeStartupPolicy<GeronimoLocalModel> {

    @Override
    protected void getStartupParameters(JavaeeParameters params, GeronimoLocalModel model) {
        params.add(getScript(model));
        params.add("run", "--quiet");
    }

    @Override
    protected void getShutdownParameters(JavaeeParameters params, GeronimoLocalModel model) {
        params.add(getScript(model));
        params.add("stop");
        params.add("--user", model.USERNAME);
        params.add("--password", model.PASSWORD);
        params.add("--port", String.valueOf(model.getServerPort()));
    }

    private File getScript(GeronimoLocalModel model) {
        File bin = new File(model.getHome(), "bin");
        @NonNls String script = SystemInfo.isWindows ? "geronimo.bat" : "geronimo.sh";
        return new File(bin, script);
    }
}
