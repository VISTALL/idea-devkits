/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.editor;

import com.fuhrer.idea.geronimo.model.GeronimoAppRoot;
import com.fuhrer.idea.geronimo.model.GeronimoEjbRoot;
import com.fuhrer.idea.geronimo.model.GeronimoWebRoot;
import com.fuhrer.idea.geronimo.server.GeronimoDescriptors;
import com.fuhrer.idea.javaee.editor.JavaeeEditorProvider;
import com.intellij.javaee.JavaeeModuleProperties;
import com.intellij.javaee.model.JavaeeApplicationModel;
import com.intellij.javaee.model.xml.ejb.EntityBean;
import com.intellij.javaee.model.xml.ejb.SessionBean;
import com.intellij.javaee.module.components.EjbModuleProperties;
import com.intellij.javaee.web.WebModuleProperties;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.xml.ui.PerspectiveFileEditor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class GeronimoEditorProvider extends JavaeeEditorProvider {

    @Override
    public double getWeight() {
        return 101;
    }

    @Override
    protected boolean acceptAppRoot(@NotNull JavaeeModuleProperties properties, @NotNull JavaeeApplicationModel model) {
        return GeronimoDescriptors.getAppRoot(properties.getModule()) != null;
    }

    @Override
    protected boolean acceptEjbRoot(@NotNull JavaeeModuleProperties properties, @NotNull EjbModuleProperties model) {
        return GeronimoDescriptors.getEjbRoot(properties.getModule()) != null;
    }

    @Override
    protected boolean acceptWebRoot(@NotNull JavaeeModuleProperties properties, @NotNull WebModuleProperties model) {
        return GeronimoDescriptors.getWebRoot(properties.getModule()) != null;
    }

    @Override
    protected boolean acceptEntityBean(@NotNull EntityBean bean) {
        return GeronimoDescriptors.getEjbRoot(bean.getModule()) != null;
    }

    @Override
    protected boolean acceptSessionBean(@NotNull SessionBean bean) {
        return GeronimoDescriptors.getEjbRoot(bean.getModule()) != null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createAppRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeModuleProperties properties, @NotNull JavaeeApplicationModel model) {
        GeronimoAppRoot root = GeronimoDescriptors.getAppRoot(properties.getModule());
        return (root != null) ? createEditor(root, new GeronimoAppRootEditor(root)) : null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createEjbRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeModuleProperties properties, @NotNull EjbModuleProperties model) {
        GeronimoEjbRoot root = GeronimoDescriptors.getEjbRoot(properties.getModule());
        return (root != null) ? createEditor(root, new GeronimoEjbRootEditor(root)) : null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createWebRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeModuleProperties properties, @NotNull WebModuleProperties model) {
        GeronimoWebRoot root = GeronimoDescriptors.getWebRoot(properties.getModule());
        return (root != null) ? createEditor(root, new GeronimoWebRootEditor(root)) : null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createEntityBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull EntityBean bean) {
        return new GeronimoEntityEditor(bean).getFileEditor();
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createSessionBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull SessionBean bean) {
        return new GeronimoSessionEditor(bean).getFileEditor();
    }
}
