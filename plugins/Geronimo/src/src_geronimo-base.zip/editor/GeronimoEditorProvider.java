/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.editor;

import com.fuhrer.idea.geronimo.GeronimoUtil;
import com.fuhrer.idea.geronimo.model.GeronimoAppRoot;
import com.fuhrer.idea.geronimo.model.GeronimoEjbRoot;
import com.fuhrer.idea.geronimo.model.GeronimoWebRoot;
import com.fuhrer.idea.javaee.editor.JavaeeEditorProvider;
import com.intellij.javaee.application.facet.JavaeeApplicationFacet;
import com.intellij.javaee.ejb.EjbModuleUtil;
import com.intellij.javaee.ejb.facet.EjbFacet;
import com.intellij.javaee.model.xml.ejb.EntityBean;
import com.intellij.javaee.model.xml.ejb.SessionBean;
import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.xml.ui.PerspectiveFileEditor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

class GeronimoEditorProvider extends JavaeeEditorProvider {

    @Override
    public double getWeight() {
        return 101;
    }

    @Override
    protected boolean acceptAppRoot(@NotNull JavaeeApplicationFacet facet) {
        return GeronimoUtil.getAppRoot(facet) != null;
    }

    @Override
    protected boolean acceptEjbRoot(@NotNull EjbFacet facet) {
        return GeronimoUtil.getEjbRoot(facet) != null;
    }

    @Override
    protected boolean acceptWebRoot(@NotNull WebFacet facet) {
        return GeronimoUtil.getWebRoot(facet) != null;
    }

    @Override
    protected boolean acceptEntityBean(@NotNull EntityBean bean) {
        return GeronimoUtil.getEjbRoot(EjbModuleUtil.getEjbFacet(bean)) != null;
    }

    @Override
    protected boolean acceptSessionBean(@NotNull SessionBean bean) {
        return GeronimoUtil.getEjbRoot(EjbModuleUtil.getEjbFacet(bean)) != null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createAppRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull JavaeeApplicationFacet facet) {
        GeronimoAppRoot root = GeronimoUtil.getAppRoot(facet);
        return (root != null) ? createEditor(root, new GeronimoAppRootEditor(root)) : null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createEjbRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull EjbFacet facet) {
        GeronimoEjbRoot root = GeronimoUtil.getEjbRoot(facet);
        return (root != null) ? createEditor(root, new GeronimoEjbRootEditor(root)) : null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createWebRootEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull WebFacet facet) {
        GeronimoWebRoot root = GeronimoUtil.getWebRoot(facet);
        return (root != null) ? createEditor(root, new GeronimoWebRootEditor(root)) : null;
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createEntityBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull EntityBean bean) {
        return new GeronimoEntityEditor(bean).getFileEditor();
    }

    @Override
    @Nullable
    protected PerspectiveFileEditor createSessionBeanEditor(@NotNull Project project, @NotNull VirtualFile file, @NotNull SessionBean bean) {
        return new GeronimoSessionEditor(bean).getFileEditor();
    }
}
