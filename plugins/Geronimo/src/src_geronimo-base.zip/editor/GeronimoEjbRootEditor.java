/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.editor;

import javax.swing.*;
import com.fuhrer.idea.geronimo.model.GeronimoEjbRoot;

class GeronimoEjbRootEditor extends GeronimoRootEditor {

    GeronimoEjbRootEditor(GeronimoEjbRoot root) {
        super(root);
        addMainComponent(new JPanel());
    }
}
