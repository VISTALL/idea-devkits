/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.editor;

import javax.swing.*;
import com.fuhrer.idea.geronimo.model.GeronimoWebRoot;

class GeronimoWebRootEditor extends GeronimoRootEditor {

    GeronimoWebRootEditor(GeronimoWebRoot web) {
        super(web);
        addMainComponent(createSplitter(new GeronimoWebSettingsEditor(web), new JPanel(), false));
    }
}
