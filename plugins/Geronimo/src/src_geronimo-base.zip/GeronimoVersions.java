/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo;

import com.intellij.psi.xml.XmlTag;
import com.fuhrer.idea.geronimo.model.GeronimoCommonRoot;

public class GeronimoVersions {

    public static boolean isGeronimo10(GeronimoCommonRoot root) {
        XmlTag tag = root.getRoot().getRootTag();
        return (tag != null) && tag.getNamespace().endsWith(".0");
    }
}
