/*
 * Copyright (c) 2006 by Fuhrer Engineering AG, CH-2504 Biel/Bienne, Switzerland
 */

package com.fuhrer.idea.geronimo.model;

@SuppressWarnings({"InterfaceNeverImplemented"})
public interface GeronimoEjbRoot extends GeronimoCommonRoot {

    GeronimoEnterpriseBeans getEnterpriseBeans();
}
