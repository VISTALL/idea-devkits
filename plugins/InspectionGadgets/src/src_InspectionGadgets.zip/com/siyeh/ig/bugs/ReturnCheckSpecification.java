/*
 * Copyright 2003-2006 Dave Griffith, Bas Leijdekkers
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.siyeh.ig.bugs;

import org.jetbrains.annotations.Nullable;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

class ReturnCheckSpecification {

    private String className = "";
    private Pattern methodNamePattern = null;

    ReturnCheckSpecification(String className, String methodName) {
        super();
        this.className = className;
        try {
            methodNamePattern = Pattern.compile(methodName);
        } catch (PatternSyntaxException ignore) {
            // can't show error at this point
        }
    }

    ReturnCheckSpecification() {
        super();
    }

    public String getClassName() {
        return className;
    }

    public String getMethodName() {
        return methodNamePattern.pattern();
    }

    @Nullable
    public Pattern getMethodNamePattern() {
        return methodNamePattern;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public void setMethodName(String methodName) {
        try {
            methodNamePattern = Pattern.compile(methodName);
        } catch (PatternSyntaxException ignore) {
            // todo probably should display the user an error of some sort.
        }
    }
}