/**
 * (c) 2006 Carp Technologies BV
 * Brouwerijstraat 1, 7523XC Enschede
 * Created: Jun 22, 2006
 */
package com.siyeh.ig.internationalization;

import com.siyeh.ig.InspectionGadgetsFix;
import com.siyeh.InspectionGadgetsBundle;
import com.intellij.openapi.project.Project;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.util.IncorrectOperationException;
import com.intellij.psi.*;
import com.intellij.codeInsight.AnnotationUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author <A href="bas@carp-technologies.nl">Bas Leijdekkers</a>
 */
public class AnnotateQualifierFix extends InspectionGadgetsFix {

    private final String qualifierName;

    public AnnotateQualifierFix(PsiModifierListOwner annotatableQualifier) {
        super();
        qualifierName = ((PsiNamedElement)annotatableQualifier).getName();
    }

    @NotNull
    public String getName() {
        return InspectionGadgetsBundle.message("annotate.with.nonnls.quickfix",
                qualifierName);
    }

    protected void doFix(Project project, ProblemDescriptor descriptor)
            throws IncorrectOperationException {
        final PsiElement element = descriptor.getPsiElement();
        final PsiReferenceExpression methodExpression =
                (PsiReferenceExpression)element.getParent();
        final PsiModifierListOwner annotatableQualifier =
                extractAnnotatableQualifier(methodExpression);
        if (annotatableQualifier ==  null) {
            return;
        }
        final PsiModifierList modifierList =
                annotatableQualifier.getModifierList();
        final PsiManager manager = modifierList.getManager();
        final PsiElementFactory factory =
                manager.getElementFactory();
        final PsiAnnotation annotation =
                factory.createAnnotationFromText(
                        '@' + AnnotationUtil.NON_NLS, modifierList);
        modifierList.addAfter(annotation, null); // add at the front of the list
    }

    @Nullable
    public static PsiModifierListOwner extractAnnotatableQualifier(
            PsiReferenceExpression expression) {
        final PsiExpression qualifierExpression =
                expression.getQualifierExpression();
        if (qualifierExpression instanceof PsiReferenceExpression) {
            final PsiReferenceExpression referenceExpression =
                    (PsiReferenceExpression)qualifierExpression;
            final PsiElement element = referenceExpression.resolve();
            if (element instanceof PsiModifierListOwner) {
                return (PsiModifierListOwner)element;
            }
        }
        return null;
    }
}