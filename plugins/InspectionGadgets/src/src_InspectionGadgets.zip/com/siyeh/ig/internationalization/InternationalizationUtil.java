/**
 * (c) 2006 Carp Technologies BV
 * Brouwerijstraat 1, 7523XC Enschede
 * Created: Jun 22, 2006
 */
package com.siyeh.ig.internationalization;

import com.intellij.psi.PsiExpression;
import com.intellij.psi.PsiReferenceExpression;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiModifierListOwner;
import com.intellij.codeInsight.AnnotationUtil;

/**
 * @author <A href="bas@carp-technologies.nl">Bas Leijdekkers</a>
 */
public class InternationalizationUtil {

    static boolean isNonNlsAnnotated(PsiExpression expression) {
        if (!(expression instanceof PsiReferenceExpression)) {
            return false;
        }
        final PsiReferenceExpression referenceExpression =
                (PsiReferenceExpression)expression;
        final PsiElement element = referenceExpression.resolve();
        if (!(element instanceof PsiModifierListOwner)) {
            return false;
        }
        final PsiModifierListOwner modifierListOwner =
                (PsiModifierListOwner)element;
        return AnnotationUtil.isAnnotated(modifierListOwner,
                AnnotationUtil.NON_NLS, false);
    }
}