/*
 * Copyright 2003-2005 Dave Griffith
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.siyeh.ipp;

import com.intellij.codeInsight.intention.IntentionManager;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.project.Project;
import com.siyeh.IntentionPowerPackBundle;
import com.siyeh.ipp.asserttoif.AssertToIfIntention;
import com.siyeh.ipp.bool.*;
import com.siyeh.ipp.braces.AddBracesIntention;
import com.siyeh.ipp.chartostring.CharToStringIntention;
import com.siyeh.ipp.chartostring.StringToCharIntention;
import com.siyeh.ipp.comment.ChangeToCStyleCommentIntention;
import com.siyeh.ipp.comment.ChangeToEndOfLineCommentIntention;
import com.siyeh.ipp.comment.MoveCommentToSeparateLineIntention;
import com.siyeh.ipp.commutative.FlipCommutativeMethodCallIntention;
import com.siyeh.ipp.commutative.SwapMethodCallArgumentsIntention;
import com.siyeh.ipp.concatenation.JoinConcatenatedStringLiteralsIntention;
import com.siyeh.ipp.concatenation.MakeAppendChainIntoAppendSequenceIntention;
import com.siyeh.ipp.concatenation.ReplaceConcatenationWithStringBufferIntention;
import com.siyeh.ipp.conditional.FlipConditionalIntention;
import com.siyeh.ipp.conditional.RemoveConditionalIntention;
import com.siyeh.ipp.conditional.ReplaceConditionalWithIfIntention;
import com.siyeh.ipp.constant.ConstantExpressionIntention;
import com.siyeh.ipp.constant.ConstantSubexpressionIntention;
import com.siyeh.ipp.decls.SimplifyVariableIntention;
import com.siyeh.ipp.enumswitch.CreateEnumSwitchBranchesIntention;
import com.siyeh.ipp.equality.ReplaceEqualityWithEqualsIntention;
import com.siyeh.ipp.equality.ReplaceEqualityWithSafeEqualsIntention;
import com.siyeh.ipp.equality.ReplaceEqualsWithEqualityIntention;
import com.siyeh.ipp.exceptions.DetailExceptionsIntention;
import com.siyeh.ipp.forloop.ReplaceForEachLoopWithForLoopIntention;
import com.siyeh.ipp.fqnames.ReplaceFullyQualifiedNameWithImportIntention;
import com.siyeh.ipp.imports.ReplaceOnDemandImportIntention;
import com.siyeh.ipp.increment.ExtractIncrementIntention;
import com.siyeh.ipp.initialization.SplitDeclarationAndInitializationIntention;
import com.siyeh.ipp.integer.ConvertIntegerToDecimalIntention;
import com.siyeh.ipp.integer.ConvertIntegerToHexIntention;
import com.siyeh.ipp.integer.ConvertIntegerToOctalIntention;
import com.siyeh.ipp.interfacetoclass.ConvertInterfaceToClassIntention;
import com.siyeh.ipp.junit.CreateAssertIntention;
import com.siyeh.ipp.junit.FlipAssertLiteralIntention;
import com.siyeh.ipp.junit.ReplaceAssertEqualsWithAssertLiteralIntention;
import com.siyeh.ipp.junit.ReplaceAssertLiteralWithAssertEqualsIntention;
import com.siyeh.ipp.opassign.ReplaceWithOperatorAssignmentIntention;
import com.siyeh.ipp.parenthesis.AddClarifyingParenthesesIntention;
import com.siyeh.ipp.parenthesis.RemoveUnnecessaryParenthesesIntention;
import com.siyeh.ipp.shift.ReplaceMultiplyWithShiftIntention;
import com.siyeh.ipp.shift.ReplaceShiftWithMultiplyIntention;
import com.siyeh.ipp.switchtoif.ReplaceIfWithSwitchIntention;
import com.siyeh.ipp.switchtoif.ReplaceSwitchWithIfIntention;
import com.siyeh.ipp.trivialif.*;
import com.siyeh.ipp.varargs.MakeMethodVarargsIntention;
import com.siyeh.ipp.varargs.ConvertVarargParameterToArrayIntention;
import org.jetbrains.annotations.NotNull;

@SuppressWarnings({"OverlyCoupledClass"})
public class IntentionPowerPack implements ProjectComponent {

	@SuppressWarnings({"OverlyLongMethod", "OverlyCoupledMethod"})
	public IntentionPowerPack(Project project) {
		super();
		final IntentionManager mgr = IntentionManager.getInstance(project);

		final String[] category = new String[]{IntentionPowerPackBundle.message("intention.category.numbers")};
		mgr.registerIntentionAndMetaData(new ConvertIntegerToDecimalIntention(), category);
		mgr.registerIntentionAndMetaData(new ConvertIntegerToHexIntention(), category);
		mgr.registerIntentionAndMetaData(new ConvertIntegerToOctalIntention(), category);

		final String[] booleanCategory = new String[]{IntentionPowerPackBundle.message("intention.category.boolean")};
		mgr.registerIntentionAndMetaData(new DemorgansIntention(), booleanCategory);
		mgr.registerIntentionAndMetaData(new RemoveBooleanEqualityIntention(), booleanCategory);
		mgr.registerIntentionAndMetaData(new NegateComparisonIntention(), booleanCategory);
		mgr.registerIntentionAndMetaData(new FlipComparisonIntention(), booleanCategory);
		mgr.registerIntentionAndMetaData(new FlipConjunctionIntention(), booleanCategory);
		mgr.registerIntentionAndMetaData(new ReplaceEqualsWithEqualityIntention(), booleanCategory);
		mgr.registerIntentionAndMetaData(new ReplaceEqualityWithEqualsIntention(), booleanCategory);
		mgr.registerIntentionAndMetaData(new ReplaceEqualityWithSafeEqualsIntention(), booleanCategory);
		mgr.registerIntentionAndMetaData(new ExpandBooleanIntention(), booleanCategory);

		final String[] conditionalCategory = new String[]{IntentionPowerPackBundle.message("intention.category.conditional.operator")};
		mgr.registerIntentionAndMetaData(new FlipConditionalIntention(), conditionalCategory);
		mgr.registerIntentionAndMetaData(new ReplaceConditionalWithIfIntention(), conditionalCategory);
		mgr.registerIntentionAndMetaData(new ReplaceIfWithConditionalIntention(), conditionalCategory);
		mgr.registerIntentionAndMetaData(new RemoveConditionalIntention(), conditionalCategory);

		final String[] shiftCategory = new String[]{IntentionPowerPackBundle.message("intention.category.shift.operation")};
		mgr.registerIntentionAndMetaData(new ReplaceMultiplyWithShiftIntention(), shiftCategory);
		mgr.registerIntentionAndMetaData(new ReplaceShiftWithMultiplyIntention(), shiftCategory);

		final String[] junitCategory = new String[]{IntentionPowerPackBundle.message("intention.category.junit")};
		// todo is ReplaceAssertEqualsWithAssertTrueEqualityIntention() the same as new ReplaceAssertEqualsWithAssertLiteralIntention(project, "true", "assertTrue") ?
		//mgr.registerIntentionAndMetaData(new ReplaceAssertEqualsWithAssertTrueEqualityIntention(), category, "Replace AssertEquals With AssertTrue");
		// todo is ReplaceAssertTrueEqualityWithAssertEqualsIntention() the same as new ReplaceAssertLiteralWithAssertEqualsIntention(project, "true", "assertTrue") ?
		//mgr.registerIntentionAndMetaData(new ReplaceAssertTrueEqualityWithAssertEqualsIntention(), category, "Replace AssertTrue With AssertEquals");

		mgr.registerIntentionAndMetaData(new ReplaceAssertEqualsWithAssertLiteralIntention(), junitCategory);
		mgr.registerIntentionAndMetaData(new ReplaceAssertLiteralWithAssertEqualsIntention(), junitCategory);
		mgr.registerIntentionAndMetaData(new CreateAssertIntention(), junitCategory);
		mgr.registerIntentionAndMetaData(new FlipAssertLiteralIntention(), junitCategory);

		final String[] declarationCategory = new String[]{IntentionPowerPackBundle.message("intention.category.declaration")};
		//   mgr.registerIntentionAndMetaData(new MoveDeclarationIntention(),
		//                                    declarationCategory);
		mgr.registerIntentionAndMetaData(new SimplifyVariableIntention(), declarationCategory);
		mgr.registerIntentionAndMetaData(new SplitDeclarationAndInitializationIntention(), declarationCategory);
		mgr.registerIntentionAndMetaData(new ConvertInterfaceToClassIntention(), declarationCategory);

		final String[] importsCategory = new String[]{IntentionPowerPackBundle.message("intention.category.imports")};
		mgr.registerIntentionAndMetaData(new ReplaceFullyQualifiedNameWithImportIntention(), importsCategory);
        mgr.registerIntentionAndMetaData(new ReplaceOnDemandImportIntention(), importsCategory);
        final String[] commentsCategory = new String[]{IntentionPowerPackBundle.message("intention.category.comments")};
		mgr.registerIntentionAndMetaData(new ChangeToCStyleCommentIntention(), commentsCategory);
		mgr.registerIntentionAndMetaData(new ChangeToEndOfLineCommentIntention(), commentsCategory);
		mgr.registerIntentionAndMetaData(new MoveCommentToSeparateLineIntention(), commentsCategory);

		final String[] controlFlowCategory = new String[]{IntentionPowerPackBundle.message("intention.category.control.flow")};
		mgr.registerIntentionAndMetaData(new SplitElseIfIntention(), controlFlowCategory);
		mgr.registerIntentionAndMetaData(new MergeElseIfIntention(), controlFlowCategory);
		mgr.registerIntentionAndMetaData(new MergeIfAndIntention(), controlFlowCategory);
		mgr.registerIntentionAndMetaData(new MergeIfOrIntention(), controlFlowCategory);
		mgr.registerIntentionAndMetaData(new MergeParallelIfsIntention(), controlFlowCategory);
		mgr.registerIntentionAndMetaData(new ReplaceSwitchWithIfIntention(), controlFlowCategory);
		mgr.registerIntentionAndMetaData(new ReplaceIfWithSwitchIntention(), controlFlowCategory);
		mgr.registerIntentionAndMetaData(new SimplifyIfElseIntention(), controlFlowCategory);
		mgr.registerIntentionAndMetaData(new ReplaceForEachLoopWithForLoopIntention(), controlFlowCategory);
		mgr.registerIntentionAndMetaData(new AddBracesIntention(), controlFlowCategory);
		//mgr.registerIntentionAndMetaData(new RemoveBracesIntention(), controlFlowCategory);
        mgr.registerIntentionAndMetaData(new MakeMethodVarargsIntention(), controlFlowCategory);
        mgr.registerIntentionAndMetaData(new ConvertVarargParameterToArrayIntention(), controlFlowCategory);

        final String[] otherCategory = new String[]{IntentionPowerPackBundle.message("intention.category.other")};
		mgr.registerIntentionAndMetaData(new FlipCommutativeMethodCallIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new SwapMethodCallArgumentsIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new RemoveUnnecessaryParenthesesIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new ReplaceConcatenationWithStringBufferIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new JoinConcatenatedStringLiteralsIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new MakeAppendChainIntoAppendSequenceIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new DetailExceptionsIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new ReplaceWithOperatorAssignmentIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new CharToStringIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new StringToCharIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new AssertToIfIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new CreateEnumSwitchBranchesIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new ConstantExpressionIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new ConstantSubexpressionIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new ExtractIncrementIntention(), otherCategory);
		mgr.registerIntentionAndMetaData(new AddClarifyingParenthesesIntention(), otherCategory);

    }

	public void projectOpened() {
	}

	public void projectClosed() {
	}

	@NotNull
	public String getComponentName() {
		return "IntentionPowerPack";
	}

	public void initComponent() {
	}

	public void disposeComponent() {
	}
}
