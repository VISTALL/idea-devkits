/*
 * Copyright 2003-2005 Dave Griffith
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.siyeh.ipp.junit;

import com.intellij.psi.*;
import com.intellij.util.IncorrectOperationException;
import com.siyeh.ipp.base.Intention;
import com.siyeh.ipp.base.PsiElementPredicate;
import com.siyeh.ipp.psiutils.ParenthesesUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.NonNls;

public class ReplaceAssertTrueEqualityWithAssertEqualsIntention
        extends Intention {

    @NotNull
    public PsiElementPredicate getElementPredicate() {
        return new AssertTrueEqualsPredicate();
    }

    public void processIntention(PsiElement element)
            throws IncorrectOperationException {
        final PsiMethodCallExpression call =
                (PsiMethodCallExpression)element;
        final PsiExpressionList argumentList = call.getArgumentList();
        final PsiExpression[] args = argumentList.getExpressions();
        final PsiReferenceExpression expression = call.getMethodExpression();
        final PsiElement qualifier = expression.getQualifier();
        final String qualifierText;
        if (qualifier == null) {
            qualifierText = "";
        } else {
            qualifierText = qualifier.getText() + '.';
        }
        final String message;
        final PsiExpression body;
        if (args.length == 1) {
            message = null;
            body = args[0];
        } else {
            message = args[0].getText();
            body = args[1];
        }
        final PsiExpression arg1;
        final PsiExpression arg2;
        if (body instanceof PsiBinaryExpression) {
            final PsiBinaryExpression binaryExp = (PsiBinaryExpression)body;
            final PsiExpression lhs = binaryExp.getLOperand();
            final PsiExpression rhs = binaryExp.getROperand();
            arg1 = ParenthesesUtils.stripParentheses(lhs);
            if (rhs != null) {
                arg2 = ParenthesesUtils.stripParentheses(rhs);
            } else {
                arg2 = null;
            }
        } else {
            final PsiMethodCallExpression methExp =
                    (PsiMethodCallExpression)body;
            final PsiReferenceExpression methodExpression =
                    methExp.getMethodExpression();
            final PsiExpression qualifierExpression =
                    methodExpression.getQualifierExpression();
            if (qualifierExpression != null) {
                arg1 = ParenthesesUtils.stripParentheses(qualifierExpression);
            } else {
                arg1 = null;
            }
            arg2 = ParenthesesUtils.stripParentheses(args[0]);
        }
        if (arg1 == null || arg2 == null) {
            return;
        }
        final PsiType argType = arg1.getType();
        final String floatText;
        if (PsiType.FLOAT.equals(argType) ||
                PsiType.DOUBLE.equals(argType)) {
            floatText = ", 0.0";
        } else {
            floatText = "";
        }
        @NonNls final String expString;
        if (message == null) {
            expString = qualifierText + "assertEquals(" + arg1.getText() +
                    ", " + arg2.getText() + floatText + ')';
        } else {
            expString =
                    qualifierText + "assertEquals(" + message + ", " +
                            arg1.getText() + ", " + arg2.getText() + floatText +
                            ')';
        }
        replaceExpression(expString, call);
    }
}