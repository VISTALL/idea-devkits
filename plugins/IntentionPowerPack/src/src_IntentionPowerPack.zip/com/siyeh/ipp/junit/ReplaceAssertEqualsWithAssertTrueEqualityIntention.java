/*
 * Copyright 2003-2006 Dave Griffith, Bas Leijdekkers
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.siyeh.ipp.junit;

import com.intellij.psi.*;
import com.intellij.util.IncorrectOperationException;
import com.siyeh.ipp.base.Intention;
import com.siyeh.ipp.base.PsiElementPredicate;
import com.siyeh.ipp.psiutils.ParenthesesUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.NonNls;

public class ReplaceAssertEqualsWithAssertTrueEqualityIntention
        extends Intention {

    @NotNull
    public PsiElementPredicate getElementPredicate() {
        return new AssertEqualsLiteralPredicate();
    }

    public void processIntention(PsiElement element)
            throws IncorrectOperationException {
        final PsiMethodCallExpression call =
                (PsiMethodCallExpression)element;
        final PsiReferenceExpression expression = call.getMethodExpression();
        final PsiElement qualifier = expression.getQualifier();
        final String qualifierText;
        if (qualifier == null) {
            qualifierText = "";
        } else {
            qualifierText = qualifier.getText() + '.';
        }
        final PsiExpressionList argumentList = call.getArgumentList();
        final PsiExpression[] args = argumentList.getExpressions();
        @NonNls final String expString;
        if (args.length == 2) {
            final PsiExpression arg1 = args[0];
            final PsiExpression arg2 = args[1];
            final PsiType argType = arg1.getType();
            if (isPrimitive(argType)) {
                final String arg1Text;
                if (ParenthesesUtils.getPrecedence(arg1) >
                        ParenthesesUtils.EQUALITY_PRECEDENCE) {
                    arg1Text = '(' + arg1.getText() + ')';
                } else {
                    arg1Text = arg1.getText();
                }
                final String arg2Text;
                if (ParenthesesUtils.getPrecedence(arg2) >
                        ParenthesesUtils.EQUALITY_PRECEDENCE) {
                    arg2Text = '(' + arg2.getText() + ')';
                } else {
                    arg2Text = arg2.getText();
                }
                expString = qualifierText + "assertTrue(" + arg1Text + "==" +
                        arg2Text + ')';
            } else {
                final String arg1Text;
                if (ParenthesesUtils.getPrecedence(arg1) >
                        ParenthesesUtils.METHOD_CALL_PRECEDENCE) {
                    arg1Text = '(' + arg1.getText() + ')';
                } else {
                    arg1Text = arg1.getText();
                }
                expString = qualifierText + "assertTrue(" + arg1Text +
                        ".equals(" + arg2.getText() + "))";
            }
        } else {
            final String label = args[0].getText();
            final PsiExpression arg1 = args[1];
            final PsiExpression arg2 = args[2];
            final PsiType argType = arg1.getType();
            if (isPrimitive(argType)) {
                final String arg1Text;
                if (ParenthesesUtils.getPrecedence(arg1) >
                        ParenthesesUtils.EQUALITY_PRECEDENCE) {
                    arg1Text = '(' + arg1.getText() + ')';
                } else {
                    arg1Text = arg1.getText();
                }
                final String arg2Text;
                if (ParenthesesUtils.getPrecedence(arg2) >
                        ParenthesesUtils.EQUALITY_PRECEDENCE) {
                    arg2Text = '(' + arg2.getText() + ')';
                } else {
                    arg2Text = arg2.getText();
                }
                expString = qualifierText + "assertTrue(" + label + ", " +
                        arg1Text + "==" + arg2Text + ')';
            } else {
                final String arg1Text;
                if (ParenthesesUtils.getPrecedence(arg1) >
                        ParenthesesUtils.METHOD_CALL_PRECEDENCE) {
                    arg1Text = '(' + arg1.getText() + ')';
                } else {
                    arg1Text = arg1.getText();
                }
                expString = qualifierText + "assertTrue(" + label + ", " +
                        arg1Text + ".equals(" + arg2.getText() + "))";
            }
        }
        replaceExpression(expString, call);
    }

    private static boolean isPrimitive(PsiType lhsType) {
        return lhsType.equals(PsiType.INT)
                || lhsType.equals(PsiType.SHORT)
                || lhsType.equals(PsiType.LONG)
                || lhsType.equals(PsiType.DOUBLE)
                || lhsType.equals(PsiType.FLOAT)
                || lhsType.equals(PsiType.CHAR)
                || lhsType.equals(PsiType.BOOLEAN)
                || lhsType.equals(PsiType.BYTE);
    }
}