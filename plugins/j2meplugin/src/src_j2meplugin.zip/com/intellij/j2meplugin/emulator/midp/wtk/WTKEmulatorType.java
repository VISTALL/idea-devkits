/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.emulator.midp.wtk;

import com.intellij.execution.configurations.ConfigurationPerRunnerSettings;
import com.intellij.execution.configurations.RunnerSettings;
import com.intellij.execution.runners.RunnerInfo;
import com.intellij.j2meplugin.emulator.EmulatorType;
import com.intellij.j2meplugin.emulator.MIDPEmulatorType;
import com.intellij.j2meplugin.emulator.MobileApiSettingsEditor;
import com.intellij.j2meplugin.emulator.MobileDefaultApiEditor;
import com.intellij.j2meplugin.module.type.midp.MIDPApplicationType;
import com.intellij.j2meplugin.run.J2MERunConfiguration;
import com.intellij.j2meplugin.run.J2MERunnableState;
import com.intellij.j2meplugin.run.RunUtil;
import com.intellij.j2meplugin.run.emulator.editors.EmulatorEditor;
import com.intellij.j2meplugin.run.emulator.midp.wtk.UEIRunnableState;
import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.projectRoots.Sdk;
import com.intellij.openapi.projectRoots.SdkModificator;
import com.intellij.openapi.util.Pair;

import java.util.Properties;

import org.jetbrains.annotations.NonNls;


/**
 * User: anna
 * Date: Sep 6, 2004
 */
public class WTKEmulatorType extends EmulatorType implements MIDPEmulatorType {
  public static final String EMULATOR_TYPE_NAME = J2MEBundle.message("emulator.wtk.fullname");
  @NonNls
  public static final String KVEM_PATH = "wtklib/kenv.zip;/wtklib/ktools.zip";
  @NonNls
  public static final String UTIL_PATH = "bin/utils";

  @SuppressWarnings({"HardCodedStringLiteral"})
  public WTKEmulatorType() {
    super(EMULATOR_TYPE_NAME, PREVERIFY_PATH, EXE_PATH, KVEM_PATH, PREF_PATH, UTIL_PATH, MIDPApplicationType.NAME,
          DESCRIPTOR, new Pair<String, String[]>("-Xdevice:", null));
  }

  public String suggestName(String homePath) {
    return ConfigurationUtil.getWTKVersion(homePath);
  }

  public boolean isValidHomeDirectory(String homePath) {
    return ConfigurationUtil.isValidWTKHome(homePath);
  }

  public EmulatorEditor getConfigurable(J2MERunConfiguration j2merc, ProjectJdk projectJdk) {
    return new EmulatorEditor(j2merc, ConfigurationUtil.getWTKDevices(projectJdk.getHomePath()), projectJdk);
  }

  public String[] getDefaultOTACommands() {
    return new String[]{RunUtil.INSTALL, RunUtil.FORCE, RunUtil.RUN, RunUtil.REMOVE, RunUtil.TRANSIENT, RunUtil.STORAGE_NAMES};
  }

  public String[] getApi(String homePath) {
    return ConfigurationUtil.getDefaultApiPath(homePath);
  }

  public MobileApiSettingsEditor getApiEditor(String homePath, Sdk sdk, SdkModificator sdkModificator) {
    final Properties apiSettings = ConfigurationUtil.getApiSettings(homePath);
    if (apiSettings == null || apiSettings.isEmpty()) {
      return new MobileDefaultApiEditor();
    }
    return new WTKApiEditor(sdk, sdkModificator);
  }

  public J2MERunnableState getJ2MERunnableState(RunnerInfo runnerInfo,
                                                RunnerSettings runnerSettings,
                                                ConfigurationPerRunnerSettings configurationSetting,
                                                J2MERunConfiguration configuration,
                                                Project project,
                                                ProjectJdk projectJdk) {
    return new UEIRunnableState(runnerInfo, runnerSettings, configurationSetting, configuration, project, projectJdk);
  }

  public String getComponentName() {
    return "WTKEmulatorType";
  }

  public void initComponent() {}

  public void disposeComponent() {}

  public String getProfile(String homePath) {
    return ConfigurationUtil.getProfileVersion(homePath);
  }

  public String getConfiguration(String homePath) {
    return ConfigurationUtil.getConfigurationVersion(homePath);
  }

  public static WTKEmulatorType getInstance() {
    return ApplicationManager.getApplication().getComponent(WTKEmulatorType.class);
  }
}
