/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.emulator.midp.nokia;

import com.intellij.execution.configurations.ConfigurationPerRunnerSettings;
import com.intellij.execution.configurations.RunnerSettings;
import com.intellij.execution.runners.RunnerInfo;
import com.intellij.j2meplugin.emulator.EmulatorType;
import com.intellij.j2meplugin.emulator.MIDPEmulatorType;
import com.intellij.j2meplugin.emulator.MobileApiSettingsEditor;
import com.intellij.j2meplugin.emulator.MobileDefaultApiEditor;
import com.intellij.j2meplugin.module.type.midp.MIDPApplicationType;
import com.intellij.j2meplugin.run.J2MERunConfiguration;
import com.intellij.j2meplugin.run.J2MERunnableState;
import com.intellij.j2meplugin.run.RunUtil;
import com.intellij.j2meplugin.run.emulator.editors.EmulatorEditor;
import com.intellij.j2meplugin.run.emulator.midp.nokia.NokiaRunnableState;
import com.intellij.j2meplugin.run.emulator.midp.wtk.UEIRunnableState;
import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.projectRoots.Sdk;
import com.intellij.openapi.projectRoots.SdkModificator;
import com.intellij.openapi.diagnostic.Logger;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.Properties;

import org.jetbrains.annotations.NonNls;

/**
 * User: anna
 * Date: Oct 6, 2004
 */
public class NokiaEmulatorType extends EmulatorType implements MIDPEmulatorType {
  public static final String NAME = J2MEBundle.message("emulator.nokia.edition");
  @NonNls private static final String KVEM_CLASS_PATH_PROPERTY = "kvem.class.path";
  @NonNls private static final String PREVERIFIER_BINARY_PROPERTY = "preverifier.binary";
  @NonNls private static final String EMULATOR_BINARY_PROPERTY = "emulator.binary";
  @NonNls private static final String API_CLASS_PATH_PROPERTY = "api.class.path";
  @NonNls private static final String MICROEDITION_PROFILES_PROPERTY = "microedition.profiles";
  @NonNls private static final String MICROEDITION_CONFIGURATION_PROPERTY = "microedition.configuration";
  @NonNls private static final String DEVICE_MODEL_PROPERTY = "device.model";
  private static final Logger LOG = Logger.getInstance("#com.intellij.j2meplugin.emulator.midp.nokia.NokiaEmulatorType");

  public NokiaEmulatorType() {
    super(NAME, null, null, null, null, null, MIDPApplicationType.NAME, DESCRIPTOR, null);
  }

  public String getName() {
    return NAME;
  }

  @Nullable
  public String getPrefPath(String home) {
    final String preferences = ConfigurationUtil.getPreferences(home);
    if (preferences != null) {
      return toSystemDependentPath(home, preferences);
    }
    else {
      return null;
    }
  }

  public String getKvemPath(String home) {
    final Properties properties = ConfigurationUtil.getProperties(home);
    LOG.assertTrue(properties != null);
    return getFullPath(home, ConfigurationUtil.getProperties(home).getProperty(KVEM_CLASS_PATH_PROPERTY));
  }

  @Nullable
  public String getUtilPath(String home) {
    return null;
  }

  public String getPreverifyPath(String home) {
    final Properties properties = ConfigurationUtil.getProperties(home);
    LOG.assertTrue(properties != null);
    return toSystemDependentPath(home, ConfigurationUtil.getProperties(home).getProperty(PREVERIFIER_BINARY_PROPERTY));
  }

  public String getExePath(String home) {
    final Properties properties = ConfigurationUtil.getProperties(home);
    LOG.assertTrue(properties != null);
    return toSystemDependentPath(home, ConfigurationUtil.getProperties(home).getProperty(EMULATOR_BINARY_PROPERTY));
  }

  public String getDescriptorOption() {
    return DESCRIPTOR;
  }

  public String[] getApi(String homePath) {
    final Properties properties = ConfigurationUtil.getProperties(homePath);
    LOG.assertTrue(properties != null);
    return getFullPath(homePath, ConfigurationUtil.getProperties(homePath).getProperty(API_CLASS_PATH_PROPERTY)).split(File.pathSeparator);
  }

  public String getProfile(String homePath) {
    final Properties properties = ConfigurationUtil.getProperties(homePath);
    LOG.assertTrue(properties != null);
    return ConfigurationUtil.getProperties(homePath).getProperty(MICROEDITION_PROFILES_PROPERTY);
  }

  public String getConfiguration(String homePath) {
    final Properties properties = ConfigurationUtil.getProperties(homePath);
    LOG.assertTrue(properties != null);
    return ConfigurationUtil.getProperties(homePath).getProperty(MICROEDITION_CONFIGURATION_PROPERTY);
  }

  public MobileApiSettingsEditor getApiEditor(final String homePath, Sdk sdk, SdkModificator sdkModificator) {
    return new MobileDefaultApiEditor();
  }

  public String suggestName(String homePath) {
    final Properties properties = ConfigurationUtil.getProperties(homePath);
    LOG.assertTrue(properties != null);
    return ConfigurationUtil.getProperties(homePath).getProperty(DEVICE_MODEL_PROPERTY);
  }

  public boolean isValidHomeDirectory(String homePath) {
    final Properties emulatorProperties = ConfigurationUtil.getProperties(homePath);
    if (emulatorProperties == null || emulatorProperties.isEmpty()) return false;
    if (emulatorProperties.getProperty(DEVICE_MODEL_PROPERTY) == null) return false;
    if (emulatorProperties.getProperty(MICROEDITION_CONFIGURATION_PROPERTY) == null) return false;
    if (emulatorProperties.getProperty(MICROEDITION_PROFILES_PROPERTY) == null) return false;
    if (emulatorProperties.getProperty(API_CLASS_PATH_PROPERTY) == null) return false;
    if (emulatorProperties.getProperty(EMULATOR_BINARY_PROPERTY) == null) return false;
    if (emulatorProperties.getProperty(PREVERIFIER_BINARY_PROPERTY) == null) return false;
    if (emulatorProperties.getProperty(KVEM_CLASS_PATH_PROPERTY) == null) return false;
    return true;
  }

  public EmulatorEditor getConfigurable(J2MERunConfiguration j2merc, ProjectJdk projectJdk) {
    return new EmulatorEditor(j2merc, null, projectJdk);
  }

  public J2MERunnableState getJ2MERunnableState(RunnerInfo runnerInfo,
                                                RunnerSettings runnerSettings,
                                                ConfigurationPerRunnerSettings configurationSetting,
                                                J2MERunConfiguration configuration,
                                                Project project,
                                                ProjectJdk projectJdk) {
    final String uei = RunUtil.getUEIExecutable(projectJdk.getHomePath());
    final boolean isSupportUEI = uei != null && !uei.equals("");
    if (isSupportUEI) {
      return new UEIRunnableState(runnerInfo,
                                  runnerSettings,
                                  configurationSetting,
                                  configuration,
                                  project,
                                  projectJdk);
    }
    else {
      return new NokiaRunnableState(runnerInfo,
                                    runnerSettings,
                                    configurationSetting,
                                    configuration,
                                    project,
                                    projectJdk);
    }
  }

  public String getComponentName() {
    return "NokiaEmulatorType";
  }

  public void initComponent() {}

  public void disposeComponent() {}
}
