/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.emulator;

import com.intellij.j2meplugin.run.RunUtil;
 import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.projectRoots.*;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMExternalizable;
import com.intellij.openapi.util.WriteExternalException;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * User: anna
 * Date: Sep 21, 2004
 */
public class Emulator implements SdkAdditionalData, JDOMExternalizable {

  @NonNls
  public static final String COMMANDS = "commands";
  @NonNls
  public static final String COMMAND = "command";
  @NonNls
  public static final String NAME = "name";

  private String[] myOTACommands;

  private EmulatorType myEmulatorType;
  private String myJavaSdkName;
  private String myHome;
  private String[] myPreverifyOptions;

  private String myProfile;
  private String myConfiguration;

  private String myCustomProfile;
  private String myCustomConfiguration;

  @NonNls
  private static final String JDK = "javaJDK";
  @NonNls
  private static final String JDK_NAME = "name";

  @NonNls
  private static final String EMULATOR_TYPE = "emulator";
  @NonNls
  private static final String EMULATOR_NAME = "name";
  @NonNls
  private static final String PROFILE = "profile";
  @NonNls
  private static final String CONFIGURATION = "configuration";
  @NonNls
  private static final String CUSTOM_PROFILE = "customProfile";
  @NonNls
  private static final String CUSTOM_CONFIGURATION = "customConfiguration";
  @NonNls
  private static final String PREVERIFY_OPTIONS = "preverify";
  @NonNls
  private static final String OPTION = "option";
  @NonNls
  private static final String OPTION_NAME = "name";


  public Emulator(EmulatorType emulatorType, String[] preverifyOptions, String javaSdk, String home) {
    myEmulatorType = emulatorType;
    myPreverifyOptions = preverifyOptions;
    myJavaSdkName = javaSdk;
    myHome = home;
  }

  //for external read
  public Emulator() {
  }

  public Object clone() throws CloneNotSupportedException {
    Emulator clone = new Emulator(myEmulatorType, myPreverifyOptions, myJavaSdkName, myHome);
    return clone;
  }

  public void checkValid(SdkModel sdkModel) throws ConfigurationException {
    if (getJavaSdk(sdkModel) == null){
      throw new ConfigurationException(J2MEBundle.message("jdk.already.removed", myJavaSdkName));
    }
  }

  public void readExternal(Element element) throws InvalidDataException {
    final Element jdk = element.getChild(JDK);
    if (jdk != null) {
      myJavaSdkName = jdk.getAttributeValue(JDK_NAME);
    }

    Element emulatorType = element.getChild(EMULATOR_TYPE);
    if (emulatorType != null) {
      final String name = emulatorType.getAttributeValue(EMULATOR_NAME);
      if (name != null) {
        myEmulatorType = EmulatorUtil.getEmulatorTypeByName(name);
      }
      myProfile = emulatorType.getAttributeValue(PROFILE);
      myConfiguration = emulatorType.getAttributeValue(CONFIGURATION);
      myCustomProfile = emulatorType.getAttributeValue(CUSTOM_PROFILE);
      myCustomConfiguration = emulatorType.getAttributeValue(CUSTOM_CONFIGURATION);
    }
    ArrayList<String> commands = new ArrayList<String>();
    Element otaCommands = element.getChild(COMMANDS);
    if (otaCommands != null) {
      for (Iterator<Element> iterator = otaCommands.getChildren(COMMAND).iterator(); iterator.hasNext();) {
        commands.add(iterator.next().getAttributeValue(NAME));
      }
      myOTACommands = commands.toArray(new String[commands.size()]);
    }
    ArrayList<String> options = new ArrayList<String>();
    Element preverifyOptions = element.getChild(PREVERIFY_OPTIONS);
    if (preverifyOptions != null) {
      for (Iterator<Element> iterator = preverifyOptions.getChildren(OPTION).iterator(); iterator.hasNext();) {
        options.add(iterator.next().getAttributeValue(OPTION_NAME));
      }
      myPreverifyOptions = options.toArray(new String[options.size()]);
    }
  }

  public void writeExternal(Element element) throws WriteExternalException {
    if (myJavaSdkName != null) {
      Element jdk = new Element(JDK);
      jdk.setAttribute(JDK_NAME, myJavaSdkName);
      element.addContent(jdk);
    }

    Element emulatorType = new Element(EMULATOR_TYPE);
    if (myEmulatorType != null) {
      emulatorType.setAttribute(EMULATOR_NAME, myEmulatorType.getName());
      if (myProfile != null) {
        emulatorType.setAttribute(PROFILE, myProfile);
      }
      if (myConfiguration != null) {
        emulatorType.setAttribute(CONFIGURATION, myConfiguration);
      }
      if (myCustomProfile != null) {
        emulatorType.setAttribute(CUSTOM_PROFILE, myCustomProfile);
      }
      if (myCustomConfiguration != null) {
        emulatorType.setAttribute(CUSTOM_CONFIGURATION, myCustomConfiguration);
      }
    }
    element.addContent(emulatorType);

    Element commands = new Element(COMMANDS);
    for (int i = 0; myOTACommands != null && i < myOTACommands.length; i++) {
      Element command = new Element(COMMAND);
      command.setAttribute(NAME, myOTACommands[i]);
      commands.addContent(command);
    }
    element.addContent(commands);

    Element options = new Element(PREVERIFY_OPTIONS);
    for (int i = 0; myPreverifyOptions != null && i < myPreverifyOptions.length; i++) {
      Element option = new Element(OPTION);
      option.setAttribute(OPTION_NAME, myPreverifyOptions[i]);
      options.addContent(option);
    }
    element.addContent(options);
  }


  public String[] getOTACommands(String home) {
    if (myOTACommands == null || myOTACommands.length == 0) {
      myOTACommands = getEmulatorType().getDefaultOTACommands();
      if (myOTACommands == null) {
        myOTACommands = RunUtil.getOTACommands(home);
      }
    }
    return myOTACommands;
  }

  public String getProfile() {
    return myProfile;
  }

  public String getConfiguration() {
    return myConfiguration;
  }

  public void setProfile(String profile) {
    myProfile = profile;
  }

  public void setConfiguration(String configuration) {
    myConfiguration = configuration;
  }

  public String[] getPreverifyOptions() {
    return myPreverifyOptions;
  }

  public String getCustomProfile() {
    return myCustomProfile;
  }

  public void setCustomProfile(String customProfile) {
    myCustomProfile = customProfile;
  }

  public String getCustomConfiguration() {
    return myCustomConfiguration;
  }

  public void setCustomConfiguration(String customConfiguration) {
    myCustomConfiguration = customConfiguration;
  }

  public String getHome() {
    return myHome;
  }

  public void setHome(String home) {
    myHome = home;
  }

  public void setPreverifyOptions(String[] preverifyOptions) {
    myPreverifyOptions = preverifyOptions;
  }

  public EmulatorType getEmulatorType() {
    return myEmulatorType;
  }

  public void setEmulatorType(EmulatorType emulatorType) {
    myEmulatorType = emulatorType;
  }

  public ProjectJdk getJavaSdk() {
    return ProjectJdkTable.getInstance().findJdk(myJavaSdkName);
  }

  public Sdk getJavaSdk(SdkModel sdkModel) {
    return sdkModel.findSdk(myJavaSdkName);
  }


  public String getJavaSdkName() {
    return myJavaSdkName;
  }

  public void setJavaSdk(String javaSdk) {
    myJavaSdkName = javaSdk;
  }

}
