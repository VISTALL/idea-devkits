/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.emulator.midp.siemens;

import org.jetbrains.annotations.NonNls;

import java.io.*;
import java.util.Properties;

/**
 * User: anna
 * Date: Oct 27, 2004
 */
public class ConfigurationUtil {
  @NonNls private static final String DEVICE_LIST_PROPERTY = "device.list";

  @SuppressWarnings({"HardCodedStringLiteral"})
  public static boolean isValidHomeDirectory(String home) {
    if (!new File(home).exists()) {
      return false;
    }
    if (new File(new File(home), "emulators").exists()) {
      return false;
    }
    if (new File(home).getParentFile() == null ||
        !new File(home).getParentFile().exists() ||
        new File(home).getParentFile().getParentFile() == null ||
        !new File(home).getParentFile().getParentFile().exists()){
      return false;
    }
    final String[] devices = getDevices(home);
    return getDescriptor(home) != null && devices != null && devices.length == 1;
  }

  public static String[] getDevices(String home) {
    final String devices = getProperties(home).getProperty(DEVICE_LIST_PROPERTY);
    if (devices != null) {
      return devices.split(", ");
    }
    return null;
  }

  public static String getSuggestedName(String home) {
    String[] devices = getDevices(home);
    if (devices == null || devices.length != 1) {
      return null;
    }
    return devices[0];
  }

  private static Properties getProperties(String home) {
    Properties properties = new Properties();
    File descriptor = getDescriptor(home);
    if (descriptor != null) {
      try {
        final InputStream is = new BufferedInputStream(new FileInputStream(descriptor));
        try {
          properties.load(is);
        }
        finally {
          is.close();
        }
      }
      catch (IOException e) {
      }
    }
    return properties;
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  private static File getDescriptor(String home) {
    final File binDirectory = new File(home.replace(File.separatorChar, '/') + "/bin");
    if (!binDirectory.isDirectory()) {
      return null;
    }
    File[] descriptions = binDirectory.listFiles(new FileFilter() {
      @SuppressWarnings({"HardCodedStringLiteral"})
      public boolean accept(File pathname) {
        if (pathname.getPath().endsWith("description.inf")) return true;
        return false;
      }
    });
    if (descriptions == null || descriptions.length != 1) {
      return null;
    }
    else {
      return descriptions[0];
    }
  }
}
