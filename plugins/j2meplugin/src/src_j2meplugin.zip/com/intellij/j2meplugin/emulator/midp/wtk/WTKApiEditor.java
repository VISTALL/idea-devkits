/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.emulator.midp.wtk;

import com.intellij.j2meplugin.emulator.Emulator;
import com.intellij.j2meplugin.emulator.MIDPEmulatorType;
import com.intellij.j2meplugin.emulator.MobileApiSettingsEditor;
import com.intellij.j2meplugin.emulator.MobileSdkUtil;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.projectRoots.ProjectRootType;
import com.intellij.openapi.projectRoots.Sdk;
import com.intellij.openapi.projectRoots.SdkModificator;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.vfs.VirtualFile;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

import org.jetbrains.annotations.NonNls;

/**
 * User: anna
 * Date: Dec 5, 2004
 */
public class WTKApiEditor extends MobileApiSettingsEditor {
  private JComboBox myProfile;
  private DefaultComboBoxModel myProfilesModel = new DefaultComboBoxModel();
  private JComboBox myConfiguration;
  private DefaultComboBoxModel myConfigurationsModel = new DefaultComboBoxModel();
  private JPanel myMIDPPanel;
  private JRadioButton myDefaultConfigs;
  private JRadioButton myCustomConfigs;
  private JLabel myDefaultProfile;
  private JLabel myDefaultConfig;

  private Sdk mySdk;
  private SdkModificator mySdkModificator;
  @NonNls private static final String PROFILES = "profiles";
  @NonNls private static final String CONFIGURATIONS = "configurations";

  public WTKApiEditor(Sdk sdk, SdkModificator sdkModificator) {
    mySdk = sdk;
    mySdkModificator = sdkModificator;
  }

  public JComponent createEditor() {
    myProfile.setModel(myProfilesModel);
    myConfiguration.setModel(myConfigurationsModel);
    ButtonGroup useConfigs = new ButtonGroup();
    useConfigs.add(myDefaultConfigs);
    useConfigs.add(myCustomConfigs);
    myDefaultConfigs.setSelected(true);

    //custom profiles choices
    myProfilesModel.removeAllElements();
    final String[] profiles = getExistSettings(mySdk.getHomePath(), PROFILES);
    for (int i = 0; profiles != null && i < profiles.length; i++) {
      myProfilesModel.addElement(profiles[i]);
    }
    //custom configurations choices
    myConfigurationsModel.removeAllElements();
    final String[] configurations = getExistSettings(mySdk.getHomePath(), CONFIGURATIONS);
    for (int i = 0; configurations != null && i < configurations.length; i++) {
      myConfigurationsModel.addElement(configurations[i]);
    }

    myDefaultConfigs.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (!myDefaultConfigs.isSelected()) return;
        doStateChanged(true);
        myModified = true;
      }
    });
    ActionListener changeRoots = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (!myCustomConfigs.isSelected()) return;
        doStateChanged(false);
        myModified = true;
      }
    };
    myCustomConfigs.addActionListener(changeRoots);
    myProfile.addActionListener(changeRoots);
    myConfiguration.addActionListener(changeRoots);
    return myMIDPPanel;
  }

  private void doStateChanged(boolean isDefault) {
    final VirtualFile[] jarsToRemove = getJarsToRemove();
    if (jarsToRemove != null) {
      for (int i = 0; i < jarsToRemove.length; i++) {
        mySdkModificator.removeRoot(jarsToRemove[i], ProjectRootType.CLASS);
      }
    }
    final VirtualFile[] jarsToAdd = getJarsToAdd(isDefault);
    if (jarsToAdd != null) {
      for (int i = 0; i < jarsToAdd.length; i++) {
        mySdkModificator.addRoot(jarsToAdd[i], ProjectRootType.CLASS);
      }
    }
  }

  public void disposeEditor() {
  }

  public void resetEditorFrom(Emulator emulator) {
    //from emulator settings
    final MIDPEmulatorType midpEmulatorType = ((MIDPEmulatorType)emulator.getEmulatorType());
    final String profile = midpEmulatorType.getProfile(emulator.getHome());
    myDefaultProfile.setText(profile);
    final String configuration = midpEmulatorType.getConfiguration(emulator.getHome());
    myDefaultConfig.setText(configuration);
    if ((Comparing.equal(profile, emulator.getProfile()) &&
         Comparing.equal(configuration, emulator.getConfiguration())) ||
                                                                      emulator.getProfile() == null ||
                                                                      emulator.getConfiguration() == null) {
      myDefaultConfigs.setSelected(true);
    }
    else {
      myCustomConfigs.setSelected(true);
    }
    myProfile.setSelectedItem(emulator.getCustomProfile());
    myConfiguration.setSelectedItem(emulator.getCustomConfiguration());
    myModified = false;
  }

  public void applyEditorTo(Emulator emulator) throws ConfigurationException {
    if (myCustomConfigs.isSelected()) {
      emulator.setProfile((String)myProfile.getSelectedItem());
      emulator.setConfiguration((String)myConfiguration.getSelectedItem());
    }
    else {
      emulator.setProfile(myDefaultProfile.getText());
      emulator.setConfiguration(myDefaultConfig.getText());
    }
    emulator.setCustomProfile((String)myProfile.getSelectedItem());
    emulator.setCustomConfiguration((String)myConfiguration.getSelectedItem());
    myModified = false;
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  private VirtualFile getJarBySettingName(String settingName, String homePath) {
    Properties apiSettings = ConfigurationUtil.getApiSettings(homePath);
    if (apiSettings == null || apiSettings.isEmpty()) {
      return null;
    }
    String jar = apiSettings.getProperty(settingName.replaceAll("-","") + ".file");//todo
    if (jar != null) {
      final VirtualFile[] apiClasses = MobileSdkUtil.findApiClasses(new String[]{homePath + File.separator + "lib" + File.separator + jar});
      if (apiClasses == null || apiClasses.length == 0) {
        return null;
      }
      return apiClasses[0];
    }
    return null;
  }

  private VirtualFile[] getJarsToRemove() {
    final String homePath = mySdk.getHomePath();
    ArrayList<VirtualFile> result = new ArrayList<VirtualFile>();
    for (int i = 0; i < myProfilesModel.getSize(); i++) {
      result.add(getJarBySettingName((String)myProfilesModel.getElementAt(i), homePath));
    }
    for (int i = 0; i < myConfigurationsModel.getSize(); i++) {
      result.add(getJarBySettingName((String)myConfigurationsModel.getElementAt(i), homePath));
    }
    result.addAll(Arrays.asList(getJarsToAdd(true)));
    return result.toArray(new VirtualFile[result.size()]);
  }

  private VirtualFile[] getJarsToAdd(boolean isDefault) {
    final String homePath = mySdk.getHomePath();
    if (isDefault) {
      return new VirtualFile[]{getJarBySettingName(myDefaultProfile.getText(), homePath),
          getJarBySettingName(myDefaultConfig.getText(), homePath)};
    }
    else {
      if (myProfile.getSelectedItem() == null || myConfiguration.getSelectedItem() == null) {
        return null;
      }
      return new VirtualFile[]{getJarBySettingName((String)myProfile.getSelectedItem(), homePath),
          getJarBySettingName((String)myConfiguration.getSelectedItem(), homePath)};
    }
  }

  //profiles, configurations
  @SuppressWarnings({"HardCodedStringLiteral"})
  private String[] getExistSettings(String homePath, String settingName) {
    Properties properties = ConfigurationUtil.getApiSettings(homePath);
    if (properties == null || properties.isEmpty()) {
      return null;
    }
    String profiles = properties.getProperty(settingName);
    if (profiles == null) {
      return null;
    }
    ArrayList<String> result = new ArrayList<String>();
    final String[] values = profiles.split("[, \n]");
    for (int i = 0; values != null && i < values.length; i++) {
      String value = values[i];
      final String stringInJad = properties.getProperty(value + ".jadValue");
      if (stringInJad != null && stringInJad.length() != 0){
        result.add(stringInJad.trim());
      }
    }
    return result.toArray(new String[result.size()]);
  }

}
