/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.emulator.doja;

import com.intellij.execution.configurations.ConfigurationPerRunnerSettings;
import com.intellij.execution.configurations.RunnerSettings;
import com.intellij.execution.runners.RunnerInfo;
import com.intellij.j2meplugin.emulator.EmulatorType;
import com.intellij.j2meplugin.module.type.doja.DOJAApplicationType;
import com.intellij.j2meplugin.run.J2MERunConfiguration;
import com.intellij.j2meplugin.run.J2MERunnableState;
import com.intellij.j2meplugin.run.emulator.doja.DOJARunnableState;
import com.intellij.j2meplugin.run.emulator.editors.EmulatorEditor;
import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.util.Pair;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import org.jetbrains.annotations.NonNls;

/**
 * User: anna
 * Date: Oct 1, 2004
 */
public class DOJAEmulatorType extends EmulatorType {
  @NonNls
  public static final String PREVERIFY_PATH = "bin/preverify";
  @NonNls
  public static final String EXE_PATH = "bin/doja_g";
  @NonNls
  public static final String NAME = "DoJa";
  @NonNls private static final String ABOUT_1_PROPERTY = "ABOUT_1";
  @NonNls private static final String MAIN_WINDOW_TITLE = "MAIN_WINDOW_TITLE";
  @NonNls private static final String LIB = "lib";

  @SuppressWarnings({"HardCodedStringLiteral"})
  public DOJAEmulatorType() {
    super(NAME, PREVERIFY_PATH, EXE_PATH, null, null, null, DOJAApplicationType.NAME, "-i",
          new Pair<String, String[]>("-s", null));
  }

  public String suggestName(String homePath) {
    return getProperties(homePath).getProperty(ABOUT_1_PROPERTY);
  }

  @SuppressWarnings({"HardCodedStringLiteral"})
  private Properties getProperties(String homePath) {
    File i18properties = new File(homePath + File.separator + LIB + File.separator + "i18n" + File.separator + "I18N.properties");
    Properties prop = new Properties();
    try {
      prop.load(new BufferedInputStream(new FileInputStream(i18properties)));
    }
    catch (IOException e) {
    }
    return prop;
  }

  public boolean isValidHomeDirectory(String homePath) {
    @NonNls String property = getProperties(homePath).getProperty(MAIN_WINDOW_TITLE);
    if (property == null) return false;
    return property.equals("iappliTool");
  }

  public EmulatorEditor getConfigurable(J2MERunConfiguration j2merc, ProjectJdk projectJdk) {
    return new EmulatorEditor(j2merc, getEmulatorSkins(projectJdk.getHomePath()), projectJdk);
  }

  public J2MERunnableState getJ2MERunnableState(RunnerInfo runnerInfo,
                                                RunnerSettings runnerSettings,
                                                ConfigurationPerRunnerSettings configurationSetting,
                                                J2MERunConfiguration configuration,
                                                Project project,
                                                ProjectJdk projectJdk) {
    return new DOJARunnableState(runnerInfo,
                                 runnerSettings,
                                 configurationSetting,
                                 configuration,
                                 project,
                                 projectJdk);
  }

  public String getComponentName() {
    return "DOJAEmulatorType";
  }

  public void initComponent() {}

  public void disposeComponent() {}

  private static String [] getEmulatorSkins(String homePath){
    @NonNls final String skin = "skin";
    File skins = new File(new File(homePath, LIB), skin);
    if (!skins.exists() || !skins.isDirectory()){
      return new String[]{J2MEBundle.message("run.configuration.doja.device1"), J2MEBundle.message("run.configuration.doja.device2"), J2MEBundle.message("run.configuration.doja.device3")};
    }
    final String[] strings = skins.list();
    ArrayList<String> devices = new ArrayList<String>();
    for (int i = 0; i < strings.length; i++) {
      String device = strings[i];
      if (new File(skins, device).isDirectory()){
        devices.add(device);
      }
    }
    return devices.toArray(new String[devices.size()]);
  }
}
