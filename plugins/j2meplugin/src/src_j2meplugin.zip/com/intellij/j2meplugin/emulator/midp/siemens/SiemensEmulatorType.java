/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.emulator.midp.siemens;

import com.intellij.execution.configurations.ConfigurationPerRunnerSettings;
import com.intellij.execution.configurations.RunnerSettings;
import com.intellij.execution.runners.RunnerInfo;
import com.intellij.j2meplugin.emulator.EmulatorType;
import com.intellij.j2meplugin.emulator.MIDPEmulatorType;
import com.intellij.j2meplugin.emulator.MobileApiSettingsEditor;
import com.intellij.j2meplugin.emulator.MobileDefaultApiEditor;
import com.intellij.j2meplugin.module.type.midp.MIDPApplicationType;
import com.intellij.j2meplugin.run.J2MERunConfiguration;
import com.intellij.j2meplugin.run.J2MERunnableState;
import com.intellij.j2meplugin.run.RunUtil;
import com.intellij.j2meplugin.run.emulator.editors.EmulatorEditor;
import com.intellij.j2meplugin.run.emulator.midp.wtk.UEIRunnableState;
import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.projectRoots.Sdk;
import com.intellij.openapi.projectRoots.SdkModificator;
import com.intellij.openapi.util.Pair;

import java.io.File;

/**
 * User: anna
 * Date: Oct 26, 2004
 */
public class SiemensEmulatorType extends EmulatorType implements MIDPEmulatorType {

  public static final String NAME = J2MEBundle.message("emulator.siemens.edition");

  @SuppressWarnings({"HardCodedStringLiteral"})
  public SiemensEmulatorType() {
    super(NAME, PREVERIFY_PATH, EXE_PATH, null, null, null, MIDPApplicationType.NAME, DESCRIPTOR,
          new Pair<String, String[]>("-Xdevice:", null));
  }

  public String getPreverifyPath(String home) {
    //preverify available only from SMTK
    String SMTK = new File(home).getParentFile().getParent();
    return toSystemDependentPath(SMTK, PREVERIFY_PATH);
  }

  public String getPrefPath(String home) {
    //preverify available only from SMTK
    String SMTK = new File(home).getParentFile().getParent();
    return toSystemDependentPath(SMTK, PREF_PATH);
  }

  public String getName() {
    return NAME;
  }

  public String getProfile(String homePath) {
    return "CLDC-1.0";
  }

  public String getConfiguration(String homePath) {
    return "MIDP-1.0";
  }

  public MobileApiSettingsEditor getApiEditor(final String homePath, Sdk sdk, SdkModificator sdkModificator) {
    return new MobileDefaultApiEditor();
  }

  public String[] getDefaultOTACommands() {
    return new String[]{RunUtil.INSTALL, RunUtil.FORCE, RunUtil.RUN, RunUtil.REMOVE, RunUtil.TRANSIENT, RunUtil.STORAGE_NAMES};
  }


  public String suggestName(String homePath) {
    return ConfigurationUtil.getSuggestedName(homePath);
  }

  public boolean isValidHomeDirectory(String homePath) {
    return ConfigurationUtil.isValidHomeDirectory(homePath);
  }

  public EmulatorEditor getConfigurable(J2MERunConfiguration j2merc, ProjectJdk projectJdk) {
    return new EmulatorEditor(j2merc, ConfigurationUtil.getDevices(projectJdk.getHomePath()), projectJdk);
  }

  public J2MERunnableState getJ2MERunnableState(RunnerInfo runnerInfo,
                                                RunnerSettings runnerSettings,
                                                ConfigurationPerRunnerSettings configurationSetting,
                                                J2MERunConfiguration configuration,
                                                Project project,
                                                ProjectJdk projectJdk) {
    return new UEIRunnableState(runnerInfo, runnerSettings, configurationSetting, configuration, project, projectJdk);
  }

  public String getComponentName() {
    return "SiemensEmulatorType";
  }

  public void initComponent() {}

  public void disposeComponent() {}
}
