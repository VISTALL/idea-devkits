/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.emulator;

import com.intellij.execution.configurations.ConfigurationPerRunnerSettings;
import com.intellij.execution.configurations.RunnerSettings;
import com.intellij.execution.runners.RunnerInfo;
import com.intellij.j2meplugin.run.J2MERunConfiguration;
import com.intellij.j2meplugin.run.J2MERunnableState;
import com.intellij.j2meplugin.run.emulator.editors.EmulatorEditor;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.extensions.PluginAware;
import com.intellij.openapi.extensions.PluginDescriptor;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.util.Pair;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NonNls;

import java.io.File;

/**
 * User: anna
 * Date: Aug 30, 2004
 */
public abstract class EmulatorType implements ApplicationComponent, PluginAware{
  //uei settings
  @NonNls
  public static final String PREVERIFY_PATH = "bin/preverify";
  @NonNls
  public static final String EXE_PATH = "bin/emulator";
  @NonNls
  public static final String DESCRIPTOR = "-Xdescriptor:";
  @NonNls
  public static final String PREF_PATH = "bin/prefs";

  private String myName;
  private String myPreverifyPath;
  private String myExePath;
  private String myKVEMPath;
  private String myPrefPath;
  private String myUtilPath;
  private String myApplicationType;
  private String myDescriptorOption;
  private Pair<String, String[]> myDeviceOption;

  private PluginDescriptor myPluginDescriptor;

  protected EmulatorType(@NonNls String name,
                         @NonNls String preverifyPath,
                         @NonNls String exePath,
                         @NonNls String kvemPath,
                         @NonNls String prefPath,
                         @NonNls String utilPath,
                         @NonNls String applicationType,
                         @NonNls String descriptorOption,
                         Pair<String, String[]> deviceOption) {
    myName = name;
    myPreverifyPath = preverifyPath;
    myExePath = exePath;
    myKVEMPath = kvemPath;
    myPrefPath = prefPath;
    myUtilPath = utilPath;
    myApplicationType = applicationType;
    myDescriptorOption = descriptorOption;
    myDeviceOption = deviceOption;
  }

  public void setPluginDescriptor(PluginDescriptor pluginDescriptor) {
    myPluginDescriptor = pluginDescriptor;
  }

  public PluginDescriptor getPluginDescriptor() {
    return myPluginDescriptor;
  }

  protected static String toSystemDependentPath(String home, String path) {
    if (path == null) return null;
    return (home + "/" + path).replace('/', File.separatorChar);
  }

  @Nullable
  public String getPrefPath(String home) {
    return toSystemDependentPath(home, myPrefPath);
  }


  protected String getFullPath(String home, @NotNull String toSplit) {
    String[] api = toSplit.split(";");
    String result = "";
    for (int i = 0; api != null && i < api.length; i++) {
      result += home + File.separator + api[i] + File.pathSeparator;
    }
    return result.replace(File.separatorChar, '/');
  }


  public String getKvemPath(String home) {
    return getFullPath(home, myKVEMPath);
  }

  @Nullable
  public String getUtilPath(String home) {
    return toSystemDependentPath(home, myUtilPath);
  }

  public String getName() {
    return myName;
  }

  public String getPreverifyPath(String home) {
    return toSystemDependentPath(home, myPreverifyPath);
  }

  public String getExePath(String home) {
    return toSystemDependentPath(home, myExePath);
  }

  public String getApplicationType() {
    return myApplicationType;
  }

  public void setApplicationType(String applicationType) {
    myApplicationType = applicationType;
  }

  public void setName(String name) {
    this.myName = name;
  }

  public void setPreverifyPath(String preverifyPath) {
    this.myPreverifyPath = preverifyPath;
  }

  public void setExePath(String exePath) {
    this.myExePath = exePath;
  }

  public void setKVEMPath(String KVEMPath) {
    this.myKVEMPath = KVEMPath;
  }

  public void setPrefPath(String prefPath) {
    this.myPrefPath = prefPath;
  }

  public void setUtilPath(String utilPath) {
    this.myUtilPath = utilPath;
  }

  public String getDescriptorOption() {
    return myDescriptorOption;
  }

  public void setDescriptorOption(String descriptorOption) {
    myDescriptorOption = descriptorOption;
  }

  public Pair<String, String[]> getDeviceOption() {
    return myDeviceOption;
  }

  public void setDeviceOption(Pair<String, String[]> deviceOption) {
    myDeviceOption = deviceOption;
  }


  @Nullable
  public String[] getDefaultOTACommands() {
    return null;
  }

  @Nullable
  public String[] getApi(String homePath) {
    return null;
  }

  public String getWorkingDirectory(String homePath){
    return homePath;
  }

  public abstract String suggestName(String homePath);

  public abstract boolean isValidHomeDirectory(String homePath);

  public abstract EmulatorEditor getConfigurable(J2MERunConfiguration j2merc, ProjectJdk projectJdk);

  public abstract J2MERunnableState getJ2MERunnableState(RunnerInfo runnerInfo,
                                                         RunnerSettings runnerSettings,
                                                         ConfigurationPerRunnerSettings configurationSetting,
                                                         J2MERunConfiguration configuration,
                                                         Project project,
                                                         ProjectJdk projectJdk);


}
