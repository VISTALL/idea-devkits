/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.emulator;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.extensions.Extensions;
import com.intellij.openapi.projectRoots.JavaSdk;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.projectRoots.ProjectJdkTable;
import com.intellij.openapi.util.Comparing;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NonNls;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * User: anna
 * Date: Oct 1, 2004
 */
public class EmulatorUtil {
  public static EmulatorType getEmulatorTypeByName(String name) {
    EmulatorType[] knownEmulatorTypes = getKnownEmulatorTypes();
    for (int i = 0; knownEmulatorTypes != null && i < knownEmulatorTypes.length; i++) {
      if (knownEmulatorTypes[i].getName().equals(name)) return knownEmulatorTypes[i];
    }
    return null;
  }

  public static EmulatorType getEmulatorTypeByHomePath(String home){
     EmulatorType[] knownEmulatorTypes = getKnownEmulatorTypes();
    for (int i = 0; knownEmulatorTypes != null && i < knownEmulatorTypes.length; i++) {
      if (knownEmulatorTypes[i].isValidHomeDirectory(home)) return knownEmulatorTypes[i];
    }
    return null;
  }

  public static EmulatorType[] getKnownEmulatorTypes(){
    final EmulatorType[] knownEmulatorTypes = ApplicationManager.getApplication().getComponents(EmulatorType.class);
    List<EmulatorType> result = new ArrayList<EmulatorType>();
    result.addAll(Arrays.asList(knownEmulatorTypes));
    @NonNls final String extensionPointName = "J2ME.emulatorType";
    final Object[] extendedTypes = Extensions.getRootArea().getExtensionPoint(extensionPointName).getExtensions();
    for (Object o : extendedTypes) {
      result.add((EmulatorType)o);
    }
    return result.toArray(new EmulatorType[result.size()]);
  }

  @Nullable
  public static ProjectJdk findFirstJavaSdk(){
    ProjectJdkTable table = ProjectJdkTable.getInstance();
    final ProjectJdk[] allJdks = table.getAllJdks();
    for (ProjectJdk jdk : allJdks) {
      if (Comparing.equal(jdk.getSdkType(), JavaSdk.getInstance())){
        return jdk;
      }
    }
    return null;
  }
}
