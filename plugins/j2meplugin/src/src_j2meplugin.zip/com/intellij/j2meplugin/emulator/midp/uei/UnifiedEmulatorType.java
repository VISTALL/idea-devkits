/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.emulator.midp.uei;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.configurations.ConfigurationPerRunnerSettings;
import com.intellij.execution.configurations.GeneralCommandLine;
import com.intellij.execution.configurations.RunnerSettings;
import com.intellij.execution.process.OSProcessHandler;
import com.intellij.execution.process.ProcessAdapter;
import com.intellij.execution.process.ProcessEvent;
import com.intellij.execution.runners.RunnerInfo;
import com.intellij.j2meplugin.emulator.EmulatorType;
import com.intellij.j2meplugin.emulator.MIDPEmulatorType;
import com.intellij.j2meplugin.emulator.MobileApiSettingsEditor;
import com.intellij.j2meplugin.emulator.MobileDefaultApiEditor;
import com.intellij.j2meplugin.module.type.midp.MIDPApplicationType;
import com.intellij.j2meplugin.run.J2MERunConfiguration;
import com.intellij.j2meplugin.run.J2MERunnableState;
import com.intellij.j2meplugin.run.RunUtil;
import com.intellij.j2meplugin.run.emulator.editors.EmulatorEditor;
import com.intellij.j2meplugin.run.emulator.midp.wtk.UEIRunnableState;
import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.projectRoots.Sdk;
import com.intellij.openapi.projectRoots.SdkModificator;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.Pair;
import org.apache.tools.ant.filters.StringInputStream;
import org.jetbrains.annotations.NonNls;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

/**
 * User: anna
 * Date: Nov 14, 2004
 */
public class UnifiedEmulatorType extends EmulatorType implements MIDPEmulatorType {
  private static final Logger LOG = Logger.getInstance("#com.intellij.j2meplugin");
  private ArrayList<String> mySuggestName = new ArrayList<String>();
  private String myProfile;
  private String myConfiguration;
  private String mySuggestedName;
  private static String HELP;

  @SuppressWarnings({"HardCodedStringLiteral"})
  public UnifiedEmulatorType() {
    super("Unified Emulator Type", PREVERIFY_PATH, EXE_PATH, null, null, null, MIDPApplicationType.NAME, DESCRIPTOR,
          new Pair<String, String[]>("-Xdevice:", null));
  }

  public String suggestName(String homePath) {
    if (mySuggestedName == null || mySuggestedName.length() == 0) {
      fillEmulatorConfigurations(homePath);
    }
    return mySuggestedName;
  }

  public boolean isValidHomeDirectory(String homePath) {
    return fillEmulatorConfigurations(homePath);
  }

  public J2MERunnableState getJ2MERunnableState(RunnerInfo runnerInfo,
                                                RunnerSettings runnerSettings,
                                                ConfigurationPerRunnerSettings configurationSetting,
                                                J2MERunConfiguration configuration,
                                                Project project,
                                                ProjectJdk projectJdk) {
    return new UEIRunnableState(runnerInfo,
                                runnerSettings,
                                configurationSetting,
                                configuration,
                                project,
                                projectJdk);
  }

  public String getComponentName() {
    return "UnifiedEmulatorType";
  }

  public void initComponent() {}

  public void disposeComponent() {}

  public String getProfile(String home) {
    if (myProfile == null || myProfile.length() == 0) {
      fillEmulatorConfigurations(home);
    }
    return myProfile;
  }

  public String getConfiguration(String home) {
    if (myConfiguration == null || myConfiguration.length() == 0) {
      fillEmulatorConfigurations(home);
    }
    return myConfiguration;
  }

  public MobileApiSettingsEditor getApiEditor(final String homePath, Sdk sdk, SdkModificator sdkModificator) {
    return new MobileDefaultApiEditor();
  }

  public EmulatorEditor getConfigurable(J2MERunConfiguration j2merc, ProjectJdk projectJdk) {
    return new EmulatorEditor(j2merc, fillEmulatorDevices(projectJdk.getHomePath()), projectJdk);
  }

  private static ArrayList<String> myVersion = new ArrayList<String>();

  private boolean fillEmulatorConfigurations(String home) {
    myVersion.clear();
    String exe = RunUtil.getUEIExecutable(home);
    if (exe != null && exe.length() != 0) {
      GeneralCommandLine generalCommandLine = new GeneralCommandLine();
      generalCommandLine.setWorkDirectory(null);
      generalCommandLine.setExePath(exe);
      @NonNls final String version = "-version";
      generalCommandLine.addParameter(version);
      try {
        OSProcessHandler osProcessHandler = new OSProcessHandler(generalCommandLine.createProcess(),
                                                                 generalCommandLine.getCommandLineString());
        osProcessHandler.addProcessListener(new ProcessAdapter() {
          public void onTextAvailable(ProcessEvent event, Key outputType) {
            myVersion.add(event.getText().trim());
          }
        });
        osProcessHandler.startNotify();
        osProcessHandler.waitFor();
        osProcessHandler.destroyProcess();
      }
      catch (ExecutionException e) {
        LOG.error(e);
      }
      if (myVersion == null || myVersion.size() != 4) {
        return false;
      }
      else {
        mySuggestedName = myVersion.get(1);
        if (!myVersion.get(2).startsWith(J2MEBundle.message("emulator.reply.profile"))) {
          return false;
        }
        myProfile = myVersion.get(2).substring(myVersion.get(2).indexOf(":") + 1);

        if (!myVersion.get(3).startsWith(J2MEBundle.message("emulator.reply.configuration"))) {
          return false;
        }
        myConfiguration = myVersion.get(3).substring(myVersion.get(3).indexOf(":") + 1);
        return true;
      }
    }
    return false;
  }

  private String[] fillEmulatorDevices(String home) {
    HELP = "";
    String exe = RunUtil.getUEIExecutable(home);
    if (exe != null && exe.length() > 0) {
      GeneralCommandLine generalCommandLine = new GeneralCommandLine();
      generalCommandLine.setWorkDirectory(null);
      generalCommandLine.setExePath(exe);
      @NonNls final String query = "-Xquery";
      generalCommandLine.addParameter(query);
      try {
        OSProcessHandler osProcessHandler = new OSProcessHandler(generalCommandLine.createProcess(),
                                                                 generalCommandLine.getCommandLineString());
        osProcessHandler.addProcessListener(new ProcessAdapter() {
          public void onTextAvailable(ProcessEvent event, Key outputType) {
            HELP += event.getText();
          }
        });
        osProcessHandler.startNotify();
        osProcessHandler.waitFor();
        osProcessHandler.destroyProcess();
      }
      catch (ExecutionException e) {
        LOG.error(e);
      }
      Properties properties = new Properties();
      try {
        properties.load(new StringInputStream(HELP));
        @NonNls final String key = "device.list";
        final String devices = properties.getProperty(key);
        if (devices != null) {
          return devices.split(", ");
        }
        else {
          return null;
        }
      }
      catch (IOException e) {
        LOG.error(e);
      }
    }
    return null;
  }

}
