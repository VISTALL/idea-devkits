package com.intellij.j2meplugin.i18n;

import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMExternalizable;
import com.intellij.openapi.util.WriteExternalException;
import com.intellij.psi.PsiClass;
import org.jdom.Element;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

public class ResourceBeansContainer implements ProjectComponent, JDOMExternalizable {
  private ResourceBundlesBean myBean;

  public static ResourceBeansContainer getInstance(Project project) {
    return project.getComponent(ResourceBeansContainer.class);
  }

  public ResourceBeansContainer(final Project project) {
    myBean = new ResourceBundlesBean(project);
  }

  public ResourceBundlesBean getBean() {
    return myBean;
  }

  public void projectOpened() {}

  public void projectClosed() {}

  @NonNls
  @NotNull
  public String getComponentName() {
    return "ResourceManagerContainer";
  }

  public void initComponent() {}

  public void disposeComponent() {}

  public void readExternal(Element element) throws InvalidDataException {
    myBean.readExternal(element);
  }

  public void writeExternal(Element element) throws WriteExternalException {
    myBean.writeExternal(element);
  }

  public void registerResourceBundle(final PsiClass aClass) {
    myBean.registerResourceBundle(aClass);
  }

  public PsiClass getResourceBundle() {
    return myBean.getResourceBundle();
  }
}