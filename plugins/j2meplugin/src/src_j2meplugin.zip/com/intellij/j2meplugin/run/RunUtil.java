/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.run;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.configurations.GeneralCommandLine;
import com.intellij.execution.process.OSProcessHandler;
import com.intellij.execution.process.ProcessAdapter;
import com.intellij.execution.process.ProcessEvent;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NonNls;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;

/**
 * User: anna
 * Date: Nov 5, 2004
 */
public class RunUtil {
  @NonNls
  public static final String INSTALL = "install";
  @NonNls
  public static final String FORCE = "force";
  @NonNls
  public static final String RUN = "run";
  @NonNls
  public static final String REMOVE = "remove";
  @NonNls
  public static final String TRANSIENT = "transient";
  @NonNls
  public static final String STORAGE_NAMES = "storageNames";

  @NonNls private static String HELP;
  private static final Logger LOG = Logger.getInstance("#com.intellij.j2meplugin");

  public static String[] getOTACommands(String homeDir) {
    HELP = "";
    String exe = getUEIExecutable(homeDir);
    if (exe != null && !exe.equals("")) {
      GeneralCommandLine generalCommandLine = new GeneralCommandLine();
      generalCommandLine.setWorkDirectory(null);
      generalCommandLine.setExePath(exe);
      generalCommandLine.addParameter("-help");
      try {
        OSProcessHandler osProcessHandler = new OSProcessHandler(generalCommandLine.createProcess(),
                                                                 generalCommandLine.getCommandLineString());
        osProcessHandler.addProcessListener(new ProcessAdapter() {
          public void onTextAvailable(ProcessEvent event, Key outputType) {
            HELP += event.getText();
          }
        });
        osProcessHandler.startNotify();
        osProcessHandler.waitFor();
        osProcessHandler.destroyProcess();
      }
      catch (ExecutionException e) {
        LOG.error(e);
      }
      if (HELP.equals("") || HELP.indexOf("-Xjam") == -1) return null;
      HELP = HELP.substring(HELP.indexOf("-Xjam") + "-Xjam".length());
      final int endIndex = HELP.indexOf("-X");
      if (endIndex > -1) {
        HELP = HELP.substring(0, endIndex);
      }
      ArrayList<String> result = new ArrayList<String>();
      if (HELP.indexOf(INSTALL) > -1) result.add(INSTALL);
      if (HELP.indexOf(FORCE) > -1) result.add(FORCE);
      if (HELP.indexOf(RUN) > -1) result.add(RUN);
      if (HELP.indexOf(REMOVE) > -1) result.add(REMOVE);
      if (HELP.indexOf(TRANSIENT) > -1) result.add(TRANSIENT);
      if (HELP.indexOf(STORAGE_NAMES) > -1) result.add(STORAGE_NAMES);
      return result.toArray(new String[result.size()]);

    }
    return null;
  }

  public static String getUEIExecutable(String home) {
    HELP = "";
    @NonNls final String emulator = "emulator";
    @NonNls final String binDirName = "bin";
    final File bin = new File(home + File.separatorChar + binDirName);
    if (!bin.exists() || !bin.isDirectory()) return null;
    String[] emulators = bin.list(new FilenameFilter() {
      public boolean accept(File dir, String name) {
        if (StringUtil.startsWithIgnoreCase(name, emulator)) return true;
        return false;
      }
    });
    if (emulators == null || emulators.length < 1) return null;
    return bin.getPath() + File.separatorChar + emulator;

  }
}
