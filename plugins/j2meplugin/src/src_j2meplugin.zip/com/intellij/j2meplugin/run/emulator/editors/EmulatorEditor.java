/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.run.emulator.editors;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.configurations.GeneralCommandLine;
import com.intellij.execution.process.OSProcessHandler;
import com.intellij.j2meplugin.emulator.Emulator;
import com.intellij.j2meplugin.emulator.EmulatorType;
import com.intellij.j2meplugin.emulator.MobileSdk;
import com.intellij.j2meplugin.run.J2MERunConfiguration;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.options.UnnamedConfigurable;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.util.Pair;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

/**
 * User: anna
 * Date: Oct 17, 2004
 */
public class EmulatorEditor implements UnnamedConfigurable {
  private JPanel myDeviceOptionsPanel;
  private JButton myPreferencesButton;
  private DefaultComboBoxModel myDevicesList = new DefaultComboBoxModel();
  private JComboBox myDevices;
  private JLabel myDeviceOption;
  private JButton myUtilButton;
  private JPanel myDevicesPanel;
  private boolean myModified = false;
  private ProjectJdk myProjectJdk;
  private J2MERunConfiguration myConfiguration;
  private String[] myDeviceNames;

  public EmulatorEditor(J2MERunConfiguration j2merc, String[] devices, ProjectJdk projectJdk) {
    myConfiguration = j2merc;
    myProjectJdk = projectJdk;
    myDeviceNames = devices;
    if (!MobileSdk.checkCorrectness(myProjectJdk, myConfiguration.getModule())) return;
    final EmulatorType emulatorType = ((Emulator)myProjectJdk.getSdkAdditionalData()).getEmulatorType();

    myPreferencesButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        final String prefPath = emulatorType.getPrefPath(myProjectJdk.getHomePath());
        GeneralCommandLine generalCommandLine = new GeneralCommandLine();
        generalCommandLine.setExePath(prefPath);
        generalCommandLine.setWorkDirectory(myProjectJdk.getHomePath() + File.separator + "bin");    //todo
        try {
          OSProcessHandler osProcessHandler = new OSProcessHandler(generalCommandLine.createProcess(),
                                                                   generalCommandLine.getCommandLineString());
          osProcessHandler.startNotify();
          osProcessHandler.waitFor();
        }
        catch (ExecutionException e1) {
        }

      }
    });

    myUtilButton.addActionListener(new ActionListener() {  // todo may be remove to other place
      public void actionPerformed(ActionEvent e) {
        final String utilPath = emulatorType.getUtilPath(myProjectJdk.getHomePath());

        GeneralCommandLine generalCommandLine = new GeneralCommandLine();
        generalCommandLine.setExePath(utilPath);
        try {
          OSProcessHandler osProcessHandler = new OSProcessHandler(generalCommandLine.createProcess(),
                                                                   generalCommandLine.getCommandLineString());
          osProcessHandler.startNotify();
          osProcessHandler.waitFor();
        }
        catch (ExecutionException e1) {
        }

      }
    });

  }

  public boolean isVisible() {
    return myDevicesPanel.isVisible() ||
           myPreferencesButton.isVisible() ||
           myUtilButton.isVisible();
  }

  public JComponent createComponent() {
    if (myDeviceNames != null) {
      myDevicesPanel.setVisible(true);
      myDevicesList.removeAllElements();
      for (int i = 0; i < myDeviceNames.length; i++) {
        myDevicesList.addElement(myDeviceNames[i]);
      }
      //if not set -> get default value
      //myDevices.setSelectedItem(myDevicesList.getSize() > 0 ? myDevicesList.getElementAt(0) : null);
      myDevices.setModel(myDevicesList);
      myDevices.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          myModified = true;
        }
      });
    }
    else {
      myDevicesPanel.setVisible(false);
    }
    final EmulatorType emulatorType = ((Emulator)myProjectJdk.getSdkAdditionalData()).getEmulatorType();
    if (emulatorType.getPrefPath(myProjectJdk.getHomePath()) == null) {
      myPreferencesButton.setVisible(false);
    }
    if (emulatorType.getUtilPath(myProjectJdk.getHomePath()) == null) {
      myUtilButton.setVisible(false);
    }
    return myDeviceOptionsPanel;
  }

  public boolean isModified() {
    return myModified;
  }

  public void apply() throws ConfigurationException {
    if (myDevicesPanel.isVisible()) {
      final EmulatorType emulatorType = ((Emulator)myProjectJdk.getSdkAdditionalData()).getEmulatorType();
      /*DeviceSpecificOption device = emulatorType.getDeviceSpecificOptions().get(EmulatorType.DEVICE);
      myConfiguration.addDeviceOption(device, (String)myDevices.getSelectedItem());*/
      myConfiguration.TARGET_DEVICE_NAME = (String)myDevices.getSelectedItem();
    }
    myModified = false;
  }

  public void reset() {
    final EmulatorType emulatorType = ((Emulator)myProjectJdk.getSdkAdditionalData()).getEmulatorType();
    final Pair<String, String[]> device = emulatorType.getDeviceOption();
    if (device != null) {
      myDevicesPanel.setVisible(true);
      myDevices.setSelectedItem(myConfiguration.TARGET_DEVICE_NAME);
    }
    else {
      myDevicesPanel.setVisible(false);
    }
    myModified = false;
  }

  public void disposeUIResources() {}
}
