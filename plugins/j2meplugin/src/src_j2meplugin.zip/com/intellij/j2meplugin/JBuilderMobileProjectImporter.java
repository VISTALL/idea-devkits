/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin;

import com.intellij.j2meplugin.emulator.Emulator;
import com.intellij.j2meplugin.emulator.EmulatorUtil;
import com.intellij.j2meplugin.emulator.MobileSdk;
import com.intellij.j2meplugin.module.J2MEModuleBuilder;
import com.intellij.j2meplugin.module.settings.MobileApplicationType;
import com.intellij.j2meplugin.module.settings.MobileModuleSettings;
import com.intellij.j2meplugin.module.settings.doja.DOJAApplicationType;
import com.intellij.j2meplugin.module.settings.doja.DOJASettings;
import com.intellij.j2meplugin.module.settings.general.UserDefinedOption;
import com.intellij.j2meplugin.module.settings.midp.MIDPApplicationType;
import com.intellij.j2meplugin.module.settings.midp.MIDPSettings;
import com.intellij.openapi.module.ModifiableModuleModel;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleWithNameAlreadyExists;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.project.impl.importProject.jbuilder.JBuilderProjectSettings;
import com.intellij.openapi.projectRoots.JavaSdk;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.projectRoots.ProjectJdkTable;
import com.intellij.openapi.projectRoots.SdkAdditionalData;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.JDOMUtil;
import com.intellij.util.projectImport.JBuilderLibraryImportHelper;
import com.intellij.util.projectImport.JBuilderProjectImportHelper;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.*;
import java.util.List;
import java.util.Properties;

/**
 * User: anna
 * Date: May 23, 2005
 */
@SuppressWarnings({"HardCodedStringLiteral"})
public class JBuilderMobileProjectImporter extends JBuilderProjectImportHelper {
  //to process sdk types available via plugins
    @Nullable public SdkAdditionalData additionalJDKDataProcessing(ProjectJdk jdk, File jdkFile) {
    if (!jdk.getSdkType().equals(MobileSdk.getInstance())){
      return null;
    }
    try {
      final Element root = JDOMUtil.loadDocument(jdkFile).getRootElement();
      final Element additionalSettings = root.getChild("customJDK");
      final Element category = additionalSettings.getChild("category");
      if (category == null || category.getAttributeValue("name") == null || !category.getAttributeValue("name").equals("micro")){
        return null;
      }
      Emulator emulator = new Emulator();
      final List properties = category.getChildren("property");
      final String jbuilderSuffix = J2MEBundle.message("jbuilder");
      for (Object o : properties) {
        Element element = (Element)o;
        final String name = element.getAttributeValue("name");
        final String value = element.getTextNormalize();
        if (name.equals("micro_profile")){
          emulator.setProfile(value);
        } else if (name.equals("micro_configuration")){
          emulator.setConfiguration(value);
        } else if (name.equals("preverify_option")){
          emulator.setPreverifyOptions(value.split("[ ;]"));
        } else if (name.equals("emulator_jdk")){
          JBuilderLibraryImportHelper.getInstance().findJdkByName(value, jdkFile.getParentFile());
          emulator.setJavaSdk(value + jbuilderSuffix);
        }
      }
      if (emulator.getJavaSdkName() == null){
        final ProjectJdkTable jdkTable = ProjectJdkTable.getInstance();
        final ProjectJdk[] allJdks = jdkTable.getAllJdks();
        for (ProjectJdk projectJdk : allJdks) {
          if (projectJdk.getSdkType().equals(JavaSdk.getInstance())){
            emulator.setJavaSdk(projectJdk.getName());
            break;
          }
        }
        if (emulator.getJavaSdkName() == null){
          final ProjectJdk createdJDK = JavaSdk.getInstance().createJdk(jbuilderSuffix, System.getProperty("java.home"));
          jdkTable.addJdk(createdJDK);
          emulator.setJavaSdk(jbuilderSuffix);
        }
      }
      emulator.setEmulatorType(EmulatorUtil.getValidEmulatorType(jdk.getHomePath()));
      emulator.setHome(jdk.getHomePath());
      return emulator;
    }
    catch (JDOMException e) {
      return null;
    }
    catch (IOException e) {
      return null;
    }

  }

   //settings are loaded from jad/jam files
    @Nullable public Module additionalModuleTypeProcessing(Element moduleElement,
                                                           final ModifiableModuleModel moduleModel,
                                                           final Module dependOn,
                                                           final JBuilderProjectSettings projectSettings)
                                                                                  throws InvalidDataException, ConfigurationException, IOException, ModuleWithNameAlreadyExists, JDOMException {
    if (moduleElement == null || moduleElement.getAttributeValue("type") == null || !moduleElement.getAttributeValue("type").equals("MicroArchive")){
      return null;
    }

    final File[] files = new File(projectSettings.getProjectLocation()).listFiles(new FilenameFilter() {
      public boolean accept(File dir, String name) {
        if (name.endsWith(".jad") || name.endsWith(".jam")) return true;
        return false;
      }
    });
    J2MEModuleBuilder builder = new J2MEModuleBuilder();
    MobileApplicationType mobileApplicationType = MIDPApplicationType.getInstance();
    MobileModuleSettings settings = new MIDPSettings();
    if (files != null && files.length > 0){
      if (!files[0].getName().endsWith(".jad")){
        mobileApplicationType = DOJAApplicationType.getInstance();
        settings = new DOJASettings();
      }
      settings.initSettings(builder);
      Properties properties = new Properties();
      final InputStream is = new BufferedInputStream(new FileInputStream(files[0]));
      try {
        properties.load(is);
        settings.getSettings().clear();
        settings.getUserDefinedOptions().clear();
        for (final Object o : properties.keySet()) {
          String key = (String)o;
          if (settings.getApplicationType().isUserField(key)) {
            settings.getUserDefinedOptions().add(new UserDefinedOption(key, properties.getProperty(key)));
          }
          else {
            settings.getSettings().put(key, properties.getProperty(key));
          }
        }
      }
      finally {
        is.close();
      }
    }
    builder.setMobileApplicationType(mobileApplicationType);
    final String name = moduleElement.getAttributeValue("name");
    builder.setModuleFilePath(projectSettings.getProjectLocation() + File.separator + name + ".iml");
    builder.setName(name);
    final List properties = moduleElement.getChildren("property");
    for (Object o : properties) {
      Element element = (Element)o;
      final String settingName = element.getAttributeValue("name");
      final String settingValue = element.getAttributeValue("value");
      if (element.getAttributeValue("archiving.micro") != null ){
        settings.getSettings().put(settingName, settingValue);
      }
    }
    builder.setMobileModuleSettings(settings);
    builder.setMobileApplicationType(mobileApplicationType);
    return builder.createModule(moduleModel);
  }

  @NotNull
  public String getComponentName() {
    return "JBuilderMobileProjectImporter";
  }

  public void initComponent() {
  }

  public void disposeComponent() {
  }
}
