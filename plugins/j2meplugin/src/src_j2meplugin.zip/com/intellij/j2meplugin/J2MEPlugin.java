/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin;

import com.intellij.codeInsight.intention.IntentionManager;
import com.intellij.codeInspection.InspectionToolProvider;
import com.intellij.j2meplugin.codeInspection.MissedExecutableInspection;
import com.intellij.j2meplugin.module.J2MEModuleType;
import com.intellij.j2meplugin.module.intentions.EditModuleSettingsIntentionAction;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.module.ModuleTypeManager;
import org.jetbrains.annotations.NotNull;

/**
 * User: anna
 * Date: Aug 16, 2004
 */
public class J2MEPlugin implements ApplicationComponent, InspectionToolProvider {
  @NotNull
  public String getComponentName() {
    return "J2MEPlugin";
  }

  public J2MEPlugin(ModuleTypeManager moduleTypeManager, IntentionManager intentionManager) {
    moduleTypeManager.registerModuleType(J2MEModuleType.getInstance(), true);
    intentionManager.addAction(new EditModuleSettingsIntentionAction());
  }

  public void initComponent() {
  }

  public void disposeComponent() {
  }

  public Class[] getInspectionClasses() {
    return new Class[] {MissedExecutableInspection.class};
  }
}
