/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.module;

import com.intellij.ide.util.projectWizard.ModuleWizardStep;
import com.intellij.ide.util.projectWizard.ProjectWizardStepFactory;
import com.intellij.ide.util.projectWizard.WizardContext;
import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.j2meplugin.emulator.Emulator;
import com.intellij.j2meplugin.emulator.MobileSdk;
import com.intellij.j2meplugin.util.MobileIcons;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.module.ModuleType;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.roots.ui.configuration.ModulesProvider;
import com.intellij.openapi.util.Computable;
import com.intellij.util.ArrayUtil;

import javax.swing.*;
import java.util.ArrayList;

/**
 * User: anna
 * Date: Aug 16, 2004
 */
public class J2MEModuleType extends ModuleType<J2MEModuleBuilder> {
  private static J2MEModuleType ourInstance = new J2MEModuleType();

  private J2MEModuleType() {
    super("J2ME_MODULE");
  }

  public static J2MEModuleType getInstance() {
    return ourInstance;
  }

  public J2MEModuleBuilder createModuleBuilder() {
    return new J2MEModuleBuilder();
  }

  public ModuleWizardStep[] createWizardSteps(final WizardContext wizardContext, final J2MEModuleBuilder moduleBuilder,
                                              ModulesProvider modulesProvider) {
    final ProjectWizardStepFactory wizardFactory = ProjectWizardStepFactory.getInstance();
    final ModuleWizardStep nameAndLocationStep = wizardFactory.createNameAndLocationStep(wizardContext, moduleBuilder, modulesProvider,
                                                                                         MobileIcons.WIZARD_ICON,
                                                                                         "j2me.createJ2ME");
    ArrayList<ModuleWizardStep> steps = new ArrayList<ModuleWizardStep>();
    steps.add(nameAndLocationStep);
    steps.add(new J2MEModuleTypeStep(wizardContext, moduleBuilder, MobileIcons.WIZARD_ICON, "j2me.createJ2ME"));
    steps.add(wizardFactory.createProjectJdkStep(wizardContext, ApplicationManager.getApplication().getComponent(MobileSdk.class), moduleBuilder, new Computable<Boolean>() {
      public Boolean compute() {
        final ProjectJdk projectJdk = wizardContext.getProjectJdk();
        return projectJdk == null ||
               !(projectJdk.getSdkType() instanceof MobileSdk) ||
               projectJdk.getSdkAdditionalData() == null ||
               moduleBuilder.getMobileApplicationType() == null ||
               !moduleBuilder.getMobileApplicationType().getName()
                 .equals(((Emulator)projectJdk.getSdkAdditionalData()).getEmulatorType().getApplicationType())
               ? Boolean.TRUE
               : Boolean.FALSE;
      }
    }, MobileIcons.WIZARD_ICON, "j2me.createJ2ME"));
    steps.add(new J2MEModuleResourcesStep(wizardContext, moduleBuilder, MobileIcons.WIZARD_ICON, "j2me.createJ2ME"));
    steps.add(new J2MEModuleExplodedDirStep(wizardContext, moduleBuilder, MobileIcons.WIZARD_ICON, "j2me.createJ2ME"));
    steps.add(wizardFactory.createSourcePathsStep(nameAndLocationStep, moduleBuilder, MobileIcons.WIZARD_ICON, "j2me.createJ2ME"));
    final ModuleWizardStep[] wizardSteps = steps.toArray(new ModuleWizardStep[steps.size()]);
    return ArrayUtil.mergeArrays(wizardSteps, super.createWizardSteps(wizardContext, moduleBuilder, modulesProvider), ModuleWizardStep.class);
  }

  public String getName() {
    return J2MEBundle.message("module.type.title");
  }

  public String getDescription() {
    return J2MEBundle.message("module.type.description");
  }

  public Icon getBigIcon() {
    return MobileIcons.MOBILE_MODULE_ICON;
  }

  public Icon getNodeIcon(boolean isOpened) {
    return MobileIcons.MOBILE_SMALL_ICON;
  }
}
