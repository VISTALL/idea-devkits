/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.module.settings.midp;

import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.j2meplugin.emulator.Emulator;
import com.intellij.j2meplugin.emulator.MobileSdk;
import com.intellij.j2meplugin.module.J2MEModuleBuilder;
import com.intellij.j2meplugin.module.settings.MobileModuleSettings;
import com.intellij.j2meplugin.module.type.MobileApplicationType;
import com.intellij.j2meplugin.module.type.midp.MIDPApplicationType;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.projectRoots.ProjectJdk;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.util.Computable;
import org.jetbrains.annotations.NonNls;

import java.io.*;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.jar.Attributes;
import java.util.regex.Pattern;

/**
 * User: anna
 * Date: Sep 5, 2004
 */
public class MIDPSettings extends MobileModuleSettings {
  /* private static final String USER_DEFINED_OPTIONS = "userDefinedOptions";
   private static final String USER_OPTION = "option";
   private static final String USER_OPTION_KEY = "key";
   private static final String USER_OPTION_VALUE = "value";
 */
  public MIDPSettings() {}

  public MIDPSettings(Module module) {
    super(module);
  }

  public void copyTo(MobileModuleSettings mobileModuleSettings) {
    if (!(mobileModuleSettings instanceof MIDPSettings)) return;
    super.copyTo(mobileModuleSettings);
  }


  public void initSettings(J2MEModuleBuilder moduleBuilder, MobileApplicationType mobileApplicationType) {
    super.initSettings(moduleBuilder, mobileApplicationType);
    if (myDefaultModified) {
      putIfNotExists(MIDPApplicationType.MIDLET_NAME, moduleBuilder.getName());
      putIfNotExists(MIDPApplicationType.MIDLET_VENDOR, J2MEBundle.message("module.settings.default.vendor"));
      putIfNotExists(MIDPApplicationType.MIDLET_VERSION, "1.0");
    }
    else {
      putSetting(MIDPApplicationType.MIDLET_NAME, moduleBuilder.getName());
      putSetting(MIDPApplicationType.MIDLET_VENDOR, J2MEBundle.message("module.settings.default.vendor"));
      putSetting(MIDPApplicationType.MIDLET_VERSION, "1.0");
    }
  }

  public void initExistModuleSettings(final MobileApplicationType mobileApplicationType) {
    super.initExistModuleSettings(mobileApplicationType);
    putIfNotExists(MIDPApplicationType.MIDLET_NAME, ApplicationManager.getApplication().runReadAction(new Computable<String >() {
      public String compute() {
        return myModule.getName();
      }
    }));
    putIfNotExists(MIDPApplicationType.MIDLET_VENDOR, J2MEBundle.message("module.settings.default.vendor"));
    putIfNotExists(MIDPApplicationType.MIDLET_VERSION, "1.0");
  }

  public void prepareJarSettings() {
    super.prepareJarSettings();
    ProjectJdk myProjectJdk = ModuleRootManager.getInstance(myModule).getJdk();
    if (MobileSdk.checkCorrectness(myProjectJdk, myModule)) {
      final String profile = ((Emulator)myProjectJdk.getSdkAdditionalData()).getProfile();
      LOG.assertTrue(profile != null);
      if (!isSynchronized()) { //refresh if user changed emulator settings
        putSetting(MIDPApplicationType.MIDLET_PROFILE,
                   profile);
      }
      final String configuration = ((Emulator)myProjectJdk.getSdkAdditionalData()).getConfiguration();
      LOG.assertTrue(configuration != null);
      if (!isSynchronized()) {
        putSetting(MIDPApplicationType.MIDLET_CONFIGURATION,
                   configuration);
      }
    }
  }

  public File getManifest() {
    final File manifest = super.getManifest();
    if (manifest != null) return manifest;
    final String separator = MIDPApplicationType.getInstance().getSeparator();
    try {
      @NonNls final String prefix = "temp";
      @NonNls final String suffix = ".mf";
      File temp = File.createTempFile(prefix, suffix);
      temp.deleteOnExit();
      PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter(temp)));

      putManifestAttribute(printWriter, Attributes.Name.MANIFEST_VERSION.toString(), separator, "1.0");
      putManifestAttribute(printWriter, MIDPApplicationType.MIDLET_CONFIGURATION, separator,
                           getSettings().get(MIDPApplicationType.MIDLET_CONFIGURATION));

      putManifestAttribute(printWriter, MIDPApplicationType.MIDLET_NAME, separator, getSettings().get(MIDPApplicationType.MIDLET_NAME));
      putManifestAttribute(printWriter, MIDPApplicationType.MIDLET_VENDOR, separator, getSettings().get(MIDPApplicationType.MIDLET_VENDOR));

      for (String key : getMIDlets()) {
        putManifestAttribute(printWriter, key, separator, getSettings().get(key).replaceAll(",", ", "));
      }

      putManifestAttribute(printWriter, MIDPApplicationType.MIDLET_VERSION, separator,
                           getSettings().get(MIDPApplicationType.MIDLET_VERSION));

      putManifestAttribute(printWriter, MIDPApplicationType.MIDLET_PROFILE, separator,
                           getSettings().get(MIDPApplicationType.MIDLET_PROFILE));

      printWriter.close();
      return temp;
    }
    catch (IOException e) {
      //do nothing
    }
    return null;
  }


  public static MIDPSettings getInstance(Module module) {
    return module.getComponent(MIDPSettings.class);
  }


  /* public void readExternal(Element parentElement) throws InvalidDataException {
     super.readExternal(parentElement);
     Element userOptionsGroup = parentElement.getChild(USER_DEFINED_OPTIONS);
     if (userOptionsGroup != null) {
       for (Iterator<Element> iterator = userOptionsGroup.getChildren(USER_OPTION).iterator(); iterator.hasNext();) {
         Element option = iterator.next();
         UserDefinedOption userDefinedOption = new UserDefinedOption(option.getAttributeValue(USER_OPTION_KEY),
                                                                     option.getAttributeValue(USER_OPTION_VALUE));
         userDefinedOptions.add(userDefinedOption);
       }
     }

   }*/

  /* public void writeExternal(Element parentElement) throws WriteExternalException {
     Element userOptionsGroup = new Element(USER_DEFINED_OPTIONS);
     for (Iterator<UserDefinedOption> iterator = userDefinedOptions.iterator(); iterator.hasNext();) {
       Element userOption = new Element(USER_OPTION);
       UserDefinedOption option = iterator.next();
       userOption.setAttribute(USER_OPTION_KEY, option.getKey());
       userOption.setAttribute(USER_OPTION_VALUE, option.getValue());
       userOptionsGroup.addContent(userOption);
     }
     parentElement.addContent(userOptionsGroup);
     parentElement.addContent(userOptionsGroup);        
     super.writeExternal(parentElement);

   }
 */
  public void projectOpened() {}

  public void projectClosed() {}

  public void moduleAdded() {}

  public String getComponentName() {
    return "MIDPSettings";
  }

  public void initComponent() {}

  public void disposeComponent() {}

  public SortedSet<String> getMIDlets() {
    SortedSet<String> midletNumbers = new TreeSet<String>();
    @NonNls final String pattern = "\\d*";
    final Pattern midlets = Pattern.compile(MIDPApplicationType.MIDLET_PREFIX + pattern);
    for (Iterator<String> iterator = getSettings().keySet().iterator(); iterator.hasNext();) {
      String key = iterator.next();
      if (midlets.matcher(key).matches()) {
        midletNumbers.add(key);
      }
    }
    return midletNumbers;
  }

  public MobileApplicationType getApplicationType() {
    return MIDPApplicationType.getInstance();
  }

  public static class MIDletProperty {
    private String name;
    private String icon;
    private String className;
    private String number;

    public MIDletProperty(String name, String icon, String className, String number) {
      this.name = name;
      this.icon = icon;
      this.className = className;
      this.number = number;
    }

    public MIDletProperty(String number, String value) {
      String[] midlet = value.split(",");
      LOG.assertTrue(midlet != null && midlet.length == 3);
      name = midlet[0];
      icon = midlet[1];
      className = midlet[2];
      this.number = number;
    }

    public String getName() {
      return name;
    }

    public String getIcon() {
      return icon;
    }

    public String getClassName() {
      return className;
    }

    public String getValueString() {
      return name + "," + icon + "," + className;
    }

    public String getNumber() {
      return number;
    }

    public boolean equals(Object o) {
      if (!(o instanceof MIDletProperty)) return false;
      return ((MIDletProperty)o).getNumber().equals(getNumber());
    }

    public int hashCode() {
      int result = getNumber().hashCode() * 29;
      return result + getValueString().hashCode() * 29;
    }
  }


}
