/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.module;

import com.intellij.ide.util.projectWizard.ModuleWizardStep;
import com.intellij.ide.util.projectWizard.WizardContext;
import com.intellij.j2meplugin.module.settings.MobileSettingsEditor;
import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;

import javax.swing.*;

import org.jetbrains.annotations.NonNls;

/**
 * User: anna
 * Date: Sep 19, 2004
 */
public class J2MEModuleTypeStep extends ModuleWizardStep {
  private static final Logger LOG = Logger.getInstance("#com.intellij.j2meplugin");
  private J2MEModuleBuilder myModuleBuilder;


  private Icon myIcon;
  private String myHelpId;

  private MobileSettingsEditor myMobileSettingsEditor;

  private Project myProject;

  public J2MEModuleTypeStep(WizardContext wizardContext,
                            J2MEModuleBuilder moduleBuilder,
                            Icon wizardIcon,
                            @NonNls String s) {
    myModuleBuilder = moduleBuilder;
    myHelpId = s;
    myIcon = wizardIcon;
    myProject = wizardContext.getProject();
    myMobileSettingsEditor = new MobileSettingsEditor(null, myProject, myModuleBuilder);

  }

  public JComponent getPreferredFocusedComponent() {
    return myMobileSettingsEditor.getPreferredFocusedComponent();
  }

  public boolean validate() {
    myModuleBuilder.setMobileApplicationType(myMobileSettingsEditor.getMobileApplicationType());
    try {
      myMobileSettingsEditor.getSettingsConfigurable().apply();
    }
    catch (ConfigurationException e) {
      Messages.showErrorDialog(e.getMessage(), J2MEBundle.message("module.settings.unable.to.save.message"));
      return false;
    }
    return true;
  }

  public JComponent getComponent() {
    myMobileSettingsEditor.changeMobileType();
    final JPanel myWholePanel = myMobileSettingsEditor.createComponent();
    myWholePanel.setBorder(BorderFactory.createEtchedBorder());
    return myWholePanel;
  }

  public void updateDataModel() {
    myMobileSettingsEditor.getSettingsConfigurable().getMobileModuleSettings().setSynchronized(
      myMobileSettingsEditor.isUseUserDefinedDescriptor());
    myMobileSettingsEditor.getSettingsConfigurable().getMobileModuleSettings().setModified(true);
    myModuleBuilder.setMobileModuleSettings(myMobileSettingsEditor.getSettingsConfigurable().getMobileModuleSettings());
  }

  public Icon getIcon() {
    return myIcon;
  }

  public String getHelpId() {
    return myHelpId;
  }

  public void onStepLeaving() {
    myModuleBuilder.setMobileApplicationType(myMobileSettingsEditor.getMobileApplicationType());
    try {
      myMobileSettingsEditor.getSettingsConfigurable().apply();
    }
    catch (ConfigurationException e) {
      //ignore
    }
    updateDataModel();
  }
}
