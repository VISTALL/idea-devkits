/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.module;

import com.intellij.j2meplugin.module.settings.MobileSettingsEditor;
import com.intellij.j2meplugin.module.type.MobileApplicationType;
import com.intellij.j2meplugin.module.type.midp.MIDPApplicationType;
import com.intellij.j2meplugin.util.MobileIcons;
import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleConfigurationEditor;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ModifiableRootModel;
import com.intellij.openapi.roots.ui.configuration.ModulesProvider;

import javax.swing.*;


/**
 * User: anna
 * Date: Aug 16, 2004
 */
public class J2MEModuleConfEditor implements ModuleConfigurationEditor {
  private Module myModule;
  private MobileSettingsEditor myMobileSettingsEditor;

  public J2MEModuleConfEditor(Project project, Module module, ModulesProvider provider, ModifiableRootModel rootModel) {
    myModule = module;
    myMobileSettingsEditor = new MobileSettingsEditor(module, project, null);
  }

  public void disposeUIResources() {
  }

  public void reset() {
    final MobileApplicationType mobileApplicationType = J2MEModuleProperties.getInstance(myModule).getMobileApplicationType();
    myMobileSettingsEditor.setMobileType(mobileApplicationType instanceof MIDPApplicationType);
    myMobileSettingsEditor.changeMobileType();

    myMobileSettingsEditor.getSettingsConfigurable().reset();
    myMobileSettingsEditor.setUseUserDefinedDescriptor(
      J2MEModuleProperties.getInstance(myModule).getMobileApplicationType().getMobileModuleSettings(myModule).isSynchronized());
  }

  public void apply() throws ConfigurationException {
    J2MEModuleProperties.getInstance(myModule).setMobileApplicationType(myMobileSettingsEditor.getMobileApplicationType());
    J2MEModuleProperties.getInstance(myModule).getMobileApplicationType().getMobileModuleSettings(myModule).setSynchronized(
      myMobileSettingsEditor.isUseUserDefinedDescriptor());
    myMobileSettingsEditor.getSettingsConfigurable().apply();

  }

  public boolean isModified() {
    return myMobileSettingsEditor.isModified();
  }

  public JComponent createComponent() {
    return myMobileSettingsEditor.createComponent();
  }

  public String getHelpTopic() {
    return "j2me.moduleJ2ME";
  }

  public Icon getIcon() {
    return MobileIcons.MOBILE_SMALL_ICON;
  }

  public String getDisplayName() {
    return J2MEBundle.message("mobile.module.settings.title");
  }

  public void moduleStateChanged() {
    //reset();
  }

  public void saveData() {
    //apply();
  }

}

