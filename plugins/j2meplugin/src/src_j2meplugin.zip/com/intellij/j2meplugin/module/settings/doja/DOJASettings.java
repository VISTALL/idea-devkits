/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.module.settings.doja;

import com.intellij.j2meplugin.module.J2MEModuleBuilder;
import com.intellij.j2meplugin.module.settings.MobileModuleSettings;
import com.intellij.j2meplugin.module.type.MobileApplicationType;
import com.intellij.j2meplugin.module.type.doja.DOJAApplicationType;
import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.Computable;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * User: anna
 * Date: Sep 19, 2004
 */
public class DOJASettings extends MobileModuleSettings {
  public DOJASettings() {}

  public DOJASettings(Module module) {
    super(module);
  }

  public void copyTo(MobileModuleSettings mobileModuleSettings) {
    if (!(mobileModuleSettings instanceof DOJASettings)) return;
    super.copyTo(mobileModuleSettings);
  }

  public void initSettings(J2MEModuleBuilder moduleBuilder, MobileApplicationType mobileApplicationType) {
    super.initSettings(moduleBuilder, mobileApplicationType);
    if (myDefaultModified) {
      putIfNotExists(DOJAApplicationType.APPLICATION_NAME, moduleBuilder.getName());
    }
    else {
      putSetting(DOJAApplicationType.APPLICATION_NAME, moduleBuilder.getName());
    }
  }

  public void initExistModuleSettings(final MobileApplicationType mobileApplicationType) {
    super.initExistModuleSettings(mobileApplicationType);
    putIfNotExists(DOJAApplicationType.APPLICATION_NAME, ApplicationManager.getApplication().runReadAction(new Computable<String>(){
      public String compute() {
        return myModule.getName();
      }
    }));
  }

  public void prepareJarSettings() {
    super.prepareJarSettings();
    final String lastModified = new SimpleDateFormat(J2MEBundle.message("doja.time.format")).format(new Date(new File(myJarURL).lastModified()));
    LOG.assertTrue(lastModified != null);
    if (myJarURL != null) {
      putSetting(DOJAApplicationType.LAST_MODIFIED,
                 lastModified);
    }
  }

  public File getManifest() {
    return null;
  }

  public SortedSet<String> getMIDlets() {
    TreeSet<String> treeSet = new TreeSet<String>();
    final String appClass = properties.get(DOJAApplicationType.APPLICATION_CLASS);
    if (appClass != null) {
      treeSet.add(appClass);
    }
    return treeSet;
  }

  public MobileApplicationType getApplicationType() {
    return DOJAApplicationType.getInstance();
  }

  public void projectOpened() {}

  public void projectClosed() {}

  public void moduleAdded() {}

  public String getComponentName() {
    return "DOJASettings";
  }

  public void initComponent() {}

  public void disposeComponent() {}

}
