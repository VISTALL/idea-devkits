/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.module.settings;

import com.intellij.j2meplugin.module.J2MEModuleBuilder;
import com.intellij.j2meplugin.module.settings.doja.DOJASettings;
import com.intellij.j2meplugin.module.settings.doja.DOJASettingsConfigurable;
import com.intellij.j2meplugin.module.settings.midp.MIDPSettings;
import com.intellij.j2meplugin.module.settings.midp.MIDPSettingsConfigurable;
import com.intellij.j2meplugin.module.type.MobileApplicationType;
import com.intellij.j2meplugin.module.type.doja.DOJAApplicationType;
import com.intellij.j2meplugin.module.type.midp.MIDPApplicationType;
import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.ActionRunner;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

/**
 * User: anna
 * Date: Sep 22, 2004
 */
public class MobileSettingsEditor {
  private static final Logger LOG = Logger.getInstance("#com.intellij.j2meplugin");
  private JPanel myWholePanel;
  private JLabel myExplanation;
  private JPanel mySettingsPanel;

  private MobileSettingsConfigurable mySettingsConfigurable;
  private MIDPSettingsConfigurable myMIDPSettingsConfigurable;
  private DOJASettingsConfigurable myDOJASettingsConfigurable;
  private MobileModuleSettings myMobileModuleSettings;
  private boolean myModified = false;
  private JCheckBox myUseUserDefinedJad;
  private JRadioButton myMIDP;
  private JRadioButton myDOJA;

  private Module myModule;
  private Project myProject;
  private J2MEModuleBuilder myModuleBuilder;
  private MobileApplicationType myMobileApplicationType;

  public MobileSettingsEditor(Module module, Project project, J2MEModuleBuilder moduleBuilder) {
    myProject = project;
    myModule = module;
    myModuleBuilder = moduleBuilder;

    ButtonGroup applicationTypes = new ButtonGroup();
    applicationTypes.add(myMIDP);
    applicationTypes.add(myDOJA);
    myMIDP.setSelected(true);

    myMIDP.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (myMobileApplicationType == null || myMobileApplicationType.equals(DOJAApplicationType.getInstance())) {
          myModified = true;
          changeMobileType();
          myMobileApplicationType = MIDPApplicationType.getInstance();
        }
      }
    });

    myDOJA.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (myMobileApplicationType == null || myMobileApplicationType.equals(MIDPApplicationType.getInstance())) {
          myModified = true;
          changeMobileType();
          myMobileApplicationType = DOJAApplicationType.getInstance();
        }
      }
    });

    myExplanation.setText(J2MEBundle.message("module.settings.type.explanation"));
    myUseUserDefinedJad.setText(J2MEBundle.message("module.settings.synchronization.needed", getMobileApplicationType().getExtension().toUpperCase()));
    myUseUserDefinedJad.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        myModified = true;
        if (myUseUserDefinedJad.isSelected() && new File(mySettingsConfigurable.mySettings.getMobileDescriptionPath()).exists()) {
          try {
            ActionRunner.runInsideWriteAction(new ActionRunner.InterruptibleRunnable() {
              public void run() throws Exception {
                final VirtualFile descriptor = LocalFileSystem.getInstance().refreshAndFindFileByPath(
                  mySettingsConfigurable.mySettings.getMobileDescriptionPath().replace(File.separatorChar, '/'));
                final FileDocumentManager documentManager = FileDocumentManager.getInstance();
                documentManager.saveDocument(documentManager.getDocument(descriptor));
              }
            });
          }
          catch (Exception ex) {
            LOG.error(ex);
          }
        }
      }
    });


    mySettingsPanel.setLayout(new BorderLayout());

  }

  public JComponent getPreferredFocusedComponent() {
    return myMIDP;
  }

  public MobileApplicationType getMobileApplicationType() {
    if (myMIDP.isSelected()) {
      return MIDPApplicationType.getInstance();
    }
    else {
      return DOJAApplicationType.getInstance();
    }
  }

  public boolean isUseUserDefinedDescriptor() {
    return myUseUserDefinedJad.isSelected();
  }

  public void setUseUserDefinedDescriptor(boolean use) {
    myUseUserDefinedJad.setSelected(use);
  }

  public MobileSettingsConfigurable getSettingsConfigurable() {
    return mySettingsConfigurable;
  }

  public JPanel createComponent() {
    myWholePanel.setBorder(new EmptyBorder(5, 5, 5, 5));
    return myWholePanel;
  }

  public boolean isModified() {
    return myModified || mySettingsConfigurable.isModified();
  }

  public void setMobileType(boolean isMIDP) {
    if (isMIDP) {
      myMIDP.setSelected(true);
    }
    else {
      myDOJA.setSelected(true);
    }
  }

  public void changeMobileType() {
    final MobileApplicationType mobileType = getMobileApplicationType();
    if (mobileType != null) {
      myUseUserDefinedJad.setText(J2MEBundle.message("module.settings.synchronization.needed", getMobileApplicationType().getExtension().toUpperCase()));
    }
    else {
      myUseUserDefinedJad.setText(J2MEBundle.message("module.settings.synchronization.needed.common"));
    }
    initMobileModuleSettings(mobileType);
    initMobileSettingsConfigurable();
  }

  public void initMobileSettingsConfigurable() {
    boolean toReset = false;
    if (myMIDP.isSelected()) {
      if ((myMIDPSettingsConfigurable == null || !myMIDPSettingsConfigurable.isModified()) && myMobileModuleSettings instanceof MIDPSettings) {
        myMIDPSettingsConfigurable = new MIDPSettingsConfigurable(myProject, myModule, (MIDPSettings)myMobileModuleSettings);
        toReset = true;
      }
      mySettingsConfigurable = myMIDPSettingsConfigurable;
    }
    else {
      if ((myDOJASettingsConfigurable == null || !myDOJASettingsConfigurable.isModified()) && myMobileModuleSettings instanceof DOJASettings) {
        myDOJASettingsConfigurable = new DOJASettingsConfigurable(myProject, myModule, (DOJASettings)myMobileModuleSettings);
        toReset = true;
      }
      mySettingsConfigurable = myDOJASettingsConfigurable;
    }
    if (mySettingsConfigurable != null) {
      if (myModule == null) {
        mySettingsConfigurable.setBeforeModuleSetState();
      }
      JComponent component = mySettingsConfigurable.createComponent();
      if (toReset) {
        mySettingsConfigurable.reset();
      }
      mySettingsPanel.removeAll();
      if (component != null) {
        mySettingsPanel.add(component, BorderLayout.CENTER);
        mySettingsPanel.setBorder(new TitledBorder(J2MEBundle.message("module.settings.descriptor.options",getMobileApplicationType().getExtension().toUpperCase())));
      }
    }
  }

  public void initMobileModuleSettings(final MobileApplicationType mobileType) {
    myMobileModuleSettings = mobileType.getMobileModuleSettings(myModule);
    if (myModule != null) {
      myMobileModuleSettings.initExistModuleSettings(mobileType);
    }
    else {
      final MobileModuleSettings mobileModuleSettings = myModuleBuilder.getMobileModuleSettings();
      if (mobileModuleSettings != null) {
        myMobileModuleSettings = mobileModuleSettings;
      }
      myMobileModuleSettings.initSettings(myModuleBuilder, mobileType);
    }
  }
}
