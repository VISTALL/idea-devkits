/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.module.settings.midp;


import com.intellij.j2meplugin.J2MEBundle;
import com.intellij.j2meplugin.module.J2MEModuleProperties;
import com.intellij.j2meplugin.module.settings.MobileSettingsConfigurable;
import com.intellij.j2meplugin.module.settings.general.UserDefinedOption;
import com.intellij.j2meplugin.module.settings.general.UserKeysConfigurable;
import com.intellij.j2meplugin.module.type.midp.MIDPApplicationType;
import com.intellij.j2meplugin.util.J2MEClassBrowser;
import com.intellij.openapi.fileChooser.FileChooser;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.ui.TextFieldWithBrowseButton;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.ui.DocumentAdapter;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.File;
import java.util.*;


/**
 * User: anna
 * Date: Sep 1, 2004
 */
public class MIDPSettingsConfigurable extends MobileSettingsConfigurable {
  private JTextField myMIDletName;
  private JLabel myMIDletNameLabel;

  private TextFieldWithBrowseButton myMIDletJarUrl;
  private JLabel myMIDletJarUrlLabel;


  private JTextField myMIDletVersion;
  private JLabel myMIDletVersionLabel;

  private JTextField myMIDletVendor;
  private JLabel myMIDletVendorLabel;


  private JButton myAddButton;
  private JButton myEditButton;
  private JButton myRemoveButton;
  private JButton myMoveUpButton;
  private JButton myMoveDownButton;
  private JButton myOptionalSettingsButton;

  private DefaultListModel myListModel = new DefaultListModel();
  private JList myMIDletList;

  private JPanel myWholePanel;

  private JPanel myMIDletPropertiesPanel;

  private boolean myModified = false;
  private Project myProject;
  private Module myModule;
  private HashMap<String, String> myTempSettings;
  private HashSet<UserDefinedOption> myTempUserOptions;

  public MIDPSettingsConfigurable(Project project, Module module, MIDPSettings midpSettings) {
    super(midpSettings);
    myProject = project;
    myModule = module;
    myTempSettings = new HashMap<String, String>();
    myTempUserOptions = new HashSet<UserDefinedOption>();
  }

  public JPanel createComponent() {
    ActionListener modifier = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        myModified = true;
      }
    };
    DocumentAdapter textModifier = new DocumentAdapter() {
      protected void textChanged(DocumentEvent e) {
        myModified = true;
      }
    };

    DocumentAdapter defaultModifier = new DocumentAdapter() {
      protected void textChanged(DocumentEvent e) {
        mySettings.setDefaultModified(true);
      }
    };

    myMIDletNameLabel.setText(MIDPApplicationType.MIDLET_NAME + ":");
    myMIDletName.getDocument().addDocumentListener(textModifier);
    myMIDletName.getDocument().addDocumentListener(defaultModifier);

    myMIDletVersionLabel.setText(MIDPApplicationType.MIDLET_VERSION + ":");
    myMIDletVersion.getDocument().addDocumentListener(textModifier);
    myMIDletVersion.addFocusListener(new FocusListener() {
      public void focusGained(FocusEvent e) {
        myMIDletVersion.selectAll();
      }

      public void focusLost(FocusEvent e) {
      }
    });

    myMIDletVendorLabel.setText(MIDPApplicationType.MIDLET_VENDOR + ":");
    myMIDletVendor.getDocument().addDocumentListener(textModifier);
    myMIDletVendor.addFocusListener(new FocusListener() {
      public void focusGained(FocusEvent e) {
        myMIDletVendor.selectAll();
      }

      public void focusLost(FocusEvent e) {
      }
    });


    myMIDletJarUrlLabel.setText(MIDPApplicationType.MIDLET_JAR_URL + ":");
    myMIDletJarUrl.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        FileChooserDescriptor fileChooserDescriptor = new FileChooserDescriptor(true, true, true, true, false, false);
        fileChooserDescriptor.setTitle(J2MEBundle.message("build.settings.jar.utl.title"));
        fileChooserDescriptor.setDescription(J2MEBundle.message("build.settings.jar.url"));
        String directoryName = myMIDletJarUrl.getText().trim();
        VirtualFile initialFile = LocalFileSystem.getInstance().findFileByPath(directoryName.replace(File.separatorChar, '/'));
        VirtualFile[] files = FileChooser.chooseFiles(myProject, fileChooserDescriptor, initialFile);
        if (files != null && files.length != 0) {
          myMIDletJarUrl.setText(FileUtil.toSystemIndependentName(files[0].getPresentableUrl()));
        }
      }
    });
    myMIDletJarUrl.addActionListener(modifier);
    myMIDletJarUrl.getTextField().getDocument().addDocumentListener(textModifier);
    myMIDletJarUrl.getTextField().getDocument().addDocumentListener(defaultModifier);

    myMoveUpButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (myMIDletList.getSelectedIndex() <= 0) return;
        moveMIDlet(-1);
        myModified = true;
      }
    });

    myMoveDownButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (myMIDletList.getSelectedValue() == null || myMIDletList.getSelectedIndex() >= myListModel.size() - 1) return;
        moveMIDlet(+1);
        myModified = true;
      }
    });


    myMIDletList.setModel(myListModel);
    myMIDletList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    myMIDletList.setCellRenderer(new DefaultListCellRenderer() {
      public Component getListCellRendererComponent(JList jList, Object o, int i, boolean b, boolean b1) {
        super.getListCellRendererComponent(jList, o, i, b, b1);
        setText(((MIDPSettings.MIDletProperty)o).getName());
        return this;
      }
    });

    myRemoveButton.setEnabled(false);
    myEditButton.setEnabled(false);
    myMoveUpButton.setEnabled(false);
    myMoveDownButton.setEnabled(false);

    myMIDletList.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        if (myMIDletList.getSelectedIndex() == -1) {
          myRemoveButton.setEnabled(false);
          myEditButton.setEnabled(false);
          myMoveUpButton.setEnabled(false);
          myMoveDownButton.setEnabled(false);
        }
        else {
          myEditButton.setEnabled(true);
          myRemoveButton.setEnabled(true);
          if (myMIDletList.getSelectedIndex() != 0) {
            myMoveUpButton.setEnabled(true);
          }
          else {
            myMoveUpButton.setEnabled(false);
          }
          if (myMIDletList.getSelectedIndex() != myListModel.getSize() - 1) {
            myMoveDownButton.setEnabled(true);
          }
          else {
            myMoveDownButton.setEnabled(false);
          }
        }
      }
    });

    myRemoveButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (myMIDletList.getSelectedValue() == null) return;
        MIDPSettings.MIDletProperty midlet = (MIDPSettings.MIDletProperty)myMIDletList.getSelectedValue();
        ArrayList<MIDPSettings.MIDletProperty> midlets = new ArrayList<MIDPSettings.MIDletProperty>();
        for (int i = 0; i < myListModel.size(); i++) {
          final MIDPSettings.MIDletProperty property = (MIDPSettings.MIDletProperty)myListModel.get(i);
          if (!property.equals(midlet)){
            midlets.add(property);
          }
        }
        myListModel.clear();
        int midletCount = 1;
        for (MIDPSettings.MIDletProperty key : midlets) {
          final MIDPSettings.MIDletProperty property = new MIDPSettings.MIDletProperty(MIDPApplicationType.MIDLET_PREFIX + midletCount,
                                                                                       key.getValueString());
          myListModel.addElement(property);
          midletCount++;
        }
        myModified = true;
      }
    });

    myAddButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        new MIDletOptionsPanel(myWholePanel,
                               new MIDPSettings.MIDletProperty("", "", "",
                                                               MIDPApplicationType.MIDLET_PREFIX + (myListModel.size() + 1)),
                               false).show();
      }
    });

    myEditButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (myMIDletList.getSelectedValue() == null) return;
        new MIDletOptionsPanel(myWholePanel,
                               (MIDPSettings.MIDletProperty)myMIDletList.getSelectedValue(),
                               true).show();
      }
    });

    myOptionalSettingsButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        new AdditionalOptionsPanel(myWholePanel).show();
      }
    });
    return myWholePanel;
  }


  public void setBeforeModuleSetState() {
    myMIDletPropertiesPanel.setVisible(false);
  }

  private void moveMIDlet(int direction) {
    int index = myMIDletList.getSelectedIndex();
    MIDPSettings.MIDletProperty from = (MIDPSettings.MIDletProperty)myListModel.getElementAt(index);
    MIDPSettings.MIDletProperty to = (MIDPSettings.MIDletProperty)myListModel.elementAt(index + direction);
    myListModel.set(index, new MIDPSettings.MIDletProperty(to.getName(),
                                                           to.getIcon(),
                                                           to.getClassName(),
                                                           from.getNumber()));
    myListModel.set(index + direction, new MIDPSettings.MIDletProperty(from.getName(),
                                                                       from.getIcon(),
                                                                       from.getClassName(),
                                                                       to.getNumber()));
    myMIDletList.removeSelectionInterval(index, index);
    myMIDletList.addSelectionInterval(index + direction, index + direction);
  }

  public void reset() {
    super.reset();
    myMIDletName.setText(mySettings.getSettings().get(MIDPApplicationType.MIDLET_NAME));
    myMIDletJarUrl.setText(mySettings.getSettings().get(MIDPApplicationType.MIDLET_JAR_URL));
    myMIDletVersion.setText(mySettings.getSettings().get(MIDPApplicationType.MIDLET_VERSION));
    myMIDletVendor.setText(mySettings.getSettings().get(MIDPApplicationType.MIDLET_VENDOR));

    myListModel.clear();
    SortedSet<String> midletNumbers = mySettings.getMIDlets();
    for (Iterator<String> iterator = midletNumbers.iterator(); iterator.hasNext();) {
      String key = iterator.next();
      final String value = mySettings.getSettings().get(key);
      if (value != null) {
        myListModel.addElement(new MIDPSettings.MIDletProperty(key, value));
      }
    }
    myMIDletList.setModel(myListModel);
    myModified = false;

    mySettings.setDefaultModified(false);
    myTempSettings.putAll(mySettings.getSettings());
    myTempUserOptions.addAll(mySettings.getUserDefinedOptions());
  }

  public void disposeUIResources() {}

  public void apply() throws ConfigurationException {
    if (myMIDletName.getText() == null || myMIDletName.getText().length() == 0) {
      throw new ConfigurationException(J2MEBundle.message("module.settings.suit.not.specified"));
    }

    if (myMIDletJarUrl.getText() == null || myMIDletJarUrl.getText().length() == 0) {
      throw new ConfigurationException(J2MEBundle.message("compiler.jar.file.not.specified"));
    }


    if (myMIDletVersion.getText() == null || myMIDletVersion.getText().length() == 0) {
      throw new ConfigurationException(J2MEBundle.message("module.settings.version.not.specified"));
    }

    if (myMIDletVendor.getText() == null || myMIDletVendor.getText().length() == 0) {
      throw new ConfigurationException(J2MEBundle.message("module.settings.vendor.not.specified."));
    }

    mySettings.getSettings().clear();
    for (final String key : myTempSettings.keySet()) {
      mySettings.putSetting(key, myTempSettings.get(key));
    }

    for (int i = 0; i < myListModel.size(); i++) {
      final MIDPSettings.MIDletProperty midlet = ((MIDPSettings.MIDletProperty)myListModel.getElementAt(i));
      mySettings.putSetting(midlet.getNumber(), midlet.getValueString());
    }

    mySettings.getUserDefinedOptions().clear();
    for (final UserDefinedOption myTempUserOption : myTempUserOptions) {
      mySettings.getUserDefinedOptions().add(myTempUserOption);
    }

    mySettings.putSetting(MIDPApplicationType.MIDLET_NAME, myMIDletName.getText());
    mySettings.putSetting(MIDPApplicationType.MIDLET_JAR_URL, myMIDletJarUrl.getText());

    mySettings.putSetting(MIDPApplicationType.MIDLET_VERSION, myMIDletVersion.getText());
    mySettings.putSetting(MIDPApplicationType.MIDLET_VENDOR, myMIDletVendor.getText());
    super.apply();
    myModified = false;
    //  mySettings.setDefaultModified(false);
  }


  public boolean isModified() {
    return myModified;
  }


  private class MIDletOptionsPanel extends DialogWrapper {

    private JPanel myMIDletOptionsPanel = new JPanel(new BorderLayout());
    private JPanel myLabelPanel = new JPanel(new GridLayout(3, 1));
    private JPanel myFieldsPanel = new JPanel(new GridLayout(3, 1));

    private TextFieldWithBrowseButton myMIDletClass = new TextFieldWithBrowseButton();
    private JLabel myClassLabel = new JLabel(J2MEBundle.message("module.settings.midlet.class"));

    private TextFieldWithBrowseButton myMIDletIcon = new TextFieldWithBrowseButton();
    private JLabel myIconLabel = new JLabel(J2MEBundle.message("module.settings.icon"));

    private JTextField myMIDletName = new JTextField();
    private JLabel myNameLabel = new JLabel(J2MEBundle.message("module.settings.midlet.name"));
    private MIDPSettings.MIDletProperty myMIDlet;
    private boolean myEditing = false;

    private String relativeResources = J2MEModuleProperties.getInstance(myModule).getResourcePath();//todo specify relative file chooser

    public MIDletOptionsPanel(Component parent,
                              MIDPSettings.MIDletProperty midlet,
                              boolean isEditing) {
      super(parent, true);
      setTitle(midlet.getNumber());
      myMIDlet = midlet;
      init();
      myEditing = isEditing;
      if (!myEditing) {
        setOKActionEnabled(false);
      }
    }

    protected JComponent createCenterPanel() {
      myMIDletOptionsPanel.add(myLabelPanel, BorderLayout.WEST);
      myMIDletOptionsPanel.add(myFieldsPanel, BorderLayout.CENTER);

      myLabelPanel.add(myNameLabel);
      myMIDletName.setText(myMIDlet.getName());
      myFieldsPanel.add(myMIDletName);


      myLabelPanel.add(myIconLabel);
      if (relativeResources != null && myMIDlet.getIcon() != null) {
        myMIDletIcon.setText((relativeResources + myMIDlet.getIcon()).replace('/', File.separatorChar));
      }
      myMIDletIcon.addBrowseFolderListener(J2MEBundle.message("module.settings.choose.midlet.icon"),
                                           J2MEBundle.message("module.settings.choose.icon", myMIDletName.getText()),
                                           myProject,
                                           new FileChooserDescriptor(true,
                                                                     false,
                                                                     false,
                                                                     false,
                                                                     false,
                                                                     false));
      myFieldsPanel.add(myMIDletIcon);

      myLabelPanel.add(myClassLabel);
      myMIDletClass.setText(myMIDlet.getClassName());
      myFieldsPanel.add(myMIDletClass);

      myMIDletClass.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          J2MEClassBrowser j2MEClassBrowser = new J2MEClassBrowser(myModule);
          j2MEClassBrowser.show();
          j2MEClassBrowser.setField(myMIDletClass);
        }
      });

      myMIDletClass.getTextField().getDocument().addDocumentListener(new DocumentAdapter() {
        protected void textChanged(DocumentEvent e) {
          if (myMIDletName.getText() == null || myMIDletName.getText().length() == 0) {
            myMIDletName.setText(myMIDletClass.getText());
          }
          if (myMIDletClass.getText() == null || myMIDletClass.getText().length() == 0) {
            setOKActionEnabled(false);
          }
          else {
            setOKActionEnabled(true);
          }
        }
      });

      myMIDletName.getDocument().addDocumentListener(new DocumentAdapter() {
        protected void textChanged(DocumentEvent e) {
          if (myMIDletName.getText() == null || myMIDletName.getText().length() == 0) {
            setOKActionEnabled(false);
          }
          else {
            setOKActionEnabled(true);
          }
        }
      });

      JPanel whole = new JPanel(new BorderLayout());
      whole.add(myMIDletOptionsPanel, BorderLayout.NORTH);
      return whole;
    }

    protected void doOKAction() {
      String iconPath = myMIDletIcon.getText().replace(File.separatorChar, '/');
      if (relativeResources == null) {
        if (iconPath.length() != 0) {
          Messages.showErrorDialog(J2MEBundle.message("module.settings.unable.to.set.icon"), J2MEBundle.message("resource.directory.needed"));
          return;
        }
      }
      else {

        if (!iconPath.startsWith(relativeResources.replace(File.separatorChar, '/'))) {
          if (iconPath.length() != 0) {
            Messages.showErrorDialog(J2MEBundle.message("module.settings.incorrect.icon.path"), J2MEBundle.message("module.settings.correct.icon.path", relativeResources));
            return;
          }
        }
        else {
          iconPath = iconPath.substring(relativeResources.length());
        }
      }
      myMIDlet = new MIDPSettings.MIDletProperty(myMIDletName.getText(),
                                                 iconPath,
                                                 myMIDletClass.getText(),
                                                 myMIDlet.getNumber());
      // if (myMIDlet.getNumber(), myMIDlet.getValueString())) {
      if (myEditing) {
        myListModel.setElementAt(myMIDlet, myMIDletList.getSelectedIndex());
      }
      else {
        myListModel.addElement(myMIDlet);
      }
      //}
      myModified = true;
      super.doOKAction();
    }
  }


  public class AdditionalOptionsPanel extends DialogWrapper {
    private JPanel myCentrePanel;


    private JTextField myDeleteConfirmField;
    private JLabel myDeleteConfirm;

    private TextFieldWithBrowseButton myInstallNotifyURL;
    private JLabel myInstallNotify;

    private JTextField myDataSizeField;
    private JLabel myDataSize;

    private TextFieldWithBrowseButton myIconField;
    private JLabel myIcon;

    private JTextField myDescriptionField;
    private JLabel myDescription;

    private TextFieldWithBrowseButton myInfoURLField;
    private JLabel myInfoUrl;
    private JPanel myUserPanel;

    private UserKeysConfigurable myUserKeysConfigurable;


    public AdditionalOptionsPanel(Component parent) {
      super(parent, true);
      setTitle(J2MEBundle.message("module.settings.optional.midp.settings"));
      init();
    }

    protected JComponent createCenterPanel() {
      myDataSize.setText(MIDPApplicationType.MIDLET_DATA_SIZE + ":");
      myDataSizeField.setText(myTempSettings.get(MIDPApplicationType.MIDLET_DATA_SIZE));

      myDeleteConfirm.setText(MIDPApplicationType.MIDLET_DELETE_CONFIRM + ":");
      myDeleteConfirmField.setText(myTempSettings.get(MIDPApplicationType.MIDLET_DELETE_CONFIRM));

      myDescription.setText(MIDPApplicationType.MIDLET_DESCRIPTION + ":");
      myDescriptionField.setText(myTempSettings.get(MIDPApplicationType.MIDLET_DESCRIPTION));

      myIcon.setText(MIDPApplicationType.MIDLET_ICON + ":");
      myIconField.setText(myTempSettings.get(MIDPApplicationType.MIDLET_ICON));
      myIconField.addBrowseFolderListener(J2MEBundle.message("module.settings.choose.icon.common"),
                                          J2MEBundle.message("module.settings.choose.icon", myMIDletName.getText()),
                                          myProject,
                                          new FileChooserDescriptor(true,
                                                                    false,
                                                                    false,
                                                                    false,
                                                                    false,
                                                                    false));

      myInfoUrl.setText(MIDPApplicationType.MIDLET_INFO_URL + ":");
      myInfoURLField.setText(myTempSettings.get(MIDPApplicationType.MIDLET_INFO_URL));
      myInfoURLField.addBrowseFolderListener(J2MEBundle.message("build.settings.file.url.title"),
                                             J2MEBundle.message("module.settings.application.url"),
                                             myProject,
                                             new FileChooserDescriptor(true,
                                                                       false,
                                                                       false,
                                                                       false,
                                                                       false,
                                                                       false));

      myInstallNotify.setText(MIDPApplicationType.MIDLET_INSTALL_NOTIFY + ":");
      myInstallNotifyURL.setText(myTempSettings.get(MIDPApplicationType.MIDLET_INSTALL_NOTIFY));
      myInstallNotifyURL.addBrowseFolderListener(J2MEBundle.message("build.settings.file.url.title"),
                                                 J2MEBundle.message("module.settings.install.notify.url"),
                                                 myProject,
                                                 new FileChooserDescriptor(true,
                                                                           false,
                                                                           false,
                                                                           false,
                                                                           false,
                                                                           false));
      myUserPanel.setLayout(new BorderLayout());
      myUserKeysConfigurable = new UserKeysConfigurable(myTempUserOptions);
      myUserPanel.add(myUserKeysConfigurable.getUserKeysPanel(), BorderLayout.CENTER);
      return myCentrePanel;
    }

    protected void doOKAction() {
      myUserKeysConfigurable.getTable().stopEditing();
      myTempSettings.put(MIDPApplicationType.MIDLET_DATA_SIZE, myDataSizeField.getText());
      myTempSettings.put(MIDPApplicationType.MIDLET_DELETE_CONFIRM, myDeleteConfirmField.getText());
      myTempSettings.put(MIDPApplicationType.MIDLET_DESCRIPTION, myDescriptionField.getText());
      myTempSettings.put(MIDPApplicationType.MIDLET_ICON, myIconField.getText());
      myTempSettings.put(MIDPApplicationType.MIDLET_INFO_URL, myInfoURLField.getText());
      myTempSettings.put(MIDPApplicationType.MIDLET_INSTALL_NOTIFY, myInstallNotifyURL.getText());
      myTempUserOptions.clear();
      for (final UserDefinedOption userDefinedOption : myUserKeysConfigurable.getUserDefinedOptions().getItems()) {
        myTempUserOptions.add(userDefinedOption);
      }
      myModified = true;
      super.doOKAction();
    }
  }
}
