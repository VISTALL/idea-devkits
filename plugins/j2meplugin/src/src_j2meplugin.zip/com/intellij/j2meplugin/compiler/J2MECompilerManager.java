/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2meplugin.compiler;

import com.intellij.openapi.compiler.CompilerManager;
import com.intellij.openapi.components.ProjectComponent;
import com.intellij.openapi.project.Project;

/**
 * User: anna
 * Date: Aug 20, 2004
 */
public class J2MECompilerManager implements ProjectComponent {
  private Project myProject;
  private J2MEPreverifier myJ2MEPreverifier;
  private J2MEPackagingCompiler myJ2MEPackagingCompiler;

  public static J2MECompilerManager getInstance(Project project) {
    return project.getComponent(J2MECompilerManager.class);
  }

  public J2MECompilerManager(Project project) {
    myProject = project;
    myJ2MEPreverifier = new J2MEPreverifier();
    myJ2MEPackagingCompiler = new J2MEPackagingCompiler(myJ2MEPreverifier);
  }

  public void projectOpened() {
    CompilerManager.getInstance(myProject).addCompiler(myJ2MEPreverifier);
    CompilerManager.getInstance(myProject).addCompiler(myJ2MEPackagingCompiler);
  }

  public void projectClosed() {
    myProject = null;
  }

  public String getComponentName() {
    return "J2ME Compiler Manager";
  }

  public void initComponent() {
    //empty
  }

  public void disposeComponent() {
    //empty
  }
}
