/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.svn.actions;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.help.HelpManager;
import org.jetbrains.idea.svn.history.SvnChangesBrowserSettings;
import org.jetbrains.idea.svn.SvnBundle;
import org.jetbrains.annotations.NonNls;

import javax.swing.*;
import java.util.List;

public class ChooseLocationDialog extends DialogWrapper {
  private final ChooseLocationPanel myPanel = new ChooseLocationPanel();
  private final String myCurrentLocation;

  @NonNls private static final String HELP_ID = "vcs.subversion.browseChanges";

  public ChooseLocationDialog(Project project, String currentLocation) {
    super(project, true);
    myCurrentLocation = currentLocation;
    myPanel.addSelectionListener(new Runnable() {
      public void run() {
        setOKActionEnabled(myPanel.hasSelectedLocation());
      }
    });
    setTitle(SvnBundle.message("dialog.title.select.location"));
    getHelpAction().setEnabled(true);
    init();
  }

  protected Action[] createActions() {
    return new Action[]{getOKAction(), getCancelAction(), getHelpAction()};
  }

  protected void doHelpAction() {
    HelpManager.getInstance().invokeHelp(HELP_ID);
  }

  protected JComponent createCenterPanel() {
    return myPanel.getPanel();
  }

  public void updateFrom(final SvnChangesBrowserSettings settings, final List<String> locations) {
    myPanel.updateFrom(settings, locations, myCurrentLocation);
  }

  public void applyTo(final SvnChangesBrowserSettings settings) {
    myPanel.applyTo(settings);
  }

  public JComponent getPreferredFocusedComponent() {
    return myPanel.getList();
  }
}
