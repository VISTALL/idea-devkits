/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.svn.checkin;

import com.intellij.openapi.vcs.RollbackProvider;
import com.intellij.openapi.vcs.checkin.DifferenceType;
import com.intellij.openapi.vcs.versions.AbstractRevisions;
import org.jetbrains.idea.svn.SvnVcs;
import org.jetbrains.idea.svn.SvnBundle;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.wc.ISVNEventHandler;
import org.tmatesoft.svn.core.wc.SVNEvent;
import org.tmatesoft.svn.core.wc.SVNEventAction;
import org.tmatesoft.svn.core.wc.SVNWCClient;

import java.io.File;

public class SvnRollbackProvider implements RollbackProvider {
  private final AbstractRevisions[] myRevision;
  private final SvnVcs myVcs;

  public SvnRollbackProvider(AbstractRevisions[] revisions, SvnVcs vcs) {
    myRevision = revisions;
    myVcs = vcs;
  }

  public boolean performRollback() {
    final boolean[] result = new boolean[]{true};

    for (int i = 0; i < myRevision.length; i++) {
      AbstractRevisions revisions = myRevision[i];

      if (revisions.getDifference() != DifferenceType.NOT_CHANGED) {
        final File ioFile = revisions.getIOFile();
        try {
          SVNWCClient client = myVcs.createWCClient();
          client.setEventHandler(new ISVNEventHandler() {
            public void handleEvent(SVNEvent event, double progress) {
              if (event.getAction() == SVNEventAction.FAILED_REVERT) {
                result[0] = false;
              }
            }

            public void checkCancelled() {
            }
          });
          client.doRevert(ioFile, false);
        }
        catch (SVNException e) {
          result[0] = false;
        }
      }
    }
    return result[0];
  }

  public boolean isVisible() {
    return true;
  }

  public boolean isEnabled() {
    for (int i = 0; i < myRevision.length; i++) {
      AbstractRevisions revisions = myRevision[i];
      if (revisions.getDifference() != DifferenceType.NOT_CHANGED) {
        return true;
      }
    }
    return false;
  }

  public String getActionName() {
    return SvnBundle.message("action.name.revert");
  }

  public boolean requestConfirmation() {
    return true;
  }

}
