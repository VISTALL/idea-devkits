/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.svn.history;

import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.ui.RefreshableOnComponent;
import com.intellij.openapi.vcs.versionBrowser.ChangeBrowserSettings;
import com.intellij.openapi.vcs.versionBrowser.RepositoryVersion;
import com.intellij.openapi.vcs.versionBrowser.VersionsProvider;
import com.intellij.openapi.util.Comparing;
import com.intellij.util.ui.ColumnInfo;
import org.jetbrains.idea.svn.SvnBundle;
import org.jetbrains.idea.svn.SvnVcs;
import org.tmatesoft.svn.core.ISVNLogEntryHandler;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNLogEntry;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.wc.SVNLogClient;
import org.tmatesoft.svn.core.wc.SVNRevision;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class SvnVersionsProvider implements VersionsProvider {
  private final String myLocation;
  private final Project myProject;

  private final static ColumnInfo<SvnRepositoryVersion, Long> NUMBER =
    new ColumnInfo<SvnRepositoryVersion, Long>(SvnBundle.message("changes.browser.change.column.name")) {
      public Long valueOf(final SvnRepositoryVersion object) {
        return new Long(object.getRevision());
      }

      public Comparator<SvnRepositoryVersion> getComparator() {
        return new Comparator<SvnRepositoryVersion>() {
          public int compare(final SvnRepositoryVersion o1, final SvnRepositoryVersion o2) {
            if (o1.getRevision() == o2.getRevision()) return 0;
            return o1.getRevision() < o2.getRevision() ? -1 : 1;
          }
        };
      }
    };

  private final static ColumnInfo<SvnRepositoryVersion, String> AUTHOR =
    new ColumnInfo<SvnRepositoryVersion, String>(SvnBundle.message("changes.browser.author.column.name")) {
      public String valueOf(final SvnRepositoryVersion object) {
        return object.getAuthor();
      }

      public Comparator<SvnRepositoryVersion> getComparator() {
        return new Comparator<SvnRepositoryVersion>() {
          public int compare(final SvnRepositoryVersion o1, final SvnRepositoryVersion o2) {
            return Comparing.compare(o1.getAuthor(), o2.getAuthor());
          }
        };
      }
    };

  private final static ColumnInfo<SvnRepositoryVersion, String> DATE =
    new ColumnInfo<SvnRepositoryVersion, String>(SvnBundle.message("changes.browser.date.column.name")) {
      public String valueOf(final SvnRepositoryVersion object) {
        return DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(object.getDate());
      }

      public Comparator<SvnRepositoryVersion> getComparator() {
        return new Comparator<SvnRepositoryVersion>() {
          public int compare(final SvnRepositoryVersion o1, final SvnRepositoryVersion o2) {
            return o1.getDate().compareTo(o2.getDate());
          }
        };
      }
    };

  private SvnVcs myVcs;

  public SvnVersionsProvider(final Project project, String svnLocation) {
    myProject = project;
    myLocation = svnLocation;
    myVcs = SvnVcs.getInstance(myProject);
  }

  public ColumnInfo[] getVersionProperties() {
    return new ColumnInfo[]{NUMBER, AUTHOR, DATE};
  }

  public RefreshableOnComponent createFilterUI() {
    return new SvnVersionFilterComponent(myProject);
  }

  public List<RepositoryVersion> getFilteredVersions() throws VcsException {
    final ArrayList<RepositoryVersion> result = new ArrayList<RepositoryVersion>();
    final ProgressIndicator progress = ProgressManager.getInstance().getProgressIndicator();
    if (progress != null) {
      progress.setText(SvnBundle.message("progress.text.changes.collecting.changes"));
      progress.setText2(SvnBundle.message("progress.text2.changes.establishing.connection", myLocation));
    }
    try {
      SVNLogClient logger = myVcs.createLogClient();
      final SVNRepository repository = myVcs.createRepository(myLocation);

      final ChangeBrowserSettings settings = ChangeBrowserSettings.getSettings(myProject);
      final SvnChangesBrowserSettings svnSettings = SvnChangesBrowserSettings.getSettings(myProject);

      final String author = svnSettings.getAuthorFilter();
      final Date dateFrom = settings.getDateAfterFilter();
      final Long changeFrom = settings.getChangeAfterFilter();
      final Date dateTo = settings.getDateBeforeFilter();
      final Long changeTo = settings.getChangeBeforeFilter();

      final SVNRevision revisionBefore;
      if (dateTo != null) {
        revisionBefore = SVNRevision.create(dateTo);
      }
      else if (changeTo != null) {
        revisionBefore = SVNRevision.create(changeTo.longValue());
      }
      else {
        revisionBefore = SVNRevision.HEAD;
      }
      final SVNRevision revisionAfter;
      if (dateFrom != null) {
        revisionAfter = SVNRevision.create(dateFrom);
      }
      else if (changeFrom != null) {
        revisionAfter = SVNRevision.create(changeFrom.longValue());
      }
      else {
        revisionAfter = SVNRevision.create(1);
      }

      logger.doLog(SVNURL.parseURIEncoded(myLocation), new String[]{""}, revisionBefore, revisionBefore, revisionAfter, false, true, 0,
                   new ISVNLogEntryHandler() {
                     public void handleLogEntry(SVNLogEntry logEntry) {
                       if (progress != null) {
                         progress.setText2(SvnBundle.message("progress.text2.processing.revision", logEntry.getRevision()));
                         progress.checkCanceled();
                       }
                       if (author == null || author.equalsIgnoreCase(logEntry.getAuthor())) {
                         result.add(new SvnRepositoryVersion(logEntry, myProject, repository));
                       }
                     }
                   });
      settings.filterChanges(result);
      return result;
    }
    catch (SVNException e) {
      throw new VcsException(e);
    }

  }

}
