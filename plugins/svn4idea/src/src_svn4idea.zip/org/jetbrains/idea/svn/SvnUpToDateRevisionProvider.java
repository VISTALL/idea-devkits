/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.svn;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.localVcs.LvcsRevision;
import com.intellij.openapi.vcs.UpToDateRevisionProvider;
import com.intellij.openapi.vfs.VirtualFile;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNWCClient;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

class SvnUpToDateRevisionProvider implements UpToDateRevisionProvider {
  public SvnUpToDateRevisionProvider() {
  }

  public String getLastUpToDateContentFor(final VirtualFile vFile, boolean quietly) {
    final File[] file = new File[1];
    final String[] charset = new String[1];
    ApplicationManager.getApplication().runReadAction(new Runnable() {
      public void run() {
        file[0] = new File(vFile.getPath());
        charset[0] = vFile.getCharset().name();
      }
    });

    return getLastUpToDateContentFor(file [0], charset [0]);
  }

  public static String getLastUpToDateContentFor(final File file, final String charset) {
    SVNWCClient wcClient = new SVNWCClient(null, null);
    try {
      File lock = new File(file.getParentFile(), SvnUtil.PATH_TO_LOCK_FILE);
      if (lock.exists()) {
        return null;
      }
      ByteArrayOutputStream buffer = new ByteArrayOutputStream();
      wcClient.doGetFileContents(file, SVNRevision.UNDEFINED, SVNRevision.BASE, true, buffer);
      buffer.close();
      return new String(buffer.toByteArray(), charset);
    }
    catch (SVNException e) {
      return null;
    }
    catch (UnsupportedEncodingException e) {
      return null;
    }
    catch (IOException e) {
      return null;
    }
  }

  public boolean itemCanBePurged(LvcsRevision lvcsObject) {
    return true;
  }
}


