/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.svn.checkin;

import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.vcs.FileStatus;
import com.intellij.openapi.vcs.checkin.DifferenceType;
import com.intellij.openapi.vcs.checkin.Revisions;
import com.intellij.openapi.vcs.checkin.changeListBasedCheckin.ChangeListBasedRevisions;
import com.intellij.openapi.vcs.checkin.changeListBasedCheckin.ChangeListBasedRevisionsFactory;
import com.intellij.openapi.vcs.checkin.changeListBasedCheckin.TreeElement;
import com.intellij.openapi.vcs.versions.AbstractRevisions;
import com.intellij.peer.PeerFactory;
import org.jetbrains.idea.svn.SvnBundle;
import org.tmatesoft.svn.core.wc.SVNStatus;
import org.tmatesoft.svn.core.wc.SVNStatusType;

import java.awt.*;

public class SvnRevisions extends ChangeListBasedRevisions<SVNStatus> implements Revisions {
  public static final DifferenceType CONFLICTED_DIFF_TYPE = PeerFactory.getInstance().getFileStatusFactory().createDifferenceType(
    SvnBundle.message("unresolved.difference.type.name"), FileStatus.MERGED_WITH_CONFLICTS,
    TextAttributesKey.createTextAttributesKey("DIFF_UNRESOLVED"), TextAttributesKey.createTextAttributesKey("DIFF_UNRESOLVED"),
    TextAttributesKey.createTextAttributesKey("DIFF_UNRESOLVED"), new Color(243, 220, 199), Color.red);

  public SvnRevisions(TreeElement<SVNStatus> treeElement, ChangeListBasedRevisionsFactory<SVNStatus> changeListBasedRevisionsFactory) {
    super(treeElement, changeListBasedRevisionsFactory);
  }

  public DifferenceType getDifferenceType(SVNStatus status) {
    if (status == null ||
        (status.getContentsStatus() == SVNStatusType.STATUS_UNVERSIONED || status.getContentsStatus() == SVNStatusType.STATUS_MISSING)) {
      return DifferenceType.NOT_CHANGED;
    }
    else if (status.getContentsStatus() == SVNStatusType.STATUS_ADDED) {
      return DifferenceType.INSERTED;
    }
    else if (status.getContentsStatus() == SVNStatusType.STATUS_DELETED) {
      return DifferenceType.DELETED;
    }
    else if (status.isCopied()) {
      return DifferenceType.INSERTED;
    }
    else if (status.getContentsStatus() == SVNStatusType.UNCHANGED) {
      return DifferenceType.NOT_CHANGED;
    }
    else if (status.getContentsStatus() == SVNStatusType.STATUS_CONFLICTED) {
      return CONFLICTED_DIFF_TYPE;
    }
    else {
      return DifferenceType.MODIFIED;
    }
  }

  public AbstractRevisions createChild(TreeElement<SVNStatus> child) {
    return new SvnRevisions(child, myRevisionsFactory);
  }
}
