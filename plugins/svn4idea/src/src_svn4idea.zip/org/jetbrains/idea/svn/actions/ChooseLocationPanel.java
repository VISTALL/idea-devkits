/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.svn.actions;

import org.jetbrains.idea.svn.history.SvnChangesBrowserSettings;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.List;


public class ChooseLocationPanel {
  private JTextField myAlternateLocation;
  private JPanel myPanel;
  private JRadioButton myUseCustomLocation;
  private JList myList;
  private JRadioButton myUseProjectLocation;
  private final DefaultListModel myModel;

  public ChooseLocationPanel() {
    final ActionListener actionListener = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        updateEnabledFields();
      }
    };

    myModel = new DefaultListModel();
    myList.setModel(myModel);
    myList.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);

    final ButtonGroup location = new ButtonGroup();
    location.add(myUseCustomLocation);
    location.add(myUseProjectLocation);

    myUseCustomLocation.addActionListener(actionListener);
    myUseProjectLocation.addActionListener(actionListener);

    addListenerForSelection(myUseCustomLocation,
                            new Runnable() {
                              public void run() {
                                myAlternateLocation.requestFocus();
                              }
                            });

    addListenerForSelection(myUseProjectLocation,
                            new Runnable() {
                              public void run() {
                                myList.requestFocus();
                                if (!myModel.isEmpty() && myList.getSelectedValue() == null) {
                                  myList.getSelectionModel().setSelectionInterval(0, 0);
                                }
                              }
                            });

  }

  private void addListenerForSelection(final JRadioButton radioButton, final Runnable runnable) {
    radioButton.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        if (radioButton.isSelected()) {
          runnable.run();
        }
      }
    });
  }

  public JPanel getPanel() {
    return myPanel;
  }

  public void updateFrom(SvnChangesBrowserSettings settings, List<String> locations, final String currentLocation) {
    myAlternateLocation.setText(settings.LOCATION);
    myUseCustomLocation.setSelected(settings.USE_ALTERNATE_LOCATION);
    myUseProjectLocation.setSelected(!settings.USE_ALTERNATE_LOCATION);

    myModel.clear();
    for (final String location1 : locations) {
      myModel.addElement(location1);
    }


    final String location = settings.LOCATION;
    if (currentLocation != null) {
      select(currentLocation);
    }
    else {
      select(location);
    }

    if (!myModel.isEmpty() && myList.getSelectedValue() == null) {
      myList.getSelectionModel().setSelectionInterval(0, 0);
    }

    updateEnabledFields();
  }

  private void select(final String location) {
    final int index = myModel.indexOf(location);
    if (index >= 0) {
      myList.getSelectionModel().setSelectionInterval(index, index);
    }
  }

  public void applyTo(SvnChangesBrowserSettings settings) {
    if (myList.isEnabled() && myList.getSelectedValue() != null) {
      settings.LOCATION = myList.getSelectedValue().toString();
    }
    else {
      settings.LOCATION = myAlternateLocation.getText();
    }
    settings.USE_ALTERNATE_LOCATION = myUseCustomLocation.isSelected();
  }

  private void updateEnabledFields() {
    myAlternateLocation.setEnabled(myUseCustomLocation.isSelected());
    myList.setEnabled(myUseProjectLocation.isSelected());
  }

  public void addSelectionListener(final Runnable runnable) {
    myList.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        runnable.run();
      }
    });
  }

  public boolean hasSelectedLocation() {
    if (myUseCustomLocation.isSelected()) {
      return myAlternateLocation.getText().trim().length() > 0;
    }
    else {
      return myList.getSelectedValue() != null;
    }
  }

  public JList getList() {
    return myList;
  }
}
