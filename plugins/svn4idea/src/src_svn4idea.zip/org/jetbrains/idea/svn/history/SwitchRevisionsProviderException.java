package org.jetbrains.idea.svn.history;

public class SwitchRevisionsProviderException extends RuntimeException {
}
