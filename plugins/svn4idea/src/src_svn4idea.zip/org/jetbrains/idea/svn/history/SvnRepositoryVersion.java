/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.svn.history;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.versionBrowser.RepositoryVersion;
import com.intellij.openapi.vcs.versions.AbstractRevisions;
import org.jetbrains.idea.svn.SvnVcs;
import org.jetbrains.idea.svn.checkin.AbstractSvnRevisionsFactory;
import org.tmatesoft.svn.core.SVNLogEntry;
import org.tmatesoft.svn.core.SVNLogEntryPath;
import org.tmatesoft.svn.core.io.SVNRepository;

import java.io.File;
import java.util.*;

public class SvnRepositoryVersion implements RepositoryVersion {
  private final SVNLogEntry myLogEntry;
  private final Project myProject;
  private final SVNRepository myRepository;

  public SvnRepositoryVersion(final SVNLogEntry logEntry, Project project, SVNRepository repository) {
    myLogEntry = logEntry;
    myProject = project;
    myRepository = repository;
  }

  public List<AbstractRevisions> getFileRevisions() throws VcsException {
    return new AbstractSvnRevisionsFactory<SVNLogEntryPath>(SvnVcs.getInstance(myProject), myLogEntry) {
      public Map<File, SVNLogEntryPath> createFileToChangeMap(String[] paths) {
        Map changedPaths = myLogEntry.getChangedPaths();
        Map result = new HashMap();
        for (Iterator logPaths = changedPaths.keySet().iterator(); logPaths.hasNext();) {
          String logPath = (String)logPaths.next();
          result.put(new File(logPath), changedPaths.get(logPath));
        }
        return result;
      }

      protected String getPath(final SVNLogEntryPath svnStatus) {
        return svnStatus.getPath();
      }

      protected boolean shouldAddChange(final SVNLogEntryPath svnStatus) {
        return true;
      }

      protected AbstractRevisions createRevisions(final File file) {
        return new SvnVersionRevisions(myFileToTreeElementMap.get(file), this, myRepository, getRevision());
      }

    }.createRevisionsListOn(new String[]{File.separator});
  }

  public String getDescription() {
    return myLogEntry.getMessage();
  }

  public String getAuthor() {
    return myLogEntry.getAuthor();
  }

  public String getUser() {
    return getAuthor();
  }

  public long getRevision() {
    return myLogEntry.getRevision();
  }

  public Date getDate() {
    return myLogEntry.getDate();
  }

  public long getNumber() {
    return getRevision();
  }
}
