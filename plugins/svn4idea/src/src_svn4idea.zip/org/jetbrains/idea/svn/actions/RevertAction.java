/**
 * @copyright
 * ====================================================================
 * Copyright (c) 2003-2004 QintSoft.  All rights reserved.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution.  The terms
 * are also available at http://subversion.tigris.org/license-1.html.
 * If newer versions of this license are posted there, you may use a
 * newer version instead, at your option.
 *
 * This software consists of voluntary contributions made by many
 * individuals.  For exact contribution history, see the revision
 * history and logs, available at http://svnup.tigris.org/.
 * ====================================================================
 * @endcopyright
 */
/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.svn.actions;

import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vcs.*;
import com.intellij.openapi.vcs.changes.Change;
import com.intellij.openapi.vcs.changes.ChangeListManager;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.idea.svn.SvnBundle;
import org.jetbrains.idea.svn.SvnFileStatus;
import org.jetbrains.idea.svn.SvnVcs;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.wc.SVNInfo;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNWCClient;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class RevertAction extends BasicAction {
  protected String getActionName(AbstractVcs vcs) {
    return SvnBundle.message("action.name.revert.files");
  }

  protected boolean needsAllFiles() {
    return false;
  }

  protected boolean isEnabled(Project project, SvnVcs vcs, VirtualFile file) {
    if (file.isDirectory()) {
      SVNInfo info = null;
      SvnVcs.SVNInfoHolder infoValue = vcs.getCachedInfo(file);
      if (infoValue != null) {
        return infoValue.getInfo() != null;
      }
      SVNWCClient wcClient = new SVNWCClient(null, null);
      try {
        info = wcClient.doInfo(new File(file.getPath()), SVNRevision.WORKING);
      }
      catch (SVNException e) {
        //
      }
      vcs.cacheInfo(file, info);
      return info != null;
    }
    FileStatus fStatus = FileStatusManager.getInstance(project).getStatus(file);
    return fStatus != FileStatus.NOT_CHANGED && fStatus != FileStatus.IGNORED &&
                    fStatus != SvnFileStatus.EXTERNAL && fStatus != SvnFileStatus.SWITCHED;
  }

  protected boolean needsFiles() {
    return true;
  }

  protected void perform(Project project, SvnVcs activeVcs, VirtualFile file, DataContext context, AbstractVcsHelper helper)
    throws VcsException {
    batchPerform(project, activeVcs, new VirtualFile[] {file}, context, helper);
  }

  protected void batchPerform(Project project, SvnVcs activeVcs, VirtualFile[] file, DataContext context, AbstractVcsHelper helper)
    throws VcsException {
    ApplicationManager.getApplication().saveAll();
    ChangeListManager changeListManager = ChangeListManager.getInstance(project);
    changeListManager.ensureUpToDate(false);

    List<Change> changes = new ArrayList<Change>();
    for (VirtualFile aFile : file) {
      changes.addAll(changeListManager.getChangesIn(aFile));
    }
    if (changes.isEmpty()) {
      Messages.showInfoMessage(project, SvnBundle.message("message.text.revert.no.modifications.found"), SvnBundle.message("message.title.revert.no.modifications.found"));
      return;
    }
    AbstractVcsHelper.getInstance(project).showRollbackChangesDialog(changes);
  }

  protected boolean isBatchAction() {
    return true;
  }
}
