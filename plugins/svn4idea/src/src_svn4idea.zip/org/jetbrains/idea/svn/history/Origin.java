package org.jetbrains.idea.svn.history;

public enum Origin {
  LIVE,
  INTERNAL,
  VISUAL
}
