package org.jetbrains.idea.svn;

import com.intellij.openapi.util.Pair;
import com.intellij.openapi.vfs.VirtualFile;
import org.tmatesoft.svn.core.SVNURL;

import java.io.File;
import java.util.Map;

public class SvnFileUrlMappingRefresher implements SvnFileUrlMapping {
  private final static int timeout = 1000;
  private long myTimestamp;

  private final RefreshableSvnFileUrlMapping myDelegate;

  protected SvnFileUrlMappingRefresher(final RefreshableSvnFileUrlMapping delegate) {
    myDelegate = delegate;
  }

  public SVNURL getUrlForFile(final File file) {
    refresh();

    return myDelegate.getUrlForFile(file);
  }

  public String getLocalPath(final String url) {
    refresh();

    return myDelegate.getLocalPath(url);
  }

  public VirtualFile getVcRootByUrl(final String url) {
    refresh();

    return myDelegate.getVcRootByUrl(url);
  }

  public RootMixedInfo getWcRootForUrl(final String url) {
    refresh();

    return myDelegate.getWcRootForUrl(url);
  }

  public Map<String,RootUrlInfo> getAllWcInfos() {
    refresh();

    return myDelegate.getAllWcInfos();
  }

  public Pair<String, RootUrlInfo> getWcRootForFilePath(final File file) {
    refresh();

    return myDelegate.getWcRootForFilePath(file);
  }

  private synchronized void refresh() {
    final long current = System.currentTimeMillis();
    if (current > (myTimestamp + timeout)) {
      myDelegate.doRefresh();
      myTimestamp = System.currentTimeMillis();
    }
  }

  protected interface RefreshableSvnFileUrlMapping extends SvnFileUrlMapping {
    void doRefresh();
  }
}

