/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.svn.history;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.checkin.DifferenceType;
import com.intellij.openapi.vcs.checkin.changeListBasedCheckin.ChangeListBasedRevisions;
import com.intellij.openapi.vcs.checkin.changeListBasedCheckin.ChangeListBasedRevisionsFactory;
import com.intellij.openapi.vcs.checkin.changeListBasedCheckin.TreeElement;
import com.intellij.openapi.vcs.versions.AbstractRevisions;
import com.intellij.openapi.vcs.versions.VersionRevisions;
import org.jetbrains.idea.svn.SvnBundle;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNLogEntryPath;
import org.tmatesoft.svn.core.io.SVNRepository;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;

public class SvnVersionRevisions extends ChangeListBasedRevisions<SVNLogEntryPath> implements VersionRevisions {
  private final SVNRepository myRepository;
  private final long myRevision;

  public SvnVersionRevisions(final TreeElement<SVNLogEntryPath> treeElement,
                             final ChangeListBasedRevisionsFactory<SVNLogEntryPath> perforceRevisionsFactory,
                             SVNRepository repository,
                             long revision) {
    super(treeElement, perforceRevisionsFactory);
    myRepository = repository;
    myRevision = revision;
  }

  protected DifferenceType getDifferenceType(final SVNLogEntryPath change) {
    if (change != null) {
      final char type = change.getType();
      switch (type) {
        case 'A':
          return DifferenceType.INSERTED;
        case 'D':
          return DifferenceType.DELETED;
        case 'M':
          return DifferenceType.MODIFIED;
        case 'R':
          return DifferenceType.MODIFIED;
      }
    }
    return DifferenceType.NOT_CHANGED;
  }

  protected AbstractRevisions createChild(final TreeElement<SVNLogEntryPath> child) {
    return new SvnVersionRevisions(child, myRevisionsFactory, myRepository, myRevision);
  }

  public String getFirstContent() throws VcsException {
    return getContent(myRevision - 1);
  }

  private String getContent(final long revision) {
    final String path = getChange().getPath();
    final OutputStream buffer = new ByteArrayOutputStream();
    ConentLoader loader = new ConentLoader(path, buffer, revision);
    if (ApplicationManager.getApplication().isDispatchThread()) {
      ProgressManager.getInstance()
        .runProcessWithProgressSynchronously(loader, SvnBundle.message("progress.title.loading.file.content"), false, null);
    }
    else {
      loader.run();
    }
    if (loader.getException() == null) {
      return buffer.toString();
    }
    return null;
  }

  public String getSecondContent() throws VcsException {
    return getContent(myRevision);
  }

  private class ConentLoader implements Runnable {
    private String myPath;
    private long myRevision;
    private OutputStream myDst;
    private SVNException myException;

    public ConentLoader(String path, OutputStream dst, long revision) {
      myPath = path;
      myDst = dst;
      myRevision = revision;
    }

    public SVNException getException() {
      return myException;
    }

    public void run() {
      ProgressIndicator progress = ProgressManager.getInstance().getProgressIndicator();
      if (progress != null) {
        progress.setText(SvnBundle.message("progress.text.loading.contents", myPath));
        progress.setText2(SvnBundle.message("progress.text2.revision.information", myRevision));
      }
      try {
        myRepository.getFile(myPath, myRevision, null, myDst);
      }
      catch (SVNException e) {
        myException = e;
      }
    }
  }
}
