package org.jetbrains.idea.svn;

import org.jetbrains.idea.svn.config.DefaultProxyGroup;
import org.jetbrains.idea.svn.config.ProxyGroup;

import java.util.*;

public class SvnServerFileManagerImpl implements SvnServerFileManager {
  private final DefaultProxyGroup myDefaultGroup;
  private final Map<String, ProxyGroup> myGroups;
  private final IdeaSVNConfigFile myFile;

  public SvnServerFileManagerImpl(final IdeaSVNConfigFile file) {
    myFile = file;
    myFile.updateGroups();

    myGroups = new HashMap<String, ProxyGroup>();
    myGroups.putAll(file.getAllGroups());
    myDefaultGroup = file.getDefaultGroup();
  }

  public DefaultProxyGroup getDefaultGroup() {
    return (DefaultProxyGroup) myDefaultGroup.copy();
  }

  public Map<String, ProxyGroup> getGroups() {
    // return deep copy 
    final Map<String, ProxyGroup> result = new HashMap<String, ProxyGroup>(myGroups);
    for (Map.Entry<String, ProxyGroup> entry : myGroups.entrySet()) {
      result.put(entry.getKey(), entry.getValue().copy());
    }
    return result;
  }

  public void updateUserServerFile(final Collection<ProxyGroup> newUserGroups) {
    final Map<String, ProxyGroup> oldGroups = getGroups();

    for (ProxyGroup proxyGroup : newUserGroups) {
      if (proxyGroup.isDefault()) {
        processGroup(proxyGroup, getDefaultGroup(), false);
      } else {
        findAndProcessGroup(proxyGroup, oldGroups);
      }
    }

    for (String groupName : oldGroups.keySet()) {
      myFile.deleteGroup(groupName);
    }

    myFile.save();
  }

  private void processGroup(final ProxyGroup newGroup, final ProxyGroup oldGroup, final boolean groupWasAdded) {
    final String newGroupName = newGroup.getName();
    if (groupWasAdded) {
      myFile.addGroup(newGroupName, newGroup.getPatterns(), newGroup.getProperties());
    } else {
      final Map<String, String> oldProperties = oldGroup.getProperties();
      final Map<String, String> newProperties = newGroup.getProperties();

      final Set<String> deletedProperties = new HashSet<String>();
      for (String oldKey : oldProperties.keySet()) {
        if (! newProperties.containsKey(oldKey)) {
          deletedProperties.add(oldKey);
        }
      }

      final Map<String, String> newOrModifiedProperties = new HashMap<String, String>();
      for (Map.Entry<String, String> entry : newProperties.entrySet()) {
        final String oldValue = oldProperties.get(entry.getKey());
        if ((oldValue == null) || (! oldValue.equals(entry.getValue()))) {
          newOrModifiedProperties.put(entry.getKey(), entry.getValue());
        }
      }

      myFile.modifyGroup(newGroupName, newGroup.getPatterns(), deletedProperties, newOrModifiedProperties, newGroup.isDefault());
    }
  }

  private void findAndProcessGroup(final ProxyGroup newGroup, final Map<String, ProxyGroup> oldGroups) {
    final String newGroupName = newGroup.getName();
    final ProxyGroup oldGroup = oldGroups.get(newGroupName);
    final boolean groupWasAdded = (oldGroup == null) && (! newGroup.isDefault());
    if (! groupWasAdded) {
      // to track deleted
      oldGroups.remove(newGroupName);
    }
    processGroup(newGroup, oldGroup, groupWasAdded);
  }
}
