/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.svn.status;

import com.intellij.openapi.options.Configurable;
import com.intellij.openapi.progress.ProcessCanceledException;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.vcs.FilePath;
import com.intellij.openapi.vcs.VcsException;
import com.intellij.openapi.vcs.update.*;
import org.jetbrains.idea.svn.SvnUtil;
import org.jetbrains.idea.svn.SvnVcs;
import org.jetbrains.idea.svn.SvnWCRootCrawler;
import org.jetbrains.idea.svn.SvnBundle;
import org.jetbrains.annotations.NonNls;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNNodeKind;
import org.tmatesoft.svn.core.wc.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

public class SvnStatusEnvironment implements UpdateEnvironment {

  @NonNls public static final String MISSING_ID = "missing";
  @NonNls public static final String REPLACED_ID = "replaced";
  @NonNls public static final String OBSTRUCTED_ID = "obstructed";
  @NonNls public static final String EXTERNAL_ID = "external";
  @NonNls public static final String SWITCHED_ID = "switch";
  @NonNls public static final String LOCK_ID = "lock";


  private final SvnVcs myVcs;

  public SvnStatusEnvironment(SvnVcs vcs) {
    myVcs = vcs;
  }

  public void fillGroups(UpdatedFiles updatedFiles) {

  }

  public UpdateSession updateDirectories(FilePath[] contentRoots,
                                         final UpdatedFiles updatedFiles,
                                         final ProgressIndicator progressIndicator)
    throws ProcessCanceledException {

    final ArrayList<VcsException> exceptions = new ArrayList<VcsException>();

    ISVNStatusHandler statusHandler = new StatusEventHandler(updatedFiles);
    StatusCrawler crawler = new StatusCrawler(myVcs, statusHandler, exceptions);

    for (FilePath contentRoot : contentRoots) {
      if (progressIndicator != null && progressIndicator.isCanceled()) {
        throw new ProcessCanceledException();
      }
      if (contentRoot.getIOFile() != null) {
        SvnUtil.crawlWCRoots(contentRoot.getIOFile(), crawler, progressIndicator);
      }
    }
    return new UpdateSessionAdapter(exceptions, false);
  }

  public Configurable createConfigurable(Collection collection) {
    return new SvnStatusConfigurable(myVcs);
  }

  private static class StatusEventHandler implements ISVNStatusHandler {
    private final UpdatedFiles myUpdatedFiles;
    private final FileGroup myModifiedOnServerFiles;
    private final FileGroup myReplacedOnServerFiles;

    public StatusEventHandler(UpdatedFiles updatedFiles) {
      myUpdatedFiles = updatedFiles;

      myModifiedOnServerFiles = new FileGroup("UpdatedOnServer", "Modified on Server", true, "Modified On Server", false);
      myReplacedOnServerFiles = new FileGroup("ReplacedOnServer", "Replaced on Server", true, "Replaced On Server", false);
      myUpdatedFiles.getGroupById(FileGroup.CHANGED_ON_SERVER_ID).addChild(myModifiedOnServerFiles);
      myUpdatedFiles.getGroupById(FileGroup.CHANGED_ON_SERVER_ID).addChild(myReplacedOnServerFiles);
    }

    public void handleStatus(SVNStatus status) {
      String path;
      if (status.getFile() != null) {
        path = status.getFile().getAbsolutePath();
      }
      else {
        return;
      }

      if (status.getContentsStatus() == SVNStatusType.STATUS_ADDED) {
        myUpdatedFiles.getGroupById(FileGroup.LOCALLY_ADDED_ID).add(path);
      }
      else if (status.getContentsStatus() == SVNStatusType.STATUS_CONFLICTED ||
        status.getPropertiesStatus() == SVNStatusType.STATUS_CONFLICTED) {
        myUpdatedFiles.getGroupById(FileGroup.MERGED_WITH_CONFLICT_ID).add(path);
      }
      else if (status.getContentsStatus() == SVNStatusType.STATUS_DELETED) {
        myUpdatedFiles.getGroupById(FileGroup.LOCALLY_REMOVED_ID).add(path);
      }
      else if (status.getContentsStatus() == SVNStatusType.STATUS_MISSING) {
        if (myUpdatedFiles.getGroupById(MISSING_ID) == null) {
          myUpdatedFiles.registerGroup(createFileGroup(SvnBundle.message("status.group.name.missing"), MISSING_ID));
        }
        myUpdatedFiles.getGroupById(MISSING_ID).add(path);
      }
      else if (status.getContentsStatus() == SVNStatusType.STATUS_REPLACED) {
        if (myUpdatedFiles.getGroupById(REPLACED_ID) == null) {
          myUpdatedFiles.registerGroup(createFileGroup(SvnBundle.message("status.group.name.replaced"), REPLACED_ID));
        }
        myUpdatedFiles.getGroupById(REPLACED_ID).add(path);
      }
      else if (status.getContentsStatus() == SVNStatusType.STATUS_MODIFIED ||
               status.getPropertiesStatus() == SVNStatusType.STATUS_MODIFIED) {
        myUpdatedFiles.getGroupById(FileGroup.MODIFIED_ID).add(path);
      }
      else if (status.getContentsStatus() == SVNStatusType.STATUS_OBSTRUCTED) {
        if (myUpdatedFiles.getGroupById(OBSTRUCTED_ID) == null) {
          myUpdatedFiles.registerGroup(createFileGroup(SvnBundle.message("status.group.name.obstructed"), OBSTRUCTED_ID));
        }
        myUpdatedFiles.getGroupById(OBSTRUCTED_ID).add(path);
      }
      else if (status.getContentsStatus() == SVNStatusType.STATUS_UNVERSIONED) {
        if (status.getFile().isFile() || !SVNWCUtil.isVersionedDirectory(status.getFile())) {
          myUpdatedFiles.getGroupById(FileGroup.UNKNOWN_ID).add(path);
        }
      }
      else if (status.isCopied()) {
        myUpdatedFiles.getGroupById(FileGroup.LOCALLY_ADDED_ID).add(path);
      }
      else if (status.getContentsStatus() == SVNStatusType.STATUS_EXTERNAL) {
        if (myUpdatedFiles.getGroupById(EXTERNAL_ID) == null) {
          myUpdatedFiles.registerGroup(createFileGroup(SvnBundle.message("status.group.name.externals"), EXTERNAL_ID));
        }
        myUpdatedFiles.getGroupById(EXTERNAL_ID).add(path);
      }
      if (status.isSwitched()) {
        if (myUpdatedFiles.getGroupById(SWITCHED_ID) == null) {
          myUpdatedFiles.registerGroup(createFileGroup(SvnBundle.message("status.group.name.switched"), SWITCHED_ID));
        }
        myUpdatedFiles.getGroupById(SWITCHED_ID).add(path);
      }
      if (status.getLocalLock() != null) {
        if (myUpdatedFiles.getGroupById(LOCK_ID) == null) {
          myUpdatedFiles.registerGroup(createFileGroup(SvnBundle.message("status.group.name.locked"), LOCK_ID));
        }
        myUpdatedFiles.getGroupById(LOCK_ID).add(path);
      }
      if (status.getRemoteContentsStatus() != SVNStatusType.STATUS_NONE ||
          status.getRemotePropertiesStatus() != SVNStatusType.STATUS_NONE) {
        if (status.getRemoteContentsStatus() == SVNStatusType.STATUS_ADDED) {
          myUpdatedFiles.getGroupById(FileGroup.CREATED_ID).add(path);
        }
        else if (status.getRemoteContentsStatus() == SVNStatusType.STATUS_REPLACED) {
          myReplacedOnServerFiles.add(path);
        }
        else if (status.getRemoteContentsStatus() == SVNStatusType.STATUS_DELETED) {
          myUpdatedFiles.getGroupById(FileGroup.REMOVED_FROM_REPOSITORY_ID).add(path);
        }
        else {
          if (status.getRemoteKind() == SVNNodeKind.DIR && status.getRemotePropertiesStatus() == SVNStatusType.STATUS_NONE) {
            return;
          }
          myModifiedOnServerFiles.add(path);
        }
      }
    }
  }

  public static FileGroup createFileGroup(String name, String id) {
    return new FileGroup(name, name, false, id, true);
  }

  private static class StatusCrawler implements SvnWCRootCrawler {
    private SvnVcs myVcs;
    private ISVNStatusHandler myHandler;
    private Collection<VcsException> myExceptions;

    public StatusCrawler(SvnVcs vcs, ISVNStatusHandler handler, Collection<VcsException> exceptions) {
      myVcs = vcs;
      myHandler = handler;
      myExceptions = exceptions;
    }

    public Collection<File> handleWorkingCopyRoot(File root, ProgressIndicator progress) {
      final Collection<File> result = new HashSet<File>();
      if (progress != null) {
        progress.setText2(root.getAbsolutePath());
      }
      try {
        SVNStatusClient client = myVcs.createStatusClient();
        client.setIgnoreExternals(false);
        boolean remote = myVcs.getSvnConfiguration().isRemoteStatus();
        if (progress != null) {
          progress.setText(!remote ? (SvnBundle.message("progress.text.status.analyzing.local", root)) : (SvnBundle.message(
            "progress.text.status.analizyng.remote", root)));
        }
        client.doStatus(root, true, remote, true, true, new ISVNStatusHandler() {
          public void handleStatus(SVNStatus status) throws SVNException {
            myHandler.handleStatus(status);
            if (status.getContentsStatus() == SVNStatusType.STATUS_UNVERSIONED && status.getFile().isDirectory()) {
              result.add(status.getFile());
            }
          }
        });
      }
      catch (SVNException e) {
        myExceptions.add(new VcsException(e));
      }
      return result;
    }
  }
}
