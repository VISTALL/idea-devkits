package org.jetbrains.idea.svn.dialogs;

enum IterationResultHolder {
  DO_NOTHING,
  SKIP,
  RESULT
}
