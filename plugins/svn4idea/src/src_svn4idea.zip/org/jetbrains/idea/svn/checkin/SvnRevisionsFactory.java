/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jetbrains.idea.svn.checkin;

import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.vcs.versions.AbstractRevisions;
import com.intellij.openapi.vcs.VcsException;
import org.jetbrains.idea.svn.*;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNNodeKind;
import org.tmatesoft.svn.core.wc.ISVNStatusHandler;
import org.tmatesoft.svn.core.wc.SVNStatus;
import org.tmatesoft.svn.core.wc.SVNStatusClient;
import org.tmatesoft.svn.core.wc.SVNStatusType;

import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class SvnRevisionsFactory extends AbstractSvnRevisionsFactory<SVNStatus> {
  public SvnRevisionsFactory(SvnVcs svnVcs) {
    super(svnVcs, null);
  }

  public AbstractRevisions createRevisions(File file) {
    return new SvnRevisions(myFileToTreeElementMap.get(file), this);
  }

  public boolean isFile(SVNStatus changeData) {
    if (changeData == null) return false;
    return changeData.getKind() != SVNNodeKind.DIR;
  }

  protected Map<File, SVNStatus> createFileToChangeMap(String[] paths) throws VcsException {
    final Map<File, SVNStatus> result = new HashMap<File, SVNStatus>();
    CommitCrawler commitCralwer = new CommitCrawler(mySvnVcs,  result);
    ProgressIndicator progress = ProgressManager.getInstance().getProgressIndicator();
    for (String path : paths) {
      SvnUtil.crawlWCRoots(new File(path).getAbsoluteFile(), commitCralwer, progress);
    }
    commitCralwer.getCommitables();
    return result;
  }

  private static class CommitCrawler implements SvnWCRootCrawler {
    private SvnVcs myVcs;
    private Map<File, SVNStatus> myCommitables;

    public CommitCrawler(SvnVcs vcs, Map<File, SVNStatus> commitables) {
      myVcs = vcs;
      myCommitables = commitables;
    }

    public Map getCommitables() {
      return myCommitables;
    }

    public Collection<File> handleWorkingCopyRoot(File root, ProgressIndicator progress) {
      final Collection<File> result = new HashSet<File>();
      if (progress != null) {
        progress.setText(SvnBundle.message("progress.text.collecting.commitables", root.getAbsolutePath()));
      }
      try {
        SVNStatusClient client = myVcs.createStatusClient();
        client.setIgnoreExternals(true);
        client.doStatus(root, true, false, false, false, new ISVNStatusHandler() {
          public void handleStatus(SVNStatus status) {
            if ((status.getContentsStatus() == SVNStatusType.STATUS_EXTERNAL ||
                 status.getContentsStatus() == SVNStatusType.STATUS_UNVERSIONED) &&
                                                                                 status.getFile().isDirectory()) {
              result.add(status.getFile());
              return;
            }
            if (status.getContentsStatus() == SVNStatusType.STATUS_MODIFIED ||
                status.getContentsStatus() == SVNStatusType.STATUS_REPLACED ||
                status.getContentsStatus() == SVNStatusType.STATUS_ADDED ||
                status.getContentsStatus() == SVNStatusType.STATUS_DELETED ||
                status.getPropertiesStatus() == SVNStatusType.STATUS_MODIFIED ||
                status.isCopied()) {
              myCommitables.put(status.getFile(), status);
            }

            if (status.getContentsStatus() == SVNStatusType.STATUS_CONFLICTED
                && SvnConfiguration.getInstance(myVcs.getProject()).PROCESS_UNRESOLVED) {
              myCommitables.put(status.getFile(), status);
            }
          }
        });
      }
      catch (SVNException e) {
        //
      }
      return result;
    }
  }
}
