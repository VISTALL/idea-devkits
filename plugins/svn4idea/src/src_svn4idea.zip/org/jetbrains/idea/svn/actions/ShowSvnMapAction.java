package org.jetbrains.idea.svn.actions;

import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.project.Project;
import org.jetbrains.idea.svn.SvnBundle;
import org.jetbrains.idea.svn.dialogs.SvnMapDialog;

public class ShowSvnMapAction extends AnAction {
  public ShowSvnMapAction() {
    super(SvnBundle.message("action.show.svn.map.text"));
  }

  @Override
  public void update(final AnActionEvent e) {
    final DataContext dataContext = e.getDataContext();
    final Project project = DataKeys.PROJECT.getData(dataContext);

    final Presentation presentation = e.getPresentation();
    presentation.setVisible(project != null);
    presentation.setEnabled(project != null);

    presentation.setText(SvnBundle.message("action.show.svn.map.text"));
    presentation.setDescription(SvnBundle.message("action.show.svn.map.description"));
  }

  public void actionPerformed(final AnActionEvent e) {
    final DataContext dataContext = e.getDataContext();
    final Project project = DataKeys.PROJECT.getData(dataContext);
    if (project == null) {
      return;
    }

    final SvnMapDialog dialog = new SvnMapDialog(project);
    dialog.show();
  }
}
