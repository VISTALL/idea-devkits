/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.web.jsr45;

import com.intellij.debugger.DebuggerManager;
import com.intellij.debugger.engine.DebugProcess;
import com.intellij.debugger.engine.DebugProcessAdapter;
import com.intellij.debugger.engine.DefaultJSPPositionManager;
import com.intellij.debugger.engine.PositionManagersFactory;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.javaee.appServerIntegrations.AppServerIntegration;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.serverInstances.DefaultServerInstance;
import com.intellij.javaee.facet.JavaeeFacet;

public class JSR45ServerInstance extends DefaultServerInstance{
  public JSR45ServerInstance(CommonModel runConfiguration) {
    super(runConfiguration);
  }

  public AppServerIntegration getIntegration() {
    return JSR45ServerManager.getInstance();
  }

  public void start(ProcessHandler processHandler) {
    super.start(processHandler);
    final CommonModel configuration = getCommonModel();
    final JSR45Model jsr45Model = (JSR45Model)configuration.getServerModel();
    DebuggerManager.getInstance(configuration.getProject()).addDebugProcessListener(processHandler, new DebugProcessAdapter() {
      public void processAttached(DebugProcess process) {
        process.appendPositionManager(createPositionManager(process, configuration, jsr45Model));
      }
    });
  }

  private static DefaultJSPPositionManager createPositionManager(final DebugProcess process,
                                                            final CommonModel configuration,
                                                            final JSR45Model jsr45Model) {
    final JavaeeFacet[] facets = getScopeFacets(configuration);
    if (jsr45Model.USE_WEBSPHERE51_LINEMAPPING_MODEL) {
      return PositionManagersFactory.getInstance().createWebSphereSpecificPositionManager(process, facets, jsr45Model.JSP_PACKAGE);
    }
    else {
      return PositionManagersFactory.getInstance().createJSR45PositionManager(process, facets, jsr45Model.JSP_PACKAGE);
    }
  }
}
