/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.web.jsr45;

import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.options.SettingsEditor;

import javax.swing.*;

import org.jetbrains.annotations.NotNull;

public class JSR45RunConfigurationEditor extends SettingsEditor<CommonModel> {
  private JPanel myPanel;

  private JTextField myJSPPackage;
  private JTextField myPort;
  private JTextField myVMOptions;
  private JCheckBox myWebSphere51ModelCheckBox;
  private JLabel myVMOptionsLabel;
  private JLabel myPortLabel;
  private final boolean myLocal;

  public JSR45RunConfigurationEditor(final boolean local) {
    myLocal = local;
    myPort.setVisible(myLocal);
    myPortLabel.setVisible(myLocal);
    myVMOptions.setVisible(myLocal);
    myVMOptionsLabel.setVisible(myLocal);
  }

  @NotNull
  public JComponent createEditor() {
    return myPanel;
  }

  public void applyEditorTo(CommonModel runConfiguration) throws ConfigurationException {
    JSR45Model jsr45Model = ((JSR45Model)runConfiguration.getServerModel());
    jsr45Model.JSP_PACKAGE = myJSPPackage.getText();
    jsr45Model.USE_WEBSPHERE51_LINEMAPPING_MODEL = myWebSphere51ModelCheckBox.isSelected();

    if (myLocal) {
      jsr45Model.VM_OPTS = myVMOptions.getText();
      try {
        jsr45Model.LOCAL_PORT = Integer.parseInt(myPort.getText());
      }
      catch (NumberFormatException e) {
        throw new ConfigurationException(Jsr45DebugBundle.message("message.text.invalid.port.value", myPort.getText()));
      }
    }
  }

  public void resetEditorFrom(CommonModel runConfiguration) {
    JSR45Model jsr45Model = ((JSR45Model)runConfiguration.getServerModel());
    myWebSphere51ModelCheckBox.setSelected(jsr45Model.USE_WEBSPHERE51_LINEMAPPING_MODEL);
    myJSPPackage.setText(jsr45Model.JSP_PACKAGE);

    if (myLocal) {
      myPort.setText(String.valueOf(jsr45Model.LOCAL_PORT));
      myVMOptions.setText(jsr45Model.VM_OPTS);
    }
  }

  public void disposeEditor() {
  }
}
