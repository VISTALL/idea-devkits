/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.j2ee.web.jsr45;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.configurations.RuntimeConfigurationError;
import com.intellij.execution.configurations.RuntimeConfigurationException;
import com.intellij.execution.process.ProcessHandler;
import com.intellij.javaee.deployment.DeploymentProvider;
import com.intellij.javaee.run.configuration.CommonModel;
import com.intellij.javaee.run.configuration.ServerModel;
import com.intellij.javaee.run.execution.DefaultOutputProcessor;
import com.intellij.javaee.run.execution.OutputProcessor;
import com.intellij.javaee.serverInstances.J2EEServerInstance;
import com.intellij.openapi.options.SettingsEditor;
import com.intellij.openapi.util.DefaultJDOMExternalizer;
import com.intellij.openapi.util.InvalidDataException;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.WriteExternalException;
import org.jdom.Element;

import java.util.ArrayList;
import java.util.List;

public class JSR45Model implements ServerModel{
  public String JSP_PACKAGE = "";
  public String VM_OPTS = "";
  public boolean USE_WEBSPHERE51_LINEMAPPING_MODEL = false;
  public int LOCAL_PORT = 80;
  private CommonModel myCommonModel;

  public int getDefaultPort() {
    return 80;
  }

  public void setCommonModel(CommonModel commonModel) {
    myCommonModel = commonModel;
  }

  public SettingsEditor<CommonModel> getEditor() {
    return new JSR45RunConfigurationEditor(myCommonModel.isLocal());
  }

  public J2EEServerInstance createServerInstance() throws ExecutionException {
    try {
      checkValid();
    }
    catch (RuntimeConfigurationException e) {
      throw new ExecutionException(e.getLocalizedMessage());
    }
    return new JSR45ServerInstance(myCommonModel);
  }

  public void checkValid() throws RuntimeConfigurationException {
    RuntimeConfigurationError executionException = new RuntimeConfigurationError(
      Jsr45DebugBundle.message("exception.text.not.valid.java.package.name", JSP_PACKAGE));

    if(JSP_PACKAGE.length() == 0) {
      throw executionException;
    }

    if(!Character.isJavaIdentifierStart(JSP_PACKAGE.charAt(0))) {
      throw executionException;

    }
    for(int i = 1; i < JSP_PACKAGE.length(); i++) {
      char ch = JSP_PACKAGE.charAt(i);

      if(ch != '.' && !Character.isJavaIdentifierPart(ch)) throw executionException;
    }

    if(myCommonModel.isLocal() && "".equals(VM_OPTS)) {
      throw new RuntimeConfigurationException(Jsr45DebugBundle.message("exception.text.not.valid.environment.vartiable.name", VM_OPTS));
    }
  }

  public DeploymentProvider getDeploymentProvider() {
    return null;
  }

  public void writeExternal(Element element) throws WriteExternalException {
    DefaultJDOMExternalizer.writeExternal(this, element);
  }

  public void readExternal(Element element) throws InvalidDataException {
    DefaultJDOMExternalizer.readExternal(this, element);
  }

  public int getLocalPort() {
    return LOCAL_PORT;
  }

  public void checkConfigurationInt() throws RuntimeConfigurationException {
    checkValid();
  }

  public List<Pair<String, Integer>> getAddressesToCheck() {
    List<Pair<String, Integer>> result = new ArrayList<Pair<String, Integer>>();
    result.add(new Pair<String, Integer>(myCommonModel.getHost(), myCommonModel.getPort()));
    return result;
  }

  public String getDefaultUrlForBrowser() {
    return "http://" + myCommonModel.getHost() + ":" + myCommonModel.getPort();
  }

  public OutputProcessor createOutputProcessor(ProcessHandler j2EEOSProcessHandlerWrapper, J2EEServerInstance serverInstance) {
    return new DefaultOutputProcessor(j2EEOSProcessHandlerWrapper);
  }

  public void checkConfiguration() throws RuntimeConfigurationException {
  }

  public JSR45Model clone() throws CloneNotSupportedException {
    return (JSR45Model)super.clone();
  }
}
